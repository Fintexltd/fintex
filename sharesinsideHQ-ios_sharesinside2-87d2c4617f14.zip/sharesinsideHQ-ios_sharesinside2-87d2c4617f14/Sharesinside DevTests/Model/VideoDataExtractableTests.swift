//
//  VideoDataExtractableTests.swift
//  Sharesinside DevTests
//
//  Created by Bartosz Żmija on 03/08/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

@testable import Sharesinside_Dev
import XCTest

struct VideoDataExtractableMock: VideoDataExtractable {
    let videos: [Video]
    let videoLinks: [VideoLink]
}

class VideoDataExtractableTests: XCTestCase {

    private let video = Video(
        id: 1,
        oryginalName: "video",
        mimeType: "type",
        url: "url",
        videoImg: "img"
    )

    private let videoLink = VideoLink(
        id: 1,
        name: "link",
        type: "type",
        url: "urlLink",
        videoImg: "imgLink"
    )

    private lazy var videoData = {
        VideoData(videoUrl: URL(string: video.url)!, videoThumbnailUrl: URL(string: video.videoImg))
    }()

    private lazy var videoLinkData = {
        VideoData(videoUrl: URL(string: videoLink.url)!, videoThumbnailUrl: URL(string: videoLink.videoImg))
    }()

    func testShouldReturnNilVideoDataForEmptyVideosAndVideoLinks() {
        // Given
        let sut = VideoDataExtractableMock(videos: [], videoLinks: [])

        // When
        let videoData = sut.videoData

        // Then
        XCTAssertNil(videoData)
    }

    func testShouldReturnVideoDataWithVideoForVideoAndEmptyVideoLinks() {
        // Given
        let sut = VideoDataExtractableMock(videos: [video], videoLinks: [])

        // When
        let expectedVideoData = sut.videoData

        // Then
        XCTAssertEqual(expectedVideoData, videoData)
    }

    func testShouldReturnVideoDataWithVideoLinkForEmptyVideosAndVideoLink() {
        // Given
        let sut = VideoDataExtractableMock(videos: [], videoLinks: [videoLink])

        // When
        let expectedVideoData = sut.videoData

        // Then
        XCTAssertEqual(expectedVideoData, videoLinkData)
    }

    func testShouldReturnVideoDataWithVideoForVideoAndVideoLink() {
        // Given
        let sut = VideoDataExtractableMock(videos: [video], videoLinks: [videoLink])

        // When
        let expectedVideoData = sut.videoData

        // Then
        XCTAssertEqual(expectedVideoData, videoData)
    }
}
