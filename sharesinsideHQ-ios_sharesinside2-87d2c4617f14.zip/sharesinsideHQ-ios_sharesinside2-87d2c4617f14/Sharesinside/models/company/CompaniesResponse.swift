//
//  CompaniesResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 25.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct CompaniesResponse: Decodable {
    var data: [Company]
    var meta: ListMetadata
}
