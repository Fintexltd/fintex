//
//  CompanyCharts.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum CompanyCharts {
    
    enum Scope: Int {
        case week = 7
        case month = 30
        case year = 365
        
        var title: String {
            switch self {
            case .week:
                return Localizable.companyChartsScopeWeek.localized
            case .month:
                return Localizable.companyChartsScopeMonth.localized
            case .year:
                return Localizable.companyChartsScopeYear.localized
            }
        }
    }
    
    struct CompanyChartsData: Codable {
        let charts: [ChartData]

        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            var charts = try container.decode([ChartData].self)
            
            //ensure that defaultChart is always at the beggining of the chart list.
            if let defaultChart = charts.first(where: { $0.isDefault }), let index = charts.index(of: defaultChart) {
                _ = charts.remove(at: index)
                charts.insert(defaultChart, at: 0)
            }
            self.charts = charts
        }
    }
    
    struct ChartData: Codable, Hashable {
        
        let chartId: Int
        let symbol: String
        let text: String?
        let currency: String
        let currencySymbol: String?
        let isDefault: Bool
        var daysData: [StockDayData]
        
        var hashValue: Int {
            return chartId
        }
        
        init(from decoder: Decoder) throws {
            let mainContainer = try decoder.container(keyedBy: MainCodingKeys.self)
            let metadataContainer = try mainContainer.nestedContainer(keyedBy: MetadataCodingKeys.self, forKey: .metadata)
            
            self.chartId = try metadataContainer.decode(Int.self, forKey: .chartId)
            self.symbol = try metadataContainer.decode(String.self, forKey: .symbol)
            self.text = try  metadataContainer.decodeIfPresent(String.self, forKey: .text)
            self.currency = try metadataContainer.decode(String.self, forKey: .currency)
            self.currencySymbol = try metadataContainer.decodeIfPresent(String.self, forKey: .currencySybol)
            self.isDefault = try metadataContainer.decode(Bool.self, forKey: .isDefault)
            self.daysData = try mainContainer.decode([StockDayData].self, forKey: .data)
        }
        
        enum MainCodingKeys: String, CodingKey {
            case metadata = "symbol"
            case data = "data"
        }
        enum MetadataCodingKeys: String, CodingKey {
            case deysData = "data"
            case chartId = "id"
            case symbol
            case text
            case currency
            case currencySybol = "currency_symbol"
            case isDefault = "is_default"
        }
        
        private func with(_ daysData: [StockDayData]) -> ChartData {
            var newDataSet = self
            newDataSet.daysData = daysData
            return newDataSet
        }
        
        func prepared(for scope: Scope) -> ChartData {
            let daysData = Array(self.daysData.safeSuffix(scope.rawValue))
            return self.with(daysData)
        }
        
        static func == (lhs: CompanyCharts.ChartData, rhs: CompanyCharts.ChartData) -> Bool {
            return lhs.chartId == rhs.chartId
        }
    
    }
    
    struct StockDayData: Codable {
        private let dateString: String
        let open: Double?
        let high: Double?
        let low: Double?
        let close: Double?
        var date: Date {
            return Date.from(string: dateString, withFormat: .ohlcDateFormat)!
        }
        
        enum CodingKeys: String, CodingKey {
            case dateString = "date"
            case open
            case high
            case low
            case close
        }
        
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            self.dateString = try container.decode(String.self, forKey: .dateString)
            
            let closeString = try container.decodeIfPresent(String.self, forKey: .close)
            let highString = try container.decodeIfPresent(String.self, forKey: .high)
            let lowString = try container.decodeIfPresent(String.self, forKey: .low)
            let openString = try container.decodeIfPresent(String.self, forKey: .open)
            
            self.close = closeString != nil ? Double(closeString!) : nil
            self.high = highString != nil ? Double(highString!) : nil
            self.low = lowString != nil ? Double(lowString!) : nil
            self.open = openString != nil ? Double(openString!) : nil
        }
    }
}
