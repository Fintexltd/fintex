//
//  SocialMedia.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct SocialMedia: Decodable {
    let type: String
    let url: String?
}
