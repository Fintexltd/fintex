//
//  Adress.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import MapKit

protocol AddressConvertible {
    var type: AddressDataType { get }
    var text: String { get }
    var destinationUrl: URL? { get }
    
}

protocol GPSConvertible {
    var gpsCoordinates: CLLocationCoordinate2D? { get }
    var locationName: String? { get }
    var latitude: Float? { get set }
    var longitude: Float? { get set }
}

enum AddressDataType {
    case location
    case phone
    case email
    case website
    case attachment
    case termsAndConditions
}

struct Address: AddressConvertible, GPSConvertible {
    
    let type: AddressDataType
    let text: String
    var destinationUrl: URL?
    var latitude: Float?
    var longitude: Float?

    init(text: String, type: AddressDataType, url: URL? = nil, latitude: Float? = nil, longitude: Float? = nil) {
        self.type = type
        self.text = text
        self.latitude = latitude
        self.longitude = longitude
        self.destinationUrl = url ?? makeURL(fromText: text, type: type)
    }
    
    private func makeURL(fromText: String, type: AddressDataType) -> URL? {
        guard let prefix = prepareURLPrefix(for: text, type: type) else { return nil }
        return URL(string: prefix + text)
    }
    
    private func prepareURLPrefix(for text: String, type: AddressDataType) -> String? {
        switch type {
        case .phone: return "tel://"
        case .email: return "mailto:/"
        case .website, .attachment:
            if text.contains("http://") || text.contains("https://") { return "" }
            return "https://"
        default: return nil
        }
    }
    
    var gpsCoordinates: CLLocationCoordinate2D? {
        guard let lat = self.latitude, let long = self.longitude else { return nil }
        return CLLocationCoordinate2D(latitude: Double(lat), longitude: Double(long))
    }
    
    var locationName: String? {
        return text
    }
}
