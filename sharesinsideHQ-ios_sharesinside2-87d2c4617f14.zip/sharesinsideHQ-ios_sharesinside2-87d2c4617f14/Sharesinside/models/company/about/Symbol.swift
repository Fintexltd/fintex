//
//  Symbol.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Symbol: Decodable {
    let id: Int
    let symbol: String 
    let exchange: String?
    let text: String?
    let currency: String?
    let ohlc: OHLC?
    
    var isValid: Bool {
        return ohlc != nil
    }    
}
