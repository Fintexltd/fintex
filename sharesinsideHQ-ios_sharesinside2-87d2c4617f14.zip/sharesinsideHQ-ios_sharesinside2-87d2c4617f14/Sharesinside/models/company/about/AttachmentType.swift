//
//  Enclosure.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

protocol AttachmentConvertible {
    func toAttachment() -> AttachmentType
}

struct AttachmentType {
    
    var id: Int?
    let url: String
    let name: String
    let iconType: String
}
