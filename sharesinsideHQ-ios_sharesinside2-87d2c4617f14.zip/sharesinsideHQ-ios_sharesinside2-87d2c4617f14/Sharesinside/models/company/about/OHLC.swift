//
//  OHCL.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

///Open High Low Close - Stock parameter
struct OHLC: Decodable {
    let low: String
    let high: String
    let open: String
    let close: String
    let date: String
    
    enum CodingKeys: String, CodingKey {
        case low
        case high
        case open
        case close
        case date
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.low = try container.decodeIfPresent(String.self, forKey: .low) ?? OHLC.emptyValuePlaceholder
        self.high = try container.decodeIfPresent(String.self, forKey: .high) ?? OHLC.emptyValuePlaceholder
        self.open = try container.decodeIfPresent(String.self, forKey: .open) ?? OHLC.emptyValuePlaceholder
        self.close = try container.decodeIfPresent(String.self, forKey: .close) ?? OHLC.emptyValuePlaceholder
        self.date = try container.decodeIfPresent(String.self, forKey: .date) ?? OHLC.emptyValuePlaceholder
    }
    
    var isValid: Bool {
        return close != OHLC.emptyValuePlaceholder ||
            low != OHLC.emptyValuePlaceholder ||
            high != OHLC.emptyValuePlaceholder
    }
    
    private static let emptyValuePlaceholder = "-"
}
