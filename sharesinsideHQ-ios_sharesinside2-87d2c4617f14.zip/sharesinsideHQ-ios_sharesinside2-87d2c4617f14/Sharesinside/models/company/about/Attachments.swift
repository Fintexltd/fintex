//
//  Attachments.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Attachments: Decodable, Hashable {
    
    let id: Int
    let oryginalName: String
    let url: String
    let mimeType: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case oryginalName = "oryginal_name"
        case url
        case mimeType = "mime_type"
    }
}

extension Attachments: AttachmentConvertible {
    func toAttachment() -> AttachmentType {
        return AttachmentType(id: id, url: url, name: oryginalName, iconType: mimeType)
    }
    
    func toPhoto() -> Photo {
        return Photo(id: id, description: "", urlPath: url, mimeType: mimeType, type: "type_image",
                     parsedDescription: NSAttributedString(string: ""))
    }
}

extension Attachments: AddressConvertible {
    
    var type: AddressDataType {
        return .attachment
    }
    
    var text: String {
        return oryginalName
    }
    
    var destinationUrl: URL? {
        return URL(string: url)
    }
    
}
