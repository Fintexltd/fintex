//
//  Employee.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum EmployeeDetailsType {
    case position
    case description
    
    var localizedTitle: String {
        switch self {
        case .position: return Localizable.employeeDetailsPositionTitle.localized
        case .description: return Localizable.employeeDetailsDescriptionTitle.localized
        }
    }
    
}
typealias EmployeeDetailsData = (type: EmployeeDetailsType, attributtedText: NSAttributedString)

struct Employee: Decodable {
    
    let name: String
    let photoUrl: String?
    let position: String?
    let description: String?
    let email: String?
    let phoneNumber: String?
    let attachment: Attachments?
    
    enum CodingKeys: String, CodingKey {
        case name
        case photoUrl = "photo_url"
        case position
        case description
        case email
        case phoneNumber = "phone_number"
        case attachment
    }
    
    var additionalInformation: [AddressConvertible] {
        var data: [AddressConvertible] = []
        if let email = email {
            data.append(Address(text: email, type: .email))
        }
        if let phone = phoneNumber {
            data.append(Address(text: phone, type: .phone))
        }
        if let attachment = attachment {
            data.append(attachment)
        }
        return data
    }
    
    var details: [EmployeeDetailsData] {
        var data: [EmployeeDetailsData] = []
        if let position = position?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.small) {
            data.append((type: .position, attributtedText: position))
        }
        if let description = description?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.small) {
            data.append((type: .description, attributtedText: description))
        }
        return data
    }
}
