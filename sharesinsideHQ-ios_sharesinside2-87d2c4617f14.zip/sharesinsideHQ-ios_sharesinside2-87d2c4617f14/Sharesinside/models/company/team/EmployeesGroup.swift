//
//  EmployeesGroup.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct EmployeesGroup: Decodable {
    let name: String
    let id: Int
    var data: [Employee]
}
