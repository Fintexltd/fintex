//
//  Album.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Album: Codable {
    let id: Int
    let name: String?
    let type: AlbumType
    let items: [Photo]
    private let updatedAt: Double
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case type
        case items
        case updatedAt = "updated_at"
    }
    
    var updatedDate: Date {
        return Date(timeIntervalSince1970: updatedAt)
    }
}

enum AlbumType: String, Codable {
    case album = "company_gallery_album_section"
    case allItems = "company_gallery_items_section"
}
