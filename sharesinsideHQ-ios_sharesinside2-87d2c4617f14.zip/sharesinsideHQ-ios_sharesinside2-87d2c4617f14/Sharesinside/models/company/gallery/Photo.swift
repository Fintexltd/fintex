//
//  Photo.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Photo: Codable {
    
    let id: Int
    let description: String?
    let urlPath: String
    let mimeType: String
    let type: String
    
    var url: URL? {
        return URL.forQuery(using: urlPath)
    }
    
    var parsedDescription: NSAttributedString?
    
    enum CodingKeys: String, CodingKey {
        case id
        case description
        case urlPath = "url"
        case mimeType = "mime_type"
        case type
    }
    
    func with(parsedDescription: NSAttributedString?) -> Photo {
        return Photo(id: id,
                     description: description,
                     urlPath: urlPath,
                     mimeType: mimeType,
                     type: type,
                     parsedDescription: parsedDescription)
    }
}
