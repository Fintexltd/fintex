//
//  HistoricalDataSection.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct HistoricalDataSection: Decodable {

    var id: Int
    var name: String
    var data: [HistoricalData]
    
    enum CodingKeys: String, CodingKey {
        case id = "section_id"
        case name
        case data
    }
}
