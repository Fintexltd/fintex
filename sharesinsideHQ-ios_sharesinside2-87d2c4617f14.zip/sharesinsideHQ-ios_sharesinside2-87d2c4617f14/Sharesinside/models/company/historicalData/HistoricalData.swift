//
//  HistoricalDataProtocol.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct HistoricalData: Decodable {
    let id: Int
    let title: String
    let fiscalYear: String?
    let timestamp: Int
    let file: File
    
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case fiscalYear = "fiscal_year"
        case timestamp
        case file
    }
}
