//
//  File.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct File: Decodable {
    let id: Int
    let originalName: String
    let url: String
    let mimeType: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case originalName = "oryginal_name"
        case url
        case mimeType = "mime_type"
    }
}
