//
//  Company.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit

enum FollowingState: String, Decodable {
    case notFollowing
    case changing
    case following

    var stateTitle: String {
        switch self {
        case .notFollowing: return Localizable.companyFollow.localized.uppercased()
        case .changing: return ""
        case .following: return Localizable.companyUnfollow.localized.uppercased()
        }
    }

    var buttonStyle: SharesinsideButton.ButtonStyle {
        switch self {
        case .notFollowing, .changing: return SharesinsideButton.Style.primary
        case .following: return SharesinsideButton.Style.transparentWithBorderPrimary
        }
    }
}

struct Company: Decodable, Hashable {

    let id: Int
    let logo: String?
    let name: String?
    let address: String?
    let industry: String?
    var mainStockPrice: String?
    var userGroups: [UserGroup]?
    var following: FollowingState
    
    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case industry
        case address = "adress"
        case mainStockPrice = "av_main_stock_price"
        case userGroups = "user_group"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        industry = try container.decodeIfPresent(String.self, forKey: .industry)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        let mainStockPrice = try container.decodeIfPresent(String.self, forKey: .mainStockPrice)
        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = FollowingState.state(by: userGroups)
        self.mainStockPrice = mainStockPrice?.replacingOccurrences(of: " ", with: "") == "" || mainStockPrice == nil ? Localizable.notAvailable.localized : mainStockPrice
    }
    
    init(id: Int, logo: String?, name: String?, address: String?, industry: String?, mainStockPrice: String?, userGroups: [UserGroup]?, following: FollowingState) {
        self.id = id
        self.logo = logo
        self.name = name
        self.address = address
        self.industry = industry
        self.mainStockPrice = mainStockPrice
        self.userGroups = userGroups
        self.following = following
    }

    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            (logo ?? "").hashValue,
            (name ?? "").hashValue,
            (address ?? "").hashValue,
            (mainStockPrice ?? "").hashValue,
            following.rawValue.hashValue
            ])
    }
    
    enum CompanyDetailsType: String, Codable, CodingKey {
        case aboutUs = "about_us"
        case ourTeam = "our_team"
        case news = "news"
        case events = "events"
        case historicalData = "historical_data"
        case gallery = "gallery"
        case charts = "av_charts"
    
        var hashValue: Int {
            switch self {
            case .aboutUs: return 0
            case .ourTeam: return 1
            case .news: return 2
            case .events: return 3
            case .gallery: return 4
            case .historicalData: return 5
            case .charts: return 6
            }
        }
    }
}

extension Company {
    func with(followingState state: FollowingState) -> Company {
        var userGroups = self.userGroups
        switch state {
        case .following: userGroups?.append(.follower)
        case .notFollowing: userGroups?.removeAll(where: { $0 == .follower })
        default: break }
        
        return Company(id: id,
            logo: logo,
            name: name,
            address: address,
            industry: industry,
            mainStockPrice: mainStockPrice,
            userGroups: userGroups,
            following: state
        )
    }
    
    var companiesCellGroups: [UserGroup] {
        return userGroups?.compactMap({
            ($0 == .shareholder || $0 == .vip || $0 == .follower) ? $0 : nil
        }) ?? []
    }
}

extension FollowingState {
    static func state(by userGroups: [UserGroup]?) -> FollowingState {
        guard let groups = userGroups, groups.contains(where: { $0 == UserGroup.follower }) else {
            return .notFollowing
        }
        return .following
    }
}
