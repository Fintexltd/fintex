//
//  Event.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Event: Publication, Decodable, Hashable {
    
    let watchlistId: Int
    let watchlistableId: Int
    let type: PublicationType
    internal let publishedAt: Double?
    var issuerId: Int

    var issuerName: String

    var issuerTypeString: String

    var issuerType: PublicationIssuerType? {
        PublicationIssuerType.from(string: issuerTypeString)
    }
    internal let logo: String?
    let title: String?
    let description: String?
    var userGroups: [UserGroup]

    let details: EventDetails

    enum CodingKeys: String, CodingKey {
        case watchlistId = "watchlist_id"
        case watchlistableId = "watchlistable_id"
        case type
        case publishedAt = "publish_at"
        case issuerId = "entitiable_id"
        case issuerName = "entitiable_name"
        case issuerTypeString = "entitiable_type"
        case logo = "logo_url"
        case title
        case description
        case details
        case userGroups = "user_group"
    }
    
    var hashValue: Int {
        return combineHashes([
            watchlistId.hashValue,
            watchlistableId.hashValue,
            (publishedAt ?? 0).hashValue,
            issuerId.hashValue,
            issuerName.hashValue,
            issuerTypeString.hashValue,
            (logo ?? "").hashValue,
            (title ?? "").hashValue,
            (description ?? "").hashValue
        ])
    }
    
    static func == (lhs: Event, rhs: Event) -> Bool {
        return lhs.watchlistId == rhs.watchlistId
    }
}
