//
//  NewsDetails.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct NewsDetails: Decodable {
    
    let isAdHoc: Bool
    let hasFiles: Bool
    let hasVideos: Bool
    let hasImages: Bool
    let hasLinks: Bool
    let hasVideoLinks: Bool
    private let videoUrlPath: String?
    private let videoThumbnailPath: String?
    
    var videoUrl: URL? {
        return URL.forQuery(using: videoUrlPath)
    }
    
    var videoThumbnailUrl: URL? {
        return URL.forQuery(using: videoThumbnailPath)
    }

    var videoData: VideoData? {
        guard let videoUrl = videoUrl, let videoThumbnailUrl = videoThumbnailUrl else {
            return nil
        }
        return VideoData(videoUrl: videoUrl, videoThumbnailUrl: videoThumbnailUrl)
    }
    
    enum CodingKeys: String, CodingKey {
        case isAdHoc = "is_ad_hoc"
        case hasFiles = "has_files"
        case hasVideos = "has_videos"
        case hasImages = "has_images"
        case hasLinks = "has_links"
        case hasVideoLinks = "has_video_links"
        case videoUrlPath = "video_url"
        case videoThumbnailPath = "video_img"
    }
}
