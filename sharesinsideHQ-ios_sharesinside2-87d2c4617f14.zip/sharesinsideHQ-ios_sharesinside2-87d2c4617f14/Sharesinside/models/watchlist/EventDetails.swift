//
//  EventDetails.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct EventDetails: Decodable {
    
    let eventDateString: String
    let timestamp: Double
    let timezone: String
    let address: String
    let longitude: Double
    let latitude: Double
    let countryCode: String
    let hasWebcastLinks: Bool
    let city: String?
    
    var eventDate: Date? {
        switch UserDefaultsEventsDisplayDateTypeRepository.shared.displayDateType {
        case .local:
            return utcDate.toTimezone()
        case .event:
            return utcDate.toTimezone(timezone: TimeZone(identifier: timezone))
        case .none:
            return nil
        }
    }

    var utcDate: Date {
        Date(timeIntervalSince1970: timestamp)
    }
    
    var prettyPrintedAddress: String {
        guard let city = city else { return address }
        guard !city.isEmpty, !address.isEmpty else {
            return address.isEmpty ? city : address
        }
        return "\(address), \(city)"
    }
    
    enum CodingKeys: String, CodingKey {
        case eventDateString = "event_date"
        case address = "adress"
        case city
        case longitude
        case latitude
        case countryCode = "country_code"
        case hasWebcastLinks = "has_webcast_links"
        case timestamp = "event_timestamp"
        case timezone = "timezone_id"
    }
}
