//
//  Publication.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum PublicationType: String, Decodable {
    case news
    case event
    case project
    
    var title: String {
        switch self {
        case .news: return Localizable.watchlistNews.localized.uppercased()
        case .event: return Localizable.watchlistEvent.localized.uppercased()
        case .project: return Localizable.watchlistProject.localized.uppercased()
        }
    }
}

enum PublicationIssuerType: String, Decodable {
    case company
    case fund
    case fundsManager
    case startup

    enum CodingKeys: String, CodingKey {
        case company
        case fund
        case fundsManager = "funds_manager"
        case startup
    }

    static func from(string: String) -> PublicationIssuerType? {
        switch string {
        case "company":
            return .company
        case "fund":
            return .fund
        case "funds_manager":
            return .fundsManager
        case "startup":
            return .startup
        default:
            return nil
        }
    }
}

protocol Publication {
    
    var watchlistId: Int { get }
    var watchlistableId: Int { get }
    var type: PublicationType { get }
    var publishedAt: Double? { get }
    var issuerId: Int { get }
    var issuerType: PublicationIssuerType? { get }
    var issuerName: String { get }
    var logo: String? { get }
    var title: String? { get }
    var description: String? { get }
    
    var logoUrl: URL? { get }
    var publishDate: Date? { get }
    var hashValue: Int { get }
    var userGroups: [UserGroup] { get }
}

extension Publication {
    
    var publishDate: Date? {
        guard let publishedAt = publishedAt else { return nil }
        return Date(timeIntervalSince1970: publishedAt)
    }
    
    var logoUrl: URL? {
        return URL(string: logo?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed))
    }
    
    var prettyPrintedDescription: NSAttributedString? {
        return description?.attributedFromHtml?.with(breakMode: .byTruncatingTail).withSystemFont(ofSize: Defaults.TextSize.medium)
    }
}
