//
//  ShareablePublication.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

protocol ShareablePublication {
    var shareUrl: URL? { get }
}
