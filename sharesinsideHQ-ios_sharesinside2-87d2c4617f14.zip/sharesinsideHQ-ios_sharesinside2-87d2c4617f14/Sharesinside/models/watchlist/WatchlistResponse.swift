//
//  WatchlistResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct WatchlistResponse: Decodable {
    var data: [WatchlistItem]
    var meta: ListMetadata
}

enum WatchlistItem {
    case news(News)
    case event(Event)
    case project(Project)
}

extension WatchlistItem: Decodable {
    init(from decoder: Decoder) throws {
        if let news = try? News(from: decoder) {
            self = .news(news)
            return
        } else if let event = try? Event(from: decoder) {
            self = .event(event)
            return
        }
        let project = try Project(from: decoder)
        self = .project(project)
    }
}

enum WatchlistItemError: Error {
    case invalid
}
