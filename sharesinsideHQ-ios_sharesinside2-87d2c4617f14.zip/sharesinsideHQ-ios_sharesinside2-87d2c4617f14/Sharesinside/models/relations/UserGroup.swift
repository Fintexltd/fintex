//
//  UserGroup.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum UserGroup: String, Decodable, CaseIterable {
    case vip = "vip"
    case shareholder = "shareholder"
    case investor = "investor"
    case blocked = "blocked"
    case follower = "follower"
    case primaryAdmin = "primary_admin"
    case secondaryAdmin = "secondary_admin"
    case editor = "editor"
    case domesticAdmin = "domestic_admin"
    case globalAdmin = "global_admin"
    case shareholderToConfirm = "shareholder_to_confirm"
    case shareholderPending = "shareholder_pending"
    
    var title: String {
        return self.rawValue.replacingOccurrences(of: "_", with: " ").uppercased()
    }
}
