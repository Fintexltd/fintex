//
//  Relation.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Relation: Decodable, Hashable {
    
    let relatedType: RelationType
    let id: Int
    let relatedId: Int
    let logo: String?
    let name: String
    private let mainStockPrice: String?
    let industry: String?
    let userGroup: UserGroup
    
    var mainStockPriceValue: String {
        guard let mainStock = mainStockPrice?.trimmingCharacters(in: .whitespacesAndNewlines), !mainStock.isEmpty else {
            return Localizable.notAvailable.localized
        }
        
        return mainStock
    }

    enum CodingKeys: String, CodingKey {
        case id
        case relatedId = "related_id"
        case logo
        case name
        case industry
        case relatedType = "related_type"
        case mainStockPrice = "main_stock_price"
        case userGroup = "user_group"
    }
    
    enum RelationType: String, Decodable {
        case company
        case country
    }
    
    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            (logo ?? "").hashValue,
            name.hashValue,
            relatedType.rawValue.hashValue,
            (mainStockPrice ?? "").hashValue,
            (industry ?? "").hashValue,
            userGroup.hashValue
            ])
    }
}
