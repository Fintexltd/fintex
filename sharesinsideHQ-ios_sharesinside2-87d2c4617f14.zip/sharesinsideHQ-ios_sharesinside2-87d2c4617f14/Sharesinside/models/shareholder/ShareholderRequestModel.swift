//
//  ShareholderRequest.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct ShareholderRequestModel: Encodable {
    
    let companyId: Int
    let firstName: String
    let lastName: String
    let phoneNumber: String
    let birthDate: String
    let address: String
    let postalCode: String
    let city: String
    let countryId: Int
    
    enum CodingKeys: String, CodingKey {
        case companyId = "company_id"
        case firstName = "first_name"
        case lastName = "last_name"
        case phoneNumber = "phone_number"
        case birthDate = "birth_date"
        case address
        case postalCode = "post_code"
        case city
        case countryId = "country_id"
    }
}
