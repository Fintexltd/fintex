//
//  Relation.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum RelationType: String {
    case follower
    case vip
}
