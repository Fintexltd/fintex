//
//  MessageResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 15.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct MessageResponse: Decodable {
    let message: String
}
