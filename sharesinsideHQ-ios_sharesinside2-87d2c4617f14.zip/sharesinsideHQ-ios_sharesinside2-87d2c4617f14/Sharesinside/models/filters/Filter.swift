//
//  Filter.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 15.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

enum SectionType {
    case filter, range
}

enum FilterType {
    case companyRelation
    case watchlistRelation
    case fundManagerRelation
    case startupRelation
    case industry
    case startupCategory
    case sector
    case country
    case continent
    case currency
    case assetClass
    case fundType
    case publicity
    case mostViewed
    case adhoc
    case attachment
    case location
    case today
    case tomorrow
    case activePassive
    case openClose
    case relationsRelation
    case managementFee
    case performanceFee
    case duration
    case tradingFrequency
    case raisedAmount
    case equityFund

    var title: String {
        switch self {
        case .companyRelation, .watchlistRelation, .fundManagerRelation, .startupRelation: return Localizable.filtersRelations.localized.uppercased()
        case .managementFee: return Localizable.filtersManagementFee.localized.uppercased()
        case .performanceFee: return Localizable.filtersPerformanceFee.localized.uppercased()
        case .duration: return Localizable.filtersDuration.localized.uppercased()
        case .industry: return Localizable.filtersIndustry.localized.uppercased()
        case .sector: return Localizable.filtersSector.localized.uppercased()
        case .startupCategory: return Localizable.filtersStartupCategories.localized.uppercased()
        case .raisedAmount: return Localizable.filtersRaisedAmount.localized.uppercased()
        case .country: return Localizable.filtersCountry.localized.uppercased()
        case .continent: return Localizable.filtersContinent.localized.uppercased()
        case .currency: return Localizable.filtersCurrency.localized.uppercased()
        case .assetClass: return Localizable.filtersAssetClass.localized.uppercased()
        case .fundType: return Localizable.filtersFundType.localized.uppercased()
        case .publicity: return Localizable.filtersPublicity.localized.uppercased()
        case .activePassive: return Localizable.filtersActivePassive.localized.uppercased()
        case .openClose: return Localizable.filtersOpenClose.localized.uppercased()
        case .attachment: return Localizable.filtersAttachment.localized.uppercased()
        case .tradingFrequency: return Localizable.filtersTradingFrequency.localized.uppercased()
        case .equityFund: return Localizable.filtersEquityFund.localized.uppercased()
        default: return ""
        }
    }

    var sectionType: SectionType {
        switch self {
        case .managementFee, .performanceFee, .duration, .raisedAmount:
            return .range
        default:
            return .filter
        }
    }
}

protocol Filter {

    var type: FilterType { get }
    var id: Int { get }
    var name: String { get }
    var isSelected: Bool { get }

    func resetted() -> Filter

    func with(selection: Bool) -> Filter
}

extension Filter {
    func resetted() -> Filter {
        with(selection: false)
    }
}

protocol RangeFilter: Filter {
    var value: Double? { get }
    func with(value: Double?) -> Filter
    var rangeType: RangeType { get }
    var inputType: InputType { get }
}

enum InputType {
    case decimal, integer

    var keyboardType: UIKeyboardType {
        switch self {
        case .decimal:
            return .decimalPad
        case .integer:
            return .numberPad
        }
    }
}

extension RangeFilter {
    func with(selection: Bool) -> Filter { return self }

    var isSelected: Bool {
        false
    }

    var name: String {
        rangeType.name.capitalized
    }

    func resetted() -> Filter {
        with(value: nil)
    }
}
