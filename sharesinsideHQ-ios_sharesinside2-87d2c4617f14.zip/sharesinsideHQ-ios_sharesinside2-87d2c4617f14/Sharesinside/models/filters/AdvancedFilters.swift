//
//  CompaniesFilter.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum SortType: Encodable, Equatable {

    case defaultSorted
    case defaultSortedSeed(seed: Int)
    case mostViewed

    var apiParameter: String {
        switch self {
        case .defaultSorted, .defaultSortedSeed: return "default"
        case .mostViewed: return "most_viewed"
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encode(apiParameter)
    }
}

struct AdvancedFilters {

    let sortBy: SortType
    let search: String
    let relations: [String]
    let sectorIds: [Int]
    let countryIds: [Int]
    let currencyIds: [Int]
    let assetClassIds: [Int]
    let fundTypeIds: [String]
    let industryIds: [Int]
    let startupCategoryIds: [Int]
    let continentIds: [Int]
    let attachments: [String]
    let publicities: [String]
    let managementFeeFrom: Double?
    let managementFeeTo: Double?
    let performanceFeeFrom: Double?
    let performanceFeeTo: Double?
    let raisedAmountFrom: Double?
    let raisedAmountTo: Double?
    let durationFrom: Int?
    let durationTo: Int?
    let adHoc: Bool
    let active: Bool
    let passive: Bool
    let equity: Bool
    let fund: Bool
    let openClose: [String]
    let tradingFrequency: [TradingFrequency]
    let startDate: String
    let endDate: String
    let eventsForToday: Bool
    let eventsForTomorrow: Bool
    let location: String
    let requestStatus: [String]
    let userGroups: [UserGroup]
    
    func with(sortType: SortType? = nil, searchText: String? = nil, relations: [String]? = nil,
              sectorIds: [Int]? = nil, countryIds: [Int]? = nil, currencyIds: [Int]? = nil, assetClassIds: [Int]? = nil, fundTypeIds: [String]? = nil, industryIds: [Int]? = nil, startupCategoryIds: [Int]? = nil,
              continentIds: [Int]? = nil, attachments: [String]? = nil, publicities: [String]? = nil,
              adHoc: Bool? = nil, active: Bool? = nil, passive: Bool? = nil, equity: Bool? = nil, fund: Bool? = nil, openClose: [String]? = nil, tradingFrequency: [TradingFrequency]? = nil, startDate: String? = nil, endDate: String? = nil,
              eventsForToday: Bool? = nil, eventsForTomorrow: Bool? = nil, location: String? = nil,
              requestStatus: [String]? = nil, userGroups: [UserGroup]? = nil) -> AdvancedFilters {
        
        return AdvancedFilters(sortBy: sortType ?? self.sortBy,
                        search: searchText ?? self.search,
                        relations: relations ?? self.relations,
                        sectorIds: sectorIds ?? self.sectorIds,
                        countryIds: countryIds ?? self.countryIds,
                        currencyIds: currencyIds ?? self.currencyIds,
                        assetClassIds: assetClassIds ?? self.assetClassIds,
                        fundTypeIds: fundTypeIds ?? self.fundTypeIds,
                        industryIds: industryIds ?? self.industryIds,
                        startupCategoryIds: startupCategoryIds ?? self.startupCategoryIds,
                        continentIds: continentIds ?? self.continentIds,
                        attachments: attachments ?? self.attachments,
                        publicities: publicities ?? self.publicities,
                        managementFeeFrom: managementFeeFrom,
                        managementFeeTo: managementFeeTo,
                        performanceFeeFrom: performanceFeeFrom,
                        performanceFeeTo: performanceFeeTo,
                        raisedAmountFrom: raisedAmountFrom,
                        raisedAmountTo: raisedAmountTo,
                        durationFrom: durationFrom,
                        durationTo: durationTo,
                        adHoc: adHoc ?? self.adHoc,
                        active: active ?? self.active,
                        passive: passive ?? self.passive,
                        equity: equity ?? self.equity,
                        fund: fund ?? self.fund,
                        openClose: openClose ?? self.openClose,
                        tradingFrequency: tradingFrequency ?? self.tradingFrequency,
                        startDate: startDate ?? self.startDate,
                        endDate: endDate ?? self.endDate,
                        eventsForToday: eventsForToday ?? self.eventsForToday,
                        eventsForTomorrow: eventsForTomorrow ?? self.eventsForTomorrow,
                        location: location ?? self.location,
                        requestStatus: requestStatus ?? self.requestStatus,
                        userGroups: userGroups ?? self.userGroups)
    }

    func with(
        managementFeeFrom: Double? = nil,
        managementFeeTo: Double? = nil,
        performanceFeeFrom: Double? = nil,
        performanceFeeTo: Double? = nil,
        durationFrom: Int? = nil,
        durationTo: Int? = nil,
        raisedAmountFrom: Double? = nil,
        raisedAmountTo: Double? = nil
    ) -> AdvancedFilters {
        AdvancedFilters(sortBy: sortBy,
                        search: search,
                        relations: relations,
                        sectorIds: sectorIds,
                        countryIds: countryIds,
                        currencyIds: currencyIds,
                        assetClassIds: assetClassIds,
                        fundTypeIds: fundTypeIds,
                        industryIds: industryIds,
                        startupCategoryIds: startupCategoryIds,
                        continentIds: continentIds,
                        attachments: attachments,
                        publicities: publicities,
                        managementFeeFrom: managementFeeFrom,
                        managementFeeTo: managementFeeTo,
                        performanceFeeFrom: performanceFeeFrom,
                        performanceFeeTo: performanceFeeTo,
                        raisedAmountFrom: raisedAmountFrom,
                        raisedAmountTo: raisedAmountTo,
                        durationFrom: durationFrom,
                        durationTo: durationTo,
                        adHoc: adHoc,
                        active: active,
                        passive: passive,
                        equity: equity,
                        fund: fund,
                        openClose: openClose,
                        tradingFrequency: tradingFrequency,
                        startDate: startDate,
                        endDate: endDate,
                        eventsForToday: eventsForToday,
                        eventsForTomorrow: eventsForTomorrow,
                        location: location,
                        requestStatus: requestStatus,
                        userGroups: userGroups)
    }

    var selectionCount: Int {
        return [sectorIds, continentIds, industryIds, startupCategoryIds, currencyIds, assetClassIds, fundTypeIds, relations, countryIds, attachments, publicities, userGroups, tradingFrequency, openClose].reduce(0) { $0 + (($1 as? [Any])?.count ?? 0) }
            + sortCount
            + (adHoc ? 1 : 0)
            + (eventsForToday ? 1 : 0)
            + (eventsForTomorrow ? 1 : 0)
            + (location.isEmpty ? 0 : 1)
            + (active ? 1 : 0)
            + (passive ? 1 : 0)
            + (equity ? 1 : 0)
            + (fund ? 1 : 0)
            + (managementFeeFrom != nil ? 1 : 0)
            + (managementFeeTo != nil ? 1 : 0)
            + (performanceFeeFrom != nil ? 1 : 0)
            + (performanceFeeTo != nil ? 1 : 0)
            + (raisedAmountFrom != nil ? 1 : 0)
            + (raisedAmountTo != nil ? 1 : 0)
            + (durationFrom != nil ? 1 : 0)
            + (durationTo != nil ? 1 : 0)
    }

    private var sortCount: Int {
        switch sortBy {
        case .defaultSortedSeed, .defaultSorted: return 0
        default: return 1
        }
    }
    
    func getDateFrom() -> Date {
        return Date.from(string: fromDateString(), withFormat: .ohlcDateFormat) ?? Date()
    }
    
    func getDateTo() -> Date {
        return Date.from(string: toDateString(), withFormat: .ohlcDateFormat) ?? Date()
    }
}

extension AdvancedFilters: Encodable {

    enum CodingKeys: String, CodingKey {
        case sortBy = "sort_by"
        case seed
        case search
        case relations
        case active
        case passive
        case equity
        case fund
        case openClose = "open_close"
        case sectorIds = "sector"
        case countryIds = "country"
        case industryIds = "industry"
        case startupCategoryIds = "startup_category"
        case continentIds = "continent"
        case currencyIds = "currency"
        case assetClassIds = "fund_type"
        case fundTypeIds = "kind_of_fund"
        case attachments = "attachments"
        case publicities = "publicity"
        case adHoc = "ad_hoc"
        case eventFrom = "event_from"
        case eventTo = "event_to"
        case managementFeeFrom = "management_fee_from"
        case managementFeeTo = "management_fee_to"
        case performanceFeeFrom = "performance_fee_from"
        case performanceFeeTo = "performance_fee_to"
        case raisedAmountFrom = "raised_amount_from"
        case raisedAmountTo = "raised_amount_to"
        case durationFrom = "duration_from"
        case durationTo = "duration_to"
        case location
        case requestStatus = "status"
        case tradingFrequency = "trading_frequency"
    }
    // swiftlint:disable cyclomatic_complexity
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(sortBy, forKey: .sortBy)
        
        if !search.isEmpty { try container.encodeIfPresent(search, forKey: .search) }
        if !relations.isEmpty { try container.encodeIfPresent(relations, forKey: .relations) }
        if !sectorIds.isEmpty { try container.encodeIfPresent(sectorIds, forKey: .sectorIds) }
        if !countryIds.isEmpty { try container.encodeIfPresent(countryIds, forKey: .countryIds) }
        if !industryIds.isEmpty { try container.encodeIfPresent(industryIds, forKey: .industryIds) }
        if !startupCategoryIds.isEmpty { try container.encodeIfPresent(startupCategoryIds, forKey: .startupCategoryIds) }
        if !currencyIds.isEmpty { try container.encodeIfPresent(currencyIds, forKey: .currencyIds) }
        if !assetClassIds.isEmpty { try container.encodeIfPresent(assetClassIds, forKey: .assetClassIds) }
        if !fundTypeIds.isEmpty { try container.encodeIfPresent(fundTypeIds, forKey: .fundTypeIds) }
        if !continentIds.isEmpty { try container.encodeIfPresent(continentIds, forKey: .continentIds) }
        if !attachments.isEmpty { try container.encodeIfPresent(attachments, forKey: .attachments) }
        if !publicities.isEmpty { try container.encodeIfPresent(publicities, forKey: .publicities) }
        if !toDateString().isEmpty { try container.encodeIfPresent(toDateString(), forKey: .eventTo) }
        if !fromDateString().isEmpty { try container.encodeIfPresent(fromDateString(), forKey: .eventFrom) }
        if !location.isEmpty { try container.encodeIfPresent(location, forKey: .location) }
        if !requestStatus.isEmpty { try container.encodeIfPresent(requestStatus, forKey: .requestStatus) }
        if !userGroups.isEmpty { try container.encodeIfPresent(userGroups.map { $0.rawValue }, forKey: .relations) }
        if !tradingFrequency.isEmpty { try container.encodeIfPresent(tradingFrequency.map { $0.tradingFrequencyType.rawValue }, forKey: .tradingFrequency) }
        if adHoc { try container.encodeIfPresent(adHoc.hashValue, forKey: .adHoc) }
        if active { try container.encodeIfPresent(active ? 1 : 0, forKey: .active) }
        if passive { try container.encodeIfPresent(passive ? 1 : 0, forKey: .passive) }
        if equity { try container.encodeIfPresent(equity ? 1 : 0, forKey: .equity) }
        if fund { try container.encodeIfPresent(fund ? 1 : 0, forKey: .fund)}
        if !openClose.isEmpty { try container.encodeIfPresent(openClose, forKey: .openClose) }
        try container.encodeIfPresent(managementFeeFrom, forKey: .managementFeeFrom)
        try container.encodeIfPresent(managementFeeTo, forKey: .managementFeeTo)
        try container.encodeIfPresent(performanceFeeFrom, forKey: .performanceFeeFrom)
        try container.encodeIfPresent(performanceFeeTo, forKey: .performanceFeeTo)
        try container.encodeIfPresent(raisedAmountFrom, forKey: .raisedAmountFrom)
        try container.encodeIfPresent(raisedAmountTo, forKey: .raisedAmountTo)
        try container.encodeIfPresent(durationFrom, forKey: .durationFrom)
        try container.encodeIfPresent(durationTo, forKey: .durationTo)


        if case let .defaultSortedSeed(seed) = sortBy {
            try container.encodeIfPresent(seed, forKey: .seed)
        }
    }
    
    private func fromDateString() -> String {
        if eventsForToday {
            return Date().toString(withFromat: .ohlcDateFormat)
        }
        
        if eventsForTomorrow {
            let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: Date())
            return tomorrow?.toString(withFromat: .ohlcDateFormat) ?? ""
        }
        
        return startDate
    }
    
    private func toDateString() -> String {
        if eventsForTomorrow {
            let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: Date())
            return tomorrow?.toString(withFromat: .ohlcDateFormat) ?? ""
        }
        
        if eventsForToday {
            return Date().toString(withFromat: .ohlcDateFormat)
        }
        
        return endDate
    }
}

extension AdvancedFilters {

    func hasRelationFilter(_ filter: Filter) -> Bool {
        return relations.contains(filter.name.lowercased())
    }

    func hasSortFilter(_ filter: Filter) -> Bool {
        guard let sort = filter as? SortFilter else { return false }
        return sortBy == sort.sortType
    }
    
    func hasTodayFilterSelected(_ filter: Filter) -> Bool {
        return filter.type == .today && eventsForToday
    }
    
    func hasTomorrowFilterSelected(_ filter: Filter) -> Bool {
        return filter.type == .tomorrow && eventsForTomorrow
    }
    
    func hasLocation(_ filter: Filter) -> Bool {
        return filter.type == .location && !location.isEmpty
    }
    
    func hasUserGroupFilter(_ filter: Filter) -> Bool {
        return userGroups.contains(where: { $0.title == filter.name })
    }
    
    func areEmpty() -> Bool {
        return isSortDefault() &&
        search.isEmpty &&
        relations.isEmpty &&
        sectorIds.isEmpty &&
        countryIds.isEmpty &&
        industryIds.isEmpty &&
        startupCategoryIds.isEmpty &&
        currencyIds.isEmpty &&
        assetClassIds.isEmpty &&
        fundTypeIds.isEmpty &&
        continentIds.isEmpty &&
        attachments.isEmpty &&
        publicities.isEmpty &&
        tradingFrequency.isEmpty &&
        openClose.isEmpty &&
        managementFeeFrom == nil &&
        managementFeeTo == nil &&
        performanceFeeFrom == nil &&
        performanceFeeTo == nil &&
        raisedAmountTo == nil &&
        raisedAmountFrom == nil &&
        durationFrom == nil &&
        durationTo == nil &&
        !adHoc &&
        !eventsForToday &&
        !eventsForTomorrow &&
        !active &&
        !passive &&
        !equity &&
        !fund &&
        location.isEmpty &&
        userGroups.isEmpty
    }
    
    private func isSortDefault() -> Bool {
        switch sortBy {
        case .defaultSorted, .defaultSortedSeed: return true
        default: return false
        }
    }
    
    static func empty(withSortType sortType: SortType = .defaultSorted) -> AdvancedFilters {
        return AdvancedFilters(
            sortBy: sortType,
            search: "",
            relations: [],
            sectorIds: [],
            countryIds: [],
            currencyIds: [],
            assetClassIds: [],
            fundTypeIds: [],
            industryIds: [],
            startupCategoryIds: [],
            continentIds: [],
            attachments: [],
            publicities: [],
            managementFeeFrom: nil,
            managementFeeTo: nil,
            performanceFeeFrom: nil,
            performanceFeeTo: nil,
            raisedAmountFrom: nil,
            raisedAmountTo: nil,
            durationFrom: nil,
            durationTo: nil,
            adHoc: false,
            active: false,
            passive: false,
            equity: false,
            fund: false,
            openClose: [],
            tradingFrequency: [],
            startDate: "",
            endDate: "",
            eventsForToday: false,
            eventsForTomorrow: false,
            location: "",
            requestStatus: [],
            userGroups: [])
    }
}
