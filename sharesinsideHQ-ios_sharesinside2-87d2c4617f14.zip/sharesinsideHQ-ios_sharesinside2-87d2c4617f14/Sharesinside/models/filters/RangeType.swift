//
//  RangeType.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 18/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

enum RangeType {
    case from, to

    var name: String {
        switch self {
        case .from:
            return Localizable.filtersRangeFrom.localized
        case .to:
            return Localizable.filtersRangeTo.localized
        }
    }
}
