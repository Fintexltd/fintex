//
//  Relation.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct WatchlistRelation: Filter {
    
    let type: FilterType = .watchlistRelation
    
    let id: Int
    let name: String
    let isSelected: Bool
    
    func with(selection: Bool) -> Filter {
        return WatchlistRelation(id: id, name: name, isSelected: selection)
    }
}
