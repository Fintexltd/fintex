//
//  Attachment.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Attachment: Filter {
    
    let type: FilterType = .attachment
    
    let id: Int
    let name: String
    
    var isSelected: Bool = false
    
    func with(selection: Bool) -> Filter {
        return Attachment(id: id, name: name, isSelected: selection)
    }
}
