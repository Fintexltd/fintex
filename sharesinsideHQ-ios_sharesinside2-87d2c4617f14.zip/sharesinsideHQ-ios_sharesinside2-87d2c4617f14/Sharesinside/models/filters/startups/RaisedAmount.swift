//
//  RaisedAmount.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 09/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct RaisedAmount: RangeFilter {

    let type: FilterType = .raisedAmount

    let inputType: InputType = .decimal

    var id: Int = -1

    let rangeType: RangeType

    var value: Double?

    func with(value: Double?) -> Filter {
        RaisedAmount(id: id, rangeType: rangeType, value: value)
    }

}
