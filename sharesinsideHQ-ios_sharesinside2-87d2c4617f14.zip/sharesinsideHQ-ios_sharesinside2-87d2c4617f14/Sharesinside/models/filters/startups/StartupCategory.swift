//
//  StartupCategory.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 09/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct StartupCategory: Decodable, Filter {

    let type: FilterType = .startupCategory

    let id: Int
    let name: String

    var isSelected: Bool = false

    enum CodingKeys: String, CodingKey {
        case id
        case name
    }

    func with(selection: Bool) -> Filter {
        return Industry(id: id, name: name, isSelected: selection)
    }
}

