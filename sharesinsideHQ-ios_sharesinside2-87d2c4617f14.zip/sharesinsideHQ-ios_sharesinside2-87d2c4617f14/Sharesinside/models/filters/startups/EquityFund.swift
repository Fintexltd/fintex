//
//  EquityFund.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 09/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

enum EquityFundType {
    case equity, fund

    var name: String {
        switch self {
        case .equity:
            return Localizable.startupEquity.localized
        case .fund:
            return Localizable.startupFund.localized
        }
    }
}

struct EquityFund: Filter {

    let type: FilterType = .equityFund
    var name: String {
        equityFundType.name
    }

    var id: Int = -1

    var isSelected: Bool = false

    let equityFundType: EquityFundType

    func with(selection: Bool) -> Filter {
        EquityFund(id: id, isSelected: selection, equityFundType: equityFundType)
    }
}
