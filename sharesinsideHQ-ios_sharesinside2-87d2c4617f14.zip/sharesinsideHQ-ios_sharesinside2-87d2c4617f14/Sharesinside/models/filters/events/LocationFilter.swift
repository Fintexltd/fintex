//
//  AdHocFilter.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct LocationFilter: Filter {
    
    var type: FilterType = .location
    
    var id: Int
    
    var name: String
    
    var isSelected: Bool
    
    func with(selection: Bool) -> Filter {
        return LocationFilter(type: type, id: id, name: name, isSelected: selection)
    }
    
    func with(name: String) -> Filter {
        return LocationFilter(type: type, id: id, name: name, isSelected: isSelected)
    }
}
