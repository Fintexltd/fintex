//
//  TommorowEventsFilter.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 04/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct TomorrowEventsFilter: Filter {
    
    var type: FilterType = .tomorrow
    
    var id: Int
    
    var name: String
    
    var isSelected: Bool
    
    func with(selection: Bool) -> Filter {
        return TomorrowEventsFilter(type: type, id: id, name: name, isSelected: selection)
    }
}
