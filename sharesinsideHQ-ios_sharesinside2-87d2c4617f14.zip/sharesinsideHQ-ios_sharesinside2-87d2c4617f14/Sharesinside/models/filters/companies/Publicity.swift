//
//  Publicity.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Publicity: Filter {
    
    let type: FilterType = .publicity
    let id: Int
    let name: String
    let isSelected: Bool
    let apiParam: String
    
    func with(selection: Bool) -> Filter {
        return Publicity(id: id, name: name, isSelected: selection, apiParam: apiParam)
    }
}
