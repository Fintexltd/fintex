//
//  Country.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Country: Decodable, Filter {

    let type: FilterType = .country
    var name: String {
        return countryName
    }
    
    var id: Int = 0
    var countryName: String = ""
    var continentId: Int = 0
    
    var isSelected: Bool = false
    
    enum CodingKeys: String, CodingKey {
        case id
        case countryName = "country_name"
        case continentId = "continent_id"
    }
    
    func with(selection: Bool) -> Filter {
        return Country(id: id, countryName: countryName, continentId: continentId, isSelected: selection)
    }

}
