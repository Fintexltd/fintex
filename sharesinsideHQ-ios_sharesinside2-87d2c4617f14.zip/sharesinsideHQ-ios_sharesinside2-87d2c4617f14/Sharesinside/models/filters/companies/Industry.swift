//
//  Industry.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 15.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Industry: Decodable, Filter {
    
    let type: FilterType = .industry
    
    let id: Int
    let name: String
    
    var isSelected: Bool = false
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
    }
    
    func with(selection: Bool) -> Filter {
        return Industry(id: id, name: name, isSelected: selection)
    }
}
