//
//  Continent.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Continent: Decodable, Filter {
    
    let type: FilterType = .continent
    
    let id: Int
    let name: String
    var isSelected: Bool = false
    
    func with(selection: Bool) -> Filter {
        return Continent(id: id, name: name, isSelected: selection)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case name = "continent_name"
    }
}
