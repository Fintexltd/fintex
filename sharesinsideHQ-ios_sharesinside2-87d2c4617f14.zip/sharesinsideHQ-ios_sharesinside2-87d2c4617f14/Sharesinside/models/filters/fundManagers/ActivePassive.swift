//
//  ActivePassive.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 15/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

enum ActivePassiveType {
    case active, passive

    var name: String {
        switch self {
        case .active:
            return Localizable.fundManagerActive.localized
        case .passive:
            return Localizable.fundManagerPassive.localized
        }
    }
}

struct ActivePassive: Filter {

    let type: FilterType = .activePassive
    var name: String {
        activePassiveType.name
    }

    var id: Int = -1

    var isSelected: Bool = false

    let activePassiveType: ActivePassiveType

    func with(selection: Bool) -> Filter {
        ActivePassive(id: id, isSelected: selection, activePassiveType: activePassiveType)
    }
}
