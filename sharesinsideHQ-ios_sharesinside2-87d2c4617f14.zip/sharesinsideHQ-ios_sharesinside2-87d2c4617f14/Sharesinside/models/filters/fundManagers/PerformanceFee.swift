//
//  PerformanceFee.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct PerformanceFee: RangeFilter {

    let type: FilterType = .performanceFee

    let inputType: InputType = .decimal

    var id: Int = -1

    let rangeType: RangeType

    var value: Double?

    func with(value: Double?) -> Filter {
        PerformanceFee(id: id, rangeType: rangeType, value: value)
    }

}
