//
//  FundManagerRelation.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagerRelation: Filter {

    let type: FilterType = .fundManagerRelation

    let id: Int
    let name: String
    let isSelected: Bool

    func with(selection: Bool) -> Filter {
        return FundManagerRelation(id: id, name: name, isSelected: selection)
    }
}
