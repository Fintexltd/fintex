//
//  ManagementFee.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 18/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct ManagementFee: RangeFilter {

    let type: FilterType = .managementFee

    let inputType: InputType = .decimal

    var id: Int = -1

    let rangeType: RangeType

    var value: Double?

    func with(value: Double?) -> Filter {
        ManagementFee(id: id, rangeType: rangeType, value: value)
    }

}
