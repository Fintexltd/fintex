//
//  TradingFrequency.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

enum TradingFrequencyType: String, CaseIterable, Decodable {
    case daily, weekly, monthly, yearly

    var title: String {
        switch self {
        case .daily:
            return Localizable.filtersDaily.localized
        case .weekly:
            return Localizable.filtersWeekly.localized
        case .monthly:
            return Localizable.filtersMonthly.localized
        case .yearly:
            return Localizable.filtersYearly.localized
        }
    }
}

struct TradingFrequency: Filter, Equatable {
    let type: FilterType = .tradingFrequency
    var name: String {
        tradingFrequencyType.title
    }

    var id: Int = -1

    var isSelected: Bool = false

    let tradingFrequencyType: TradingFrequencyType

    func with(selection: Bool) -> Filter {
        TradingFrequency(id: id, isSelected: selection, tradingFrequencyType: tradingFrequencyType)
    }

    static func == (lhs: TradingFrequency, rhs: TradingFrequency) -> Bool {
        return lhs.id == rhs.id
    }
}
