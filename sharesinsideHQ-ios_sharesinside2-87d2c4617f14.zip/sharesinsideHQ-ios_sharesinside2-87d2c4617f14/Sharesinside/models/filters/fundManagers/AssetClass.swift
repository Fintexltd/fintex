//
//  AssetClass.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct AssetClass: Decodable, Filter {

    let type: FilterType = .assetClass

    var id: Int = 0
    var name: String = ""

    var isSelected: Bool = false

    enum CodingKeys: String, CodingKey {
        case id
        case name
    }

    func with(selection: Bool) -> Filter {
        return AssetClass(id: id, name: name, isSelected: selection)
    }

}
