//
//  FundTypeFilter.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct FundTypeFilter: Filter {

    let type: FilterType = .fundType
    let id: Int
    let name: String
    let isSelected: Bool
    let apiParam: String

    func with(selection: Bool) -> Filter {
        return FundTypeFilter(id: id, name: name, isSelected: selection, apiParam: apiParam)
    }
}
