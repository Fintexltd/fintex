//
//  OpenClose.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

enum OpenCloseType {
    case open, close

    var name: String {
        switch self {
        case .open:
            return Localizable.fundManagerOpen.localized
        case .close:
            return Localizable.fundManagerClose.localized
        }
    }
}

struct OpenClose: Filter {

    let type: FilterType = .openClose
    var name: String {
        openCloseType.name
    }

    var id: Int = -1

    var isSelected: Bool = false

    let openCloseType: OpenCloseType

    func with(selection: Bool) -> Filter {
        OpenClose(id: id, isSelected: selection, openCloseType: openCloseType)
    }
}
