//
//  Duration.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct Duration: RangeFilter {

    let type: FilterType = .duration

    let inputType: InputType = .integer

    var id: Int = -1

    let rangeType: RangeType

    var value: Double?

    func with(value: Double?) -> Filter {
        Duration(id: id, rangeType: rangeType, value: value)
    }

}
