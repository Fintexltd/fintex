//
//  CurrencyFilter.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

struct CurrencyFilter: Decodable, Filter {

    let type: FilterType = .currency
    var name: String {
        return "\(currencyName) (\(currencySymbol))"
    }

    var id: Int = 0
    var currencyName: String = ""
    var currencySymbol: String = ""

    var isSelected: Bool = false

    enum CodingKeys: String, CodingKey {
        case id
        case currencyName = "currency_name"
        case currencySymbol = "currency_symbol"
    }

    func with(selection: Bool) -> Filter {
        return CurrencyFilter(id: id, currencyName: currencyName, currencySymbol: currencySymbol, isSelected: selection)
    }

}
