//
//  RelationRequest.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 10/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum RelationRequestStatus: String, Decodable {
    case toActivate = "to_confirm"
    case active = "active"
    case pending = "pending"
    
    var nameForFilter: String {
        switch self {
        case .active: return Localizable.requestsStatusActive.localized
        case .pending: return Localizable.requestsStatusPending.localized
        case .toActivate: return Localizable.requestsStatusFilterToactivate.localized
        }
    }
    var name: String {
        switch self {
        case .active: return Localizable.requestsStatusActive.localized
        case .pending: return Localizable.requestsStatusPending.localized
        case .toActivate: return Localizable.requestsStatusToactivate.localized
        }
    }
}

struct RelationRequest: Decodable, Hashable {
    let id: Int
    let status: RelationRequestStatus
    let company: Company
    
    var hashValue: Int {
        return id
    }
}
