//
//  RequestsResponse.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 10/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct RequestsResponse: Decodable {
    var data: [RelationRequest]
    var meta: ListMetadata
}
