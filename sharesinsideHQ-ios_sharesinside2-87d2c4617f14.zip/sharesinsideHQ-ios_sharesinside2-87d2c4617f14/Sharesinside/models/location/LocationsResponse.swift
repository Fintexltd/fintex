//
//  LocationsResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 08/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct LocationsResponse: Decodable {
    let data: [String]
}
