//
//  Startup.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit

struct Startup: Decodable, Hashable {

    let id: Int
    let logo: String?
    let name: String?
    let address: String?
    let industry: String?
    var userGroups: [UserGroup]?
    var following: FollowingState
    let raisedAmount: Double

    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case industry
        case address
        case userGroups = "user_group"
        case raisedAmount = "raised_amount"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        industry = try container.decodeIfPresent(String.self, forKey: .industry)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = FollowingState.state(by: userGroups)
        raisedAmount = try container.decode(Double.self, forKey: .raisedAmount)
    }

    init(id: Int, logo: String?, name: String?, address: String?, industry: String?, userGroups: [UserGroup]?, following: FollowingState, raisedAmount: Double) {
        self.id = id
        self.logo = logo
        self.name = name
        self.address = address
        self.industry = industry
        self.userGroups = userGroups
        self.following = following
        self.raisedAmount = raisedAmount
    }

    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            (logo ?? "").hashValue,
            (name ?? "").hashValue,
            (address ?? "").hashValue,
            following.rawValue.hashValue
            ])
    }

    enum StartupDetailsType: String, Codable, CodingKey {
        case aboutUs = "about_us"
        case ourTeam = "our_team"
        case news = "news"
        case events = "events"
        case gallery = "gallery"
        case documents = "documents"
        case projects = "projects"

        var hashValue: Int {
            switch self {
            case .aboutUs: return 0
            case .ourTeam: return 1
            case .news: return 2
            case .events: return 3
            case .gallery: return 4
            case .documents: return 5
            case .projects: return 6
            }
        }
    }
}

extension Startup {
    func with(followingState state: FollowingState) -> Startup {
        var userGroups = self.userGroups
        switch state {
        case .following: userGroups?.append(.follower)
        case .notFollowing: userGroups?.removeAll(where: { $0 == .follower })
        default: break }

        return Startup(id: id,
            logo: logo,
            name: name,
            address: address,
            industry: industry,
            userGroups: userGroups,
            following: state,
            raisedAmount: raisedAmount
        )
    }

    var startupsCellGroups: [UserGroup] {
        return userGroups?.compactMap({
            ($0 == .shareholder || $0 == .vip || $0 == .follower) ? $0 : nil
        }) ?? []
    }
}
