//
//  StartupAbout.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct StartupAbout: Decodable {

    let id: Int
    let logo: String?
    let name: String?
    let title: String?
    let description: String?
    let address: String?
    let phone: String?
    let email: String?
    let website: String?
    let longitude: Float?
    let latitude: Float?
    let country: Country?
    let industry: Industry?
    let background: String?
    let videos: [Video]
    let videoLinks: [VideoLink]
    let attachments: [Attachments]
    let links: [Link]
    let symbols: [Symbol]
    let socialMedia: [SocialMedia]
    let userGroups: [UserGroup]?
    var following: FollowingState? = .notFollowing
    var availableInformations: [Startup.StartupDetailsType]
    var dontAllowShareholders: Bool
    let raisedAmount: Double
    let startupCategories: [StartupCategory]
    let currency: Currency

    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case title
        case description
        case address = "adress"
        case phone
        case email
        case website
        case longitude
        case latitude
        case country
        case industry
        case background
        case videos
        case videoLinks = "video_links"
        case attachments
        case links
        case symbols
        case socialMedia = "social_media"
        case userGroups = "user_group"
        case availableInformations = "available_tabs"
        case dontAllowShareholders = "dont_allow_shareholders"
        case raisedAmount = "raised_amount"
        case startupCategories = "startup_categories"
        case currency
    }

    init(id: Int, logo: String?, name: String?, title: String?,
         description: String?, address: String?, phone: String?,
         email: String?, website: String?, longitude: Float?,
         latitude: Float?, country: Country?, industry: Industry?,
         background: String?, videos: [Video], videoLinks: [VideoLink], attachments: [Attachments], links: [Link],
         symbols: [Symbol], socialMedia: [SocialMedia], userGroups: [UserGroup]?,
         following: FollowingState?, availableInformations: [Startup.StartupDetailsType],
         dontAllowShareholders: Bool, raisedAmount: Double, startupCategories: [StartupCategory], currency: Currency) {
        self.id = id
        self.logo = logo
        self.name = name
        self.title = title
        self.description = description
        self.address = address
        self.phone = phone
        self.email = email
        self.website = website
        self.longitude = longitude
        self.latitude = latitude
        self.country = country
        self.industry = industry
        self.background = background
        self.videos = videos
        self.videoLinks = videoLinks
        self.attachments = attachments
        self.links = links
        self.symbols = symbols
        self.socialMedia = socialMedia
        self.userGroups = userGroups
        self.following = following
        self.availableInformations = availableInformations
        self.dontAllowShareholders = dontAllowShareholders
        self.raisedAmount = raisedAmount
        self.startupCategories = startupCategories
        self.currency = currency
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        phone = try container.decodeIfPresent(String.self, forKey: .phone)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        website = try container.decodeIfPresent(String.self, forKey: .website)
        longitude = try container.decodeIfPresent(Float.self, forKey: .longitude)
        latitude = try container.decodeIfPresent(Float.self, forKey: .latitude)
        country = try container.decodeIfPresent(Country.self, forKey: .country)
        industry = try container.decodeIfPresent(Industry.self, forKey: .industry)
        background = try container.decodeIfPresent(String.self, forKey: .background)
        videos = try container.decode([Video].self, forKey: .videos)
        videoLinks = try container.decode([VideoLink].self, forKey: .videoLinks)
        attachments = try container.decode([Attachments].self, forKey: .attachments)
        links = try container.decode([Link].self, forKey: .links)
        symbols = try container.decodeIfPresent([Symbol].self, forKey: .symbols) ?? []
        socialMedia = try container.decode([SocialMedia].self, forKey: .socialMedia)
        dontAllowShareholders = try container.decode(Bool.self, forKey: .dontAllowShareholders)

        raisedAmount = try container.decode(Double.self, forKey: .raisedAmount)
        startupCategories = try container.decode([StartupCategory].self, forKey: .startupCategories)
        currency = try container.decode(Currency.self, forKey: .currency)

        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = userGroups?.contains(UserGroup.follower) == true ? .following : .notFollowing

        // decode available company details informations
        let availableInformationsContainer = try container.nestedContainer(keyedBy: Startup.StartupDetailsType.self, forKey: .availableInformations)
        self.availableInformations = []
        let informationKeys = availableInformationsContainer.allKeys
        for index in (0...informationKeys.count-1) {
            if let informationType = Startup.StartupDetailsType(rawValue: informationKeys[index].rawValue),
                let isPresent = try? availableInformationsContainer.decode(Bool.self, forKey: informationType),
                isPresent {

                self.availableInformations.append(informationType)
            }
        }
    }
}

extension StartupAbout: EmployerData {}

extension StartupAbout {

    var addressInformation: [Address] {
        var data: [Address] = []
        if let location = address {
            data.append(Address(text: location, type: .location, latitude: latitude, longitude: longitude))
        }
        if let phone = phone {
            data.append(Address(text: phone, type: .phone))
        }
        if let email = email {
            data.append(Address(text: email, type: .email))
        }
        if let website = website {
            data.append(Address(text: website, type: .website))
        }
        return data
    }

    func with(followingState: FollowingState) -> StartupAbout {
        return StartupAbout(id: id, logo: logo, name: name, title: title,
                            description: description, address: address, phone: phone,
                            email: email, website: website, longitude: longitude,
                            latitude: latitude, country: country, industry: industry,
                            background: background, videos: videos, videoLinks: videoLinks, attachments: attachments, links: links,
                            symbols: symbols, socialMedia: socialMedia, userGroups: userGroups,
                            following: followingState, availableInformations: availableInformations,
                            dontAllowShareholders: dontAllowShareholders, raisedAmount: raisedAmount, startupCategories: startupCategories, currency: currency)
    }

    var isShareholder: Bool {
        return userGroups?.contains(.shareholder) ?? false
    }

    var isShareholderPending: Bool {
        return userGroups?.contains(.shareholderPending) ?? false
    }

    var isShareholderToConfirm: Bool {
        return userGroups?.contains(.shareholderToConfirm) ?? false
    }

    var isShareholderBlocked: Bool {
        return userGroups?.contains(.blocked) ?? false
    }

    var canAssignAsShareholder: Bool {
        return !isShareholder && !isShareholderPending && !isShareholderToConfirm && !dontAllowShareholders && !isShareholderBlocked
    }
}

extension StartupAbout: VideoDataExtractable {}
