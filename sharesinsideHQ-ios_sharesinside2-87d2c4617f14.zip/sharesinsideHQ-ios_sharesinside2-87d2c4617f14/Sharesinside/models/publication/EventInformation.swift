//
//  NewsDetails.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct EventInformation: Decodable {
    
    let id: Int
    let issuerId: Int
    let issuerName: String
    let title: String
    let description: String
    let files: [Attachments]
    let links: [Link]
    let eventCountryCode: String
    let address: String
    let latitude: Double
    let longitude: Double
    let userGroups: [UserGroup]
    let frontendAppUrl: String?
    let timestamp: Double
    let timezone: String

    var issuerTypeString: String

    var issuerType: PublicationIssuerType? {
        PublicationIssuerType.from(string: issuerTypeString)
    }

    private let eventDateString: String
    private let logoPath: String
    private let publishedAt: Double?
    
    var logoUrl: URL? {
        return URL.forQuery(using: logoPath)
    }
    
    var publishDate: Date? {
        guard let publishedAt = publishedAt else { return nil }
        return Date(timeIntervalSince1970: publishedAt)
    }
    
    var eventDate: Date? {
        switch UserDefaultsEventsDisplayDateTypeRepository.shared.displayDateType {
        case .local:
            return utcDate.toTimezone()
        case .event:
            return utcDate.toTimezone(timezone: TimeZone(identifier: timezone))
        case .none:
            return nil
        }
    }

    var utcDate: Date {
        Date(timeIntervalSince1970: timestamp)
    }
    
    var prettyPrintedDescription: NSAttributedString? {
        return description.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.medium)
    }
    
    var shareUrl: URL? {
        return URL(string: frontendAppUrl)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case issuerId = "entitiable_id"
        case issuerName = "entitiable_name"
        case issuerTypeString = "entitiable_type"
        case logoPath = "logo_url"
        case title
        case description
        case files
        case links
        case publishedAt = "publish_at"
        case eventDateString = "event_date"
        case eventCountryCode = "event_country_code"
        case address = "adress"
        case latitude
        case longitude
        case userGroups = "user_group"
        case frontendAppUrl = "frontend_app_url"
        case timestamp = "event_timestamp"
        case timezone = "timezone_id"
    }
}
