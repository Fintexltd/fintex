//
//  NewsDetails.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct NewsInformation: Decodable {
    
    let id: Int
    let issuerId: Int
    let issuerName: String
    let title: String
    let description: String
    let files: [Attachments]
    let videos: [Video]
    let images: [Attachments]
    let links: [Link]
    let videoLinks: [VideoLink]
    let isAdHoc: Bool?
    let userGroups: [UserGroup]
    private let logoPath: String
    private let publishedAt: Double?
    let frontendAppUrl: String?

    var issuerTypeString: String

    var issuerType: PublicationIssuerType? {
        PublicationIssuerType.from(string: issuerTypeString)
    }

    var logoUrl: URL? {
        return URL.forQuery(using: logoPath)
    }
    
    var publishDate: Date? {
        guard let publishedAt = publishedAt else { return nil }
        return Date(timeIntervalSince1970: publishedAt)
    }
    
    var prettyPrintedDescription: NSAttributedString? {
        return description.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.medium)
    }
    
    var shareUrl: URL? {
        return URL(string: frontendAppUrl)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case issuerId = "entitiable_id"
        case issuerName = "entitiable_name"
        case issuerTypeString = "entitiable_type"
        case logoPath = "logo_url"
        case title
        case description
        case files
        case videos
        case images
        case links
        case videoLinks = "video_links"
        case publishedAt = "publish_at"
        case isAdHoc = "is_ad_hoc"
        case userGroups = "user_group"
        case frontendAppUrl = "frontend_app_url"
    }
}

extension NewsInformation: VideoDataExtractable {}
