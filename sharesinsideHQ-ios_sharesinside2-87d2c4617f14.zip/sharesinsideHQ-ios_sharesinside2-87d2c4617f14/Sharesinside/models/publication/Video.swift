//
//  Video.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Video: Decodable, AttachmentConvertible {
    
    let id: Int
    let oryginalName: String
    let mimeType: String
    let url: String
    let videoImg: String
    
    var videoUrl: URL? {
        return URL.forQuery(using: url)
    }
    
    var videoImgUrl: URL? {
        return URL.forQuery(using: videoImg)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case oryginalName = "oryginal_name"
        case url
        case mimeType = "mime_type"
        case videoImg = "video_img"
    }
    
    func toAttachment() -> AttachmentType {
        return AttachmentType(id: id,
                              url: url,
                              name: oryginalName,
                              iconType: Defaults.AttachmentType.video)
    }
}
