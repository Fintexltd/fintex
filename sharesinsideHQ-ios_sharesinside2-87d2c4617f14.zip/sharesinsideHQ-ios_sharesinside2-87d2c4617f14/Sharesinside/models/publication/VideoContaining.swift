//
//  VideoContaining.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/08/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

protocol VideoDataExtractable {
    var videos: [Video] { get }
    var videoLinks: [VideoLink] { get }
    var videoData: VideoData? { get }
}

extension VideoDataExtractable {
    var videoData: VideoData? {
        guard let videoUrl = videos.first?.videoUrl ?? videoLinks.first?.videoUrl else {
            return nil
        }

        let videoThumbnailUrl = videos.first?.videoImgUrl ?? videoLinks.first?.videoImgUrl
        return VideoData(videoUrl: videoUrl, videoThumbnailUrl: videoThumbnailUrl)
    }
}

struct VideoData: Equatable {
    let videoUrl: URL
    let videoThumbnailUrl: URL?
}
