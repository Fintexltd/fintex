//
//  InvestorRequestModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct InvestorRequestModel: Encodable {
    let fundId: Int?
    let startupId: Int?
    let firstName: String
    let lastName: String
    let phoneNumber: String
    let birthDate: String
    let address: String
    let postalCode: String
    let city: String
    let countryId: Int

    enum CodingKeys: String, CodingKey {
        case fundId = "fund_id"
        case startupId = "startup_id"
        case firstName = "first_name"
        case lastName = "last_name"
        case phoneNumber = "phone_number"
        case birthDate = "birth_date"
        case address
        case postalCode = "post_code"
        case city
        case countryId = "country_id"
    }
}
