//
//  Either.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum Either<Left, Right> {
    case left(Left)
    case right(Right)
}

extension Either: Decodable where Left: Decodable, Right: Decodable {
    init(from decoder: Decoder) throws {
        do {
            self = .left(try Left(from: decoder))
        } catch {
            self = .right(try Right(from: decoder))
        }
    }
}
