//
//  RegisterResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class RegisterResponse: Decodable {
    var message: String?
}
