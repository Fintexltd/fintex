//
//  AuthData.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

struct AuthData: Decodable {
    
    var accessToken: String
    var refreshToken: String?
    var tokenType: String
    var expiresIn: Float
    var message: String?
    
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
        case expiresIn = "expires_in"
        case refreshToken = "refresh_token"
        case message
    }
}
