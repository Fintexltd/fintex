//
//  AuthLinkedinResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 20.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class AuthLinkedinResponse: Decodable {
    var linkedInUser: LinkedInRegisterUserData?
    var authData: AuthData?

    required init(from decoder: Decoder) throws {
        linkedInUser = try? LinkedInRegisterUserData(from: decoder)
        authData = try? AuthData(from: decoder)
    }
}

struct LinkedInRegisterUserData: Decodable {

    let email: String
    let name: String
    let registrationKey: String
    let country: Country?

    enum CodingKeys: String, CodingKey {
        case email
        case name
        case country
        case registrationKey = "linkedin_register"
    }
}
