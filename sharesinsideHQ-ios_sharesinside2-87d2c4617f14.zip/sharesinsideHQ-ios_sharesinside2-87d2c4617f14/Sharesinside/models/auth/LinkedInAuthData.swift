//
//  LinkedInAuthData.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 20.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct LinkedInAuthData: Decodable {
    
    let accessToken: String
    let expiresIn: Float
    
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case expiresIn = "expires_in"
    }
}
