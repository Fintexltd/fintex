//
//  FundManagersResponse.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagersResponse: Decodable {
    var data: [FundManager]
    var meta: ListMetadata
}
