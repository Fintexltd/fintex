//
//  FundManagerDocumentsDetails.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagerDocumentsDetails: Decodable {
    let id: String
    let name: String
    let data: [FundManagerDocument]
    let meta: ListMetadata

    enum CodingKeys: String, CodingKey {
        case id = "section_id"
        case name
        case data
        case meta
    }
}
