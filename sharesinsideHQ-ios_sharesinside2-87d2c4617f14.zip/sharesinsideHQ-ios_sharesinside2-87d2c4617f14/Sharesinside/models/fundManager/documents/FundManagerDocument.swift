//
//  FundManagerDocument.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagerDocument: Hashable, Decodable {
    let title: String
    let timestamp: Double
    let file: Attachments
}
