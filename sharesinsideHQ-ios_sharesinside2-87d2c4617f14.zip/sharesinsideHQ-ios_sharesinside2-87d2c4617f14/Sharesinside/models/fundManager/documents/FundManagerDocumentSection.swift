//
//  FundManagerDocumentSection.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagerDocumentSection: Decodable {
    let id: Int
    let name: String
    let data: [FundManagerDocument]

    enum CodingKeys: String, CodingKey {
        case id = "section_id"
        case name
        case data
    }
}
