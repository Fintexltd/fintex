
//
//  FundManagerAbout.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 01/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManagerAbout: Decodable {

    let id: Int
    let logo: String?
    let name: String?
    let title: String?
    let description: String?
    let address: String?
    let phone: String?
    let email: String?
    let website: String?
    let longitude: Float?
    let latitude: Float?
    let country: Country?
    let background: String?
    let videos: [Video]
    let videoLinks: [VideoLink]
    let attachments: [Attachments]
    let links: [Link]
    let symbols: [Symbol]
    let socialMedia: [SocialMedia]
    let userGroups: [UserGroup]?
    var following: FollowingState? = .notFollowing
    var availableInformations: [FundManager.FundManagerDetailsType]
    let termsAndConditionsLinks: [Link]
    let termsAndConditionsAttachments: [Attachments]

    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case title
        case description
        case address
        case phone
        case email
        case website
        case longitude
        case latitude
        case country
        case background
        case videos
        case videoLinks = "video_links"
        case attachments
        case links
        case symbols
        case socialMedia = "social_media"
        case userGroups = "user_group"
        case availableInformations = "available_tabs"
        case termsAndConditionsAttachments = "terms_and_conditions"
        case termsAndConditionsLinks = "terms_and_conditions_links"
    }

    init(id: Int, logo: String?, name: String?, title: String?,
         description: String?, address: String?, phone: String?,
         email: String?, website: String?, longitude: Float?,
         latitude: Float?, country: Country?,
         background: String?, videos: [Video], videoLinks: [VideoLink], attachments: [Attachments], links: [Link],
         symbols: [Symbol], socialMedia: [SocialMedia], userGroups: [UserGroup]?,
         following: FollowingState?, availableInformations: [FundManager.FundManagerDetailsType],
         termsAndConditionsAttachments: [Attachments], termsAndConditionsLinks: [Link]) {
        self.id = id
        self.logo = logo
        self.name = name
        self.title = title
        self.description = description
        self.address = address
        self.phone = phone
        self.email = email
        self.website = website
        self.longitude = longitude
        self.latitude = latitude
        self.country = country
        self.background = background
        self.videos = videos
        self.videoLinks = videoLinks
        self.attachments = attachments
        self.links = links
        self.symbols = symbols
        self.socialMedia = socialMedia
        self.userGroups = userGroups
        self.following = following
        self.availableInformations = availableInformations
        self.termsAndConditionsAttachments = termsAndConditionsAttachments
        self.termsAndConditionsLinks = termsAndConditionsLinks
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        phone = try container.decodeIfPresent(String.self, forKey: .phone)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        website = try container.decodeIfPresent(String.self, forKey: .website)
        longitude = try container.decodeIfPresent(Float.self, forKey: .longitude)
        latitude = try container.decodeIfPresent(Float.self, forKey: .latitude)
        country = try container.decodeIfPresent(Country.self, forKey: .country)
        background = try container.decodeIfPresent(String.self, forKey: .background)
        videos = try container.decode([Video].self, forKey: .videos)
        videoLinks = try container.decode([VideoLink].self, forKey: .videoLinks)
        attachments = try container.decode([Attachments].self, forKey: .attachments)
        links = try container.decode([Link].self, forKey: .links)
        symbols = try container.decodeIfPresent([Symbol].self, forKey: .symbols) ?? []
        socialMedia = try container.decode([SocialMedia].self, forKey: .socialMedia)
        termsAndConditionsAttachments = try container.decode([Attachments].self, forKey: .termsAndConditionsAttachments)
        termsAndConditionsLinks = try container.decode([Link].self, forKey: .termsAndConditionsLinks)

        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = userGroups?.contains(UserGroup.follower) == true ? .following : .notFollowing

        // decode available fundManager details informations
        let availableInformationsContainer = try container.nestedContainer(keyedBy: FundManager.FundManagerDetailsType.self, forKey: .availableInformations)
        self.availableInformations = []
        let informationKeys = availableInformationsContainer.allKeys
        for index in (0...informationKeys.count-1) {
            if let informationType = FundManager.FundManagerDetailsType(rawValue: informationKeys[index].rawValue),
                let isPresent = try? availableInformationsContainer.decode(Bool.self, forKey: informationType),
                isPresent {

                self.availableInformations.append(informationType)
            }
        }
    }
}

extension FundManagerAbout: EmployerData {}

extension FundManagerAbout {

    var addressInformation: [Address] {
        var data: [Address] = []
        if let location = address {
            data.append(Address(text: location, type: .location, latitude: latitude, longitude: longitude))
        }
        if let phone = phone {
            data.append(Address(text: phone, type: .phone))
        }
        if let email = email {
            data.append(Address(text: email, type: .email))
        }
        if let website = website {
            data.append(Address(text: website, type: .website))
        }
        if let termsAndConditions = termsAndConditions {
            data.append(Address(text: termsAndConditions.name, type: .termsAndConditions, url: URL(string: termsAndConditions.url)))
        }
        return data
    }

    func with(followingState: FollowingState) -> FundManagerAbout {
        return FundManagerAbout(id: id, logo: logo, name: name, title: title,
                            description: description, address: address, phone: phone,
                            email: email, website: website, longitude: longitude,
                            latitude: latitude, country: country,
                            background: background, videos: videos, videoLinks: videoLinks, attachments: attachments, links: links,
                            symbols: symbols, socialMedia: socialMedia, userGroups: userGroups,
                            following: followingState, availableInformations: availableInformations,
            termsAndConditionsAttachments: termsAndConditionsAttachments, termsAndConditionsLinks: termsAndConditionsLinks)
    }

    var isShareholder: Bool {
        return userGroups?.contains(.shareholder) ?? false
    }

    var isShareholderPending: Bool {
        return userGroups?.contains(.shareholderPending) ?? false
    }

    var isShareholderToConfirm: Bool {
        return userGroups?.contains(.shareholderToConfirm) ?? false
    }

    var isShareholderBlocked: Bool {
        return userGroups?.contains(.blocked) ?? false
    }

    var canAssignAsShareholder: Bool {
        return !isShareholder && !isShareholderPending && !isShareholderToConfirm && !isShareholderBlocked
    }
}

extension FundManagerAbout: VideoDataExtractable {}

protocol TermsAndConditionsExtractable {
    var termsAndConditionsAttachments: [Attachments] { get }
    var termsAndConditionsLinks: [Link] { get }
    var termsAndConditions: TermsAndConditions? { get }
}

extension TermsAndConditionsExtractable {
    var termsAndConditions: TermsAndConditions? {
        guard let name = termsAndConditionsLinks.first?.name ?? termsAndConditionsAttachments.first?.oryginalName else {
            return nil
        }

        guard let url = termsAndConditionsLinks.first?.url ?? termsAndConditionsAttachments.first?.url else {
            return nil
        }
        return TermsAndConditions(name: name, url: url)
    }
}

struct TermsAndConditions: Equatable {
    let name: String
    let url: String
}

extension FundManagerAbout: TermsAndConditionsExtractable {}
