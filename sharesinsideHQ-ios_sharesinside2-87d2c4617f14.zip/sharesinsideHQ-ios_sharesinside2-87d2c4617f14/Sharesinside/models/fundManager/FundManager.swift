//
//  FundManager.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct FundManager: Decodable, Hashable {

    let id: Int
    let logo: String?
    let name: String?
    let address: String?
    var userGroups: [UserGroup]?
    var following: FollowingState
    let termsAndConditionsLinks: [Link]
    let termsAndConditionsAttachments: [Attachments]

    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case address
        case userGroups = "user_group"
        case termsAndConditionsAttachments = "terms_and_conditions"
        case termsAndConditionsLinks = "terms_and_conditions_links"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = FollowingState.state(by: userGroups)
        termsAndConditionsAttachments = try container.decode([Attachments].self, forKey: .termsAndConditionsAttachments)
        termsAndConditionsLinks = try container.decode([Link].self, forKey: .termsAndConditionsLinks)
    }

    init(id: Int, logo: String?, name: String?, address: String?, userGroups: [UserGroup]?, following: FollowingState, termsAndConditionsAttachments: [Attachments], termsAndConditionsLinks: [Link]) {
        self.id = id
        self.logo = logo
        self.name = name
        self.address = address
        self.userGroups = userGroups
        self.following = following
        self.termsAndConditionsAttachments = termsAndConditionsAttachments
        self.termsAndConditionsLinks = termsAndConditionsLinks
    }

    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            (logo ?? "").hashValue,
            (name ?? "").hashValue,
            (address ?? "").hashValue,
            following.rawValue.hashValue
            ])
    }

    enum FundManagerDetailsType: String, Codable, CodingKey {
        case aboutUs = "about_us"
        case funds
        case news
        case events
        case documents
        case ourTeam = "our_team"

        var hashValue: Int {
            switch self {
            case .aboutUs: return 0
            case .funds: return 1
            case .news: return 2
            case .events: return 3
            case .documents: return 4
            case .ourTeam: return 5
            }
        }
    }
}

extension FundManager {
    func with(followingState state: FollowingState) -> FundManager {
        var userGroups = self.userGroups
        switch state {
        case .following: userGroups?.append(.follower)
        case .notFollowing: userGroups?.removeAll(where: { $0 == .follower })
        default: break }

        return FundManager(id: id,
            logo: logo,
            name: name,
            address: address,
            userGroups: userGroups,
            following: state,
            termsAndConditionsAttachments: termsAndConditionsAttachments,
            termsAndConditionsLinks: termsAndConditionsLinks
        )
    }

    var fundManagersCellGroups: [UserGroup] {
        return userGroups?.compactMap({
            ($0 == .investor || $0 == .vip || $0 == .follower) ? $0 : nil
        }) ?? []
    }
}

extension FundManager: TermsAndConditionsExtractable {}
