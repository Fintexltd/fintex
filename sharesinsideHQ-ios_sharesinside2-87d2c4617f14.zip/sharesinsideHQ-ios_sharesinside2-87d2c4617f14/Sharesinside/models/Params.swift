//
//  Params.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct Params {
    let apiKey: String
    let apiSecret: String
    let redirectUrl: String
    let readScope: String
}
