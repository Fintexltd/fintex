//
//  CalendarModels.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

struct Month: Equatable {
    let name: String
    let startDate: Date
    let endDate: Date
    let daysCount: Int
    let days: [Day]
    
    init(basedOn monthDate: Date) {
        var calendar = Calendar.current
        calendar.locale = Locale(identifier: "en_US")
        
        self.name = calendar.standaloneMonthSymbols[calendar.component(.month, from: monthDate)-1]
        self.startDate = monthDate.startOfMonth()
        self.endDate = monthDate.endOfMonth()
        self.daysCount = calendar.component(.day, from: endDate)
        
        var days: [Day] = []
        var date = startDate
        while date <= endDate {
            days.append(Day(baseOn: date))
            date = calendar.date(byAdding: .day, value: 1, to: date)!
        }
        self.days = days
    }
    
    func configure(with daysWithEvent: [Date]) {
        let monthDateComponents = Calendar.current.dateComponents([.year, .month], from: startDate)
        let daysForMonth = daysWithEvent.filter { dayWithEvent in
            let dayWithEventComponents = Calendar.current.dateComponents([.year, .month], from: dayWithEvent)
            let isTheSameYearAndMonth = (dayWithEventComponents.year == monthDateComponents.year && dayWithEventComponents.month == monthDateComponents.month)
            return isTheSameYearAndMonth
        }
        guard daysForMonth.isEmpty == false else { return }
        var monthDays = self.days
        daysForMonth.forEach { dateWithEvent in
            if let accordingDay = monthDays.enumerated().first(where: { _, day in
                if let dayDate = day.date {
                    return Calendar.current.isDate(dayDate, inSameDayAs: dateWithEvent)
                }
                return false
            }) {
                accordingDay.element.hasEvent.accept(true)
                monthDays.remove(at: accordingDay.offset)
            }
        }
    }
    
    static func == (lhs: Month, rhs: Month) -> Bool {
        return lhs.startDate == rhs.startDate
    }
}

struct Day: Equatable {
    let number: Int?
    let date: Date?
    var hasEvent: BehaviorRelay<Bool>
    
    init(baseOn dayDate: Date, hasEvent: Bool = false) {
        self.number = Calendar.current.component(.day, from: dayDate)
        self.date = dayDate
        self.hasEvent = BehaviorRelay(value: false)
    }
    
    static func == (lhs: Day, rhs: Day) -> Bool {
        if lhs.date == nil || rhs.date == nil { return false }
        return lhs.date == rhs.date
    }
}
