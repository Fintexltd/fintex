//
//  EventDateDisplayType.swift
//  Sharesinside
//

import Foundation

enum EventDateDisplayType: String {
    /// Display local date
    case local
    /// Display event date
    case event
}
