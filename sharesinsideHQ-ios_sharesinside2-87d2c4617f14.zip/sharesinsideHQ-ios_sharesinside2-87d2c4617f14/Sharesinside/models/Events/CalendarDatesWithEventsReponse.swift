//
//  CalendarDatesWithEventsReponse.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct CalendarDatesWithEventsReponse: Codable {
    private let datesRaw: [String]
    
    var dates: [Date] {
        return datesRaw.compactMap { Date.from(string: $0, withFormat: .ohlcDateFormat )}
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        self.datesRaw = try container.decode([String].self)
    }
    
}
