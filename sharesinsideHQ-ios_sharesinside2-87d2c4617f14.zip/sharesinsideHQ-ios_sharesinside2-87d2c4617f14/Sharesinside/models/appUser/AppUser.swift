//
//  AppUser.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 06/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class AppUser: Decodable {
    let username: String
    let id: Int
    let email: String
    var relationsCount: Int
    var requestsCount: Int
    var isManualAccountConnected: Bool
    var isLinkedInAccountConnected: Bool
    var userGroups: [UserGroup]
    
    var linkedInConnectionStatus: LinkedInConnectionStatus {
        if isLinkedInAccountConnected {
            return isManualAccountConnected ? .connected : .connectedOnlyWithLinkedIn
        }
        return .disconnected
    }
    
    private let avatarURLPath: String? = nil
    var avatarURL: URL? {
        return URL(string: avatarURLPath)
    }
    
    enum CodingKeys: String, CodingKey {
        case username = "name"
        case id
        case email
        case relationsCount = "assigned_relations"
        case requestsCount = "requests"
        case isManualAccountConnected = "manual_login"
        case isLinkedInAccountConnected = "linkedin_login"
        case userGroups = "user_groups"
    }

    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(Int.self, forKey: .id)
        self.username = try container.decode(String.self, forKey: .username)
        self.email = try container.decode(String.self, forKey: .email)
        self.relationsCount = (try? container.decode(Int.self, forKey: .relationsCount)) ?? 0
        self.requestsCount = (try? container.decode(Int.self, forKey: .requestsCount)) ?? 0
        self.isManualAccountConnected = (try? container.decode(Bool.self, forKey: .isManualAccountConnected)) ?? true
        self.isLinkedInAccountConnected = (try? container.decode(Bool.self, forKey: .isLinkedInAccountConnected)) ?? false
        self.userGroups = (try? container.decode([UserGroup].self, forKey: .userGroups)) ?? []
    }
}

extension AppUser {
    
    static var current: AppUser?
    
    static let userUpdated = PublishRelay<Void>()
    
    static func decreaseRelationsCount() -> AppUser? {
        if let currentUser = AppUser.current {
            currentUser.relationsCount -= 1
            return currentUser
        }
        
        return AppUser.current
    }
    
    static func decreaseRelationRequestsCount() -> AppUser? {
        if let currentUser = AppUser.current {
            currentUser.requestsCount -= 1
            return currentUser
        }
        return AppUser.current
    }
    
    static func fetchCurrentUserDetails() {
        let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        let userManager = appDelegate?.applicationDependencies.profileManager
        _ = userManager?.getUserDetails()
            .subscribe(
                onNext: { user in
                    AppUser.current = user
                    AppUser.userUpdated.accept(())
                },
                onError: { error in
                    AppUser.userUpdated.accept(())
                    printDebug(error.localizedDescription)
                })
    }
}
