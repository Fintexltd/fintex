//
//  AppNotification.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

struct AppNotification {
    
    let id: Int
    let timestamp: Double?
    let title: String
    let message: String
    let destination: PushNotification.NotificationType?
    let destinationId: Int?
    let logo: String?
    
    var publishDate: Date? {
        guard let publishedAt = timestamp else { return nil }
        return Date(timeIntervalSince1970: publishedAt)
    }

    var logoUrl: URL? {
        return URL.forQuery(using: logo)
    }
}

extension AppNotification: Decodable {
    enum CodingKeys: String, CodingKey {
        case id
        case timestamp
        case title
        case message
        case destination
        case destinationId = "destination_id"
        case logo
    }
}

extension AppNotification: Hashable {
 
    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            title.hashValue,
            destination.hashValue,
            (destinationId ?? 0).hashValue,
            (logo ?? "").hashValue,
            (timestamp ?? 0).hashValue,
            message.hashValue
            ])
    }
}

extension AppNotification {
    
    var routeDestination: Destination? {
        guard let id = destinationId, let destination = destination else { return nil }
        
        switch destination {
        case .company: return .companyDetails(companyId: id)
        case .event: return .eventDetails(eventId: id)
        case .news: return .newsDetails(newsId: id)
        case .startup: return .startupDetails(startupId: id)
        case .fund: return .fundDetails(fundId: id)
        case .relations: return .relations(delegate: UIApplication.shared.visibleViewController as? RelationsCountHandler)
        case .project: return .projectDetails(projectId: id)
        case .notifications: return nil
        }
    }
}
