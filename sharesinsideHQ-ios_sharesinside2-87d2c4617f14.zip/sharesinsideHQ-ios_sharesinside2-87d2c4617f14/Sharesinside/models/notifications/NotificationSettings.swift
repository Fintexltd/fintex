//
//  NotificationSettings.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct NotificationSettingsModel: Codable {
    
    var allowPush: Bool
    var followingEvents: Bool
    var followingNews: Bool
    var shareholderEvents: Bool
    var shareholderNews: Bool
    var investorFundEvents: Bool
    var investorFundNews: Bool
    var fundEvents: Bool
    var fundNews: Bool
    var startupEvents: Bool
    var startupNews: Bool
    var investorStartupEvents: Bool
    var investorStartupNews: Bool
    
    enum CodingKeys: String, CodingKey {
        case allowPush = "allow_push"
        case followingEvents = "followed_events"
        case followingNews = "followed_news"
        case shareholderEvents = "shareholder_events"
        case shareholderNews = "shareholder_news"
        case investorFundEvents = "investor_fund_events"
        case investorFundNews = "investor_fund_news"
        case fundEvents = "followed_fund_events"
        case fundNews = "followed_fund_news"
        case startupEvents = "followed_startup_events"
        case startupNews = "followed_startup_news"
        case investorStartupEvents = "investor_startup_events"
        case investorStartupNews = "investor_startup_news"
    }
    
}
