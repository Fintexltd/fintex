//
//  CompanyNotification.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

struct PushNotification: Codable {
    
    let message: NotificationMessage?
    let badge: Int?
    let sound: String?
    let id: Int?
    let type: NotificationType?
    
    struct NotificationMessage: Codable {
        let title: String?
        let body: String?
    }
    
    enum NotificationType: String, Codable {
        case company
        case news
        case event
        case relations
        case notifications
        case fund
        case startup
        case project
    }
    
    enum CodingKeys: String, CodingKey {
        case message = "alert"
        case badge
        case sound
        case id
        case type
    }
    
    enum PresenationType {
        case present
        case push
        case select(screen: MainTabBarScreen)
    }
    
    var destination: Destination? {
        guard let type = type else { return nil }
        guard let id = id, type != .relations else { return Destination.relations(delegate: UIApplication.shared.visibleViewController as? RelationsCountHandler) }
        
        switch type {
        case .company: return .companyDetails(companyId: id)
        case .event: return .eventDetails(eventId: id)
        case .news: return .newsDetails(newsId: id)
        case .fund: return .fundDetails(fundId: id)
        case .startup: return .startupDetails(startupId: id)
        case .relations: return .relations(delegate: UIApplication.shared.visibleViewController as? RelationsCountHandler)
        case .project: return .projectDetails(projectId: id)
        case .notifications: return .notifications
        }
    }
    
    var isValid: Bool {
        return message != nil && (id != nil || type == .relations) && type != nil
    }
    
    var presentationType: PushNotification.PresenationType? {
        guard let type = type else { return nil }
        switch type {
        case .relations: return .present
        case .notifications: return .select(screen: .notifications)
        default: return .push
        }
    }
    
    static func make(using json: [String: Any]) -> PushNotification? {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: json, options: .prettyPrinted)
            let pushNotification = try JSONDecoder().decode(PushNotification.self, from: jsonData)
            return pushNotification
        } catch {
            print("Couldn't serilize PushNotification: \(error)")
            return nil
        }
    }
}

extension PushNotification.NotificationType {
    
    var associatedViewControllerClass: AnyClass {
        switch self {
        case .company: return CompanyDetailsViewController.self
        case .news: return NewsViewController.self
        case .event: return EventViewController.self
        case .relations: return RelationsViewController.self
        case .notifications: return NotificationsViewController.self
        case .startup: return StartupDetailsViewController.self
        case .fund: return FundDetailsViewController.self
        case .project: return ProjectViewController.self
        }
    }
}
