//
//  NotificationIndicator.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 06/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct AppNotificationsIndicator: Decodable {
    let indicator: Int
}
