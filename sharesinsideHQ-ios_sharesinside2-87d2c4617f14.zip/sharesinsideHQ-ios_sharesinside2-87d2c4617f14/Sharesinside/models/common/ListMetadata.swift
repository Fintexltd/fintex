//
//  ListMetadata.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 13.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

struct ListMetadata: Decodable {
    
    let currentPage: Int
    let lastPage: Int
    let total: Int
    let perPage: Int
    var isFollowingAll: Bool? = false
    
    enum CodingKeys: String, CodingKey {
        case currentPage = "current_page"
        case lastPage = "last_page"
        case total
        case perPage = "per_page"
        case isFollowingAll = "is_following_all"
    }
    
    func with(perPage: Int) -> ListMetadata {
        return ListMetadata(currentPage: currentPage,
                            lastPage: lastPage,
                            total: total,
                            perPage: perPage,
                            isFollowingAll: isFollowingAll)
    }
}
