//
//  Fund.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit

struct Fund: Decodable, Hashable {

    let id: Int
    let logo: String?
    let name: String?
    let isActive: Bool
    let isPassive: Bool
    let duration: Int
    let managementFee: String
    let performanceFee: String
    let currency: Currency
    var userGroups: [UserGroup]?
    let fundTypes: [FundType]
    var following: FollowingState
    let openClosed: String?
    let mainStockPrice: String?

    enum CodingKeys: String, CodingKey {
        case id
        case logo
        case name
        case isActive = "is_active"
        case isPassive = "is_passive"
        case duration
        case fundTypes = "fund_types"
        case managementFee = "management_fee"
        case performanceFee = "performance_fee"
        case userGroups = "user_group"
        case currency
        case mainStockPrice = "se_main_stock_price"
        case openClosed = "open_closed"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        isActive = try container.decode(Bool.self, forKey: .isActive)
        isPassive = try container.decode(Bool.self, forKey: .isPassive)
        duration = try container.decode(Int.self, forKey: .duration)
        fundTypes = try container.decode([FundType].self, forKey: .fundTypes)
        managementFee = try container.decode(String.self, forKey: .managementFee)
        performanceFee = try container.decode(String.self, forKey: .performanceFee)
        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = FollowingState.state(by: userGroups)
        currency = try container.decode(Currency.self, forKey: .currency)
        openClosed = try container.decode(String.self, forKey: .openClosed)
        mainStockPrice = try container.decode(String.self, forKey: .mainStockPrice)
    }

    init(id: Int, logo: String?, name: String?, isActive: Bool, isPassive: Bool, duration: Int, managementFee: String, performanceFee: String, userGroups: [UserGroup]?, fundTypes: [FundType], following: FollowingState, currency: Currency, openClosed: String?, mainStockPrice: String?) {
        self.id = id
        self.logo = logo
        self.name = name
        self.isActive = isActive
        self.isPassive = isPassive
        self.duration = duration
        self.fundTypes = fundTypes
        self.managementFee = managementFee
        self.performanceFee = performanceFee
        self.userGroups = userGroups
        self.following = following
        self.currency = currency
        self.openClosed = openClosed
        self.mainStockPrice = mainStockPrice
    }

    var hashValue: Int {
        return combineHashes([
            id.hashValue,
            (logo ?? "").hashValue,
            (name ?? "").hashValue,
            following.rawValue.hashValue
            ])
    }

    enum FundDetailsType: String, Codable, CodingKey {
        case aboutUs = "about_us"
        case news = "news"
        case events
        case documents
        case charts = "se_charts"

        var hashValue: Int {
            switch self {
            case .aboutUs: return 0
            case .news: return 1
            case .events: return 2
            case .documents: return 3
            case .charts: return 4
            }
        }
    }
}

extension Fund {
    func with(followingState state: FollowingState) -> Fund {
        var userGroups = self.userGroups
        switch state {
        case .following: userGroups?.append(.follower)
        case .notFollowing: userGroups?.removeAll(where: { $0 == .follower })
        default: break }

        return Fund(
            id: id,
            logo: logo,
            name: name,
            isActive: isActive,
            isPassive: isPassive,
            duration: duration,
            managementFee: managementFee,
            performanceFee: performanceFee,
            userGroups: userGroups,
            fundTypes: fundTypes,
            following: state,
            currency: currency,
            openClosed: openClosed,
            mainStockPrice: mainStockPrice
        )
    }

    var fundsCellGroups: [UserGroup] {
        return userGroups?.compactMap({
            ($0 == .investor || $0 == .vip || $0 == .follower) ? $0 : nil
        }) ?? []
    }
}

struct FundType: Codable, Equatable {
    let name: String
    let id: Int
}
