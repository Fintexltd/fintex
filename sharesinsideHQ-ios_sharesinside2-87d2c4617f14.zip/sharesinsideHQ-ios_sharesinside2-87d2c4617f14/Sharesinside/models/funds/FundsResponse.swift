//
//  FundsResponse.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct FundsResponse: Decodable {
    var data: [Fund]
    var meta: ListMetadata
}
