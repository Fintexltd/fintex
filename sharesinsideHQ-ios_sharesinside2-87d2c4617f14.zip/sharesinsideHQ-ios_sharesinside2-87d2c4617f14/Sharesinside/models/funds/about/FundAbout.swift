//
//  FundAbout.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct FundAbout: Decodable {

    let id: Int
    let fundManagerId: Int
    let logo: String?
    let name: String?
    let title: String?
    let description: String?
    let managementFee: String?
    let performanceFee: String?
    let duration: Int?
    let tradingFrequency: TradingFrequencyType?
    let isActive: Bool
    let isPassive: Bool
    let country: Country?
    let currency: Currency?
    let background: String?
    let videos: [Video]
    let videoLinks: [VideoLink]
    let attachments: [Attachments]
    let links: [Link]
    let socialMedia: [SocialMedia]
    let userGroups: [UserGroup]?
    var following: FollowingState? = .notFollowing
    var availableInformations: [Fund.FundDetailsType]
    let isAccepted: Bool
    let symbols: [Symbol]
    let termsAndConditionsLinks: [Link]
    let termsAndConditionsAttachments: [Attachments]
    let fundTypes: [FundType]
    let openClosed: String?

    enum CodingKeys: String, CodingKey {
        case id
        case fundManagerId = "funds_manager_id"
        case logo
        case name
        case title
        case description
        case managementFee = "management_fee"
        case performanceFee = "performance_fee"
        case duration
        case tradingFrequency = "trading_frequency"
        case isActive = "is_active"
        case isPassive = "is_passive"
        case symbols = "se_symbols"
        case country
        case currency
        case background
        case videos
        case videoLinks = "video_links"
        case attachments
        case links
        case socialMedia = "social_media"
        case userGroups = "user_group"
        case availableInformations = "available_tabs"
        case isAccepted = "is_accepted"
        case termsAndConditions = "terms_and_conditions"
        case termsAndConditionsLinks = "terms_and_conditions_links"
        case fundTypes = "fund_types"
        case openClosed = "open_closed"
    }

    init(id: Int, fundManagerId: Int, logo: String?, name: String?, title: String?,
         description: String?, managementFee: String?, performanceFee: String?, duration: Int?, tradingFrequency: TradingFrequencyType?, isActive: Bool, isPassive: Bool, country: Country?, currency: Currency?, background: String?, videos: [Video], videoLinks: [VideoLink], attachments: [Attachments], symbols: [Symbol], links: [Link], socialMedia: [SocialMedia], userGroups: [UserGroup]?,
         following: FollowingState?, availableInformations: [Fund.FundDetailsType], isAccepted: Bool, termsAndConditionsAttachments: [Attachments], termsAndConditionsLinks: [Link], fundTypes: [FundType], openClosed: String?) {
        self.id = id
        self.fundManagerId = fundManagerId
        self.managementFee = managementFee
        self.performanceFee = performanceFee
        self.duration = duration
        self.tradingFrequency = tradingFrequency
        self.isAccepted = isAccepted
        self.isActive = isActive
        self.isPassive = isPassive
        self.currency = currency
        self.termsAndConditionsLinks = termsAndConditionsLinks
        self.termsAndConditionsAttachments = termsAndConditionsAttachments
        self.logo = logo
        self.name = name
        self.title = title
        self.description = description
        self.country = country
        self.background = background
        self.videos = videos
        self.videoLinks = videoLinks
        self.attachments = attachments
        self.links = links
        self.socialMedia = socialMedia
        self.userGroups = userGroups
        self.following = following
        self.availableInformations = availableInformations
        self.fundTypes = fundTypes
        self.openClosed = openClosed
        self.symbols = symbols
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        fundManagerId = try container.decode(Int.self, forKey: .fundManagerId)
        managementFee = try container.decode(String.self, forKey: .managementFee)
        performanceFee = try container.decode(String.self, forKey: .performanceFee)
        duration = try container.decode(Int.self, forKey: .duration)
        tradingFrequency = try container.decodeIfPresent(TradingFrequencyType.self, forKey: .tradingFrequency)
        isAccepted = try container.decodeIfPresent(Bool.self, forKey: .isAccepted) ?? false
        isActive = try container.decodeIfPresent(Bool.self, forKey: .isActive) ?? false
        isPassive = try container.decodeIfPresent(Bool.self, forKey: .isPassive) ?? false
        currency = try container.decode(Currency.self, forKey: .currency)
        termsAndConditionsAttachments = try container.decode([Attachments].self, forKey: .termsAndConditions)
        termsAndConditionsLinks = try container.decode([Link].self, forKey: .termsAndConditionsLinks)
        logo = try container.decodeIfPresent(String.self, forKey: .logo)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        description = try container.decodeIfPresent(String.self, forKey: .description)
        country = try container.decodeIfPresent(Country.self, forKey: .country)
        background = try container.decodeIfPresent(String.self, forKey: .background)
        videos = try container.decode([Video].self, forKey: .videos)
        videoLinks = try container.decode([VideoLink].self, forKey: .videoLinks)
        attachments = try container.decode([Attachments].self, forKey: .attachments)
        links = try container.decode([Link].self, forKey: .links)
        socialMedia = try container.decode([SocialMedia].self, forKey: .socialMedia)
        fundTypes = try container.decode([FundType].self, forKey: .fundTypes)
        symbols = try container.decode([Symbol].self, forKey: .symbols)

        userGroups = try container.decodeIfPresent([UserGroup].self, forKey: .userGroups)
        following = userGroups?.contains(UserGroup.follower) == true ? .following : .notFollowing
        openClosed = try container.decode(String.self, forKey: .openClosed)

        // decode available fund details informations
        let availableInformationsContainer = try container.nestedContainer(keyedBy: Fund.FundDetailsType.self, forKey: .availableInformations)
        self.availableInformations = []
        let informationKeys = availableInformationsContainer.allKeys
        for index in (0...informationKeys.count-1) {
            if let informationType = Fund.FundDetailsType(rawValue: informationKeys[index].rawValue),
                let isPresent = try? availableInformationsContainer.decode(Bool.self, forKey: informationType),
                isPresent {

                self.availableInformations.append(informationType)
            }
        }
    }
}

extension FundAbout {

    var addressInformation: [Address] {
        return []
    }

    func with(followingState: FollowingState) -> FundAbout {
        return FundAbout(id: id, fundManagerId: fundManagerId, logo: logo, name: name, title: title,
                         description: description, managementFee: managementFee, performanceFee: performanceFee, duration: duration, tradingFrequency: tradingFrequency, isActive: isActive, isPassive: isPassive, country: country, currency: currency, background: background, videos: videos, videoLinks: videoLinks, attachments: attachments, symbols: symbols, links: links, socialMedia: socialMedia, userGroups: userGroups,
        following: followingState, availableInformations: availableInformations, isAccepted: isAccepted, termsAndConditionsAttachments: termsAndConditionsAttachments, termsAndConditionsLinks: termsAndConditionsLinks, fundTypes: fundTypes, openClosed: openClosed)
    }

    var isShareholder: Bool {
        return userGroups?.contains(.shareholder) ?? false
    }

    var isShareholderPending: Bool {
        return userGroups?.contains(.shareholderPending) ?? false
    }

    var isShareholderToConfirm: Bool {
        return userGroups?.contains(.shareholderToConfirm) ?? false
    }

    var isShareholderBlocked: Bool {
        return userGroups?.contains(.blocked) ?? false
    }

    var canAssignAsShareholder: Bool {
        return !isShareholder && !isShareholderPending && !isShareholderToConfirm && !isShareholderBlocked
    }
}

extension FundAbout: VideoDataExtractable {}

extension FundAbout: TermsAndConditionsExtractable {}
