//
//  Currency.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation

struct Currency: Decodable, Hashable {
    let id: Int
    let rawSymbol: String?
    let currencySymbol: String?
    var symbol: String? {
        rawSymbol ?? currencySymbol
    }

    let rawName: String?
    let currencyName: String?
    var name: String? {
        rawName ?? currencyName
    }

    enum CodingKeys: String, CodingKey {
        case id
        case rawSymbol = "symbol"
        case currencySymbol = "currency_symbol"
        case rawName = "name"
        case currencyName = "currency_name"
    }
}
