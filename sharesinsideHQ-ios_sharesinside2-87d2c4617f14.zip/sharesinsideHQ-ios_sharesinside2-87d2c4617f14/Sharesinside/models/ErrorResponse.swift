//
//  ErrorResponse.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

struct ErrorResponse: LocalizedError {
    
    var message: String
    var status: Int = 0
    var error: String?
    var errors: [String: [String]]?
    
    var errorDescription: String? {
        return message
    }
    
    var prettyPrintedErrors: String? {
        return errors.flatMap {
            $0.keys.flatMap { errors?[$0] ?? [] }
        }?.joined(separator: "\n")
    }
    
    var messageWithErrors: String {
        if let errors = prettyPrintedErrors {
            return message + "\n" + errors
        }
        return message
    }
}

extension ErrorResponse: Decodable {
    
    enum CodingKeys: String, CodingKey {
        case error
        case errors
        case message
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.message = try container.decode(String.self, forKey: .message)
        
        self.error = try? container.decode(String.self, forKey: .error)
        
        if  error == nil {
            errors = try container.decode([String: [String]].self, forKey: .errors)
        }
    }
}
