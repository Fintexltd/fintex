//
//  ListResponse.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

struct ListResponse<Item: Decodable>: Decodable {
    var data: [Item]
    var meta: ListMetadata
}
