//
//  AuthHandler.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import Alamofire
import RxSwift

class AuthHandler {
    
    private static let MAX_TOKEN_REFRESH_COUNT = 1
    
    private var accessToken: String {
        return Config.accessToken
    }
    
    private let lock = NSLock()
    private let disposeBag = DisposeBag()
    private let baseUrlString: String
    private let apiManager: ApiManager
    
    private var tokenRefreshCount = 0
    
    init(withUrl url: String, andApiManager apiManager: ApiManager) {
        self.baseUrlString = url
        self.apiManager = apiManager
    }
}

extension AuthHandler: RequestAdapter {
    func adapt(_ urlRequest: URLRequest) throws -> URLRequest {
        guard let url = urlRequest.url?.absoluteString, url.hasPrefix(baseUrlString) else {
            return urlRequest
        }
        
        var urlRequest = urlRequest
        urlRequest.setValue("application/json", forHTTPHeaderField: "Accept")
        urlRequest.setValue(" Bearer \(accessToken)", forHTTPHeaderField: Defaults.ApiKeys.accessToken)
        
        return urlRequest
    }
}

extension AuthHandler: RequestRetrier {
    func should(_ manager: SessionManager, retry request: Request, with error: Error, completion: @escaping RequestRetryCompletion) {
        lock.lock() ; defer { lock.unlock() }
        
        if let response = request.task?.response as? HTTPURLResponse,
            response.statusCode == ApiError.notAuthorized.rawValue &&
                tokenRefreshCount == 0 && response.url?.absoluteString.hasSuffix("token") != true {
            refreshToken(withCompletion: completion)
        } else {
            tokenRefreshCount = 0
            completion(false, 0.0)
        }
    }
    
    private func refreshToken(withCompletion completion: @escaping RequestRetryCompletion) {
        apiManager.refreshToken(Config.refreshToken)
            .do(onSubscribe: { [weak self] in self?.tokenRefreshCount += 1 })
            .subscribe(onNext: { data in
                Config.accessToken = data.accessToken
                completion(true, 0.0)
            }, onError: { _ in
                self.tokenRefreshCount = 0
                completion(false, 0.0)
            }).disposed(by: disposeBag)
    }
    
}
