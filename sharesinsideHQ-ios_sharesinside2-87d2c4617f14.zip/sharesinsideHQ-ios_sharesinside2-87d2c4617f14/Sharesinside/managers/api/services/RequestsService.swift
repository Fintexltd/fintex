//
//  RequestsService.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 09/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

protocol RequestsService {
    func fetchRequests(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RequestsResponse>
    func cancel(_ request: RelationRequest) -> Observable<MessageResponse>
    func requestForResendCode(for request: RelationRequest) -> Observable<MessageResponse>
    func activate(_ request: RelationRequest, with code: String) -> Observable<MessageResponse>
}

extension ApiManager: RequestsService {
    
    func fetchRequests(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RequestsResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders/user/requests")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func cancel(_ request: RelationRequest) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders/\(request.id)")
        
        return manager.rx.request(.delete, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func requestForResendCode(for request: RelationRequest) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders/resend-code")
        let params: Parameters = [
            "shareholder_id": request.id
        ]
        return manager.rx.request(.post, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
    func activate(_ request: RelationRequest, with code: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders/activate")
        let params: Parameters = [
            "code": code,
            "company_id": request.company.id
        ]
        return manager.rx.request(.post, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
}
