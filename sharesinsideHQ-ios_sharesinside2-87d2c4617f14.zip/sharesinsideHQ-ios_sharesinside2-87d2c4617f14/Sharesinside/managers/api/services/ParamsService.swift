//
//  ParamsService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol ParamsService {
    func fetchParams() -> Observable<[String]>
}

extension ApiManager: ParamsService {
    
    func fetchParams() -> Observable<[String]> {
        let url = ApiManager.apiUrl.appending("/params")
        let body: Parameters = ["secret": Defaults.LinkedIn.apiSecret]
        
        return manager.rx.request(.get, url, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }
    
}
