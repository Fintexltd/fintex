//
//  FiltersService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 15.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import Alamofire
import RxSwift

protocol FiltersService {
    func fetchIndustries() -> Observable<[Industry]>
    func fetchSectors() -> Observable<[EconomicSector]>
    func fetchContinents() -> Observable<[Continent]>
    func fetchCurrencies() -> Observable<[CurrencyFilter]>
    func fetchStartupCategories() -> Observable<[StartupCategory]>
    func fetchAssetClasses() -> Observable<[AssetClass]>
    func searchLocations(withText text: String) -> Observable<LocationsResponse>
    func fetchSuggestedLocations() -> Observable<LocationsResponse>
}

extension ApiManager: FiltersService {
    
    func fetchIndustries() -> Observable<[Industry]> {
        let url = ApiManager.apiUrl.appending("/industries")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchStartupCategories() -> Observable<[StartupCategory]> {
        let url = ApiManager.apiUrl.appending("/startup-categories")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchSectors() -> Observable<[EconomicSector]> {
        let url = ApiManager.apiUrl.appending("/economic-sectors")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchContinents() -> Observable<[Continent]> {
        let url = ApiManager.apiUrl.appending("/continents")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchCurrencies() -> Observable<[CurrencyFilter]> {
        let url = ApiManager.apiUrl.appending("/currencies")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchAssetClasses() -> Observable<[AssetClass]> {
        let url = ApiManager.apiUrl.appending("/fund-types")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func searchLocations(withText text: String) -> Observable<LocationsResponse> {
        let url = ApiManager.apiUrl.appending("/locations")
        let params: Parameters = ["search": text]
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchSuggestedLocations() -> Observable<LocationsResponse> {
        let url = ApiManager.apiUrl.appending("/locations/suggested")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
}
