//
//  CountriesService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol WatchlistService {
    func fetchWatchlist(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int?) -> Observable<WatchlistResponse>
    func fetchCompanyNews(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchCompanyEvents(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchFundNews(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchFundEvents(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchFundManagerNews(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchFundManagerEvents(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchStartupNews(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchStartupProjects(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchStartupEvents(id: Int, page: Int) -> Observable<WatchlistResponse>
    func fetchNewsDetails(id: Int) -> Observable<NewsInformation>
    func fetchProjectDetails(id: Int) -> Observable<ProjectInformation>
    func fetchEventDetails(id: Int) -> Observable<EventInformation>
    func fetchLatestNews(for newsId: Int) -> Observable<[News]>
    func fetchLatestEvents(for newsId: Int) -> Observable<[Event]>
    func fetchLatestProjects(for projectId: Int) -> Observable<[Project]>
}

extension ApiManager: WatchlistService {
    func fetchCompanyNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/companies/\(id)/news")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchCompanyEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/companies/\(id)/events")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchFundNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/funds/\(id)/news")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchFundEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/funds/\(id)/events")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchFundManagerNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(id)/news")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchFundManagerEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(id)/events")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchStartupNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)/news")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchStartupEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)/events")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchStartupProjects(id: Int, page: Int) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)/projects")
        let params: Parameters = ["page": page]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchWatchlist(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int?) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/watchlist")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page
        params?["per_page"] = itemsPerPage
        
        if filters.adHoc {
            params?["ad_hoc"] = 1
        }
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchNewsDetails(id: Int) -> Observable<NewsInformation> {
        let url = ApiManager.apiUrl.appending("/news/\(id)")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchProjectDetails(id: Int) -> Observable<ProjectInformation> {
        let url = ApiManager.apiUrl.appending("/projects/\(id)")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchEventDetails(id: Int) -> Observable<EventInformation> {
        let url = ApiManager.apiUrl.appending("/events/\(id)")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchLatestNews(for newsId: Int) -> Observable<[News]> {
        let url = ApiManager.apiUrl.appending("/news/\(newsId)/latest")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchLatestEvents(for eventId: Int) -> Observable<[Event]> {
        let url = ApiManager.apiUrl.appending("/events/\(eventId)/latest")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }

    func fetchLatestProjects(for projectId: Int) -> Observable<[Project]> {
        let url = ApiManager.apiUrl.appending("/projects/\(projectId)/latest")

        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
    
}
