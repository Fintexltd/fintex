//
//  DocumentsService.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 22.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import RxSwift
import Alamofire

protocol DocumentsService {
    func getTermsAndConditions() -> Observable<MessageResponse>
    func getPrivacyPolicy() -> Observable<MessageResponse>
    func getDocuments(fundManagerId: Int) -> Observable<[FundManagerDocumentSection]>
    func getDocumentsDetails(fundManagerId: Int, sectionId: Int, page: Int) -> Observable<FundManagerDocumentsDetails>
}

extension ApiManager: DocumentsService {
    
    func getTermsAndConditions() -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/static/terms")
        
        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }
    
    func getPrivacyPolicy() -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/static/privacy_policy")
        
        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }

    func getDocuments(fundManagerId: Int) -> Observable<[FundManagerDocumentSection]> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(fundManagerId)/documents")

        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }

    func getDocumentsDetails(fundManagerId: Int, sectionId: Int, page: Int) -> Observable<FundManagerDocumentsDetails> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(fundManagerId)/documents/list")

        let parameters: Parameters? = [
            "section_id": sectionId,
            "page": page
        ]

        return manager.rx.request(.get, url, parameters: parameters, encoding: URLEncoding.default).mapToObject()
    }
}
