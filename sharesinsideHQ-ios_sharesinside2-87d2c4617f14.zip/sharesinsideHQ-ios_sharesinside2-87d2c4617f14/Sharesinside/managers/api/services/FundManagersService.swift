//
//  FundManagersService.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol FundManagersService {
    func fetchFundManagerDetails(id: Int) -> Observable<FundManagerAbout>
    func fetchFundManagers(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<FundManagersResponse>
    func followFundManager(id: Int) -> Observable<MessageResponse>
    func unfollowFundManager(id: Int) -> Observable<MessageResponse>
    func fetchEmployeesGroup(fundManagerId: Int) -> Observable<[EmployeesGroup]>
}

extension ApiManager: FundManagersService {

    func fetchFundManagerDetails(id: Int) -> Observable<FundManagerAbout> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(id)")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchFundManagers(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<FundManagersResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page

        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchEmployeesGroup(fundManagerId: Int) -> Observable<[EmployeesGroup]> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(fundManagerId)/employees")
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func followFundManager(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(id)/follow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func unfollowFundManager(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(id)/unfollow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }
}
