//
//  AuthApiService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire
import AlamofireActivityLogger

protocol AuthApiService {
    func refreshToken(_ token: String) -> Observable<AuthData>

    func login(withUsername username: String, password: String) -> Observable<AuthData>
    
    func loginAsDemo() -> Observable<AuthData>

    func linkedInAuth(withAuthorizationCode code: String, andParams params: Params) -> Observable<LinkedInAuthData>

    func apiLinkedInAuth(withLinkedInAccessToken token: String) -> Observable<AuthLinkedinResponse>

    func register(name: String, email: String, password: String?, passwordConfirmation: String?,
                  linkedinRegister: String?, countryId: Int, acceptTerms: Bool) -> Observable<RegisterResponse>
    
    func resetPassword(for email: String) -> Observable<MessageResponse>
}

extension ApiManager: AuthApiService {

    func refreshToken(_ token: String) -> Observable<AuthData> {
        let url = ApiManager.oauthUrl.appending("/refreshToken")
        let body: Parameters = [:]

        return manager.rx.request(.post, url, parameters: body, encoding: JSONEncoding.default)
            .mapToObject()
    }

    func login(withUsername username: String, password: String) -> Observable<AuthData> {
        let url = ApiManager.oauthUrl.appending("/token")

        var clientSecret = ""
        #if DEV
        clientSecret = "mqrSYEg5K9Y0lKCA1vNbkZ80I6ZV4LgCY6ofv9xP"
        #else
        clientSecret = "OuO51HQoZ1T3eEFCUB1yaUPIzy1SngGvESmPoYLP"
        #endif
        let body: Parameters = [
            "grant_type": "password",
            "client_id": "3",
            "client_secret": clientSecret,
            "username": username,
            "password": password
        ]

        return manager.rx.request(.post, url, parameters: body, encoding: JSONEncoding.default)
            .mapToObject()
    }

    func linkedInAuth(withAuthorizationCode code: String, andParams params: Params) -> Observable<LinkedInAuthData> {
        let body: Parameters = [
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": params.redirectUrl,
            "client_id": params.apiKey,
            "client_secret": params.apiSecret
        ]

        return manager.rx.request(.post, Defaults.LinkedIn.accessTokenUrl, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }

    func apiLinkedInAuth(withLinkedInAccessToken token: String) -> Observable<AuthLinkedinResponse> {
        let url = ApiManager.oauthUrl.appending("/linkedin")
        let body: Parameters = ["token": token]

        return manager.rx.request(.get, url, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }

    func register(name: String, email: String, password: String?, passwordConfirmation: String?,
                  linkedinRegister: String?, countryId: Int, acceptTerms: Bool) -> Observable<RegisterResponse> {
        let url = ApiManager.apiUrl.appending("/register")
        var body: Parameters = [
            "name": name,
            "email": email,
            "country_id": countryId,
            "accept_terms": acceptTerms
        ]

        if let linkedinRegister = linkedinRegister {
            body["linkedin_register"] = linkedinRegister
        } else {
            body["password"] = password ?? ""
            body["password_confirmation"] = passwordConfirmation ?? ""
        }

        return manager.rx.request(.post, url, parameters: body, encoding: JSONEncoding.default)
            .mapToObject()
    }
    
    func resetPassword(for email: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/password-reset")
        let body: Parameters = ["email": email]
        
        return manager.rx.request(.post, url, parameters: body, encoding: JSONEncoding.default).mapToObject()
    }
    
    func loginAsDemo() -> Observable<AuthData> {
        let url = ApiManager.oauthUrl.appending("/demo")
        return manager.rx.request(.post, url, encoding: JSONEncoding.default).mapToObject()
    }
}
