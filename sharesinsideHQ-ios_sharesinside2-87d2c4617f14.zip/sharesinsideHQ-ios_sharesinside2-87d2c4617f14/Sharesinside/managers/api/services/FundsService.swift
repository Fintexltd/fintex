//
//  FundsService.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol FundsService {
    func fetchFundDetails(id: Int) -> Observable<FundAbout>
    func fetchFunds(fromPage page: Int, fundManagerId: Int, withFilters filters: AdvancedFilters) -> Observable<FundsResponse>
    func fetchFundDocuments(fundId: Int) -> Observable<[HistoricalDataSection]>
    func fetchDocumentsDetails(fundId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse>
    func fetchChartsFundDataResponse(fundId: Int) -> Observable<CompanyCharts.CompanyChartsData>
    func assignAsInvestor(requestData: InvestorRequestModel) -> Observable<MessageResponse>
    func followFund(id: Int) -> Observable<MessageResponse>
    func unfollowFund(id: Int) -> Observable<MessageResponse>
}

extension ApiManager: FundsService {

    func fetchFundDetails(id: Int) -> Observable<FundAbout> {
        let url = ApiManager.apiUrl.appending("/funds/\(id)")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchFunds(fromPage page: Int, fundManagerId: Int, withFilters filters: AdvancedFilters) -> Observable<FundsResponse> {
        let url = ApiManager.apiUrl.appending("/funds-managers/\(fundManagerId)/funds")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page

        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchChartsFundDataResponse(fundId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        let url = ApiManager.apiUrl.appending("/funds/\(fundId)/se-charts")
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }

    func fetchFundDocuments(fundId: Int) -> Observable<[HistoricalDataSection]> {
        let url = ApiManager.apiUrl.appending("/funds/\(fundId)/documents")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchDocumentsDetails(fundId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        let url = ApiManager.apiUrl.appending("/funds/\(fundId)/documents/list")
        let params: Parameters? = [
            "id": fundId,
            "section_id": sectionId,
            "page": page
        ]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func followFund(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/funds/\(id)/follow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func assignAsInvestor(requestData: InvestorRequestModel) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders")
        let body: Parameters? = requestData.asDictionary()

        return manager.rx.request(.post, url, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }

    func unfollowFund(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/funds/\(id)/unfollow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }

}
