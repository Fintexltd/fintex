//
//  EventsService.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol EventsService {
    func fetchDaysWithEvents(startDate: Date) -> Observable<CalendarDatesWithEventsReponse>
    func fetchEvents(fromPage page: Int, withFilters filters: AdvancedFilters?, itemsPerPage: Int?) -> Observable<WatchlistResponse>
    func searchEvents(withSearchText searchText: String, andFilters filters: AdvancedFilters?) -> Observable<[String]>
}

extension ApiManager: EventsService {
    
    func fetchDaysWithEvents(startDate: Date) -> Observable<CalendarDatesWithEventsReponse> {
        let url = ApiManager.apiUrl.appending("/calendar")
        let params: Parameters = [
            "event_from": startDate.toString(withFromat: .ohlcDateFormat),
            "event_to": Calendar.current.date(byAdding: .year, value: 1, to: Date())!.toString(withFromat: .ohlcDateFormat)
        ]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchEvents(fromPage page: Int = 0, withFilters filters: AdvancedFilters? = nil, itemsPerPage: Int? = nil) -> Observable<WatchlistResponse> {
        let url = ApiManager.apiUrl.appending("/events")
        var params: Parameters? = filters?.asDictionary()
        params?["page"] = page
        params?["per_page"] = itemsPerPage
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.queryString).mapToObject()
    }
    
    func searchEvents(withSearchText searchText: String, andFilters filters: AdvancedFilters?) -> Observable<[String]> {
        let url = ApiManager.apiUrl.appending("/events-typeahead")
        var params: Parameters? = filters?.asDictionary()
        params?["search"] = searchText
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.queryString).mapToObject()
    }
}
