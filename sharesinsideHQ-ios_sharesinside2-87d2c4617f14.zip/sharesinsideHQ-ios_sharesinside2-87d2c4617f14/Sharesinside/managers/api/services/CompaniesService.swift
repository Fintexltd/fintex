//
//  CountriesService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol CompaniesService {
    func fetchCompanyDetails(id: Int) -> Observable<CompanyAbout>
    func fetchCompanies(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<CompaniesResponse>
    func fetchEmployeesGroup(companyId: Int) -> Observable<[EmployeesGroup]>
    func fetchHistoricalDataSection(companyId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse>
    func fetchHistoricalDataResponse(companyId: Int) -> Observable<[HistoricalDataSection]>
    func fetchGalleries(companyId: Int) -> Observable<[Album]>
    func fetchChartsCompanyDataResponse(companyId: Int) -> Observable<CompanyCharts.CompanyChartsData>
    func followCompany(id: Int) -> Observable<MessageResponse>
    func unfollowCompany(id: Int) -> Observable<MessageResponse>
    func followAllCompanies(matching filters: AdvancedFilters) -> Observable<MessageResponse>
}

extension ApiManager: CompaniesService {
    
    func fetchCompanyDetails(id: Int) -> Observable<CompanyAbout> {
        let url = ApiManager.apiUrl.appending("/companies/\(id)")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchCompanies(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<CompaniesResponse> {
        let url = ApiManager.apiUrl.appending("/companies")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchEmployeesGroup(companyId: Int) -> Observable<[EmployeesGroup]> {
        let url = ApiManager.apiUrl.appending("/companies/\(companyId)/employees")
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func fetchHistoricalDataResponse(companyId: Int) -> Observable<[HistoricalDataSection]> {
        let url = ApiManager.apiUrl.appending("/companies/\(companyId)/historical-data")
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchHistoricalDataSection(companyId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        let url = ApiManager.apiUrl.appending("/companies/\(companyId)/historical-data/list")
        let params: Parameters? = [
            "id": companyId,
            "section_id": sectionId,
            "page": page
        ]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
    
    func fetchGalleries(companyId: Int) -> Observable<[Album]> {
        let url = ApiManager.apiUrl.appending("/companies/\(companyId)/galleries")
        
        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }
    
    func fetchChartsCompanyDataResponse(companyId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        let url = ApiManager.apiUrl.appending("/companies/\(companyId)/av-charts")
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
    
    func followCompany(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/companies/\(id)/follow")
        
        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func unfollowCompany(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/companies/\(id)/unfollow")
        
        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func followAllCompanies(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/companies/follow-filters")
        var params: Parameters? = filters.asDictionary()
        params?["type"] = "follow"
        
        return manager.rx.request(.post, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
}
