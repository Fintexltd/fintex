//
//  NotificationsService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol NotificationsService {
    func fetchNotificationsSettings() -> Observable<NotificationSettingsModel>
    func pushNotificationsSettings(settings: NotificationSettingsModel) -> Observable<MessageResponse>
    func fetchAppNotifications(forPage page: Int) -> Observable<AppNotificationsResponse>
    func getAppNotificationsIndicator() -> Observable<AppNotificationsIndicator>
}

extension ApiManager: NotificationsService {
    
    func fetchNotificationsSettings() -> Observable<NotificationSettingsModel> {
        let url = ApiManager.apiUrl.appending("/notification-settings")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
    
    func pushNotificationsSettings(settings: NotificationSettingsModel) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/notification-settings")
        let body: Parameters? = settings.asDictionary()
        
        return manager.rx.request(.put, url, parameters: body, encoding: JSONEncoding.default)
            .mapToObject()
    }
    
    func fetchAppNotifications(forPage page: Int) -> Observable<AppNotificationsResponse> {
        let url = ApiManager.apiUrl.appending("/notifications")
        let body: Parameters? = ["page": page]

        return manager.rx.request(.get, url, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func getAppNotificationsIndicator() -> Observable<AppNotificationsIndicator> {
        let url = ApiManager.apiUrl.appending("/notifications/indicator")
        
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }
}
