//
//  UserApiService.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 06/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol ProfileService {
    func fetchProfileDetails() -> Observable<AppUser>
    func changeEmail(with newEmail: String) -> Observable<MessageResponse>
    func changeUsername(with newUsername: String) -> Observable<MessageResponse>
    func changePassword(oldPassword: String, newPassword: String, repeatedPassword: String) -> Observable<AuthData>
    func registerForPushNotifications(_ token: String)
    func setPassword(newPassword: String, repeatedPassword: String) -> Observable<MessageResponse>
    func connectWithLinkedIn(token: String) -> Observable<MessageResponse>
    func disconnectWithLinkedIn() -> Observable<MessageResponse>
}

extension ApiManager: ProfileService {

    func fetchProfileDetails() -> Observable<AppUser> {
        let url = ApiManager.apiUrl.appending("/users/me")
        
        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }
    
    func changeEmail(with newEmail: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/users/email-change")
        let params: Parameters? = ["new_email": newEmail]
        
        return manager.rx.request(.post, url, parameters: params, encoding: JSONEncoding.default).mapToObject()
    }
    
    func changeUsername(with newUsername: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/users/username-change")
        let params: Parameters? = ["new_username": newUsername]
        
        return manager.rx.request(.post, url, parameters: params, encoding: JSONEncoding.default).mapToObject()
    }
    
    func changePassword(oldPassword: String, newPassword: String, repeatedPassword: String) -> Observable<AuthData> {
        let url = ApiManager.apiUrl.appending("/users/password-change")
        let params: Parameters? = [
            "old_password": oldPassword,
            "new_password": newPassword,
            "repeat_password": repeatedPassword
        ]
        return manager.rx.request(.post, url, parameters: params, encoding: JSONEncoding.default).mapToObject()
    }
    
    func registerForPushNotifications(_ token: String) {
        let url = ApiManager.apiUrl.appending("/push/register")
        let params: Parameters? = [
            "system": "iOS",
            "token": token,
            "language": Localizable.language.localized
        ]
        manager.request(url, method: .post, parameters: params, encoding: JSONEncoding.default).log().response { response in
            print("Registration push notifications toke in SI backend - response code: \(response.response?.statusCode ?? -1)")
        }
    }
    
    func setPassword(newPassword: String, repeatedPassword: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/manual-append")
        let params: Parameters? = [
            "password": newPassword,
            "password_confirmation": repeatedPassword
        ]
        return manager.rx.request(.post, url, parameters: params, encoding: JSONEncoding.default).mapToObject()
    }
    
    func connectWithLinkedIn(token: String) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/linkedin-append")
        let params: Parameters? = [
            "linkedin_token": token
        ]
        return manager.rx.request(.post, url, parameters: params, encoding: JSONEncoding.default).mapToObject()
    }
    
    func disconnectWithLinkedIn() -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/linkedin-remove")
        return manager.rx.request(.delete, url, encoding: JSONEncoding.default).mapToObject()
    }
}
