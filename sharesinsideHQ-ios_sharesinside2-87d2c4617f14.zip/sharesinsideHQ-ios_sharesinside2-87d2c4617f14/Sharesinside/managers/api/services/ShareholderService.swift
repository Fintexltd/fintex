//
//  ShareholderService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol ShareholderService {
    func assignAsShareholder(requestModel: ShareholderRequestModel) -> Observable<MessageResponse>
}

extension ApiManager: ShareholderService {
    
    func assignAsShareholder(requestModel: ShareholderRequestModel) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/shareholders")
        let body: Parameters? = requestModel.asDictionary()
        
        return manager.rx.request(.post, url, parameters: body, encoding: URLEncoding.default)
            .mapToObject()
    }
    
}
