//
//  RelationsService.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

protocol RelationsService {
    func fetchRelations(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RelationsResponse>
    func resign(from relation: Relation) -> Observable<MessageResponse>
}

extension ApiManager: RelationsService {
    
    func fetchRelations(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RelationsResponse> {
        let url = ApiManager.apiUrl.appending("/users/relations")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page
        
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
    
    func resign(from relation: Relation) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/users/relations")
        let params: Parameters? = [
            "id": relation.id
        ]
        
        return manager.rx.request(.delete, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }
}
