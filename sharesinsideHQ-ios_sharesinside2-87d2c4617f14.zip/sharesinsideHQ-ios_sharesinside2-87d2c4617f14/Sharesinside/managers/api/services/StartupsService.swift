//
//  StartupsService.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire
import RxAlamofire

protocol StartupsService {
    func fetchStartupDetails(id: Int) -> Observable<StartupAbout>
    func fetchStartups(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<ListResponse<Startup>>
    func fetchEmployeesGroup(startupId: Int) -> Observable<[EmployeesGroup]>
    func fetchHistoricalDataSection(startupId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse>
    func fetchHistoricalDataResponse(startupId: Int) -> Observable<[HistoricalDataSection]>
    func fetchGalleries(startupId: Int) -> Observable<[Album]>
    func followStartup(id: Int) -> Observable<MessageResponse>
    func unfollowStartup(id: Int) -> Observable<MessageResponse>
    func followAllStartups(matching filters: AdvancedFilters) -> Observable<MessageResponse>
}

extension ApiManager: StartupsService {

    func fetchStartupDetails(id: Int) -> Observable<StartupAbout> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)")

        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchStartups(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<ListResponse<Startup>> {
        let url = ApiManager.apiUrl.appending("/startups")
        var params: Parameters? = filters.asDictionary()
        params?["page"] = page

        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchEmployeesGroup(startupId: Int) -> Observable<[EmployeesGroup]> {
        let url = ApiManager.apiUrl.appending("/startups/\(startupId)/employees")
        return manager.rx.request(.get, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func fetchHistoricalDataResponse(startupId: Int) -> Observable<[HistoricalDataSection]> {
        let url = ApiManager.apiUrl.appending("/startups/\(startupId)/documents")
        return manager.rx.request(.get, url, encoding: URLEncoding.default).mapToObject()
    }

    func fetchHistoricalDataSection(startupId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(startupId)/documents/list")
        let params: Parameters? = [
            "id": startupId,
            "section_id": sectionId,
            "page": page
        ]
        return manager.rx.request(.get, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }

    func fetchGalleries(startupId: Int) -> Observable<[Album]> {
        let url = ApiManager.apiUrl.appending("/startups/\(startupId)/galleries")

        return manager.rx.request(.get, url, encoding: JSONEncoding.default).mapToObject()
    }

    func followStartup(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)/follow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func unfollowStartup(id: Int) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/startups/\(id)/unfollow")

        return manager.rx.request(.post, url, encoding: URLEncoding.default)
            .mapToObject()
    }

    func followAllStartups(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        let url = ApiManager.apiUrl.appending("/startups/follow-filters")
        var params: Parameters? = filters.asDictionary()
        params?["type"] = "follow"

        return manager.rx.request(.post, url, parameters: params, encoding: URLEncoding.default).mapToObject()
    }
}
