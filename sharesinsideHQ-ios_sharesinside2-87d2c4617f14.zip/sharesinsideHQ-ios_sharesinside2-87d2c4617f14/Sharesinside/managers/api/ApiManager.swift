//
//  ApiManager.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import RxSwift
import Alamofire

enum ApiResult<T> {
    case success(T)
    case failure(ApiError)
}

class ApiManager {

    #if DEV
    private static let url = "https://api.sharesinside.gegroup.pl/"
    #else
    private static let url = "https://api2.sharesinside.com/"
    #endif
    
    private static let apiPostfix = "api"
    private static let oauthPostfix = "oauth"
    
    static let apiUrl = url.appending(ApiManager.apiPostfix)
    static let oauthUrl = url.appending(ApiManager.oauthPostfix)
    
    let authManager: Alamofire.SessionManager = {
        return SessionManager()
    }()
    
    lazy var manager: Alamofire.SessionManager = {
        let manager = SessionManager()
        let adapter = AuthHandler(withUrl: ApiManager.url,
                                  andApiManager: self)
        manager.adapter = adapter
        manager.retrier = adapter
        return manager
    }()
}
