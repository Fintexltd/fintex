//
//  ApiError.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

enum ApiError: Int, EnumCollection {
    case notAuthorized = 401
}
