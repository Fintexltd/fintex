//
//  CalendarManager.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import EventKit

class CalendarManager {
    
    struct EventData {
        let title: String?
        let date: Date?
        let description: String?
        let address: String?
    }

    private lazy var eventStore = EKEventStore()

    func addToCalendar(event: EventData, completion: @escaping ((Bool, Error?) -> Void)) {
        eventStore.requestAccess(to: .event) { (granted, error) in
            guard granted && error == nil else {
                completion(false, error)
                return
            }

            let calendarEvent: EKEvent = EKEvent(eventStore: self.eventStore)
            calendarEvent.title = event.title
            calendarEvent.startDate = event.date
            calendarEvent.endDate = event.date
            calendarEvent.notes = event.description
            calendarEvent.location = event.address
            calendarEvent.calendar = self.eventStore.defaultCalendarForNewEvents

            do {
                try self.eventStore.save(calendarEvent, span: .thisEvent)
                completion(true, nil)
            } catch {
                completion(false, error)
            }
        }
    }
}
