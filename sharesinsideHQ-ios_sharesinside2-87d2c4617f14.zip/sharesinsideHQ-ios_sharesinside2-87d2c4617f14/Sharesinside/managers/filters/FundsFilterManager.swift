//
//  FundsFilterManager.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/01/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import RxCocoa

final class FundsFilterManager {

    typealias FilterData = (filters: [Filter], selectedFilters: Int)

    static let instance = FundsFilterManager()

    let filtersData = BehaviorRelay<FilterData>(value: ([], 0))

    let refreshRelay = PublishRelay<Void>()

    private(set) lazy var filters = BehaviorRelay(
        value: AdvancedFilters.empty(withSortType: .defaultSortedSeed(seed: generateRandomSeed()))
    )

    let moreDataNeedRelay = PublishRelay<Void>()

    private init() {}

    private func generateRandomSeed() -> Int {
        return Int(arc4random_uniform(9999) + 1)
    }
}
