//
//  Config.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import WebKit

class Config {

    private static let ACCESS_TOKEN_TAG = "accessToken"
    private static let DEMO_ACCOUNT_TAG = "isDemoAccount"
    private static let REFRESH_TOKEN_TAG = "refreshToken"
    private static let APNS_TOKEN_KEY = "com.kissdigital.Sharesinside.APNSToken"
    private static let NOTIFICATIONS_ACCEPTANCE = "com.sharesinside.ios2.norifications_acceptance"
    private static let NOTIFICATIONS_BADGE_COUNT = "com.sharesinside.ios2.norifications_badge_count"
    private static let LINKEDIN_API_KEY = "linkedinApiKey"
    private static let LINKEDIN_API_SECRET = "linkedinApiSecret"
    private static let LINKEDIN_REDIRECT_URL = "linkedinRedirectUrl"
    private static let LINKEDIN_READ_SCOPE = "linkedinReadScope"
    private static let WATCHLIST_NOTIFICATIONS_COUNT = "watchlistNotificationsCount"

    class func logout() {
        accessToken = ""
        isDemoAccount = false
        AppUser.current = nil
        WKWebView.flushCookies()
    }

    class var accessToken: String {
        set {
            UserDefaults.standard.set(newValue, forKey: ACCESS_TOKEN_TAG)
        }
        get {
            return UserDefaults.standard.string(forKey: ACCESS_TOKEN_TAG) ?? ""
        }
    }

    class var refreshToken: String {
        set {
            UserDefaults.standard.set(newValue, forKey: REFRESH_TOKEN_TAG)
        }
        get {
            return UserDefaults.standard.string(forKey: REFRESH_TOKEN_TAG) ?? ""
        }
    }

    class var isDemoAccount: Bool {
        set {
            UserDefaults.standard.set(newValue, forKey: DEMO_ACCOUNT_TAG)
        }
        get {
            return UserDefaults.standard.bool(forKey: DEMO_ACCOUNT_TAG)
        }
    }

    class var APNSToken: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: APNS_TOKEN_KEY)
        }
        get {
            return UserDefaults.standard.string(forKey: APNS_TOKEN_KEY)
        }
    }
    
    class var newPublicationsCount: Int {
        set {
            UserDefaults.standard.set(newValue, forKey: WATCHLIST_NOTIFICATIONS_COUNT)
        }
        get {
            return UserDefaults.standard.integer(forKey: WATCHLIST_NOTIFICATIONS_COUNT)
        }
    }

    class var linkedinParams: Params? {
        set {
            UserDefaults.standard.set(newValue?.apiKey, forKey: LINKEDIN_API_KEY)
            UserDefaults.standard.set(newValue?.apiSecret, forKey: LINKEDIN_API_SECRET)
            UserDefaults.standard.set(newValue?.redirectUrl, forKey: LINKEDIN_REDIRECT_URL)
            UserDefaults.standard.set(newValue?.readScope, forKey: LINKEDIN_READ_SCOPE)
        }
        get {
            guard let apiKey = UserDefaults.standard.string(forKey: LINKEDIN_API_KEY),
                let apiSecret = UserDefaults.standard.string(forKey: LINKEDIN_API_SECRET),
                let redirectUrl = UserDefaults.standard.string(forKey: LINKEDIN_REDIRECT_URL),
                let readScope = UserDefaults.standard.string(forKey: LINKEDIN_READ_SCOPE) else {
                    return nil
            }

            return Params(apiKey: apiKey, apiSecret: apiSecret, redirectUrl: redirectUrl, readScope: readScope)
        }
    }
    
    // MARK: - Notifications settings
    enum Notifications {

        static var areAllowed: Bool {
            set { UserDefaults.standard.set(newValue, forKey: NOTIFICATIONS_ACCEPTANCE) }
            get { return UserDefaults.standard.bool(forKey: NOTIFICATIONS_ACCEPTANCE) }
        }

        enum FollowedCompanies {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.companies.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.companies.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }

        enum Funds {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.funds.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.funds.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }

        enum Shareholders {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.shareholders.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.shareholders.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }

        enum FundInvestors {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.investors.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.investors.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }

        enum StartupInvestors {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.startup_investors.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.startup_investors.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }

        enum Startups {
            static let ARE_EVENTS_ON = "com.sharesinside.ios2.notifications.startups.areEventsOn"
            static let ARE_NEWS_ON = "com.sharesinside.ios2.notifications.startups.areNewsOn"

            static var areEventsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_EVENTS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_EVENTS_ON) }
            }
            static var areNewsOn: Bool {
                set { UserDefaults.standard.set(newValue, forKey: ARE_NEWS_ON) }
                get { return UserDefaults.standard.bool(forKey: ARE_NEWS_ON) }
            }
        }
    }
}

extension Config {

    class var notificationSettings: NotificationSettingsModel {
        get {
            return NotificationSettingsModel(
                allowPush: Notifications.areAllowed,
                followingEvents: Notifications.FollowedCompanies.areEventsOn,
                followingNews: Notifications.FollowedCompanies.areNewsOn,
                shareholderEvents: Notifications.Shareholders.areEventsOn,
                shareholderNews: Notifications.Shareholders.areNewsOn,
                investorFundEvents: Notifications.FundInvestors.areEventsOn,
                investorFundNews: Notifications.FundInvestors.areNewsOn,
                fundEvents: Notifications.Funds.areEventsOn,
                fundNews: Notifications.Funds.areNewsOn,
                startupEvents: Notifications.Startups.areEventsOn,
                startupNews: Notifications.Startups.areNewsOn,
                investorStartupEvents: Notifications.StartupInvestors.areEventsOn,
                investorStartupNews: Notifications.StartupInvestors.areNewsOn
            )
        }
        set {
            Notifications.areAllowed = newValue.allowPush
            Notifications.FollowedCompanies.areEventsOn = newValue.followingEvents
            Notifications.FollowedCompanies.areNewsOn = newValue.followingNews
            Notifications.Funds.areEventsOn = newValue.fundEvents
            Notifications.Funds.areNewsOn = newValue.fundNews
            Notifications.Shareholders.areEventsOn = newValue.shareholderEvents
            Notifications.Shareholders.areNewsOn = newValue.shareholderNews
            Notifications.FundInvestors.areEventsOn = newValue.investorFundEvents
            Notifications.FundInvestors.areNewsOn = newValue.investorFundNews
            Notifications.Startups.areEventsOn = newValue.startupEvents
            Notifications.Startups.areNewsOn = newValue.startupNews
            Notifications.StartupInvestors.areEventsOn = newValue.investorStartupEvents
            Notifications.StartupInvestors.areNewsOn = newValue.investorStartupNews
        }
    }
}
