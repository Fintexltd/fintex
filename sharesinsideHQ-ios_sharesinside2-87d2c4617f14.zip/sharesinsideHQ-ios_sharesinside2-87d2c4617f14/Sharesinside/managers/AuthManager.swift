//
//  AuthManager.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class AuthManager {

    private let apiManager: AuthApiService

    init(apiManager: AuthApiService) {
        self.apiManager = apiManager
    }

    func signUpUser(name: String, email: String, password: String, passwordConfiramtion: String, countryId: Int, acceptTerms: Bool) -> Observable<RegisterResponse> {
        return apiManager.register(name: name,
            email: email,
            password: password,
            passwordConfirmation: password,
            linkedinRegister: nil,
            countryId: countryId,
            acceptTerms: acceptTerms).observeOn(MainScheduler.instance)
    }

    func signUpUserWithLinkedin(name: String, email: String, countryId: Int, registrationKey: String, acceptTerms: Bool) -> Observable<RegisterResponse> {
        return apiManager.register(name: name,
            email: email,
            password: nil,
            passwordConfirmation: nil,
            linkedinRegister: registrationKey,
            countryId: countryId,
            acceptTerms: acceptTerms).observeOn(MainScheduler.instance)
    }

    func logInUser(username: String, password: String) -> Observable<AuthData> {
        return apiManager.login(withUsername: username, password: password)
            .observeOn(MainScheduler.instance)
            .do(onNext: { authData in
                Config.accessToken = authData.accessToken
                Config.refreshToken = authData.refreshToken ?? ""
                AppUser.fetchCurrentUserDetails()
            }).observeOn(MainScheduler.instance)
    }

    func linkedInAuth(with authorizationCode: String, andParams params: Params) -> Observable<AuthLinkedinResponse> {
        return apiManager.linkedInAuth(withAuthorizationCode: authorizationCode, andParams: params)
            .flatMap { return self.apiManager.apiLinkedInAuth(withLinkedInAccessToken: $0.accessToken) }
            .do(onNext: { authLinkedinResponse in
                Config.accessToken = authLinkedinResponse.authData?.accessToken ?? ""
            })
            .observeOn(MainScheduler.instance)
    }
    
    func linkedInConnect(with authorizationCode: String, andParams params: Params) -> Observable<LinkedInAuthData> {
        return apiManager.linkedInAuth(withAuthorizationCode: authorizationCode, andParams: params)
    }
    
    func resetPassword(for email: String) -> Observable<MessageResponse> {
        return apiManager.resetPassword(for: email).observeOn(MainScheduler.instance)
    }
    
    func loginAsDemo() -> Observable<AuthData> {
        return apiManager.loginAsDemo().do(onNext: { authData in
            Config.isDemoAccount = true
            Config.accessToken = authData.accessToken
            AppUser.fetchCurrentUserDetails()
        }).observeOn(MainScheduler.instance)
    }
}
