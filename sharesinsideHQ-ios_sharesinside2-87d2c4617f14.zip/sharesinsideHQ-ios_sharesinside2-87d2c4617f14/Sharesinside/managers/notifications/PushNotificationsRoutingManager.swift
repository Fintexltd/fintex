//
//  PushNotificationsRouter.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 12/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import UserNotifications
import RxSwift

protocol PushNotificationsRoutingLogic {
    func navigate(with notification: PushNotification, forced: Bool)
}

class PushNotificationsRoutingManager: PushNotificationsRoutingLogic {
    
    let disposeBag = DisposeBag()
    
    weak var viewController: UIViewController?
    
    var visibleViewController: UIViewController? {
        return UIApplication.shared.visibleViewController
    }
    
    init(controller: UIViewController) {
        self.viewController = controller
    }
    
    func navigate(with notification: PushNotification, forced: Bool) {
        guard !forced else {
            route(with: notification, forced: forced)
            return
        }
        informBeforeRouting(with: notification) {
            self.route(with: notification, forced: forced)
        }
    }
    
    private func informBeforeRouting(with notification: PushNotification, callback: @escaping (() -> Void)) {
        if let type = notification.type {
            if type == .event || type == .news { Config.newPublicationsCount += 1 }
            MainFlowRxBus.notificationReceivedPublishRelay.accept(type)
        }
        
        guard let uiViewController = UIApplication.shared.visibleViewController,
            let viewController = uiViewController as? ViewController, notification.isValid else { return }
        
        viewController.alert.showDefault(in: uiViewController, withData: AlertData(
            message: notification.message?.body,
            title: notification.message?.title,
            positiveButtonTitle: Localizable.ok,
            cancelButtonTitle: Localizable.cancel,
            onPositiveTap: { callback() }))
    }
}

extension PushNotificationsRoutingManager {
    
    func route(with notification: PushNotification, forced: Bool) {
        if notification.type?.associatedViewControllerClass == visibleViewController?.classForCoder,
            let reinitilizableViewController = visibleViewController as? ReinitializableViewController,
            let id = notification.id {
            reinitilizableViewController.reinitializeView(with: id)
            return
        }
        
        guard let routeType = notification.presentationType else { return }
        initializeRouter { [weak self] router in
            switch routeType {
            case .present: router?.present(with: notification, forced: forced)
            case .push: router?.push(with: notification, forced: forced)
            case .select(let screen):
                (self?.viewController as? MainTabBarController)?.selectScreen(screen)
                router?.dismissNavigationController(animated: true)
            }
        }
    }
    
    private func initializeRouter(completion: @escaping ((NotificationRouter?) -> Void)) {
        guard
            let mainTabBarController = viewController as? MainTabBarController,
            let viewController = ((mainTabBarController.selectedViewController as? UINavigationController)?.topViewController as? ViewController)?.topViewController
        else { return }
        
        viewController.hasLoadedView
            .subscribe(onNext: {_ in completion(viewController.router)})
            .disposed(by: disposeBag)
    }
}
