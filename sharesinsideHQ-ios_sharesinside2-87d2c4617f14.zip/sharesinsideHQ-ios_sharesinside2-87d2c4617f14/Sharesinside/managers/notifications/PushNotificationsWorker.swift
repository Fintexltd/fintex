//
//  PushNotificationsWorker.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 12/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit
import UserNotifications

class PushNotificationsWorker: HasProfileManager {
    
    unowned var appDelegate: AppDelegate
    private var routingManager: PushNotificationsRoutingLogic?
    var profileManager: ProfileRepository
    
    init(delegate: AppDelegate) {
        self.appDelegate = delegate
        self.profileManager = ProfileRepository(remote: ProfileRemoteRepo(apiManager: ApiManager()))
        self.routingManager = PushNotificationsRoutingManager(controller: appDelegate.window!.rootViewController!)
    }
    
    class func pushNotification(basedOn launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> PushNotification? {
        return buildNotification(using: launchOptions?[.remoteNotification])
    }
    
    class func pushNotification(basedOn launchOptions: [AnyHashable: Any]?) -> PushNotification? {
        return buildNotification(using: launchOptions)
    }
    
    class func buildNotification(using pushContainer: Any?) -> PushNotification? {
        if let pushContainer = pushContainer as? [String: Any], let aps = pushContainer["aps"] as? [String: Any], let notification = PushNotification.make(using: aps) {
            return notification
        }
        return nil
    }
    
    class func registerForPushNotifications() {
        guard Config.Notifications.areAllowed else { return }
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, _) in
            guard granted else { return }
            DispatchQueue.main.async {
                UIApplication.shared.registerForRemoteNotifications()
            }
        }
    }
    
    class func unregisterFromPushNotifications() {
        UIApplication.shared.unregisterForRemoteNotifications()
    }
    
    class func checkNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { _ in
            registerForPushNotifications()
        }
    }
    
    class func resetAppBadgeCount() {
        UIApplication.shared.applicationIconBadgeNumber = 0
    }
    
    class func notificationsAuthorizationStatus(completion: @escaping (UNAuthorizationStatus) -> Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            completion(settings.authorizationStatus)
        }
    }
    
    func handle(_ notification: PushNotification, forced: Bool, completion: ((UIBackgroundFetchResult) -> Void)? = nil) {                
        routingManager?.navigate(with: notification, forced: forced)
    }
    
    func handle(_ apnsToken: Data) {
        let tokenParts = apnsToken.map { data -> String in
            return String(format: "%02.2hhx", data)
        }
        let token = tokenParts.joined()
        Config.APNSToken = token
        profileManager.registerPushNotificationsInSIServer()
        print("Device Push Notifications Token: \(token)")
    }
    
}
