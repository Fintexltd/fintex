//
//  AppDelegate.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 04.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit
import Crashlytics
import Fabric
import IQKeyboardManagerSwift
import GoogleMaps
import RxSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    let disposeBag = DisposeBag()

    let applicationDependencies = AppDependenciesModule()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        setupApp()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) { }

    func applicationDidEnterBackground(_ application: UIApplication) { }

    func applicationWillEnterForeground(_ application: UIApplication) { }

    func applicationDidBecomeActive(_ application: UIApplication) {
        PushNotificationsWorker.resetAppBadgeCount()
    }

    func applicationWillTerminate(_ application: UIApplication) {
        logoutIfDemo()
    }
}

extension AppDelegate {

    fileprivate func setupApp() {
        setupCrashltics()
        setupIQKeyboardManager()
        setupWindow()
        setupGoogleMaps()
        setupParams()
    }

    private func setupCrashltics() {
        #if !DEBUG
            Fabric.with([Crashlytics.self])
        #endif
    }

    private func setupIQKeyboardManager() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        IQKeyboardManager.shared.keyboardDistanceFromTextField = 70
        IQKeyboardManager.shared.toolbarTintColor = .primaryDark        
    }
    
    private func setupWindow() {
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.backgroundColor = .primaryDark
        
        let initialController: UIViewController
        if Config.accessToken.isEmpty {
            initialController = BaseNavigationController(rootViewController: WelcomeViewController())
        } else {
            initialController = MainTabBarController()
            initializeUser()
        }
        
        window?.rootViewController = initialController
        window?.makeKeyAndVisible()
        if #available(iOS 13.0, *) {
            window?.overrideUserInterfaceStyle = .light
        }
    }
    
    private func setupGoogleMaps() {
        GMSServices.provideAPIKey("AIzaSyCAOam2vSjGNMoe1DvWdIRcp7t0zQYYTlI")
    }
    
    private func setupParams() {
        applicationDependencies.paramsRepository
            .getParams(forceRefresh: true)
            .subscribe(onNext: { params in
                Config.linkedinParams = params
            }, onError: { error in
                printDebug(error)
            }).disposed(by: disposeBag)
    }
}

extension AppDelegate {

    func userUnauthorized() {
        if (window?.rootViewController as? UINavigationController)?.topViewController?.isAuthentication == false || (window?.rootViewController as? UITabBarController)?.isAuthentication == false {
            UIApplication.shared.logoutUser()
        }
    }
    
    private func isAuthenticationControllerPresent() -> Bool {
        let viewController = (window?.rootViewController as? UINavigationController)?.topViewController
        return viewController is AuthViewController == true || viewController is LinkedInAuthViewController == true
    }
    
    private func initializeUser() {
        AppUser.fetchCurrentUserDetails()
    }
}

// MARK: Push Notifications methods
extension AppDelegate {
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        if let notification = PushNotificationsWorker.pushNotification(basedOn: userInfo) {
            let forceRouting = application.applicationState == .inactive
            PushNotificationsWorker(delegate: self).handle(notification, forced: forceRouting, completion: completionHandler)
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        PushNotificationsWorker(delegate: self).handle(deviceToken)
    }
    
    func application(_ application: UIApplication,
                     didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Failed to register Push Notifications: \(error)")
    }
}

extension AppDelegate {
    private func logoutIfDemo() {
        if Config.isDemoAccount {
            Config.logout()
        }
    }
}
