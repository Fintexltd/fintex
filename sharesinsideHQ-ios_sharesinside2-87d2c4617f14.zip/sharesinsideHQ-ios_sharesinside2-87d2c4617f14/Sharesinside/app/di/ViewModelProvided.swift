//
//  ViewModelInjector.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

struct ViewModelProvider {
    
    static func provide<ViewModelType>(for type: ViewModelType.Type, withApp app: AppDelegate) -> ViewModelType where ViewModelType: ViewModel {
        let dependencies = app.applicationDependencies
        
        let viewModel = type.init()
        if let dependencies = dependencies as? ViewModelType.Dependencies {
            viewModel.dependencies = dependencies
        } else {
            preconditionFailure("AppDependencies do not implements one of view model dependencies")
        }
        
        return viewModel
    }
}
