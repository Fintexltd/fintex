//
//  Dependencies.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

protocol HasCountriesRepository {
    var countriesRepository: CountriesRepository { get }
}

protocol HasAuthManager {
    var authManager: AuthManager { get }
}

protocol HasCompaniesRepository {
    var companiesRepository: CompaniesRepository { get }
}

protocol HasStartupsRepository {
    var startupsRepository: StartupsRepository { get }
}

protocol HasFundsRepository {
    var fundsRepository: FundsRepository { get }
}

protocol HasFundManagersRepository {
    var fundManagersRepository: FundManagersRepository { get }
}

protocol HasFiltersRepository {
    var filtersRepository: FiltersRepository { get }
}

protocol HasWatchlistRepository {
    var watchlistRepository: WatchlistRepository { get }
}

protocol HasEventsDisplayDateTypeRepository {
    var eventsDisplayDateTypeRepository: EventsDisplayDateTypeRepository { get }
}

protocol HasEventsRepository {
    var eventsRepository: EventsRepository { get }
}

protocol HasCalendarManager {
    var calendarManager: CalendarManager { get }
}

protocol HasProfileManager {
    var profileManager: ProfileRepository { get }
}

protocol HasDocumentsService {
    var documentsService: DocumentsService { get }
}

protocol HasParamsRepository {
    var paramsRepository: ParamsRepository { get }
}

protocol HasNotificationsRepository {
    var notificationsRepository: NotificationsRepository { get }
}

protocol HasRelationsRepository {
    var relationsRepository: RelationsRepository { get }
}

protocol HasRequestsRepository {
    var requestsRepository: RequestsRepository { get }
}
