//
//  AppDependency.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

internal protocol AppDependencies: HasCountriesRepository, HasAuthManager, HasCompaniesRepository, HasFundManagersRepository,
    HasFiltersRepository, HasWatchlistRepository, HasEventsRepository, HasCalendarManager, HasProfileManager,
    HasNotificationsRepository, HasDocumentsService, HasParamsRepository, HasRelationsRepository, HasRequestsRepository, HasFundsRepository, HasStartupsRepository, HasEventsDisplayDateTypeRepository { }

internal class AppDependenciesModule: AppDependencies {
    
    lazy var authManager: AuthManager = AuthManager(apiManager: apiManager)
    
    lazy var countriesRepository = CountriesRepository(remote: remoteCountriesRepo)
    
    lazy var companiesRepository = CompaniesRepository(remote: remoteCompaniesRepo)

    lazy var fundManagersRepository = FundManagersRepository(remote: remoteFundManagersRepo)

    lazy var fundsRepository = FundsRepository(remote: remoteFundsRepo)

    lazy var startupsRepository = StartupsRepository(remote: remoteStartupsRepo)
    
    lazy var filtersRepository = FiltersRepository(remote: remoteFiltersRepo, local: localFiltersRepo)

    lazy var eventsDisplayDateTypeRepository: EventsDisplayDateTypeRepository = UserDefaultsEventsDisplayDateTypeRepository.shared
    
    lazy var eventsRepository = EventsRepository(remote: remoteEventsRepo)
    
    lazy var watchlistRepository = WatchlistRepository(remote: remoteWatchlistRepo)
    
    lazy var calendarManager = CalendarManager()

    lazy var profileManager = ProfileRepository(remote: remoteProfileRepo)
    
    lazy var documentsService: DocumentsService = apiManager
    
    lazy var paramsRepository = ParamsRepository(remote: remoteParamsRepo, local: localParamsRepo)
    
    lazy var notificationsRepository = NotificationsRepository(remote: remoteNotificationsRepository)
    
    lazy var relationsRepository = RelationsRepository(remote: remoteRelationsRepository)
    
    lazy var requestsRepository = RequestsRepository(remote: remoteRequestsRepository)
    
    // MARK: Private variables
    private lazy var remoteCountriesRepo = CountriesRemoteRepo(apiManager: apiManager)
    
    private lazy var remoteCompaniesRepo = CompaniesRemoteRepo(apiManager: apiManager)

    private lazy var remoteFundManagersRepo = FundManagersRemoteRepo(apiManager: apiManager)

    private lazy var remoteFundsRepo = FundsRemoteRepo(apiManager: apiManager)

    private lazy var remoteStartupsRepo = StartupsRemoteRepo(apiManager: apiManager)
    
    private lazy var remoteFiltersRepo = FiltersRemoteRepo(apiManager: apiManager)

    private lazy var remoteProfileRepo = ProfileRemoteRepo(apiManager: apiManager)
    
    private lazy var localFiltersRepo = FiltersLocalRepo()
    
    private lazy var remoteWatchlistRepo = WatchlistRemoteRepo(watchlistService: apiManager)

    private lazy var remoteEventsRepo = EventsRemoteRepo(eventsService: apiManager)
    
    private lazy var remoteParamsRepo = ParamsRemoteRepo(apiManager: apiManager)
    
    private lazy var localParamsRepo = ParamsLocalRepo()
    
    private lazy var remoteNotificationsRepository = NotificationsRemoteRepository(notificationsService: apiManager)

    private lazy var remoteRelationsRepository = RelationsRemoteRepository(relationsService: apiManager)

    private lazy var remoteRequestsRepository = RequestsRemoteRepository(requestsService: apiManager)
    
    private lazy var apiManager = ApiManager()
}
