//
//  FundDetailsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class FundDetailsViewModel: BaseViewModel<HasFundsRepository & HasFundManagersRepository> {

    var fundId: Int?
    let fundData = BehaviorRelay<(FundAbout, FundManagerAbout)?>(value: nil)
    let followingStateChangeAction = PublishRelay<FollowingState>()

    lazy var fundsRepository = dependencies.fundsRepository
    lazy var fundManagersRepository = dependencies.fundManagersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        getFundAboutData()
    }

    func reloadData(forFundWithId id: Int) {
        fundId = id
        getFundAboutData()
    }

    private func getFundAboutData() {
        guard let fundId = fundId else {
            alert.accept(AlertData(message: Localizable.fundDetailsFetchError.localized,
                                   onPositiveTap: { self.router?.pop() }))
            return
        }
        fundsRepository.getFundsAbout(fundId: fundId)
            .flatMapLatest { [unowned self] fundAbout in
                return self.fundManagersRepository.getFundManagerAbout(fundManagerId: fundAbout.fundManagerId).map { fundManagerAbout in
                    return (fundAbout, fundManagerAbout)
                }
            }
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] fundAbout in
                    self?.fundData.accept(fundAbout) },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent) })
            .disposed(by: disposeBag)
    }

    func show(historicalDataSection: HistoricalDataSection) {
        guard let fundId = fundId else { return }
        router?.push(to: .historicalDataSection(legalEntity: .fund(fundId),
                                                sectionId: historicalDataSection.id,
                                                sectionTitle: historicalDataSection.name))
    }

    func show(publication: Publication) {
        switch publication.type {
        case .event: router?.push(to: .eventDetails(eventId: publication.watchlistableId))
        case .news: router?.push(to: .newsDetails(newsId: publication.watchlistableId))
        case .project: router?.push(to: .projectDetails(projectId: publication.watchlistableId))
        }
    }

    func didSelect(fundManagerId: Int) {
        router?.push(to: .fundManagerDetails(fundManagerId: fundManagerId))
    }

    func assignAsInvestor(delegate: AssignAsInvestorViewControllerDelegate?) {
        guard let fundAbout = fundData.value else { return }
        router?.present(destination: .assignAsInvestor(investmentType: .fund(fundAbout.0), delegate: delegate))
    }
}

extension FundDetailsViewModel {

    func toogleFundFollowingState() {
        guard let fund = fundData.value else { return }
        fundsRepository.toggleFollowing(ofFundWithId: fund.0.id, follow: fund.0.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(
                onSubscribe: { self.changeFundFollowState(.changing, forFund: fund.0) })
            .subscribe(
                onNext: { [weak self] _ in
                    self?.changeFundFollowState(
                        fund.0.following == .following ? .notFollowing : .following, forFund: fund.0 ) },
                onError: { [weak self] error in
                    self?.changeFundFollowState(fund.0.following ?? .notFollowing, forFund: fund.0)
                    self?.alert.accept(AlertData(message: error.localizedDescription))})
            .disposed(by: disposeBag)
    }

    private func changeFundFollowState(_ state: FollowingState, forFund fund: FundAbout) {
        let updatedFund = fund.with(followingState: state)
        followingStateChangeAction.accept(state)
        let fundManager = fundData.value!.1
        fundData.accept((updatedFund, fundManager))
    }
}
