//
//  FundAboutView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit

protocol FundAboutDelegate: AddressButtonDelegate, SocialMediaButtonDelegate, AttachmentsViewDelegate { }

class FundAboutView: BaseViewCreator {

    weak var delegate: FundAboutDelegate?

    private let dividerTag = 1

    // MARK: Video view
    let videoView: NewsVideoView = {
        let view = NewsVideoView()
        return view
    }()

    lazy var addressStackView: UIStackView = .make(
        axis: AppInfo.isIPad ? .horizontal : .vertical,
        with: [],
        spacing: AppInfo.isIPad ? Defaults.marginNormal : 0,
        distribution: .fill)

    lazy var addressScrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false
        return scrollView
    }()

    lazy var sharepriceCollectionView: SharepriceCollectionView = {
        let collectionView = UICollectionView.makeCustomCollectionView(
            type: SharepriceCollectionView.self,
            scrollDirection: AppInfo.isIPad ? .horizontal : .vertical)
        collectionView.isScrollEnabled = AppInfo.isIPad
        collectionView.isCompact = AppInfo.isIPhone
        collectionView.alwaysBounceVertical = false
        return collectionView
    }()

    lazy var descriptionTitleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark, withFontSize: Defaults.TextSize.big, fontWeight: .bold)
        label.textAlignment = .left
        return label
    }()

    lazy var descriptionContentLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.medium, fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()

    lazy var descriptionView = UIView().layoutable()

    lazy var socialMediaStackView: UIStackView = .make(
        axis: .horizontal,
        with: [],
        spacing: Defaults.FundDetails.socialMediaMargin,
        alignment: .center,
        distribution: .equalSpacing)

    lazy var socialMediaView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .background
        return view
    }()

    lazy var attachmentsView: AttachmentsView = {
        let view = AttachmentsView()
        view.delegate = self
        return view
    }()

    lazy var linksView: AttachmentsView = {
        let view = AttachmentsView()
        view.delegate = self
        return view
    }()

    var horizontalDivider: UIView {
        let view = UIView.horizontalDivider
        view.tag = dividerTag
        return view
    }

    lazy var contentView = UIStackView.make(axis: .vertical, with: [])

    // MARK: Scroll View
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.decelerationRate = .fast
        scrollView.alwaysBounceVertical = true
        return scrollView
    }()

    override func setupViewHierarchy() {
        addressScrollView.addSubview(addressStackView)
        socialMediaView.addSubview(socialMediaStackView)
        [descriptionTitleLabel, descriptionContentLabel].forEach { descriptionView.addSubview($0) }
        scrollView.addSubview(contentView)
        parentView.addSubview(scrollView)
    }

    override func setupConstraints() {

        setupAddressConstraints()
        setupSharepriceConstraints()
        setupDescriptionConstraints()
        setupSocialMediaConstraints()

        scrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.height.equalToSuperview()
        }
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
    }

    private func setupSharepriceConstraints() {
        sharepriceCollectionView.snp.makeConstraints { make in
            let footerHeight: CGFloat = AppInfo.isIPhone ? Defaults.seeMooreFooterHeight : 0
            make.height.equalTo(Defaults.Shareprice.cellHeight + footerHeight)
        }
    }

    private func setupAddressConstraints() {
        addressScrollView.snp.makeConstraints { make in
            make.height.equalTo(addressStackView.snp.height)
            if AppInfo.isIPhone { make.width.equalTo(addressStackView.snp.width) }
        }
        addressStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    private func setupDescriptionConstraints() {
        descriptionTitleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(Defaults.marginBig)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginSmall)
        }
        descriptionContentLabel.snp.makeConstraints { make in
            make.top.equalTo(descriptionTitleLabel.snp.bottom).offset(Defaults.marginSmall)
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
    }

    private func setupSocialMediaConstraints() {

        socialMediaView.snp.makeConstraints { make in
            make.height.equalTo(socialMediaStackView.snp.height)
        }
        socialMediaStackView.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
    }

    private func setupVideoConstraints() {
        videoView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.width.equalTo(videoView.snp.height).multipliedBy(2).priority(.highest)
        }
    }

}

extension FundAboutView {

    func configure(with fund: FundAbout) {
        cleanContentView()
        configureHeaderView(with: fund)
        configureSharepriceView(with: fund)
        configureDescriptionView(with: fund)
        configureSocialMediaView(with: fund)
        configureVideoView(with: fund)
        configureAttachmentsView(with: fund)
        configureLinksView(with: fund)
    }

    private func cleanContentView() {
        addressStackView.removeAllArrangedSubviews()
        socialMediaStackView.removeAllArrangedSubviews()
        attachmentsView.removeAllItems()
        linksView.removeAllItems()
        contentView.arrangedSubviews.forEach {
            if $0.tag == dividerTag { contentView.removeArrangedSubview($0) }
        }
    }

    private func configureHeaderView(with fund: FundAbout) {
        addHeaderView(
            title: Localizable.fundHeaderManagementFee.localized,
            text: "\(fund.managementFee ?? "")%"
        )

        addHeaderView(
            title: Localizable.fundHeaderPerformanceFee.localized,
            text: "\(fund.performanceFee ?? "")%"
        )

        addHeaderView(
            title: Localizable.fundHeaderDuration.localized,
            text: "\(fund.duration ?? 0) \(fund.duration == 1 ? Localizable.year : Localizable.years), \(fund.openClosed?.capitalized ?? "")"
        )

        addHeaderView(
            title: Localizable.fundHeaderTradingFrequency.localized,
            text: fund.tradingFrequency?.title ?? ""
        )

        addHeaderView(
            title: Localizable.fundHeaderCurrency.localized,
            text: "\(fund.currency?.symbol ?? "")"
        )

        addHeaderView(
            title: Localizable.fundHeaderAssetClass.localized,
            text: "\(fund.fundTypes.first?.name ?? "")"
        )

        if let lastCell = addressStackView.arrangedSubviews.last as? AddressButton {
            lastCell.hasDivider = false
        }
        addToContentView(addressScrollView)
    }

    private func configureSharepriceView(with fund: FundAbout) {
        let validatedShareprices = fund.symbols.validSymbols.filter { $0.ohlc?.isValid == true }
        guard !validatedShareprices.isEmpty else { return }

        sharepriceCollectionView.shareprices = validatedShareprices
        addToContentView(sharepriceCollectionView)
    }

    private func addHeaderView(title: String, text: String) {
        guard !text.isEmpty else {
            return
        }
        let headerView = TitledLabelView()
        headerView.text = text
        headerView.title = title
        addressStackView.addArrangedSubview(headerView)
    }

    private func configureDescriptionView(with fund: FundAbout) {
        guard fund.title != nil || fund.description != nil else { return }

        descriptionTitleLabel.attributedText = fund.title?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.big)
        descriptionContentLabel.attributedText = fund.description?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.medium)
        addToContentView(descriptionView)
    }

    private func configureSocialMediaView(with fund: FundAbout) {
        guard !fund.socialMedia.isEmpty else { return }
        fund.socialMedia
            .compactMap { makeSocialMediaButton(for: $0) }
            .forEach { socialMediaStackView.addArrangedSubview($0) }
        socialMediaView.layoutIfNeeded()
        addToContentView(socialMediaView)
    }

    private func configureVideoView(with fund: FundAbout) {
        guard let videoData = fund.videoData else {
            return
        }

        videoView.videoData = videoData
        addToContentView(videoView.embedInView())
        setupVideoConstraints()
    }

    private func configureAttachmentsView(with fund: FundAbout) {
        guard !fund.attachments.isEmpty else { return }
        attachmentsView.configure(with: fund.attachments, title: "\(Localizable.attachments.localized) (\(fund.attachments.count))")
        addToContentView(attachmentsView)
    }

    private func configureLinksView(with fund: FundAbout) {
        guard !fund.links.isEmpty else { return }
        linksView.configure(with: fund.links, title: "\(Localizable.links.localized) (\(fund.links.count))")
        addToContentView(linksView)
    }

    private func addToContentView(_ view: UIView) {
        contentView.addArrangedSubview(view)
        contentView.addArrangedSubview(horizontalDivider)
    }
}

extension FundAboutView {

    private func makeSocialMediaButton(for socialMedia: SocialMedia) -> UIButton? {
        let button = SocialMediaButton()
        button.socialMedia = socialMedia
        button.addTarget(self, action: #selector(socialMediaButtonDidTouch(_:)), for: .touchUpInside)
        return button
    }
}

extension FundAboutView: AttachmentsViewDelegate {
    func attachmentButtonDidTouch(button: AttachmentButton) {
        delegate?.attachmentButtonDidTouch(button: button)
    }

    @objc func addressButtonDidTouch(_ button: AddressButton) {
        delegate?.didTouchAddress(button: button)
    }

    @objc func socialMediaButtonDidTouch(_ button: SocialMediaButton) {
        delegate?.didTouchSocialMedia(button: button)
    }
}
