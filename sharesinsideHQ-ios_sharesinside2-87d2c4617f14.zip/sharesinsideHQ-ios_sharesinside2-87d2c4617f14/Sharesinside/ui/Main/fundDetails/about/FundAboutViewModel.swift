//
//  FundAboutViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class FundAboutViewModel: BaseViewModel<HasFundsRepository> {

    let fundAboutData = BehaviorRelay<FundAbout?>(value: nil)

}
