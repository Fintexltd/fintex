//
//  FundDetailsFragment.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher
import TTTAttributedLabel

class FundDetailsViewController: BaseViewController<FundDetailsViewModel>, UIScrollViewDelegate, UINavigationControllerDelegate {

    private lazy var viewCreator = FundDetailsView(parentView: self.view, pagedViewControllers: pagedViewControllers)

    private var pagerLayoutNeedsReload = false
    private var pagerDataNeedsReload = true
    private var isAnimating = false
    private var isMenuShown = true

    private var childScrollView: UIScrollView!

    var fundId: Int

    lazy var pagedViewControllers: [UIViewController] = {
        return [UIViewController()]
    }()

    init(fundId: Int) {
        self.fundId = fundId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
    }

    override func setupView() {
        self.view.backgroundColor = .primaryDark
        viewCreator.setupView()
        automaticallyAdjustsScrollViewInsets = false
        viewCreator.fundTitle.delegate = self
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        viewCreator.updatePagedViewHeight(withNavigationBarHeight:
            (navigationController?.navigationBar.frame.height ?? 0) + Defaults.marginSmall)
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pagerLayoutNeedsReload = true
        viewCreator.pagerView.viewControllers[viewCreator.pagerView.currentSelectedPage].viewWillTransition(to: size, with: coordinator)
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.fundId = fundId
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.scrollView.delegate = self
        viewCreator.pagerView.delegate = self
        navigationController?.delegate = self
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.clear]
        viewCreator.followButton.addTarget(self, action: #selector(toogleFollowing), for: .touchUpInside)
        viewCreator.assignAsShareholderButton.addTarget(self, action: #selector(assignAsInvestor), for: .touchUpInside)
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.fundData
            .ignoreNil()
            .subscribe(onNext: { [weak self] fundAbout in
                guard let self = self else { return }
                self.configureHeader(with: fundAbout.0, fundManager: fundAbout.1)
                if self.pagerDataNeedsReload {
                    self.initializePages(from: fundAbout.0.availableInformations)
                    self.updateFundAboutViewController(with: fundAbout.0)
                    self.pagerDataNeedsReload = false
                }
            }).disposed(by: disposeBag)

        viewModel.followingStateChangeAction
            .subscribe(onNext: { [weak self] state in
                guard let self = self else { return }
                MainFlowRxBus.fundFollowingStatePublishRelay
                    .accept(FundFollowingChangeModel(fundId: self.fundId, newFollowingState: state))
            }).disposed(by: disposeBag)
    }

    private func configureHeader(with fundData: FundAbout, fundManager: FundManagerAbout) {
        title = fundData.name
        let name = NSMutableAttributedString(string: fundManager.name ?? "", attributes: [
            .font: UIFont.systemFont(ofSize: Defaults.TextSize.normal),
            .foregroundColor: UIColor.white
        ])
        name.append(NSAttributedString(string: ", ", attributes: [
            .foregroundColor: UIColor.white
        ]))
        name.append(NSAttributedString(string: fundData.name ?? "", attributes: [
            .font: UIFont.boldSystemFont(ofSize: Defaults.TextSize.normal),
            .foregroundColor: UIColor.white
        ]))
        viewCreator.fundTitle.attributedText = name
        let range = (name.string as NSString).range(of: fundManager.name ?? "")
        viewCreator.fundTitle.addLink(to: Date(), with: range)

        if fundData.following != .changing {
            viewCreator.followButton.setTitle(fundData.following?.stateTitle, for: .normal)
        }

        viewCreator.assignAsShareholderButton.isHidden = Config.isDemoAccount || !fundData.canAssignAsShareholder

        if let logo = fundData.logo, let logoUrl = URL(string: logo) {
            viewCreator.fundLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        if let background = fundData.background, let logoUrl = URL(string: background) {
            viewCreator.backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.followButton.alpha = fundData.following == FollowingState.changing ? 0 : 1
            self.viewCreator.assignAsShareholderButton.alpha = 1
            self.viewCreator.followLoader.alpha = fundData.following != FollowingState.changing ? 0 : 1
        }
    }

    private func initializePages(from availableInformations: [Fund.FundDetailsType]) {

        func buildViewControllerForDetails(ofType type: Fund.FundDetailsType) -> UIViewController {
            switch type {
            case .aboutUs: return FundAboutViewController(delegate: self)
            case .news: return PublicationsViewController(type: .fundNews(fundId: fundId), delegate: self)
            case .events: return PublicationsViewController(type: .fundEvents(fundId: fundId), delegate: self)
            case .documents: return LegalEntityHistoricalDataViewController(legalEntity: .fund(viewModel.fundId ?? 0), delegate: self)
            case .charts: return CompanyChartsViewController(chartId: .fundId(viewModel.fundId ?? 0), delegate: self)
            }
        }

        pagedViewControllers = availableInformations.sorted { $0.hashValue < $1.hashValue }.compactMap { buildViewControllerForDetails(ofType: $0) }

        let initialPageIndex = pagedViewControllers.index(where: { type(of: $0) == FundAboutViewController.self }) ?? 0
        viewCreator.pagerView.viewControllers = pagedViewControllers
        viewCreator.pagerView.setInitialPage(initialPageIndex)

        viewCreator.pagerView.layoutIfNeeded()
        UIView.animate(withDuration: Defaults.animationDuration, animations: { [weak self] in
            self?.viewCreator.pagerView.alpha = 1
        })
    }

    private func updateFundAboutViewController(with data: FundAbout) {
        if let fundAbout = viewCreator.findPagedViewController(type: FundAboutViewController.self) {
            fundAbout.data = data
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.scrollView.layoutIfNeeded()

        if pagerLayoutNeedsReload {
            pagerLayoutNeedsReload = false
            viewCreator.pagerView.reloadPagerCells()
        }
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard childScrollView.contentOffset.y < Defaults.FundDetails.minOffsetToAnimateHeader else { return }
        let goingUp = scrollView.panGestureRecognizer.translation(in: scrollView).y < 0
        guard goingUp == isMenuShown else { return }
        animateHeader(show: !goingUp)
    }

    private func animateHeader(show: Bool) {
        guard !isAnimating else {
            childScrollView.contentOffset.y = 0
            return
        }
        isAnimating = true
        let headerMaxContentYOffset = viewCreator.scrollView.contentSize.height - viewCreator.scrollView.frame.height

        viewCreator.contentStackView.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(show ? 0 : headerMaxContentYOffset.negative())
        }
        UIView.animate(withDuration: Defaults.headerAnimationDuration, animations: {
            self.view.layoutIfNeeded()
            self.updateHeaderAppearance(offset: show ? 0 : headerMaxContentYOffset)
            self.childScrollView.contentOffset.y = 0
        }, completion: { completed in
            self.isAnimating = !completed
            self.isMenuShown = show
        })
    }

    private func updateHeaderAppearance(offset: CGFloat) {
        let hoverViewAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.4)
        let titleAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.7)

        viewCreator.headerHoverView.alpha = hoverViewAlpha
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent.withAlpha(titleAlpha)]
    }

    @objc private func toogleFollowing() {
        guard let fund = viewModel.fundData.value?.0 else {
            return
        }
        if fund.following == .following {
            viewModel.toogleFundFollowingState()
        } else {
            let dialog = TermsAndConditionsDialogViewController(link: fund.termsAndConditions?.url ?? "", successHandler: { [unowned self] in
                self.viewModel.toogleFundFollowingState()
            }) { }
            dialog.modalPresentationStyle = .overCurrentContext
            present(dialog, animated: false)
        }
    }

    @objc private func assignAsInvestor() {
        viewModel.assignAsInvestor(delegate: self)
    }

    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension FundDetailsViewController: ReinitializableViewController {

    func reinitializeView(with id: Int) {
        pagerDataNeedsReload = true
        fundId = id
        viewModel.reloadData(forFundWithId: id)
    }
}

extension FundDetailsViewController: PagerViewDelegate {

    func didChangeScrollView(_ scrollView: UIScrollView) {
        childScrollView = scrollView
    }
}

extension FundDetailsViewController: PagedViewControllerDelegate {

    func pagedScrollView(didScroll scrollView: UIScrollView) {
        scrollViewDidScroll(scrollView)
    }
}

extension FundDetailsViewController: PublicationsViewControllerDelegate {

    func didSelect(publication: Publication) {
        viewModel.show(publication: publication)
    }

    func didTapShareButton(shareUrl: URL?) {
        shareNews(url: shareUrl)
    }
}

extension FundDetailsViewController: TTTAttributedLabelDelegate {
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith date: Date!) {
        guard let fundManager = viewModel.fundData.value?.1 else {
            return
        }
        viewModel.didSelect(fundManagerId: fundManager.id)
    }
}

extension FundDetailsViewController: AssignAsInvestorViewControllerDelegate {
    func didSuccesfullyAsignAsInvestor() {
        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.assignAsShareholderButton.isHidden = true
            self.viewCreator.buttonsStackView.layoutIfNeeded()
        }
    }
}

extension FundDetailsViewController: LegalEntityHistoricalDataViewControllerDelegate {

    func shouldShow(historicalDataSection: HistoricalDataSection) {
        viewModel.show(historicalDataSection: historicalDataSection)
    }
}
