//
//  TradingViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 08.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class TradingViewController: UIViewController {
    
    func showRedirectingAlert() {
        let alert = AlertView()
        alert.showDefault(in: self, withData: AlertData(
            message: nil,
            title: Localizable.tradingAlertTitle.localized,
            positiveButtonTitle: Localizable.tradingContinue,
            cancelButtonTitle: Localizable.tradingReturn,
            onPositiveTap: { [weak self] in self?.openExanteSite() }))
    }
    
    private func openExanteSite() {
        guard let url = URL.forQuery(using: Defaults.UrlPath.exante) else { return }
        UIApplication.shared.openIfPossible(url)
    }
}
