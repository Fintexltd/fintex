//
//  AlbumCollectionHeaderView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 28/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AlbumCollectionHeaderView: UICollectionReusableView {
    
    // MARK: Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    func initializeView() {
        backgroundColor = .white
        addSubview(contentView)
        contentView.addSubview(stackView)
        
        stackView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.leading.trailing.top.equalToSuperview().inset(Defaults.marginNormal)
        }
        
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    // MARK: Views
    private let albumTitleLabel = UILabelFactory.styled(textColor: .darkGrey,
                                                withFontSize: Defaults.TextSize.big,
                                                fontWeight: .bold)
    
    private let photosCountLabel = UILabelFactory.styled(textColor: .primaryDark,
                                                 withFontSize: Defaults.TextSize.small,
                                                 fontWeight: .bold)
    
    private let dateLabel = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.small)
    
    private lazy var stackView = UIStackView.make(
        axis: .vertical,
        with: [
            albumTitleLabel,
            photosCountLabel,
            dateLabel
        ])
    
    let contentView: UIView = UIView().layoutable()
}

// MARK: public functions
extension AlbumCollectionHeaderView {
    func configure(withTitle title: String, picturesCount: Int, andDate date: Date) {
        albumTitleLabel.text = title
        
        let pictureCountSuffix = (picturesCount == 1 ? Localizable.legalEntityGalleryAlbumPicture : Localizable.legalEntityGalleryAlbumPictures).localized
        photosCountLabel.text = "\(picturesCount) \(pictureCountSuffix)"
        dateLabel.text = date.toString(withFromat: Date.Format.appDateFormat)
    }
}
