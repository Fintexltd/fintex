//
//  AlbumDetailsViewModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa

class AlbumDetailsViewModel: BaseViewModel<HasCompaniesRepository> {
    
    let albumData = BehaviorRelay<Album?>(value: nil)
    
    func show(photoPreview: Photo, legalEntityName: String) {
        guard let photos = albumData.value?.items,
            let photoIndex = photos.firstIndex(where: { $0.id == photoPreview.id }) else { return }
            router?.present(destination: .photoPreview(legalEntityName: legalEntityName,
                                                       photos: photos,
                                                       initialIndex: photoIndex))
    }
}
