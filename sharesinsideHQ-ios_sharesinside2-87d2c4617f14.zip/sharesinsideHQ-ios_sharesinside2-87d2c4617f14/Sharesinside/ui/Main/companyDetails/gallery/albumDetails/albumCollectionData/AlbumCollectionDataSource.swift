//
//  AlbumsCollectionDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol AlbumCollectionDataSourceDelegate: class {
    func didSelect(photo: Photo, inAlbum album: Album)
}

class AlbumCollectionDataSource: NSObject {

    weak var delegate: AlbumCollectionDataSourceDelegate?
    
    private let sectionsCount = 1

    private let collectionView: UICollectionView

    var album: Album? {
        didSet {
            collectionView.reloadData()
        }
    }

    init(with collectionView: UICollectionView) {
        self.collectionView = collectionView
        super.init()
        setupCollectionView()
    }
}

extension AlbumCollectionDataSource {

    private func setupCollectionView() {
        collectionView.registerCell(PhotoCollectionViewCell.self)
        collectionView.registerHeaderView(AlbumCollectionHeaderView.self)
        collectionView.registerFooterView(UICollectionReusableView.self)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.footerReferenceSize = .zero
    }
}

extension AlbumCollectionDataSource: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return sectionsCount
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return album?.items.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: PhotoCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.photo = album?.items[indexPath.row]
            return cell
        }

        return UICollectionViewCell()
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        switch kind {
        case UICollectionView.elementKindSectionHeader:
            if let header: AlbumCollectionHeaderView = collectionView.dequeueReusableHeaderView(for: indexPath) {
                if let album = album {
                    header.configure(withTitle: album.name ?? "",
                                     picturesCount: album.items.count,
                                     andDate: album.updatedDate)
                }
                return header
            }
        default: break
        }
        
        if let footer = collectionView.dequeueReusableFooterView(for: indexPath) {
            return footer
        }
    
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let album = album {
            delegate?.didSelect(photo: album.items[indexPath.item], inAlbum: album)
        }
    }
}

extension AlbumCollectionDataSource: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.galleryPhotoSize(for: collectionView)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        
        if let headerView = collectionView.visibleSupplementaryViews(ofKind: UICollectionView.elementKindSectionHeader).first as? AlbumCollectionHeaderView {
            headerView.layoutIfNeeded()
            let height = headerView.contentView.systemLayoutSizeFitting(UIView.layoutFittingExpandedSize).height
            return CGSize(width: collectionView.frame.width, height: height)
        }
        
        return CGSize(width: collectionView.frame.width, height: Defaults.CompanyDetails.Gallery.albumHeaderHeight)
    }
}
