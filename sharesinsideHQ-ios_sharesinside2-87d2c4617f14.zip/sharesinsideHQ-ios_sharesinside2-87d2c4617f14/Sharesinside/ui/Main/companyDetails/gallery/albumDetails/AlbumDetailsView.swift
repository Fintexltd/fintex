//
//  AlbumDetailsView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AlbumDetailsView: BaseViewCreator {
    
    lazy var albumTitleLabel = UILabelFactory.styled(textColor: .primaryDark, withFontSize: Defaults.TextSize.normal, fontWeight: .semibold)
    
    lazy var photosCountLabel = UILabelFactory.styled(textColor: .primary, withFontSize: Defaults.TextSize.small)
    
    lazy var dateLabel = UILabelFactory.styled(textColor: .grey, withFontSize: Defaults.TextSize.small)
    
    lazy var photosCollectionView: UICollectionView = {
        let collectionView = UICollectionView.makeCustomCollectionView(type: UICollectionView.self,
                                                                       lineSpacing: Defaults.marginNormal,
                                                                       interItemSpacing: Defaults.marginNormal)
        
        (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.sectionInset =
            UIEdgeInsets(top: Defaults.marginNormal,
                         left: Defaults.marginNormal,
                         bottom: Defaults.marginNormal,
                         right: Defaults.marginNormal)
        collectionView.alwaysBounceVertical = true
        
        return collectionView
    }()
    
    override func setupViewHierarchy() {
        parentView.addSubview(photosCollectionView)
    }
    
    override func setupConstraints() {
        photosCollectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
