//
//  AlbumDetailsViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

class AlbumDetailsViewController: BaseViewController<AlbumDetailsViewModel> {
    
    lazy var viewCreator = AlbumDetailsView(withParentView: self.view)
    
    lazy var dataSource = AlbumCollectionDataSource(with: viewCreator.photosCollectionView)
    
    let album: Album
    let legalEntityName: String
    
    init(album: Album, legalEntityName: String) {
        self.album = album
        self.legalEntityName = legalEntityName
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setupView() {
        viewCreator.setupView()
    }
    
    override func initializeView() {
        super.initializeView()
        title = legalEntityName
        dataSource.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent]
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        viewCreator.photosCollectionView.collectionViewLayout.invalidateLayout()
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.albumData.accept(album)
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.albumData
            .ignoreNil()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] in self?.configure(with: $0) })
            .disposed(by: disposeBag)
    }
    
    func configure(with album: Album) {
        dataSource.album = album
    }
}

extension AlbumDetailsViewController: AlbumCollectionDataSourceDelegate {
    func didSelect(photo: Photo, inAlbum album: Album) {
        viewModel.show(photoPreview: photo, legalEntityName: legalEntityName)
    }
}
