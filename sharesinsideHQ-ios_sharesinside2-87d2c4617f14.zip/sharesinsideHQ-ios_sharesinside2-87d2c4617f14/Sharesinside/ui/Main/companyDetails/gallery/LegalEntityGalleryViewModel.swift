//
//  LegalEntityAboutViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum GalleryState {
    
    case loading
    case loaded([Album])
    case error(Error)
    
    var currentAlbums: [Album] {
        switch self {
        case .loaded(let albums): return albums
        default: return []
        }
    }
}

class LegalEntityGalleryViewModel: BaseViewModel<HasCompaniesRepository & HasStartupsRepository> {
    
    let galleryState = BehaviorRelay<GalleryState>(value: .loading)
    
    private lazy var companiesRepository = dependencies.companiesRepository

    private lazy var startupsRepository = dependencies.startupsRepository
    
    func loadGallery(forLegalEntity legalEntity: LegalEntity) {
        dataSource(for: legalEntity)
            .do(onSubscribe: { [weak self] in self?.galleryState.accept(.loading) })
            .observeOn(MainScheduler.asyncInstance)
            .subscribe( onNext: { [weak self] albums in
                self?.galleryState.accept(.loaded(albums))
            }, onError: { [weak self] error in
                self?.galleryState.accept(.error(error))
            })
            .disposed(by: disposeBag)
    }

    private func dataSource(for legalEntity: LegalEntity) -> Observable<[Album]> {
        switch legalEntity {
        case let .company(id):
            return companiesRepository.getGalleries(companyId: id)
        case let .startup(id):
            return startupsRepository.getGalleries(startupId: id)
        default: return Observable.empty()
        }
    }
}
