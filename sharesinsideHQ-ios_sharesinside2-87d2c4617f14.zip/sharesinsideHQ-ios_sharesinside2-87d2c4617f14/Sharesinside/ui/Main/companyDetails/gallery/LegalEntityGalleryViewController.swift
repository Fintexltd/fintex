//
//  LegalEntityAboutViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher

protocol LegalEntityGalleryViewControllerDelegate: PagedViewControllerDelegate {
    func didSelect(album: Album)
    func didSelect(photo: Photo, inPhotos photos: [Photo])
}

class LegalEntityGalleryViewController: BaseViewController<LegalEntityGalleryViewModel> {

    private lazy var viewCreator = LegalEntityGalleryView(withParentView: self.view)
    private lazy var dataSource = GalleryCollectionDataSource(with: viewCreator.galleryCollectionView)

    private let legalEntity: LegalEntity
    private var pagerNeedsReload = false

    weak var delegate: LegalEntityGalleryViewControllerDelegate?

    init(legalEntity: LegalEntity, delegate: LegalEntityGalleryViewControllerDelegate?) {
        self.legalEntity = legalEntity
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.legalEntityGalleryTitle.localized }
        set { }
    }

    override func setupView() {
        viewCreator.setupView()
    }

    override func initializeView() {
        super.initializeView()
        dataSource.delegate = self
    }

    override func bindRxLifecycle() {
        super.bindRxLifecycle()

        self.rx.firstTimeViewDidAppear
            .subscribe(onSuccess: { [weak self] in
                guard let `self` = self else { return }
                self.viewModel.loadGallery(forLegalEntity: self.legalEntity) })
            .disposed(by: disposeBag)
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.galleryState
            .subscribe(onNext: { [weak self] in self?.configure(with: $0) })
            .disposed(by: disposeBag)
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pagerNeedsReload = true
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        if pagerNeedsReload {
            pagerNeedsReload = false
            viewCreator.galleryCollectionView.collectionViewLayout.invalidateLayout()
        }
    }

    func configure(with galleryState: GalleryState) {
        dataSource.galleryState = galleryState
    }
}

extension LegalEntityGalleryViewController: GalleryCollectionDataSourceDelegate {

    func pagedScrollView(didScroll scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }

    func didSelect(photo: Photo, inPhotos photos: [Photo]) {
        delegate?.didSelect(photo: photo, inPhotos: photos)
    }

    func didSelect(album: Album) {
        delegate?.didSelect(album: album)
    }
}
