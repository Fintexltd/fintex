//
//  LegalEntityAboutView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class LegalEntityGalleryView: BaseViewCreator {

    lazy var galleryCollectionView: UICollectionView = {
        let collectionView = UICollectionView.makeCustomCollectionView(type: UICollectionView.self,
                                                                       lineSpacing: Defaults.marginNormal,
                                                                       interItemSpacing: Defaults.marginNormal)
        
        if let flowLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            flowLayout.sectionHeadersPinToVisibleBounds = true
            flowLayout.sectionInset = UIEdgeInsets(top: Defaults.marginNormal,
                                               left: Defaults.marginNormal,
                                               bottom: Defaults.marginNormal,
                                               right: Defaults.marginNormal)
        }
        return collectionView
    }()

    override func setupViewHierarchy() {
        parentView.addSubview(galleryCollectionView)
    }
    override func setupConstraints() {
        galleryCollectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
