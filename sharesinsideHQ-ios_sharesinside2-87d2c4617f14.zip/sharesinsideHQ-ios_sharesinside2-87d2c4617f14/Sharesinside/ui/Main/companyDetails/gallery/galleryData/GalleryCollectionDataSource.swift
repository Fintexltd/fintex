//
//  AlbumsCollectionDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol GalleryCollectionDataSourceDelegate: PagedViewControllerDelegate {
    func didSelect(album: Album)
    func didSelect(photo: Photo, inPhotos photos: [Photo])
}

class GalleryCollectionDataSource: NSObject {

    weak var delegate: GalleryCollectionDataSourceDelegate?

    private let gallerySectionsCount = 2
    private let albumsSection = 0
    private let allPhotosSection = 1
    
    private let collectionView: UICollectionView

    var galleryState: GalleryState = .loading {
        didSet {
            albums = galleryState.currentAlbums.filter { $0.type != .allItems && $0.name != nil && !$0.items.isEmpty }
            allPhotos = galleryState.currentAlbums.filter { $0.type == .allItems }.flatMap { $0.items }
            collectionView.collectionViewLayout.invalidateLayout()
            collectionView.reloadData()
        }
    }

    private var albums: [Album] = []
    private var allPhotos: [Photo] = []

    init(with collectionView: UICollectionView) {
        self.collectionView = collectionView
        super.init()
        setupCollectionView()
    }

}

extension GalleryCollectionDataSource {

    private func setupCollectionView() {
        collectionView.registerCell(PhotoCollectionViewCell.self)
        collectionView.registerCell(AlbumsCollectionViewCell.self)
        collectionView.registerFooterView(StateFooterView.self)
        collectionView.registerHeaderView(LabelledCollectionViewHeader.self)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.headerReferenceSize =
            CGSize(width: collectionView.frame.width, height: Defaults.CompanyDetails.Gallery.heightForHeader)
    }
}

extension GalleryCollectionDataSource: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return gallerySectionsCount
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch section {
        case albumsSection: return albums.count > 0 ? 1 : 0
        default: return allPhotos.count
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch indexPath.section {
        case albumsSection:
            guard !albums.isEmpty else { return UICollectionViewCell() }
            if let cell: AlbumsCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
                cell.albums = albums.filter { !$0.items.isEmpty }
                cell.delegate = self
                return cell
            }
        default:
            if let cell: PhotoCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
                cell.photo = allPhotos[indexPath.row]
                return cell
            }
        }

        return UICollectionViewCell()
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        switch kind {
        case UICollectionView.elementKindSectionFooter:
            if let stateFooter: StateFooterView = collectionView.dequeueReusableFooterView(for: indexPath) {
                stateFooter.initialize()
                return stateFooter
            }
        default:
            if let header: LabelledCollectionViewHeader = collectionView.dequeueReusableHeaderView(for: indexPath) {
                header.title = Localizable.legalEntityGallertAllPhotos.localized.uppercased()
                return header
            }
        }
    
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section == allPhotosSection {
            delegate?.didSelect(photo: allPhotos[indexPath.row], inPhotos: allPhotos)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension GalleryCollectionDataSource: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.section {
        case albumsSection: return CGSize(width: collectionView.frame.width, height: albums.isEmpty ? 0.1 : Defaults.CompanyDetails.Gallery.albumsSectionHeight)
        default:
            return CGSize.galleryPhotoSize(for: collectionView)
        }
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: galleryState.heightForFooter)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        switch section {
        case albumsSection: return .zero
        default: return CGSize(width: collectionView.frame.width, height: Defaults.CompanyDetails.Gallery.heightForHeader)
        }
    }
}

extension GalleryState {
    fileprivate var heightForFooter: CGFloat {
        switch self {
        case .loading: return Defaults.Company.footerHeight
        default: return 0
        }
    }
}

extension GalleryCollectionDataSource: AlbumsCollectionViewCellDelegate {
    func didSelectAlbum(_ album: Album) {
        delegate?.didSelect(album: album)
    }
}
