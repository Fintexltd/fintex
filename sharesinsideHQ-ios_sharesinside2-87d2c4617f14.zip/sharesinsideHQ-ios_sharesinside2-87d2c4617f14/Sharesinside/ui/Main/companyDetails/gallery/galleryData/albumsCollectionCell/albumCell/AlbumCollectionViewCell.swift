//
//  AlbumsCollectionViewCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class AlbumCollectionViewCell: UICollectionViewCell {
    
    lazy var viewCreator = AlbumCellView(withParentView: self)
    
    var model: Album? {
        didSet {
            guard let model = model else { return }
            configure(with: model)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        viewCreator.setupView()
        backgroundColor = .accent
    }
    
    private func configure(with model: Album) {
        viewCreator.albumNameLabel.text = model.name ?? "--"
        viewCreator.photosCountLabel.text = "\(model.items.count)"
        
        configurePhotos(with: model.items)
    }
    
    private func configurePhotos(with data: [Photo]) {
        viewCreator.miniatures.forEach { $0.image = nil }
        data.compactMap { $0.url }
            .prefix(4)
            .enumerated()
            .forEach { index, url in
                viewCreator.miniatures[index].load(with: url)
        }
    }
}
