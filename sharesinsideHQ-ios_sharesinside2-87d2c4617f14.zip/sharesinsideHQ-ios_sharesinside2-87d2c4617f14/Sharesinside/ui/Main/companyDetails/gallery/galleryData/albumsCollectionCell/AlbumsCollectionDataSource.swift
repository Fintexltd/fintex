//
//  AlbumsCollectionDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol AlbumsCollectionDataSourceDelegate: class {
    func didSelect(album: Album)
}

class AlbumsCollectionDataSource: NSObject {
    
    let collectionView: UICollectionView
    
    weak var delegate: AlbumsCollectionDataSourceDelegate?
    
    var albums: [Album] = [] {
        didSet {
            collectionView.reloadData()
        }
    }
    
    init(with collectionView: UICollectionView) {
        self.collectionView = collectionView
        super.init()
        setupCollectionView()
    }
    
}

extension AlbumsCollectionDataSource {
    
    private func setupCollectionView() {
        collectionView.registerCell(AlbumCollectionViewCell.self)
        collectionView.delegate = self
        collectionView.dataSource = self
    }
}

extension AlbumsCollectionDataSource: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return albums.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: AlbumCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.model = albums[indexPath.row]
            return cell
        }
        
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didSelect(album: albums[indexPath.row])
    }
}

extension AlbumsCollectionDataSource: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let insets = (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.sectionInset  ?? .zero
        let height = collectionView.frame.height - insets.top - insets.bottom
        let width = height - 2 * Defaults.CompanyDetails.Gallery.albumLabelHeight
        return CGSize(width: width, height: height)
    }
}
