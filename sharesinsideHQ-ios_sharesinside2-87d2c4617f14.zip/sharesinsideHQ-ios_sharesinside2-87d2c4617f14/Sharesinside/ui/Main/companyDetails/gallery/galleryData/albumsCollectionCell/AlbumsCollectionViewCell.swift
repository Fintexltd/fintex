//
//  PhotosCollectionViewCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol AlbumsCollectionViewCellDelegate: class {
    func didSelectAlbum(_ album: Album)
}

class AlbumsCollectionViewCell: UICollectionViewCell {
    
    weak var delegate: AlbumsCollectionViewCellDelegate?
    
    private lazy var albumsDataSource = AlbumsCollectionDataSource(with: albumsCollectionView)
    
    private let albumsCollectionView: UICollectionView = {
        let collectionView = UICollectionView.makeCustomCollectionView(
            type: UICollectionView.self,
            scrollDirection: .horizontal,
            lineSpacing: Defaults.marginNormal,
            interItemSpacing: Defaults.marginNormal)
        collectionView.alwaysBounceVertical = false
        if let flowLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            flowLayout.sectionInset = UIEdgeInsets(top: Defaults.marginBig,
                                                   left: Defaults.marginNormal,
                                                   bottom: Defaults.marginMicro,
                                                   right: Defaults.marginNormal)
            flowLayout.scrollDirection = .horizontal
            
        }
        return collectionView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    var albums: [Album] = [] {
        didSet {
            configure(with: albums)
        }
    }
    
    private func initializeView() {
        albumsDataSource.delegate = self
        addSubview(albumsCollectionView)
        setupConstraints()
    }
    
    private func setupConstraints() {
        albumsCollectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func configure(with albums: [Album]) {
        albumsDataSource.albums = albums
    }
}

extension AlbumsCollectionViewCell: AlbumsCollectionDataSourceDelegate {
    
    func didSelect(album: Album) {
        delegate?.didSelectAlbum(album)
    }
}
