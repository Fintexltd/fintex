//
//  AlbumsCellView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AlbumCellView: BaseViewCreator {
    
    lazy var miniaturesContainer = UIView().layoutable()
    
    let albumNameLabel = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
    
    let photosCountLabel = UILabelFactory.styled(textColor: .grey, withFontSize: Defaults.TextSize.small)
    
    lazy var upperLeftPhoto = buildPhotoView()
    
    lazy var upperRightPhoto = buildPhotoView()
    
    lazy var lowerLeftPhoto = buildPhotoView()
    
    lazy var lowerRightPhoto = buildPhotoView()
    
    var miniatures: [UIImageView] {
        return [upperLeftPhoto, upperRightPhoto, lowerLeftPhoto, lowerRightPhoto]
    }
    
    lazy var contentStackView = UIStackView.make(
        axis: .vertical,
        with: [
            miniaturesContainer,
            albumNameLabel,
            photosCountLabel
        ])
    
    override func setupProperties() {
        [albumNameLabel, photosCountLabel].forEach {
            $0.textAlignment = .left
            $0.numberOfLines = 1
            $0.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        }
    }
    
    override func setupViewHierarchy() {
        miniatures.forEach {
            miniaturesContainer.addSubview($0)
            $0.addShadowView()
        }
        
        parentView.addSubview(contentStackView)
    }
    
    override func setupConstraints() {
        upperLeftPhoto.snp.makeConstraints { make in
            make.top.leading.equalToSuperview()
            make.trailing.equalTo(upperRightPhoto.snp.leading)
                .offset(Defaults.loaderStrokeWidth.negative()).priority(.highest)
            make.bottom.equalTo(lowerLeftPhoto.snp.top)
                .offset(Defaults.loaderStrokeWidth.negative()).priority(.highest)
            make.height.equalTo(upperLeftPhoto.snp.width)
            make.width.equalTo(upperRightPhoto.snp.width)
        }
        
        upperRightPhoto.snp.makeConstraints { make in
            make.top.trailing.equalToSuperview()
            make.bottom.equalTo(lowerRightPhoto.snp.top)
                .offset(Defaults.loaderStrokeWidth.negative()).priority(.highest)
            make.height.equalTo(upperRightPhoto.snp.width)
        }
        
        lowerLeftPhoto.snp.makeConstraints { make in
            make.leading.bottom.equalToSuperview()
            make.trailing.equalTo(lowerRightPhoto.snp.leading)
                .offset(Defaults.loaderStrokeWidth.negative()).priority(.highest)
            make.height.equalTo(lowerLeftPhoto.snp.width)
            make.width.equalTo(lowerRightPhoto.snp.width)
        }
        
        lowerRightPhoto.snp.makeConstraints { make in
            make.trailing.bottom.equalToSuperview()
            make.height.equalTo(lowerRightPhoto.snp.width)
        }
        
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}

extension AlbumCellView {
    private func buildPhotoView() -> UIImageView {
        let view = UIImageView().layoutable()
        view.contentMode = .scaleAspectFill
        view.backgroundColor = .grey
        view.cornerRadius(Defaults.CompanyDetails.Gallery.albumPhotoCornerRadius)
        
        return view
    }
}

extension UIImageView {
    
    fileprivate func addShadowView() {
        
        let view = UIView().layoutable()
        view.backgroundColor = .white
        view.cornerRadius(self.layer.cornerRadius)
        view.clipsToBounds = false
        view.layer.shadowColor = UIColor.darkGrey.cgColor
        view.layer.shadowOpacity = 0.2
        view.layer.shadowOffset = CGSize(width: 0, height: 0.1)
        
        guard let superview = self.superview else { return }
        
        superview.addSubview(view)
        superview.sendSubviewToBack(view)
        
        view.snp.makeConstraints { make in
            make.center.equalTo(self)
            make.width.height.equalTo(self)
        }
    }
}
