//
//  PhotosCollectionViewCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class PhotoCollectionViewCell: UICollectionViewCell {
    
    let imageView: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.cornerRadius(Defaults.CompanyDetails.Gallery.photoCornerRadius)
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .grey
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    var photo: Photo? {
        didSet {
            if let photo = photo {
                configure(with: photo)
            }
        }
    }
    
    private func initializeView() {
        contentView.addSubview(imageView)
        setupConstraints()
    }
    
    private func setupConstraints() {
        imageView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func configure(with photo: Photo) {
        imageView.load(with: photo.url)
    }
}
