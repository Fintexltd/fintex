//
//  CompanyDetailsViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class CompanyDetailsViewModel: BaseViewModel<HasCompaniesRepository> {

    var companyId: Int?
    let companyData = BehaviorRelay<CompanyAbout?>(value: nil)
    let followingStateChangeAction = PublishRelay<FollowingState>()

    lazy var companiesRepository = dependencies.companiesRepository
    
    override func onViewDidLoad() {
        super.onViewDidLoad()
        getCompanyAboutData()
    }
    
    func reloadData(forCompanyWithId id: Int) {
        companyId = id
        getCompanyAboutData()
    }
    
    private func getCompanyAboutData() {
        guard let companyId = companyId else {
            alert.accept(AlertData(message: Localizable.companyDetailsFetchError.localized,
                                   onPositiveTap: { self.router?.pop() }))
            return
        }
        companiesRepository.getCompanyAbout(companyId: companyId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] companyAbout in
                    self?.companyData.accept(companyAbout) },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent) })
            .disposed(by: disposeBag)
    }
    
    func show(allShareprices data: [Symbol]) {
        router?.push(to: .allShareprices(shareprices: data))
    }
    
    func show(allEmployees employeesGroup: EmployeesGroup, employeesDelegate: EmployeesDelegate) {
        router?.push(to: .allEmployees(employeesGroup: employeesGroup, delegate: employeesDelegate))
    }
    
    func show(detailsOf employee: Employee) {
        router?.push(to: .employeeDetails(employee: employee, employerData: companyData.value))
    }
    
    func show(historicalDataSection: HistoricalDataSection) {
        guard let companyId = companyId else { return }
        router?.push(to: .historicalDataSection(legalEntity: .company(companyId),
                                                sectionId: historicalDataSection.id,
                                                sectionTitle: historicalDataSection.name))
    }
    
    func show(publication: Publication) {
        switch publication.type {
        case .event: router?.push(to: .eventDetails(eventId: publication.watchlistableId))
        case .news: router?.push(to: .newsDetails(newsId: publication.watchlistableId))
        case .project: router?.push(to: .projectDetails(projectId: publication.watchlistableId))
        }
    }
    
    func show(albumDetails: Album) {
        router?.push(to: .albumDetails(album: albumDetails, legalEntityName: companyData.value?.name ?? ""))
    }
    
    func show(photoPreview: Photo, forPhotos photos: [Photo]) {
        guard let photoIndex = photos.firstIndex(where: { $0.id == photoPreview.id }) else { return }
        router?.present(destination: .photoPreview(legalEntityName: companyData.value?.name ?? "",
                                                   photos: photos,
                                                   initialIndex: photoIndex))
    }
    
    func assignAsShareholder(delegate: AssignAsShareholderViewControllerDelegate?) {
        guard let companyAbout = companyData.value else { return }
        router?.present(destination: .assignAsShareholder(companyAbout: companyAbout, delegate: delegate))
    }
}

extension CompanyDetailsViewModel {
    
    func toogleCompanyFollowingState() {
        guard let company = companyData.value else { return }
        companiesRepository.toggleFollowing(ofCompanyWithId: company.id, follow: company.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(
                onSubscribe: { self.changeCompanyFollowState(.changing, forCompany: company) })
            .subscribe(
                onNext: { [weak self] _ in
                    self?.changeCompanyFollowState(
                        company.following == .following ? .notFollowing : .following, forCompany: company) },
                onError: { [weak self] error in
                    self?.changeCompanyFollowState(company.following ?? .notFollowing, forCompany: company)
                    self?.alert.accept(AlertData(message: error.localizedDescription))})
            .disposed(by: disposeBag)
    }
    
    private func changeCompanyFollowState(_ state: FollowingState, forCompany company: CompanyAbout) {
        let updatedCompany = company.with(followingState: state)
        followingStateChangeAction.accept(state)
        companyData.accept(updatedCompany)
    }
}
