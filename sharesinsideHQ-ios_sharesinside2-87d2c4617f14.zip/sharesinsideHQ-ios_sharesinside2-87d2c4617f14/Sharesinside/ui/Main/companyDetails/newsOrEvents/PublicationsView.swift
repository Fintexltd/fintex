//
//  CompanyAboutView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class PublicationsView: BaseViewCreator {

    let tableView: WatchlistTableView = {
        let tableView = WatchlistTableView()
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .clear
        tableView.bounces = true
        return tableView
    }()
    
    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
    }
    
    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
