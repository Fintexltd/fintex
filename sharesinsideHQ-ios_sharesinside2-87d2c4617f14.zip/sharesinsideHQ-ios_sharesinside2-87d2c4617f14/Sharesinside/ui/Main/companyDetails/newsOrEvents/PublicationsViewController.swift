//
//  CompanyAboutViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher

protocol PublicationsViewControllerDelegate: PagedViewControllerDelegate {
    func didSelect(publication: Publication)
    func didTapShareButton(shareUrl: URL?)
}

class PublicationsViewController: BaseViewController<WatchlistViewModel> {

    private lazy var viewCreator = PublicationsView(withParentView: self.view)

    weak var delegate: PublicationsViewControllerDelegate?
    
    let type: WatchlistDataType
    
    init(type: WatchlistDataType, delegate: PublicationsViewControllerDelegate) {
        self.type = type
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        self.type = .watchlist
        super.init(coder: aDecoder)
    }
    
    override var title: String? {
        get {
            type.title
        }
        set {}
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.listType = type
    }
    override func setupView() {
        viewCreator.setupView()
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.tableView.customDelegate = self
    }

    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.watchlistState
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] watchlistState in
                self?.viewCreator.tableView.state = watchlistState
                self?.viewCreator.tableView.isHidden = watchlistState.showBackgroundView
            }).disposed(by: disposeBag)
    }
}

extension PublicationsViewController: WatchlistTableViewDelegate {

    func didTapHeader(for issuerId: Int, issuerType: PublicationIssuerType) {
        switch issuerType {
        case .company:
            router.push(to: .companyDetails(companyId: issuerId))
        case .fund:
            router.push(to: .fundDetails(fundId: issuerId))
        case .fundsManager:
            router.push(to: .fundManagerDetails(fundManagerId: issuerId))
        case .startup:
            router.push(to: .startupDetails(startupId: issuerId))
        }
    }
    
    func pagedScrollView(didScroll scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
 
    func didSelectAddToCalendar(for event: Event) {
        viewModel.addToCalendar(event: event)
    }
    
    func didScrollToBottom() {
        viewModel.loadMoreData()
    }
    
    func didScrollToTop() {}
    
    func didSelect(publication: Publication) {
        delegate?.didSelect(publication: publication)
    }
    
    func didSelectPlayVideo(for news: News) { }
    
    func didTapShareButton(shareUrl: URL?) {
        delegate?.didTapShareButton(shareUrl: shareUrl)
    }

    func didSwitch(dateDisplayType: EventDateDisplayType) {
        viewModel.switch(displayDateType: dateDisplayType)
    }
}
