//
//  ShareprizeCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class SharepriceCollectionViewCell: UICollectionViewCell {
    
    private lazy var viewCreator = SharepriceCellView(withParentView: self.contentView)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        viewCreator.setupView()
        backgroundColor = .background
    }
    
    func configure(with data: Symbol) {
        guard let ohcl = data.ohlc else { return }
        
        let currency = data.currency ?? ""
        viewCreator.leftTitleLabel.text = Localizable.companyAboutSharepriceTitle.localized
        viewCreator.rightTitleLabel.text = "\(currency) \(ohcl.close)"
        viewCreator.leftSubtitleLabel.text = Localizable.companyAboutSharepriceHighLow.localized
        viewCreator.rightSubtitleLabel.text = "\(currency) \(ohcl.high)/\(ohcl.low)"
        
        viewCreator.exchangeLabel.text = "\(Localizable.companyAboutSharepriceExchange.localized) \(data.exchange ?? "-")"
    }
}
