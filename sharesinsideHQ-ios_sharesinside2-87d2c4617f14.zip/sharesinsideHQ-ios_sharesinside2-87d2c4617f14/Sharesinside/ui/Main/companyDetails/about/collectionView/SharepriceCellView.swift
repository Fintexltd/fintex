//
//  SharepriceCellView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class SharepriceCellView: BaseViewCreator {
    
    lazy var leftTitleLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .darkGrey,
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()
    
    lazy var leftSubtitleLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .grey,
            withFontSize: Defaults.TextSize.small,
            fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()
    
    lazy var rightTitleLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .darkGrey,
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .semibold)
        label.textAlignment = .right
        return label
    }()
    
    lazy var rightSubtitleLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .grey,
            withFontSize: Defaults.TextSize.small,
            fontWeight: .semibold)
        label.textAlignment = .right
        return label
    }()
    
    lazy var exchangeLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .darkGrey,
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()
    
    lazy var divider: UIView = {
        let view = UIView()
        view.backgroundColor = .grey
        return view
    }()
    
    override func setupViewHierarchy() {
        [leftTitleLabel, leftSubtitleLabel, rightTitleLabel, rightSubtitleLabel, exchangeLabel, divider]
            .forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        leftTitleLabel.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().inset(Defaults.marginSmall)
            make.trailing.equalTo(rightTitleLabel.snp.leading)
        }
        leftSubtitleLabel.snp.makeConstraints { make in
            make.top.equalTo(leftTitleLabel.snp.bottom)
            make.leading.equalToSuperview().inset(Defaults.marginSmall)
            make.trailing.equalTo(rightSubtitleLabel.snp.leading)
        }
        rightTitleLabel.snp.makeConstraints { make in
            make.centerY.equalTo(leftTitleLabel)
            make.trailing.equalToSuperview().inset(Defaults.marginSmall)
        }
        rightSubtitleLabel.snp.makeConstraints { make in
            make.centerY.equalTo(leftSubtitleLabel)
            make.trailing.equalToSuperview().inset(Defaults.marginSmall)
        }
        exchangeLabel.snp.makeConstraints { make in
            make.top.equalTo(leftSubtitleLabel.snp.bottom).offset(Defaults.marginSmall)
            make.leading.equalToSuperview().inset(Defaults.marginSmall)
            make.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
        AppInfo.isIPad ?
            setupVerticalDividerConstraints() : setupHorizontalDividerConstraints()
    }
    
    private func setupVerticalDividerConstraints() {
        divider.snp.makeConstraints { make in
            make.trailing.centerY.equalToSuperview()
            make.height.equalToSuperview()
            make.width.equalTo(Defaults.dividerSize)
        }
    }
    
    private func setupHorizontalDividerConstraints() {
        divider.snp.makeConstraints { make in
            make.bottom.trailing.equalToSuperview()
            make.leading.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
    }
}
