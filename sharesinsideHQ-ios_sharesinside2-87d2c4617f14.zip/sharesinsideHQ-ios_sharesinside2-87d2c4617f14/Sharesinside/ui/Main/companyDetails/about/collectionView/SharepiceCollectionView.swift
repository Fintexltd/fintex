//
//  SharepiceCollectionView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol SharepriceCollectionViewDelegate: class {
    func showAllShareprices(with data: [Symbol])
}

class SharepriceCollectionView: UICollectionView {
    
    weak var customDelegate: SharepriceCollectionViewDelegate?
    
    var isCompact: Bool = false
    var shareprices: [Symbol] = [] {
        didSet { sharepriceData = cutDataIfNeeded(shareprices.validSymbols) }
    }
    private var sharepriceData: [Symbol] = [] {
        didSet { reloadData() }
    }
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        registerCell(SharepriceCollectionViewCell.self)
        registerFooterView(SeeMoreCollectionViewFooter.self)
        dataSource = self
        delegate = self
    }
    
    private func cutDataIfNeeded(_ data: [Symbol]) -> [Symbol] {
        guard isCompact, let firstElement = data.first else { return data }
        return [firstElement]
    }
}

extension SharepriceCollectionView: UICollectionViewDataSource, UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sharepriceData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: SharepriceCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.configure(with: sharepriceData[indexPath.row])
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if let seeMoreFooter: SeeMoreCollectionViewFooter = collectionView.dequeueReusableFooterView(for: indexPath), isCompact {
            seeMoreFooter.delegate = self
            return seeMoreFooter
        }
        return UICollectionReusableView()
    }
}

extension SharepriceCollectionView: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = AppInfo.isIPad ? Defaults.Shareprice.iPadCellWidth : collectionView.frame.width
        let height: CGFloat = Defaults.Shareprice.cellHeight
        
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if shouldShowFooter() {
            return CGSize(width: collectionView.frame.width, height: Defaults.seeMooreFooterHeight)
        } else {
            return CGSize.zero
        }
    }
    
    private func shouldShowFooter() -> Bool {
        let minNumberToShowFooter = 2
        return !(AppInfo.isIPad || !isCompact || shareprices.count < minNumberToShowFooter)
    }
}

extension SharepriceCollectionView: SeeMoreFooterDelegate {
    
    func seeMoreDidTouch(inSection section: Int) {
        customDelegate?.showAllShareprices(with: shareprices)
    }
}
