//
//  CompanyAboutViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class CompanyAboutViewModel: BaseViewModel<HasCompaniesRepository> {
    
    let companyAboutData = BehaviorRelay<CompanyAbout?>(value: nil)

}
