//
//  AllSharepricesView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AllSharepricesView: BaseViewCreator {
    
    private lazy var sharepriceCollectionView: SharepriceCollectionView = {
        return UICollectionView.makeCustomCollectionView(type: SharepriceCollectionView.self)
    }()
    
    func configure(with shareprices: [Symbol]) {
        sharepriceCollectionView.shareprices = shareprices
            .filter { $0.ohlc != nil && $0.currency != nil }
    }
    
    override func setupViewHierarchy() {
        parentView.addSubview(sharepriceCollectionView)
    }

    override func setupConstraints() {
        sharepriceCollectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
