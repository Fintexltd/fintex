//
//  AllSharepricesViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AllSharepricesViewController: BaseViewController<AllSharepricesViewModel> {
    
    private lazy var viewCreator = AllSharepricesView(withParentView: self.view)
    
    let shareprices: [Symbol]
    
    init(shareprices: [Symbol]) {
        self.shareprices = shareprices
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        shareprices = []
        super.init(coder: aDecoder)
    }
    
    override func setupView() {
        navigationController?.setupNavigationBar()
        viewCreator.setupView()
    }
    
    override func initializeView() {
        super.initializeView()
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.background]
        viewCreator.configure(with: shareprices)
        title = Localizable.companyAboutSharepricesTitle.localized
    }
}
