//
//  CompanyAboutViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import MapKit

protocol CompanyAboutViewControllerDelegate: SharepriceCollectionViewDelegate, PagedViewControllerDelegate {}

class CompanyAboutViewController: BaseViewController<CompanyAboutViewModel>, UIScrollViewDelegate {

    weak var delegate: CompanyAboutViewControllerDelegate?
    
    private lazy var viewCreator = CompanyAboutView(withParentView: self.view)
    
    var data: CompanyAbout? {
        didSet {
            guard let data = data else { return }
            viewCreator.configure(with: data)
        }
    }
    
    init(delegate: CompanyAboutViewControllerDelegate) {
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.companyAboutTitle.localized }
        set {}
    }
    
    override func setupView() {
        viewCreator.setupView()
        viewCreator.delegate = self
        viewCreator.scrollView.delegate = self
        viewCreator.sharepriceCollectionView.customDelegate = self
    }
    
    override func initializeView() {
        super.initializeView()
    }
    
    override func localize() {
        super.localize()
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        viewModel.companyAboutData
            .ignoreNil()
            .subscribe(onNext: { [weak self] companyAbout in
                self?.data = companyAbout
            }).disposed(by: disposeBag)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension CompanyAboutViewController: SharepriceCollectionViewDelegate {
    func showAllShareprices(with data: [Symbol]) {
        delegate?.showAllShareprices(with: data)
    }   
}

extension CompanyAboutViewController: CompanyAboutDelegate {
    
    func didTouchAddress(button: AddressButton) {
        if let gpsAddress = button.address as? GPSConvertible, button.address?.type == .location {
            MKMapItem.openMaps(for: gpsAddress)
            return
        }
        guard let url = button.address?.destinationUrl else { return }
        UIApplication.shared.openIfPossible(url)
    }
    
    func didTouchSocialMedia(button: SocialMediaButton) {
        guard let url = URL(string: button.socialMedia?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }
    
    func attachmentButtonDidTouch(button: AttachmentButton) {
        guard let url = URL(string: button.attachment?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }
        
}
