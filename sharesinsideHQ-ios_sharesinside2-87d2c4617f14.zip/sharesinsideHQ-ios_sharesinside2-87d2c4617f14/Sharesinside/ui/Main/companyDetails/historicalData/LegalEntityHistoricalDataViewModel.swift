//
//  CompanyAboutViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class LegalEntityHistoricalDataViewModel: BaseViewModel<HasCompaniesRepository & HasStartupsRepository & HasFundsRepository> {
    
    lazy var companiesRepository = dependencies.companiesRepository

    lazy var startupsRepository = dependencies.startupsRepository

    private lazy var fundsRepository = dependencies.fundsRepository
 
    let historicalData = BehaviorRelay<[HistoricalDataSection]>(value: [])
    
    func loadHistoricalData(ofLegalEntity legalEntity: LegalEntity) {
        dataSource(for: legalEntity)
            .observeOn(MainScheduler.asyncInstance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] data in self?.historicalData.accept(data) })
            .disposed(by: disposeBag)
    }

    private func dataSource(for legalEntity: LegalEntity) -> Observable<[HistoricalDataSection]> {
        switch legalEntity {
        case let .company(id):
            return companiesRepository.getHistoricalData(companyId: id)
        case let .startup(id):
            return startupsRepository.getHistoricalData(startupId: id)
        case let .fund(id):
            return fundsRepository.getDocuments(fundId: id)
        }
    }
}
