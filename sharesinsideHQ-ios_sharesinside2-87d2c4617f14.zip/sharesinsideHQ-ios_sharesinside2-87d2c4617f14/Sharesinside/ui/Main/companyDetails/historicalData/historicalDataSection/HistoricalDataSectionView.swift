//
//  HistoricalDataView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class HistoricalDataSectionView: BaseViewCreator {
    
    lazy var tableView: HistoricalDataSectionTableView = HistoricalDataSectionTableView()
    
    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
    }
    
    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func updateTableView(with state: HistoricalDataSectionState) {
        tableView.state = state
    }
}
