//
//  HistoricalDataSectionTableView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol HistoricalDataSectionTableViewDelegate: class {
    func shouldOpenUrl(from data: HistoricalData)
    func tableViewNeedsMoreData()
}

class HistoricalDataSectionTableView: UITableView {
    
    weak var customDelegate: HistoricalDataSectionTableViewDelegate?
    
    var state: HistoricalDataSectionState = .empty {
        didSet { reloadData() }
    }
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        registerCell(HistoricalDataTableViewCell.self)
        self.separatorStyle = .none
        self.tableFooterView = UIView()
        dataSource = self
        delegate = self
        
        estimatedRowHeight = Defaults.CompanyDetails.HistoricalData.estimatedRowHeight
        rowHeight = UITableView.automaticDimension
    }
    
}
extension HistoricalDataSectionTableView: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return state.currentData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: HistoricalDataTableViewCell = tableView.dequeueReusableCell(for: indexPath) {
            cell.configure(with: state.currentData[indexPath.row])
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        customDelegate?.shouldOpenUrl(from: state.currentData[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if Float(indexPath.row) >= (Float(state.currentData.count) * 0.7) {
            customDelegate?.tableViewNeedsMoreData()
        }
    }
}
