//
//  File.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

class HistoricalDataSectionViewController: BaseViewController<HistoricalDataSectionViewModel> {
    
    private lazy var viewCreator = HistoricalDataSectionView(withParentView: self.view)

    let legalEntity: LegalEntity
    let sectionId: Int
    let sectionTitle: String
    
    init(legalEntity: LegalEntity, sectionId: Int, sectionTitle: String) {
        self.legalEntity = legalEntity
        self.sectionId = sectionId
        self.sectionTitle = sectionTitle
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setupView() {
        navigationController?.setupNavigationBar()
        viewCreator.setupView()
    }
    
    override func initializeView() {
        super.initializeView()
        viewCreator.tableView.customDelegate = self
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.background]
        title = sectionTitle
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.legalEntity = legalEntity
        viewModel.sectionId = sectionId
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.historicalDataState
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] state in self?.viewCreator.updateTableView(with: state) })
            .disposed(by: disposeBag)
    }
}

extension HistoricalDataSectionViewController: HistoricalDataSectionTableViewDelegate {
    func tableViewNeedsMoreData() {
        viewModel.loadMoreData()
    }
    
    func shouldOpenUrl(from data: HistoricalData) {
        guard let url = URL.forQuery(using: data.file.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }
}
