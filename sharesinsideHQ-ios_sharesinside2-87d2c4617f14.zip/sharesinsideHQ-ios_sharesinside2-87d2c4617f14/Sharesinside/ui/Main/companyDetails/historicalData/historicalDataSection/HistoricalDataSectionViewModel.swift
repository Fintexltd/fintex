//
//  HistoricalDataSectionViewModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 06.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

enum HistoricalDataSectionState {
    case loading
    case paging([HistoricalData])
    case populated([HistoricalData])
    case empty
    case error(Error)
    
    var currentData: [HistoricalData] {
        switch self {
        case .paging(let data): return data
        case .populated(let data): return data
        default: return []
        }
    }
}

class HistoricalDataSectionViewModel: BaseViewModel<HasCompaniesRepository & HasStartupsRepository & HasFundsRepository> {
    
    var sectionId: Int?
    var legalEntity: LegalEntity?

    let historicalDataState = BehaviorRelay<HistoricalDataSectionState>(value: .loading)
    
    private let historicalDataResponses = BehaviorRelay<[HistoricalDataSectionResponse]>(value: [])
    
    private let moreDataNeedRelay = BehaviorRelay(value: 1)
    lazy var companiesRepository = dependencies.companiesRepository
    lazy var fundsRepository = dependencies.fundsRepository

    private lazy var startupsRepository = dependencies.startupsRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
    }
    
    private func loadData() {
        guard let legalEntity = legalEntity, let sectionId = sectionId else { return }
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.historicalDataState.accept(.loading) })
            .withLatestFrom(historicalDataResponses)
            .filter { responses -> Bool in
                guard let last = responses.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .flatMapLatest { previousResponses -> Observable<[HistoricalDataSectionResponse]> in
                let page = (previousResponses.last?.meta.currentPage ?? 0) + 1
                return self.dataSource(for: legalEntity, sectionId: sectionId, page: page)
                    .map { previousResponses + [$0] }
                    .do(
                        onNext: { [weak self] historicalDataResponses in self?.handle(responses: historicalDataResponses)
                    })
                    .catchError { [weak self] error in
                        let lastState = self?.historicalDataState.value
                        let newState = (lastState?.currentData.isEmpty == true) ? .error(error) : (lastState ?? .error(error))

                        self?.historicalDataState.accept(newState)
                        return Observable<[HistoricalDataSectionResponse]>.empty()
                }
            }
            .bind(to: historicalDataResponses)
            .disposed(by: disposeBag)
    }

    private func dataSource(for dataType: HistoricalDataType, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        switch dataType {
        case .company(let id):
            return self.companiesRepository.getHistoricalDataSection(companyId: id, sectionId: sectionId, page: page)
        case .fund(let id):
            return self.fundsRepository.getDocumentsDetails(fundId: id, sectionId: sectionId, page: page)
        }
    }
    
    private func handle(responses: [HistoricalDataSectionResponse]) {
        let historicalData = responses.flatMap { $0.data }.compactMap { $0 }
        if historicalData.isEmpty {
            self.historicalDataState.accept(.empty)
        } else if let last = responses.last, last.meta.currentPage < last.meta.lastPage {
            self.historicalDataState.accept(.paging(historicalData))
        } else {
            self.historicalDataState.accept(.populated(historicalData))
        }
        
    }

    private func dataSource(for legalEntity: LegalEntity, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        switch legalEntity {
        case let .company(id):
            return self.companiesRepository.getHistoricalDataSection(companyId: id, sectionId: sectionId, page: page)
        case let .startup(id):
            return self.startupsRepository.getHistoricalDataSection(startupId: id, sectionId: sectionId, page: page)
        case let .fund(id):
            return self.fundsRepository.getDocumentsDetails(fundId: id, sectionId: sectionId, page: page)
        }
    }
    
    func loadMoreData() {
        moreDataNeedRelay.accept(1)
    }
}
