//
//  LegalEntityAboutViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher

enum LegalEntity {
    case company(Int)
    case startup(Int)
    case fund(Int)
}

protocol LegalEntityHistoricalDataViewControllerDelegate: PagedViewControllerDelegate {
    func shouldShow(historicalDataSection: HistoricalDataSection)
}

class LegalEntityHistoricalDataViewController: BaseViewController<LegalEntityHistoricalDataViewModel> {
    
    private lazy var viewCreator = LegalEntityHistoricalDataView(withParentView: self.view)
    
    weak var delegate: LegalEntityHistoricalDataViewControllerDelegate?


    let legalEntity: LegalEntity
    
    init(legalEntity: LegalEntity, delegate: LegalEntityHistoricalDataViewControllerDelegate) {
        self.legalEntity = legalEntity
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("View controller shouldn't be initialized in this way.")
    }

    override var title: String? {
        get { return Localizable.legalEntityHistoricalDataTitle.localized }
        set {}
    }
    override func setupView() {
        viewCreator.setupView()
        viewCreator.tableView.customDelegate = self
    }
    
    override func bindRxLifecycle() {
        super.bindRxLifecycle()
        
        self.rx.firstTimeViewDidAppear
            .subscribe(
                onSuccess: { [weak self] in
                    guard let `self` = self else { return}
                    self.viewModel.loadHistoricalData(ofLegalEntity: self.legalEntity)})            .disposed(by: disposeBag)
    }
  
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.historicalData
            .subscribe(
                onNext: { [weak self] data in self?.viewCreator.configure(with: data) })
            .disposed(by: disposeBag)
    }
}

extension LegalEntityHistoricalDataViewController: HistoricalDataTableViewDelegate {
   
    func pagedScrollView(didScroll scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }

    func shouldShow(historicalDataSection: HistoricalDataSection) {
        delegate?.shouldShow(historicalDataSection: historicalDataSection)
    }
    
    func shouldOpenUrl(from data: HistoricalData) {
        guard let url = URL(string: data.file.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }
    
}
