//
//  CompanyAboutView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class LegalEntityHistoricalDataView: BaseViewCreator {

    lazy var tableView: HistoricalDataTableView = {
        let tableView = HistoricalDataTableView()
        return tableView
    }()
    
    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
    }
    
    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func configure(with historicalData: [HistoricalDataSection]) {
        tableView.sections = historicalData
        tableView.reloadData()
    }
}
