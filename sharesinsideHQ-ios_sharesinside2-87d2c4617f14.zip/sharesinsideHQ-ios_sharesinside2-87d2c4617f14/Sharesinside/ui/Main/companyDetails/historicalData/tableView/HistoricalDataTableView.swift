//
//  HistoricalDataTableView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol HistoricalDataTableViewDelegate: PagedViewControllerDelegate {
    func shouldOpenUrl(from data: HistoricalData)
    func shouldShow(historicalDataSection: HistoricalDataSection)
}

class HistoricalDataTableView: UITableView {
    
    weak var customDelegate: HistoricalDataTableViewDelegate?

    var sections: [HistoricalDataSection] = []
    
    private var maxItemsInSection: Int = 3
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        registerHeaderFooter(LabelledHeaderView.self)
        registerCell(HistoricalDataTableViewCell.self)
        registerHeaderFooter(SeeMoreTableViewFooter.self)
        
        self.separatorStyle = .none
        self.tableFooterView = UIView()
        self.estimatedRowHeight = Defaults.CompanyDetails.HistoricalData.estimatedRowHeight
        self.rowHeight = UITableView.automaticDimension
        
        dataSource = self
        delegate = self
    }
    
}
extension HistoricalDataTableView: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard section < sections.count else { return 0 }
        return min(maxItemsInSection, sections[section].data.count)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let header: LabelledHeaderView = tableView.dequeueReusableHeaderFooter(), shouldShowHeader(in: section) {
            header.title = sections[section].name
            return header
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: HistoricalDataTableViewCell = tableView.dequeueReusableCell(for: indexPath) {
            cell.configure(with: sections[indexPath.section].data[indexPath.row])
            
            let isLastElement = indexPath.row == tableView.numberOfRows(inSection: indexPath.section) - 1
            cell.dividerPadding = isLastElement ? 0 : Defaults.marginNormal
            
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if let footer: SeeMoreTableViewFooter = tableView.dequeueReusableHeaderFooter(), shouldShowFooter(in: section) {
            footer.delegate = self
            footer.section = section
            return footer
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return shouldShowHeader(in: section) ? UITableView.automaticDimension : 0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return shouldShowFooter(in: section) ? Defaults.seeMooreFooterHeight : 0
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        customDelegate?.pagedScrollView(didScroll: scrollView)
    }
    
    private func shouldShowHeader(in section: Int) -> Bool {
        guard section < sections.count else { return false }
        return !sections[section].data.isEmpty
    }
    
    private func shouldShowFooter(in section: Int) -> Bool {
        guard section < sections.count else { return false }
        return sections[section].data.count > maxItemsInSection
    }
}

extension HistoricalDataTableView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        customDelegate?.shouldOpenUrl(from: sections[indexPath.section].data[indexPath.row])
    }
}
extension HistoricalDataTableView: SeeMoreFooterDelegate {
   
    func seeMoreDidTouch(inSection section: Int) {
        customDelegate?.shouldShow(historicalDataSection: sections[section])
    }
}
