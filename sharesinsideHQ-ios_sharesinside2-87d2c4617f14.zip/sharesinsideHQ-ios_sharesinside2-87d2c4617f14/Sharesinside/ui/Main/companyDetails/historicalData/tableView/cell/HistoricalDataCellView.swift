//
//  HistoricalDataCellView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class HistoricalDataCellView: BaseViewCreator {
    
    lazy var itemTitleLabel = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.medium, fontWeight: .regular)
    
    lazy var publishedLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                     withFontSize: Defaults.TextSize.tiny)
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    lazy var fiscalLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                     withFontSize: Defaults.TextSize.tiny)
        label.textAlignment = .left
        return label
    }()
    
    lazy var subtitleStackView: UIStackView = UIStackView.make(
        axis: .vertical,
        with: [
            publishedLabel,
            fiscalLabel
        ],
        spacing: Defaults.marginMicro)

    lazy var contentStackView: UIStackView = UIStackView.make(
        axis: .vertical,
        with: [
            itemTitleLabel,
            subtitleStackView.embedInView()
        ],
        spacing: AppInfo.isIPad ? Defaults.marginSmall : 0)
    
    lazy var iconImageView: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = .primary
        imageView.image = #imageLiteral(resourceName: "IconAttachement")
        return imageView
    }()
    
    lazy var dividerView = UIView().layoutable()
    
    override func setupProperties() {
        itemTitleLabel.textAlignment = .left
        dividerView.backgroundColor = .grey
    }
    
    override func setupViewHierarchy() {
        [contentStackView, iconImageView, dividerView].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        let margin: CGFloat = (AppInfo.isIPad ? Defaults.marginTremendous : Defaults.marginTiny).negative()
        contentStackView.snp.makeConstraints { make in
            make.trailing.equalTo(iconImageView.snp.leading).inset(margin).priority(.highest)
            make.leading.top.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
        
        subtitleStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.lessThanOrEqualToSuperview()
        }
        
        iconImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().inset(Defaults.marginSmall)
            make.height.width.equalTo(Defaults.addressIconSize)
        }
        
        dividerView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
            make.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.bottom.trailing.equalToSuperview()
        }
    }
}
