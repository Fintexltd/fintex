//
//  HistoricalDataTableViewCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class HistoricalDataTableViewCell: UITableViewCell {
    
    private lazy var viewCreator = HistoricalDataCellView(withParentView: self)
    
    var dividerPadding: CGFloat = Defaults.marginNormal {
        didSet { setupDividerConstraints()}
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        viewCreator.setupView()
        selectionStyle = .none
    }
    
    func configure(with data: HistoricalData) {
        viewCreator.itemTitleLabel.text = data.title
        if let fiscalYear = data.fiscalYear {
            viewCreator.fiscalLabel.attributedText = attributedString(withLabel: Localizable.legalEntityHistoricalDataFiscal.localized,
                                                                  andValue: fiscalYear)
        } else {
            viewCreator.fiscalLabel.isHidden = true
        }
        viewCreator.publishedLabel.attributedText = attributedString(withLabel: Localizable.legalEntityHistoricalDataPublished.localized,
                                                           andValue: Date(timeIntervalSince1970: TimeInterval(data.timestamp)).toString())
        viewCreator.iconImageView.image = iconFor(mimeType: data.file.mimeType)
    }
    
    private func attributedString(withLabel label: String, andValue value: String) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: label,
            attributes: [
                .foregroundColor: UIColor.primaryDark,
                .font: UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .semibold)
            ])
        
        let attributedValue = NSAttributedString(string: value,
                                                 attributes: [.foregroundColor: UIColor.grey,
                                                              .font: UIFont.systemFont(ofSize: Defaults.TextSize.small)])
        
        attributedString.append(attributedValue)
        return attributedString
    }
    
    func setupDividerConstraints() {
        viewCreator.dividerView.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(dividerPadding)
            make.bottom.trailing.equalToSuperview().priority(.highest)
            make.height.equalTo(Defaults.dividerSize)
        }
    }
    
    private func iconFor(mimeType type: String) -> UIImage {
        if type.contains("image") { return #imageLiteral(resourceName: "IconPicture") }
        if type.contains("video") { return #imageLiteral(resourceName: "IconPlaySmall") }
        return #imageLiteral(resourceName: "IconAttachement")
    }
}
