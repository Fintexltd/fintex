//
//  CompanyAboutViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class CompanyHistoricalDataViewModel: BaseViewModel<HasCompaniesRepository & HasFundsRepository> {
    
    lazy var companiesRepository = dependencies.companiesRepository

    lazy var fundsRepository = dependencies.fundsRepository
 
    let historicalData = BehaviorRelay<[HistoricalDataSection]>(value: [])
    
    func loadHistoricalData(ofType dataType: HistoricalDataType) {
        dataSource(for: dataType)
            .observeOn(MainScheduler.asyncInstance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] data in self?.historicalData.accept(data) })
            .disposed(by: disposeBag)
    }

    private func dataSource(for dataType: HistoricalDataType) -> Observable<[HistoricalDataSection]> {
        switch dataType {
        case .company(let id):
            return companiesRepository.getHistoricalData(companyId: id)
        case .fund(let id):
            return fundsRepository.getDocuments(fundId: id)
        }
    }
}
