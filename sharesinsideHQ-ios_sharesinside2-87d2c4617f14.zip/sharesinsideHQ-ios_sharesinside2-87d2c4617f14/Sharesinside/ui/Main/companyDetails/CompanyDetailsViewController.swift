//
//  CompanyDetailsViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher

class CompanyDetailsViewController: BaseViewController<CompanyDetailsViewModel>, UIScrollViewDelegate, UINavigationControllerDelegate {
    
    private lazy var viewCreator = CompanyDetailsView(parentView: self.view, pagedViewControllers: pagedViewControllers)
    
    private var pagerLayoutNeedsReload = false
    private var pagerDataNeedsReload = true
    private var isAnimating = false
    private var isMenuShown = true
    
    private var childScrollView: UIScrollView!
    
    var companyId: Int

    lazy var pagedViewControllers: [UIViewController] = {
        return [UIViewController()]
    }()
    
    init(companyId: Int) {
        self.companyId = companyId
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
    }
    
    override func setupView() {
        self.view.backgroundColor = .primaryDark
        viewCreator.setupView()
        automaticallyAdjustsScrollViewInsets = false
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        viewCreator.updatePagedViewHeight(withNavigationBarHeight:
            (navigationController?.navigationBar.frame.height ?? 0) + Defaults.marginSmall)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pagerLayoutNeedsReload = true
        viewCreator.pagerView.viewControllers[viewCreator.pagerView.currentSelectedPage].viewWillTransition(to: size, with: coordinator)
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.companyId = companyId
    }
    
    override func initializeView() {
        super.initializeView()
        viewCreator.scrollView.delegate = self
        viewCreator.pagerView.delegate = self
        navigationController?.delegate = self
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.clear]
        viewCreator.followButton.addTarget(self, action: #selector(toogleFollowing), for: .touchUpInside)
        viewCreator.assignAsShareholderButton.addTarget(self, action: #selector(assignAsShareholder), for: .touchUpInside)
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.companyData
            .ignoreNil()
            .subscribe(onNext: { [weak self] companyAbout in
                guard let self = self else { return }
                self.configureHeader(with: companyAbout)
                if self.pagerDataNeedsReload {
                    self.initializePages(from: companyAbout.availableInformations)
                    self.updateCompanyAboutViewController(with: companyAbout)
                    self.pagerDataNeedsReload = false
                }
            }).disposed(by: disposeBag)

        viewModel.followingStateChangeAction
            .subscribe(onNext: { [weak self] state in
                guard let self = self else { return }
                MainFlowRxBus.companyFollowingStatePublishRelay
                    .accept(CompanyFollowingChangeModel(companyId: self.companyId, newFollowingState: state))
            }).disposed(by: disposeBag)
    }
    
    private func configureHeader(with companyData: CompanyAbout) {
        title = companyData.name
        viewCreator.companyTitle.text = companyData.name
        
        viewCreator.companyGroup.text = companyData.industry?.name
        if companyData.following != .changing {
            viewCreator.followButton.setTitle(companyData.following?.stateTitle, for: .normal)
        }
        
        if let logo = companyData.logo, let logoUrl = URL(string: logo) {
            viewCreator.companyLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }
        
        if let background = companyData.background, let logoUrl = URL(string: background) {
            viewCreator.backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }
        
        viewCreator.assignAsShareholderButton.isHidden = Config.isDemoAccount || !companyData.canAssignAsShareholder
        
        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.followButton.alpha = companyData.following == FollowingState.changing ? 0 : 1
            self.viewCreator.assignAsShareholderButton.alpha = 1
            self.viewCreator.followLoader.alpha = companyData.following != FollowingState.changing ? 0 : 1
        }
    }
    
    private func initializePages(from availableInformations: [Company.CompanyDetailsType]) {
        
        func buildViewControllerForDetails(ofType type: Company.CompanyDetailsType) -> UIViewController {
            switch type {
            case .aboutUs: return CompanyAboutViewController(delegate: self)
            case .ourTeam: return TeamViewController(teamType: .company(id: companyId), delegate: self)
            case .news: return PublicationsViewController(type: .companyNews(companyId: companyId), delegate: self)
            case .events: return PublicationsViewController(type: .companyEvents(companyId: companyId), delegate: self)
            case .historicalData: return LegalEntityHistoricalDataViewController(legalEntity: .company(companyId), delegate: self)
            case .gallery: return LegalEntityGalleryViewController(legalEntity: .company(companyId), delegate: self)
            case .charts: return CompanyChartsViewController(chartId: .companyId(companyId), delegate: self)
            }
        }
        
        pagedViewControllers = availableInformations.sorted { $0.hashValue < $1.hashValue }.compactMap { buildViewControllerForDetails(ofType: $0) }
        
        let initialPageIndex = pagedViewControllers.index(where: { type(of: $0) == PublicationsViewController.self }) ?? pagedViewControllers.index(where: { type(of: $0) == CompanyAboutViewController.self }) ?? 0
        viewCreator.pagerView.viewControllers = pagedViewControllers
        viewCreator.pagerView.setInitialPage(initialPageIndex)
        
        viewCreator.pagerView.layoutIfNeeded()
        UIView.animate(withDuration: Defaults.animationDuration, animations: { [weak self] in
            self?.viewCreator.pagerView.alpha = 1
        })
    }
    
    private func updateCompanyAboutViewController(with data: CompanyAbout) {
        if let companyAbout = viewCreator.findPagedViewController(type: CompanyAboutViewController.self) {
            companyAbout.data = data
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.scrollView.layoutIfNeeded()
        
        if pagerLayoutNeedsReload {
            pagerLayoutNeedsReload = false
            viewCreator.pagerView.reloadPagerCells()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard childScrollView.contentOffset.y < Defaults.CompanyDetails.minOffsetToAnimateHeader else { return }
        let goingUp = scrollView.panGestureRecognizer.translation(in: scrollView).y < 0
        guard goingUp == isMenuShown else { return }
        animateHeader(show: !goingUp)
    }
    
    private func animateHeader(show: Bool) {
        guard !isAnimating else {
            childScrollView.contentOffset.y = 0
            return
        }
        isAnimating = true
        let headerMaxContentYOffset = viewCreator.scrollView.contentSize.height - viewCreator.scrollView.frame.height
        
        viewCreator.contentStackView.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(show ? 0 : headerMaxContentYOffset.negative())
        }
        UIView.animate(withDuration: Defaults.headerAnimationDuration, animations: {
            self.view.layoutIfNeeded()
            self.updateHeaderAppearance(offset: show ? 0 : headerMaxContentYOffset)
            self.childScrollView.contentOffset.y = 0
        }, completion: { completed in
            self.isAnimating = !completed
            self.isMenuShown = show
        })
    }
    
    private func updateHeaderAppearance(offset: CGFloat) {
        let hoverViewAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.4)
        let titleAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.7)
        
        viewCreator.headerHoverView.alpha = hoverViewAlpha
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent.withAlpha(titleAlpha)]
    }
    
    @objc private func toogleFollowing() {
        viewModel.toogleCompanyFollowingState()
    }
    
    @objc private func assignAsShareholder() {
        viewModel.assignAsShareholder(delegate: self)
    }
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension CompanyDetailsViewController: ReinitializableViewController {
   
    func reinitializeView(with id: Int) {
        pagerDataNeedsReload = true
        companyId = id
        viewModel.reloadData(forCompanyWithId: id)
    }
}

extension CompanyDetailsViewController: PagerViewDelegate {
    
    func didChangeScrollView(_ scrollView: UIScrollView) {
        childScrollView = scrollView
    }
}

extension CompanyDetailsViewController: CompanyAboutViewControllerDelegate {
    
    func showAllShareprices(with data: [Symbol]) {
        viewModel.show(allShareprices: data)
    }
}

extension CompanyDetailsViewController: TeamViewControllerDelegate {
  
    func showEmployeeDetails(_ employee: Employee) {
        viewModel.show(detailsOf: employee)
    }
    
    func showAllEmployees(with data: EmployeesGroup) {
        viewModel.show(allEmployees: data, employeesDelegate: self)
    }
}

extension CompanyDetailsViewController: LegalEntityHistoricalDataViewControllerDelegate {
   
    func shouldShow(historicalDataSection: HistoricalDataSection) {
        viewModel.show(historicalDataSection: historicalDataSection)
    }
}

extension CompanyDetailsViewController: PublicationsViewControllerDelegate {
    
    func didSelect(publication: Publication) {
        viewModel.show(publication: publication)
    }
    
    func didTapShareButton(shareUrl: URL?) {
        shareNews(url: shareUrl)
    }
}

extension CompanyDetailsViewController: LegalEntityGalleryViewControllerDelegate {
   
    func didSelect(album: Album) {
        viewModel.show(albumDetails: album)
    }
    
    func didSelect(photo: Photo, inPhotos photos: [Photo]) {
        viewModel.show(photoPreview: photo, forPhotos: photos)
    }
}

extension CompanyDetailsViewController: PagedViewControllerDelegate {
    
    func pagedScrollView(didScroll scrollView: UIScrollView) {
        scrollViewDidScroll(scrollView)
    }
}

extension CompanyDetailsViewController: AssignAsShareholderViewControllerDelegate {
    
    func didSuccesfullyAsignAsShareholder() {
        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.assignAsShareholderButton.isHidden = true
            self.viewCreator.buttonsStackView.layoutIfNeeded()
        }
    }
}
