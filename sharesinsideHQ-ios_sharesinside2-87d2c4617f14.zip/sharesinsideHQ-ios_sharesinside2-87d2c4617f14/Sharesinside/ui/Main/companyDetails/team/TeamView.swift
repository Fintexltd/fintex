//
//  TeamView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class TeamView: BaseViewCreator {
    
    lazy var tableView: EmployeeGroupsTableView = {
        let tableView = EmployeeGroupsTableView()
        tableView.backgroundColor = .white
        tableView.separatorColor = .clear
        return tableView
    }()

    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
    }
    
    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func configure(with data: [EmployeesGroup]) {
        tableView.groups = data
        tableView.reloadData()
    }
}
