//
//  TeamViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class TeamViewModel: BaseViewModel<HasCompaniesRepository & HasFundManagersRepository & HasStartupsRepository> {

    var teamType: TeamType?
    
    lazy var companiesRepository = dependencies.companiesRepository
    lazy var fundManagersRepository = dependencies.fundManagersRepository
    lazy var startupsRepository = dependencies.startupsRepository
    let employeesData = BehaviorRelay<[EmployeesGroup]>(value: [])
    
    func loadEmployeeGroups() {
        let employeeGroup: Observable<[EmployeesGroup]>
        switch teamType {
        case .fundManager(let id):
            employeeGroup = fundManagersRepository.getEmployeesGroup(fundManagerId: id)
        case .company(let id):
            employeeGroup = companiesRepository.getEmployeesGroup(companyId: id)
        case .startup(let id):
            employeeGroup = startupsRepository.getEmployeesGroup(startupId: id)
        default:
            employeeGroup = Observable.empty()
        }
        employeeGroup
            .observeOn(MainScheduler.asyncInstance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(onNext: { [weak self] data in
                self?.employeesData.accept(data.filter({ !$0.data.isEmpty }))
            })
            .disposed(by: disposeBag)
    }
}
