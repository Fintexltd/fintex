//
//  TeamViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

protocol TeamViewControllerDelegate: EmployeeGroupsTableViewDelegate { }

enum TeamType {
    case company(id: Int)
    case fundManager(id: Int)
    case startup(id: Int)
}

class TeamViewController: BaseViewController<TeamViewModel> {

    weak var delegate: TeamViewControllerDelegate?
    private lazy var viewCreator = TeamView(withParentView: self.view)
    
    let teamType: TeamType
    
    init(teamType: TeamType, delegate: TeamViewControllerDelegate?) {
        self.teamType = teamType
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.companyTeamTitle.localized }
        set {}
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.teamType = teamType
    }
    
    override func setupView() {
        automaticallyAdjustsScrollViewInsets = false
        viewCreator.setupView()
        viewCreator.tableView.customDelegate = self
    }

    override func bindRxLifecycle() {
        super.bindRxLifecycle()
        
        self.rx.firstTimeViewDidAppear
            .subscribe(
                onSuccess: { [weak self] in
                    guard let `self` = self else { return}
                    self.viewModel.loadEmployeeGroups()})
            .disposed(by: disposeBag)
    }

    override func bindViewModel() {
        super.bindViewModel()
        viewModel.employeesData
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] in self?.viewCreator.configure(with: $0) })
            .disposed(by: disposeBag)
    }
}

extension TeamViewController: EmployeeGroupsTableViewDelegate {
    func pagedScrollView(didScroll scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
    
    func showEmployeeDetails(_ employee: Employee) {
        delegate?.showEmployeeDetails(employee)
    }
    
    func showAllEmployees(with data: EmployeesGroup) {
        delegate?.showAllEmployees(with: data)
    }
   
}
