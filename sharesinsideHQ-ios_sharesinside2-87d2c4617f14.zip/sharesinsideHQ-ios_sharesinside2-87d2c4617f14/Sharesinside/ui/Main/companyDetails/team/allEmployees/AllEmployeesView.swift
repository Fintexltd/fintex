//
//  AllEmployeesView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AllEmployeesView: BaseViewCreator {
    
    lazy var collectionView: EmployeesCollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = AppInfo.isIPad ? .horizontal : .vertical
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        let collectionView = EmployeesCollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.layoutable()
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.backgroundColor = .white
        return collectionView
    }()
    
    override func setupViewHierarchy() {
        parentView.addSubview(collectionView)
    }
    override func setupConstraints() {
        collectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func configure(with employees: [Employee]) {
        collectionView.employees = employees
    }
}
