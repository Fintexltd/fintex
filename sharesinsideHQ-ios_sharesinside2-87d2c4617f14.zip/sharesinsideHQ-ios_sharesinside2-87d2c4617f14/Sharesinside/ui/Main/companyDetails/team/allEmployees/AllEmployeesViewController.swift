//
//  AllEmployeesViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AllEmployeesViewController: BaseViewController<AllEmployeesViewModel> {
    
    weak var delegate: EmployeesDelegate?
    
    private lazy var viewCreator = AllEmployeesView(withParentView: self.view)
    
    let employeesGroup: EmployeesGroup
    
    init(group: EmployeesGroup, delegate: EmployeesDelegate) {
        self.delegate = delegate
        self.employeesGroup = group
        super.init(nibName: nil, bundle: nil)

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setupView() {
        viewCreator.setupView()
        viewCreator.configure(with: employeesGroup.data)
    }
    
    override func initializeView() {
        super.initializeView()
        title = employeesGroup.name
        viewCreator.collectionView.customDelegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar()
    }
}

extension AllEmployeesViewController: EmployeesDelegate {
    func showEmployeeDetails(_ employee: Employee) {
        delegate?.showEmployeeDetails(employee)
    }
    
}
