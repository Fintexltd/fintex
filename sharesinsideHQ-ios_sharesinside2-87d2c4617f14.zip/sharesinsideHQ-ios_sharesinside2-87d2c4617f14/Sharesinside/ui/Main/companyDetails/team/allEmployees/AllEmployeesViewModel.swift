//
//  AllEmployeesViewModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class AllEmployeesViewModel: BaseViewModel<HasCompaniesRepository> {

}
