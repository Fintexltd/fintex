//
//  EmployeeGroupsTableView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol EmployeeGroupsTableViewDelegate: EmployeesDelegate, PagedViewControllerDelegate {
    func showAllEmployees(with data: EmployeesGroup)
}

class EmployeeGroupsTableView: UITableView {
    
    weak var customDelegate: EmployeeGroupsTableViewDelegate?
    
    var groups: [EmployeesGroup] = []
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        dataSource = self
        delegate = self
        registerHeaderFooter(LabelledHeaderView.self)
        registerCell(EmployeesGroupTableViewCell.self)
        registerHeaderFooter(SeeMoreTableViewFooter.self)
        self.tableFooterView = UIView()
        estimatedRowHeight = Defaults.CompanyMember.cellHeight
        estimatedSectionHeaderHeight = Defaults.CompanyMember.headerHeight
    }
}

extension EmployeeGroupsTableView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return groups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: EmployeesGroupTableViewCell = tableView.dequeueReusableCell(for: indexPath) {
            let group = groups[indexPath.section]
            cell.configure(with: group.data, shouldBeCutted: shouldBeCutted(in: indexPath.section))
            cell.delegate = self
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let header: LabelledHeaderView = tableView.dequeueReusableHeaderFooter(), groups[section].name != "" {
            header.title = groups[section].name
            return header
        }
        return nil
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if let footer: SeeMoreTableViewFooter = tableView.dequeueReusableHeaderFooter(), shouldBeCutted(in: section) {
            footer.delegate = self
            footer.section = section
            return footer
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if !shouldBeCutted(in: section) { return 0 }
        return Defaults.seeMooreFooterHeight
    }
    
    func shouldBeCutted(in section: Int) -> Bool {
        return groups.count > section && groups[section].data.count > 4 && AppInfo.isIPhone
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        customDelegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension EmployeeGroupsTableView: SeeMoreFooterDelegate, EmployeesDelegate {
    func showEmployeeDetails(_ employee: Employee) {
        customDelegate?.showEmployeeDetails(employee)
    }
    
    func seeMoreDidTouch(inSection section: Int) {
        customDelegate?.showAllEmployees(with: groups[section])
    }
    
}
