//
//  EmployeeCellView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EmployeeCellView: BaseViewCreator {
    
    lazy var memberAvatar: UIImageView = {
        let imageView = CircleImageView()
        imageView.backgroundColor = .clear
        imageView.image = #imageLiteral(resourceName: "IconMemberPlaceholder")
        return imageView
    }()
    
    lazy var memberName: UILabel = {
     let label = UILabelFactory
        .styled(
            textColor: .black,
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .regular)
        label.numberOfLines = 2
        return label
    }()
    override func setupViewHierarchy() {
        [memberAvatar, memberName].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        
        memberAvatar.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(Defaults.marginSmall)
            make.leading.greaterThanOrEqualToSuperview().inset(Defaults.marginSmall)
            make.trailing.lessThanOrEqualToSuperview().inset(Defaults.marginSmall)
            make.centerX.equalToSuperview()
            make.height.equalTo(Defaults.Company.logoSize).priority(.high)
            make.width.equalTo(memberAvatar.snp.height)
        }
        
        memberName.snp.makeConstraints { make in
            make.top.equalTo(memberAvatar.snp.bottom)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginTiny)
            make.bottom.equalToSuperview()
            make.height.equalTo(Defaults.CompanyMember.nameLabelHeight)
        }
    }
}
