//
//  EmployeeGroupTableViewCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 26.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EmployeesGroupTableViewCell: UITableViewCell {
    
    weak var delegate: EmployeesDelegate?
    
    private lazy var collectionView: EmployeesCollectionView = {
        let collectionView = UICollectionView.makeCustomCollectionView(
            type: EmployeesCollectionView.self,
            scrollDirection: AppInfo.isIPad ? .horizontal : .vertical)
        collectionView.customDelegate = self
        collectionView.isScrollEnabled = AppInfo.isIPad
        collectionView.alwaysBounceVertical = false
        return collectionView
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    func configure(with data: [Employee], shouldBeCutted: Bool) {
        configureCollectionView(data, cut: shouldBeCutted)
        [collectionView, dividerView].forEach { contentView.addSubview($0) }
        setupConstraints()
    }
    
    private func configureCollectionView(_ data: [Employee], cut: Bool) {
        collectionView.employees = []
        var employees = data
        if cut { employees = sliceEmployees(data) }
        collectionView.employees = employees
        setupEmployeesCollectionViewHeight(collectionView)
    }
    
    private func sliceEmployees(_ data: [Employee]) -> [Employee] {
        return Array(data[0...3])
    }
    
    private func setupEmployeesCollectionViewHeight(_ collectionView: EmployeesCollectionView) {
        collectionView.snp.remakeConstraints { make in
            make.height.equalTo(collectionView.contentHeight).priority(.highest)
        }
        contentView.layoutIfNeeded()
    }
    
    private func setupConstraints() {
        collectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        dividerView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.bottom.trailing.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
    }
}

extension EmployeesGroupTableViewCell: EmployeesDelegate {
    
    func showEmployeeDetails(_ employee: Employee) {
        delegate?.showEmployeeDetails(employee)
    }
}
