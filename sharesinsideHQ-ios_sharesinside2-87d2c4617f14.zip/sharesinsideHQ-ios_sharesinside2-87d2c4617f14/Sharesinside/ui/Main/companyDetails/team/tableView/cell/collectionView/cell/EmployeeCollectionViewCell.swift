//
//  TeamMemberCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class EmployeeCollectionViewCell: UICollectionViewCell {
    
    private lazy var viewCreator = EmployeeCellView(withParentView: self.contentView)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    override func prepareForReuse() {
        viewCreator.memberAvatar.image = #imageLiteral(resourceName: "IconMemberPlaceholder")
    }
    
    private func initializeView() {
        viewCreator.setupView()
        backgroundColor = .white
    }
    
    func configure(with data: Employee) {
        viewCreator.memberName.text = data.name
        
        if let url = URL(string: data.photoUrl) {
            setImage(imgUrl: url)
        }
    }
    
    private func setImage(imgUrl: URL) {
        viewCreator.memberAvatar.kf.setImage(with: ImageResource(downloadURL: imgUrl), options: [.backgroundDecode])
    }
}
