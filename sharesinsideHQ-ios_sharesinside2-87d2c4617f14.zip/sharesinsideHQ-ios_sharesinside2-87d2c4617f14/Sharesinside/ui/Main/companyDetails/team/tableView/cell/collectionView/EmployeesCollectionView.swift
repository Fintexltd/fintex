//
//  EmployeesCollectionView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 25.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol EmployeesDelegate: class {
    func showEmployeeDetails(_ employee: Employee)
}

class EmployeesCollectionView: UICollectionView {

    weak var customDelegate: EmployeesDelegate?
    
    var employees: [Employee] = [] {
        didSet {
            reloadData()
        }
    }

    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        backgroundColor = .white
        registerCell(EmployeeCollectionViewCell.self)
        dataSource = self
        delegate = self
    }
}

extension EmployeesCollectionView: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return employees.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: EmployeeCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.configure(with: employees[indexPath.row])
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        customDelegate?.showEmployeeDetails(employees[indexPath.row])
    }
}

extension EmployeesCollectionView: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let iPadWidth: CGFloat = Defaults.CompanyMember.cellWidth
        let iPhoneWidth: CGFloat = collectionView.frame.width / 2
        return CGSize(width: AppInfo.isIPad ? iPadWidth : iPhoneWidth, height: Defaults.CompanyMember.cellHeight)
    }
}

extension EmployeesCollectionView {
    
    var cellHeight: CGFloat {
        if employees.isEmpty { return 0 }
        return Defaults.CompanyMember.cellHeight
    }
    
    var contentHeight: CGFloat {
        if employees.isEmpty { return 0 }
        if employees.count <= 2 || AppInfo.isIPad { return cellHeight }
        return cellHeight * 2
    }
}
