//
//  EmployeeDetailsCell.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 14/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EmployeeDetailsCell: UITableViewCell {
    
    lazy var contentLabel = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.medium, fontWeight: .regular)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initView() {
        contentView.addSubview(contentLabel)
        contentLabel.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginBig)
        }
    }
    
    func configure(with attributtedText: NSAttributedString) {
        contentLabel.attributedText = attributtedText
    }
}
