//
//  EmployeeDetailsViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol EmployerData {
    var name: String? { get }
    var background: String? { get }
}

class EmployeeDetailsViewController: BaseViewController<EmployeeDetailsViewModel>, UIScrollViewDelegate {
    
    private lazy var viewCreator = EmployeeDetailsView(withParentView: self.view)
    private lazy var tableController = EmployeeDetailsTableViewController(tableView: viewCreator.descriptionTableView)
    var employee: Employee!
    var employerData: EmployerData?
 
    var isAnimating: Bool = false
    var isHeaderHidden: Bool = true
    
    init(employee: Employee, employerData: EmployerData?) {
        self.employee = employee
        self.employerData = employerData
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
        view.layoutIfNeeded()
    }

    override func setupView() {
        viewCreator.setupView()
        title = employee.name
        viewCreator.delegate = self
        tableController.delegate = self
        viewCreator.scrollView.delegate = self
        automaticallyAdjustsScrollViewInsets = false
        
    }
    
    override func initializeView() {
        super.initializeView()
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.clear]
        configure()
    }
    
    func configure() {
        tableController.employeeData = employee.details
        viewCreator.headerView.configure(with: employee, employerData: employerData)
        viewCreator.headerView.layoutIfNeeded()
        viewCreator.setupTableViewHeader(for: employee)
        tableController.reloadData()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
    guard viewCreator.descriptionTableView.contentOffset.y < Defaults.CompanyDetails.minOffsetToAnimateHeader else { return }
    let goingUp = scrollView.panGestureRecognizer.translation(in: scrollView).y < 0
    guard goingUp == isHeaderHidden else { return }
    animateHeader(show: !goingUp)
    }
    
    private func animateHeader(show: Bool) {
        let hoverAlpha: CGFloat = show ? 0 : 1
        let informationAlpha: CGFloat = show ? 1 : 0
        guard !isAnimating else {
            viewCreator.descriptionTableView.contentOffset.y = 0
            return
        }
        isAnimating = true
        
        let headerMaxContentOffset = viewCreator.scrollView.contentSize.height - viewCreator.scrollView.frame.height - Defaults.CompanyMember.headerHoverHeight
        
        viewCreator.headerContainer.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(show ? 0 : headerMaxContentOffset.negative())
        }
        
        UIView.animate(withDuration: Defaults.headerAnimationDuration, animations: {
            self.view.layoutIfNeeded()
            self.viewCreator.descriptionTableView.contentOffset.y = 0
            self.viewCreator.headerHoverView.alpha = hoverAlpha
            self.viewCreator.headerView.alpha = informationAlpha
            self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent.withAlpha(hoverAlpha)]
        }, completion: { completed in
            self.isAnimating = !completed
            self.isHeaderHidden = show
        })
    }
}

extension EmployeeDetailsViewController: EmployeeDetailsViewDelegate {
    
    func didTouchAddress(button: AddressButton) {
        UIApplication.shared.openIfPossible(button.address?.destinationUrl)
    }
}

extension EmployeeDetailsViewController: EmployeeDetailsTableViewControllerDelegate {
    
    func didScroll(with scrollView: UIScrollView) {
        scrollViewDidScroll(scrollView)
    }
}
