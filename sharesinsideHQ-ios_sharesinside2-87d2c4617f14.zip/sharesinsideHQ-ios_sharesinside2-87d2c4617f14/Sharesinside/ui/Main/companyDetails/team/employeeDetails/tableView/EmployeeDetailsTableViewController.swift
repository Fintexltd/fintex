//
//  EmployeeDetailsTableViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 14/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol EmployeeDetailsTableViewControllerDelegate: class {
    func didScroll(with scrollView: UIScrollView)
}

class EmployeeDetailsTableViewController: NSObject {
    
    weak var delegate: EmployeeDetailsTableViewControllerDelegate?
    
    let tableView: UITableView
    
    var employeeData: [EmployeeDetailsData] = []
    
    init(tableView: UITableView) {
        self.tableView = tableView
        super.init()
        self.tableView.registerCell(EmployeeDetailsCell.self)
        self.tableView.registerHeaderFooter(LabelledHeaderView.self)
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.rowHeight = UITableView.automaticDimension
    }
    
    func reloadData() {
        tableView.reloadData()
    }
    
}

extension EmployeeDetailsTableViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return employeeData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: EmployeeDetailsCell = tableView.dequeueReusableCell(for: indexPath) {
            cell.configure(with: employeeData[indexPath.section].attributtedText)
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if let header: LabelledHeaderView = tableView.dequeueReusableHeaderFooter() {
            header.title = employeeData[section].type.localizedTitle
            return header
        }
        return UIView()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.didScroll(with: scrollView)
    }
}
