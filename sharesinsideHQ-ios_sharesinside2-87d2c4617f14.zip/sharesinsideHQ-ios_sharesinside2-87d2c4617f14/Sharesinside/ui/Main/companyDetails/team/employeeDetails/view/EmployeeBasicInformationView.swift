//
//  EmployeeDetailsHeaderView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 14/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class EmployeeDetailsHeaderView: BaseView {
    
    lazy var employeeAvatar: UIImageView = {
        let imageView = CircleImageView()
        imageView.backgroundColor = .clear
        imageView.image = #imageLiteral(resourceName: "IconMemberPlaceholder")
        return imageView
    }()
    
    lazy var employeeName: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        return label
    }()
    
    lazy var employeeCompany = UILabelFactory.styled(withFontSize: Defaults.TextSize.small)
    
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        return imageView
    }()
    
    lazy var gradientView: GradientView = {
        let gradientView = GradientView()
        gradientView.initWith(colors: [
            UIColor.primaryDark.withAlphaComponent(0.01).cgColor,
            UIColor.primaryDark.withAlphaComponent(0.5).cgColor,
            UIColor.primaryDark.cgColor
            ], locations: [0.0, 0.3, 0.8])
        
        return gradientView
    }()
    
    lazy var basicInformationStackView = UIStackView.make(
        axis: .vertical,
        with: [
            employeeAvatar.embedInView(),
            employeeName,
            employeeCompany
        ],
        spacing: Defaults.marginTiny)
    
    override func setupViewHierarchy() {
        addSubview(backgroundImage)
        addSubview(gradientView)
        addSubview(basicInformationStackView)

    }
    
    override func setupConstraints() {
        employeeAvatar.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(Defaults.CompanyDetails.logoTopMargin)
            make.centerX.equalToSuperview()
            make.width.equalTo(Defaults.Company.logoSize)
            make.height.equalTo(employeeAvatar.snp.width)
        }
        
        basicInformationStackView.snp.makeConstraints { make in
            let bottomMargin = AppInfo.isIPhone ? Defaults.marginSmall : Defaults.marginTremendous
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().inset(bottomMargin)
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        gradientView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func configure(with employee: Employee, employerData: EmployerData?) {
        employeeName.text = employee.name
        employeeCompany.text = employerData?.name
        updateImages(avatarImagePath: employee.photoUrl, companyBackgroundImagePath: employerData?.background)
    }
    
    private func updateImages(avatarImagePath avatar: String?, companyBackgroundImagePath company: String?) {
        if let avatarURL = URL(string: avatar) {
            employeeAvatar.kf.setImage(with: ImageResource(downloadURL: avatarURL), options: [.backgroundDecode])
        }
        if let companyBackgroundURL = URL(string: company) {
            backgroundImage.kf.setImage(with: ImageResource(downloadURL: companyBackgroundURL))
        }
    }
}
