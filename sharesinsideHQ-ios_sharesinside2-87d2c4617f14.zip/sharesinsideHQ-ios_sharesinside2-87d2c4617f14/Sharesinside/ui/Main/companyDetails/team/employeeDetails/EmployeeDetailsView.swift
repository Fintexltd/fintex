//
//  EmployeeDetailsView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol EmployeeDetailsViewDelegate: AddressButtonDelegate {}

class EmployeeDetailsView: BaseViewCreator {
    
    weak var delegate: EmployeeDetailsViewDelegate?
    
    lazy var headerView: EmployeeDetailsHeaderView = {
        return EmployeeDetailsHeaderView()
    }()
    
    lazy var headerContainer = headerView.embedInView()
    
    lazy var descriptionTableView: UITableView = {
        let tableView = UITableView()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.separatorColor = .clear
        tableView.bounces = true
        return tableView
    }()
    
    lazy var attachmentsStackView: UIStackView = UIStackView.make(axis: AppInfo.isIPad ? .horizontal : .vertical, with: [])
    
    lazy var headerHoverView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .primaryDark
        view.alpha = 0
        
        return view
    }()
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        }
        scrollView.bounces = false
        return scrollView
    }()
    
    lazy var contentContainer: UIStackView = .make(axis: .vertical, with: [headerContainer, descriptionTableView])
    
    override func setupProperties() {
        headerContainer.backgroundColor = .primaryDark
        descriptionTableView.backgroundColor = .clear
    }
    
    override func setupViewHierarchy() {
        scrollView.addSubview(contentContainer)
        parentView.addSubview(scrollView)
        parentView.addSubview(headerHoverView)
    }
    
    override func setupConstraints() {
        
        headerView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        headerHoverView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(Defaults.CompanyMember.headerHoverHeight)
        }
        contentContainer.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        scrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        descriptionTableView.snp.makeConstraints { make in
            make.height.equalTo(parentView)
        }
    }
    
    func setupTableViewHeader(for employee: Employee) {
        addressButtons(for: employee).forEach {
            attachmentsStackView.addArrangedSubview($0)
        }
        let container = attachmentsStackView.embedInView()
        container.translatesAutoresizingMaskIntoConstraints = true
        attachmentsStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.center.equalToSuperview()
        }
        descriptionTableView.layoutableTableHeaderView(header: container)
    }
    
    private func addressButtons(for employee: Employee) -> [AddressButton] {
        let buttons = employee.additionalInformation
            .compactMap { AddressButton.make(from: $0, target: self, selector: #selector(addressButtonDidTouch(_:)))}
        buttons.forEach {
            $0.style = AddressButton.Style.transparentDark
            $0.textLabel.numberOfLines = 1
        }
        return buttons
    }
    
    @objc func addressButtonDidTouch(_ button: AddressButton) {
        delegate?.didTouchAddress(button: button)
    }
}
