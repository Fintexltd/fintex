//
//  CompanyDetailsView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CompanyDetailsView: BaseViewCreator {

    var pagerView: PagerView!

    // MARK: Company basic information
    lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)

        return imageView
    }()

    lazy var gradientView: GradientView = {
        let view = GradientView()
        view.backgroundColor = UIColor.primaryDark.withAlpha(0.4)
        view.initWith(colors: [
            UIColor.primaryDark.withAlphaComponent(0.01).cgColor,
            UIColor.primaryDark.withAlphaComponent(0.5).cgColor,
            UIColor.primaryDark.cgColor
            ], locations: [0.0, 0.3, 0.8])
        return view
    }()

    lazy var companyLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .clear
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        return imageView
    }()

    lazy var companyTitle: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        return label
    }()

    lazy var companyGroup: UILabel = {
        let label = UILabelFactory.styled(withFontSize: Defaults.TextSize.small)
        return label
    }()

    // MARK: Buttons
    lazy var followButton: SharesinsideButton = {
        let button = SharesinsideButton()
        button.style = SharesinsideButton.Style.transparentWithBorder
        button.setTitle(Localizable.companyFollow.localized.uppercased(), for: .normal)
        button.setContentPriority(resistancePriority: UILayoutPriority.required.decreased(by: 1),
            resistanceAxis: .horizontal)
        button.setContentHuggingPriority(.defaultHigh, for: .vertical)
        button.alpha = 0
        return button
    }()

    lazy var followLoader: LoaderView = {
        let loader = LoaderView()
        loader.isSpinning = true
        loader.alpha = 0
        loader.spinnerView.circleLayer.strokeColor = UIColor.accent.cgColor

        return loader
    }()

    lazy var assignAsShareholderButton: SharesinsideButton = {
        let button = SharesinsideButton()
        button.style = SharesinsideButton.Style.transparentWithBorder
        button.updateTitleMargins(left: Defaults.marginSmall,
            right: Defaults.marginSmall)
        button.setTitle(Localizable.companyAssignAsShareholder.localized.uppercased(), for: .normal)
        button.alpha = 0
        return button
    }()

    lazy var buttonsStackView = UIStackView.make(
        axis: .horizontal,
        with: [
            [followLoader, followButton].embedInView(),
            assignAsShareholderButton
        ],
        spacing: Defaults.marginNormal)

    // MARK: Basic information ContentView
    lazy var basicInformationStackView = UIStackView.make(
        axis: .vertical,
        with: [companyLogo.embedInView(), companyTitle, companyGroup, buttonsStackView.embedInView()],
        spacing: Defaults.marginTiny)

    lazy var basicInformationView: UIView = {
        let view = UIView().layoutable()
        view.clipsToBounds = true
        view.backgroundColor = .primary
        return view
    }()

    // MARK: Header hover view
    lazy var headerHoverView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .primaryDark
        view.alpha = 0

        return view
    }()

    init(parentView: UIView, pagedViewControllers: [UIViewController]) {
        super.init(withParentView: parentView)
        pagerView = pagerView(with: pagedViewControllers)
    }

    required init(withParentView parent: UIView) {
        fatalError("Pager view has not been implemented")
    }

    // MARK: Scroll View
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        } 
        return scrollView
    }()

    lazy var contentStackView = UIStackView.make(
        axis: .vertical,
        with: [basicInformationView, pagerView],
        spacing: Defaults.marginNormal)

    private func pagerView(with viewControllers: [UIViewController]) -> PagerView {
        let pagerView = PagerView(with: viewControllers)
        pagerView.alpha = 0
        return pagerView
    }

    // MARK: Setup views in parent

    override func setupViewHierarchy() {
        [backgroundImage, gradientView, basicInformationStackView, headerHoverView].forEach { basicInformationView.addSubview($0) }
        [basicInformationView].forEach { contentStackView.addSubview($0) }

        scrollView.addSubview(contentStackView)
        [scrollView].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        setupBasicInformationConstraints()

        scrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }

        pagerView.snp.makeConstraints { make in
            make.height.equalTo(parentView.snp.height)
        }
    }

    private func setupBasicInformationConstraints() {
        companyLogo.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(Defaults.CompanyDetails.logoTopMargin)
            make.centerX.equalToSuperview()
            make.width.equalTo(Defaults.Company.logoSize)
            make.height.equalTo(companyLogo.snp.width)
        }

        basicInformationStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        backgroundImage.snp.makeConstraints { make in
            make.edges.equalTo(basicInformationStackView.snp.edges)
        }

        gradientView.snp.makeConstraints { make in
            make.edges.equalTo(basicInformationStackView.snp.edges)
        }

        buttonsStackView.snp.makeConstraints { make in
            make.leading.greaterThanOrEqualToSuperview().inset(Defaults.marginTiny)
            make.trailing.lessThanOrEqualToSuperview().inset(Defaults.marginTiny)
            make.top.equalToSuperview().offset(Defaults.marginMicro)
            make.bottom.equalToSuperview()
            make.centerX.equalToSuperview()
        }

        headerHoverView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        followButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        followLoader.snp.makeConstraints { make in
            make.edges.equalTo(followButton).inset(Defaults.marginMicro)
        }
    }
}

extension CompanyDetailsView {

    func findPagedViewController<T: UIViewController>(type: T.Type) -> T? {
        return pagerView.viewControllers.first(where: { $0 is T}) as? T
    }

    func updatePagedViewHeight(withNavigationBarHeight height: CGFloat) {
        pagerView.snp.updateConstraints { make in
            make.height.equalTo(parentView.snp.height).offset((height + UIWindow.safeAreaTopInset).negative())
        }
    }
}
