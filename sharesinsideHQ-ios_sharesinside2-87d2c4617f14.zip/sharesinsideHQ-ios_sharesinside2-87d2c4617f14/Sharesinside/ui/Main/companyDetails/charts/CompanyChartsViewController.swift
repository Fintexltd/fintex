//
//  CompanyAboutViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher
import Charts

enum ChartId {
    case fundId(Int)
    case companyId(Int)
}

class CompanyChartsViewController: BaseViewController<CompanyChartsViewModel>, UIScrollViewDelegate {

    weak var delegate: PagedViewControllerDelegate?
    
    private lazy var viewCreator = CompanyChartsView(withParentView: self.view)
    private let chartId: ChartId

    init(chartId: ChartId, delegate: PagedViewControllerDelegate?) {
        self.chartId = chartId
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        self.chartId = .companyId(-1)
        super.init(coder: aDecoder)
    }

    override var title: String? {
        get { return Localizable.companyChartsTitle.localized }
        set {}
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.scopeButtons.forEach { $0.addTarget(self, action: #selector(self.didTapScopeButton(_:)), for: .touchUpInside) }
        viewCreator.monthScopeButton.sendActions(for: .touchUpInside)
        viewCreator.scrollView.delegate = self
    }
    
    override func bindRxLifecycle() {
        super.bindRxLifecycle()
        
        self.rx.firstTimeViewDidAppear
            .subscribe(
                onSuccess: { [weak self] in
                    guard let `self` = self else { return}
                    self.viewModel.loadChartsData(withId: self.chartId)})
            .disposed(by: disposeBag)
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.chartsData
            .observeOn(MainScheduler.asyncInstance)
            .ignoreNil()
            .subscribe(
                onNext: { [weak self] data in self?.viewCreator.buildCharts(for: data) })
            .disposed(by: disposeBag)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        viewModel.loadChartsData(withId: chartId)
    }

    @objc private func didTapScopeButton(_ button: ChartScopeButton) {
        viewCreator.scopeButtons.forEach { $0.isSelected = false }
        button.isSelected = true
        viewCreator.charts.forEach { $0.present(button.scope) }
    }
 
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}
