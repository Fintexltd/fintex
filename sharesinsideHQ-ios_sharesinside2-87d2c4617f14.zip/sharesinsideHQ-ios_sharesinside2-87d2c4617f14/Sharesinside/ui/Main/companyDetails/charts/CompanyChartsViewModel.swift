//
//  CompanyAboutViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class CompanyChartsViewModel: BaseViewModel<HasCompaniesRepository & HasFundsRepository> {

    private lazy var companiesRepository = dependencies.companiesRepository

    private lazy var fundsRepository = dependencies.fundsRepository
    
    let chartsData = BehaviorRelay<CompanyCharts.CompanyChartsData?>(value: nil)
}

extension CompanyChartsViewModel {

    func loadChartsData(withId id: ChartId) {
        return dataSource(for: id)
            .observeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] in self?.chartsData.accept($0)})
            .disposed(by: disposeBag)
    }

    private func dataSource(for id: ChartId) -> Observable<CompanyCharts.CompanyChartsData> {
        switch id {
        case .fundId(let id):
            return fundsRepository.getChartsData(fundId: id)
        case .companyId(let id):
            return companiesRepository.getChartsData(companyId: id)
        }
    }
}
