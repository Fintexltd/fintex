//
//  CompanyAboutView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Charts

class CompanyChartsView: BaseViewCreator {
    
    weak var chartsDelegate: ChartViewDelegate?
    
    // MARK: Views
    
    lazy var contentView = UIStackView.make(
        axis: .vertical,
        with: [],
        spacing: 0)
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.backgroundColor = .background
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = true
        scrollView.isHidden = true
        return scrollView
    }()
    
    lazy var headerView: UIView = {
        let header = UIView().layoutable()
        header.backgroundColor = .white
        return header
    }()
    
    lazy var headerStackView: UIStackView = {
        let stackView = UIStackView().layoutable()
        stackView.axis = .horizontal
        stackView.spacing = Defaults.CompanyDetails.Charts.headerViewItemSpacing
        
        return stackView
    }()
    
    lazy var weekScopeButton: ChartScopeButton = buildScopeButton(for: .week)
    lazy var monthScopeButton: ChartScopeButton = buildScopeButton(for: .month)
    lazy var yearScopeButton: ChartScopeButton = buildScopeButton(for: .year)
    
    var scopeButtons: [ChartScopeButton] {
        return [weekScopeButton, monthScopeButton, yearScopeButton]
    }
    var charts: [ChartViewContainer] {
        return contentView.arrangedSubviews.filter { $0 is ChartViewContainer } as! [ChartViewContainer]
    }
    
    // MARK: Build methods
    
    func buildCharts(for data: CompanyCharts.CompanyChartsData) {
        func isValid(_ chartData: CompanyCharts.ChartData) -> Bool {
            return chartData.daysData.first(where: {$0.close != nil}) != nil
        }
        contentView.arrangedSubviews.forEach { subview in
            if subview is ChartViewContainer {
                subview.removeFromSuperview()
            }
        }
        scrollView.isHidden = false
        for chartData in data.charts {
            if isValid(chartData) {
                let chartViewContainer = buildChartView(for: chartData)
                contentView.addArrangedSubview(chartViewContainer)
                contentView.addArrangedSubview(buildSeparatorLine())
            }
        }
        parentView.layoutIfNeeded()
    }
    
    func buildChartView(for data: CompanyCharts.ChartData) -> ChartViewContainer {
        let chartViewContainer = ChartViewContainer(data: data)
        chartViewContainer.snp.makeConstraints { make in
            make.height.equalTo(400)
        }
        return chartViewContainer
    }
    
    func buildScopeDescriptionLabel() -> UILabel {
        let label = UILabel().layoutable()
        label.textColor = .grey
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .regular)
        label.text = Localizable.companyChartsScopeDescription.localized
        return label
    }
    
    func buildScopeButton(for scope: CompanyCharts.Scope) -> ChartScopeButton {
        let button = ChartScopeButton(for: scope).layoutable()
        return button
    }
    
    func buildSeparatorLine() -> UIView {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        view.snp.makeConstraints { make in
            make.height.equalTo(0.5)
        }
        return view
    }
    
    // MARK: Setup methods
    
    override func setupViewHierarchy() {
        parentView.addSubview(scrollView)
        scrollView.addSubview(contentView)
        contentView.addArrangedSubview(headerView)
        headerView.addSubview(headerStackView)
        headerStackView.addArrangedSubview(buildScopeDescriptionLabel())
        headerStackView.addArrangedSubview(weekScopeButton)
        headerStackView.addArrangedSubview(monthScopeButton)
        headerStackView.addArrangedSubview(yearScopeButton)
        contentView.addArrangedSubview(buildSeparatorLine())
    }
    
    override func setupConstraints() {
        
        scrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        let headerHeight = AppInfo.isIPad ? Defaults.CompanyDetails.Charts.headerViewHeightForIPad : Defaults.CompanyDetails.Charts.headerViewHeight
        headerView.snp.makeConstraints { make in
            make.height.equalTo(headerHeight)
        }
        
        headerStackView.snp.makeConstraints { make in
            if AppInfo.isIPad {
                make.left.equalToSuperview().offset(Defaults.marginSmall).priority(.low)
                make.centerY.equalToSuperview().offset(Defaults.marginSmall)
            } else {
                make.centerX.equalToSuperview().priority(.low)
                make.centerY.equalToSuperview()
            }
            make.left.greaterThanOrEqualToSuperview()
            make.right.lessThanOrEqualToSuperview().inset(Defaults.marginMicro)
            make.height.equalTo(Defaults.CompanyDetails.Charts.scopeButtonHeight)
        }
        
        scopeButtons.forEach { scopeButton in
            scopeButton.snp.makeConstraints { make in
                make.width.equalTo(Defaults.CompanyDetails.Charts.scopeButtonWidth)
            }
        }
    }
    
    override func setupProperties() {
        parentView.backgroundColor = .white
    }
}
