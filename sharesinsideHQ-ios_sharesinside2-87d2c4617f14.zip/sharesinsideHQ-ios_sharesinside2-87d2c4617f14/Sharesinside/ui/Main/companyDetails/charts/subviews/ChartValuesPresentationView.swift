//
//  ChartValuesPresentationView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 08/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class ChartValuesPresentationView: BaseView {
    
    // MARK: - Views
    
    private let scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.backgroundColor = .white
        scrollView.showsHorizontalScrollIndicator = false
        return scrollView
    }()
    private let stackView: UIStackView = {
        let stackView = UIStackView().layoutable()
        stackView.axis = .horizontal
        stackView.spacing = Defaults.marginMicro
        return stackView
    }()
    private lazy var dateLabel: UILabel = self.buildValueLabel()
    private lazy var openLabel: UILabel = self.buildDescriptionLabel(withText: Localizable.companyChartsValueOpen.localized)
    private lazy var openValueLabel: UILabel = self.buildValueLabel()
    private lazy var highLabel: UILabel = self.buildDescriptionLabel(withText: Localizable.companyChartsValueHigh.localized)
    private lazy var highValueLabel: UILabel = self.buildValueLabel()
    private lazy var lowLabel: UILabel = self.buildDescriptionLabel(withText: Localizable.companyChartsValueLow.localized)
    private lazy var lowValueLabel: UILabel = self.buildValueLabel()
    private lazy var closeLabel: UILabel = self.buildDescriptionLabel(withText: Localizable.companyChartsValueClose.localized)
    private lazy var closeValueLabel: UILabel = self.buildValueLabel()
    
    private var valueLabels: [UILabel] {
        return [openValueLabel, highValueLabel, lowValueLabel, closeValueLabel]
    }
    private var descriptionLabels: [UILabel] {
        return [openLabel, highLabel, lowLabel, closeLabel]
    }
    
    // MARK: - Building methods
    
    private func buildValueLabel() -> UILabel {
        let label = UILabel().layoutable()
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .bold)
        label.textColor = .primaryDark
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        return label
    }
    
    private func buildDescriptionLabel(withText text: String) -> UILabel {
        let label = UILabel().layoutable()
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .regular)
        label.textColor = .grey
        label.text = text
        return label
    }
    
    // MARK: - Setup methods
    
    override func setupViewHierarchy() {
        addSubview(dateLabel)
        addSubview(scrollView)
        scrollView.addSubview(stackView)
        stackView.addArrangedSubview(openLabel)
        stackView.addArrangedSubview(openValueLabel)
        stackView.addArrangedSubview(highLabel)
        stackView.addArrangedSubview(highValueLabel)
        stackView.addArrangedSubview(lowLabel)
        stackView.addArrangedSubview(lowValueLabel)
        stackView.addArrangedSubview(closeLabel)
        stackView.addArrangedSubview(closeValueLabel)
    }
    
    override func setupConstraints() {
        layoutable()
        
        dateLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(Defaults.marginSmall)
            make.left.equalToSuperview().offset(Defaults.marginSmall)
            make.height.equalTo(25)
        }
        
        scrollView.snp.makeConstraints { make in
            make.top.equalTo(dateLabel.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
        stackView.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(Defaults.marginSmall)
            make.right.equalToSuperview().inset(Defaults.marginSmall)
            make.top.bottom.equalToSuperview()
            make.height.equalTo(scrollView.snp.height)
        }
    }
    
    override func setupProperties() {
        backgroundColor = .white
    }
    
    private func prepareForUser(value: Double?, with currencyDescription: String) -> String {
        if  let value = value {
            return currencyDescription + value.cashFormat + " "
        }
        return "– "
    }
    
    private func getCurrencyDescription(from chartData: CompanyCharts.ChartData) -> String {
        return chartData.currencySymbol ?? chartData.currency + " "
    }
    
    // MARK: - Endpoints
    
    func present(_ data: CompanyCharts.StockDayData, from chartData: CompanyCharts.ChartData) {
        let currencyDescription = getCurrencyDescription(from: chartData)
        self.dateLabel.text = data.date.toString(withFromat: .watchlistDateFormat)
        self.highValueLabel.text = self.prepareForUser(value: data.high, with: currencyDescription)
        self.lowValueLabel.text = self.prepareForUser(value: data.low, with: currencyDescription)
        self.closeValueLabel.text = self.prepareForUser(value: data.close, with: currencyDescription)
        self.openValueLabel.text = self.prepareForUser(value: data.open, with: currencyDescription)
        layoutIfNeeded()
    }
}
