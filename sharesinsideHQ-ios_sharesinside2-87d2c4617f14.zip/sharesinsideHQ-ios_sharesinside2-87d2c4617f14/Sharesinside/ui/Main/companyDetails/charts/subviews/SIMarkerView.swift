//
//  SIMarkerView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 09/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit
import Charts

class SIMarkerView: MarkerView {
    
    private let CONTAINER_HEIGHT: CGFloat = 24
    private let WIDTH_OFFSET: CGFloat = Defaults.marginSmall
    private var textView: UITextView!
    private var valueSymbol: String = ""
    private var dataSource: [CompanyCharts.StockDayData]?
    
    init() {
        super.init(frame: .zero)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        self.backgroundColor = .grey
        buildTextLabel()
        setupConstraints()
    }
    
    private func buildTextLabel() {
        self.textView = UITextView().layoutable()
        self.textView.isUserInteractionEnabled = false
        self.textView.isScrollEnabled = false
        self.textView.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .semibold)
        self.textView.textColor = .white
        self.textView.textContainerInset = .init(top: 3, left: Defaults.marginTiny, bottom: 0, right: Defaults.marginTiny)
        self.textView.backgroundColor = self.backgroundColor
        self.textView.setContentHuggingPriority(.defaultLow, for: .horizontal)
        self.textView.setContentCompressionResistancePriority(.required, for: .horizontal)
        self.textView.textAlignment = .center
        addSubview(textView)
    }
    
    private func setupConstraints() {
        textView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalToSuperview()
        }
        self.snp.makeConstraints { make in
            make.height.equalTo(CONTAINER_HEIGHT)
            make.width.equalTo(textView.snp.width)
        }
    }
    
    override var offset: CGPoint {
        get {
            let xPos: CGFloat = super.offset.x - self.frame.width/2
            let yPos: CGFloat = -self.frame.height - Defaults.marginTiny
            return CGPoint(x: xPos, y: yPos)
        }
        set {
            super.offset = newValue
        }
    }
    
    func prepare(for chart: ChartViewBase, _ data: CompanyCharts.ChartData, with scope: CompanyCharts.Scope) {
        self.valueSymbol = data.currencySymbol ?? data.currency + " "
        self.dataSource = data.prepared(for: scope).daysData
    }
    
    override func refreshContent(entry: ChartDataEntry, highlight: Highlight) {
        guard let dayData = self.dataSource?[Int(entry.x)] else { return }
        self.textView?.text = valueSymbol + (dayData.close?.description ?? "")
        super.refreshContent(entry: entry, highlight: highlight)
        if let textView = textView, let font = textView.font {
            textView.frame.size.width = entry.x.description.width(withConstraintedHeight: CONTAINER_HEIGHT, font: font)
            self.frame.size.width = textView.frame.size.width
            layoutIfNeeded()
        }
    }
    
}
