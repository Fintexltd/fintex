//
//  ChartScopeButton.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 08/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class ChartScopeButton: UIButton {
    
    typealias ButtonStyle = (background: UIColor, foreground: UIColor, border: UIColor)
    
    enum Style {
        static let selected = ButtonStyle(background: .primary, foreground: .accent, border: .clear)
        static let notSelected = ButtonStyle(background: .grey, foreground: .accent, border: .clear)
    }
    
    var style: ButtonStyle = Style.notSelected {
        didSet {
            configureColors()
        }
    }
    
    let scope: CompanyCharts.Scope
    
    override var isSelected: Bool {
        didSet {
            updateStyle()
        }
    }
    
    override var isHighlighted: Bool {
        didSet {
            configureColors()
        }
    }
    
    init(for scope: CompanyCharts.Scope) {
        self.scope = scope
        super.init(frame: .zero)
        self.initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.scope = .year
        super.init(coder: aDecoder)
        self.initialize()
    }
    
    private func initialize() {
        layer.borderWidth = Defaults.buttonBorderWidth
        titleLabel?.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .semibold)
        cornerRadius(Defaults.Company.cellCornerRadius)
        configureColors()
        adjustToScope()
    }
    
    private func adjustToScope() {
        self.setTitle(scope.title, for: .normal)
    }
    
    func updateStyle() {
        style = isSelected ? Style.selected : Style.notSelected
    }
    
    func configureColors() {
        let alpha: CGFloat = isHighlighted ? 0.5 : 1
        backgroundColor = style.background.withAlpha(alpha)
        layer.borderColor = style.border.withAlpha(alpha).cgColor
        setTitleColor(style.foreground.withAlpha(alpha), for: .normal)
    }
}
