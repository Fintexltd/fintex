//
//  CompanyChartView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import UIKit
import Charts

class ChartViewContainer: BaseView, ChartViewDelegate {
    
    struct ChartEntries {
        let visibleEntries: [ChartDataEntry]
        let hiddenEntries: [ChartDataEntry]
    }
    
    // MARK: Properties

    private struct Constants {
        static let leftAxisMaxLabels = 7
        static let leftAxisXOffset: CGFloat = 10
        static let xAxisXOffset: CGFloat = -5
        static let xAxisYOffset: CGFloat = 10
        static let chartLineWidth: CGFloat = 1.5
        static let circleHoleRadius: CGFloat = 6
        static let chartCircleRadius: CGFloat = 8
        
        enum ChartXAxisLabelsCount: Int {
            case defaultValue = 6
            case ifIPad = 14
        }
    }
    
    private(set) var scope: CompanyCharts.Scope = .month
    private(set) var data: CompanyCharts.ChartData
    private var chartLine: LineChartDataSet?
    
    private lazy var xAxisValuesFormatter = DefaultAxisValueFormatter(block: { [weak self] (index, _) in
        guard let `self` = self else { return "" }
       
        let scopeData = self.data.prepared(for: self.scope)
        guard Int(index) < scopeData.daysData.count else { return "" }
        
        let dayData = scopeData.daysData[Int(index)]
        let dateString =  dayData.date.toString(withFromat: .chartFormat)
            
        return dateString
    })
    
    // MARK: - Views
    
    private var stackView: UIStackView = {
        let stackView = UIStackView().layoutable()
        stackView.axis = .vertical
        return stackView
    }()
    
    private lazy var chartDescriptionView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = UIColor.background
        return view
    }()
    
    private lazy var chartDescriptionLabel: UILabel = {
        let label = UILabel().layoutable()
        label.attributedText = prepareTextForDescription()
        return label
    }()
    
    private var chartValuesPresentationView = ChartValuesPresentationView()
    
    private lazy var chartContainer: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .white
        return view
    }()
    private lazy var chartView: LineChartView = buildChartView()
    
    // MARK: - Build methods
    
    private func buildSeparatorLine() -> UIView {
        let view = UIView()
        view.backgroundColor = .grey
        view.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        return view
    }
    
    private func buildChartView() -> LineChartView {
        let chartView = LineChartView()
        chartView.delegate = self
        chartView.backgroundColor = .white
        
        chartView.clipsToBounds = false
        chartView.gridBackgroundColor = .white
        chartView.extraTopOffset = Defaults.marginBig
        chartView.extraBottomOffset = Defaults.marginBig
        chartView.legend.enabled = false
        chartView.chartDescription?.enabled = false
        let marker = SIMarkerView()
        marker.chartView = chartView
        chartView.marker = marker
        chartView.doubleTapToZoomEnabled = false
        chartView.drawMarkers = true
        
        chartView.leftAxis.labelTextColor = .grey
        chartView.leftAxis.labelFont = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .regular)
        chartView.leftAxis.axisMaxLabels = Constants.leftAxisMaxLabels
        chartView.leftAxis.drawGridLinesEnabled = false
        chartView.leftAxis.drawAxisLineEnabled = false
        chartView.leftAxis.gridColor = .white
        chartView.leftAxis.xOffset = Constants.leftAxisXOffset
        chartView.leftAxis.valueFormatter = ChartLeftAxisFormatter()
        chartView.rightAxis.maxWidth = 20
        chartView.rightAxis.minWidth = 20
        chartView.rightAxis.drawAxisLineEnabled = false
        chartView.rightAxis.drawGridLinesEnabled = false
        chartView.rightAxis.labelTextColor = .clear
        chartView.rightAxis.drawLabelsEnabled = true
        chartView.rightAxis.drawZeroLineEnabled = false
        chartView.xAxis.gridColor = UIColor.grey.withAlpha(0.5)
        chartView.xAxis.labelPosition = .bottom
        chartView.xAxis.labelTextColor = .grey
        chartView.xAxis.granularityEnabled = true
        chartView.xAxis.xOffset = 0
        
        chartView.xAxis.yOffset = Constants.xAxisYOffset
        chartView.xAxis.drawAxisLineEnabled = false
        chartView.xAxis.drawGridLinesEnabled = true
        chartView.xAxis.labelFont = UIFont.systemFont(ofSize: Defaults.TextSize.tiny, weight: .regular)
        chartView.xAxis.valueFormatter = xAxisValuesFormatter

        let gestRec = UITapGestureRecognizer(target: self, action: #selector(didDoubleTapChartView(_:)))
        gestRec.cancelsTouchesInView = false
        gestRec.numberOfTapsRequired = 2
        
        chartView.addGestureRecognizer(gestRec)
        
        return chartView
    }
    
    func prepareTextForDescription() -> NSAttributedString {
        let text = NSMutableAttributedString()
        
        text.append(NSAttributedString(string: Localizable.companyChartsDescription.localized + " ",
                                       attributes: [
                                        .foregroundColor: UIColor.grey,
                                        .font: UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .regular)
                                        ]
        ))
        text.append(NSAttributedString(string: data.symbol,
                                       attributes: [
                                        .foregroundColor: UIColor.grey,
                                        .font: UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .bold)
                                        ]
        ))
        return text
    }
    
    // MARK: - Setup methods
    
    init(data: CompanyCharts.ChartData) {
        self.data = data
        super.init()
    }
    
    override func setupViewHierarchy() {
        addSubview(stackView)
        chartDescriptionView.addSubview(chartDescriptionLabel)
        chartContainer.addSubview(chartView)
        stackView.addArrangedSubview(chartDescriptionView)
        stackView.addArrangedSubview(buildSeparatorLine())
        stackView.addArrangedSubview(chartValuesPresentationView)
        stackView.addArrangedSubview(buildSeparatorLine())
        stackView.addArrangedSubview(chartContainer)
    }
    
    override func setupConstraints() {
        stackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        chartView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        chartDescriptionView.snp.makeConstraints { make in
            make.height.height.equalTo(Defaults.CompanyDetails.Charts.chartDescriptionViewHeight)
        }
        chartDescriptionLabel.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(Defaults.marginSmall)
            make.bottom.equalToSuperview().inset(Defaults.marginMicro)
        }
        chartValuesPresentationView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.CompanyDetails.Charts.chartSelectedDataValuesPresentationViewHeight)
        }

    }
    
    override func setupProperties() {
        self.updateChartViewData(for: .month)
    }
    
    // MARK: - Update chart view methods
    
    private func updateChartViewData(for scope: CompanyCharts.Scope) {
        self.scope = scope
        let scopeData = self.data.prepared(for: scope).daysData
        let chartEntries = getChartEntries(for: scope, from: scopeData)
        (chartView.marker as? SIMarkerView)?.prepare(for: chartView, data, with: scope)
        chartView.data = setupChartLine(basedOn: chartEntries, with: scope)
        let valueToHighlight = getValueToHighlight(basedOn: chartEntries)
        updateChartViewDesign(with: scopeData, highlight: valueToHighlight)
    }
    
    private func getChartEntries(for scope: CompanyCharts.Scope, from scopeData: [CompanyCharts.StockDayData]) -> ChartEntries {
        var visibleEntries: [ChartDataEntry] = []
        var hiddenEntries: [ChartDataEntry] = []
        scopeData.enumerated().forEach { index, dayData in
            let chartEntry = ChartDataEntry(x: Double(index), y: dayData.close ?? 1)
            dayData.close != nil ? visibleEntries.append(chartEntry) : hiddenEntries.append(chartEntry)
        }
        let firstVisibleXValue = visibleEntries.first?.x ?? 0.0
        if let lastEntry = visibleEntries.last {
            let lastVisible = max(1, lastEntry.y)
            hiddenEntries.forEach { $0.y = lastVisible }
        }
        hiddenEntries = hiddenEntries.filter { $0.x > firstVisibleXValue }
        return ChartEntries(visibleEntries: visibleEntries, hiddenEntries: hiddenEntries)
    }
    
    private func getValueToHighlight(basedOn entries: ChartEntries) -> Highlight {
        let lastValue: (value: Double, dataSetIndex: Int) = {
            let lastHiddenValue = entries.hiddenEntries.last?.x ?? 0
            let lastVisibleValue = entries.visibleEntries.last?.x ?? 0
            if lastHiddenValue > lastVisibleValue {
                return (lastHiddenValue, 1)
            } else {
                return (lastVisibleValue, 0)
            }
        }()
        return Highlight(x: lastValue.value, y: 0.0, dataSetIndex: lastValue.dataSetIndex)
    }
    
    private func setupChartLine(basedOn chartEntries: ChartEntries, with scope: CompanyCharts.Scope) -> LineChartData {
        let visibleDataSet = LineChartDataSet(values: chartEntries.visibleEntries, label: nil)
        visibleDataSet.setColor(.primary, alpha: 1)
        let shouldShowValueCircle = (scope == .week) || (AppInfo.isIPad && scope == .month)
        visibleDataSet.circleRadius = shouldShowValueCircle ? Constants.chartCircleRadius : 0
        visibleDataSet.setCircleColor(.white)
        visibleDataSet.highlightColor = .lightGray
        visibleDataSet.drawVerticalHighlightIndicatorEnabled = AppInfo.isIPhone
        visibleDataSet.drawHorizontalHighlightIndicatorEnabled = false
        visibleDataSet.drawValuesEnabled = false
        visibleDataSet.lineWidth = Constants.chartLineWidth
        visibleDataSet.circleHoleRadius = shouldShowValueCircle ? Constants.circleHoleRadius : 0
        visibleDataSet.circleHoleColor = .primary
        
        let hiddenDataSet = LineChartDataSet(values: chartEntries.hiddenEntries, label: nil)
        hiddenDataSet.setColor(.clear)
        hiddenDataSet.circleHoleColor = nil
        hiddenDataSet.highlightColor = .clear
        hiddenDataSet.drawVerticalHighlightIndicatorEnabled = false
        hiddenDataSet.drawHorizontalHighlightIndicatorEnabled = false
        hiddenDataSet.drawValuesEnabled = false
        hiddenDataSet.setCircleColor(.clear)
        hiddenDataSet.setDrawHighlightIndicators(false)
        hiddenDataSet.highlightEnabled = false
        
        return LineChartData(dataSets: [visibleDataSet, hiddenDataSet])
    }
    
    func updateChartViewDesign(with scopeData: [CompanyCharts.StockDayData], highlight valueToHighlight: Highlight) {
        let scope = CompanyCharts.Scope(rawValue: scopeData.count) ?? .year
        self.chartView.highlightValue(valueToHighlight, callDelegate: true)
        let labelsMaxCount: Int = {
            var constant: Constants.ChartXAxisLabelsCount {
                switch scope {
                case .week: return .defaultValue
                case .month: return AppInfo.isIPad ? .ifIPad : .defaultValue
                case .year: return AppInfo.isIPad ? .ifIPad : .defaultValue
                }
            }
            return constant.rawValue
        }()
        self.chartView.xAxis.axisMinLabels = 0
        self.chartView.xAxis.axisMaxLabels = labelsMaxCount
        self.chartView.xAxis.setLabelCount(labelsMaxCount, force: false)
        zoomOutChartView()
    }
    
    func zoomOutChartView() {
        chartView.zoomOut()
        if chartView.isFullyZoomedOut == false {
            zoomOutChartView()
        }
    }
    
    // MARK: - Endpoints
    
    func present(_ scope: CompanyCharts.Scope) {
        self.updateChartViewData(for: scope)
    }
    
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        let selectedData = data.prepared(for: scope).daysData[Int(entry.x)]
        chartValuesPresentationView.present(selectedData, from: data)
    }
    
    @objc func didDoubleTapChartView(_ sender: UITapGestureRecognizer) {
        zoomOutChartView()
    }
    
}
