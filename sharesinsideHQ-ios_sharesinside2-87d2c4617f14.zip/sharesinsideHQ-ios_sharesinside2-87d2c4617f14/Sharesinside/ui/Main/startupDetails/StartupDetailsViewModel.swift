//
//  StartupDetailsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 04/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class StartupDetailsViewModel: BaseViewModel<HasStartupsRepository> {

    var startupId: Int?
    let startupData = BehaviorRelay<StartupAbout?>(value: nil)
    let followingStateChangeAction = PublishRelay<FollowingState>()

    lazy var startupsRepository = dependencies.startupsRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        getStartupAboutData()
    }

    func reloadData(forStartupWithId id: Int) {
        startupId = id
        getStartupAboutData()
    }

    private func getStartupAboutData() {
        guard let startupId = startupId else {
            alert.accept(AlertData(message: Localizable.startupDetailsFetchError.localized,
                                   onPositiveTap: { self.router?.pop() }))
            return
        }
        startupsRepository.getStartupAbout(startupId: startupId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] startupAbout in
                    self?.startupData.accept(startupAbout) },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent) })
            .disposed(by: disposeBag)
    }

    func show(allShareprices data: [Symbol]) {
        router?.push(to: .allShareprices(shareprices: data))
    }

    func show(allEmployees employeesGroup: EmployeesGroup, employeesDelegate: EmployeesDelegate) {
        router?.push(to: .allEmployees(employeesGroup: employeesGroup, delegate: employeesDelegate))
    }

    func show(detailsOf employee: Employee) {
        router?.push(to: .employeeDetails(employee: employee, employerData: startupData.value))
    }

    func show(historicalDataSection: HistoricalDataSection) {
        guard let startupId = startupId else { return }
        router?.push(to: .historicalDataSection(legalEntity: .startup(startupId),
                                                sectionId: historicalDataSection.id,
                                                sectionTitle: historicalDataSection.name))
    }

    func show(publication: Publication) {
        switch publication.type {
        case .event: router?.push(to: .eventDetails(eventId: publication.watchlistableId))
        case .news: router?.push(to: .newsDetails(newsId: publication.watchlistableId))
        case .project: router?.push(to: .projectDetails(projectId: publication.watchlistableId))
        }
    }

    func show(albumDetails: Album) {
        router?.push(to: .albumDetails(album: albumDetails, legalEntityName: startupData.value?.name ?? ""))
    }

    func show(photoPreview: Photo, forPhotos photos: [Photo]) {
        guard let photoIndex = photos.firstIndex(where: { $0.id == photoPreview.id }) else { return }
        router?.present(destination: .photoPreview(legalEntityName: startupData.value?.name ?? "",
                                                   photos: photos,
                                                   initialIndex: photoIndex))
    }

    func assignAsInvestor(delegate: AssignAsInvestorViewControllerDelegate?) {
        guard let startupAbout = startupData.value else { return }
        router?.present(destination: .assignAsInvestor(investmentType: .startup(startupAbout), delegate: delegate))
    }
}

extension StartupDetailsViewModel {

    func toogleStartupFollowingState() {
        guard let startup = startupData.value else { return }
        startupsRepository.toggleFollowing(ofStartupWithId: startup.id, follow: startup.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(
                onSubscribe: { self.changeStartupFollowState(.changing, forStartup: startup) })
            .subscribe(
                onNext: { [weak self] _ in
                    self?.changeStartupFollowState(
                        startup.following == .following ? .notFollowing : .following, forStartup: startup) },
                onError: { [weak self] error in
                    self?.changeStartupFollowState(startup.following ?? .notFollowing, forStartup: startup)
                    self?.alert.accept(AlertData(message: error.localizedDescription))})
            .disposed(by: disposeBag)
    }

    private func changeStartupFollowState(_ state: FollowingState, forStartup startup: StartupAbout) {
        let updatedStartup = startup.with(followingState: state)
        followingStateChangeAction.accept(state)
        startupData.accept(updatedStartup)
    }
}
