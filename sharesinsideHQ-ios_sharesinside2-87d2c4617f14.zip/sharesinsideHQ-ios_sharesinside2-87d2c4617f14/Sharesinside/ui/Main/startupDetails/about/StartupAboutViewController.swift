//
//  StartupAboutViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 04/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import MapKit

class StartupAboutViewController: BaseViewController<StartupAboutViewModel>, UIScrollViewDelegate {

    weak var delegate: PagedViewControllerDelegate?

    private lazy var viewCreator = StartupAboutView(withParentView: self.view)

    var data: StartupAbout? {
        didSet {
            guard let data = data else { return }
            viewCreator.configure(with: data)
        }
    }

    init(delegate: PagedViewControllerDelegate) {
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.startupAboutTitle.localized }
        set {}
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.delegate = self
        viewCreator.scrollView.delegate = self
    }

    override func initializeView() {
        super.initializeView()
    }

    override func localize() {
        super.localize()
    }

    override func bindViewModel() {
        super.bindViewModel()
        viewModel.startupAboutData
            .ignoreNil()
            .subscribe(onNext: { [weak self] startupAbout in
                self?.data = startupAbout
            }).disposed(by: disposeBag)
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension StartupAboutViewController: StartupAboutDelegate {

    func didTouchAddress(button: AddressButton) {
        if let gpsAddress = button.address as? GPSConvertible, button.address?.type == .location {
            MKMapItem.openMaps(for: gpsAddress)
            return
        }
        guard let url = button.address?.destinationUrl else { return }
        UIApplication.shared.openIfPossible(url)
    }

    func didTouchSocialMedia(button: SocialMediaButton) {
        guard let url = URL(string: button.socialMedia?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }

    func attachmentButtonDidTouch(button: AttachmentButton) {
        guard let url = URL(string: button.attachment?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }

}
