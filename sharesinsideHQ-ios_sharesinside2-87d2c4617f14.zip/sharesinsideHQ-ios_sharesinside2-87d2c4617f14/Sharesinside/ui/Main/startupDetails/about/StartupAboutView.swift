//
//  StartupAboutView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

protocol StartupAboutDelegate: AddressButtonDelegate, SocialMediaButtonDelegate, AttachmentsViewDelegate { }

class StartupAboutView: BaseViewCreator {

    weak var delegate: StartupAboutDelegate?

    private let dividerTag = 1

    // MARK: Video view
    let videoView: NewsVideoView = {
        let view = NewsVideoView()
        return view
    }()

    lazy var addressStackView: UIStackView = .make(
        axis: AppInfo.isIPad ? .horizontal : .vertical,
        with: [],
        distribution: .fill)

    lazy var addressScrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false
        return scrollView
    }()

    lazy var descriptionTitleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark, withFontSize: Defaults.TextSize.big, fontWeight: .bold)
        label.textAlignment = .left
        return label
    }()

    lazy var descriptionContentLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.medium, fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()

    lazy var descriptionView = UIView().layoutable()

    lazy var socialMediaStackView: UIStackView = .make(
        axis: .horizontal,
        with: [],
        spacing: Defaults.StartupDetails.socialMediaMargin,
        alignment: .center,
        distribution: .equalSpacing)

    lazy var socialMediaView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .background
        return view
    }()

    lazy var attachmentsView: AttachmentsView = {
        let view = AttachmentsView()
        view.delegate = self
        return view
    }()

    lazy var linksView: AttachmentsView = {
        let view = AttachmentsView()
        view.delegate = self
        return view
    }()

    var horizontalDivider: UIView {
        let view = UIView.horizontalDivider
        view.tag = dividerTag
        return view
    }

    lazy var contentView = UIStackView.make(axis: .vertical, with: [])

    // MARK: Scroll View
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.decelerationRate = .fast
        scrollView.alwaysBounceVertical = true
        return scrollView
    }()

    override func setupViewHierarchy() {
        addressScrollView.addSubview(addressStackView)
        socialMediaView.addSubview(socialMediaStackView)
        [descriptionTitleLabel, descriptionContentLabel].forEach { descriptionView.addSubview($0) }
        scrollView.addSubview(contentView)
        parentView.addSubview(scrollView)
    }

    override func setupConstraints() {

        setupAddressConstraints()
        setupDescriptionConstraints()
        setupSocialMediaConstraints()

        scrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.height.equalToSuperview()
        }
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
    }

    private func setupAddressConstraints() {
        addressScrollView.snp.makeConstraints { make in
            make.height.equalTo(addressStackView.snp.height)
            if AppInfo.isIPhone { make.width.equalTo(addressStackView.snp.width) }
        }
        addressStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    private func setupDescriptionConstraints() {
        descriptionTitleLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().inset(Defaults.marginBig)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginSmall)
        }
        descriptionContentLabel.snp.makeConstraints { make in
            make.top.equalTo(descriptionTitleLabel.snp.bottom).offset(Defaults.marginSmall)
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
    }

    private func setupSocialMediaConstraints() {

        socialMediaView.snp.makeConstraints { make in
            make.height.equalTo(socialMediaStackView.snp.height)
        }
        socialMediaStackView.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
    }

    private func setupVideoConstraints() {
        videoView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.width.equalTo(videoView.snp.height).multipliedBy(2).priority(.highest)
        }
    }

}

extension StartupAboutView {

    func configure(with startup: StartupAbout) {
        cleanContentView()
        configureAddressView(with: startup)
        configureHeaderView(with: startup)
        configureDescriptionView(with: startup)
        configureSocialMediaView(with: startup)
        configureVideoView(with: startup)
        configureAttachmentsView(with: startup)
        configureLinksView(with: startup)
    }

    private func configureHeaderView(with startup: StartupAbout) {
        addHeaderView(
            title: Localizable.startupHeaderRaisedAmount.localized,
            text: "\(startup.raisedAmount)%"
        )

        if let startupCategory = startup.startupCategories.first?.name {
            addHeaderView(
                title: Localizable.startupHeaderstartupCategory.localized,
                text: startupCategory
            )
        }

        if let symbol = startup.currency.symbol {
            addHeaderView(
                title: Localizable.startupHeaderCurrency.localized,
                text: symbol
            )
        }
        addToContentView(addressScrollView)
    }

    private func addHeaderView(title: String, text: String) {
        guard !text.isEmpty else {
            return
        }
        let headerView = TitledLabelView()
        headerView.text = text
        headerView.title = title
        addressStackView.addArrangedSubview(headerView)
    }

    private func cleanContentView() {
        addressStackView.removeAllArrangedSubviews()
        socialMediaStackView.removeAllArrangedSubviews()
        attachmentsView.removeAllItems()
        linksView.removeAllItems()
        contentView.arrangedSubviews.forEach {
            if $0.tag == dividerTag { contentView.removeArrangedSubview($0) }
        }
    }

    private func configureAddressView(with startup: StartupAbout) {

        startup.addressInformation
            .compactMap { AddressButton.make(from: $0, target: self, selector: #selector(addressButtonDidTouch(_:))) }
            .forEach {
                addressStackView.addArrangedSubview($0)
        }

        if let lastCell = addressStackView.arrangedSubviews.last as? AddressButton {
            lastCell.hasDivider = false
        }
        addToContentView(addressScrollView)
        addressStackView.addArrangedSubview(horizontalDivider)
    }
    
    private func configureDescriptionView(with startup: StartupAbout) {
        guard startup.title != nil || startup.description != nil else { return }

        descriptionTitleLabel.attributedText = startup.title?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.big)
        descriptionContentLabel.attributedText = startup.description?.attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.medium)
        addToContentView(descriptionView)
    }

    private func configureSocialMediaView(with startup: StartupAbout) {
        guard !startup.socialMedia.isEmpty else { return }
        startup.socialMedia
            .compactMap { makeSocialMediaButton(for: $0) }
            .forEach { socialMediaStackView.addArrangedSubview($0) }
        socialMediaView.layoutIfNeeded()
        addToContentView(socialMediaView)
    }

    private func configureVideoView(with startup: StartupAbout) {
        guard let videoData = startup.videoData else {
            return
        }

        videoView.videoData = videoData
        addToContentView(videoView.embedInView())
        setupVideoConstraints()
    }

    private func configureAttachmentsView(with startup: StartupAbout) {
        guard !startup.attachments.isEmpty else { return }
        attachmentsView.configure(with: startup.attachments, title: "\(Localizable.attachments.localized) (\(startup.attachments.count))")
        addToContentView(attachmentsView)
    }

    private func configureLinksView(with startup: StartupAbout) {
        guard !startup.links.isEmpty else { return }
        linksView.configure(with: startup.links, title: "\(Localizable.links.localized) (\(startup.links.count))")
        addToContentView(linksView)
    }

    private func addToContentView(_ view: UIView) {
        contentView.addArrangedSubview(view)
        contentView.addArrangedSubview(horizontalDivider)
    }
}

extension StartupAboutView {

    private func makeSocialMediaButton(for socialMedia: SocialMedia) -> UIButton? {
        let button = SocialMediaButton()
        button.socialMedia = socialMedia
        button.addTarget(self, action: #selector(socialMediaButtonDidTouch(_:)), for: .touchUpInside)
        return button
    }
}

extension StartupAboutView: AttachmentsViewDelegate {
    func attachmentButtonDidTouch(button: AttachmentButton) {
        delegate?.attachmentButtonDidTouch(button: button)
    }

    @objc func addressButtonDidTouch(_ button: AddressButton) {
        delegate?.didTouchAddress(button: button)
    }

    @objc func socialMediaButtonDidTouch(_ button: SocialMediaButton) {
        delegate?.didTouchSocialMedia(button: button)
    }
}
