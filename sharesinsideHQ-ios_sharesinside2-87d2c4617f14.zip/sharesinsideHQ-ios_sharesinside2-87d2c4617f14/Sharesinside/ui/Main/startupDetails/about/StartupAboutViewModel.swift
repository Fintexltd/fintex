//
//  StartupAboutViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 06/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class StartupAboutViewModel: BaseViewModel<HasStartupsRepository> {

    let startupAboutData = BehaviorRelay<StartupAbout?>(value: nil)

}
