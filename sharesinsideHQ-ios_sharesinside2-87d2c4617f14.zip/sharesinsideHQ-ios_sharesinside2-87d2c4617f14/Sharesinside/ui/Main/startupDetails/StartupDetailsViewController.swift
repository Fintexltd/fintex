//
//  StartupDetailsViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 04/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher

class StartupDetailsViewController: BaseViewController<StartupDetailsViewModel>, UIScrollViewDelegate, UINavigationControllerDelegate {

    private lazy var viewCreator = StartupDetailsView(parentView: self.view, pagedViewControllers: pagedViewControllers)

    private var pagerLayoutNeedsReload = false
    private var pagerDataNeedsReload = true
    private var isAnimating = false
    private var isMenuShown = true

    private var childScrollView: UIScrollView!

    var startupId: Int

    lazy var pagedViewControllers: [UIViewController] = {
        return [UIViewController()]
    }()

    init(startupId: Int) {
        self.startupId = startupId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
    }

    override func setupView() {
        self.view.backgroundColor = .primaryDark
        viewCreator.setupView()
        automaticallyAdjustsScrollViewInsets = false
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        viewCreator.updatePagedViewHeight(withNavigationBarHeight:
            (navigationController?.navigationBar.frame.height ?? 0) + Defaults.marginSmall)
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pagerLayoutNeedsReload = true
        viewCreator.pagerView.viewControllers[viewCreator.pagerView.currentSelectedPage].viewWillTransition(to: size, with: coordinator)
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.startupId = startupId
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.scrollView.delegate = self
        viewCreator.pagerView.delegate = self
        navigationController?.delegate = self
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.clear]
        viewCreator.followButton.addTarget(self, action: #selector(toogleFollowing), for: .touchUpInside)
        viewCreator.assignAsInvestorButton.addTarget(self, action: #selector(assignAsInvestor), for: .touchUpInside)
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.startupData
            .ignoreNil()
            .subscribe(onNext: { [weak self] startupAbout in
                guard let self = self else { return }
                self.configureHeader(with: startupAbout)
                if self.pagerDataNeedsReload {
                    self.initializePages(from: startupAbout.availableInformations)
                    self.updateStartupAboutViewController(with: startupAbout)
                    self.pagerDataNeedsReload = false
                }
            }).disposed(by: disposeBag)

        viewModel.followingStateChangeAction
            .subscribe(onNext: { [weak self] state in
                guard let self = self else { return }
                MainFlowRxBus.startupFollowingStatePublishRelay
                    .accept(FollowingChangeModel(id: self.startupId, newFollowingState: state))
            }).disposed(by: disposeBag)
    }

    private func configureHeader(with startupData: StartupAbout) {
        title = startupData.name
        viewCreator.startupTitle.text = startupData.name

        viewCreator.startupGroup.text = startupData.industry?.name
        if startupData.following != .changing {
            viewCreator.followButton.setTitle(startupData.following?.stateTitle, for: .normal)
        }

        viewCreator.assignAsInvestorButton.isHidden = Config.isDemoAccount || !startupData.canAssignAsShareholder

        if let logo = startupData.logo, let logoUrl = URL(string: logo) {
            viewCreator.startupLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        if let background = startupData.background, let logoUrl = URL(string: background) {
            viewCreator.backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.followButton.alpha = startupData.following == FollowingState.changing ? 0 : 1
            self.viewCreator.assignAsInvestorButton.alpha = 1
            self.viewCreator.followLoader.alpha = startupData.following != FollowingState.changing ? 0 : 1
        }
    }

    private func initializePages(from availableInformations: [Startup.StartupDetailsType]) {

        func buildViewControllerForDetails(ofType type: Startup.StartupDetailsType) -> UIViewController {
            switch type {
            case .aboutUs: return StartupAboutViewController(delegate: self)
            case .ourTeam: return TeamViewController(teamType: .startup(id: startupId), delegate: self)
            case .news: return PublicationsViewController(type: .startupNews(startupId: startupId), delegate: self)
            case .events: return PublicationsViewController(type: .startupEvents(startupId: startupId), delegate: self)
            case .documents: return LegalEntityHistoricalDataViewController(legalEntity: .startup(startupId), delegate: self)
            case .gallery: return LegalEntityGalleryViewController(legalEntity: .startup(startupId), delegate: self)
            case .projects: return PublicationsViewController(type: .startupProjects(startupId: startupId), delegate: self)
            }
        }

        pagedViewControllers = availableInformations.sorted { $0.hashValue < $1.hashValue }.compactMap { buildViewControllerForDetails(ofType: $0) }

        let initialPageIndex = pagedViewControllers.index(where: { type(of: $0) == PublicationsViewController.self }) ?? pagedViewControllers.index(where: { type(of: $0) == UIViewController.self }) ?? 0
        viewCreator.pagerView.viewControllers = pagedViewControllers
        viewCreator.pagerView.setInitialPage(initialPageIndex)

        viewCreator.pagerView.layoutIfNeeded()
        UIView.animate(withDuration: Defaults.animationDuration, animations: { [weak self] in
            self?.viewCreator.pagerView.alpha = 1
        })
    }

    private func updateStartupAboutViewController(with data: StartupAbout) {
        if let startupAbout = viewCreator.findPagedViewController(type: StartupAboutViewController.self) {
            startupAbout.data = data
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.scrollView.layoutIfNeeded()

        if pagerLayoutNeedsReload {
            pagerLayoutNeedsReload = false
            viewCreator.pagerView.reloadPagerCells()
        }
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard childScrollView.contentOffset.y < Defaults.StartupDetails.minOffsetToAnimateHeader else { return }
        let goingUp = scrollView.panGestureRecognizer.translation(in: scrollView).y < 0
        guard goingUp == isMenuShown else { return }
        animateHeader(show: !goingUp)
    }

    private func animateHeader(show: Bool) {
        guard !isAnimating else {
            childScrollView.contentOffset.y = 0
            return
        }
        isAnimating = true
        let headerMaxContentYOffset = viewCreator.scrollView.contentSize.height - viewCreator.scrollView.frame.height

        viewCreator.contentStackView.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(show ? 0 : headerMaxContentYOffset.negative())
        }
        UIView.animate(withDuration: Defaults.headerAnimationDuration, animations: {
            self.view.layoutIfNeeded()
            self.updateHeaderAppearance(offset: show ? 0 : headerMaxContentYOffset)
            self.childScrollView.contentOffset.y = 0
        }, completion: { completed in
            self.isAnimating = !completed
            self.isMenuShown = show
        })
    }

    private func updateHeaderAppearance(offset: CGFloat) {
        let hoverViewAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.4)
        let titleAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.7)

        viewCreator.headerHoverView.alpha = hoverViewAlpha
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent.withAlpha(titleAlpha)]
    }

    @objc private func toogleFollowing() {
        viewModel.toogleStartupFollowingState()
    }

    @objc private func assignAsInvestor() {
        viewModel.assignAsInvestor(delegate: self)
    }

    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension StartupDetailsViewController: AssignAsInvestorViewControllerDelegate {
    func didSuccesfullyAsignAsInvestor() {
        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.assignAsInvestorButton.isHidden = true
            self.viewCreator.buttonsStackView.layoutIfNeeded()
        }
    }
}

extension StartupDetailsViewController: ReinitializableViewController {

    func reinitializeView(with id: Int) {
        pagerDataNeedsReload = true
        startupId = id
        viewModel.reloadData(forStartupWithId: id)
    }
}

extension StartupDetailsViewController: PagerViewDelegate {

    func didChangeScrollView(_ scrollView: UIScrollView) {
        childScrollView = scrollView
    }
}

extension StartupDetailsViewController: TeamViewControllerDelegate {

    func showEmployeeDetails(_ employee: Employee) {
        viewModel.show(detailsOf: employee)
    }

    func showAllEmployees(with data: EmployeesGroup) {
        viewModel.show(allEmployees: data, employeesDelegate: self)
    }
}

extension StartupDetailsViewController: LegalEntityHistoricalDataViewControllerDelegate {

    func shouldShow(historicalDataSection: HistoricalDataSection) {
        viewModel.show(historicalDataSection: historicalDataSection)
    }
}

extension StartupDetailsViewController: PublicationsViewControllerDelegate {

    func didSelect(publication: Publication) {
        viewModel.show(publication: publication)
    }

    func didTapShareButton(shareUrl: URL?) {
        shareNews(url: shareUrl)
    }
}

extension StartupDetailsViewController: LegalEntityGalleryViewControllerDelegate {

    func didSelect(album: Album) {
        viewModel.show(albumDetails: album)
    }

    func didSelect(photo: Photo, inPhotos photos: [Photo]) {
        viewModel.show(photoPreview: photo, forPhotos: photos)
    }
}

extension StartupDetailsViewController: PagedViewControllerDelegate {

    func pagedScrollView(didScroll scrollView: UIScrollView) {
        scrollViewDidScroll(scrollView)
    }
}
