//
//  CompaniesViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

class CompaniesViewController: BaseViewController<CompaniesViewModel>, PredefinedFiltersViewDelegate, UISearchBarDelegate {

    private lazy var viewCreator = CompaniesView(withParentView: self.view)
    private var needReloadItems: Bool = false

    override func setupView() {
        viewCreator.setupView()
        viewCreator.navigationView.setup(in: self.navigationItem)
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.collectionView.collectionViewDelegate = self
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        bindNavigationBarItems()
        viewCreator.filterView.delegate = self
        viewCreator.snackBar.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needReloadItems {
            needReloadItems = false
            viewCreator.collectionView.reloadSections(IndexSet(integer: 0))
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        needReloadItems = true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }

    // MARK: Binding
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.companiesState
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] state in
                    self?.endRefreshing()
                    self?.viewCreator.collectionView.state = state })
            .disposed(by: disposeBag)
        
        viewModel.filtersData
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] in
                    self?.viewCreator.filterView.configure(with: $0.filters, andSelectedCount: $0.selectedFilters)
            })
            .disposed(by: disposeBag)
        
        viewModel.showFollowAll
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] should in
                    if should {
                        self?.viewCreator.snackBar.show(withMessage: Localizable.companyFollowAll.localized)
                    } else {
                        self?.viewCreator.snackBar.hide()
                    }
            }).disposed(by: disposeBag)
    }

    private func bindNavigationBarItems() {
        viewCreator.navigationView.accountButton.rx
            .tap
            .asDriver()
            .drive(
                onNext: { [weak self] in self?.viewModel.moveToAccountInfoView()})
            .disposed(by: disposeBag)

        viewCreator.navigationView.searchBar.rx
            .text
            .asDriver()
            .debounce(Defaults.Search.delay)
            .ignoreNil()
            .drive(
                onNext: { [weak self] text in self?.viewModel.searchFor(fraze: text)})
            .disposed(by: disposeBag)
      
        viewCreator.navigationView.searchBar.rx
            .searchButtonClicked
            .asDriver()
            .drive(
                onNext: { [weak self] in self?.hideKeyboard() })
            .disposed(by: disposeBag)
    }

    @objc private func didSwipeForRefresh() {
        viewModel.refreshDataRandomly()
    }
    
    private func hideKeyboard() {
       viewCreator.navigationView.searchBar.resignFirstResponder()
    }

    private func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.refreshControl.endRefreshing()
        }
    }

    func didSelect(filter: Filter) {
        viewModel.selectedPredefinedFilter(filter)
    }

    func moreFiltersDidTouch() {
        viewModel.moveToMoreFiltersView()
    }
}

extension CompaniesViewController: CompaniesCollectionViewDelegate {
    func collectionViewNeedsMoreData() {
        viewModel.collectionViewNeedsMoreData()
    }

    func toogleFollowing(of company: Company) {
        viewModel.toogleFollowingCompany(company)
    }

    func didSelect(company: Company) {
        viewModel.selected(company: company)
    }
}

extension CompaniesViewController: SnackBarDelegate {
    func snackBarDidTouch() {
        viewModel.followAll()
    }
}
