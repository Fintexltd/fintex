//
//  CompaniesView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CompaniesView: BaseViewCreator {

    lazy var navigationView: SearchableNavigationView = {
        return SearchableNavigationView()
    }()

    lazy var collectionView: CompaniesCollectionView = {
        return UICollectionView.makeCustomCollectionView(type: CompaniesCollectionView.self)
    }()

    lazy var filterView: PredefinedFiltersView = {
        return PredefinedFiltersView()
    }()

    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary

        return refreshControl
    }()
        
    let snackBar: SnackBarView = SnackBarView()

    override func setupProperties() {
        collectionView.addSubview(refreshControl)
    }

    override func setupViewHierarchy() {
        [filterView, collectionView, snackBar].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        filterView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
        }
        
        collectionView.snp.makeConstraints { make in
            make.top.equalTo(filterView.snp.bottom).priority(.highest)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}
