//
//  CompaniesViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum CompaniesState: Equatable {
  
    case loading
    case paging([Company])
    case populated([Company])
    case empty
    case error(Error)

    var currentCompanies: [Company] {
        switch self {
        case .paging(let companies): return companies
        case .populated(let companies): return companies
        default: return []
        }
    }
    
    static func == (lhs: CompaniesState, rhs: CompaniesState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}

class CompaniesViewModel: BaseViewModel<HasCompaniesRepository & HasFiltersRepository> {
    
    typealias FilterData = (filters: [Filter], selectedFilters: Int)
    let filtersData = BehaviorRelay<FilterData>(value: ([], 0))
    let companiesState = BehaviorRelay<CompaniesState>(value: .loading)

    private let companyResponses = BehaviorRelay<[CompaniesResponse]>(value: [])
    private let moreDataNeedRelay = BehaviorRelay(value: 1)
    
    let showFollowAll = PublishRelay<Bool>()
    
    private lazy var filters = BehaviorRelay(value:
        AdvancedFilters.empty(withSortType: .defaultSortedSeed(seed: generateRandomSeed())))

    private lazy var companiesRepository = dependencies.companiesRepository
    private lazy var filtersRepository = dependencies.filtersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        fetchFilters()
        
        MainFlowRxBus.companyFollowingStatePublishRelay
            .subscribe(onNext: { [weak self] model in
                guard let model = model else {
                    self?.refresh()
                    return
                }
                
                if let company = self?.companiesState.value.currentCompanies.first(where: { $0.id == model.companyId }) {
                    self?.changeCompanyFollowState(model.newFollowingState, forCompany: company)
                }
            }).disposed(by: disposeBag)
    }

    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.companiesState.accept(.loading) })
            .withLatestFrom(companyResponses)
            .filter { companyResponses -> Bool in
                guard let last = companyResponses.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .withLatestFrom(filters) { ($0, $1) }
            .flatMapLatest { (arg) -> Observable<[CompaniesResponse]> in
                let (companyResponses, filters) = arg

                return self.companiesRepository.getCompanies(fromPage: (companyResponses.last?.meta.currentPage ?? 0) + 1, withFilters: filters)
                    .map { return companyResponses + [$0] }
                    .do(onNext: { [weak self] companiesResponses in
                        self?.handleCompaniesResponses(with: companiesResponses)
                    })
                    .catchError { [weak self] error in
                        self?.companiesState.accept(.error(error))
                        return Observable<[CompaniesResponse]>.empty()
                }
            }
            .bind(to: companyResponses)
            .disposed(by: disposeBag)
    }
    
    private func handleCompaniesResponses(with responses: [CompaniesResponse]) {
        let companies = responses.flatMap { $0.data }.uniqueElements
        
        if companies.isEmpty {
            companiesState.accept(.empty)
        } else if let last = responses.last, last.meta.currentPage < last.meta.lastPage {
            companiesState.accept(.paging(companies))
        } else {
            companiesState.accept(.populated(companies))
        }
        updateFollowAllState(with: responses)
    }
    
    private func updateFollowAllState(with responses: [CompaniesResponse]) {
        let isNotFollowingAll = responses.filter { $0.meta.isFollowingAll ?? false }.isEmpty
        let hasMinimalNumberOfFilters = filtersData.value.selectedFilters >= Defaults.Filter.minNumberToShowFollowAll
        let isPopulated = companiesState.value != .empty
        
        showFollowAll.accept(isNotFollowingAll && hasMinimalNumberOfFilters && isPopulated)
    }
    
    private func refresh() {
        companyResponses.accept([])
        moreDataNeedRelay.accept(1)
    }

    private func generateRandomSeed() -> Int {
        return Int(arc4random_uniform(9999) + 1)
    }
    
    private func fetchFilters() {
        filtersRepository.getCompanyPredefinedFilters()
            .subscribe(onNext: { [weak self] filters in
                guard let `self` = self else { return }
                let oldFilters = self.filters.value
                let mappedRelations = filters.map {
                    $0.with(selection: oldFilters.hasRelationFilter($0) || oldFilters.hasSortFilter($0))
                }
                self.filtersData.accept((mappedRelations, self.filters.value.selectionCount))
            }, onError: { error in printDebug(error) })
        .disposed(by: disposeBag)
    }
}

extension CompaniesViewModel {

    var reloadDriver: Driver<Int> {
        return companyResponses.asDriver().map { _ in 0 }
    }

    func collectionViewNeedsMoreData() {
        moreDataNeedRelay.accept(1)
    }
    
    func refreshDataRandomly() {
        if case SortType.defaultSortedSeed = filters.value.sortBy {
            let newFilters = filters.value.with(sortType: .defaultSortedSeed(seed: generateRandomSeed()))
            self.filters.accept(newFilters)
        }
        refresh()
    }

    func toogleFollowingCompany(_ company: Company) {
        companiesRepository.toggleFollowing(ofCompanyWithId: company.id, follow: company.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(onSubscribe: { self.changeCompanyFollowState(.changing, forCompany: company) })
            .subscribe(onNext: { [weak self] _ in
                guard let `self` = self else { return }
                let newState: FollowingState = company.following == .following ? .notFollowing : .following
                MainFlowRxBus.companyFollowingStatePublishRelay
                    .accept(CompanyFollowingChangeModel(companyId: company.id,
                                                        newFollowingState: newState))
                self.changeCompanyFollowState(newState, forCompany: company)
            }, onError: { [weak self] error in
                self?.changeCompanyFollowState(company.following, forCompany: company)
                self?.alert.accept(AlertData(message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    func followAll() {
        companiesRepository.followAllCompanies(matching: filters.value)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                MainFlowRxBus.companyFollowingStatePublishRelay.accept(nil)
                self?.showFollowAll.accept(false)
            }, onError: { [weak self] error in
                self?.handleFollowingCompaniesError(message: error.localizedDescription)
            }).disposed(by: disposeBag)
    }

    private func handleFollowingCompaniesError(message: String) {
        alert.accept(AlertData(message: message != "" ? message : Localizable.companiesFollowAllError.localized))
    }
    
    private func changeCompanyFollowState(_ state: FollowingState, forCompany company: Company) {
        var companies = companiesState.value.currentCompanies        
        let updatedCompany = company.with(followingState: state)
        if let companyIndex = companies.index(where: { $0.id == company.id }) {
            companies[companyIndex] = updatedCompany
        }

        switch companiesState.value {
        case .paging: companiesState.accept(.paging(companies))
        case .populated: companiesState.accept(.populated(companies))
        default: break
        }
    }

    func selected(company: Company) {
        router?.push(to: .companyDetails(companyId: company.id))
    }

    func didTapAccountIcon() {
    }

    func searchFor(fraze: String) {
        self.filters.accept(filters.value.with(searchText: fraze))
        refresh()
    }
    
    func moveToMoreFiltersView() {
        router?.present(destination:
            .filters(filterTypes: [.companyRelation, .industry, .sector, .continent, .country],
                     initialFilters: filters.value,
                     delegate: self))
    }
    
    func moveToAccountInfoView() {}

    func selectedPredefinedFilter(_ filter: Filter) {
        switch filter {
        case is CompanyRelation:
            updateRelationFilters(with: filter)
        case is SortFilter:
            updateSortFilters(with: filter)
        default: break
        }
        updateFiltersData(filters: self.filters.value)
        refresh()
    }
    
    func company(withId id: Int, didChangeFollowingState state: FollowingState) {
        if let company = companiesState.value.currentCompanies.first(where: { $0.id == id }) {
            changeCompanyFollowState(state, forCompany: company)
        }
    }
    
    private func updateRelationFilters(with filter: Filter) {
        guard let relation = filter as? CompanyRelation else { return }
        var relations = filters.value.relations
        
        if let index = relations.index(where: { $0 == relation.name.lowercased() }) {
            relations.remove(at: index)
        }
        if filter.isSelected { relations.append(filter.name.lowercased()) }
        self.filters.accept(filters.value.with(relations: relations))
    }
    
    private func updateSortFilters(with filter: Filter) {
        guard let sort = filter as? SortFilter else { return }
        let sortType = sort.isSelected ? sort.sortType : .defaultSortedSeed(seed: generateRandomSeed())
        
        self.filters.accept(filters.value.with(sortType: sortType))
    }
    
    private func updateFiltersData(filters: AdvancedFilters) {
        let updatedRelations = filtersData.value.filters.map {
            $0.with(selection: filters.hasRelationFilter($0) || filters.hasSortFilter($0))
        }
        self.filtersData.accept((updatedRelations, filters.selectionCount))
    }
}

extension CompaniesViewModel: FiltersDelegate {
    
    func didSelect(filters: AdvancedFilters) {
        self.filters.accept(filters)
        updateFiltersData(filters: filters)
        refresh()
    }
}
