//
//  StateFooterView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class StateFooterView: UICollectionReusableView {
    
    private lazy var loaderView: LoaderView = {
        let loaderView = LoaderView()
        loaderView.isSpinning = true
        
        return loaderView
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        clipsToBounds = true
        [loaderView].forEach { addSubview($0) }
        loaderView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Auth.countryLoadSpinnerSize).priority(.highest)
            make.center.equalToSuperview()
        }
    }
    
    func initialize() {
        loaderView.isHidden = false
    }

}

class StateTableViewFooter: UITableViewHeaderFooterView {
    
    private lazy var loaderView: LoaderView = {
        let loaderView = LoaderView()
        loaderView.isSpinning = true
        
        return loaderView
    }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        clipsToBounds = true
        [loaderView].forEach { addSubview($0) }
        loaderView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Auth.countryLoadSpinnerSize).priority(.highest)
            make.center.equalToSuperview()
        }
    }
    
    func initialize() {
        loaderView.isHidden = false
    }

}
