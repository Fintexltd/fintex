//
//  CompaniesCollectionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import DeepDiff

protocol CompaniesCollectionViewDelegate: class {
    func collectionViewNeedsMoreData()
    func toogleFollowing(of company: Company)
    func didSelect(company: Company)
}

class CompaniesCollectionView: UICollectionView {
    
    weak var collectionViewDelegate: CompaniesCollectionViewDelegate?
    
    var state: CompaniesState = .loading {
        willSet(newValue) {
            listChanges = diff(old: state.currentCompanies, new: newValue.currentCompanies)
        }
        didSet {
            if let listChanges = listChanges {
                updateCollectionView(withChanges: listChanges)
                updateBackgroundView()
            }
        }
    }

    private var itemWidth: CGFloat = 0
    private var listChanges: [Change<Company>]?
    
    lazy var failureView: FailureView = {
        let view = FailureView()
        
        return view
    }()
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        registerCell(CompanyCollectionViewCell.self)
        registerFooterView(StateFooterView.self)
        delegate = self
        dataSource = self
    }
    
    override func reloadSections(_ sections: IndexSet) {
        itemWidth = 0
        super.reloadSections(sections)
    }
    
    private func updateCollectionView(withChanges changes: [Change<Company>]) {
        collectionViewLayout.invalidateLayout()
        reload(changes: changes) { [weak self] _ in self?.listChanges = nil }
    }
    
    private func updateBackgroundView() {
        failureView.updateText(state.failureMessage)
        backgroundView = failureView
    }
}

extension CompaniesCollectionView: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return state.currentCompanies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: CompanyCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.company = state.currentCompanies[indexPath.row]
            cell.delegate = self
            return cell
        }
        
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == (collectionView.numberOfItems(inSection: indexPath.section) - 4) {
            collectionViewDelegate?.collectionViewNeedsMoreData()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if let stateFooter: StateFooterView = collectionView.dequeueReusableFooterView(for: indexPath) {
            stateFooter.initialize()
            return stateFooter
        }
        return UICollectionReusableView()
    }
    
    private func itemWidth(forSize size: CGSize) -> CGFloat {
        let multiplier: CGFloat = UIScreen.main.traitCollection.userInterfaceIdiom == .phone ? 1 : 0.5
        return (size.width) * multiplier
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionViewDelegate?.didSelect(company: state.currentCompanies[indexPath.row])
    }
}

extension CompaniesCollectionView: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if itemWidth == 0 { itemWidth = itemWidth(forSize: bounds.size) }
        
        let height: CGFloat = UIApplication.shared.statusBarOrientation.isPortrait ?
            Defaults.Company.cellPortraitHeight : Defaults.Company.cellHorizontalHeight
        
        return CGSize(width: itemWidth, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: state.heightForFooter)
    }
}

extension CompaniesCollectionView: CompanyCellDelegate {
   
    func collectionCell(_ cell: CompanyCollectionViewCell, didToogleFollowCompany company: Company) {
        collectionViewDelegate?.toogleFollowing(of: company)
    }
    
    func collectionCell(_ cell: CompanyCollectionViewCell, didTapUserGroupsFor company: Company) {
        collectionViewDelegate?.didSelect(company: company)
    }
}
  
extension CompaniesState {
    
    var heightForFooter: CGFloat {
        switch self {
        case .loading, .paging: return Defaults.Company.footerHeight
        default: return 0
        }
    }
    
    var failureMessage: String? {
        switch self {
        case .error(let error): return error.localizedDescription
        case .empty: return Localizable.companiesNoResults.localized
        default: return nil
        }
    }
}
