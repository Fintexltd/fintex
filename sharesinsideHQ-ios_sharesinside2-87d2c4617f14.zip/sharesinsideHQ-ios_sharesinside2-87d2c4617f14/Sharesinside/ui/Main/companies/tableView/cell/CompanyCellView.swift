//
//  CompanyCellView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 25.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CompanyCellViewCreator: BaseViewCreator {

    lazy var companyLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        imageView.backgroundColor = .clear

        return imageView
    }()

    lazy var companyTitle: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark,
            fontWeight: .bold)
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()

    let userGroups = ChipCollectionView()

    lazy var companyGroup: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
            withFontSize: Defaults.TextSize.small)
        label.numberOfLines = 1
        label.setContentPriority(resistancePriority: UILayoutPriority.required, resistanceAxis: .vertical, huggingPriority: UILayoutPriority.defaultLow.decreased(by: 1), huggingAxis: .vertical)
        return label
    }()

    lazy var companySharePrice: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.small)
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        label.numberOfLines = 1
        return label
    }()

    lazy var followButton: SharesinsideButton = {
        let button = SharesinsideButton()
        button.style = SharesinsideButton.Style.primary

        return button
    }()

    lazy var followLoader: LoaderView = {
        let loader = LoaderView()
        loader.isSpinning = true
        return loader
    }()

    lazy var titleStackView = UIStackView
        .make(axis: .vertical,
            with: [
                companyTitle,
                userGroups
            ],
            spacing: Defaults.marginTiny)

    lazy var detailsStackView = UIStackView
        .make(axis: .vertical,
            with: [
                companyGroup,
                companySharePrice
            ])

    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView
            .make(axis: .vertical,
                with: [
                    titleStackView,
                    detailsStackView.embedInView()
                ],
                spacing: Defaults.marginTiny,
                distribution: .fill)
        stackView.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        return stackView
    }()

    lazy var bottomDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    lazy var verticalDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    override func setupProperties() {
        parentView.backgroundColor = .accent
        parentView.clipsToBounds = true
    }

    override func setupViewHierarchy() {
        [companyLogo, contentStackView, followLoader, followButton, bottomDivider, verticalDivider].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        companyLogo.snp.makeConstraints { make in
            make.leading.top.equalToSuperview().offset(Defaults.marginNormal)
            make.width.equalTo(Defaults.Company.logoSize)
            make.height.equalTo(companyLogo.snp.width).multipliedBy(1).priority(.highest)
        }

        contentStackView.snp.makeConstraints { make in
            make.leading.equalTo(companyLogo.snp.trailing).offset(Defaults.marginNormal)
            make.top.trailing.equalToSuperview().inset(Defaults.marginNormal)
        }

        followButton.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.greaterThanOrEqualTo(contentStackView.snp.bottom).offset(Defaults.marginNormal).priority(.high)
            make.height.equalTo(Defaults.Company.followButtonHeight)
            make.bottom.equalToSuperview().inset(Defaults.marginBig)
            make.top.greaterThanOrEqualTo(companyLogo.snp.bottom).offset(Defaults.marginNormal)
        }

        bottomDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
            make.leading.trailing.bottom.equalToSuperview()
        }

        verticalDivider.snp.makeConstraints { make in
            make.width.equalTo(Defaults.dividerSize)
            make.top.bottom.trailing.equalToSuperview()
        }
        
        detailsStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.greaterThanOrEqualToSuperview()
            make.bottom.lessThanOrEqualToSuperview()
            make.centerY.equalToSuperview()
        }
        
        followLoader.snp.makeConstraints { make in
            make.edges.equalTo(followButton.snp.edges).inset(Defaults.marginTiny)
        }
    }
}
