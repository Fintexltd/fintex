//
//  CompanyCollectionViewCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 25.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol CompanyCellDelegate: class {
    func collectionCell(_ cell: CompanyCollectionViewCell, didToogleFollowCompany company: Company)
    func collectionCell(_ cell: CompanyCollectionViewCell, didTapUserGroupsFor company: Company)
}

class CompanyCollectionViewCell: UICollectionViewCell {
    
    weak var delegate: CompanyCellDelegate?
    
    private lazy var viewCreator = CompanyCellViewCreator(withParentView: self.contentView)

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    var company: Company? {
        didSet {
            if let company = company {
                configure(with: company)
            }
        }
    }

    private func configure(with company: Company) {
        viewCreator.companyTitle.text = company.name
        
        viewCreator.companyGroup.text = company.industry
        viewCreator.companySharePrice.text = Localizable.companyCellSharePrice.localized + "\(company.mainStockPrice ?? "--")"
        viewCreator.followButton.isHidden = company.following == .changing
        viewCreator.followButton.setTitle(company.following.stateTitle, for: .normal)
        viewCreator.followButton.style = company.following.buttonStyle
        viewCreator.followLoader.isHidden = company.following != .changing

        if let logo = company.logo, let logoUrl = URL(string: logo) {
            viewCreator.companyLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
        }

        let orientation = UIApplication.shared.statusBarOrientation
        viewCreator.contentStackView.axis = orientation.isPortrait ? .vertical : .horizontal
        viewCreator.companySharePrice.textAlignment = orientation.isPortrait ? .left : .right
        viewCreator.companyGroup.textAlignment = orientation.isPortrait ? .left : .right
        viewCreator.followButton.addTarget(self, action: #selector(followDidTouch), for: .touchUpInside)
        viewCreator.userGroups.configure(withUserGroups: company.companiesCellGroups.compactMap({ $0.title }))
    }

    private func initializeView() {
        viewCreator.setupView()
        viewCreator.userGroups.setupGestureRecognizer(target: self, selector: #selector(userGroupsDidTouch))
    }
    
    @objc private func followDidTouch() {
        guard let company = company else { return }
        delegate?.collectionCell(self, didToogleFollowCompany: company)
    }
    
    @objc private func userGroupsDidTouch() {
        guard let company = company else { return }
        delegate?.collectionCell(self, didTapUserGroupsFor: company)
    }
}
