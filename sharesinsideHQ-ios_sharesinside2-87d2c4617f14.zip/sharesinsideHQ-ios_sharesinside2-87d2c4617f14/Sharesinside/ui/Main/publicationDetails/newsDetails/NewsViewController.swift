//
//  InformationViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

class NewsViewController: BaseViewController<NewsViewModel>, UINavigationControllerDelegate {
    
    private lazy var viewCreator = NewsView(withParentView: self.view)
    
    private lazy var otherNewsViewController = OtherPublicationsViewController(publicationId: newsId, delegate: self, type: .news)
    
    var newsId: Int
    
    init(withNewsId id: Int) {
        self.newsId = id
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.headerView.delegate = self
        navigationController?.delegate = self
        automaticallyAdjustsScrollViewInsets = false
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.newsId = newsId
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.orientationChanged()
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.delegate = self
        viewCreator.attachmentsView.delegate = self
        viewCreator.linksView.delegate = self
        viewCreator.galleryView.delegate = self
        otherNewsViewController.delegate = self
        viewCreator.descriptionLabel.delegate = self
        viewCreator.otherNewsStackView.addArrangedSubview(otherNewsViewController.view)
        viewCreator.videoView.superview?.isHidden = true
        viewCreator.setupProperties()
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.newsData
            .asDriver()
            .ignoreNil()
            .do(onSubscribe: { [weak self] in self?.hideAllChildren() })
            .drive(onNext: { [weak self] news in
                self?.configureView(withNews: news)
                self?.otherNewsViewController.loadData()
            }).disposed(by: disposeBag)
    }

    private func configureView(withNews news: NewsInformation) {
        showAllChildren(animated: true)
        viewCreator.newsTitle.text = news.title
        viewCreator.headerView.configure(with: news)
        viewCreator.descriptionLabel.text = news.prettyPrintedDescription
        configureVideoView(with: news)
        configureAdditionalData(with: news.files, videos: news.videos, videoLinks: news.videoLinks, andLinks: news.links)
        configureGallery(with: news.images)
    }
    
    private func configureVideoView(with news: NewsInformation) {
        guard let videoData = news.videoData else {
            return
        }
        viewCreator.videoView.videoData = videoData
        viewCreator.videoView.superview?.isHidden = false
    }
    
    private func configureAdditionalData(with attachments: [Attachments],
                                         videos: [Video],
                                         videoLinks: [VideoLink],
                                         andLinks links: [Link]) {
        
        var allLinks: [AttachmentConvertible] = links
        var allAttachments: [AttachmentConvertible] = attachments
        
        if !videos.isEmpty {
            allAttachments += videos[1 ..< videos.count].compactMap { $0 as AttachmentConvertible }
            allLinks += videoLinks.compactMap { $0 as AttachmentConvertible }
        } else if videos.isEmpty && videoLinks.count > 1 {
            let videoLinksSlice = Array(videoLinks[1 ..< videoLinks.count])
            allLinks += videoLinksSlice.compactMap { $0 as AttachmentConvertible }
        }
        
        viewCreator.attachmentsView.configure(with: allAttachments, title: "\(Localizable.publicationAttachments.localized) (\(allAttachments.count))")
        viewCreator.linksView.configure(with: allLinks, title: "\(Localizable.publicationLinks.localized) (\(allLinks.count))")
        viewCreator.attachmentsView.isHidden = allAttachments.isEmpty
        viewCreator.attachmentsDivider.isHidden = allAttachments.isEmpty
        viewCreator.linksView.isHidden = allLinks.isEmpty
    }
    
    private func configureGallery(with images: [Attachments]) {
        viewCreator.galleryView.images = images
        viewCreator.galleryView.isHidden = images.isEmpty
    }
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension NewsViewController: ReinitializableViewController {
    
    func reinitializeView(with id: Int) {
        newsId = id
        viewModel.newsId = id
    }
}

extension NewsViewController: AttachmentsViewDelegate {
    
    func attachmentButtonDidTouch(button: AttachmentButton) {
        open(url: URL(string: button.attachment?.url))
    }
}

extension NewsViewController: OtherPublicationsDelegate {
   
    func moveToWatchlist() {
        router.pop(animated: true, toDestination: .watchlist)
    }
    
    func didSelect(publication: Publication) {
        router.push(to: .newsDetails(newsId: publication.watchlistableId), forcePush: true)
    }
    
    func layoutChanged() {
        viewCreator.updateOtherNewsConstraints()
        view.layoutIfNeeded()
    }
}

extension NewsViewController: HorizontalGalleryViewDelegate {
    func didSelect(photo: Photo, inPhotos photos: [Photo]) {
        viewModel.show(photoPreview: photo, forPhotos: photos)
    }
}

extension NewsViewController: PublicationHeaderDelegate {
    func didTapPublicationHeader(_ publicationHeader: PublicationHeaderView) {
        viewModel.showPublisherDetails()
    }
    
    func didTapShareButton(_ publicationHeader: PublicationHeaderView) { }
}

extension NewsViewController: NewsViewDelegate {
    func didTapShareButton(_ newsView: NewsView) {
        let url = viewModel.newsData.value?.shareUrl
        self.shareNews(url: url)
    }
}

extension NewsViewController: TTTAttributedLabelDelegate {
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        open(url: url)
    }
}
