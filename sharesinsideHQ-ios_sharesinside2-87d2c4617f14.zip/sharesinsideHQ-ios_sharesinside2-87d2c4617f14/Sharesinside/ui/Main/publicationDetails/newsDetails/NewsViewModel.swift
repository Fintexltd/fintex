//
//  InformationViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class NewsViewModel: BaseViewModel<HasWatchlistRepository> {
    
    var newsId: Int? {
        didSet { fetchNewsDetails() }
    }
    
    let newsData = BehaviorRelay<NewsInformation?>(value: nil)
    
    lazy var watchlistRepository = dependencies.watchlistRepository
    
    private func fetchNewsDetails() {
        guard let id = newsId else {
                alert.accept(AlertData(
                    message: Localizable.publicationWrongData.localized,
                    onPositiveTap: { self.router?.pop() }))
                return
        }
        getNewsDetails(newsId: id)
    }
    
    private func getNewsDetails(newsId: Int) {
        watchlistRepository.getNewsDetails(id: newsId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] newsDetails in
                    self?.newsData.accept(newsDetails)
                },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent)
                }).disposed(by: disposeBag)
    }
    
    func show(photoPreview: Photo, forPhotos photos: [Photo]) {
        guard let photoIndex = photos.firstIndex(where: { $0.id == photoPreview.id }) else { return }
        router?.present(destination: .photoPreview(legalEntityName: newsData.value?.issuerName ?? "",
                                                   photos: photos,
                                                   initialIndex: photoIndex))
    }
    
    func showPublisherDetails() {
        guard let issuerType = newsData.value?.issuerType,
            let issuerId = newsData.value?.issuerId else {
            return
        }
        switch issuerType {
        case .company:
            router?.push(to: .companyDetails(companyId: issuerId))
        case .fund:
            router?.push(to: .fundDetails(fundId: issuerId))
        case .fundsManager:
            router?.push(to: .fundManagerDetails(fundManagerId: issuerId))
        case .startup:
            router?.push(to: .startupDetails(startupId: issuerId))
        }
    }
}
