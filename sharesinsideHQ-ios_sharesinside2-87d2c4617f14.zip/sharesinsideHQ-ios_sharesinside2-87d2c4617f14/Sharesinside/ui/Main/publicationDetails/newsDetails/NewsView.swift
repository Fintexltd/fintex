//
//  InformationView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

protocol NewsViewDelegate: class {
    func didTapShareButton(_ newsView: NewsView)
}

class NewsView: BaseViewCreator {
    
    let headerView = PublicationHeaderView()
    weak var delegate: NewsViewDelegate?
    
    // MARK: Video view
    let videoView: NewsVideoView = {
        let view = NewsVideoView()
        return view
    }()
    
    // MARK: Description
    let newsTitle: UILabel = {
        let title = UILabelFactory.styled(textColor: .primaryDark, withFontSize: Defaults.TextSize.big, fontWeight: .bold)
        title.textAlignment = .left
        return title
    }()
    
    let shareButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "share"), for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: Defaults.shareButtonImageInset,
                                              left: Defaults.shareButtonImageInset,
                                              bottom: Defaults.shareButtonImageInset,
                                              right: Defaults.shareButtonImageInset)
        return button
    }()
    
    lazy var newsTitleWithShareButtonView: UIView = {
        let view = UIView()
        view.addSubview(newsTitle)
        view.addSubview(shareButton)
        return view
    }()
    
    let descriptionLabel: TTTAttributedLabel = {
        let label = UILabelFactory.styled(label: TTTAttributedLabel(frame: .zero), textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.textAlignment = .left
        label.enabledTextCheckingTypes = NSTextCheckingResult.CheckingType.link.rawValue
        return label
    }()
    
    // MARK: Attachments and links
    let attachmentsView = AttachmentsView()
    
    let linksView = AttachmentsView()
    
    // MARK: Dividers
    let galleryDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    let attachmentsDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    let divider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    // Gallery
    let galleryView = HorizontalGalleryView()
    
    // Other news
    
    lazy var otherNewsStackView = UIStackView.make(
        axis: .vertical,
        with: [])
    
    // MARK: Content view
    
    lazy var mainInformationStackView: UIStackView = UIStackView.make(
        axis: .vertical,
        with: [
            newsTitleWithShareButtonView,
            headerView.embedInView(),
            videoView.embedInView(),
            descriptionLabel.embedInView(),
            galleryView,
            galleryDivider,
            attachmentsView,
            attachmentsDivider,
            linksView
        ])
    
    lazy var otherNewsContainer = otherNewsStackView.embedInView()
    
    lazy var  contentStackView = UIStackView.make(
        axis: AppInfo.orientation.isPortrait ? .vertical : .horizontal,
        with: [
            mainInformationStackView.embedInView(),
            otherNewsContainer
        ])
    
    let contentScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false
        
        return scrollView
    }()
    
    override func setupViewHierarchy() {
        otherNewsContainer.addSubview(divider)
        contentScrollView.addSubview(contentStackView)
        parentView.addSubview(contentScrollView)
    }
    
    override func setupConstraints() {
        setupContentConstraints()
        setupContainersConstraints()
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        contentScrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func setupContainersConstraints() {
        mainInformationStackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().priority(.highest)
            make.bottom.lessThanOrEqualToSuperview()
        }
        updateOtherNewsConstraints()
    }
    
    override func setupProperties() {
        shareButton.addTarget(self, action: #selector(didTapShareButton), for: .touchUpInside)
    }
    
    @objc private func didTapShareButton() {
        delegate?.didTapShareButton(self)
    }
}

extension NewsView {
    
    private func setupContentConstraints() {
        shareButton.snp.makeConstraints { make in
            make.top.equalTo(newsTitle.snp.top).offset(Defaults.marginMicro).priority(.highest)
            make.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.leading.equalTo(newsTitle.snp.trailing).offset(Defaults.marginSmall).priority(.highest)
            make.width.equalTo(Defaults.shareButtonWidht).priority(.highest)
            make.height.equalTo(Defaults.shareButtonHeight).priority(.highest)
        }
        
        headerView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
        }
        
        descriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
        }
        
        newsTitle.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
        
        galleryDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        
        attachmentsDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        
        videoView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
            make.width.equalTo(videoView.snp.height).multipliedBy(2).priority(.highest)
        }
        
        galleryView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Publication.newsGalleryHeight)
        }
        
        shareButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().priority(.highest)
            make.width.equalTo(Defaults.shareButtonWidht).priority(.highest)
            make.height.equalTo(Defaults.shareButtonHeight).priority(.highest)
        }
    }    
}

extension NewsView {
    
    func orientationChanged() {
        contentStackView.axis = AppInfo.orientation.isPortrait ? .vertical : .horizontal
        updateOtherNewsConstraints()
    }
    
    func updateOtherNewsConstraints() {
        otherNewsStackView.snp.remakeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.lessThanOrEqualToSuperview().priority(.highest)
            make.width.equalTo(parentView.snp.width).multipliedBy(AppInfo.orientation.isPortrait ? 1 : 0.4)
        }
        
        divider.snp.remakeConstraints { make in
            make.top.leading.equalToSuperview()
            if AppInfo.orientation.isPortrait {
                make.height.equalTo(Defaults.dividerSize).priority(.highest)
                make.width.greaterThanOrEqualTo(contentScrollView.snp.width)
            } else {
                make.width.equalTo(Defaults.dividerSize).priority(.highest)
                make.height.greaterThanOrEqualTo(contentScrollView.snp.height)
            }
        }
    }
}
