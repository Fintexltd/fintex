//
//  ProjectView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

protocol ProjectViewDelegate: class {
    func didTapShareButton(_ projectView: ProjectView)
}

class ProjectView: BaseViewCreator {

    let headerView = PublicationHeaderView()
    weak var delegate: ProjectViewDelegate?

    // MARK: Video view
    let videoView: ProjectDetailsView = {
        let view = ProjectDetailsView()
        return view
    }()

    // MARK: Description
    let projectTitle: UILabel = {
        let title = UILabelFactory.styled(textColor: .primaryDark, withFontSize: Defaults.TextSize.big, fontWeight: .bold)
        title.textAlignment = .left
        return title
    }()

    let shareButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "share"), for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: Defaults.shareButtonImageInset,
                                              left: Defaults.shareButtonImageInset,
                                              bottom: Defaults.shareButtonImageInset,
                                              right: Defaults.shareButtonImageInset)
        return button
    }()

    lazy var projectTitleWithShareButtonView: UIView = {
        let view = UIView()
        view.addSubview(projectTitle)
        view.addSubview(shareButton)
        return view
    }()

    let descriptionLabel: TTTAttributedLabel = {
        let label = UILabelFactory.styled(label: TTTAttributedLabel(frame: .zero), textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.textAlignment = .left
        label.enabledTextCheckingTypes = NSTextCheckingResult.CheckingType.link.rawValue
        return label
    }()

    // MARK: Attachments and links
    let attachmentsView = AttachmentsView()

    let linksView = AttachmentsView()

    // MARK: Dividers
    let galleryDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    let attachmentsDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    let divider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    // Gallery
    let galleryView = HorizontalGalleryView()

    // Other project

    lazy var otherProjectStackView = UIStackView.make(
        axis: .vertical,
        with: [])

    // MARK: Content view

    lazy var mainInformationStackView: UIStackView = UIStackView.make(
        axis: .vertical,
        with: [
            projectTitleWithShareButtonView,
            headerView.embedInView(),
            videoView.embedInView(),
            descriptionLabel.embedInView(),
            galleryView,
            galleryDivider,
            attachmentsView,
            attachmentsDivider,
            linksView
        ])

    lazy var otherProjectContainer = otherProjectStackView.embedInView()

    lazy var  contentStackView = UIStackView.make(
        axis: AppInfo.orientation.isPortrait ? .vertical : .horizontal,
        with: [
            mainInformationStackView.embedInView(),
            otherProjectContainer
        ])

    let contentScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false

        return scrollView
    }()

    override func setupViewHierarchy() {
        otherProjectContainer.addSubview(divider)
        contentScrollView.addSubview(contentStackView)
        parentView.addSubview(contentScrollView)
    }

    override func setupConstraints() {
        setupContentConstraints()
        setupContainersConstraints()
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }

        contentScrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    private func setupContainersConstraints() {
        mainInformationStackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().priority(.highest)
            make.bottom.lessThanOrEqualToSuperview()
        }
        updateOtherProjectConstraints()
    }

    override func setupProperties() {
        shareButton.addTarget(self, action: #selector(didTapShareButton), for: .touchUpInside)
    }

    @objc private func didTapShareButton() {
        delegate?.didTapShareButton(self)
    }
}

extension ProjectView {

    private func setupContentConstraints() {
        shareButton.snp.makeConstraints { make in
            make.top.equalTo(projectTitle.snp.top).offset(Defaults.marginMicro).priority(.highest)
            make.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.leading.equalTo(projectTitle.snp.trailing).offset(Defaults.marginSmall).priority(.highest)
            make.width.equalTo(Defaults.shareButtonWidht).priority(.highest)
            make.height.equalTo(Defaults.shareButtonHeight).priority(.highest)
        }

        headerView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
        }

        descriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
        }

        projectTitle.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }

        galleryDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }

        attachmentsDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }

        videoView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
            make.width.equalTo(videoView.snp.height).multipliedBy(2).priority(.highest)
        }

        galleryView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Publication.newsGalleryHeight)
        }

        shareButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().priority(.highest)
            make.width.equalTo(Defaults.shareButtonWidht).priority(.highest)
            make.height.equalTo(Defaults.shareButtonHeight).priority(.highest)
        }
    }
}

extension ProjectView {

    func orientationChanged() {
        contentStackView.axis = AppInfo.orientation.isPortrait ? .vertical : .horizontal
        updateOtherProjectConstraints()
    }

    func updateOtherProjectConstraints() {
        otherProjectStackView.snp.remakeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.lessThanOrEqualToSuperview().priority(.highest)
            make.width.equalTo(parentView.snp.width).multipliedBy(AppInfo.orientation.isPortrait ? 1 : 0.4)
        }

        divider.snp.remakeConstraints { make in
            make.top.leading.equalToSuperview()
            if AppInfo.orientation.isPortrait {
                make.height.equalTo(Defaults.dividerSize).priority(.highest)
                make.width.greaterThanOrEqualTo(contentScrollView.snp.width)
            } else {
                make.width.equalTo(Defaults.dividerSize).priority(.highest)
                make.height.greaterThanOrEqualTo(contentScrollView.snp.height)
            }
        }
    }
}
