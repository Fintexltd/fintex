//
//  ProjectViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

class ProjectViewController: BaseViewController<ProjectViewModel>, UINavigationControllerDelegate {

    private lazy var viewCreator = ProjectView(withParentView: self.view)

    private lazy var otherProjectViewController = OtherPublicationsViewController(publicationId: projectId, delegate: self, type: .project)

    var projectId: Int

    init(withProjectId id: Int) {
        self.projectId = id
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.headerView.delegate = self
        navigationController?.delegate = self
        automaticallyAdjustsScrollViewInsets = false
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.projectId = projectId
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.orientationChanged()
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.delegate = self
        viewCreator.attachmentsView.delegate = self
        viewCreator.linksView.delegate = self
        viewCreator.galleryView.delegate = self
        otherProjectViewController.delegate = self
        viewCreator.descriptionLabel.delegate = self
        viewCreator.otherProjectStackView.addArrangedSubview(otherProjectViewController.view)
        viewCreator.videoView.superview?.isHidden = true
        viewCreator.setupProperties()
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.projectData
            .asDriver()
            .ignoreNil()
            .do(onSubscribe: { [weak self] in self?.hideAllChildren() })
            .drive(onNext: { [weak self] project in
                self?.configureView(withProject: project)
                self?.otherProjectViewController.loadData()
            }).disposed(by: disposeBag)
    }

    private func configureView(withProject project: ProjectInformation) {
        showAllChildren(animated: true)
        viewCreator.projectTitle.text = project.title
        viewCreator.headerView.configure(with: project)
        viewCreator.descriptionLabel.text = project.prettyPrintedDescription
        configureVideoView(with: project)
        configureAdditionalData(with: project.files, videos: project.videos, videoLinks: project.videoLinks, andLinks: project.links)
        configureGallery(with: project.images)
    }

    private func configureVideoView(with project: ProjectInformation) {
        guard let videoData = project.videoData else {
            return
        }
        viewCreator.videoView.videoData = videoData
        viewCreator.videoView.superview?.isHidden = false
    }

    private func configureAdditionalData(with attachments: [Attachments],
                                         videos: [Video],
                                         videoLinks: [VideoLink],
                                         andLinks links: [Link]) {

        var allLinks: [AttachmentConvertible] = links
        var allAttachments: [AttachmentConvertible] = attachments

        if !videos.isEmpty {
            allAttachments += videos[1 ..< videos.count].compactMap { $0 as AttachmentConvertible }
            allLinks += videoLinks.compactMap { $0 as AttachmentConvertible }
        } else if videos.isEmpty && videoLinks.count > 1 {
            let videoLinksSlice = Array(videoLinks[1 ..< videoLinks.count])
            allLinks += videoLinksSlice.compactMap { $0 as AttachmentConvertible }
        }

        viewCreator.attachmentsView.configure(with: allAttachments, title: "\(Localizable.publicationAttachments.localized) (\(allAttachments.count))")
        viewCreator.linksView.configure(with: allLinks, title: "\(Localizable.publicationLinks.localized) (\(allLinks.count))")
        viewCreator.attachmentsView.isHidden = allAttachments.isEmpty
        viewCreator.attachmentsDivider.isHidden = allAttachments.isEmpty
        viewCreator.linksView.isHidden = allLinks.isEmpty
    }

    private func configureGallery(with images: [Attachments]) {
        viewCreator.galleryView.images = images
        viewCreator.galleryView.isHidden = images.isEmpty
    }

    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension ProjectViewController: ReinitializableViewController {

    func reinitializeView(with id: Int) {
        projectId = id
        viewModel.projectId = id
    }
}

extension ProjectViewController: AttachmentsViewDelegate {

    func attachmentButtonDidTouch(button: AttachmentButton) {
        open(url: URL(string: button.attachment?.url))
    }
}

extension ProjectViewController: OtherPublicationsDelegate {

    func moveToWatchlist() {
        router.pop(animated: true, toDestination: .watchlist)
    }

    func didSelect(publication: Publication) {
        router.push(to: .projectDetails(projectId: publication.watchlistableId), forcePush: true)
    }

    func layoutChanged() {
        viewCreator.updateOtherProjectConstraints()
        view.layoutIfNeeded()
    }
}

extension ProjectViewController: HorizontalGalleryViewDelegate {
    func didSelect(photo: Photo, inPhotos photos: [Photo]) {
        viewModel.show(photoPreview: photo, forPhotos: photos)
    }
}

extension ProjectViewController: PublicationHeaderDelegate {
    func didTapPublicationHeader(_ publicationHeader: PublicationHeaderView) {
        viewModel.showPublisherDetails()
    }

    func didTapShareButton(_ publicationHeader: PublicationHeaderView) { }
}

extension ProjectViewController: ProjectViewDelegate {
    func didTapShareButton(_ projectView: ProjectView) {
        let url = viewModel.projectData.value?.shareUrl
        self.shareNews(url: url)
    }
}

extension ProjectViewController: TTTAttributedLabelDelegate {
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        open(url: url)
    }
}
