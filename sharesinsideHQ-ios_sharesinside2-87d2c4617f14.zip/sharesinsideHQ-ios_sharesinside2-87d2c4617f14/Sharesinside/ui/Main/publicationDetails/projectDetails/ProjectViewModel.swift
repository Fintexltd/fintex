//
//  ProjectViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 11/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class ProjectViewModel: BaseViewModel<HasWatchlistRepository> {

    var projectId: Int? {
        didSet { fetchProjectDetails() }
    }

    let projectData = BehaviorRelay<ProjectInformation?>(value: nil)

    lazy var watchlistRepository = dependencies.watchlistRepository

    private func fetchProjectDetails() {
        guard let id = projectId else {
                alert.accept(AlertData(
                    message: Localizable.publicationWrongData.localized,
                    onPositiveTap: { self.router?.pop() }))
                return
        }
        getProjectDetails(projectId: id)
    }

    private func getProjectDetails(projectId: Int) {
        watchlistRepository.getProjectDetails(id: projectId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] projectDetails in
                    self?.projectData.accept(projectDetails)
                },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent)
                }).disposed(by: disposeBag)
    }

    func show(photoPreview: Photo, forPhotos photos: [Photo]) {
        guard let photoIndex = photos.firstIndex(where: { $0.id == photoPreview.id }) else { return }
        router?.present(destination: .photoPreview(legalEntityName: projectData.value?.issuerName ?? "",
                                                   photos: photos,
                                                   initialIndex: photoIndex))
    }

    func showPublisherDetails() {
        guard let issuerType = projectData.value?.issuerType,
            let issuerId = projectData.value?.issuerId else {
            return
        }
        switch issuerType {
        case .company:
            router?.push(to: .companyDetails(companyId: issuerId))
        case .fund:
            router?.push(to: .fundDetails(fundId: issuerId))
        case .fundsManager:
            router?.push(to: .fundManagerDetails(fundManagerId: issuerId))
        case .startup:
            router?.push(to: .startupDetails(startupId: issuerId))
        }
    }
}
