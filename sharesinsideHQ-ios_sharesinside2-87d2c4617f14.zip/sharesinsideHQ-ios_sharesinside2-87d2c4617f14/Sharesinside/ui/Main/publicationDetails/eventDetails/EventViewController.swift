//
//  InformationViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

class EventViewController: BaseViewController<EventViewModel>, UIScrollViewDelegate, UINavigationControllerDelegate {
    
    private lazy var viewCreator = EventView(withParentView: self.view)
    
    private lazy var otherEventsViewController = OtherPublicationsViewController(publicationId: eventId, delegate: self, type: .event)
    
    private var eventId: Int
    private var needReloadItems: Bool = false
    
    init(eventId id: Int) {
        self.eventId = id
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }
    
    override func setupView() {
        viewCreator.setupView()
        viewCreator.headerView.delegate = self
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.eventId = eventId
    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel.onViewWillAppear()
        navigationController?.setupNavigationBar(withStyle: .transparent)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        needReloadItems = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needReloadItems {
            needReloadItems = false
            viewCreator.orientationChanged()
        }
    }
    
    override func initializeView() {
        super.initializeView()
        viewCreator.attachmentsView.delegate = self
        viewCreator.webcastLinkView.delegate = self
        viewCreator.contentScrollView.delegate = self
        viewCreator.descriptionLabel.delegate = self
        otherEventsViewController.delegate = self
        viewCreator.eventDisplayDateSwitch.didChangeDateDisplayType = { [unowned self] dateDisplayType in
            self.viewModel.switch(dateDisplayType: dateDisplayType)
        }
        viewCreator.otherEventsStackView.insertArrangedSubview(otherEventsViewController.view, at: 0)
        automaticallyAdjustsScrollViewInsets = false
        viewCreator.addToCalendarButton.addTarget(self, action: #selector(addToCalendarDidTouch), for: .touchUpInside)
        navigationController?.delegate = self
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.eventState.asDriver()
            .drive(
                onNext: { [weak self] eventState in self?.handleEventState(eventState)
            })
            .disposed(by: disposeBag)
        viewModel.displayDateTypeChange
            .bind { [unowned self] dateDisplayType in
                guard let event = self.viewModel.eventState.value.currentEventInformation else {
                    return
                }
                self.viewCreator.eventDisplayDateSwitch.bind(dateDisplayType: dateDisplayType ?? .local)
                let dateString = event.eventDate?.toString(withFromat: Date.Format.eventDateFormat) ?? "--"
                self.viewCreator.eventDate.text = "\(dateString)"
            }
            .disposed(by: disposeBag)
    }
    
    private func handleEventState(_ state: EventState) {
        switch state {
        case .loading:
            loader.toggle(show: true, dimmedBackground: true)
            hideAllChildren()
        case .loaded(let event):
            configureView(withEvent: event)
            otherEventsViewController.loadData()
            loader.toggle(show: false)
            showAllChildren(animated: true)
        case .error(let message):
            router.push(to: .failure(message: message), animated: true, forcePush: false, routeFlag: .popCurrent)
        }
    }
    
    private func configureView(withEvent event: EventInformation) {
        viewCreator.headerView.configure(with: event)
        viewCreator.descriptionLabel.text = event.prettyPrintedDescription
        
        let webcastLinks = event.links.filter { $0.type == Defaults.AttachmentType.archivedVideo }
        let links = webcastLinks.isEmpty ? event.links : webcastLinks
        configureAdditionalData(with: event.files, andLinks: links)
        
        viewCreator.eventTitle.text = event.title
        let dateString = event.eventDate?.toString(withFromat: Date.Format.eventDateFormat) ?? "--"
        viewCreator.eventDate.text = "\(dateString)"
        viewCreator.eventDisplayDateSwitch.bind(dateDisplayType: viewModel.eventsDisplayDateTypeRepository.displayDateType ?? .local)

        viewCreator.locationView.setup(withAddress: event.address,
                                       longitude: event.longitude,
                                       latitude: event.latitude)
    }
    
    private func configureAdditionalData(with attachments: [Attachments], andLinks links: [Link]) {
        viewCreator.attachmentsView.configure(with: attachments, title: "\(Localizable.publicationAttachments.localized) (\(attachments.count))")
        viewCreator.webcastLinkView.configure(with: links, title: Localizable.publicationWebcastLinks.localized)
        viewCreator.attachmentsView.isHidden = attachments.isEmpty
        viewCreator.attachmentsDivider.isHidden = attachments.isEmpty
        viewCreator.webcastLinkView.isHidden = links.isEmpty
        viewCreator.webcastDivider.isHidden = links.isEmpty
    }
    
    @objc private func addToCalendarDidTouch() {
        viewModel.addToCalendar()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offset = scrollView.contentOffset.y
        let navigationBarAlpha = offset / (viewCreator.eventTopView.frame.height * 0.4)
        updateNaviagtionBar(withAlpha: navigationBarAlpha)
    }
    
    private func updateNaviagtionBar(withAlpha alpha: CGFloat) {
        let image = UIImage(color: UIColor.primaryDark.withAlpha(alpha))
        navigationController?.navigationBar.setBackgroundImage(image, for: .default)
    }
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension EventViewController: ReinitializableViewController {
    
    func reinitializeView(with id: Int) {
        eventId = id
        viewModel.eventId = id
    }
}

extension EventViewController: AttachmentsViewDelegate {
   
    func attachmentButtonDidTouch(button: AttachmentButton) {
        guard let url = URL(string: button.attachment?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }
}

extension EventViewController: OtherPublicationsDelegate {
    
    func moveToWatchlist() {
        router.pop(animated: true, toDestination: .watchlist)
    }
    
    func didSelect(publication: Publication) {
        router.push(to: .eventDetails(eventId: publication.watchlistableId), forcePush: true)
    }
    
    func layoutChanged() {
        viewCreator.updateOtherEventsConstraints()
        view.layoutIfNeeded()
    }
}

extension EventViewController: PublicationHeaderDelegate {
    func didTapPublicationHeader(_ publicationHeader: PublicationHeaderView) {
        viewModel.showCompanyDetails()
    }
    
    func didTapShareButton(_ publicationHeader: PublicationHeaderView) {
    }
}

extension EventViewController: TTTAttributedLabelDelegate {
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        open(url: url)
    }
}
