//
//  InformationView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

class EventView: BaseViewCreator {
    
    let headerView = PublicationHeaderView()

    // MARK: Event top view
    let eventTitle: UILabel = {
        let title = UILabelFactory.styled(textColor: .accent,
                                          withFontSize: Defaults.TextSize.big,
                                          fontWeight: .bold)
        return title
    }()
    
    let eventDate: UILabel = {
        let dateLabel = UILabelFactory.styled(textColor: .accent,
                                              withFontSize: Defaults.TextSize.small,
                                              fontWeight: .bold)
        
        return dateLabel
    }()

    let eventDisplayDateSwitch = EventDisplayDateSwitch()
    
    private let addToCalendarIcon: UIImageView = {
        let icon = UIImageView(image: #imageLiteral(resourceName: "IconAddToCalendar")).layoutable()
        icon.tintColor = .accent
        icon.contentMode = .scaleAspectFit
        
        return icon
    }()
    
    let addToCalendarButton: UIButton = {
        let button = UIButton().layoutable()
        return button
    }()
    
    let backgroundImage: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "IconEventBackground")).layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        
        return imageView
    }()

    private let addToCalendarContainer: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .event
        view.layer.cornerRadius = Defaults.Watchlist.addToCalendarIconSize / 2
        view.clipsToBounds = true
        
        return view
    }()
    
    let eventTopView = UIView().layoutable()

    // MARK: Description
    let descriptionLabel: TTTAttributedLabel = {
        let label = UILabelFactory.styled(
            label: TTTAttributedLabel(frame: .zero),
            textColor: .darkGrey,
            withFontSize: Defaults.TextSize.medium
        )
        label.textAlignment = .left
        label.enabledTextCheckingTypes = NSTextCheckingResult.CheckingType.link.rawValue
        return label
    }()
    
    // MARK: Attachments and links
    let attachmentsView = AttachmentsView()
    
    let webcastLinkView = AttachmentsView()
    
    // MARK: Dividers
    let descriptionDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    let attachmentsDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    let webcastDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    let divider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        
        return view
    }()
    
    let locationView = LocationView()

    // MARK: Content 
    lazy var mainInformationStackView = UIStackView.make(
        axis: .vertical,
        with: [
            headerView.embedInView(),
            descriptionLabel.embedInView(),
            descriptionDivider,
            attachmentsView,
            attachmentsDivider,
            webcastLinkView,
            webcastDivider,
            locationView.embedInView()
        ])
    
    lazy var otherEventsStackView = UIStackView.make(axis: .vertical, with: [])
    
    lazy var otherEventsContainer = otherEventsStackView.embedInView()
    
    lazy var contentStackView = UIStackView.make(
        axis: AppInfo.orientation.isPortrait ? .vertical : .horizontal,
        with: [
            mainInformationStackView.embedInView(),
            otherEventsContainer
        ])
    
    let contentView = UIView().layoutable()
    
    let contentScrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsVerticalScrollIndicator = false
        scrollView.bounces = false
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        }
        
        return scrollView
    }()
 
    override func setupViewHierarchy() {
        [addToCalendarIcon, addToCalendarButton].forEach { addToCalendarContainer.addSubview($0) }
        [backgroundImage, eventTitle, eventDate, eventDisplayDateSwitch, addToCalendarContainer].forEach { eventTopView.addSubview($0) }
        otherEventsContainer.addSubview(divider)
        [contentStackView, eventTopView].forEach { contentView.addSubview($0) }
        contentScrollView.addSubview(contentView)
        parentView.addSubview(contentScrollView)
    }
    
    override func setupConstraints() {
        setupEventTopViewConstraints()
        setupMainInformationConstraints()
        setupContainersConstraints()
        
        contentStackView.snp.makeConstraints { make in
            make.top.equalTo(eventTopView.snp.bottom)
            make.leading.bottom.trailing.equalToSuperview()
        }
        
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        contentScrollView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func setupContainersConstraints() {
        mainInformationStackView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.lessThanOrEqualToSuperview()
        }
        updateOtherEventsConstraints()
    }
}

extension EventView {
    
    private func setupMainInformationConstraints() {
        headerView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
        
        descriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview()
        }
        
        descriptionDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        
        attachmentsDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        
        webcastDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        
        locationView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.bottom.equalToSuperview()
        }
    }
    
    private func setupEventTopViewConstraints() {
        eventTopView.snp.makeConstraints { make in
            make.leading.trailing.top.equalToSuperview()
        }
        
        eventTitle.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().inset(Defaults.Publication.eventTitleTopMargin)
        }

        eventDisplayDateSwitch.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(eventTitle.snp.bottom).offset(Defaults.marginTiny)
        }
        
        eventDate.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalTo(eventDisplayDateSwitch.snp.bottom).offset(Defaults.marginTiny)
        }
        
        addToCalendarContainer.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(Defaults.marginBig)
            make.width.equalTo(Defaults.Watchlist.addToCalendarIconSize)
            make.height.equalTo(addToCalendarContainer.snp.width)
            make.top.equalTo(eventDate.snp.bottom).offset(Defaults.marginBig)
        }
        
        addToCalendarIcon.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.Watchlist.addToCalendarPadding)
        }
        
        addToCalendarButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}

extension EventView {

    func orientationChanged() {
        contentStackView.axis = AppInfo.orientation.isPortrait ? .vertical : .horizontal
        updateOtherEventsConstraints()
    }
    
    func updateOtherEventsConstraints() {
        otherEventsStackView.snp.remakeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.lessThanOrEqualToSuperview()
            make.width.equalTo(parentView.snp.width).multipliedBy(AppInfo.orientation.isPortrait ? 1 : 0.4)
        }
        
        divider.snp.remakeConstraints { make in
            make.top.leading.equalToSuperview()
            if AppInfo.orientation.isPortrait {
                make.height.equalTo(Defaults.dividerSize).priority(.highest)
                make.width.greaterThanOrEqualTo(contentScrollView.snp.width)
            } else {
                make.width.equalTo(Defaults.dividerSize).priority(.highest)
                make.height.greaterThanOrEqualTo(contentScrollView.snp.height)
            }
        }
    }
}
