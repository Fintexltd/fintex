//
//  InformationViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum EventState {
    case loading
    case loaded(EventInformation)
    case error(String)

    var currentEventInformation: EventInformation? {
        switch self {
        case .loaded(let data): return data
        default: return nil
        }
    }
}

class EventViewModel: BaseViewModel<HasWatchlistRepository & HasCalendarManager & HasEventsDisplayDateTypeRepository> {
    
    var eventId: Int? {
        didSet { loadData() }
    }
    
    let eventState = BehaviorRelay<EventState>(value: .loading)

    var displayDateTypeChange: Observable<EventDateDisplayType?> {
        eventsDisplayDateTypeRepository.displayDateTypeChange
    }
    
    lazy var watchlistRepository = dependencies.watchlistRepository
    lazy var calendarManager = dependencies.calendarManager
    lazy var eventsDisplayDateTypeRepository = dependencies.eventsDisplayDateTypeRepository

    private func loadData() {
        guard let eventId = eventId else {
                eventState.accept(.error(Localizable.publicationWrongData.localized))
                return
        }
        getEventDetails(eventId: eventId)
    }
    
    private func getEventDetails(eventId: Int) {
        watchlistRepository.getEventDetails(id: eventId)
            .do(onSubscribe: { [weak self] in self?.eventState.accept(.loading) })
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] eventDetails in
                    self?.eventState.accept(.loaded(eventDetails))
                },
                onError: { [weak self] error in
                    self?.eventState.accept(.error(error.localizedDescription))
                })
            .disposed(by: disposeBag)
    }
    
    func addToCalendar() {
        if case EventState.loaded(let event) = eventState.value {
            let eventData = CalendarManager.EventData(title: event.title,
                                                      date: event.utcDate.toTimezone(),
                                                      description: event.description,
                                                      address: event.address)
            calendarManager.addToCalendar(event: eventData) { [weak self] (success, _) in
                self?.alert.accept(AlertData(message: (success ? Localizable.watchlistAddedEvent : Localizable.watchlistAddedEventError).localized))
            }
        }
    }

    func `switch`(dateDisplayType: EventDateDisplayType) {
        eventsDisplayDateTypeRepository.displayDateType = dateDisplayType
    }
    
    func showCompanyDetails() {
        guard let issuerType = eventState.value.currentEventInformation?.issuerType,
            let issuerId = eventState.value.currentEventInformation?.issuerId else {
            return
        }
        switch issuerType {
        case .company:
            router?.push(to: .companyDetails(companyId: issuerId))
        case .fund:
            router?.push(to: .fundDetails(fundId: issuerId))
        case .fundsManager:
            router?.push(to: .fundManagerDetails(fundManagerId: issuerId))
        case .startup:
            router?.push(to: .startupDetails(startupId: issuerId))
        }
    }
}
