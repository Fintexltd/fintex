//
//  EventsViewController.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class EventsViewController: BaseViewController<EventsViewModel>, UIGestureRecognizerDelegate {

    private lazy var viewCreator = EventsView(withParentView: self.view)
    private var calendarViewController: CalendarViewController?
    private var eventsTableViewController: EventsListViewController?
    
    private var needReloadLayout = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passDataToChildContollers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
        callViewModelUpdate()
    }

    override func setupView() {
        viewCreator.setupView()
        setupChildViewControllers()
        bindChildControllerViewsToContainers()
        setupTitleViewAction()
        setupDismissCalendarGestureRecognizer()
        setupNavigationBar()
    }
    
    override func initializeView() {
        super.initializeView()
        viewCreator.filterView.delegate = self
        viewCreator.navigationItemView.searchButton.addTarget(self, action: #selector(showSearch), for: .touchUpInside)
        updateLayoutDueToScreenOrientationChange()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        needReloadLayout = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needReloadLayout {
            needReloadLayout = false
            updateLayoutDueToScreenOrientationChange()
        }
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.watchlistState
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] watchlistState in
                self?.eventsTableViewController?.viewCreator.tableView.state = watchlistState
                self?.eventsTableViewController?.endRefreshing()
            }).disposed(by: disposeBag)
        
        viewModel.scopeDates
            .ignoreNil()
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] scopeDates in
                self?.eventsTableViewController?.setScopeDescription(with: scopeDates.startDate,
                                                                     basedOn: [scopeDates.endDate],
                                                                     shouldShowStarDateAsCurrentDate: false)
            }).disposed(by: disposeBag)
    }
    
    private func callViewModelUpdate() {
        let startDate = Calendar.current.date(byAdding: .year, value: -1, to: Date())!
        viewModel.getDaysWithEvents(startDate: startDate, success: { dates in
            self.calendarViewController?.setDaysWithEvents(dates)
        }, failure: { _ in })
        
        viewModel.filtersData
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] filtersData in
                self?.viewCreator.filterView.configure(with: filtersData.filters, andSelectedCount: filtersData.selectedFilters)
            }).disposed(by: disposeBag)
        
        viewModel.filters.subscribe(onNext: { [weak self] filters in
            guard let self = self else { return }
            self.eventsTableViewController?.setSearchText(filters.search)
        }).disposed(by: disposeBag)
    }
    
    private func setupChildViewControllers() {
        self.calendarViewController = CalendarViewController()
        self.eventsTableViewController = EventsListViewController()
        eventsTableViewController?.delegate = self
        calendarViewController?.delegate = self
        addChild(calendarViewController!)
        addChild(eventsTableViewController!)
    }
    
    private func bindChildControllerViewsToContainers() {
        if let eventsTableViewController = eventsTableViewController {
            viewCreator.addEdgeConstrained(eventsTableViewController.view, to: viewCreator.tableViewContainter)
        }
        if let calendarViewController = calendarViewController {
            viewCreator.addEdgeConstrained(calendarViewController.view, to: viewCreator.calendarContainer)
        }
        
    }
    
    private func setupNavigationBar() {
        viewCreator.navigationItemView.setup(in: navigationItem)
        navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    private func setupTitleViewAction() {
        viewCreator.navigationItemView.add(self, action: #selector(didTapNavigationItemTitle))
    }
    
    private func setupDismissCalendarGestureRecognizer() {
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(hideCalendarContainer))
        eventsTableViewController?.view.addGestureRecognizer(recognizer)
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.listType = .events
    }
    
    private func passDataToChildContollers() {
        let calendarScope = viewModel.prepareCalendarScope()
        calendarViewController?.setScope(calendarScope)
    }
    
    private func updateLayoutDueToScreenOrientationChange() {
        viewCreator.updateNavigationTitleArrowVisiblitiy()
        viewCreator.setupConstraints()
        calendarViewController?.updateLayoutDueToScreenOrientationChange()
    }
    
    @objc private func didTapNavigationItemTitle() {
        viewCreator.setCalendarIsVisible(viewCreator.navigationItemView.isSelected)
    }
    
    @objc private func hideCalendarContainer() {
        viewCreator.setCalendarIsVisible(false)
    }
    
    @objc private func showSearch() {
        viewModel.showSearchController()
    }
    
    // MARK: - Gesture Recognizer methods
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return viewCreator.navigationItemView.isSelected
    }
    
}

// MARK: - CalendarViewControllerDelegate methods
extension EventsViewController: CalendarViewControllerDelegate {
    
    func calendar(_ calendar: CalendarViewController, didSelect day: Day) {
        
        if AppInfo.isIPhone || AppInfo.orientation.isPortrait {
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5, execute: { [weak self] in
                self?.hideCalendarContainer()
            })
        }
        
        viewModel.selectedCalendarDate(day.date)
    }
    
    func calendar(_ calendar: CalendarViewController, didShow month: Month?) {
        
        var title = month?.name ?? ""
        if let month = month {
            let monthYear = Calendar.current.component(.year, from: month.startDate)
            if monthYear != Calendar.current.component(.year, from: Date()) {
                title += " " + monthYear.description
            }
        }
        viewCreator.navigationItemView.set(title)
        viewModel.refresh()
    }
}

extension EventsViewController: EventsListViewControllerDelegate {
    func eventsListDidSelect(publication: Event) {
        viewModel.selected(publication: publication)
    }
    
    func eventsListDidScrollToTop() {
        
    }
    
    func eventsListDidSelectAddToCalendar(for event: Event) {
        viewModel.addToCalendar(event: event)
    }
    
    func eventsListDidScrollToBottom() {
        print("EventsList didScrollToBottom")
        viewModel.loadMoreData()
    }
    
    func eventsListDidPullToRefresh() {
        viewModel.refresh()
    }
    
    func eventsListDidSelectToClearSearch() {
        viewModel.searchFor(fraze: "")
    }

    func eventsListDidSwitch(dateDisplayType: EventDateDisplayType) {
        viewModel.switch(displayDateType: dateDisplayType)
    }
}

extension EventsViewController: PredefinedFiltersViewDelegate {
    
    func didSelect(filter: Filter) {
        viewModel.selectedPredefinedFilter(filter)
    }
    
    func moreFiltersDidTouch() {
        viewModel.showMoreFitlers()
    }
    
}
