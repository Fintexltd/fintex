//
//  EventsView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EventsView: BaseViewCreator {
    
    // MARK: - Views
    
    lazy var calendarContainer: UIView = {
        let container = UIView().layoutable()
        container.backgroundColor = UIColor.primaryDark
        return container
    }()
    
    lazy var filterView: PredefinedFiltersView = {
        let filterView = PredefinedFiltersView()
        return filterView
    }()
    
    lazy var tableViewContainter: UIView = {
        let container = UIView().layoutable()
        container.backgroundColor = .white
        return container
    }()
    
    lazy var navigationItemView: EventsNavigationItemView = {
        let view = EventsNavigationItemView()
        return view
    }()
    
    // MARK: - Setup methods    
    override func setupViewHierarchy() {
        [filterView, tableViewContainter, calendarContainer].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        calendarContainer.snp.remakeConstraints { make in
            if AppInfo.orientation.isLandscape {
                make.top.bottom.equalToSuperview()
                make.width.equalTo(Defaults.Events.calendarContentSize)
                make.left.equalToSuperview()
            } else {
                make.left.right.equalToSuperview()
                make.height.equalTo(Defaults.Events.calendarContentSize)
                make.top.equalToSuperview().inset(-Defaults.Events.calendarContentSize)
            }
        }
        
        filterView.snp.remakeConstraints { make in
            make.top.right.equalToSuperview()
            
            if AppInfo.orientation.isLandscape && AppInfo.isIPad {
                make.left.equalTo(calendarContainer.snp.right)
            } else {
                make.left.equalToSuperview()
            }
        }
        
        tableViewContainter.snp.remakeConstraints { make in
            make.top.equalTo(filterView.snp.bottom)
            make.right.bottom.equalToSuperview()
            if AppInfo.orientation.isLandscape {
                make.left.equalTo(calendarContainer.snp.right)
            } else {
                make.left.equalToSuperview()
            }
        }
    }
    
    func updateNavigationTitleArrowVisiblitiy() {
        let shouldBeHidden = !(AppInfo.isIPhone || AppInfo.orientation.isPortrait)
        self.navigationItemView.arrowImageView.isHidden = shouldBeHidden
        self.navigationItemView.titleView.isUserInteractionEnabled = AppInfo.orientation.isPortrait
        if AppInfo.orientation.isLandscape {
            setCalendarIsVisible(false, animated: true)
        }
    }
    
    func addEdgeConstrained(_ subview: UIView, to view: UIView) {
        view.addSubview(subview)
        subview.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func setCalendarIsVisible(_ flag: Bool, animated: Bool = true) {
        navigationItemView.setSelected(flag, animated: animated)
        let duration = animated ? Defaults.animationDuration : 0
        self.calendarContainer.snp.updateConstraints { make in
            let relation = AppInfo.orientation.isLandscape ? make.left : make.top
            let isHiddenValue: CGFloat = -Defaults.Events.calendarContentSize
            let insetValue = flag ? 0 : isHiddenValue
            relation.equalToSuperview().inset(insetValue)
        }
        UIView.animate(withDuration: duration, animations: {
            self.parentView.layoutIfNeeded()
        })
        
    }
}
