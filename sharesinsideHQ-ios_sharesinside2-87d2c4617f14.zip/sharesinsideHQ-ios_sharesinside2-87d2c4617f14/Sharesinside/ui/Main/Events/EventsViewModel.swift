//
//  EventsViewModel.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class EventsViewModel: WatchlistViewModel {
    
    let scopeDates = BehaviorRelay<(startDate: Date, endDate: Date)?>(value: nil)
    
    private let moreDataNeedRelay = BehaviorRelay(value: 1)
    private let eventsResponse = BehaviorRelay<WatchlistData?>(value: nil)
    
    override func onViewDidLoad() {
        filters.accept(filters.value.with(startDate: Date().toString(withFromat: .ohlcDateFormat)))
        if let endDate = Calendar.current.date(byAdding: .year, value: 1, to: Date()) {
            filters.accept(filters.value.with(endDate: endDate.toString(withFromat: .ohlcDateFormat)))
        }
        
        super.onViewDidLoad()
    }

    override func onViewWillAppear() {
        super.onViewWillAppear()
        
        let startDate = Calendar.current.date(byAdding: .year, value: -1, to: Date()) ?? Date()
        getDaysWithEvents(startDate: startDate, success: { dates in
            self.scopeDates.accept((Date(), dates.last ?? startDate))
        }, failure: { _ in })
    }

    override func fetchFilters() {
        filtersRepository.getEventsPredefinedFilters()
            .subscribe(
                onNext: { [weak self] in
                    guard let `self` = self else { return }
                    let mappedFilters = $0.map { $0.with(selection: self.filters.value.adHoc) }
                    self.filtersData.accept((mappedFilters, self.filters.value.selectionCount, self.filters.value.search))
                },
                onError: { error in printDebug(error) })
            .disposed(by: disposeBag)
    }
    
    override func updateDayRangeFilter(_ filter: Filter) {
        super.updateDayRangeFilter(filter)
        scopeDates.accept((filters.value.getDateFrom(),
                           endDate: filters.value.getDateTo()))
    }
}

// MARK: - Endpoints
extension EventsViewModel {
    
    func prepareCalendarScope() -> CalendarScope {
        let calendarScope = CalendarScope()
        return calendarScope!
    }
    
    func getDaysWithEvents(startDate: Date? = nil, success: @escaping([Date]) -> Void, failure: @escaping (AppError) -> Void) {
        eventsRepository.getDaysWithEvents(startDate: startDate ?? Calendar.current.date(byAdding: .year, value: -1, to: Date())!)
            .subscribe(onNext: { model in
                DispatchQueue.main.sync {
                    success(model.dates)
                }
            })
            .disposed(by: disposeBag)
    }
    
    func showSearchController() {
        router?.push(to: .search(filters: filters.value, delegate: self))
    }
    
    func showMoreFitlers() {
        router?.present(destination: .filters(filterTypes: [
            .watchlistRelation,
            .publicity
            ], initialFilters: filters.value, delegate: self))
    }
    
    func selectedCalendarDate(_ date: Date?) {
        var updatedFilter = filters.value.with(startDate: date?.toString(withFromat: .ohlcDateFormat) ?? "")
        if let date = date {
            updatedFilter = updatedFilter.with(eventsForToday: false, eventsForTomorrow: false)
            scopeDates.accept((date, endDate: updatedFilter.getDateTo()))
        }
        
        filters.accept(updatedFilter)
        didSelect(filters: self.filters.value)
        refresh()
    }
}

extension EventsViewModel: SearchViewControllerDelegate {
    func didSelect(textToSearch: String) {
        searchFor(fraze: textToSearch)
    }
}

struct CalendarScope {
    let months: [Month]
    init?() {
        let calendar = Calendar.current
        let currentDate = Date()
        guard
            let scopeStartDate = calendar.date(byAdding: .month, value: -7, to: currentDate),
            let scopeEndDate = calendar.date(byAdding: .month, value: 12, to: currentDate)
        else { return nil }
        
        let oneMonthTimeInterval: TimeInterval = 60 * 60 * 24 * 30
        var months: [Month] = []
        var date = scopeStartDate
        while date < scopeEndDate {
            months.append(Month(basedOn: date))
            date = calendar.date(byAdding: .month, value: 1, to: date) ?? date.addingTimeInterval(oneMonthTimeInterval)
        }
        self.months = months
    }
    
    func configure(with daysWithEvent: [Date]) {
        self.months.forEach { $0.configure(with: daysWithEvent) }
    }
}
