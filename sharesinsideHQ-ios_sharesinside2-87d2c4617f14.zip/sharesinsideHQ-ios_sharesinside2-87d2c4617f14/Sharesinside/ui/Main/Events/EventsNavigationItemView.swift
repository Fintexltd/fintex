//
//  EventsNavigationItemView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EventsNavigationItemView: BaseView {

    private var tapNavigationItemTitleAction: (target: Any, selector: Selector)?
    private(set) var isSelected = false

    lazy var accountButton: UIButton = {
        return ButtonFactory.makeAccountButton()
    }()

    lazy var monthLabelTapGestureRecognizer: UITapGestureRecognizer = {
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(didTapNavigationItemTitle))
        return recognizer
    }()

    lazy var titleView: UIStackView = {
        let stackView = UIStackView.make(axis: .horizontal, with: [], spacing: Defaults.marginTiny)
        stackView.isUserInteractionEnabled = true
        stackView.addGestureRecognizer(monthLabelTapGestureRecognizer)
        return stackView
    }()

    lazy var arrowImageView: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "IconArrowSnackBar"))
        imageView.frame.size = CGSize(width: Defaults.Events.navigationBarArrowConstant, height: Defaults.Events.navigationBarArrowConstant)
        imageView.image = imageView.image?.rotatedBy(degrees: 180).withRenderingMode(.alwaysTemplate)
        imageView.tintColor = .white
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    lazy var monthLabel: UILabel = {
        let label = UILabel().layoutable()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.big, weight: .bold)
        return label
    }()

    lazy var searchButton: UIButton = {
        return ButtonFactory.makeSearchButton()
    }()

    override var intrinsicContentSize: CGSize {
        return UIView.layoutFittingExpandedSize
    }

    override func setupViewHierarchy() {
        [monthLabel, arrowImageView].forEach { titleView.addArrangedSubview($0) }
        [titleView, accountButton, searchButton].forEach { addSubview($0) }
    }

    override func setupConstraints() {
        accountButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().inset(Defaults.marginTiny)
            make.width.equalTo(Defaults.Navigation.itemWidth)
            make.height.equalTo(Defaults.Navigation.itemHeight)
        }

        searchButton.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.trailing.equalToSuperview()
            make.width.equalTo(Defaults.Navigation.searchSize)
        }

        titleView.snp.makeConstraints { make in
            make.left.equalTo(accountButton.snp.right).offset(Defaults.marginBig)
            make.trailing.lessThanOrEqualTo(searchButton.snp.leading).inset(Defaults.marginTiny)
            make.centerY.equalTo(accountButton.snp.centerY)
        }

        if AppInfo.isIPhone {
            arrowImageView.snp.makeConstraints { make in
                make.width.equalTo(20)
                make.height.equalToSuperview().priority(.low)
            }
        }

        self.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Navigation.barHeight)
        }

        titleView.setNeedsLayout()
    }

    override func setupProperties() {
        arrowImageView.isHidden = AppInfo.isIPad && AppInfo.orientation.isLandscape
    }

    func setup(in navigationItem: UINavigationItem) {
        if #available(iOS 11.0, *) {
            navigationItem.titleView = self
        } else {
            navigationItem.titleView = self
            navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchButton)
        }
        accountButton.addTarget(self, action: #selector(showProfile), for: .touchUpInside)
    }

    @objc private func showProfile() {
        let viewController = BaseNavigationController(rootViewController: ProfileViewController())
        accountButton.viewController?.present(viewController, animated: true, completion: nil)
    }

    func setSelected(_ selected: Bool, animated: Bool = true) {
        isSelected = selected
        rotateArrowImage()
    }

    @objc private func didTapNavigationItemTitle() {
        isSelected = !isSelected
        rotateArrowImage()
    }

    private func rotateArrowImage() {
        let transformMatrix: CGAffineTransform = isSelected ? CGAffineTransform(rotationAngle: CGFloat(Double.pi)) : .identity
        UIView.animate(withDuration: Defaults.animationDuration, animations: { [weak self] in
            self?.arrowImageView.transform = transformMatrix
        })
    }

    func add(_ target: Any, action: Selector) {
        self.monthLabelTapGestureRecognizer.addTarget(target, action: action)
    }

    func set(_ title: String?) {
        self.monthLabel.text = title
    }
}
