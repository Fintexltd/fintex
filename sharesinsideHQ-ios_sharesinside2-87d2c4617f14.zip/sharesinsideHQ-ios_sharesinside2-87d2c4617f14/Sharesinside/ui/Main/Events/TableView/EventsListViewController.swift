//
//  EventsTableViewController.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol EventsListViewControllerDelegate: class {
    func eventsListDidPullToRefresh()
    func eventsListDidSelect(publication: Event)
    func eventsListDidScrollToTop()
    func eventsListDidScrollToBottom()
    func eventsListDidSelectAddToCalendar(for event: Event)
    func eventsListDidSelectToClearSearch()
    func eventsListDidSwitch(dateDisplayType: EventDateDisplayType)
}

class EventsListViewController: UIViewController {

    lazy var viewCreator = EventsListControllerView(withParentView: self.view)
    
    weak var delegate: EventsListViewControllerDelegate?
    
    override func loadView() {
        self.view = UIView()
        self.view.backgroundColor = .white
        viewCreator.setupView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    private func setupViews() {
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        
        viewCreator.tableView.eventDelegate = self
        viewCreator.tableView.customDelegate = self
        
        viewCreator.clearSearchButton.addTarget(self, action: #selector(didTouchClearSearch), for: .touchUpInside)
    }
    
    func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.tableView.refreshControl?.endRefreshing()
        }
    }
    
    func setScopeDescription(with startDate: Date, basedOn dates: [Date], shouldShowStarDateAsCurrentDate: Bool = true) {
        guard let endDate = dates.last else { return }
        let startDate = shouldShowStarDateAsCurrentDate ? Date() : startDate
        self.setScopeDescription(startDate: startDate, endDate: endDate)
    }
    
    func setSearchText(_ searchText: String?) {
        viewCreator.setSearchText(searchText)
    }
    
    private func setScopeDescription(startDate: Date, endDate: Date?) {
        var calendar = Calendar.current
        calendar.locale = Locale(identifier: "en_US")
        
        func getDescription(of date: Date) -> String {
            var description = ""
            let components = calendar.dateComponents(Set([.day, .weekday, .month, .year]), from: date)
            if let weekdayIndex = components.weekday, Calendar.current.shortWeekdaySymbols.count >= weekdayIndex {
                let weekday = calendar.shortWeekdaySymbols[weekdayIndex-1]
                description += weekday + " "
            }
            if let day = components.day {
                description += day.description + " "
            }
            if let monthIndex = components.month, calendar.shortMonthSymbols.count >= monthIndex {
                let month = calendar.standaloneMonthSymbols[monthIndex-1]
                description += month + " "
            }
            let currentYear = calendar.component(.year, from: Date())
            let dateYear = components.year!
            if dateYear != currentYear {
                description += dateYear.description
            }
            return description
        }
        
        var description = getDescription(of: startDate)
        if let endDate = endDate, endDate.compare(startDate) != .orderedSame {
            description += " – " + getDescription(of: endDate)
        }
        
        viewCreator.setScope(description)
    }

    @objc private func didSwipeForRefresh() {
        delegate?.eventsListDidPullToRefresh()
    }
    
    @objc private func didTouchClearSearch() {
        delegate?.eventsListDidSelectToClearSearch()
    }
}

extension EventsListViewController: EventDetailsViewDelegate {

    func didSwitch(dateDisplayType: EventDateDisplayType) {
        delegate?.eventsListDidSwitch(dateDisplayType: dateDisplayType)
    }
    
    func addEventToCalendar(_ event: Event) {
        delegate?.eventsListDidSelectAddToCalendar(for: event)
    }
    
    func didSelect(_ event: Event) {
        delegate?.eventsListDidSelect(publication: event)
    }
}

extension EventsListViewController: EventsListTableViewDelegate {
    func eventsTableViewDidSelect(_ event: Event) {
        delegate?.eventsListDidSelect(publication: event)
    }
    
    func eventsTableViewDidSelectAddToCalendar(for event: Event) {
        delegate?.eventsListDidSelectAddToCalendar(for: event)
    }
    
    func eventsTableView(_ tableView: EventsListTableView, didLoadEventsScope beginingDate: Date, endDate: Date?) {

    }
    
    func eventsTableViewDidScrollToBottom(_ tableView: EventsListTableView) {
        delegate?.eventsListDidScrollToBottom()
    }
    
}
