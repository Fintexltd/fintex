//
//  EventsListTableViewCellView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 11/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EventsListTableViewCellView: BaseViewCreator {
    
    var eventView: EventDetailsView!
    
    lazy var cellStackView: UIStackView = {
        let stackView = UIStackView().layoutable()
        stackView.distribution = .fill
        stackView.alignment = .fill
        return stackView
    }()
    lazy var sectionDateContainer: UIView = {
        let view = UIView()
        return view
    }()
    lazy var sectionDateStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = Defaults.marginMicro
        stackView.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        return stackView
    }()
    lazy var sectionDayOfMonthLabel: UILabel = {
        let label = UILabel()
        label.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.big, weight: .semibold)
        return label
    }()
    lazy var sectionMonthAndYearLabel: UILabel = {
        let label = UILabel()
        label.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.medium, weight: .semibold)
        return label
    }()
    lazy var sectionWeekdayLabel: UILabel = {
        let label = UILabel()
        label.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.medium, weight: .regular)
        return label
    }()
    lazy var eventViewContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    private func buildEventView(basedOn model: Event) -> EventDetailsView {
        let view = EventDetailsView()
        view.event = model
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(didSelectEvent(_:)))
        view.addGestureRecognizer(tapRecognizer)
        return view
    }
    
    // MARK: - ViewCreator initialization methods
    
    override func setupViewHierarchy() {
        parentView.addSubview(cellStackView)
        cellStackView.addArrangedSubview(sectionDateContainer)
        cellStackView.addArrangedSubview(eventViewContainer)
    }
    
    override func setupConstraints() {
        cellStackView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.left.equalToSuperview().offset(Defaults.marginMicro)
            make.right.bottom.equalToSuperview().inset(Defaults.marginTiny)
        }
        sectionDateContainer.snp.makeConstraints { make in
            make.width.equalTo(AppInfo.isIPad ? 100 : 80)
        }
    }
    
    override func setupProperties() {
    }
    
    @objc private func didSelectEvent(_ selector: Any) {
        guard let event = eventView.event else { return }
        eventView.delegate?.didSelect(event)
    }
    
    // MARK: - Enpoints
    
    func setupEventView(basedOn model: Event?) {
        guard let event = model else { return }
        eventView = buildEventView(basedOn: event)
        eventViewContainer.addSubview(eventView)
        eventView.snp.makeConstraints { make in
            make.top.left.equalToSuperview()
            make.right.equalToSuperview()
        }
        eventViewContainer.snp.makeConstraints { make in
            make.bottom.equalTo(eventView.snp.bottom)
        }
    }
    
    func setupDateViews(basedOn model: Event?) {
        guard let event = model else {
            sectionWeekdayLabel.text = ""
            sectionDayOfMonthLabel.text = ""
            sectionMonthAndYearLabel.text = ""
            return
        }
        sectionDateContainer.addSubview(sectionDateStackView)
        [sectionDayOfMonthLabel, sectionMonthAndYearLabel, sectionWeekdayLabel].forEach { sectionDateStackView.addArrangedSubview($0) }
        if let eventDate = event.details.eventDate {
            let weekdayIndex = Calendar.current.component(.weekday, from: eventDate) - 1
            let weekdaySymbol = Calendar.current.shortWeekdaySymbols[weekdayIndex].lowercased().capitalized
            self.sectionWeekdayLabel.text = weekdaySymbol
            
            let dayOfMonth = Calendar.current.component(.day, from: eventDate)
            self.sectionDayOfMonthLabel.text = dayOfMonth.description
            
            let monthIndex = Calendar.current.component(.month, from: eventDate) - 1
            let monthSymbol = Calendar.current.shortMonthSymbols[monthIndex]
            
            let year = Calendar.current.component(.year, from: eventDate)
            let formattedYear = "\(year.description.suffix(2))'"
            self.sectionMonthAndYearLabel.text = "\(monthSymbol) \(formattedYear)"
        }
        
        sectionDateStackView.snp.makeConstraints { make in
            make.top.right.equalToSuperview()
            make.left.equalToSuperview().offset(Defaults.marginTiny)
        }
    }
    
}
