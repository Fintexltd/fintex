//
//  EventsListTableViewCell.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 10/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EventsListTableViewCell: UITableViewCell {
    
    lazy var viewCreator = EventsListTableViewCellView(withParentView: contentView)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none 
        viewCreator.setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        event = nil
        date = nil
        viewCreator.setupDateViews(basedOn: nil)
        viewCreator.eventView.removeFromSuperview()
    }
    
    private(set) var date: Date?
    private var event: Event!

    func configure(with model: Event, isFirstRow: Bool, delegate: EventDetailsViewDelegate?) {
        self.event = model
        self.viewCreator.setupEventView(basedOn: event)
        self.viewCreator.eventView?.delegate = delegate
        if isFirstRow {
            self.viewCreator.setupDateViews(basedOn: event)
        }
    }
}
