//
//  EventsListControllerView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 10/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class EventsListControllerView: BaseViewCreator {
    
    private lazy var scopeView: UIStackView = buildScopeView()
    
    private lazy var descriptionLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .regular)
        label.textColor = .grey
        return label
    }()
    
    private lazy var separatorView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    private lazy var searchView = UIView().layoutable()
    
    private lazy var searchLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.small)
        
        label.textAlignment = .left
        return label
    }()
    
    lazy var clearSearchButton: UIButton = {
        let button = UIButton().layoutable()
        button.setImage(#imageLiteral(resourceName: "IconClose"), for: .normal)
        button.tintColor = .grey
        button.contentMode = .scaleAspectFit
        
        let padding = Defaults.Events.clearSearchButtonSize / 4
        button.imageEdgeInsets = UIEdgeInsets(top: padding,
                                              left: padding,
                                              bottom: padding,
                                              right: padding)
        
        return button
    }()
    
    lazy var tableView: EventsListTableView = {
        let tableView = EventsListTableView(frame: .zero, style: .grouped)
        tableView.backgroundColor = .white
        return tableView
    }()
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary
        
        return refreshControl
    }()
    
    override func setupViewHierarchy() {
        tableView.addSubview(refreshControl)
        parentView.addSubview(tableView)
        parentView.addSubview(scopeView)
        parentView.addSubview(separatorView)
    }
    
    override func setupConstraints() {
        
        scopeView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(Defaults.marginMicro).priority(.highest)
            make.left.right.equalToSuperview().inset(Defaults.marginTiny).priority(.highest)
            make.height.greaterThanOrEqualTo(Defaults.Events.scopeDescriptionViewHeight).priority(.highest)
        }
        
        separatorView.snp.makeConstraints { make in
            make.top.equalTo(scopeView.snp.bottom).offset(Defaults.marginMicro)
            make.height.equalTo(Defaults.dividerSize).priority(.highest)
            make.left.right.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(separatorView.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    override func setupProperties() {
        tableView.refreshControl = refreshControl
        scopeView.setContentCompressionResistancePriority(.required, for: .vertical)
    }
    
    private func buildScopeView() -> UIStackView {
        let view = UIStackView.make(
            axis: .vertical,
            with: [
                searchView,
                descriptionLabel
            ],
            spacing: Defaults.marginTiny)
        
        searchView.addSubview(searchLabel)
        searchView.addSubview(clearSearchButton)
        searchView.isHidden = true
        
        searchLabel.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview()
            make.trailing.equalTo(clearSearchButton.snp.leading)
        }
        
        clearSearchButton.snp.makeConstraints { make in
            make.trailing.centerY.equalToSuperview()
            make.width.height.equalTo(Defaults.Events.clearSearchButtonSize).priority(.highest)
        }
        
        return view
    }
    
    func setScope(_ description: String) {
        descriptionLabel.text = description
    }
    
    func setSearchText(_ searchText: String?) {
        searchLabel.text = "\(Localizable.eventsSearchResultsFor.localized) \(searchText ?? "")"
        searchLabel.superview?.isHidden = searchText?.isEmpty != false
        UIView.animate(withDuration: 0.2) {
            self.parentView.layoutIfNeeded()
        }
    }
}
