//
//  EventListTableView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 10/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Foundation

struct EventsListSection {
    let date: Date
    var events: [Event]
}

protocol EventsListTableViewDelegate: class {
    func eventsTableViewDidSelect(_ event: Event)
    func eventsTableViewDidSelectAddToCalendar(for event: Event)
    func eventsTableView(_ tableView: EventsListTableView, didLoadEventsScope beginingDate: Date, endDate: Date?)
    func eventsTableViewDidScrollToBottom(_ tableView: EventsListTableView)
}

class EventsListTableView: UITableView {
    
    weak var eventDelegate: EventDetailsViewDelegate?
    weak var customDelegate: EventsListTableViewDelegate? {
        didSet {
            sendToDelegateScopeDates()
        }
    }
    
    private var cellHeightsDictionary: [IndexPath: CGFloat] = [:]
    
    private lazy var failureView = FailureView()
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        delegate = self
        dataSource = self
        separatorStyle = .none
        estimatedRowHeight = Defaults.Watchlist.estimatedCellHeight
        rowHeight = UITableView.automaticDimension
        
        estimatedSectionFooterHeight = Defaults.Watchlist.estimatedFooterHeight
        sectionFooterHeight = UITableView.automaticDimension
        
        estimatedSectionHeaderHeight = 1
        sectionHeaderHeight = 1
        
        registerCell(EventsListTableViewCell.self)
        backgroundView = failureView
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var shouldReload = false
    
    var state: WatchlistState = .loading {
        willSet(newValue) {
            shouldReload = true
        }
        didSet {
            if shouldReload { reloadData() }
            configureBackgroundView(withState: state)
        }
    }
    var sections: [EventsListSection] = []
    
    private func configureBackgroundView(withState state: WatchlistState) {
        failureView.updateText(state.messageForBackgroundView)
        failureView.showArrow = state.showArrow
        UIView.animate(withDuration: 0.2) {
            self.failureView.alpha = state.messageForBackgroundView.isEmpty ? 0 : 1.0
        }
    }
    
    private func buildScopeView() -> UIView {
        let view = UIView().layoutable()
        return view
    }
}

extension EventsListTableView: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard self.sections.count >= section else { return 0 }
        return sections[section].events.count
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        self.sections = getSections()
        return sections.count
    }
    
    private func getSections() -> [EventsListSection] {
        let events = state.currentWatchlist.compactMap { $0 as? Event }.filter { $0.details.eventDate != nil }
        guard events.count > 0 else { return [] }
        var separatorDate = events.first!.details.eventDate!
        var separatedEvents: [[Event]] = []
        var eventsGroup: [Event] = []
        
        events.forEach { event in
            guard let eventDate = event.details.eventDate else { return }
            let needToSplit = !Calendar.current.isDate(eventDate, inSameDayAs: separatorDate)
            if needToSplit {
                separatorDate = eventDate
                separatedEvents.append(eventsGroup)
                eventsGroup = []
            }
            eventsGroup.append(event)
            if event == events.last {
                separatedEvents.append(eventsGroup)
            }
        }
        
        let sections: [EventsListSection] = separatedEvents.compactMap { groupedEvents in
            if let sectionDate = groupedEvents.first?.details.eventDate {
                return EventsListSection(date: sectionDate, events: Array(groupedEvents))
            } else {
                return nil
            }
        }
        sendToDelegateScopeDates()
        return sections
    }
    
    private func sendToDelegateScopeDates() {
        let events = state.currentWatchlist.compactMap { $0 as? Event }
        if let startDate: Date = events.last?.details.eventDate {
            var endDate: Date? = events.first?.details.eventDate
            if endDate != nil, Calendar.current.isDate(endDate!, inSameDayAs: startDate) {
                endDate = nil
            }
            customDelegate?.eventsTableView(self, didLoadEventsScope: startDate, endDate: endDate)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return state == .populated([]) ? 0 : UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cellHeightsDictionary[indexPath] = cell.frame.size.height
        var row = 0
        for section in 0...indexPath.section {
            row += section == indexPath.section ? indexPath.row : tableView.numberOfRows(inSection: section)
        }
        if row >= state.currentWatchlist.count - 4 {
            customDelegate?.eventsTableViewDidScrollToBottom(self)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? Defaults.Events.tableViewHeaderHeight : 1
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeightsDictionary[indexPath] ?? Defaults.Watchlist.estimatedCellHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: EventsListTableViewCell.className) as! EventsListTableViewCell
        let event = sections[indexPath.section].events[indexPath.row]
        cell.configure(with: event, isFirstRow: indexPath.row == 0, delegate: self.eventDelegate)
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let event = sections[indexPath.section].events[indexPath.row]
        customDelegate?.eventsTableViewDidSelect(event)
    }

}

private extension WatchlistState {
    
    var messageForBackgroundView: String {
        switch self {
        case .empty(let usingFilters):
            return usingFilters ? Localizable.eventsNoResults.localized : Localizable.eventsStartFollowing.localized
        case .error(let error): return error.localizedDescription
        default: return ""
        }
    }
    
}
