//
//  DayCalendarViewControllerCell.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class DayCalendarViewControllerCell: UICollectionViewCell {
    
    private let disposeBag = DisposeBag()
    private(set) var day: Day?
    
    private lazy var separatorView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = UIColor.gray.withAlpha(0.5)
        return view
    }()
    
    private lazy var stackView: UIStackView = {
        let view = UIStackView()
        view.axis = .vertical
        view.spacing = 2
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel().layoutable()
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private lazy var eventPresenceIndicatorContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    private lazy var eventPresenceIndicatiorView: UIView = {
        let indicator = UIView(frame: CGRect(x: 0, y: 0, width: 5, height: 5)).layoutable()
        indicator.backgroundColor = .grey
        indicator.round()
        indicator.isHidden = true
        return indicator
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        setupViewsHierarchy()
        setupContstraints()
        setupProperties()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.reset()
    }
    
    private func setupViewsHierarchy() {
        addSubview(separatorView)
        contentView.addSubview(stackView)
        eventPresenceIndicatorContainer.addSubview(eventPresenceIndicatiorView)
        stackView.addArrangedSubview(titleLabel)
        stackView.addArrangedSubview(eventPresenceIndicatorContainer)
    }
    
    private func setupContstraints() {
        separatorView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
        
        stackView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
        }
        
        eventPresenceIndicatorContainer.snp.makeConstraints { make in
            make.height.equalTo(eventPresenceIndicatiorView.snp.height).multipliedBy(3)
        }
        
        eventPresenceIndicatiorView.snp.makeConstraints { make in
            make.width.height.equalTo(5)
            make.centerY.centerX.equalToSuperview()
        }
    
        titleLabel.snp.makeConstraints { make in
            make.width.height.equalTo(Defaults.Events.DayCellLabelHeight)
        }
    }
    
    private func setupProperties() {
        backgroundColor = .primaryDark
        separatorView.isHidden = true
    }
    
    func configure(with model: Day) {
        self.day = model
        if let dayDate = model.date, Calendar.current.isDateInToday(dayDate) {
            titleLabel.textColor = .event
            
        }
        titleLabel.font = UIFont.systemFont(ofSize: titleLabel.font.pointSize, weight: .medium)
        separatorView.isHidden = model.number == nil
        titleLabel.text = model.number?.description
        
        model.hasEvent.bind { [weak self] hasEvent in
            self?.eventPresenceIndicatiorView.isHidden = !hasEvent
        }.disposed(by: disposeBag)
    }
    
    func reset() {
        titleLabel.text = nil
        titleLabel.textColor = .white
        titleLabel.backgroundColor = .clear
        separatorView.isHidden = true
        eventPresenceIndicatiorView.isHidden = true
    }
    
    func setSelected(_ selected: Bool) {
        self.isSelected = selected
        titleLabel.round()
        if isSelected {
            titleLabel.backgroundColor = .primary
            titleLabel.font = UIFont.systemFont(ofSize: titleLabel.font.pointSize, weight: .semibold)
        } else {
            titleLabel.backgroundColor = .clear
            titleLabel.font = UIFont.systemFont(ofSize: titleLabel.font.pointSize, weight: .medium)
        }
    }
    
}
