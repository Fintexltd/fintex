//
//  CalendarViewController.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 04/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol CalendarViewControllerDelegate: class {
    func calendar(_ calendar: CalendarViewController, didSelect day: Day)
    func calendar(_ calendar: CalendarViewController, didShow month: Month?)
}

class CalendarViewController: UIViewController {

    weak var delegate: CalendarViewControllerDelegate?
    private lazy var viewCreator = CalendarView(withParentView: self.view)
    private var scope: CalendarScope?
    private var needToUpdateLayoutAfterScreenRotation = false
    
    private var showedMonth: Month?
    private(set) var selectedDate: Date?
    
    override func loadView() {
        self.view = UIView()
        view.backgroundColor = .primaryDark
        viewCreator.setupView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setCurrentMonthAsDefault()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needToUpdateLayoutAfterScreenRotation {
            updateLayoutAfterScreenRotation()
        }
    }
    
    private func setupViews() {
        viewCreator.collectionView
            .registerCell(CalendarCollectionViewCell.self)
        viewCreator.collectionView.delegate = self
        viewCreator.collectionView.dataSource = self
    }

    private func setCurrentMonthAsDefault() {
        if let currentMonthIndex = self.scope?.months.enumerated().first(where: { _, month in
            return Calendar.current.isDate(month.startDate, inSameDayAs: Date().startOfMonth())
        })?.offset {
            let currentMonthIndexPath = IndexPath(item: currentMonthIndex, section: 0)
            viewCreator.collectionView.scrollToItem(at: currentMonthIndexPath, at: .centeredHorizontally, animated: false)
        }
    }
    
    private func updateLayoutAfterScreenRotation() {
        let visibleCells = self.viewCreator.collectionView.visibleCells as! [CalendarCollectionViewCell]
        visibleCells.forEach { $0.controller?.shouldRefreshLayout = true }
        viewCreator.collectionView.alpha = 1
        needToUpdateLayoutAfterScreenRotation = false
        guard let selectedMonth = self.showedMonth, let item = self.scope?.months.index(of: selectedMonth) else { return }
        viewCreator.collectionView.collectionViewLayout.invalidateLayout()
        viewCreator.collectionView.reloadSections(IndexSet(arrayLiteral: 0))
        let selectedMonthCellOffset = CGPoint(x: self.viewCreator.collectionView.frame.width * CGFloat(item), y: 0)
        viewCreator.collectionView.setContentOffset(selectedMonthCellOffset, animated: false)
    }
    
}

// MARK: - Endpoints
extension CalendarViewController {
    func updateLayoutDueToScreenOrientationChange() {
        self.needToUpdateLayoutAfterScreenRotation = true
    }
    
    func setScope(_ scope: CalendarScope) {
        self.scope = scope
        viewCreator.collectionView.reloadData()
    }
    
    func setDaysWithEvents(_ dates: [Date]) {
        self.scope?.configure(with: dates)
    }
}

// MARK: - Collection view methods
extension CalendarViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return scope?.months.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CalendarCollectionViewCell.className, for: indexPath) as! CalendarCollectionViewCell
        cell.delegate = self
        if let monthForCell = scope?.months[indexPath.item] {
            cell.configure(with: monthForCell, selectedDate: self.selectedDate)
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if let centerCellIndexPath = viewCreator.collectionView.indexPathForCentralItem,
            let month = scope?.months[centerCellIndexPath.item] {
            self.showedMonth = month
            delegate?.calendar(self, didShow: month)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let cell = cell as? CalendarCollectionViewCell else { return }
        cell.updateSelected(selectedDate)
    }
}

extension CalendarViewController: MonthCalendarDelegate {
    func calendar(_ calendar: MonthCalendarViewController, didSelect day: Day) {
        selectedDate = day.date
        delegate?.calendar(self, didSelect: day)
    }
}
