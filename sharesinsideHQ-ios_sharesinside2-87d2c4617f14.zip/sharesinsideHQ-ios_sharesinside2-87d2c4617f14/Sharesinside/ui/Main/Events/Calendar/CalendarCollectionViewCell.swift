//
//  CalendarCollectionViewCell.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CalendarCollectionViewCell: UICollectionViewCell {
    weak var delegate: MonthCalendarDelegate? {
        didSet {
            controller.delegate = self.delegate
        }
    }
    private(set) var controller: MonthCalendarViewController!
    
    var month: Month? {
        return controller?.monthModel
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        controller = MonthCalendarViewController()
        contentView.addSubview(controller.view)
        controller.view.snp.remakeConstraints { make in
            make.top.left.equalToSuperview()
            make.right.bottom.equalToSuperview()
        }
    }
    
    func configure(with model: Month, selectedDate: Date?) {
        controller.view.updateConstraints()
        controller.configure(with: model, selectedDate: selectedDate)
    }
    
    func updateSelected(_ date: Date?) {
        controller.updateSelected(date)
    }
    
}
