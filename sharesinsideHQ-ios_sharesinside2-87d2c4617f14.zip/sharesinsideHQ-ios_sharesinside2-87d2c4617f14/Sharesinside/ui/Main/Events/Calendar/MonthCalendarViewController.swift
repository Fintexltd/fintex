//
//  MonthCalendarViewController.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
 let ANY = 1
protocol MonthCalendarDelegate: class {
    func calendar(_ calendar: MonthCalendarViewController, didSelect day: Day)
}
class MonthCalendarViewController: UICollectionViewController {
    
    weak var delegate: MonthCalendarDelegate?
    private(set) var monthModel: Month?
    private var firstDayIndex: Int?
    private var selectedDate: Date?
    var shouldRefreshLayout = false
    
    private lazy var flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        return layout
    }()
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if shouldRefreshLayout {
            shouldRefreshLayout = false
            self.collectionView.collectionViewLayout.invalidateLayout()
        }
    }
    
    override func loadView() {
        self.view = UIView()
        self.collectionView = UICollectionView(frame: view.frame, collectionViewLayout: flowLayout)
        collectionView?.isScrollEnabled = false
        collectionView?.backgroundColor = .clear
        collectionView?.registerCell(DayCalendarViewControllerCell.self)
    }
    
    func reset() {
        monthModel = nil
        firstDayIndex = nil
        selectedDate = nil
    }
    
    func updateSelected(_ date: Date?) {
        if selectedDate != date {
            self.selectedDate = date
            self.collectionView.reloadData()
        }
    }
    
    func configure(with model: Month, selectedDate: Date?) {
        self.monthModel = model
        self.selectedDate = selectedDate
        self.firstDayIndex = Calendar.current.component(.weekday, from: model.startDate) - 1
        collectionView.reloadData()
    }
}

// MARK: - Collection view methods
extension MonthCalendarViewController: UICollectionViewDelegateFlowLayout {
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.monthModel != nil ? Defaults.Events.numberOfDayCells : 0
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DayCalendarViewControllerCell.className, for: indexPath) as! DayCalendarViewControllerCell
        
        guard
            let firstDayIndex = firstDayIndex,
            let month = monthModel,
            indexPath.item >= firstDayIndex
        else { return cell }
        
        let monthMaxIndex = month.daysCount - 1 + firstDayIndex
        let dayToShowIndex = indexPath.item - firstDayIndex
        if indexPath.item <= monthMaxIndex {
            let day = month.days[dayToShowIndex]
            cell.configure(with: day)
            if day.date == self.selectedDate {
                cell.setSelected(true)
            }
        }
        if month.name.lowercased() == "september", dayToShowIndex == 10 {
            print()
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let heightIfPortraint = collectionView.frame.height / 6
        let calculatedHeightIfLandscape = (collectionView.frame.height / 6) * 0.5
        let minimalHeightIfLandscape: CGFloat = 60
        let heightIfLandscape = max(calculatedHeightIfLandscape, minimalHeightIfLandscape)
        
        let height = AppInfo.orientation.isPortrait ? heightIfPortraint : heightIfLandscape
        let width = (collectionView.frame.width / 7)
        return CGSize(width: width, height: height)
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! DayCalendarViewControllerCell
        deselectVisibleCells()
        cell.setSelected(true)
        if let day = cell.day {
            delegate?.calendar(self, didSelect: day)
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! DayCalendarViewControllerCell
        cell.setSelected(false)
    }
    
    private func deselectVisibleCells() {
        collectionView.visibleCells
            .filter { $0.isSelected }
            .compactMap { $0 as? DayCalendarViewControllerCell }
            .forEach { $0.setSelected(false) }
    }
}
