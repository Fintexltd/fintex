//
//  CalendarView.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 07/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CalendarView: BaseViewCreator {
    
    lazy var collectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.isPagingEnabled = true
        collectionView.backgroundColor = .clear
        collectionView.clipsToBounds = false
        return collectionView
    }()
    
    lazy var flowLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        return layout
    }()
    
    lazy var weekdaysView: UIView = {
        func buildWeekdayLabel(for day: String) -> UILabel {
            let label = UILabel().layoutable()
            label.text = day
            label.textAlignment = .center
            label.textColor = .grey
            label.font = UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .medium)
            return label
        }
        let view = UIStackView.make(axis: .horizontal, with: [], spacing: 0, alignment: .center, distribution: .fillEqually)
        Calendar.current.veryShortWeekdaySymbols.forEach { view.addArrangedSubview(buildWeekdayLabel(for: $0)) }
        return view
    }()
    
    lazy var separatorView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = UIColor.gray.withAlpha(0.5)
        return view
    }()
    
    override func setupViewHierarchy() {
        [collectionView, separatorView, weekdaysView].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        
        weekdaysView.snp.remakeConstraints { make in
            make.top.equalToSuperview().offset(Defaults.marginBig)
            make.left.equalTo(collectionView.snp.left)
            make.right.equalTo(collectionView.snp.right)
            make.height.equalTo(Defaults.marginBig)
        }
        
        separatorView.snp.remakeConstraints { make in
            make.top.equalTo(weekdaysView.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
        
        collectionView.snp.remakeConstraints { make in
            make.top.equalTo(weekdaysView.snp.bottom)
            make.left.equalToSuperview()
            make.right.bottom.equalToSuperview()
        }
    }
    
    override func setupProperties() {
        parentView.clipsToBounds = true
    }
}
