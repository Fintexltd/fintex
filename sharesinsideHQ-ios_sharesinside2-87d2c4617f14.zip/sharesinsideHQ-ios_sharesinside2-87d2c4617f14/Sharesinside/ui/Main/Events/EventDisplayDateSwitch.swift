//
//  EventDisplayDateSwitch.swift
//  Sharesinside
//

import UIKit

final class EventDisplayDateSwitch: UIView {

    var didChangeDateDisplayType: ((EventDateDisplayType) -> Void)?

    var dateDisplayType: EventDateDisplayType? = nil {
        didSet {
            guard let dateDisplayType = dateDisplayType else {
                return
            }
            bind(dateDisplayType: dateDisplayType)
        }
    }

    private lazy var buttonsStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        [
            localTimeButton,
            eventTimeButton
        ].forEach { stackView.addArrangedSubview($0) }
        stackView.distribution = .fillProportionally
        stackView.spacing = Defaults.marginSmall
        return stackView
    }()

    private lazy var localTimeButton: UIButton = {
        let button = UIButton(type: .system)
        button.contentEdgeInsets = .init(top: 0, left: Defaults.marginTiny, bottom: 0, right: Defaults.marginTiny)
        button.setTitle("My time".capitalized, for: .normal)
        button.addTarget(self, action: #selector(didTapLocalTimeButton), for: .touchUpInside)
        button.layer.cornerRadius = 4
        return button
    }()

    private lazy var eventTimeButton: UIButton = {
        let button = UIButton(type: .system)
        button.contentEdgeInsets = .init(top: 0, left: Defaults.marginTiny, bottom: 0, right: Defaults.marginTiny)
        button.setTitle("Event place time".capitalized, for: .normal)
        button.addTarget(self, action: #selector(didTapEventTimeButton), for: .touchUpInside)
        button.layer.cornerRadius = 4
        return button
    }()

    override init(frame: CGRect) {
        super.init(frame: .zero)
        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("Please use this view from code.")
    }

    func setup() {
        addSubview(buttonsStackView)
        buttonsStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.height.equalTo(30)
        }
    }

    func bind(dateDisplayType: EventDateDisplayType) {
        localTimeButton.backgroundColor = dateDisplayType == .local ? .event : .clear
        localTimeButton.setTitleColor(dateDisplayType == .local ? .white : .event, for: .normal)
        eventTimeButton.backgroundColor = dateDisplayType == .local ? .clear : .event
        eventTimeButton.setTitleColor(dateDisplayType == .local ? .event : .white, for: .normal)
    }

    @objc private func didTapLocalTimeButton() {
        didChangeDateDisplayType?(.local)
    }

    @objc private func didTapEventTimeButton() {
        didChangeDateDisplayType?(.event)
    }
}
