//
//  MainTabBarController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxCocoa

enum MainTabBarScreen {
    case watchlist
    case events
    case companies
    case funds
    case startups
    case trading
    case notifications
}

class MainTabBarController: UITabBarController {
    
    private var previousControllerClass: AnyClass?

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViewControllers()
        setupAppearance()
        
        delegate = self
    }

    private func setupViewControllers() {
        let watchlist = BaseNavigationController(rootViewController: WatchlistViewController())
        let events = BaseNavigationController(rootViewController: EventsViewController())
        let companies = BaseNavigationController(rootViewController: CompaniesViewController())
        let funds = BaseNavigationController(rootViewController: FundManagersViewController())
        let startups = BaseNavigationController(rootViewController: StartupsViewController())
        let trading = BaseNavigationController(rootViewController: TradingViewController())
        let notifications = BaseNavigationController(rootViewController: NotificationsViewController())

        watchlist.tabBarItem = MainTabBarScreen.watchlist.createTabBarItem()
        events.tabBarItem = MainTabBarScreen.events.createTabBarItem()
        companies.tabBarItem = MainTabBarScreen.companies.createTabBarItem()
        funds.tabBarItem = MainTabBarScreen.funds.createTabBarItem()
        startups.tabBarItem = MainTabBarScreen.startups.createTabBarItem()
        trading.tabBarItem = MainTabBarScreen.trading.createTabBarItem()
        notifications.tabBarItem = MainTabBarScreen.notifications.createTabBarItem()

        viewControllers = [watchlist, companies, funds, startups, events, notifications]
    }

    private func setupAppearance() {
        tabBar.tintColor = .primary
        tabBar.barTintColor = .primaryDark
        tabBar.unselectedItemTintColor = .accent
        tabBar.isTranslucent = false

        guard let tabBarItems = tabBar.items else { return }
        for tabBarItem in tabBarItems {
            tabBarItem.badgeColor = .notification
            if UIScreen.main.traitCollection.userInterfaceIdiom == .phone {
                tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: Defaults.buttonBorderWidth.negative())
            }
        }
        moreNavigationController.setupNavigationBar()
    }
    
    func selectScreen(_ screen: MainTabBarScreen) {
        selectedIndex = screen.index
    }
}

extension MainTabBarScreen {

    var title: String {
        switch self {
        case .watchlist: return Localizable.tabBarWatchlist.localized
        case .events: return Localizable.tabBarEvents.localized
        case .companies: return Localizable.tabBarCompanies.localized
        case .funds: return Localizable.tabBarFunds.localized
        case .startups: return Localizable.tabBarStartups.localized
        case .trading: return Localizable.tabBarTrading.localized
        case .notifications: return Localizable.tabBarNotifications.localized
        }
    }

    var icon: UIImage {
        switch self {
        case .watchlist: return #imageLiteral(resourceName: "IconWatchlist")
        case .events: return #imageLiteral(resourceName: "IconEvents")
        case .companies: return #imageLiteral(resourceName: "IconCompanies")
        case .funds: return #imageLiteral(resourceName: "IconFunds")
        case .startups: return #imageLiteral(resourceName: "iconStartups")
        case .trading: return #imageLiteral(resourceName: "IconTrading")
        case .notifications: return #imageLiteral(resourceName: "IconNotifications")
        }
    }

    var index: Int {
        switch self {
        case .watchlist: return 0
        case .events: return 1
        case .companies: return 2
        case .funds: return 3
        case .startups: return 4
        case .trading: return 5
        case .notifications: return 6
        }
    }

    var className: AnyClass {
        switch self {
        case .watchlist: return WatchlistViewController.self
        case .events: return EventViewController.self
        case .companies: return CompaniesViewController.self
        case .funds: return FundManagersViewController.self
        case .startups: return StartupsViewController.self
        case .trading: return TradingViewController.self
        case .notifications: return NotificationsViewController.self
        }
    }

    func createTabBarItem() -> UITabBarItem {
        return UITabBarItem(title: self.title, image: self.icon, selectedImage: nil)
    }
}

extension MainTabBarController: UITabBarControllerDelegate {

    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        previousControllerClass = (tabBarController.selectedViewController as? BaseNavigationController)?.topViewController?.classForCoder
        
        if let navController = viewController as? BaseNavigationController,
            let tradingViewController = navController.viewControllers.first as? TradingViewController {
            tradingViewController.showRedirectingAlert()
            return false
        }
        return true
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        if let selectedCotroller = (viewController as? BaseNavigationController)?.topViewController,
            let previousControllerClass = previousControllerClass, previousControllerClass == selectedCotroller.classForCoder,
            let tabBarController = selectedCotroller as? TabBarChildController {
                tabBarController.didTouchTabItem()
        }
    }
}
