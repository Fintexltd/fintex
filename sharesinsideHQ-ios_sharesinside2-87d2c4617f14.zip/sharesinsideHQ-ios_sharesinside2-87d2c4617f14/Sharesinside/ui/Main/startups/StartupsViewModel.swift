//
//  StartupsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum PageState<Item>: Equatable {

    case loading
    case paging([Item])
    case populated([Item])
    case empty
    case error(Error)

    var currentItems: [Item] {
        switch self {
        case .paging(let items): return items
        case .populated(let items): return items
        default: return []
        }
    }

    static func == (lhs: PageState, rhs: PageState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}

class StartupsViewModel: BaseViewModel<HasStartupsRepository & HasFiltersRepository> {

    typealias FilterData = (filters: [Filter], selectedFilters: Int)
    let filtersData = BehaviorRelay<FilterData>(value: ([], 0))
    let pageState = BehaviorRelay<PageState<Startup>>(value: .loading)

    private let startupResponses = BehaviorRelay<[ListResponse<Startup>]>(value: [])
    private let moreDataNeedRelay = BehaviorRelay(value: 1)

    let showFollowAll = PublishRelay<Bool>()

    private lazy var filters = BehaviorRelay(value:
        AdvancedFilters.empty(withSortType: .defaultSortedSeed(seed: generateRandomSeed())))

    private lazy var startupsRepository = dependencies.startupsRepository
    private lazy var filtersRepository = dependencies.filtersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        fetchFilters()

        MainFlowRxBus.startupFollowingStatePublishRelay
            .subscribe(onNext: { [weak self] model in
                guard let model = model else {
                    self?.refresh()
                    return
                }

                if let startup = self?.pageState.value.currentItems.first(where: { $0.id == model.id }) {
                    self?.changeStartupFollowState(model.newFollowingState, forStartup: startup)
                }
            }).disposed(by: disposeBag)
    }

    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.pageState.accept(.loading) })
            .withLatestFrom(startupResponses)
            .filter { startupResponses -> Bool in
                guard let last = startupResponses.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .withLatestFrom(filters) { ($0, $1) }
            .flatMapLatest { (arg) -> Observable<[ListResponse<Startup>]> in
                let (startupResponses, filters) = arg

                return self.startupsRepository.getStartups(fromPage: (startupResponses.last?.meta.currentPage ?? 0) + 1, withFilters: filters)
                    .map { return startupResponses + [$0] }
                    .do(onNext: { [weak self] startupsResponses in
                        self?.handleStartupsResponses(with: startupsResponses)
                    })
                    .catchError { [weak self] error in
                        self?.pageState.accept(.error(error))
                        return Observable<[ListResponse<Startup>]>.empty()
                }
            }
            .bind(to: startupResponses)
            .disposed(by: disposeBag)
    }

    private func handleStartupsResponses(with responses: [ListResponse<Startup>]) {
        let startups = responses.flatMap { $0.data }.uniqueElements

        if startups.isEmpty {
            pageState.accept(.empty)
        } else if let last = responses.last, last.meta.currentPage < last.meta.lastPage {
            pageState.accept(.paging(startups))
        } else {
            pageState.accept(.populated(startups))
        }
        updateFollowAllState(with: responses)
    }

    private func updateFollowAllState(with responses: [ListResponse<Startup>]) {
        let isNotFollowingAll = responses.filter { $0.meta.isFollowingAll ?? false }.isEmpty
        let hasMinimalNumberOfFilters = filtersData.value.selectedFilters >= Defaults.Filter.minNumberToShowFollowAll
        let isPopulated = pageState.value != .empty

        showFollowAll.accept(isNotFollowingAll && hasMinimalNumberOfFilters && isPopulated)
    }

    private func refresh() {
        startupResponses.accept([])
        moreDataNeedRelay.accept(1)
    }

    private func generateRandomSeed() -> Int {
        return Int(arc4random_uniform(9999) + 1)
    }

    private func fetchFilters() {
        filtersRepository.getStartupPredefinedFilters()
            .subscribe(onNext: { [weak self] filters in
                guard let `self` = self else { return }
                let oldFilters = self.filters.value
                let mappedRelations = filters.map {
                    $0.with(selection: oldFilters.hasRelationFilter($0) || oldFilters.hasSortFilter($0))
                }
                self.filtersData.accept((mappedRelations, self.filters.value.selectionCount))
            }, onError: { error in printDebug(error) })
        .disposed(by: disposeBag)
    }
}

extension StartupsViewModel {

    var reloadDriver: Driver<Int> {
        return startupResponses.asDriver().map { _ in 0 }
    }

    func collectionViewNeedsMoreData() {
        moreDataNeedRelay.accept(1)
    }

    func refreshDataRandomly() {
        if case SortType.defaultSortedSeed = filters.value.sortBy {
            let newFilters = filters.value.with(sortType: .defaultSortedSeed(seed: generateRandomSeed()))
            self.filters.accept(newFilters)
        }
        refresh()
    }

    func toogleFollowingStartup(_ startup: Startup) {
        startupsRepository.toggleFollowing(ofStartupWithId: startup.id, follow: startup.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(onSubscribe: { self.changeStartupFollowState(.changing, forStartup: startup) })
            .subscribe(onNext: { [weak self] _ in
                guard let `self` = self else { return }
                let newState: FollowingState = startup.following == .following ? .notFollowing : .following
                MainFlowRxBus.startupFollowingStatePublishRelay
                    .accept(FollowingChangeModel(id: startup.id,
                                                        newFollowingState: newState))
                self.changeStartupFollowState(newState, forStartup: startup)
            }, onError: { [weak self] error in
                self?.changeStartupFollowState(startup.following, forStartup: startup)
                self?.alert.accept(AlertData(message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }

    func followAll() {
        startupsRepository.followAllStartups(matching: filters.value)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                MainFlowRxBus.startupFollowingStatePublishRelay.accept(nil)
                self?.showFollowAll.accept(false)
            }, onError: { [weak self] error in
                self?.handleFollowingStartupsError(message: error.localizedDescription)
            }).disposed(by: disposeBag)
    }

    private func handleFollowingStartupsError(message: String) {
        alert.accept(AlertData(message: message != "" ? message : Localizable.startupsFollowAllError.localized))
    }

    private func changeStartupFollowState(_ state: FollowingState, forStartup startup: Startup) {
        var startups = pageState.value.currentItems
        let updatedStartup = startup.with(followingState: state)
        if let startupIndex = startups.index(where: { $0.id == startup.id }) {
            startups[startupIndex] = updatedStartup
        }

        switch pageState.value {
        case .paging: pageState.accept(.paging(startups))
        case .populated: pageState.accept(.populated(startups))
        default: break
        }
    }

    func selected(startup: Startup) {
        router?.push(to: .startupDetails(startupId: startup.id))
    }

    func didTapAccountIcon() {
    }

    func searchFor(fraze: String) {
        self.filters.accept(filters.value.with(searchText: fraze))
        refresh()
    }

    func moveToMoreFiltersView() {
        router?.present(destination:
            .filters(filterTypes: [.startupRelation, .startupCategory, .equityFund, .continent, .country, .currency, .raisedAmount],
                     initialFilters: filters.value,
                     delegate: self))
    }

    func moveToAccountInfoView() {}

    func selectedPredefinedFilter(_ filter: Filter) {
        switch filter {
        case is StartupRelation:
            updateRelationFilters(with: filter)
        case is SortFilter:
            updateSortFilters(with: filter)
        default: break
        }
        updateFiltersData(filters: self.filters.value)
        refresh()
    }

    func startup(withId id: Int, didChangeFollowingState state: FollowingState) {
        if let startup = pageState.value.currentItems.first(where: { $0.id == id }) {
            changeStartupFollowState(state, forStartup: startup)
        }
    }

    private func updateRelationFilters(with filter: Filter) {
        guard let relation = filter as? StartupRelation else { return }
        var relations = filters.value.relations

        if let index = relations.index(where: { $0 == relation.name.lowercased() }) {
            relations.remove(at: index)
        }
        if filter.isSelected { relations.append(filter.name.lowercased()) }
        self.filters.accept(filters.value.with(relations: relations))
    }

    private func updateSortFilters(with filter: Filter) {
        guard let sort = filter as? SortFilter else { return }
        let sortType = sort.isSelected ? sort.sortType : .defaultSortedSeed(seed: generateRandomSeed())

        self.filters.accept(filters.value.with(sortType: sortType))
    }

    private func updateFiltersData(filters: AdvancedFilters) {
        let updatedRelations = filtersData.value.filters.map {
            $0.with(selection: filters.hasRelationFilter($0) || filters.hasSortFilter($0))
        }
        self.filtersData.accept((updatedRelations, filters.selectionCount))
    }
}

extension StartupsViewModel: FiltersDelegate {

    func didSelect(filters: AdvancedFilters) {
        self.filters.accept(filters)
        updateFiltersData(filters: filters)
        refresh()
    }
}
