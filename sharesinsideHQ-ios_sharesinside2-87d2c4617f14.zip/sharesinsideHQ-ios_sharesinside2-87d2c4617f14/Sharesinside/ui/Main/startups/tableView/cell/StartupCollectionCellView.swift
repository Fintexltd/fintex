//
//  StartupCollectionCellView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol StartupCellDelegate: class {
    func collectionCell(_ cell: StartupCollectionViewCell, didToogleFollowStartup startup: Startup)
    func collectionCell(_ cell: StartupCollectionViewCell, didTapUserGroupsFor startup: Startup)
}

class StartupCollectionViewCell: UICollectionViewCell {

    weak var delegate: StartupCellDelegate?

    private lazy var viewCreator = StartupCellViewCreator(withParentView: self.contentView)

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    var startup: Startup? {
        didSet {
            if let startup = startup {
                configure(with: startup)
            }
        }
    }

    private func configure(with startup: Startup) {
        viewCreator.startupTitle.text = startup.name

        viewCreator.startupAddress.text = startup.address
        viewCreator.startupRaisedAmount.text = Localizable.startupCellRaisedAmount.localized + "\(startup.raisedAmount)%"
        viewCreator.followButton.isHidden = startup.following == .changing
        viewCreator.followButton.setTitle(startup.following.stateTitle, for: .normal)
        viewCreator.followButton.style = startup.following.buttonStyle
        viewCreator.followLoader.isHidden = startup.following != .changing

        if let logo = startup.logo, let logoUrl = URL(string: logo) {
            viewCreator.startupLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
        }

        let orientation = UIApplication.shared.statusBarOrientation
        viewCreator.contentStackView.axis = orientation.isPortrait ? .vertical : .horizontal
        viewCreator.startupRaisedAmount.textAlignment = orientation.isPortrait ? .left : .right
        viewCreator.startupAddress.textAlignment = orientation.isPortrait ? .left : .right
        viewCreator.followButton.addTarget(self, action: #selector(followDidTouch), for: .touchUpInside)
        viewCreator.userGroups.configure(withUserGroups: startup.startupsCellGroups.compactMap({ $0.title }))
    }

    private func initializeView() {
        viewCreator.setupView()
        viewCreator.userGroups.setupGestureRecognizer(target: self, selector: #selector(userGroupsDidTouch))
    }

    @objc private func followDidTouch() {
        guard let startup = startup else { return }
        delegate?.collectionCell(self, didToogleFollowStartup: startup)
    }

    @objc private func userGroupsDidTouch() {
        guard let startup = startup else { return }
        delegate?.collectionCell(self, didTapUserGroupsFor: startup)
    }
}
