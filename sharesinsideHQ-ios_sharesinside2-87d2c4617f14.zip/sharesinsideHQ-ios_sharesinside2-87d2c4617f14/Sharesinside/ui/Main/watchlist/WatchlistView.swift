//
//  CompaniesView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class WatchlistView: BaseViewCreator {

    lazy var navigationTitle: SearchableNavigationView = {
        let titleView = SearchableNavigationView()
        return titleView
    }()

    var navigationItem: UINavigationItem?
    
    let snackBar: SnackBarView = {
        let snackBar = SnackBarView()
        snackBar.leftIcon = #imageLiteral(resourceName: "IconArrowSnackBar")
        return snackBar
    }()

    lazy var tableView: WatchlistTableView = {
        let tableView = WatchlistTableView()
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .clear
        return tableView
    }()

    lazy var filterView: PredefinedFiltersView = {
        return PredefinedFiltersView()
    }()

    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary

        return refreshControl
    }()
    
    lazy var contentStackView: UIStackView = .make(
        axis: .vertical,
        with: [filterView, tableView]
    )

    convenience init(withParentView parent: UIView, withNavigationItem item: UINavigationItem) {
        self.init(withParentView: parent)
        self.navigationItem = item
    }

    func setupView() {
        super.setupView()
        setupNavigationBar()
    }

    override func setupProperties() {
        tableView.addSubview(refreshControl)
    }

    override func setupViewHierarchy() {
        parentView.addSubview(contentStackView)
        parentView.addSubview(snackBar)
    }

    override func setupConstraints() {
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    func setupNavigationBar() {
        guard let navItem = navigationItem else { return }
        navigationTitle.setup(in: navItem)
    }
}
