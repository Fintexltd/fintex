//
//  EventDetailsView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol EventDetailsViewDelegate: class {
    func addEventToCalendar(_ event: Event)
    func didSwitch(dateDisplayType: EventDateDisplayType)
    func didSelect(_ event: Event)
}

class EventDetailsView: UIView {

    weak var delegate: EventDetailsViewDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    private func initializeView() {
        layoutable()
        layer.cornerRadius = 5
        backgroundColor = .grey
        clipsToBounds = true

        addSubview(backgroundImageView)
        addSubview(contentStackView)
        dateImageContainer.addSubview(dateImageView)
        addSubview(addToCalendarContainer)
        addToCalendarContainer.addSubview(addToCalendarButton)
        addToCalendarContainer.addSubview(addToCalendarIcon)
        setupConstraints()

        addToCalendarButton.addTarget(self, action: #selector(addToCalendarDidTouch), for: .touchUpInside)
        eventDisplayDateSwitch.didChangeDateDisplayType = { [weak self] dateDisplayType in
            self?.delegate?.didSwitch(dateDisplayType: dateDisplayType)
        }
    }

    var event: Event? {
        didSet {
            guard let event = event else { return }
            configure(with: event)
        }
    }
    
    private func configure(with event: Event) {
        eventTitle.text = event.title
        eventAddress.text = event.details.prettyPrintedAddress
        webcastLinkImageView.superview?.isHidden = !event.details.hasWebcastLinks
        loadCompanyLogo(with: event.logoUrl)

        let dateDisplayType = UserDefaultsEventsDisplayDateTypeRepository.shared.displayDateType ?? .local

        eventDisplayDateSwitch.dateDisplayType = dateDisplayType

        let date: Date?
        switch dateDisplayType {
        case .local:
            date = event.details.utcDate.toTimezone()
        case .event:
            date = event.details.utcDate.toTimezone(timezone: TimeZone(identifier: event.details.timezone))
        }
        eventDate.text = date?.toString(withFromat: Date.Format.eventDateFormat) ?? "--"
    }
    
    func updateTopImageStackViewContent(hasWebcastLinks: Bool) {
        companyLogoImageView.superview?.isHidden = true
        webcastLinkImageView.superview?.isHidden = !hasWebcastLinks
        topImagesStackView.isHidden = !hasWebcastLinks
        if hasWebcastLinks {
            webcastLinkImageView.snp.remakeConstraints { make in
                make.width.equalTo(Defaults.Watchlist.webcastLinkIconSize)
                make.height.equalTo(webcastLinkImageView.snp.width)
                make.leading.equalToSuperview()
                make.top.bottom.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
            }
        }
    }
    
    private func loadCompanyLogo(with logoUrl: URL?) {
        if let logoUrl = logoUrl {
            companyLogoImageView.kf.setImage(with: ImageResource(downloadURL: logoUrl),
                                             options: [.backgroundDecode])
        }
    }
    
    @objc private func addToCalendarDidTouch() {
        guard let event = event else { return }
        delegate?.addEventToCalendar(event)
    }

    // Views
    private let webcastLinkImageView: UIImageView = {
        let image = UIImageView().layoutable()
        image.image = #imageLiteral(resourceName: "IconLink")
        image.tintColor = .accent
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    private let companyLogoImageView: UIImageView = {
        let image = UIImageView().layoutable()
        image.image = #imageLiteral(resourceName: "IconLink")
        image.tintColor = .accent
        image.contentMode = .scaleAspectFit
        return image
    }()

    private let eventTitle: UILabel = {
        let title = UILabelFactory.styled(textColor: .accent,
            fontWeight: .bold)
        title.textAlignment = .left
        title.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical, huggingPriority: UILayoutPriority.defaultLow.increased(by: 1), huggingAxis: .vertical)
        title.numberOfLines = 2
        return title
    }()

    private let eventAddress: UILabel = {
        let address = UILabelFactory.styled(textColor: .accent,
            withFontSize: Defaults.TextSize.medium,
            fontWeight: UIFont.Weight.light)
        address.textAlignment = .left
        address.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        address.numberOfLines = 2
        return address
    }()

    private let eventDate: UILabel = {
        let dateLabel = UILabelFactory.styled(textColor: .accent,
            withFontSize: Defaults.TextSize.small,
            fontWeight: .bold)
        dateLabel.textAlignment = .left
        return dateLabel
    }()

    private let dateImageContainer: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .primaryDark
        view.layer.cornerRadius = Defaults.Watchlist.calendarIconSize / 2
        view.clipsToBounds = true

        return view
    }()

    private let dateImageView: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "IconCalendar")).layoutable()
        imageView.tintColor = .accent
        imageView.contentMode = .scaleAspectFit

        return imageView
    }()

    private let addToCalendarIcon: UIImageView = {
        let icon = UIImageView(image: #imageLiteral(resourceName: "IconAddToCalendar")).layoutable()
        icon.tintColor = .accent
        icon.contentMode = .scaleAspectFit
        return icon
    }()

    private let addToCalendarButton: UIButton = {
        let button = UIButton().layoutable()
        return button
    }()

    private let addToCalendarContainer: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .event
        view.layer.cornerRadius = Defaults.Watchlist.addToCalendarIconSize / 2
        view.clipsToBounds = true

        return view
    }()

    private let backgroundImageView: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: "IconEventBackground")).layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .vertical)
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .horizontal)
        return imageView
    }()

    private let eventDisplayDateSwitch = EventDisplayDateSwitch()
    
    private lazy var topImagesStackView: UIStackView = .make(
        axis: .horizontal,
        with: [
            companyLogoImageView.embedInView(),
            webcastLinkImageView.embedInView()],
        spacing: Defaults.marginSmall)

    private lazy var dateInnerStackView: UIStackView = .make(
        axis: .vertical,
        with: [eventDisplayDateSwitch, eventDate],
        spacing: Defaults.marginSmall
    )

    private lazy var dateStackView: UIStackView = .make(
        axis: .horizontal,
        with: [dateImageContainer.embedInView(), dateInnerStackView],
        spacing: Defaults.marginNormal)

    private lazy var informationStackView: UIStackView = .make(
        axis: .vertical,
        with: [
            topImagesStackView,
            eventTitle,
            eventAddress,
            dateStackView],
        spacing: Defaults.marginSmall)

    private lazy var contentStackView: UIStackView = .make(
        axis: .horizontal,
        with: [
            informationStackView
        ],
        spacing: Defaults.marginMicro)
}

extension EventDetailsView {

    private func setupConstraints() {

        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
            make.top.bottom.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }

        addToCalendarContainer.snp.makeConstraints { make in
            make.trailing.top.equalToSuperview().inset(Defaults.marginSmall)
            make.bottom.lessThanOrEqualToSuperview()
            make.width.equalTo(Defaults.Watchlist.addToCalendarIconSize)
            make.height.equalTo(addToCalendarContainer.snp.width)
        }

        addToCalendarIcon.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.Watchlist.addToCalendarPadding)
        }

        addToCalendarButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        companyLogoImageView.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Watchlist.addToCalendarIconSize)
            make.height.equalTo(companyLogoImageView.snp.width)
            make.leading.equalToSuperview()
            make.centerY.equalTo(addToCalendarContainer)
        }
        
        webcastLinkImageView.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Watchlist.webcastLinkIconSize)
            make.height.equalTo(webcastLinkImageView.snp.width)
            make.leading.equalTo(companyLogoImageView.snp.trailing).offset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
        }

        dateImageContainer.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Watchlist.calendarIconSize)
            make.height.equalTo(dateImageContainer.snp.width)
            make.centerY.equalToSuperview()
            make.leading.trailing.equalToSuperview()
        }

        dateStackView.snp.makeConstraints { make in
            make.height.equalTo(70)
        }

        dateImageView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.marginTiny)
        }

        backgroundImageView.snp.makeConstraints({ make in
            make.edges.equalToSuperview()
        })
    }
}
