//
//  NewsVideoView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 03.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import WebKit
import Kingfisher

class NewsVideoView: UIView {
    
    var videoData: VideoData? {
        didSet {
            adjust(to: videoData)
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        layoutable()
        layer.cornerRadius = 5
        backgroundColor = .grey
        clipsToBounds = true
        playButton.addTarget(self, action: #selector(didTouchPlayButton), for: .touchUpInside)
        
        [webView, videoThumbnail, playButton].forEach { addSubview($0) }

        webView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        videoThumbnail.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        playButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(Defaults.Watchlist.playVideoButtonWidth)
            make.height.equalTo(playButton.snp.width)
        }
    }

    // MARK: - Views
    let playButton: UIButton = {
        let button = UIButton().layoutable()
        button.setImage(#imageLiteral(resourceName: "IconPlay"), for: .normal)
        button.adjustsImageWhenHighlighted = false
        return button
    }()

    lazy var webView: WKWebView = {
        let configuration = WKWebViewConfiguration()
        
        configuration.allowsInlineMediaPlayback = false
        configuration.ignoresViewportScaleLimits = true
        let webView = WKWebView(frame: .zero, configuration: configuration).layoutable()
        webView.contentMode = .center
        webView.alpha = 1
        webView.scrollView.contentMode = .center
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.showsVerticalScrollIndicator = false
        
        return webView
    }()

    let videoThumbnail: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.backgroundColor = .grey
        return imageView
    }()

    // MARK: - Internal methods

    private func adjust(to videoData: VideoData?) {
        guard let videoData = videoData else { return }
        if let thumbnailUrl = videoData.videoThumbnailUrl {
            videoThumbnail.kf.setImage(with: ImageResource(downloadURL: thumbnailUrl),
                                       options: [.backgroundDecode])
        }
    }

    private func playVideo() {
        guard let videoData = videoData else { return }
        let preparedURL = URL(string: videoData.videoUrl.absoluteString + "?playsinline=0")!
        let playRequest = URLRequest(url: preparedURL)
        webView.load(playRequest)
        videoThumbnail.isHidden = true
        playButton.isHidden = true
    }

    @objc private func didTouchPlayButton() {
        func animateButtonTapped() {
            UIView.animate(withDuration: Defaults.animationDuration, animations: {
                self.playButton.alpha = 0
            }) { _ in
                UIView.animate(withDuration: Defaults.animationDuration, animations: {
                    self.playButton.alpha = 1
                })
            }
        }
        animateButtonTapped()
        playVideo()
    }

    // MARK: - Endpoints

    func prepareForReuse() {
        videoData = nil
        videoThumbnail.isHidden = false
        playButton.isHidden = false
    }
}
