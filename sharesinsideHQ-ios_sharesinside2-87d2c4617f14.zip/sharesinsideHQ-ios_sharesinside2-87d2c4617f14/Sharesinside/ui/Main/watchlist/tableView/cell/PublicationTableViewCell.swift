//
//  CompanyCollectionViewCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 25.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher
import RxSwift

protocol PublicationCellDelegate: class {
    func didSelectAddToCalendar(for event: Event)
    func didSelectPlayVideo(for news: News)
    func didTapHeader(for issuerId: Int, issuerType: PublicationIssuerType)
    func didSelect(publication: Publication)
    func didTapShareButton(shareUrl: URL?)
    func didSwitch(dateDisplayType: EventDateDisplayType)
}

class PublicationTableViewCell: UITableViewCell {

    weak var delegate: PublicationCellDelegate?
    
    private lazy var viewCreator = PublicationCellView(withParentView: self.contentView)

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        publication = nil
        viewCreator.newsView.prepareForReuse()
        viewCreator.newsView.removeFromSuperview()
        viewCreator.eventView.removeFromSuperview()
        viewCreator.headerView.shareButton.removeFromSuperview()
    }
    
    private func initializeView() {
        selectionStyle = .none
        backgroundColor = .white
        viewCreator.setupView()
        viewCreator.contentStackView.axis = AppInfo.isIPad ? .horizontal : .vertical
        viewCreator.headerView.delegate = self
        viewCreator.eventView.delegate = self
    }

    var publication: Publication? {
        didSet {
            if let publication = publication {
                configure(with: publication)
            }
        }
    }
    
    private func configure(with publication: Publication) {
        viewCreator.publicationTitle.text = publication.type == .news || publication.type == .project ? publication.title : nil
        viewCreator.headerView.configure(with: publication)
        viewCreator.publicationDescription.attributedText = publication.prettyPrintedDescription
        switch publication.type {
        case .event:
            viewCreator.contentStackView.addArrangedSubview(viewCreator.eventView)
            let event = publication as? Event
            viewCreator.eventView.event = event
            viewCreator.eventView.updateTopImageStackViewContent(hasWebcastLinks: event?.details.hasWebcastLinks ?? false)
        case .news:
            guard let news = publication as? News,
                let videoData = news.details.videoData else { return }
            viewCreator.contentStackView.addArrangedSubview(viewCreator.newsView)
            viewCreator.newsView.videoData = videoData
        case .project:
            guard let project = publication as? Project,
                let videoData = project.details.videoData else { return }
            viewCreator.contentStackView.addArrangedSubview(viewCreator.projectView)
            viewCreator.projectView.videoData = videoData        }
        viewCreator.remakePublicationViewConstraints()
    }
}

extension PublicationTableViewCell: EventDetailsViewDelegate {

    func didSwitch(dateDisplayType: EventDateDisplayType) {
        delegate?.didSwitch(dateDisplayType: dateDisplayType)
    }

    func addEventToCalendar(_ event: Event) {
        delegate?.didSelectAddToCalendar(for: event)
    }
    
    func didSelect(_ event: Event) {}

    func eventsListDidSwitch(dateDisplayType: EventDateDisplayType) {
        delegate?.didSwitch(dateDisplayType: dateDisplayType)
    }
}

extension PublicationTableViewCell: PublicationHeaderDelegate {
    func didTapPublicationHeader(_ publicationHeader: PublicationHeaderView) {
        guard let publication = publication,
            let issuerType = publication.issuerType else {
            return
        }
        delegate?.didTapHeader(for: publication.issuerId, issuerType: issuerType)
    }

    func didTapShareButton(_ publicationHeader: PublicationHeaderView) {
        let url = (publication as? ShareablePublication)?.shareUrl
        delegate?.didTapShareButton(shareUrl: url)
    }
}
