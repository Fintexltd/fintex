//
//  CompanyCellView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 25.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import SnapKit

class PublicationCellView: BaseViewCreator {

    let headerView: PublicationHeaderView = {
        let headerView = PublicationHeaderView()
        return headerView
    }()

    let publicationTitle: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark, fontWeight: .bold)
        label.textAlignment = .left
        label.numberOfLines = 2
        label.backgroundColor = .white
        return label
    }()

    let publicationDescription: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.medium)
        label.textAlignment = .left
        label.lineBreakMode = .byTruncatingTail
        label.numberOfLines = 2
        label.adjustsFontSizeToFitWidth = false
        label.backgroundColor = .white
        return label
    }()
    
    lazy var readMore: UILabel = {
        let label = UILabelFactory.styled(withFontSize: Defaults.TextSize.medium, aligment: .left)
        return label
    }()

    lazy var mainContentContainer = UIStackView.make(
        axis: .vertical,
        with: [headerView, descriptionStackView.embedInView()],
        spacing: Defaults.marginMicro)
    
    lazy var descriptionStackView = UIStackView.make(
        axis: .vertical,
        with: [publicationTitle, publicationDescription, marginView, readMore],
        spacing: Defaults.marginMicro)

    let eventView: EventDetailsView = {
        let view = EventDetailsView()
        return view
    }()

    let newsView: NewsVideoView = {
        let view = NewsVideoView()
        return view
    }()

    let projectView = ProjectDetailsView()

    lazy var contentStackView = UIStackView
        .make(axis: .vertical,
            with: [mainContentContainer],
            spacing: Defaults.marginTiny)

    lazy var bottomDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    var marginView: UIView {
        let view = UIView().layoutable()
        view.setContentHuggingPriority(.defaultLow, for: .vertical)
        return view
    }
    
    private var readMoreAttributed: NSAttributedString {
        return NSMutableAttributedString(
            string: Localizable.watchlistReadMore.localized,
            attributes: [
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: Defaults.TextSize.medium, weight: .bold),
                NSAttributedString.Key.foregroundColor: UIColor.primary])
    }

    override func setupProperties() {
        parentView.backgroundColor = .accent
        parentView.clipsToBounds = true
        readMore.attributedText =  readMoreAttributed
    }

    override func setupViewHierarchy() {
        [contentStackView, bottomDivider].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        
        descriptionStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginBig)
        }
        bottomDivider.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
    }

    func remakePublicationViewConstraints() {
        let multiplier = contentStackView.axis == .horizontal ? 0.45 : 1
        if eventView.superview != nil {
            eventView.snp.remakeConstraints { make in
                make.width.equalToSuperview().multipliedBy(multiplier)
            }
        }
        if newsView.superview != nil {
            newsView.snp.remakeConstraints { make in
                make.height.equalTo(Defaults.Watchlist.videoPlayerHeight).priority(.highest)
                make.width.equalTo(contentStackView).multipliedBy(multiplier)
            }
        }
        if projectView.superview != nil {
            projectView.snp.remakeConstraints { make in
                make.height.equalTo(Defaults.Watchlist.videoPlayerHeight).priority(.highest)
                make.width.equalTo(contentStackView).multipliedBy(multiplier)
            }
        }
    }
}
