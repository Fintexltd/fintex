//
//  FiltersTableView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 15.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol WatchlistTableViewDelegate: PublicationCellDelegate, PagedViewControllerDelegate {
    func didScrollToBottom()
    func didScrollToTop()
    func didSelect(publication: Publication)
}

class WatchlistTableView: UITableView {

    weak var customDelegate: WatchlistTableViewDelegate?
    
    private var cellHeightsDictionary: [IndexPath: CGFloat] = [:]

    var state: WatchlistState = .loading {
        didSet {
            reloadData()
            configureBackgroundView(withState: state)
        }
    }

    let listBackgroundView: FailureView = {
        let view = FailureView()
        view.showArrow = true
        view.alpha = 0
        return view
    }()
    
    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: .grouped)
        backgroundColor = .background

        delegate = self
        dataSource = self
        registerCell(PublicationTableViewCell.self)
        registerHeaderFooter(StateFooterTableViewCell.self)
        separatorStyle = .none

        estimatedRowHeight = Defaults.Watchlist.estimatedCellHeight
        rowHeight = UITableView.automaticDimension

        estimatedSectionFooterHeight = Defaults.Watchlist.estimatedFooterHeight
        sectionFooterHeight = UITableView.automaticDimension

        estimatedSectionHeaderHeight = Defaults.Watchlist.estimatedHeaderHeight
        sectionHeaderHeight = UITableView.automaticDimension
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension WatchlistTableView: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return state.currentWatchlist.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: PublicationTableViewCell = dequeueReusableCell(for: indexPath) {
            let publication = state.currentWatchlist[indexPath.row]
            cell.publication = publication
            cell.delegate = self
            return cell
        }

        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if let stateFooter: StateFooterTableViewCell = tableView.dequeueReusableHeaderFooter(),
            state == .loading || state == .paging([]) {
            stateFooter.initialize()
            return stateFooter
        }

        return UIView()
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.01
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return state == .populated([]) ? 0 : UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cellHeightsDictionary[indexPath] = cell.frame.size.height
        if indexPath.row >= state.currentWatchlist.count - 4 {
            customDelegate?.didScrollToBottom()
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeightsDictionary[indexPath] ?? Defaults.Watchlist.estimatedCellHeight
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        customDelegate?.pagedScrollView(didScroll: scrollView)
        if scrollView.contentOffset.y == 0 {
            customDelegate?.didScrollToTop()
        }
    }
}

extension WatchlistTableView: UITableViewDelegate {

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        customDelegate?.didSelect(publication: state.currentWatchlist[indexPath.row])
    }
}

extension WatchlistTableView: PublicationCellDelegate {

    func didTapHeader(for issuerId: Int, issuerType: PublicationIssuerType) {
        customDelegate?.didTapHeader(for: issuerId, issuerType: issuerType)
    }

    func didSelect(publication: Publication) {
        customDelegate?.didSelect(publication: publication)
    }
    
    func didSelectAddToCalendar(for event: Event) {
        customDelegate?.didSelectAddToCalendar(for: event)
    }
    
    func didSelectPlayVideo(for news: News) {
        customDelegate?.didSelectPlayVideo(for: news)
    }
    
    func didTapShareButton(shareUrl: URL?) {
        customDelegate?.didTapShareButton(shareUrl: shareUrl)
    }

    func didSwitch(dateDisplayType: EventDateDisplayType) {
        customDelegate?.didSwitch(dateDisplayType: dateDisplayType)
    }
}

extension WatchlistTableView {
    
    private func configureBackgroundView(withState state: WatchlistState) {
        listBackgroundView.updateText(state.messageForBackgroundView)
        listBackgroundView.showArrow = state.showArrow
        
        var newListBackgroundAlpha: CGFloat = 0
        self.backgroundView = nil
        
        if state.showBackgroundView {
            self.backgroundView = listBackgroundView
            newListBackgroundAlpha = 1
            reloadData()
        }
        UIView.animate(withDuration: 0.5) {
            self.listBackgroundView.alpha = newListBackgroundAlpha
        }
    }
}

private extension WatchlistState {
    
    var messageForBackgroundView: String {
        switch self {
        case .empty(let usingFilters):
            return usingFilters ? Localizable.watchlistEmptyWithFilters.localized : Localizable.watchlistEmpty.localized 
        case .error(let error): return error.localizedDescription
        default: return ""
        }
    }
}
