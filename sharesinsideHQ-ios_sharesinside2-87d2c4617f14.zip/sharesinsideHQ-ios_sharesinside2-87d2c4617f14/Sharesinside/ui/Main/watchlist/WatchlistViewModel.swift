//
//  CompaniesViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum WatchlistDataType {
    case watchlist
    case events
    case companyNews(companyId: Int)
    case companyEvents(companyId: Int)
    case fundNews(fundId: Int)
    case fundEvents(fundId: Int)
    case fundManagerNews(fundManagerId: Int)
    case fundManagerEvents(fundManagerId: Int)
    case startupNews(startupId: Int)
    case startupEvents(startupId: Int)
    case startupProjects(startupId: Int)

    var title: String? {
        switch self {
        case .companyNews: return Localizable.companyNewsTitle.localized
        case .companyEvents: return Localizable.companyEventsTitle.localized
        case .fundEvents: return Localizable.fundEventsTitle.localized
        case .fundNews: return Localizable.fundNewsTitle.localized
        case .fundManagerEvents: return Localizable.fundManagerEventsTitle.localized
        case .fundManagerNews: return Localizable.fundManagerNewsTitle.localized
        case .startupEvents: return Localizable.fundManagerEventsTitle.localized
        case .startupNews: return Localizable.fundManagerNewsTitle.localized
        case .startupProjects: return Localizable.startupProjectsTitle.localized
        default: return nil
        }
    }
}

enum WatchlistState: Equatable {

    case loading
    case paging([Publication])
    case populated([Publication])
    case empty(usingFilters: Bool)
    case error(Error)

    var currentWatchlist: [Publication] {
        switch self {
        case .paging(let watchlist): return watchlist
        case .populated(let watchlist): return watchlist
        default: return []
        }
    }

    var showBackgroundView: Bool {
        switch self {
        case .empty, .error: return true
        default: return false
        }
    }
    
    var hashes: [Int] {
        return currentWatchlist.compactMap { $0.hashValue }
    }

    static func == (lhs: WatchlistState, rhs: WatchlistState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
    
    var showArrow: Bool {
        switch self {
        case .empty(let usingFilters): return !usingFilters
        default: return false
        }
    }
}

class WatchlistViewModel: BaseViewModel<HasWatchlistRepository & HasFiltersRepository & HasCalendarManager & HasEventsRepository & HasEventsDisplayDateTypeRepository> {

    typealias FilterData = (filters: [Filter], selectedFilters: Int, searchValue: String?)
    typealias WatchlistData = (publications: [Publication], metadata: ListMetadata)

    let watchlistState = BehaviorRelay<WatchlistState>(value: .loading)
    let filtersData = BehaviorRelay<FilterData>(value: FilterData([], 0, nil))
    let newPublicationsCount = PublishRelay<Int>()

    private let watchlistResponse = BehaviorRelay<WatchlistData?>(value: nil)
    private let moreDataNeedRelay = BehaviorRelay(value: 1)

    lazy var filters = BehaviorRelay(value: AdvancedFilters.empty())

    var listType: WatchlistDataType = .watchlist
    
    private(set) lazy var eventsRepository = dependencies.eventsRepository
    private(set) lazy var watchlistRepository = dependencies.watchlistRepository
    private(set) lazy var filtersRepository = dependencies.filtersRepository
    private(set) lazy var calendarManager = dependencies.calendarManager
    private lazy var eventsDisplayDateTypeRepository = dependencies.eventsDisplayDateTypeRepository
    
    var isUsingFilters: Bool {
        return filtersData.value.selectedFilters != 0
    }
    
    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        fetchFilters()
        
        MainFlowRxBus.companyFollowingStatePublishRelay
            .subscribe(onNext: { [weak self] model in
                guard let `self` = self else { return }
                if model?.newFollowingState != .changing {
                    self.refresh()
                }
            }).disposed(by: disposeBag)
        
        MainFlowRxBus.notificationReceivedPublishRelay
            .subscribe(onNext: { [weak self] _ in
                self?.newPublicationsCount.accept(Config.newPublicationsCount)
            }).disposed(by: disposeBag)

        eventsDisplayDateTypeRepository.displayDateTypeChange
            .withLatestFrom(watchlistState)
            .bind(to: watchlistState)
            .disposed(by: disposeBag)
    }
    
    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.watchlistState.accept(.loading) })
            .withLatestFrom(watchlistResponse)
            .filter { watchlistResponse -> Bool in
                guard let meta = watchlistResponse?.metadata else { return true }
                return meta.currentPage < meta.lastPage
            }
            .withLatestFrom(filters) { ($0, $1) }
            .flatMapLatest { args -> Observable<WatchlistData?> in
                let (watchlistResponse, filters) = args
                return self.response(ofType: self.listType, previousResponse: watchlistResponse, filters: filters)
                    .map {
                        let watchlist = self.mapToPublications(watchlistData: $0.data)
                        return (((watchlistResponse?.publications ?? []) + watchlist).uniqueElements, $0.meta)
                    }
                    .do(onNext: { [weak self] watchlistResponse in
                        self?.handle(watchlistResponse: watchlistResponse)
                    })
                    .catchError { [weak self] error in
                        self?.watchlistState.accept(.error(error))
                        return Observable<WatchlistData?>.just(nil)
                }
            }
            .bind(to: watchlistResponse)
            .disposed(by: disposeBag)
    }
    
    private func handle(watchlistResponse: WatchlistData?) {
        /* Waiting before update state was added to awoid edge case where
            first page is loaded and immediatelly list sends information that it needs more data
            and watchlistResponses is empty because '.bind(to:)' is called after api request
         */
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(10), execute: {
            guard let publications = watchlistResponse?.publications,
                let meta = watchlistResponse?.metadata else {
                    self.watchlistState.accept(.empty(usingFilters: self.isUsingFilters))
                    return
            }
            
            if publications.isEmpty {
                self.watchlistState.accept(.empty(usingFilters: self.isUsingFilters))
            } else if meta.currentPage < meta.lastPage {
                self.watchlistState.accept(.paging(publications))
            } else {
                self.watchlistState.accept(.populated(publications))
            }
        })
    }

    private func response(ofType type: WatchlistDataType,
                          previousResponse: WatchlistData?,
                          filters: AdvancedFilters,
                          page: Int? = nil,
                          itemsPerPage: Int? = nil) -> Observable<WatchlistResponse> {
        
        let currentItems = previousResponse?.publications.count ?? 0
        let itemsPerPageCount = previousResponse?.metadata.perPage ?? 1
        
        var currentPage = currentItems / itemsPerPageCount
        if currentPage < 0 { currentPage = 0 }
        
        let nextPage = (page ?? currentPage) + 1
        switch type {
        case .watchlist:
            return self.watchlistRepository.getWatchlist(fromPage: nextPage, withFilters: filters, itemsPerPage: itemsPerPage)
        case .events:
            return self.eventsRepository.getEvents(fromPage: nextPage, withFilters: filters, itemsPerPage: itemsPerPage)
        case .companyEvents(let companyId):
            return self.watchlistRepository.getCompanyEvents(id: companyId, page: nextPage)
        case .companyNews(let companyId):
            return self.watchlistRepository.getCompanyNews(id: companyId, page: nextPage)
        case .fundNews(let fundId):
            return self.watchlistRepository.getFundNews(id: fundId, page: nextPage)
        case .fundEvents(let fundId):
            return self.watchlistRepository.getFundEvents(id: fundId, page: nextPage)
        case .fundManagerEvents(let fundManagerId):
            return self.watchlistRepository.getFundManagerEvents(id: fundManagerId, page: nextPage)
        case .fundManagerNews(let fundManagerId):
            return self.watchlistRepository.getFundManagerNews(id: fundManagerId, page: nextPage)
        case .startupEvents(let startupId):
            return self.watchlistRepository.getStartupEvents(id: startupId, page: nextPage)
        case .startupNews(let startupId):
            return self.watchlistRepository.getStartupNews(id: startupId, page: nextPage)
        case .startupProjects(let startupId):
            return self.watchlistRepository.getStartupProjects(id: startupId, page: nextPage)
        }
    }
    
    internal func fetchFilters() {
        filtersRepository.getWatchlistPredefinedFilters()
            .subscribe(
                onNext: { [weak self] in
                    guard let `self` = self else { return }
                    let mappedFilters = $0.map { $0.with(selection: self.filters.value.adHoc) }
                    self.filtersData.accept((mappedFilters, self.filters.value.selectionCount, self.filters.value.search))
                },
                onError: { error in printDebug(error) })
            .disposed(by: disposeBag)
    }
    
    internal func updateDayRangeFilter(_ filter: Filter) {
        var updatedFilters = filters.value
        let defaultStartDate = Date().toString(withFromat: .ohlcDateFormat)
        
        switch filter.type {
        case .today: updatedFilters = updatedFilters.with(startDate: defaultStartDate, eventsForToday: filter.isSelected)
        case .tomorrow: updatedFilters = updatedFilters.with(startDate: defaultStartDate, eventsForTomorrow: filter.isSelected)
        default: break
        }
        
        filters.accept(updatedFilters)
    }
    
    private func mapToPublications(watchlistData: [WatchlistItem]) -> [Publication] {
        return watchlistData.compactMap { item -> Publication? in
            switch item {
            case let .news(news): return news
            case let .event(event): return event
            case let .project(project): return project
            }
        }
    }
    
}

extension WatchlistViewModel {

    func `switch`(displayDateType: EventDateDisplayType) {
        eventsDisplayDateTypeRepository.displayDateType = displayDateType
    }

    func loadMoreData() {
        moreDataNeedRelay.accept(1)
    }

    func refresh() {
        watchlistResponse.accept(nil)
        moreDataNeedRelay.accept(1)
    }

    func selected(publication: Publication) {
        switch publication.type {
        case .event: router?.push(to: .eventDetails(eventId: publication.watchlistableId))
        case .news: router?.push(to: .newsDetails(newsId: publication.watchlistableId))
        case .project: router?.push(to: .projectDetails(projectId: publication.watchlistableId))
        }
    }

    func didTapAccountIcon() { }

    func searchFor(fraze: String) {
        self.filters.accept(filters.value.with(searchText: fraze))
        refresh()
    }

    func moveToWatchlistMoreFiltersView() {
        router?.present(destination: .filters(
            filterTypes: [.attachment, .watchlistRelation, .publicity],
            initialFilters: filters.value,
            delegate: self))
    }

    func moveToAccountInfoView() { }

    private func updateRelationsWithSelectedFilters(filters: AdvancedFilters) { }

    func addToCalendar(event: Event) {
        let eventData = CalendarManager.EventData(title: event.title,
                                                  date: event.details.utcDate.toTimezone(),
                                                  description: event.description,
                                                  address: event.details.prettyPrintedAddress)
        calendarManager.addToCalendar(event: eventData) { [weak self] (success, _) in
            self?.alert.accept(AlertData(message: (success ? Localizable.watchlistAddedEvent : Localizable.watchlistAddedEventError).localized))
        }
    }
    
    func sawNewestPublications() {
        Config.newPublicationsCount = 0
        newPublicationsCount.accept(0)
        refresh()
    }
    
    func clearFiltersIfNeeded() {
        if Config.newPublicationsCount != 0 {
            filters.accept(AdvancedFilters.empty())
            updateFiltersData(filters: filters.value)
            refresh()
        }
    }
}

extension WatchlistViewModel {

    func selectedPredefinedFilter(_ filter: Filter) {
        switch filter.type {
        case .adhoc:
            updateAdHocFilter(with: filter)
        case .location:
            let initialLocation = filters.value.location.isEmpty ? nil : filters.value.location
            router?.present(destination: .locationSearch(initialLocation: initialLocation, delegate: self))
        case .today, .tomorrow:
            updateDayRangeFilter(filter)
        case .watchlistRelation:
            updateWatchlistRelationFilters(with: filter)
        default: break
        }
        
        updateFiltersData(filters: self.filters.value)
        refresh()
    }

    private func updateAdHocFilter(with filter: Filter) {
        self.filters.accept(filters.value.with(adHoc: filter.isSelected))
    }
    
    private func updateWatchlistRelationFilters(with filter: Filter) {
        guard let relation = filter as? WatchlistRelation else { return }
        var relations = filters.value.relations
        
        if let index = relations.index(where: { $0 == relation.name.lowercased() }) {
            relations.remove(at: index)
        }
        if filter.isSelected { relations.append(filter.name.lowercased()) }
        self.filters.accept(filters.value.with(relations: relations))
    }
    
    private func updateFiltersData(filters: AdvancedFilters) {
        let updatedRelations = filtersData.value.filters.map { filter -> Filter in
            var updated = filter.with(selection: filters.hasRelationFilter(filter) ||
                filters.hasSortFilter(filter) ||
                (filter.type == .adhoc && filters.adHoc) ||
                filters.hasTodayFilterSelected(filter) ||
                filters.hasTomorrowFilterSelected(filter) ||
                filters.hasLocation(filter))
            
            if let locationFilter = updated as? LocationFilter {
                updated = locationFilter.with(name: filters.location.isEmpty ?
                    Localizable.filtersLocation.localized : filters.location)
            }
            
            return updated
        }
        self.filtersData.accept((updatedRelations, filters.selectionCount, filters.search))
    }
}

extension WatchlistViewModel: FiltersDelegate {
    func didSelect(filters: AdvancedFilters) {
        self.filters.accept(filters)
        updateFiltersData(filters: filters)
        refresh()
    }    
}

extension WatchlistViewModel: LocationSearchDelegate {
    func didSelect(location: String) {
        self.filters.accept(filters.value.with(location: location))
        updateFiltersData(filters: filters.value)
        refresh()
    }
}
