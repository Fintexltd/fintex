//
//  CompaniesViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import EventKit

class WatchlistViewController: BaseViewController<WatchlistViewModel>, PredefinedFiltersViewDelegate, UISearchBarDelegate {
    
    private lazy var viewCreator = WatchlistView(withParentView: self.view,
        withNavigationItem: self.navigationItem)

    override func setupView() {
        viewCreator.setupView()
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.tableView.customDelegate = self
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        bindNavigationBarItems()
        viewCreator.filterView.delegate = self
        viewCreator.snackBar.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }

    // MARK: Binding
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.watchlistState
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] watchlistState in
                self?.viewCreator.tableView.state = watchlistState
                self?.endRefreshing()
            }).disposed(by: disposeBag)
        
        viewModel.filtersData
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] filtersData in
                    self?.viewCreator.navigationTitle.searchBar.text = filtersData.searchValue
                    self?.viewCreator.filterView.configure(with: filtersData.filters, andSelectedCount: filtersData.selectedFilters)
            })
            .disposed(by: disposeBag)
        
        viewModel.newPublicationsCount
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] publicationsCount in
                guard let self = self else { return }
                if publicationsCount > 0 {
                    self.update(badgeValue: publicationsCount)
                    
                    if self.viewModel.filters.value.areEmpty() {
                        self.viewCreator.snackBar
                            .show(withMessage: "\(Localizable.watchlistNewPublications.localized) (\(publicationsCount))")
                    }
                } else {
                    self.update(badgeValue: nil)
                    self.viewCreator.snackBar.hide()
                }
            }).disposed(by: disposeBag)
    }

    private func bindNavigationBarItems() {
        viewCreator.navigationTitle.accountButton.rx
            .tap
            .asDriver()
            .drive(onNext: { [weak self] in
                self?.viewModel.moveToAccountInfoView()
            }).disposed(by: disposeBag)

        viewCreator.navigationTitle.searchBar.rx
            .text
            .asDriver()
            .ignoreNil()
            .debounce(Defaults.Search.delay)
            .drive(
                onNext: { [weak self] text in self?.viewModel.searchFor(fraze: text) })
            .disposed(by: disposeBag)
        
        viewCreator.navigationTitle.searchBar.rx
            .searchButtonClicked
            .asDriver()
            .drive(
                onNext: { [weak self] in self?.hideKeyboard() })
            .disposed(by: disposeBag)
    }

    @objc private func didSwipeForRefresh() {
        viewModel.refresh()
    }

    private func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.refreshControl.endRefreshing()
        }
    }

    func didSelect(filter: Filter) {
        viewModel.selectedPredefinedFilter(filter)
    }

    func moreFiltersDidTouch() {
        viewModel.moveToWatchlistMoreFiltersView()
    }
    
    private func hideKeyboard() {
        viewCreator.navigationTitle.searchBar.resignFirstResponder()
    }
}

extension WatchlistViewController: WatchlistTableViewDelegate {

    func didTapHeader(for issuerId: Int, issuerType: PublicationIssuerType) {
        switch issuerType {
        case .company:
            router.push(to: .companyDetails(companyId: issuerId))
        case .fund:
            router.push(to: .fundDetails(fundId: issuerId))
        case .fundsManager:
            router.push(to: .fundManagerDetails(fundManagerId: issuerId))
        case .startup:
            router.push(to: .startupDetails(startupId: issuerId))
        }
    }
    
    func pagedScrollView(didScroll scrollView: UIScrollView) {}
    
    func didSelectAddToCalendar(for event: Event) {
        viewModel.addToCalendar(event: event)
    }

    func didScrollToBottom() {
        viewModel.loadMoreData()
    }
    
    func didScrollToTop() {
        viewModel.sawNewestPublications()
    }

    func didSelect(publication: Publication) {
        viewModel.selected(publication: publication)
    }
    
    func didSelectPlayVideo(for news: News) {
        
    }
    
    func didTapShareButton(shareUrl: URL?) {
        self.shareNews(url: shareUrl)
    }

    func didSwitch(dateDisplayType: EventDateDisplayType) {
        viewModel.switch(displayDateType: dateDisplayType)
    }
}

extension WatchlistViewController: SnackBarDelegate {
    func snackBarDidTouch() {
        scrollTableViewToTop()
    }
}

extension WatchlistViewController: TabBarChildController {
    func didTouchTabItem() {
        viewModel.clearFiltersIfNeeded()
        scrollTableViewToTop()
    }
    
    private func scrollTableViewToTop() {
        if viewCreator.tableView.contentOffset.y == 0 {
            viewModel.sawNewestPublications()
        } else {
            guard viewCreator.tableView.numberOfRows(inSection: 0) > 0 else { return }
            viewCreator.tableView.scrollToRow(at: IndexPath(item: 0, section: 0), at: .top, animated: true)
        }
    }
}
