//
//  NotificationsViewController.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

class NotificationsViewController: BaseViewController<NotificationsViewModel> {
    
    lazy var viewCreator = NotificationsView(withParentView: self.view)
    lazy var tableDataSource = NotificationsTableDataSource(with: viewCreator.tableView)
 
    private var needReloadView: Bool = false

    override func setupView() {
        viewCreator.setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupSettings()
        navigationController?.setupNavigationBar(withStyle: .dark)
    }
    
    override func initializeView() {
        super.initializeView()
        title = Localizable.tabBarNotifications.localized
        
        tableDataSource.delegate = self
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        
        viewCreator.accountButton.addTarget(self, action: #selector(accountButtonDidTouch), for: .touchUpInside)
        navigationItem.leftBarButtonItem = viewCreator.accountBarButtonItem
        viewCreator.settingsButton.addTarget(self, action: #selector(settingsButtonDidTouch), for: .touchUpInside)
        viewCreator.leftViewButton.addTarget(self, action: #selector(settingsButtonDidTouch), for: .touchUpInside)
        navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.notificationsState
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] notificationsState in
                self?.tableDataSource.appNotificationsState = notificationsState
                self?.endRefreshing()
            }).disposed(by: disposeBag)
        
        viewModel.newNotificationsCount
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] notificationsCount in
                guard let self = self else { return }
                self.update(badgeValue: notificationsCount > 0 ? notificationsCount : nil)
            }).disposed(by: disposeBag)
    }
    
    private func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.refreshControl.endRefreshing()
        }
    }
    
    @objc private func didSwipeForRefresh() {
        viewModel.refresh()
    }
    
    @objc private func accountButtonDidTouch() {
        router.present(destination: .profile)
    }
    
    @objc private func settingsButtonDidTouch() {
        router.present(destination: .notificationSettings)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        needReloadView = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needReloadView {
            needReloadView = false
            setupSettings()
        }
    }
    
    private func setupSettings() {
        let isTabletLandscape = AppInfo.isIPad && AppInfo.orientation.isLandscape
        navigationItem.rightBarButtonItem = isTabletLandscape ? nil : viewCreator.settingsBarButtonItem
        viewCreator.changeNotificationLeftViewVisibility(visible: isTabletLandscape)
        
        UIView.animate(withDuration: 0.2) {
            self.viewCreator.contentStackView.layoutIfNeeded()
        }
    }
}

extension NotificationsViewController: NotificationsTableDataSourceDelegate {
    func didScrollToBottom() {
        viewModel.loadMoreData()
    }
    
    func didSelect(notification: AppNotification) {
        viewModel.openDetails(for: notification)
    }
    
    func didScrollToTop() {
        viewModel.sawNewestNotifications()
    }
}

extension NotificationsViewController: TabBarChildController {
    func didTouchTabItem() {
        scrollTableViewToTop()
    }
    
    private func scrollTableViewToTop() {
        if viewCreator.tableView.contentOffset.y == 0 {
            viewModel.refresh()
        } else {
            guard viewCreator.tableView.numberOfRows(inSection: 0) > 0 else { return }
            viewCreator.tableView.scrollToRow(at: IndexPath(item: 0, section: 0), at: .middle, animated: true)
        }
    }
}
