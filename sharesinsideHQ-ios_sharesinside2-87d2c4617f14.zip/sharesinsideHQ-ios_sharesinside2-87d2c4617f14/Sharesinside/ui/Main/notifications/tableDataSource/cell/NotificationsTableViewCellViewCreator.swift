//
//  NotificationsTableViewCellViewCreator.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class NotificationsTableViewCellViewCreator: BaseViewCreator {
    
    lazy var companyLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        
        return imageView
    }()
    
    lazy var notificationMessage: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey,
                                          withFontSize: Defaults.TextSize.medium)
        label.textAlignment = .left
        return label
    }()
    
    let dateLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.small)
        label.numberOfLines = 1
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        return label
    }()
    
    private lazy var logoStackView = UIStackView.make(
        axis: .vertical,
        with: [
            companyLogo.embedInView(),
            dateLabel
        ],
        spacing: Defaults.marginTiny)
    
    override func setupViewHierarchy() {
        [logoStackView, notificationMessage].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        companyLogo.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Company.logoSize)
            make.height.equalTo(companyLogo.snp.width).multipliedBy(1)
            make.top.bottom.equalToSuperview()
            make.leading.greaterThanOrEqualToSuperview()
            make.trailing.lessThanOrEqualToSuperview()
            make.centerX.equalToSuperview()
        }
        
        logoStackView.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().offset(Defaults.marginSmall).priority(.highest)
            make.bottom.lessThanOrEqualToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
        
        notificationMessage.snp.makeConstraints { make in
            make.leading.equalTo(logoStackView.snp.trailing).inset(Defaults.marginSmall.negative())
            make.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().offset(Defaults.marginNormal).priority(.highest)
            make.bottom.lessThanOrEqualToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
    }
    
}
