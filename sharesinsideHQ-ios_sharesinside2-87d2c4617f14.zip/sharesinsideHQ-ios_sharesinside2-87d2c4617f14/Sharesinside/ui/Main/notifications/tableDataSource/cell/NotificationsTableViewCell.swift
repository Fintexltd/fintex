//
//  NotificationsTableViewCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class NotificationsTableViewCell: UITableViewCell {
    
    var appNotification: AppNotification? {
        didSet {
            guard let appNotification = appNotification else { return }
            configure(with: appNotification)
        }
    }
    
    private lazy var viewCreator = NotificationsTableViewCellViewCreator(withParentView: self.contentView)
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        viewCreator.setupView()
        selectionStyle = .none
        separatorInset = .zero
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        viewCreator.companyLogo.image = nil
    }
    
    private func configure(with appNotification: AppNotification) {
        viewCreator.companyLogo.load(with: appNotification.logoUrl)
        viewCreator.dateLabel.text = appNotification.publishDate?.prettyPrintedNotificationsDate
        viewCreator.notificationMessage.attributedText = appNotification.title
            .attributedFromHtml?
            .withSystemFont(ofSize: Defaults.TextSize.medium)
    }
}
