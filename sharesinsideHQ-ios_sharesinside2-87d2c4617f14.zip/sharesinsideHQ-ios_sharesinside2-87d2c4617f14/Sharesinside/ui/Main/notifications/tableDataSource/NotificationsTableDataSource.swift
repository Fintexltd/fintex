//
//  NotificationsTableDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import DeepDiff

protocol NotificationsTableDataSourceDelegate: class {
    func didScrollToBottom()
    func didSelect(notification: AppNotification)
    func didScrollToTop()
}

class NotificationsTableDataSource: NSObject {
    
    weak var delegate: NotificationsTableDataSourceDelegate?
    
    private var cellHeightsDictionary: [IndexPath: CGFloat] = [:]
    
    var appNotificationsState: AppNotificationsState = .loading {
        didSet {
            tableView.reloadData()
            updateBackgroundView()
        }
    }
    
    private lazy var failureView: FailureView = {
        let view = FailureView()
        view.showArrow = false
        return view
    }()
    
    private let tableView: UITableView
    
    init(with tableView: UITableView) {
        self.tableView = tableView
        super.init()
        setupTableView()
    }
    
    private func updateBackgroundView() {
        failureView.updateText(appNotificationsState.messageForBackgroundView)
        failureView.showArrow = appNotificationsState.showArrow
        tableView.backgroundView = failureView
        
        var newListBackgroundAlpha: CGFloat = 0
        tableView.backgroundView = nil
        
        if appNotificationsState.showBackgroundView {
            tableView.backgroundView = failureView
            newListBackgroundAlpha = 1
            tableView.reloadData()
        }
        UIView.animate(withDuration: 0.5) {
            self.failureView.alpha = newListBackgroundAlpha
        }
    }
}

extension NotificationsTableDataSource {
    
    private func setupTableView() {
        tableView.registerCell(NotificationsTableViewCell.self)
        tableView.registerHeaderFooter(StateTableViewFooter.self)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.sectionFooterHeight = 0
        tableView.tableFooterView = UIView()
        tableView.tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
        
        tableView.estimatedRowHeight = Defaults.Watchlist.estimatedCellHeight
        tableView.rowHeight = UITableView.automaticDimension
        
        tableView.sectionFooterHeight = Defaults.Company.footerHeight
        tableView.sectionHeaderHeight = 1
    }
}

extension NotificationsTableDataSource: UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appNotificationsState.notifications.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: NotificationsTableViewCell = tableView.dequeueReusableCell(for: indexPath) {
            cell.appNotification = appNotificationsState.notifications[indexPath.item]
            return cell
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if let stateFooter: StateTableViewFooter = tableView.dequeueReusableHeaderFooter(),
            appNotificationsState == .loading || appNotificationsState == .paging([]) {
            stateFooter.initialize()
            stateFooter.contentView.backgroundColor = .white
            return stateFooter
        }

        return UIView()
    }
        
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cellHeightsDictionary[indexPath] = cell.frame.size.height
        if indexPath.row >= appNotificationsState.notifications.count - 4 {
            delegate?.didScrollToBottom()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return appNotificationsState == .populated([]) ? 0 : UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeightsDictionary[indexPath] ?? Defaults.Watchlist.estimatedCellHeight
    }
}

extension NotificationsTableDataSource: UITableViewDelegate {
  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        delegate?.didSelect(notification: appNotificationsState.notifications[indexPath.item])
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.contentOffset.y == 0 {
            delegate?.didScrollToTop()
        }
    }
}
