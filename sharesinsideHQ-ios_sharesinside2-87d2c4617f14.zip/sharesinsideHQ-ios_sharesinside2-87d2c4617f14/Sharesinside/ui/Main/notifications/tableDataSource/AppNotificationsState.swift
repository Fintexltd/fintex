//
//  AppNotificationsState.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

enum AppNotificationsState {
    
    case loading
    case paging([AppNotification])
    case populated([AppNotification])
    case empty
    case error(Error)
    
    var notifications: [AppNotification] {
        switch self {
        case .paging(let watchlist): return watchlist
        case .populated(let watchlist): return watchlist
        default: return []
        }
    }
    
    var showBackgroundView: Bool {
        switch self {
        case .empty, .error: return true
        default: return false
        }
    }
    
    var showArrow: Bool {
        switch self {
        case .empty: return true
        default: return false
        }
    }
}

extension AppNotificationsState {
    
    var messageForBackgroundView: String {
        switch self {
        case .empty: return Localizable.appNotificationsEmpty.localized
        case .error(let error): return error.localizedDescription
        default: return ""
        }
    }
}

extension AppNotificationsState: Equatable {
    static func == (lhs: AppNotificationsState, rhs: AppNotificationsState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}
