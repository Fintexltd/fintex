//
//  NotificationsViewModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class NotificationsViewModel: BaseViewModel<HasNotificationsRepository> {

    typealias NotificationsData = (notifications: [AppNotification], metadata: ListMetadata)

    let notificationsState = BehaviorRelay<AppNotificationsState>(value: .loading)
    let newNotificationsCount = PublishRelay<Int>()

    private let moreDataNeedRelay = BehaviorRelay(value: 1)
    private let notificationsResponse = BehaviorRelay<NotificationsData?>(value: nil)

    private lazy var notificationsRepository = dependencies.notificationsRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        subscribeToPushNotifications()
    }

    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.notificationsState.accept(.loading) })
            .withLatestFrom(notificationsResponse)
            .filter { notificationsResponse -> Bool in
                guard let meta = notificationsResponse?.metadata else { return true }
                return meta.currentPage < meta.lastPage
            }
            .flatMapLatest { notificationsResponse -> Observable<NotificationsData?> in
                let nextPage = (notificationsResponse?.metadata.currentPage ?? 0) + 1
                return self.notificationsRepository
                    .fetchAppNotifications(fromPage: nextPage)
                    .map { NotificationsData(((notificationsResponse?.notifications ?? []) + $0.data).uniqueElements, $0.meta) }
                    .do(onNext: { [weak self] notificationsData in
                        if nextPage == 1 { self?.newNotificationsCount.accept(0) }
                        self?.handle(notificationsResponse: notificationsData)
                    })
                    .catchError { [weak self] error in
                        self?.notificationsState.accept(.error(error))
                        return Observable<NotificationsData?>.just(nil)
                }
            }
            .bind(to: notificationsResponse)
            .disposed(by: disposeBag)
    }

    private func handle(notificationsResponse: NotificationsData?) {
        /* Waiting before update state was added to awoid edge case where
         first page is loaded and immediatelly list sends information that it needs more data
         and notificationsResponse is empty because '.bind(to:)' is called after api request
         */
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(10), execute: {
                guard let notifications = notificationsResponse?.notifications,
                    let meta = notificationsResponse?.metadata else {
                        self.notificationsState.accept(.empty)
                        return
                }

                if notifications.isEmpty {
                    self.notificationsState.accept(.empty)
                } else if meta.currentPage < meta.lastPage {
                    self.notificationsState.accept(.paging(notifications))
                } else {
                    self.notificationsState.accept(.populated(notifications))
                }
            })
    }

    private func subscribeToPushNotifications() {
        MainFlowRxBus.notificationReceivedPublishRelay
            .subscribe(onNext: { [weak self] _ in
                self?.fetchNotificationsIndicator()
            }).disposed(by: disposeBag)
    }

    private func fetchNotificationsIndicator() {
        notificationsRepository.getAppNotificationsIndicator()
            .subscribe(onNext: { indicator in
                self.newNotificationsCount.accept(indicator)
            }).disposed(by: disposeBag)
    }
}

extension NotificationsViewModel {

    func loadMoreData() {
        moreDataNeedRelay.accept(1)
    }

    func refresh() {
        notificationsResponse.accept(nil)
        moreDataNeedRelay.accept(1)
    }

    func openDetails(for notification: AppNotification) {
        if let destination = notification.routeDestination {
            router?.push(to: destination)
        }
    }

    func sawNewestNotifications() {
        newNotificationsCount.accept(0)
        refresh()
    }
}
