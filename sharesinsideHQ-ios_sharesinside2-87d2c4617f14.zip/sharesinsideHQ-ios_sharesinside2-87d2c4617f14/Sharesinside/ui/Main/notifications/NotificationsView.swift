//
//  NotificationsView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class NotificationsView: BaseViewCreator {
    
    let tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped).layoutable()
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .white
        return tableView
    }()
    
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary
        
        return refreshControl
    }()
    
    // MARK: Bar buttons
    let accountButton = ButtonFactory.makeAccountButton()
    
    lazy var accountBarButtonItem: UIBarButtonItem = {
        return UIBarButtonItem(customView: accountButton)
    }()
    
    let settingsButton = ButtonFactory.makeSettingsButton()
    
    lazy var settingsBarButtonItem: UIBarButtonItem = {
        return UIBarButtonItem(customView: settingsButton)
    }()
    
    // MARK: left view
    let leftViewContainer = UIView().layoutable()
    
    lazy var leftViewIcon: UIImageView = {
        let imageView = UIImageView(image: #imageLiteral(resourceName: " InformationNotifications")).layoutable()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var leftViewTitle: UILabel = {
        let title = UILabelFactory.styled(withFontSize: Defaults.TextSize.big,
                                          fontWeight: .bold)
        title.text = Localizable.appNotificationsWantMore.localized
        return title
    }()
    
    lazy var leftViewDescription: UILabel = {
        let description = UILabelFactory.styled(withFontSize: Defaults.TextSize.medium)
        description.text = Localizable.appNotificationsDescription.localized
        return description
    }()
    
    lazy var leftViewButton: UIButton = {
        let button = SharesinsideButton()
        button.style = SharesinsideButton.Style.accent
        button.setTitle(Localizable.appNotificationsButtonTitle.localized.uppercased(), for: .normal)
        return button
    }()
    
    lazy var leftViewStackView: UIStackView = UIStackView.make(
        axis: .vertical,
        with: [
            leftViewIcon,
            leftViewTitle,
            leftViewDescription,
            leftViewButton
        ],
        spacing: Defaults.marginBig)
    
    // MARK: Content stackView
    lazy var contentStackView: UIStackView = UIStackView.make(
        axis: .horizontal,
        with: [
            leftViewContainer,
            tableView
        ],
        spacing: Defaults.marginNormal)
    
    // MARK: Initialization
    override func setupViewHierarchy() {
        parentView.addSubview(contentStackView)
        tableView.addSubview(refreshControl)
        leftViewContainer.addSubview(leftViewStackView)
    }
    
    override func setupProperties() {
        settingsButton.tintColor = .grey
        leftViewContainer.backgroundColor = .primaryDark
    }
    
    override func setupConstraints() {
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview().priority(.highest)
        }
        
        accountButton.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Navigation.itemWidth)
            make.height.equalTo(Defaults.Navigation.itemHeight)
        }
        
        settingsButton.snp.makeConstraints { make in
            make.width.equalTo(Defaults.Navigation.settingsSize)
            make.height.equalTo(Defaults.Navigation.settingsSize)
        }        
        setupLeftViewConstraints()
    }
    
    private func setupLeftViewConstraints() {
        leftViewContainer.snp.remakeConstraints { make in
            make.width.equalToSuperview().multipliedBy(0.4).priority(.highest)
        }
        
        leftViewStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.centerY.equalToSuperview().offset(Defaults.marginTremendous.negative())
        }
        
        leftViewIcon.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Information.iconHeight).priority(.high)
        }
    }
}

extension NotificationsView {
    
    func changeNotificationLeftViewVisibility(visible: Bool) {
        [leftViewContainer, leftViewDescription, leftViewIcon, leftViewTitle, leftViewButton].forEach { $0.isHidden = !visible }
    }
}
