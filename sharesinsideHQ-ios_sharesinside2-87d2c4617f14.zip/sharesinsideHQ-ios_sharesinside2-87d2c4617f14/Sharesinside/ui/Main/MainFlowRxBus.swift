//
//  MainFlowRxBus.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 12.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa

struct CompanyFollowingChangeModel {
    let companyId: Int
    let newFollowingState: FollowingState
}

struct FundManagerFollowingChangeModel {
    let fundManagerId: Int
    let newFollowingState: FollowingState
}

struct FundFollowingChangeModel {
    let fundId: Int
    let newFollowingState: FollowingState
}

struct FollowingChangeModel {
    let id: Int
    let newFollowingState: FollowingState
}

class MainFlowRxBus {
    
    static let companyFollowingStatePublishRelay = PublishRelay<CompanyFollowingChangeModel?>()

    static let startupFollowingStatePublishRelay = PublishRelay<FollowingChangeModel?>()

    static let fundFollowingStatePublishRelay = PublishRelay<FundFollowingChangeModel?>()

    static let fundManagersFollowingStatePublishRelay = PublishRelay<FundManagerFollowingChangeModel?>()
    
    static let notificationReceivedPublishRelay = PublishRelay<PushNotification.NotificationType>()

}
