//
//  FundManagerCollectionViewCell.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol FundManagerCellDelegate: class {
    func collectionCell(_ cell: FundManagerCollectionViewCell, didToogleFollowFundManager fundManager: FundManager)
    func collectionCell(_ cell: FundManagerCollectionViewCell, didTapUserGroupsFor fundManager: FundManager)
}

class FundManagerCollectionViewCell: UICollectionViewCell {

    weak var delegate: FundManagerCellDelegate?

    private lazy var viewCreator = FundManagerCellViewCreator(withParentView: self.contentView)

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    var fundManager: FundManager? {
        didSet {
            if let fundManager = fundManager {
                configure(with: fundManager)
            }
        }
    }

    private func configure(with fundManager: FundManager) {
        viewCreator.fundManagerTitle.text = fundManager.name

        viewCreator.fundManagerAddress.text = fundManager.address

        viewCreator.followButton.isHidden = fundManager.following == .changing
        viewCreator.followButton.setTitle(fundManager.following.stateTitle, for: .normal)
        viewCreator.followButton.style = fundManager.following.buttonStyle
        viewCreator.followLoader.isHidden = fundManager.following != .changing

        if let logo = fundManager.logo, let logoUrl = URL(string: logo) {
            viewCreator.fundManagerLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
        }

        let orientation = UIApplication.shared.statusBarOrientation
        viewCreator.contentStackView.axis = orientation.isPortrait ? .vertical : .horizontal
        viewCreator.fundManagerAddress.textAlignment = orientation.isPortrait ? .left : .right
        viewCreator.followButton.addTarget(self, action: #selector(followDidTouch), for: .touchUpInside)
        viewCreator.userGroups.configure(withUserGroups: fundManager.fundManagersCellGroups.compactMap({ $0.title }))
    }

    private func initializeView() {
        viewCreator.setupView()
        viewCreator.userGroups.setupGestureRecognizer(target: self, selector: #selector(userGroupsDidTouch))
    }

    @objc private func followDidTouch() {
        guard let fundManager = fundManager else { return }
        delegate?.collectionCell(self, didToogleFollowFundManager: fundManager)
    }

    @objc private func userGroupsDidTouch() {
        guard let fundManager = fundManager else { return }
        delegate?.collectionCell(self, didTapUserGroupsFor: fundManager)
    }
}
