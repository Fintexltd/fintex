//
//  FundManagerCellView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit

class FundManagerCellViewCreator: BaseViewCreator {

    lazy var fundManagerLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.FundManager.cellCornerRadius
        imageView.backgroundColor = .clear

        return imageView
    }()

    lazy var fundManagerTitle: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark,
            fontWeight: .bold)
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()

    let userGroups = ChipCollectionView()

    lazy var fundManagerAddress: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
            withFontSize: Defaults.TextSize.small)
        label.numberOfLines = 0
        label.setContentPriority(resistancePriority: UILayoutPriority.required, resistanceAxis: .vertical, huggingPriority: UILayoutPriority.defaultLow.decreased(by: 1), huggingAxis: .vertical)
        return label
    }()

    lazy var followButton: SharesinsideButton = {
        let button = SharesinsideButton()
        button.style = SharesinsideButton.Style.primary
        return button
    }()

    lazy var followLoader: LoaderView = {
        let loader = LoaderView()
        loader.isSpinning = true
        return loader
    }()

    lazy var titleStackView = UIStackView
        .make(axis: .vertical,
            with: [
                fundManagerTitle,
                userGroups
            ],
            spacing: Defaults.marginTiny)

    lazy var detailsStackView = UIStackView
        .make(axis: .vertical,
            with: [
                fundManagerAddress
            ])

    lazy var contentStackView: UIStackView = {
        let stackView = UIStackView
            .make(axis: .vertical,
                with: [
                    titleStackView,
                    detailsStackView.embedInView()
                ],
                spacing: Defaults.marginTiny,
                distribution: UIStackView.Distribution.fillProportionally)
        stackView.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        return stackView
    }()

    lazy var bottomDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    lazy var verticalDivider: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    override func setupProperties() {
        parentView.backgroundColor = .accent
        parentView.clipsToBounds = true
    }

    override func setupViewHierarchy() {
        [fundManagerLogo, contentStackView, bottomDivider, followLoader, followButton, verticalDivider].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        fundManagerLogo.snp.makeConstraints { make in
            make.leading.top.equalToSuperview().offset(Defaults.marginNormal)
            make.width.equalTo(Defaults.FundManager.logoSize)
            make.height.equalTo(fundManagerLogo.snp.width).multipliedBy(1).priority(.highest)
        }

        contentStackView.snp.makeConstraints { make in
            make.leading.equalTo(fundManagerLogo.snp.trailing).offset(Defaults.marginNormal)
            make.top.trailing.equalToSuperview().inset(Defaults.marginNormal)
        }

        followButton.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.greaterThanOrEqualTo(contentStackView.snp.bottom).offset(Defaults.marginNormal).priority(.high)
            make.height.equalTo(Defaults.FundManager.followButtonHeight)
            make.bottom.equalToSuperview().inset(Defaults.marginBig)
            make.top.greaterThanOrEqualTo(fundManagerLogo.snp.bottom).offset(Defaults.marginNormal)
        }

        bottomDivider.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
            make.leading.trailing.bottom.equalToSuperview()
        }

        verticalDivider.snp.makeConstraints { make in
            make.width.equalTo(Defaults.dividerSize)
            make.top.bottom.trailing.equalToSuperview()
        }

        detailsStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.greaterThanOrEqualToSuperview()
            make.bottom.lessThanOrEqualToSuperview()
            make.centerY.equalToSuperview()
        }

        followLoader.snp.makeConstraints { make in
            make.edges.equalTo(followButton.snp.edges).inset(Defaults.marginTiny)
        }
    }
}
