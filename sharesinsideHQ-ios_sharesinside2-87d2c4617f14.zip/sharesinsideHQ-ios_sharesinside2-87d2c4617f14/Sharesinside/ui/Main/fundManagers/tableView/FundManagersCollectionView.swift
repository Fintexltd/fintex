//
//  FundManagersCollectionView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import DeepDiff

protocol FundManagersCollectionViewDelegate: class {
    func collectionViewNeedsMoreData()
    func toogleFollowing(of fundManager: FundManager)
    func didSelect(fundManager: FundManager)
}

class FundManagersCollectionView: UICollectionView {

    weak var collectionViewDelegate: FundManagersCollectionViewDelegate?

    var state: FundManagersState = .loading {
        willSet(newValue) {
            listChanges = diff(old: state.currentFundManagers, new: newValue.currentFundManagers)
        }
        didSet {
            if let listChanges = listChanges {
                updateCollectionView(withChanges: listChanges)
                updateBackgroundView()
            }
        }
    }

    private var itemWidth: CGFloat = 0
    private var listChanges: [Change<FundManager>]?

    lazy var failureView: FailureView = {
        let view = FailureView()

        return view
    }()

    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        initialize()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }

    private func initialize() {
        registerCell(FundManagerCollectionViewCell.self)
        registerFooterView(StateFooterView.self)
        delegate = self
        dataSource = self
    }

    override func reloadSections(_ sections: IndexSet) {
        itemWidth = 0
        super.reloadSections(sections)
    }

    private func updateCollectionView(withChanges changes: [Change<FundManager>]) {
        collectionViewLayout.invalidateLayout()
        reload(changes: changes) { [weak self] _ in self?.listChanges = nil }
    }

    private func updateBackgroundView() {
        failureView.updateText(state.failureMessage)
        backgroundView = failureView
    }
}

extension FundManagersCollectionView: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return state.currentFundManagers.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: FundManagerCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.fundManager = state.currentFundManagers[indexPath.row]
            cell.delegate = self
            return cell
        }

        return UICollectionViewCell()
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == (collectionView.numberOfItems(inSection: indexPath.section) - 4) {
            collectionViewDelegate?.collectionViewNeedsMoreData()
        }
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if let stateFooter: StateFooterView = collectionView.dequeueReusableFooterView(for: indexPath) {
            stateFooter.initialize()
            return stateFooter
        }
        return UICollectionReusableView()
    }

    private func itemWidth(forSize size: CGSize) -> CGFloat {
        let multiplier: CGFloat = UIScreen.main.traitCollection.userInterfaceIdiom == .phone ? 1 : 0.5
        return (size.width) * multiplier
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionViewDelegate?.didSelect(fundManager: state.currentFundManagers[indexPath.row])
    }
}

extension FundManagersCollectionView: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if itemWidth == 0 { itemWidth = itemWidth(forSize: bounds.size) }

        let height: CGFloat = UIApplication.shared.statusBarOrientation.isPortrait ?
            Defaults.FundManager.cellPortraitHeight : Defaults.FundManager.cellHorizontalHeight

        return CGSize(width: itemWidth, height: height)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: state.heightForFooter)
    }
}

extension FundManagersCollectionView: FundManagerCellDelegate {

    func collectionCell(_ cell: FundManagerCollectionViewCell, didToogleFollowFundManager fundManager: FundManager) {
        collectionViewDelegate?.toogleFollowing(of: fundManager)
    }

    func collectionCell(_ cell: FundManagerCollectionViewCell, didTapUserGroupsFor fundManager: FundManager) {
        collectionViewDelegate?.didSelect(fundManager: fundManager)
    }
}

extension FundManagersState {

    var heightForFooter: CGFloat {
        switch self {
        case .loading, .paging: return Defaults.FundManager.footerHeight
        default: return 0
        }
    }

    var failureMessage: String? {
        switch self {
        case .error(let error): return error.localizedDescription
        case .empty: return Localizable.fundManagersNoResults.localized
        default: return nil
        }
    }
}
