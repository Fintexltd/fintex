//
//  FundManagersViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum FundManagersState: Equatable {

    case loading
    case paging([FundManager])
    case populated([FundManager])
    case empty
    case error(Error)

    var currentFundManagers: [FundManager] {
        switch self {
        case .paging(let fundManagers): return fundManagers
        case .populated(let fundManagers): return fundManagers
        default: return []
        }
    }

    static func == (lhs: FundManagersState, rhs: FundManagersState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}

class FundManagersViewModel: BaseViewModel<HasFundManagersRepository & HasFiltersRepository> {

    let filtersData = FundsFilterManager.instance.filtersData
    let fundManagersState = BehaviorRelay<FundManagersState>(value: .loading)
    let refreshRelay = FundsFilterManager.instance.refreshRelay

    private let fundManagersResponses = BehaviorRelay<[FundManagersResponse]>(value: [])
    private let moreDataNeedRelay = FundsFilterManager.instance.moreDataNeedRelay

    let showFollowAll = PublishRelay<Bool>()

    private lazy var filters = FundsFilterManager.instance.filters

    private lazy var fundManagersRepository = dependencies.fundManagersRepository
    private lazy var filtersRepository = dependencies.filtersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        fetchFilters()

        MainFlowRxBus.fundManagersFollowingStatePublishRelay
            .subscribe(onNext: { [weak self] model in
                guard let model = model else {
                    self?.refreshRelay.accept(())
                    return
                }

                if let fundManager = self?.fundManagersState.value.currentFundManagers.first(where: { $0.id == model.fundManagerId }) {
                }
            }).disposed(by: disposeBag)
        refreshRelay
            .bind { [unowned self] in
                self.refresh()
            }
            .disposed(by: disposeBag)
    }

    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.fundManagersState.accept(.loading) })
            .withLatestFrom(fundManagersResponses)
            .filter { fundManagersResponse -> Bool in
                guard let last = fundManagersResponse.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .withLatestFrom(filters) { ($0, $1) }
            .flatMapLatest { (arg) -> Observable<[FundManagersResponse]> in
                let (fundManagersResponses, filters) = arg

                return self.fundManagersRepository.getFundManagers(fromPage: (fundManagersResponses.last?.meta.currentPage ?? 0) + 1, withFilters: filters)
                    .map { return fundManagersResponses + [$0] }
                    .do(onNext: { [weak self] fundManagersResponses in
                        self?.handleFundManagersResponses(with: fundManagersResponses)
                    })
                    .catchError { [weak self] error in
                        self?.fundManagersState.accept(.error(error))
                        return Observable<[FundManagersResponse]>.empty()
                }
            }
            .bind(to: fundManagersResponses)
            .disposed(by: disposeBag)
    }

    private func handleFundManagersResponses(with responses: [FundManagersResponse]) {
        let fundManagers = responses.flatMap { $0.data }.uniqueElements

        if fundManagers.isEmpty {
            fundManagersState.accept(.empty)
        } else if let last = responses.last, last.meta.currentPage < last.meta.lastPage {
            fundManagersState.accept(.paging(fundManagers))
        } else {
            fundManagersState.accept(.populated(fundManagers))
        }
        updateFollowAllState(with: responses)
    }

    private func updateFollowAllState(with responses: [FundManagersResponse]) {
        let isNotFollowingAll = responses.filter { $0.meta.isFollowingAll ?? false }.isEmpty
        let hasMinimalNumberOfFilters = filtersData.value.selectedFilters >= Defaults.Filter.minNumberToShowFollowAll
        let isPopulated = fundManagersState.value != .empty

//        showFollowAll.accept(isNotFollowingAll && hasMinimalNumberOfFilters && isPopulated)
    }

    private func refresh() {
        fundManagersResponses.accept([])
        moreDataNeedRelay.accept(())
    }

    private func generateRandomSeed() -> Int {
        return Int(arc4random_uniform(9999) + 1)
    }

    private func fetchFilters() {
        filtersRepository.getFundManagerPredefinedFilters()
            .subscribe(onNext: { [weak self] filters in
                guard let `self` = self else { return }
                let oldFilters = self.filters.value
                let mappedRelations = filters.map {
                    $0.with(selection: oldFilters.hasRelationFilter($0) || oldFilters.hasSortFilter($0))
                }
                self.filtersData.accept((mappedRelations, self.filters.value.selectionCount))
            }, onError: { error in printDebug(error) })
        .disposed(by: disposeBag)
    }
}

extension FundManagersViewModel {

    var reloadDriver: Driver<Int> {
        return fundManagersResponses.asDriver().map { _ in 0 }
    }

    func collectionViewNeedsMoreData() {
        moreDataNeedRelay.accept(())
    }

    func refreshDataRandomly() {
        if case SortType.defaultSortedSeed = filters.value.sortBy {
            let newFilters = filters.value.with(sortType: .defaultSortedSeed(seed: generateRandomSeed()))
            self.filters.accept(newFilters)
        }
        refreshRelay.accept(())
    }

    func toogleFollowingFundManager(_ fundManager: FundManager) {
        fundManagersRepository.toggleFollowing(ofFundManagerWithId: fundManager.id, follow: fundManager.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(onSubscribe: { self.changeFundManagerFollowState(.changing, forFundManager: fundManager) })
            .subscribe(onNext: { [weak self] _ in
                guard let `self` = self else { return }
                let newState: FollowingState = fundManager.following == .following ? .notFollowing : .following
                MainFlowRxBus.fundManagersFollowingStatePublishRelay
                    .accept(FundManagerFollowingChangeModel(fundManagerId: fundManager.id,
                                                        newFollowingState: newState))
                self.changeFundManagerFollowState(newState, forFundManager: fundManager)
            }, onError: { [weak self] error in
                self?.changeFundManagerFollowState(fundManager.following, forFundManager: fundManager)
                self?.alert.accept(AlertData(message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }

    func followAll() {
    }

    private func handleFollowingCompaniesError(message: String) {
        alert.accept(AlertData(message: message != "" ? message : Localizable.fundManagersFollowAllError.localized))
    }

    private func changeFundManagerFollowState(_ state: FollowingState, forFundManager fundManager: FundManager) {
        var fundManagers = fundManagersState.value.currentFundManagers
        let updatedFundManager = fundManager.with(followingState: state)
        if let fundManagerIndex = fundManagers.index(where: { $0.id == fundManager.id }) {
            fundManagers[fundManagerIndex] = updatedFundManager
        }

        switch fundManagersState.value {
        case .paging: fundManagersState.accept(.paging(fundManagers))
        case .populated: fundManagersState.accept(.populated(fundManagers))
        default: break
        }
    }

    func selected(fundManager: FundManager) {
        router?.push(to: .fundManagerDetails(fundManagerId: fundManager.id))
    }

    func didTapAccountIcon() {
    }

    func searchFor(fraze: String) {
        self.filters.accept(filters.value.with(searchText: fraze))
        refreshRelay.accept(())
    }

    func moveToMoreFiltersView() {
        router?.present(destination:
            .filters(filterTypes: [.fundManagerRelation, .continent, .country, .currency, .fundType, .assetClass, .activePassive, .openClose, .tradingFrequency, .managementFee, .performanceFee, .duration],
                     initialFilters: filters.value,
                     delegate: self))
    }

    func moveToAccountInfoView() {    }

    func selectedPredefinedFilter(_ filter: Filter) {
        switch filter {
        case is FundManagerRelation:
            updateRelationFilters(with: filter)
        case is SortFilter:
            updateSortFilters(with: filter)
        default: break
        }
        updateFiltersData(filters: self.filters.value)
        refreshRelay.accept(())
    }

    func fundManager(withId id: Int, didChangeFollowingState state: FollowingState) {
        if let fundManager = fundManagersState.value.currentFundManagers.first(where: { $0.id == id }) {
            changeFundManagerFollowState(state, forFundManager: fundManager)
        }
    }

    private func updateRelationFilters(with filter: Filter) {
        guard let relation = filter as? FundManagerRelation else { return }
        var relations = filters.value.relations

        if let index = relations.index(where: { $0 == relation.name.lowercased() }) {
            relations.remove(at: index)
        }
        if filter.isSelected { relations.append(filter.name.lowercased()) }
        self.filters.accept(filters.value.with(relations: relations))
    }

    private func updateSortFilters(with filter: Filter) {
        guard let sort = filter as? SortFilter else { return }
        let sortType = sort.isSelected ? sort.sortType : .defaultSortedSeed(seed: generateRandomSeed())

        self.filters.accept(filters.value.with(sortType: sortType))
    }

    private func updateFiltersData(filters: AdvancedFilters) {
        let updatedRelations = filtersData.value.filters.map {
            $0.with(selection: filters.hasRelationFilter($0) || filters.hasSortFilter($0))
        }
        self.filtersData.accept((updatedRelations, filters.selectionCount))
    }
}

extension FundManagersViewModel: FiltersDelegate {

    func didSelect(filters: AdvancedFilters) {
        self.filters.accept(filters)
        updateFiltersData(filters: filters)
        refreshRelay.accept(())
    }
}
