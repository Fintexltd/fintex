//
//  FundManagerDetailsViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 01/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import Kingfisher
import IQKeyboardManagerSwift

class FundManagerDetailsViewController: BaseViewController<FundManagerDetailsViewModel>, UIScrollViewDelegate, UINavigationControllerDelegate {

    private lazy var viewCreator = FundManagerDetailsView(parentView: self.view, pagedViewControllers: pagedViewControllers)

    private var pagerLayoutNeedsReload = false
    private var pagerDataNeedsReload = true
    private var isAnimating = false
    private var isMenuShown = true

    private var childScrollView: UIScrollView!

    var fundManagerId: Int

    lazy var pagedViewControllers: [UIViewController] = {
        return [UIViewController()]
    }()

    init(fundManagerId: Int) {
        self.fundManagerId = fundManagerId
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
        IQKeyboardManager.shared.enable = false
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        IQKeyboardManager.shared.enable = true
    }

    override func setupView() {
        self.view.backgroundColor = .primaryDark
        viewCreator.setupView()
        automaticallyAdjustsScrollViewInsets = false
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        viewCreator.updatePagedViewHeight(withNavigationBarHeight:
            (navigationController?.navigationBar.frame.height ?? 0) + Defaults.marginSmall)
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        pagerLayoutNeedsReload = true
        viewCreator.pagerView.viewControllers[viewCreator.pagerView.currentSelectedPage].viewWillTransition(to: size, with: coordinator)
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.fundManagerId = fundManagerId
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.scrollView.delegate = self
        viewCreator.pagerView.delegate = self
        navigationController?.delegate = self
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.clear]
        viewCreator.followButton.addTarget(self, action: #selector(toogleFollowing), for: .touchUpInside)
    }

    override func keyboardWillShow(withHeight height: CGFloat) {
        guard isMenuShown else {
            return
        }
        animateHeader(show: false)
    }

    override func keyboardWillHide() {
        animateHeader(show: true)
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.fundManagerData
            .ignoreNil()
            .subscribe(onNext: { [weak self] fundManagerAbout in
                guard let self = self else { return }
                self.configureHeader(with: fundManagerAbout)
                if self.pagerDataNeedsReload {
                    self.initializePages(from: fundManagerAbout.availableInformations)
                    self.updateFundManagerAboutViewController(with: fundManagerAbout)
                    self.pagerDataNeedsReload = false
                }
            }).disposed(by: disposeBag)

        viewModel.followingStateChangeAction
            .subscribe(onNext: { [weak self] state in
                guard let self = self else { return }
                MainFlowRxBus.fundManagersFollowingStatePublishRelay
                    .accept(FundManagerFollowingChangeModel(fundManagerId: self.fundManagerId, newFollowingState: state))
            }).disposed(by: disposeBag)
    }

    private func configureHeader(with fundManagerData: FundManagerAbout) {
        title = fundManagerData.name
        viewCreator.fundManagerTitle.text = fundManagerData.name

        if fundManagerData.following != .changing {
            viewCreator.followButton.setTitle(fundManagerData.following?.stateTitle, for: .normal)
        }

        if let logo = fundManagerData.logo, let logoUrl = URL(string: logo) {
            viewCreator.fundManagerLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        if let background = fundManagerData.background, let logoUrl = URL(string: background) {
            viewCreator.backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
        }

        UIView.animate(withDuration: Defaults.animationDuration) {
            self.viewCreator.followButton.alpha = fundManagerData.following == FollowingState.changing ? 0 : 1
            self.viewCreator.followLoader.alpha = fundManagerData.following != FollowingState.changing ? 0 : 1
        }
    }

    private func initializePages(from availableInformations: [FundManager.FundManagerDetailsType]) {

        func buildViewControllerForDetails(ofType type: FundManager.FundManagerDetailsType) -> UIViewController {
            switch type {
            case .aboutUs: return FundManagerAboutViewController(delegate: self)
            case .funds: return FundsViewController(fundManagerId: fundManagerId, termsAndConditionsLink: viewModel.fundManagerData.value?.termsAndConditions?.url ?? "", delegate: self)
            case .news: return PublicationsViewController(type: .fundManagerNews(fundManagerId: fundManagerId), delegate: self)
            case .events: return PublicationsViewController(type: .fundManagerEvents(fundManagerId: fundManagerId), delegate: self)
            case .documents: return FundManagerDocumentsViewController(fundManagerId: fundManagerId, delegate: self)
            case .ourTeam: return TeamViewController(teamType: .fundManager(id: fundManagerId), delegate: self)
            }
        }

        pagedViewControllers = availableInformations.sorted { $0.hashValue < $1.hashValue }.compactMap { buildViewControllerForDetails(ofType: $0) }

        let initialPageIndex = pagedViewControllers.index(where: { type(of: $0) == FundManagerAboutViewController.self }) ?? 0
        viewCreator.pagerView.viewControllers = pagedViewControllers
        viewCreator.pagerView.setInitialPage(initialPageIndex)

        viewCreator.pagerView.layoutIfNeeded()
        UIView.animate(withDuration: Defaults.animationDuration, animations: { [weak self] in
            self?.viewCreator.pagerView.alpha = 1
        })
    }

    private func updateFundManagerAboutViewController(with data: FundManagerAbout) {
        if let fundManagerAbout = viewCreator.findPagedViewController(type: FundManagerAboutViewController.self) {
            fundManagerAbout.data = data
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        viewCreator.scrollView.layoutIfNeeded()

        if pagerLayoutNeedsReload {
            pagerLayoutNeedsReload = false
            viewCreator.pagerView.reloadPagerCells()
        }
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard childScrollView.contentOffset.y < Defaults.FundManagerDetails.minOffsetToAnimateHeader else { return }
        let goingUp = scrollView.panGestureRecognizer.translation(in: scrollView).y < 0
        guard goingUp == isMenuShown else { return }
        animateHeader(show: !goingUp)
    }

    private func animateHeader(show: Bool) {
        guard !isAnimating else {
            childScrollView.contentOffset.y = 0
            return
        }
        isAnimating = true
        let headerMaxContentYOffset = viewCreator.scrollView.contentSize.height - viewCreator.scrollView.frame.height

        viewCreator.contentStackView.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(show ? 0 : headerMaxContentYOffset.negative())
        }
        UIView.animate(withDuration: Defaults.headerAnimationDuration, animations: {
            self.view.layoutIfNeeded()
            self.updateHeaderAppearance(offset: show ? 0 : headerMaxContentYOffset)
            self.childScrollView.contentOffset.y = 0
        }, completion: { completed in
            self.isAnimating = !completed
            self.isMenuShown = show
        })
    }

    private func updateHeaderAppearance(offset: CGFloat) {
        let hoverViewAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.4)
        let titleAlpha = offset / (viewCreator.basicInformationView.frame.height * 0.7)

        viewCreator.headerHoverView.alpha = hoverViewAlpha
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.accent.withAlpha(titleAlpha)]
    }

    @objc private func toogleFollowing() {
        guard let fundManager = viewModel.fundManagerData.value else {
            return
        }
        if fundManager.following == .following {
            viewModel.toogleFundManagerFollowingState()
        } else {
            let dialog = TermsAndConditionsDialogViewController(link: fundManager.termsAndConditions?.url ?? "", successHandler: { [unowned self] in
                self.viewModel.toogleFundManagerFollowingState()
            }) { }
            dialog.modalPresentationStyle = .overCurrentContext
            present(dialog, animated: false)
        }    }

    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return toVC.transitionAnimator
    }
}

extension FundManagerDetailsViewController: ReinitializableViewController {

    func reinitializeView(with id: Int) {
        pagerDataNeedsReload = true
        fundManagerId = id
        viewModel.reloadData(forFundManagerWithId: id)
    }
}

extension FundManagerDetailsViewController: PagerViewDelegate {

    func didChangeScrollView(_ scrollView: UIScrollView) {
        childScrollView = scrollView
    }
}

extension FundManagerDetailsViewController: FundManagerAboutViewControllerDelegate {

    func showAllShareprices(with data: [Symbol]) {
    }
}

extension FundManagerDetailsViewController: FundManagerDocumentsViewControllerDelegate {
    func didSelectSeeMore(forSection section: FundManagerDocumentSection) {
        viewModel.showDetails(of: section)
    }
}

extension FundManagerDetailsViewController: PagedViewControllerDelegate {

    func pagedScrollView(didScroll scrollView: UIScrollView) {
        scrollViewDidScroll(scrollView)
    }
}

extension FundManagerDetailsViewController: AssignAsShareholderViewControllerDelegate {

    func didSuccesfullyAsignAsShareholder() {
        UIView.animate(withDuration: Defaults.animationDuration) {            self.viewCreator.buttonsStackView.layoutIfNeeded()
        }
    }
}

extension FundManagerDetailsViewController: TeamViewControllerDelegate {

    func showEmployeeDetails(_ employee: Employee) {
        viewModel.show(detailsOf: employee)
    }

    func showAllEmployees(with data: EmployeesGroup) {
        viewModel.show(allEmployees: data, employeesDelegate: self)
    }
}

extension FundManagerDetailsViewController: FundsViewControllerDelegate {
    func fundsViewController(didTapFund fundId: Int) {
        viewModel.selected(fundId: fundId)
    }
    func fundsViewController(didTapMoreFilters filters: AdvancedFilters, delegate: FiltersDelegate) {
        viewModel.moveToMoreFiltersView(filters: filters, delegate: delegate)
    }
}

extension FundManagerDetailsViewController: PublicationsViewControllerDelegate {

    func didSelect(publication: Publication) {
        viewModel.show(publication: publication)
    }

    func didTapShareButton(shareUrl: URL?) {
        shareNews(url: shareUrl)
    }
}
