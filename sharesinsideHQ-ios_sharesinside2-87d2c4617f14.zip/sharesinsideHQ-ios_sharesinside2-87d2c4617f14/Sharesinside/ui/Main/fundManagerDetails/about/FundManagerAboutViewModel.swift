//
//  FundManagerAboutViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 01/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class FundManagerAboutViewModel: BaseViewModel<HasFundManagersRepository> {

    let fundManagerAboutData = BehaviorRelay<FundManagerAbout?>(value: nil)

}
