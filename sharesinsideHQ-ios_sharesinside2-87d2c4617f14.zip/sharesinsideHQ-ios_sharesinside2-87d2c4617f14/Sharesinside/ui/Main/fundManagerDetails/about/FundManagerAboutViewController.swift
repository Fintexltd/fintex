//
//  FundManagerAboutViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 01/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift
import MapKit

protocol FundManagerAboutViewControllerDelegate: SharepriceCollectionViewDelegate, PagedViewControllerDelegate {}

class FundManagerAboutViewController: BaseViewController<FundManagerAboutViewModel>, UIScrollViewDelegate {

    weak var delegate: FundManagerAboutViewControllerDelegate?

    private lazy var viewCreator = FundManagerAboutView(withParentView: self.view)

    var data: FundManagerAbout? {
        didSet {
            guard let data = data else { return }
            viewCreator.configure(with: data)
        }
    }

    init(delegate: FundManagerAboutViewControllerDelegate) {
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.fundManagerAboutTitle.localized }
        set {}
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.delegate = self
        viewCreator.scrollView.delegate = self
        viewCreator.sharepriceCollectionView.customDelegate = self
    }

    override func initializeView() {
        super.initializeView()
    }

    override func localize() {
        super.localize()
    }

    override func bindViewModel() {
        super.bindViewModel()
        viewModel.fundManagerAboutData
            .ignoreNil()
            .subscribe(onNext: { [weak self] fundManagerAbout in
                self?.data = fundManagerAbout
            }).disposed(by: disposeBag)
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension FundManagerAboutViewController: SharepriceCollectionViewDelegate {
    func showAllShareprices(with data: [Symbol]) {
        delegate?.showAllShareprices(with: data)
    }
}

extension FundManagerAboutViewController: FundManagerAboutDelegate {

    func didTouchAddress(button: AddressButton) {
        if let gpsAddress = button.address as? GPSConvertible, button.address?.type == .location {
            MKMapItem.openMaps(for: gpsAddress)
            return
        }
        guard let url = button.address?.destinationUrl else { return }
        UIApplication.shared.openIfPossible(url)
    }

    func didTouchSocialMedia(button: SocialMediaButton) {
        guard let url = URL(string: button.socialMedia?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }

    func attachmentButtonDidTouch(button: AttachmentButton) {
        guard let url = URL(string: button.attachment?.url) else { return }
        UIApplication.shared.openIfPossible(url)
    }

}
