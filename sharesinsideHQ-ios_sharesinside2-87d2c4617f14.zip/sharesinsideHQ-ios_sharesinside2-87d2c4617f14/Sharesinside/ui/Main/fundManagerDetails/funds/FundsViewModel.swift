//
//  FundsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

enum FundsState: Equatable {

    case loading
    case paging([Fund])
    case populated([Fund])
    case empty
    case error(Error)

    var currentFunds: [Fund] {
        switch self {
        case .paging(let funds): return funds
        case .populated(let funds): return funds
        default: return []
        }
    }

    static func == (lhs: FundsState, rhs: FundsState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}

class FundsViewModel: BaseViewModel<HasFundsRepository & HasFiltersRepository> {

    let filtersData = FundsFilterManager.instance.filtersData
    let fundsState = BehaviorRelay<FundsState>(value: .loading)
    let refreshRelay = FundsFilterManager.instance.refreshRelay

    var fundManagerId: Int = 0

    private let fundResponses = BehaviorRelay<[FundsResponse]>(value: [])
    private let moreDataNeedRelay = FundsFilterManager.instance.moreDataNeedRelay

    let showFollowAll = PublishRelay<Bool>()

    lazy var filters = FundsFilterManager.instance.filters

    private lazy var fundsRepository = dependencies.fundsRepository
    private lazy var filtersRepository = dependencies.filtersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()
        fetchFilters()

        MainFlowRxBus.fundFollowingStatePublishRelay
            .subscribe(onNext: { [weak self] model in
                guard let model = model else {
                    self?.refreshRelay.accept(())
                    return
                }

                if let fund = self?.fundsState.value.currentFunds.first(where: { $0.id == model.fundId }) {
                    self?.changeFundFollowState(model.newFollowingState, forFund: fund)
                }
            }).disposed(by: disposeBag)
        refreshRelay
            .bind { [unowned self] in
                self.refresh()
            }
            .disposed(by: disposeBag)
    }

    private func loadData() {
        moreDataNeedRelay
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .do(onSubscribe: { [weak self] in self?.fundsState.accept(.loading) })
            .withLatestFrom(fundResponses)
            .filter { fundResponses -> Bool in
                guard let last = fundResponses.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .withLatestFrom(filters) { ($0, $1) }
            .flatMapLatest { (arg) -> Observable<[FundsResponse]> in
                let (fundResponses, filters) = arg

                return self.fundsRepository.getFunds(fromPage: (fundResponses.last?.meta.currentPage ?? 0) + 1, fundManagerId: self.fundManagerId, withFilters: filters)
                    .map { return fundResponses + [$0] }
                    .do(onNext: { [weak self] fundsResponses in
                        self?.handleFundsResponses(with: fundsResponses)
                    })
                    .catchError { [weak self] error in
                        self?.fundsState.accept(.error(error))
                        return Observable<[FundsResponse]>.empty()
                }
            }
            .bind(to: fundResponses)
            .disposed(by: disposeBag)
    }

    private func handleFundsResponses(with responses: [FundsResponse]) {
        let funds = responses.flatMap { $0.data }.uniqueElements

        if funds.isEmpty {
            fundsState.accept(.empty)
        } else if let last = responses.last, last.meta.currentPage < last.meta.lastPage {
            fundsState.accept(.paging(funds))
        } else {
            fundsState.accept(.populated(funds))
        }
        updateFollowAllState(with: responses)
    }

    private func updateFollowAllState(with responses: [FundsResponse]) {
        let isNotFollowingAll = responses.filter { $0.meta.isFollowingAll ?? false }.isEmpty
        let hasMinimalNumberOfFilters = filtersData.value.selectedFilters >= Defaults.Filter.minNumberToShowFollowAll
        let isPopulated = fundsState.value != .empty

//        showFollowAll.accept(isNotFollowingAll && hasMinimalNumberOfFilters && isPopulated)
    }

    private func refresh() {
        fundResponses.accept([])
        moreDataNeedRelay.accept(())
    }

    private func generateRandomSeed() -> Int {
        return Int(arc4random_uniform(9999) + 1)
    }

    private func fetchFilters() {
        filtersRepository.getFundManagerPredefinedFilters()
            .subscribe(onNext: { [weak self] filters in
                guard let `self` = self else { return }
                let oldFilters = self.filters.value
                let mappedRelations = filters.map {
                    $0.with(selection: oldFilters.hasRelationFilter($0) || oldFilters.hasSortFilter($0))
                }
                self.filtersData.accept((mappedRelations, self.filters.value.selectionCount))
            }, onError: { error in printDebug(error) })
        .disposed(by: disposeBag)
    }
}

extension FundsViewModel {

    var reloadDriver: Driver<Int> {
        return fundResponses.asDriver().map { _ in 0 }
    }

    func collectionViewNeedsMoreData() {
        moreDataNeedRelay.accept(())
    }

    func refreshDataRandomly() {
        if case SortType.defaultSortedSeed = filters.value.sortBy {
            let newFilters = filters.value.with(sortType: .defaultSortedSeed(seed: generateRandomSeed()))
            self.filters.accept(newFilters)
        }
        refreshRelay.accept(())
    }

    func toogleFollowingFund(_ fund: Fund) {
        fundsRepository.toggleFollowing(ofFundWithId: fund.id, follow: fund.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(onSubscribe: { self.changeFundFollowState(.changing, forFund: fund) })
            .subscribe(onNext: { [weak self] _ in
                guard let `self` = self else { return }
                let newState: FollowingState = fund.following == .following ? .notFollowing : .following
                MainFlowRxBus.fundFollowingStatePublishRelay
                    .accept(FundFollowingChangeModel(fundId: fund.id,
                                                        newFollowingState: newState))
                self.changeFundFollowState(newState, forFund: fund)
            }, onError: { [weak self] error in
                self?.changeFundFollowState(fund.following, forFund: fund)
                self?.alert.accept(AlertData(message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }

    func followAll() {
    }

    private func handleFollowingFundsError(message: String) {
        alert.accept(AlertData(message: message != "" ? message : Localizable.fundsFollowAllError.localized))
    }

    private func changeFundFollowState(_ state: FollowingState, forFund fund: Fund) {
        var funds = fundsState.value.currentFunds
        let updatedFund = fund.with(followingState: state)
        if let fundIndex = funds.index(where: { $0.id == fund.id }) {
            funds[fundIndex] = updatedFund
        }

        switch fundsState.value {
        case .paging: fundsState.accept(.paging(funds))
        case .populated: fundsState.accept(.populated(funds))
        default: break
        }
    }

    func searchFor(fraze: String) {
        self.filters.accept(filters.value.with(searchText: fraze))
        refreshRelay.accept(())
    }

    func moveToAccountInfoView() {}

    func selectedPredefinedFilter(_ filter: Filter) {
        switch filter {
        case is FundManagerRelation:
            updateRelationFilters(with: filter)
        case is SortFilter:
            updateSortFilters(with: filter)
        default: break
        }
        updateFiltersData(filters: self.filters.value)
        refreshRelay.accept(())
    }

    func fund(withId id: Int, didChangeFollowingState state: FollowingState) {
        if let fund = fundsState.value.currentFunds.first(where: { $0.id == id }) {
            changeFundFollowState(state, forFund: fund)
        }
    }

    private func updateRelationFilters(with filter: Filter) {
        guard let relation = filter as? FundManagerRelation else { return }
        var relations = filters.value.relations

        if let index = relations.index(where: { $0 == relation.name.lowercased() }) {
            relations.remove(at: index)
        }
        if filter.isSelected { relations.append(filter.name.lowercased()) }
        self.filters.accept(filters.value.with(relations: relations))
    }

    private func updateSortFilters(with filter: Filter) {
        guard let sort = filter as? SortFilter else { return }
        let sortType = sort.isSelected ? sort.sortType : .defaultSortedSeed(seed: generateRandomSeed())

        self.filters.accept(filters.value.with(sortType: sortType))
    }

    private func updateFiltersData(filters: AdvancedFilters) {
        let updatedRelations = filtersData.value.filters.map {
            $0.with(selection: filters.hasRelationFilter($0) || filters.hasSortFilter($0))
        }
        self.filtersData.accept((updatedRelations, filters.selectionCount))
    }
}

extension FundsViewModel: FiltersDelegate {

    func didSelect(filters: AdvancedFilters) {
        self.filters.accept(filters)
        updateFiltersData(filters: filters)
        refreshRelay.accept(())
    }
}
