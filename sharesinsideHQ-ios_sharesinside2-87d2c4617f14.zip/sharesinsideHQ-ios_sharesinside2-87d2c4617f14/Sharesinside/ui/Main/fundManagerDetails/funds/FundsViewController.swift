//
//  FundsViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

protocol FundsViewControllerDelegate: PagedViewControllerDelegate {
    func fundsViewController(didTapFund fundId: Int)
    func fundsViewController(didTapMoreFilters filters: AdvancedFilters, delegate: FiltersDelegate)
}

class FundsViewController: BaseViewController<FundsViewModel>, PredefinedFiltersViewDelegate {

    private lazy var viewCreator = FundsView(withParentView: self.view)
    private var needReloadItems: Bool = false

    weak var delegate: FundsViewControllerDelegate?

    private let fundManagerId: Int
    private let termsAndConditionsLink: String

    override var title: String? {
        get { return Localizable.fundsTitle.localized }
        set {}
    }

    init(fundManagerId: Int, termsAndConditionsLink: String, delegate: FundsViewControllerDelegate?) {
        self.fundManagerId = fundManagerId
        self.termsAndConditionsLink = termsAndConditionsLink
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setupView() {
        viewCreator.setupView()
        viewCreator.navigationView.setup(in: self.navigationItem)
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.collectionView.collectionViewDelegate = self
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        bindNavigationBarItems()
        viewCreator.snackBar.delegate = self
        viewCreator.filterView.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if needReloadItems {
            needReloadItems = false
            viewCreator.collectionView.reloadSections(IndexSet(integer: 0))
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        needReloadItems = true
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }

    // MARK: Binding
    override func bindViewModel() {
        super.bindViewModel()

        viewModel.fundManagerId = fundManagerId

        viewModel.fundsState
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] state in
                    self?.endRefreshing()
                    self?.viewCreator.collectionView.state = state })
            .disposed(by: disposeBag)

        viewModel.filtersData
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] in
                self?.viewCreator.filterView.configure(with: $0.filters, andSelectedCount: $0.selectedFilters, addPrimeButton: false)
            })
            .disposed(by: disposeBag)

        viewModel.showFollowAll
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] should in
                    if should {
                        self?.viewCreator.snackBar.show(withMessage: Localizable.fundFollowAll.localized)
                    } else {
                        self?.viewCreator.snackBar.hide()
                    }
            }).disposed(by: disposeBag)
    }

    private func bindNavigationBarItems() {
        viewCreator.searchBar.rx
            .text
            .asDriver()
            .debounce(Defaults.Search.delay)
            .ignoreNil()
            .debug()
            .drive(onNext: { [weak self] text in
                self?.viewModel.searchFor(fraze: text)
            })
            .disposed(by: disposeBag)

        viewCreator.searchBar.rx
            .searchButtonClicked
            .asDriver()
            .drive(
                onNext: { [weak self] in self?.hideKeyboard() })
            .disposed(by: disposeBag)
    }

    @objc private func didSwipeForRefresh() {
        viewModel.refreshDataRandomly()
    }

    private func hideKeyboard() {
       viewCreator.navigationView.searchBar.resignFirstResponder()
    }

    private func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.refreshControl.endRefreshing()
        }
    }

    func didSelect(filter: Filter) {
        viewModel.selectedPredefinedFilter(filter)
    }

    func moreFiltersDidTouch() {
        delegate?.fundsViewController(didTapMoreFilters: viewModel.filters.value, delegate: viewModel)
    }

}

extension FundsViewController: FundsCollectionViewDelegate {
    func collectionViewNeedsMoreData() {
        viewModel.collectionViewNeedsMoreData()
    }

    func toogleFollowing(of fund: Fund) {
        if fund.following == .following {
            viewModel.toogleFollowingFund(fund)
        } else {
            let dialog = TermsAndConditionsDialogViewController(link: termsAndConditionsLink, successHandler: { [unowned self] in
                self.viewModel.toogleFollowingFund(fund)
            }) { }
            dialog.modalPresentationStyle = .overCurrentContext
            present(dialog, animated: false)
        }
    }

    func didSelect(fund: Fund) {
        delegate?.fundsViewController(didTapFund: fund.id)
    }

    func didScroll(scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension FundsViewController: SnackBarDelegate {
    func snackBarDidTouch() {
        viewModel.followAll()
    }
}
