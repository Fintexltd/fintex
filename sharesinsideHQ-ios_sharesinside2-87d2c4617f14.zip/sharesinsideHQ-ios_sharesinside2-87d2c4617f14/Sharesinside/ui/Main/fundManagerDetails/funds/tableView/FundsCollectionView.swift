//
//  FundsCollectionView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import DeepDiff

protocol FundsCollectionViewDelegate: class {
    func collectionViewNeedsMoreData()
    func toogleFollowing(of fund: Fund)
    func didSelect(fund: Fund)
    func didScroll(scrollView: UIScrollView)
}

class FundsCollectionView: UICollectionView {

    weak var collectionViewDelegate: FundsCollectionViewDelegate?

    var state: FundsState = .loading {
        willSet(newValue) {
            listChanges = diff(old: state.currentFunds, new: newValue.currentFunds)
        }
        didSet {
            if let listChanges = listChanges {
                updateCollectionView(withChanges: listChanges)
                updateBackgroundView()
            }
        }
    }

    private var itemWidth: CGFloat = 0
    private var listChanges: [Change<Fund>]?

    lazy var failureView: FailureView = {
        let view = FailureView()

        return view
    }()

    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        initialize()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }

    private func initialize() {
        registerCell(FundCollectionViewCell.self)
        registerFooterView(StateFooterView.self)
        delegate = self
        dataSource = self
    }

    override func reloadSections(_ sections: IndexSet) {
        itemWidth = 0
        super.reloadSections(sections)
    }

    private func updateCollectionView(withChanges changes: [Change<Fund>]) {
        collectionViewLayout.invalidateLayout()
        reload(changes: changes) { [weak self] _ in self?.listChanges = nil }
    }

    private func updateBackgroundView() {
        failureView.updateText(state.failureMessage)
        backgroundView = failureView
    }
}

extension FundsCollectionView: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return state.currentFunds.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: FundCollectionViewCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.fund = state.currentFunds[indexPath.row]
            cell.delegate = self
            return cell
        }

        return UICollectionViewCell()
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        collectionViewDelegate?.didScroll(scrollView: scrollView)
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == (collectionView.numberOfItems(inSection: indexPath.section) - 4) {
            collectionViewDelegate?.collectionViewNeedsMoreData()
        }
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if let stateFooter: StateFooterView = collectionView.dequeueReusableFooterView(for: indexPath) {
            stateFooter.initialize()
            return stateFooter
        }
        return UICollectionReusableView()
    }

    private func itemWidth(forSize size: CGSize) -> CGFloat {
        let multiplier: CGFloat = UIScreen.main.traitCollection.userInterfaceIdiom == .phone ? 1 : 0.5
        return (size.width) * multiplier
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionViewDelegate?.didSelect(fund: state.currentFunds[indexPath.row])
    }
}

extension FundsCollectionView: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if itemWidth == 0 { itemWidth = itemWidth(forSize: bounds.size) }

        let height: CGFloat = UIApplication.shared.statusBarOrientation.isPortrait ?
            Defaults.Fund.cellPortraitHeight : Defaults.Fund.cellHorizontalHeight

        return CGSize(width: itemWidth, height: height)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: state.heightForFooter)
    }
}

extension FundsCollectionView: FundCellDelegate {

    func collectionCell(_ cell: FundCollectionViewCell, didToogleFollowFund fund: Fund) {
        collectionViewDelegate?.toogleFollowing(of: fund)
    }

    func collectionCell(_ cell: FundCollectionViewCell, didTapUserGroupsFor fund: Fund) {
        collectionViewDelegate?.didSelect(fund: fund)
    }
}

extension FundsState {

    var heightForFooter: CGFloat {
        switch self {
        case .loading, .paging: return Defaults.Fund.footerHeight
        default: return 0
        }
    }

    var failureMessage: String? {
        switch self {
        case .error(let error): return error.localizedDescription
        case .empty: return Localizable.fundsNoResults.localized
        default: return nil
        }
    }
}
