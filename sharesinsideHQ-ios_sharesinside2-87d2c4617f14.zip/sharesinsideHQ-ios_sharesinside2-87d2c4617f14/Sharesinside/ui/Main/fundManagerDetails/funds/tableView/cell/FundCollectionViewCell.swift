//
//  FundCollectionViewCell.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

protocol FundCellDelegate: class {
    func collectionCell(_ cell: FundCollectionViewCell, didToogleFollowFund fund: Fund)
    func collectionCell(_ cell: FundCollectionViewCell, didTapUserGroupsFor fund: Fund)
}

class FundCollectionViewCell: UICollectionViewCell {

    weak var delegate: FundCellDelegate?

    private lazy var viewCreator = FundCellViewCreator(withParentView: self.contentView)

    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    var fund: Fund? {
        didSet {
            if let fund = fund {
                configure(with: fund)
            }
        }
    }

    private func configure(with fund: Fund) {
        viewCreator.fundTitle.text = fund.name

        var fundInfoPrefix = ""
        if fund.isActive {
            fundInfoPrefix = Localizable.fundActive.localized
        }
        if fund.isPassive {
            fundInfoPrefix = Localizable.fundPassive.localized
        }
        var fundInfoPostfix = ""
        if let fundType = fund.fundTypes.first {
            fundInfoPostfix = fundType.name
        }

        var fundInfo = fundInfoPrefix
        if !fundInfoPostfix.isEmpty {
            fundInfo += ", " + fundInfoPostfix
        }
        if fundInfo.isEmpty {
            fundInfo = fundInfoPostfix
        }

        viewCreator.managementFee.text = "\(Localizable.fundHeaderManagementFee.localized) \(fund.managementFee ?? "")%"
        viewCreator.performanceFee.text = "\(Localizable.fundHeaderPerformanceFee.localized) \(fund.performanceFee ?? "")%"
        var sharePriceText = "N/A"
        if let mainStockPrice = fund.mainStockPrice,
            !mainStockPrice.isEmpty {
            sharePriceText = mainStockPrice
        }
        viewCreator.sharePrice.text = "\(Localizable.fundSharePrice.localized)\(sharePriceText)"

        viewCreator.fundInfo.text = fundInfo
        let periodPostfix = fund.duration == 1 ? Localizable.year.localized : Localizable.years.localized
        var fundDuration = "\(Localizable.fundDuration.localized) \(fund.duration) \(periodPostfix)"
        if let openClosed = fund.openClosed {
            fundDuration += ", \(openClosed.capitalized)"
        }
        viewCreator.fundDuration.text = fundDuration
        viewCreator.followButton.isHidden = fund.following == .changing
        viewCreator.followButton.setTitle(fund.following.stateTitle, for: .normal)
        viewCreator.followButton.style = fund.following.buttonStyle
        viewCreator.followLoader.isHidden = fund.following != .changing

        if let logo = fund.logo, let logoUrl = URL(string: logo) {
            viewCreator.fundLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
        }

        let orientation = UIApplication.shared.statusBarOrientation
        viewCreator.contentStackView.axis = orientation.isPortrait ? .vertical : .horizontal
        viewCreator.contentStackView.distribution = orientation.isPortrait ? .fillProportionally : .fill
        viewCreator.fundInfo.textAlignment = .left
        viewCreator.fundDuration.textAlignment = .left
        viewCreator.managementFee.textAlignment = .left
        viewCreator.performanceFee.textAlignment = .left
        viewCreator.sharePrice.textAlignment = .left
        viewCreator.embeddedDetailsStackView.setContentHuggingPriority(orientation.isPortrait ? .required : .defaultHigh, for: .horizontal)
        viewCreator.detailsStackView.setContentHuggingPriority(orientation.isPortrait ? .required : .defaultHigh, for: .horizontal)
        viewCreator.followButton.addTarget(self, action: #selector(followDidTouch), for: .touchUpInside)
        viewCreator.userGroups.configure(withUserGroups: fund.fundsCellGroups.compactMap({ $0.title }))
    }

    private func initializeView() {
        viewCreator.setupView()
    }

    @objc private func followDidTouch() {
        guard let fund = fund else { return }
        delegate?.collectionCell(self, didToogleFollowFund: fund)
    }

    @objc private func userGroupsDidTouch() {
        guard let fund = fund else { return }
        delegate?.collectionCell(self, didTapUserGroupsFor: fund)
    }
}
