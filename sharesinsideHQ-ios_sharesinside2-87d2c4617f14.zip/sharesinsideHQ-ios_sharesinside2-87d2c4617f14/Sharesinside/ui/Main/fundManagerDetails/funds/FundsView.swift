//
//  FundsView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 02/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit

class FundsView: BaseViewCreator {

    lazy var navigationView: SearchableNavigationView = {
        return SearchableNavigationView()
    }()

    lazy var collectionView: FundsCollectionView = {
        return UICollectionView.makeCustomCollectionView(type: FundsCollectionView.self)
    }()

    lazy var filterView: PredefinedFiltersView = {
        return PredefinedFiltersView()
    }()

    lazy var searchBar: SISearchBar = {
        let searchBar = SISearchBar()
        return searchBar
    }()

    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary

        return refreshControl
    }()

    let searchBarBackground: UIView = {
        let view = UIView()
        view.backgroundColor = .primaryDark
        return view
    }()

    let snackBar: SnackBarView = SnackBarView()

    override func setupProperties() {
        collectionView.addSubview(refreshControl)
    }

    override func setupViewHierarchy() {
        searchBarBackground.addSubview(searchBar)
        [searchBarBackground, filterView, collectionView, snackBar].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        searchBar.snp.makeConstraints { make in
            make.top.leading.equalToSuperview().offset(Defaults.marginTiny)
            make.bottom.trailing.equalToSuperview().offset(-Defaults.marginTiny)
        }

        searchBarBackground.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
        }

        filterView.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom)
            make.leading.trailing.equalToSuperview()
        }

        collectionView.snp.makeConstraints { make in
            make.top.equalTo(filterView.snp.bottom).priority(.highest)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
}
