//
//  FundManagerDetailsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 01/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

class FundManagerDetailsViewModel: BaseViewModel<HasFundManagersRepository> {

    var fundManagerId: Int?
    let fundManagerData = BehaviorRelay<FundManagerAbout?>(value: nil)
    let followingStateChangeAction = PublishRelay<FollowingState>()

    lazy var fundManagersRepository = dependencies.fundManagersRepository

    override func onViewDidLoad() {
        super.onViewDidLoad()
        getFundManagerAboutData()
    }

    func reloadData(forFundManagerWithId id: Int) {
        fundManagerId = id
        getFundManagerAboutData()
    }

    private func getFundManagerAboutData() {
        guard let fundManagerId = fundManagerId else {
            alert.accept(AlertData(message: Localizable.fundManagerDetailsFetchError.localized,
                                   onPositiveTap: { self.router?.pop() }))
            return
        }
        fundManagersRepository.getFundManagerAbout(fundManagerId: fundManagerId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] fundManagerAbout in
                    self?.fundManagerData.accept(fundManagerAbout) },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent) })
            .disposed(by: disposeBag)
    }

    func selected(fundId: Int) {
        router?.push(to: .fundDetails(fundId: fundId))
    }

    func moveToMoreFiltersView(filters: AdvancedFilters, delegate: FiltersDelegate) {
        router?.present(destination:
            .filters(filterTypes: [.fundManagerRelation, .continent, .country, .currency, .fundType, .assetClass, .activePassive, .openClose, .tradingFrequency, .managementFee, .performanceFee, .duration],
                     initialFilters: filters,
                     delegate: delegate))
    }

    func show(publication: Publication) {
        switch publication.type {
        case .event: router?.push(to: .eventDetails(eventId: publication.watchlistableId))
        case .news: router?.push(to: .newsDetails(newsId: publication.watchlistableId))
        case .project: router?.push(to: .projectDetails(projectId: publication.watchlistableId))
        }
    }

    func showDetails(of section: FundManagerDocumentSection) {
        guard let fundManagerId = fundManagerId else {
            return
        }
        router?.push(to: .fundManagerDocumentsDetails(fundManagerId: fundManagerId, section: section))
    }

    func show(allEmployees employeesGroup: EmployeesGroup, employeesDelegate: EmployeesDelegate) {
        router?.push(to: .allEmployees(employeesGroup: employeesGroup, delegate: employeesDelegate))
    }

    func show(detailsOf employee: Employee) {
        router?.push(to: .employeeDetails(employee: employee, employerData: fundManagerData.value))
    }
}

extension FundManagerDetailsViewModel {

    func toogleFundManagerFollowingState() {
        guard let fundManager = fundManagerData.value else { return }
        fundManagersRepository.toggleFollowing(ofFundManagerWithId: fundManager.id, follow: fundManager.following == .notFollowing)
            .observeOn(MainScheduler.instance)
            .do(
                onSubscribe: { self.changeFundManagerFollowState(.changing, forFundManager: fundManager) })
            .subscribe(
                onNext: { [weak self] _ in
                    self?.changeFundManagerFollowState(
                        fundManager.following == .following ? .notFollowing : .following, forFundManager: fundManager) },
                onError: { [weak self] error in
                    self?.changeFundManagerFollowState(fundManager.following ?? .notFollowing, forFundManager: fundManager)
                    self?.alert.accept(AlertData(message: error.localizedDescription))})
            .disposed(by: disposeBag)
    }

    private func changeFundManagerFollowState(_ state: FollowingState, forFundManager fundManager: FundManagerAbout) {
        let updatedFundManager = fundManager.with(followingState: state)
        followingStateChangeAction.accept(state)
        fundManagerData.accept(updatedFundManager)
    }
}
