//
//  FundManagerDocumentsCellView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

class FundManagerDocumentsCellView: BaseViewCreator {

    var didTapCell: (() -> Void)?

    lazy var labelStackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [titleLabel, dateLabelContainer])
        stackView.axis = .vertical
        stackView.spacing = Defaults.marginSmallest
        return stackView
    }()

    lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey,
                                          withFontSize: Defaults.TextSize.normal)
        label.textAlignment = .natural
        return label
    }()

    let dateLabelContainer = UIView()

    lazy var publishLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.medium)
        label.textAlignment = .natural
        label.text = "\(Localizable.fundManagerDocumentsPublished.localized): "
        label.setContentPriority(huggingPriority: .defaultHigh, huggingAxis: .horizontal)
        return label
    }()

    lazy var dateLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark,
                                          withFontSize: Defaults.TextSize.medium,
                                          fontWeight: .bold)
        label.textAlignment = .natural
        return label
    }()

    lazy var attachmentImageView: UIImageView = {
        let image = UIImageView(image: #imageLiteral(resourceName: "IconAttachement")).layoutable()
        image.contentMode = .scaleAspectFit
        image.tintColor = .primary
        return image
    }()

    lazy var tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTap))

    required init(withParentView parent: UIView) {
        super.init(withParentView: parent)
        parent.addGestureRecognizer(tapRecognizer)
    }

    override func setupViewHierarchy() {
        [attachmentImageView, labelStackView].forEach { parentView.addSubview($0) }
        [publishLabel, dateLabel].forEach { dateLabelContainer.addSubview($0) }
    }

    override func setupConstraints() {
        attachmentImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.top.equalTo(labelStackView.snp.top)
            make.bottom.equalTo(labelStackView.snp.bottom)
            make.width.equalTo(attachmentImageView.snp.height)
            make.height.equalTo(Defaults.Filter.closeButtonHeight)
        }

        labelStackView.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.leading.equalTo(attachmentImageView.snp.trailing).offset(Defaults.marginTremendous)
            make.trailing.equalToSuperview()
        }

        publishLabel.snp.makeConstraints { make in
            make.leading.bottom.top.equalToSuperview()
        }
        
        dateLabel.snp.makeConstraints { make in
            make.leading.equalTo(publishLabel.snp.trailing)
            make.top.bottom.trailing.equalToSuperview()
        }
    }

    @objc private func didTap() {
        didTapCell?()
    }
}
