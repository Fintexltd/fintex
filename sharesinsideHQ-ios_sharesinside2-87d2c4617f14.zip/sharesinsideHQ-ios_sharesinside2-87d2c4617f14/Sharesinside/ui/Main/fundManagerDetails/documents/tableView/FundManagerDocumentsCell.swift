//
//  FundManagerDocumentsCell.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

class FundManagerDocumentsCell: UITableViewCell {

    private lazy var viewCreator = FundManagerDocumentsCellView(withParentView: self.contentView)

    var didTap: (() -> Void)? {
        didSet {
            viewCreator.didTapCell = didTap
        }
    }

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    var document: FundManagerDocument? {
        didSet {
            guard let document = document else { return }
            configure(with: document)
        }
    }

    private func configure(with document: FundManagerDocument) {
        viewCreator.titleLabel.text = document.title
        let dateString = Date(timeIntervalSince1970: document.timestamp).toString(withFromat: .appDateFormat)
        viewCreator.dateLabel.text = dateString
    }

    private func initializeView() {
        viewCreator.setupView()
        backgroundColor = .white
        selectionStyle = .none
    }
}
