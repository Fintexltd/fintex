//
//  FundManagerDocumentsTableView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

protocol FundManagerDocumentsTableViewDelegate: class, PagedViewControllerDelegate {
    func didSelect(document: FundManagerDocument, inSection section: FundManagerDocumentSection)
    func didSelectSeeMore(forSection section: FundManagerDocumentSection)
}

class FundManagerDocumentsTableView: UITableView {

    weak var customDelegate: FundManagerDocumentsTableViewDelegate?

    var sections: [FundManagerDocumentSection] = [] {
        didSet {
            reloadData()
        }
    }

    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        backgroundColor = .background

        delegate = self
        dataSource = self
        registerCell(FundManagerDocumentsCell.self)
        registerHeaderFooter(LabelledHeaderView.self)
        registerHeaderFooter(SeeMoreTableViewFooter.self)
        separatorStyle = .none

        rowHeight = UITableView.automaticDimension
        estimatedRowHeight = Defaults.Filter.rowHeight

        sectionFooterHeight = UITableView.automaticDimension
        estimatedSectionFooterHeight = Defaults.Filter.headerHeight

        sectionHeaderHeight = UITableView.automaticDimension
        estimatedSectionHeaderHeight = Defaults.Filter.headerHeight
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension FundManagerDocumentsTableView: UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = sections[indexPath.section]
        let document = section.data[indexPath.row]
        guard let cell: FundManagerDocumentsCell = dequeueReusableCell(for: indexPath) else {
            return UITableViewCell()
        }
        cell.document = document
        cell.didTap = { [unowned self] in
            self.customDelegate?.didSelect(document: document, inSection: section)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let header: LabelledHeaderView = tableView.dequeueReusableHeaderFooter() else {
            return nil
        }
        header.title = sections[section].name
        return header
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let documentSection = sections[section]

        guard let footer: SeeMoreTableViewFooter = tableView.dequeueReusableHeaderFooter(),
            documentSection.data.count > 3 else {
            return nil
        }

        footer.isButtonVisible = true
        footer.delegate = self
        footer.section = section
        return footer
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        let documentSection = sections[section]
        return documentSection.data.count > 3 ? Defaults.Filter.footerLargeHeight : 0
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        customDelegate?.pagedScrollView(didScroll: scrollView)
    }
}

extension FundManagerDocumentsTableView: UITableViewDelegate {}

extension FundManagerDocumentsTableView: SeeMoreFooterDelegate {
    func seeMoreDidTouch(inSection section: Int) {
        customDelegate?.didSelectSeeMore(forSection: sections[section])
    }
}
