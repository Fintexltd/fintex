//
//  FundManagerDocumentsDetailsTableView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import DeepDiff

protocol FundManagerDocumentsDetailsTableViewDelegate: class {
    func didSelect(document: FundManagerDocument)
    func tableViewNeedsMoreData()
}

class FundManagerDocumentsDetailsTableView: UITableView {

    weak var customDelegate: FundManagerDocumentsDetailsTableViewDelegate?

    var documentsState: FundManagerDocumentsDetailsState = .loading {
        willSet(newValue) {
            listChanges = diff(old: documentsState.currentDocuments, new: newValue.currentDocuments)
        }
        didSet {
            if let listChanges = listChanges {
                updateCollectionView(withChanges: listChanges)
                updateBackgroundView()
            }
        }
    }

    private var listChanges: [Change<FundManagerDocument>]?

    lazy var failureView: FailureView = {
        let view = FailureView()

        return view
    }()

    override init(frame: CGRect, style: UITableView.Style) {
        super.init(frame: frame, style: style)
        backgroundColor = .background

        delegate = self
        dataSource = self
        registerCell(FundManagerDocumentsCell.self)
        registerHeaderFooter(StateTableViewFooter.self)
        separatorStyle = .none

        rowHeight = UITableView.automaticDimension
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func updateCollectionView(withChanges changes: [Change<FundManagerDocument>]) {
        reload(changes: changes) { [weak self] _ in self?.listChanges = nil }
    }

    private func updateBackgroundView() {
        failureView.updateText(documentsState.failureMessage)
        backgroundView = failureView
    }
}

extension FundManagerDocumentsDetailsTableView: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return documentsState.currentDocuments.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let document = documentsState.currentDocuments[indexPath.row]
        guard let cell: FundManagerDocumentsCell = dequeueReusableCell(for: indexPath) else {
            return UITableViewCell()
        }
        cell.document = document
        cell.didTap = { [unowned self] in
            self.customDelegate?.didSelect(document: document)
        }
        return cell
    }

    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == (tableView.numberOfRows(inSection: indexPath.section) - 4) {
            customDelegate?.tableViewNeedsMoreData()
        }
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if let stateFooter: StateTableViewFooter = tableView.dequeueReusableHeaderFooterView(withIdentifier: StateTableViewFooter.className) as? StateTableViewFooter {
            stateFooter.initialize()
            stateFooter.contentView.backgroundColor = .white
            return stateFooter
        }
        return UICollectionReusableView()
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return documentsState.heightForFooter
    }
}

extension FundManagerDocumentsDetailsTableView: UITableViewDelegate {}

extension FundManagerDocumentsDetailsState {

    var heightForFooter: CGFloat {
        switch self {
        case .loading, .paging: return Defaults.Fund.footerHeight
        default: return 0
        }
    }

    var failureMessage: String? {
        switch self {
        case .error(let error): return error.localizedDescription
        case .empty: return Localizable.fundsNoResults.localized
        default: return nil
        }
    }
}
