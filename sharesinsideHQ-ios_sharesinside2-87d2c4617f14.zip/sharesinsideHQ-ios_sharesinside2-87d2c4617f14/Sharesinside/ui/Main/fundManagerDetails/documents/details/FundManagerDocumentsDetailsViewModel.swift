//
//  FundManagerDocumentsDetailsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

enum FundManagerDocumentsDetailsState: Equatable {

    case loading
    case paging([FundManagerDocument])
    case populated([FundManagerDocument])
    case empty
    case error(Error)

    var currentDocuments: [FundManagerDocument] {
        switch self {
        case .paging(let documents): return documents
        case .populated(let documents): return documents
        default: return []
        }
    }

    static func == (lhs: FundManagerDocumentsDetailsState, rhs: FundManagerDocumentsDetailsState) -> Bool {
        switch (lhs, rhs) {
        case (.loading, .loading),
             (.paging, .paging),
             (.populated, .populated),
             (.empty, .empty),
             (.error, .error): return true
        default: return false
        }
    }
}


final class FundManagerDocumentsDetailsViewModel: BaseViewModel<HasDocumentsService> {

    var fundManagerId: Int = 0

    var sectionId: Int = 0

    let documentsState = BehaviorRelay<FundManagerDocumentsDetailsState>(value: .loading)

    let refreshRelay = FundsFilterManager.instance.refreshRelay

    private let moreDataNeedRelay = PublishRelay<Void>()

    private lazy var documentsService = dependencies.documentsService

    var documents: Observable<[FundManagerDocument]> {
        sectionsPublisher.map { $0.flatMap { $0.data } }
    }

    private let sectionsPublisher = BehaviorRelay<[FundManagerDocumentsDetails]>(value: [])

    override func onViewDidLoad() {
        super.onViewDidLoad()
        loadData()

        refreshRelay
            .bind { [unowned self] in
                self.refresh()
            }
            .disposed(by: disposeBag)
    }

    private func loadData() {
        moreDataNeedRelay
            .do(onSubscribe: { [weak self] in self?.documentsState.accept(.loading) })
            .withLatestFrom(sectionsPublisher)
            .filter { sections -> Bool in
                guard let last = sections.last else { return true }
                return last.meta.currentPage < last.meta.lastPage
            }
            .flatMapLatest { [unowned self] sections -> Observable<[FundManagerDocumentsDetails]> in
                return self.documentsService.getDocumentsDetails(
                    fundManagerId: self.fundManagerId,
                    sectionId: self.sectionId,
                    page: (sections.last?.meta.currentPage ?? 0) + 1
                )
                    .map { return sections + [$0] }
                    .do(onNext: { [weak self] sections in
                        self?.handleSections(with: sections)
                    })
                    .catchError { [weak self] error in
                        self?.documentsState.accept(.error(error))
                        return Observable<[FundManagerDocumentsDetails]>.empty()
                    }
            }
            .observeOn(MainScheduler.instance)
            .bind(to: sectionsPublisher)
            .disposed(by: disposeBag)
    }

    private func handleSections(with sections: [FundManagerDocumentsDetails]) {
        let documents = sections.flatMap { $0.data }

        if documents.isEmpty {
            documentsState.accept(.empty)
        } else if let last = sections.last, last.meta.currentPage < last.meta.lastPage {
            documentsState.accept(.paging(documents))
        } else {
            documentsState.accept(.populated(documents))
        }
    }

    private func refresh() {
        sectionsPublisher.accept([])
        moreDataNeedRelay.accept(())
    }

    func loadMore() {
        moreDataNeedRelay.accept(())
    }
}
