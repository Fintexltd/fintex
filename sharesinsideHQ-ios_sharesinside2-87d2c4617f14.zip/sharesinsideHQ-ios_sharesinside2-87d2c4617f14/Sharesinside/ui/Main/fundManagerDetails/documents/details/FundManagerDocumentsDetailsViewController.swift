//
//  FundManagerDocumentsDetailsViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

class FundManagerDocumentsDetailsViewController: BaseViewController<FundManagerDocumentsDetailsViewModel> {

    private lazy var viewCreator = FundManagerDocumentsDetailsView(withParentView: self.view)

    private let fundManagerId: Int

    private let section: FundManagerDocumentSection

    init(fundManagerId: Int, section: FundManagerDocumentSection) {
        self.fundManagerId = fundManagerId
        self.section = section
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.fundManagerId = fundManagerId
        viewModel.sectionId = section.id
    }

    override func setupView() {
        automaticallyAdjustsScrollViewInsets = false
        viewCreator.setupView()
        viewCreator.tableView.customDelegate = self
        navigationController?.setupNavigationBar(withStyle: .dark)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        viewCreator.refreshControl.addTarget(self, action: #selector(didSwipeForRefresh), for: .valueChanged)
        navigationItem.title = section.name
    }

    override func bindRxLifecycle() {
        self.rx.firstTimeViewDidAppear
            .subscribe(
                onSuccess: { [weak self] in
                    guard let `self` = self else { return}
                    self.viewModel.loadMore()})
            .disposed(by: disposeBag)
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.documentsState
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] state in
                    self?.endRefreshing()
                    self?.viewCreator.tableView.documentsState = state })
            .disposed(by: disposeBag)
    }

    private func endRefreshing() {
        if viewCreator.refreshControl.isRefreshing {
            viewCreator.refreshControl.endRefreshing()
        }
    }

    @objc private func didSwipeForRefresh() {
        viewModel.refreshRelay.accept(())
    }
}

extension FundManagerDocumentsDetailsViewController: FundManagerDocumentsDetailsTableViewDelegate {

    func tableViewNeedsMoreData() {
        viewModel.loadMore()
    }

    func didSelect(document: FundManagerDocument) {
        guard let url = document.file.destinationUrl else {
            return
        }
        UIApplication.shared.open(url)
    }
}
