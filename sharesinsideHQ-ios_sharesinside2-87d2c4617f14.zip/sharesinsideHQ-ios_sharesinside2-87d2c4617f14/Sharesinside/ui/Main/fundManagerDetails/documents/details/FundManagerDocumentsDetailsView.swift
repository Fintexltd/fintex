//
//  FundManagerDocumentsDetailsView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

class FundManagerDocumentsDetailsView: BaseViewCreator {

    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .primary

        return refreshControl
    }()

    lazy var tableView: FundManagerDocumentsDetailsTableView = {
        let tableView = FundManagerDocumentsDetailsTableView()
        tableView.backgroundColor = .white
        tableView.separatorColor = .clear
        return tableView
    }()

    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
        tableView.addSubview(refreshControl)
    }

    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
