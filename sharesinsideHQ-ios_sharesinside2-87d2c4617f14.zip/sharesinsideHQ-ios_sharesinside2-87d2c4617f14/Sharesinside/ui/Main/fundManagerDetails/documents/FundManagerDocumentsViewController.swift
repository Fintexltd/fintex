//
//  FundManagerDocumentsViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import RxSwift

protocol FundManagerDocumentsViewControllerDelegate: PagedViewControllerDelegate {
    func didSelectSeeMore(forSection section: FundManagerDocumentSection)
}

class FundManagerDocumentsViewController: BaseViewController<FundManagerDocumentsViewModel> {

    weak var delegate: FundManagerDocumentsViewControllerDelegate?
    private lazy var viewCreator = FundManagerDocumentsView(withParentView: self.view)

    let fundManagerId: Int

    init(fundManagerId: Int, delegate: FundManagerDocumentsViewControllerDelegate?) {
        self.fundManagerId = fundManagerId
        self.delegate = delegate
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override var title: String? {
        get { return Localizable.fundManagerDocumentsTitle.localized }
        set {}
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.fundManagerId = fundManagerId
    }

    override func setupView() {
        automaticallyAdjustsScrollViewInsets = false
        viewCreator.setupView()
        viewCreator.tableView.customDelegate = self
    }

    override func bindRxLifecycle() {
        super.bindRxLifecycle()

        self.rx.firstTimeViewDidAppear
            .subscribe(
                onSuccess: { [weak self] in
                    guard let `self` = self else { return}
                    self.viewModel.getDocuments()})
            .disposed(by: disposeBag)
    }

    override func bindViewModel() {
        super.bindViewModel()
        viewModel.sections
            .bind { [unowned self] sections in
                self.viewCreator.configure(with: sections)
            }
            .disposed(by: disposeBag)
    }
}

extension FundManagerDocumentsViewController: FundManagerDocumentsTableViewDelegate {
    func didSelect(document: FundManagerDocument, inSection section: FundManagerDocumentSection) {
        guard let url = document.file.destinationUrl else {
            return
        }
        UIApplication.shared.open(url)
    }

    func didSelectSeeMore(forSection section: FundManagerDocumentSection) {
        delegate?.didSelectSeeMore(forSection: section)
    }

    func pagedScrollView(didScroll scrollView: UIScrollView) {
        delegate?.pagedScrollView(didScroll: scrollView)
    }
}
