//
//  FundManagerDocumentsView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

class FundManagerDocumentsView: BaseViewCreator {

    lazy var tableView: FundManagerDocumentsTableView = {
        let tableView = FundManagerDocumentsTableView()
        tableView.backgroundColor = .white
        tableView.separatorColor = .clear
        return tableView
    }()

    override func setupViewHierarchy() {
        parentView.addSubview(tableView)
    }

    override func setupConstraints() {
        tableView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    func configure(with data: [FundManagerDocumentSection]) {
        tableView.sections = data
    }
}
