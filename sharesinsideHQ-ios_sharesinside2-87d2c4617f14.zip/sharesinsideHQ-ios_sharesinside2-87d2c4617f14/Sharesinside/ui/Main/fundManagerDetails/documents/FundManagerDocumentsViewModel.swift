//
//  FundManagerDocumentsViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 21/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

final class FundManagerDocumentsViewModel: BaseViewModel<HasDocumentsService> {

    var fundManagerId: Int?

    var sections: Observable<[FundManagerDocumentSection]> {
        sectionsPublisher.asObservable()
    }

    private lazy var documentsService = dependencies.documentsService

    private let sectionsPublisher = BehaviorRelay<[FundManagerDocumentSection]>(value: [])

    func getDocuments() {
        guard let fundManagerId = fundManagerId else {
            alert.accept(AlertData(message: Localizable.fundDetailsFetchError.localized,
                                   onPositiveTap: { self.router?.pop() }))
            return
        }
        documentsService.getDocuments(fundManagerId: fundManagerId)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] sections in
                    self?.sectionsPublisher.accept(sections)
                },
                onError: { [weak self] error in
                    self?.router?.push(to: .failure(message: error.localizedDescription), animated: true, routeFlag: .popCurrent) })
            .disposed(by: disposeBag)
    }
}
