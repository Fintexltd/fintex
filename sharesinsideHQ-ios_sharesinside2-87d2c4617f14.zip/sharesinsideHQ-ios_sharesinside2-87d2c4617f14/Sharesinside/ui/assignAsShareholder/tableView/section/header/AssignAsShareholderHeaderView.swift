//
//  AssignAsShareholderSectionHeader.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 04.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class AssignAsShareholderHeaderView: BaseView {
    
    private lazy var gradient: CAGradientLayer = gradientView
        .applyGradient(colors: [
            UIColor.primaryDark.withAlphaComponent(0.5).cgColor,
            UIColor.primaryDark.withAlphaComponent(0.9).cgColor,
            UIColor.primaryDark.cgColor
            ], locations: [0.0, 0.4, 0.6])
    
    private lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.text = Localizable.companyAssignAsShareholder.localized
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)
        return label
    }()
    
    // MARK: Company basic information
    private lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .vertical)
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .horizontal)
        
        return imageView
    }()
    
    private lazy var gradientView: UIView = {
        return UIView().layoutable()
    }()
    
    private lazy var companyLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .clear
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        return imageView
    }()
    
    private lazy var companyTitle: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.text = "--"
        label.textAlignment = .left
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)

        return label
    }()
    
    private lazy var companyGroup: UILabel = {
        let label = UILabelFactory.styled(withFontSize: Defaults.TextSize.small)
        label.text = "--"
        label.textAlignment = .left
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)

        return label
    }()
    
    private lazy var companyDataContainer = UIView().layoutable()

    // MARK: Basic information StackView
    private lazy var contentStackView = UIStackView.make(
        axis: .vertical,
        with: [
            titleLabel,
            companyDataContainer.embedInView()
        ],
        spacing: Defaults.marginBig)
    
    // MARK: Header hover view
    private lazy var headerHoverView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .primaryDark
        view.alpha = 0
        
        return view
    }()
    
    // MARK: Lifecycle
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        gradient.frame = gradientView.frame
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        gradient.frame = gradientView.frame
    }
    
    // Initialization
    override func initializeView() {
        clipsToBounds = true
        backgroundColor = .primary
        [backgroundImage, gradientView, contentStackView, headerHoverView].forEach { addSubview($0) }
        [companyLogo, companyTitle, companyGroup].forEach { companyDataContainer.addSubview($0) }
        
        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().inset(Defaults.Shareholder.headerTopMargin).priority(.highest)
        }
        
        companyLogo.snp.makeConstraints { make in
            make.top.leading.equalToSuperview()
            make.height.equalTo(Defaults.Company.logoSize)
            make.width.equalTo(companyLogo.snp.height)
        }
        
        companyTitle.snp.makeConstraints { make in
            make.leading.equalTo(companyLogo.snp.trailing).offset(Defaults.marginNormal)
            make.trailing.equalToSuperview()
            make.top.equalToSuperview()
        }
        
        companyGroup.snp.makeConstraints { make in
            make.leading.equalTo(companyLogo.snp.trailing).offset(Defaults.marginNormal)
            make.trailing.equalToSuperview()
            make.top.equalTo(companyTitle.snp.bottom).offset(Defaults.marginSmall).priority(.highest)
            make.bottom.equalToSuperview().inset(Defaults.Shareholder.headerBottomMargin)
        }
        
        companyDataContainer.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.greaterThanOrEqualToSuperview()
            make.trailing.lessThanOrEqualToSuperview()
            make.centerX.equalToSuperview()
        }
        
        backgroundImage.snp.makeConstraints { make in
            make.height.equalToSuperview()
            make.width.equalToSuperview()
            make.center.equalToSuperview()
        }
        
        gradientView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        headerHoverView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        snp.makeConstraints { make in
            make.bottom.equalTo(contentStackView.snp.bottom)
        }
    }
    
    // MARK: public methods
    
    var companyAbout: CompanyAbout? {
        didSet {
            if let companyAbout = companyAbout {
                companyTitle.text = companyAbout.name
                companyGroup.text = companyAbout.industry?.name
                
                if let logo = companyAbout.logo, let logoUrl = URL.forQuery(using: logo) {
                    companyLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
                }
                
                if let background = companyAbout.background, let logoUrl = URL(string: background) {
                    backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
                }
            }
        }
    }
    
    var hoverAlpha: CGFloat = 0 {
        didSet {
            headerHoverView.alpha = hoverAlpha
        }
    }
    
    func setTitle(_ title: String?) {
        self.titleLabel.text = title
    }
}
