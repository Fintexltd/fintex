//
//  TitleAuthSectionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class DescriptionSectionView: BaseAuthSectionView {
    
    // MARK: Views
    
    private lazy var descriptionLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey, withFontSize: Defaults.TextSize.tiny)
        label.textAlignment = .left
        return label
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    // Initialization
    
    override func initializeView() {
        contentView.backgroundColor = .accent
        [descriptionLabel, dividerView].forEach { addSubview($0) }
        
        dividerView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
        
        descriptionLabel.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().offset(Defaults.marginNormal).priority(.highest)
            make.bottom.equalTo(dividerView.snp.top).offset(Defaults.marginNormal.negative())
        }
    }
    
    var sectionModel: DescriptionSectionModel? {
        didSet {
            if let model = sectionModel {
                descriptionLabel.text = model.description
            }
        }
    }
}
