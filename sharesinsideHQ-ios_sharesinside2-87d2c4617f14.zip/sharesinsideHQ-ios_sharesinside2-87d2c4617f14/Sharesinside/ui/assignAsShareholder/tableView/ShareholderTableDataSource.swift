//
//  AuthTableDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol ShareholderTableDataSourceDelegate: class {
    func tableFormDataChanged()
    func tableViewDidScroll(offsetY: CGFloat)
    func showTermsAndConditions()
}

class ShareholderTableDataSource: NSObject {
    
    let tableView: UITableView
    
    weak var delegate: ShareholderTableDataSourceDelegate?

    var formSections: [AuthSectionModel] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    init(with tableView: UITableView) {
        self.tableView = tableView
        super.init()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.registerHeaderFooter(TitleAuthSectionView.self)
        self.tableView.registerHeaderFooter(InputAuthSectionView.self)
        self.tableView.registerHeaderFooter(SearchCountrySectionView.self)
        self.tableView.registerHeaderFooter(DescriptionSectionView.self)
        self.tableView.registerHeaderFooter(TermsAuthSectionView.self)
        self.tableView.registerCell(CountryCell.self)
        self.tableView.registerCell(ErrorMessageCell.self)
        self.tableView.registerCell(ListStateCell.self)
        
        self.tableView.estimatedRowHeight = Defaults.Auth.authSectionHeight
        self.tableView.estimatedSectionHeaderHeight = Defaults.Auth.authSectionHeight
    }
    
    func reload(section: Int) {
        if formSections.indices.contains(section) {
            var sectionModel = formSections[section]
            let value = sectionModel.value
            sectionModel.value = value
            reloadTableViewSection(sectionNumber: section, numberOfElements: sectionModel.rowCount)
        }
    }
    
    func reloadSectionHeader(section: Int) {
        tableView.reloadSections(IndexSet(integer: section), with: .automatic)
    }
    
    fileprivate func reloadTableViewSection(sectionNumber: Int, numberOfElements: Int) {
        let numberOfVisibleRows = tableView.numberOfRows(inSection: sectionNumber)
        let rowsDifference = numberOfElements - numberOfVisibleRows
        
        var indexPaths = [IndexPath]()
        if rowsDifference > 0 {
            for index in numberOfVisibleRows ..< numberOfElements {
                indexPaths.append(IndexPath(row: index, section: sectionNumber))
            }
            tableView.insertRows(at: indexPaths, with: .top)
        } else if rowsDifference < 0 {
            for index in numberOfElements ..< numberOfVisibleRows {
                indexPaths.append(IndexPath(row: index, section: sectionNumber))
            }
            tableView.deleteRows(at: indexPaths, with: .top)
        }
        
        indexPaths.removeAll()
        for index in 0 ..< numberOfElements {
            indexPaths.append(IndexPath(row: index, section: sectionNumber))
        }
        
        if !indexPaths.isEmpty {
            tableView.reloadRows(at: indexPaths, with: .none)
        }
    }
}

extension ShareholderTableDataSource: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return formSections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return formSections[section].rowCount
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = formSections[indexPath.section]

        switch section.sectionType {
        case .input:
            if let section = section as? InputAuthSectionModel,
                let cell: ErrorMessageCell = tableView.dequeueReusableCell(for: indexPath) {
                cell.configureWith(section.inputType.errorMessage ?? "")
                return cell
            }
        case .searchCountry:
            return prepareCountryCell(for: tableView, andIndexPath: indexPath)
        default:
            return UITableViewCell()
        }

        return UITableViewCell()
    }
    
    private func prepareCountryCell(for tableView: UITableView, andIndexPath indexPath: IndexPath) -> UITableViewCell {
        guard let section = formSections[indexPath.section] as? SearchCountrySectionModel else {
            return UITableViewCell()
        }
        
        if let cell: ListStateCell = tableView.dequeueReusableCell(for: indexPath), section.loadingCountries {
            cell.configure(withState: .loading)
            return cell
        }
        
        if let cell: ListStateCell = tableView.dequeueReusableCell(for: indexPath), section.noCountriesFound {
            cell.configure(withState: .noResults)
            return cell
        }
        
        if let cell: CountryCell = tableView.dequeueReusableCell(for: indexPath) {
            let country = section.filteredCountries[indexPath.row]
            cell.configureWith(countryTitle: country.countryName,
                               searchedText: section.value)
            
            return cell
        }
        return UITableViewCell()
    }
}

extension ShareholderTableDataSource: UITableViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.tableViewDidScroll(offsetY: scrollView.contentOffset.y)
        if scrollView.contentOffset.y == 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1)) {
                scrollView.setContentOffset(.zero, animated: true)
            }
        }
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch formSections[section].sectionType {
        case .title, .description: return UITableView.automaticDimension
        default: return Defaults.Auth.authSectionHeight
        }
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionModel = formSections[section]
        switch sectionModel.sectionType {
        case .input:
            if let sectionModel = sectionModel as? InputAuthSectionModel,
                let header: InputAuthSectionView = tableView.dequeueReusableHeaderFooter() {
                let isLastCell = section == formSections.count - 1
                header.tag = section
                header.sectionModel = sectionModel
                header.delegate = self
                header.dividerPadding = isLastCell ? 0 : Defaults.marginNormal
                return header
            }
        case .terms:
            if let sectionModel = sectionModel as? TermsAuthSectionModel,
                let header: TermsAuthSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.sectionModel = sectionModel
                header.delegate = self
                return header
            }
        case .searchCountry:
            if let sectionModel = sectionModel as? SearchCountrySectionModel,
                let header: SearchCountrySectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.searchSectionModel = sectionModel
                header.delegate = self
                let isLastCell = section == formSections.count - 1
                header.dividerPadding = isLastCell ? 0 : Defaults.marginNormal
                return header
            }
        case .description:
            if let sectionModel = sectionModel as? DescriptionSectionModel,
                let header: DescriptionSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.sectionModel = sectionModel
                return header
            }
        default: return nil
        }
        return nil
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let searchSection = tableView.headerView(forSection: indexPath.section) as? SearchCountrySectionView {
            searchSection.selectedCountry(searchSection.searchSectionModel?.filteredCountries[indexPath.row])
            reload(section: indexPath.section)
            delegate?.tableFormDataChanged()
        }
    }
}

extension ShareholderTableDataSource: AuthInputSectionDelegate {
    
    func inputSection(_ section: InputAuthSectionView, didChangeInputValue newValue: String?) {
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
    }
}

extension ShareholderTableDataSource: TermsAuthSectionDelegate {

    func showTermsAndConditions() {
        delegate?.showTermsAndConditions()
    }

    func termsAcceptationChanged(accepted: Bool) {
        delegate?.tableFormDataChanged()
    }
}

extension ShareholderTableDataSource: SearchCountrySectionDelegate {
    func searchSection(_ section: SearchCountrySectionView, didChangeSearchValue newValue: String?) {
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
    }
    
    func searchSectionNeedUpdate(_ section: SearchCountrySectionView) {
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
    }
}
