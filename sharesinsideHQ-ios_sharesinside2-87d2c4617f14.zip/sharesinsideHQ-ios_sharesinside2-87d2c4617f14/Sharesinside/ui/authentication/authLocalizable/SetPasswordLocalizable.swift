//
//  SetPasswordLocalizable.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class SetPasswordLocalizable: AuthLocalizable {
    
    var pageTitle: String { return "" }
    
    var sectionTitle: String? { return  Localizable.authSetPassword.localized }
    
    var sectionSubtitle: String?
    
    var mainButtonTitle: String { return Localizable.save.localized.uppercased()}
    
    var secondaryButtonTitle: String?
}
