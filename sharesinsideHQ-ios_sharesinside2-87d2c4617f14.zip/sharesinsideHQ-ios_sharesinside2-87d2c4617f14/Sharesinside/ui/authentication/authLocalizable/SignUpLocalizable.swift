//
//  SignUpLocalizable.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class SignUpLocalizable: AuthLocalizable {

    var pageTitle: String { return Localizable.authRegister.localized }
    
    var sectionTitle: String? { return nil }

    var sectionSubtitle: String? { return nil }

    var mainButtonTitle: String { return Localizable.next.localized }

    var secondaryButtonTitle: String? { return nil }

}
