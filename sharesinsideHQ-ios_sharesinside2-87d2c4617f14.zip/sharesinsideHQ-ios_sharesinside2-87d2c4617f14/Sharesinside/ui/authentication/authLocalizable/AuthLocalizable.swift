//
//  AuthLocalizable.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

protocol AuthLocalizable {
    var pageTitle: String { get }
    var sectionTitle: String? { get }
    var sectionSubtitle: String? { get }
    var mainButtonTitle: String { get }
    var secondaryButtonTitle: String? { get }
}
