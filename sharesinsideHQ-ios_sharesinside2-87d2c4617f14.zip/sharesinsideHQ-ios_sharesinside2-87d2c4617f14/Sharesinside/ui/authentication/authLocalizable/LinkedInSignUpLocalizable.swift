//
//  LinkedInSignUp.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class LinkedInSignUpLocalizable: AuthLocalizable {

    var pageTitle: String { return Localizable.authOneMoreStep.localized }

    var sectionTitle: String? { return "" }

    var sectionSubtitle: String? { return Localizable.authReview.localized }

    var mainButtonTitle: String { return Localizable.next.localized }

    var secondaryButtonTitle: String? { return nil }

}
