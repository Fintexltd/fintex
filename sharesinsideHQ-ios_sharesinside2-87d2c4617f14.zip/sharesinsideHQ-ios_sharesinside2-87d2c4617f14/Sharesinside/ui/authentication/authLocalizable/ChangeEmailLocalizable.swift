//
//  ChangeEmailLocalizable.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 23.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class ChangeEmailLocalizable: AuthLocalizable {
    
    var pageTitle: String { return "" }
    
    var sectionTitle: String? { return  Localizable.authChangeEmail.localized }
    
    var sectionSubtitle: String?
    
    var mainButtonTitle: String { return Localizable.save.localized.uppercased()}
    
    var secondaryButtonTitle: String?
}
