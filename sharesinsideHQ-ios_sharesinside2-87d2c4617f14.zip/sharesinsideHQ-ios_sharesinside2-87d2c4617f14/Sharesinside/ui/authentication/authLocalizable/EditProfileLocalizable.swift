//
//  EditProfileLocalizable.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 22.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class EditProfileLocalizable: AuthLocalizable {
    var pageTitle: String { return ""}
    
    var sectionTitle: String? { return  Localizable.authUserSettings.localized }
    
    var sectionSubtitle: String?
    
    var mainButtonTitle: String { return "" }
    
    var secondaryButtonTitle: String?
}
