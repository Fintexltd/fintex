//
//  LoginLocalizable.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class LoginLocalizable: AuthLocalizable {

    var pageTitle: String { return Localizable.authLogin.localized }

    var sectionTitle: String? { return nil }

    var sectionSubtitle: String? { return nil }

    var mainButtonTitle: String { return Localizable.authLogin.localized }

    var secondaryButtonTitle: String? { return Localizable.authForgotPasswordTitle.localized.uppercased() }

}
