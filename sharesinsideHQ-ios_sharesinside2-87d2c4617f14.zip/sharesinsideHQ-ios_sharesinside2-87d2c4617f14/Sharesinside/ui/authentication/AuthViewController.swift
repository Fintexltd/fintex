//
//  AuthViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

enum AuthPage {
    case signUp
    case linkedInSignUp
    case login
    case resetPassword
    case editProfile
    case changePassword
    case setPassword
    case changeEmail
    case changeUsername
    
    var localizable: AuthLocalizable {
        switch self {
        case .signUp: return SignUpLocalizable()
        case .linkedInSignUp: return LinkedInSignUpLocalizable()
        case .login: return LoginLocalizable()
        case .resetPassword: return ResetPasswordLocalizable()
        case .editProfile: return EditProfileLocalizable()
        case .changePassword: return ChangePasswordLocalizable()
        case .changeUsername: return ChangeUsernameLocalizable()
        case .changeEmail: return ChangeEmailLocalizable()
        case .setPassword: return SetPasswordLocalizable()
        }
    }
}

class AuthViewController: BaseViewController<AuthViewModel> {

    private lazy var viewCreator = AuthView(withParentView: self.view)
    
    private let authPage: AuthPage
    
    private lazy var authTableManager: AuthTableDataSource = {
        let dataSource = AuthTableDataSource(with: viewCreator.tableView)
        dataSource.delegate = self
        return dataSource
    }()
    
    private let linkedinUserData: LinkedInRegisterUserData?
    
    init(authPage: AuthPage, linkedinUserData: LinkedInRegisterUserData? = nil) {
        self.authPage = authPage
        self.linkedinUserData = linkedinUserData
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .dark)
    }

    override func setupView() {
        viewCreator.setupView()
        viewCreator.bottomMainButton.isHidden = authPage == .editProfile
    }
    
    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.pageType = authPage
        viewModel.linkedinUserData = linkedinUserData
    }

    override func localize() {
        let localizableAuthPage = viewModel.pageType.localizable
        viewCreator.bottomMainButton.setTitle(localizableAuthPage.mainButtonTitle.uppercased(), for: .normal)
        viewCreator.bottomSecondaryButton.isHidden = localizableAuthPage.secondaryButtonTitle == nil
        viewCreator.bottomSecondaryButton.setTitle(localizableAuthPage.secondaryButtonTitle, for: .normal)
        title = localizableAuthPage.pageTitle
    }

    override func initializeView() {
        super.initializeView()
        viewCreator.bottomMainButton.addTarget(self, action: #selector(bottomMainButtonDidTouch), for: .touchUpInside)
        viewCreator.bottomSecondaryButton.addTarget(self, action: #selector(secondaryButtonDidTouch), for: .touchUpInside)
    }

    override func bindViewModel() {
        super.bindViewModel()
        
        viewModel.sectionsData.asDriver()
            .drive(onNext: { [weak self] sectionsData in
                self?.authTableManager.authSections = sectionsData
            }).disposed(by: disposeBag)
        
        viewModel.sectionUpdateNeed
            .subscribe(onNext: { [weak self] section in
                self?.authTableManager.reload(section: section)
            }).disposed(by: disposeBag)
        
        viewModel.sectionHeaderUpdateNeed
            .subscribe(onNext: { [weak self] section in
                self?.authTableManager.reloadSectionHeader(section: section)
            }).disposed(by: disposeBag)
        
        viewModel.dataValid
            .subscribe(onNext: { [weak self] dataValid in
                self?.viewCreator.bottomMainButton.isEnabled = dataValid
            }).disposed(by: disposeBag)
        
        viewModel.linkedInConnectionStatus
            .subscribe(onNext: { [weak self] _ in
                self?.authTableManager.tableView.reloadData() })
            .disposed(by: disposeBag)
    }
    
    @objc private func bottomMainButtonDidTouch() {
        viewModel.proceedButtonDidTouch()
    }
    
    @objc private func secondaryButtonDidTouch() {
        viewModel.secondaryButtonDidTouch()
    }
}

extension AuthViewController: AuthTableDataDelegate {
   
    func didTapLinkedInConnectSection(_ sectionView: LinkedInConnectSectionView) {
        guard let model = sectionView.sectionModel else { return }
        viewModel.connectOrDisconnectWithLinkedIn(with: model)
    }
    
    func didSelectNavigateCell(with model: NavigateAuthSectionModel) {
        guard model.type != .privacyPolicy else {
            router.present(destination: model.type.destination)
            return
        } 
        router.push(to: model.type.destination, animated: true, forcePush: true, routeFlag: .none)
    }
    
    func showTermsAndConditions() {
        router.present(destination: .documents(type: .termsAndConditions))
    }
    
    func tableFormDataChanged() {
        viewModel.formDataChanged()
    }
}
