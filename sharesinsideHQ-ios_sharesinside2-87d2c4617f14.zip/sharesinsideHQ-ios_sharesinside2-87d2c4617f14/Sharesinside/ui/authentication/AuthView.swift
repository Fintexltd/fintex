//
//  AuthView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AuthView: BaseViewCreator {

    lazy var tableView: UITableView = {
        let tableView = UITableView().layoutable()
        tableView.separatorStyle = .none
        return tableView
    }()
    
    lazy var bottomMainButton: SharesinsideButton = {
        let button = SharesinsideButton(type: .system)
        button.style = SharesinsideButton.Style.primary
        button.updateTitleMargins(left: Defaults.marginBig, right: Defaults.marginBig)
        return button
    }()
    
    lazy var bottomSecondaryButton: SharesinsideButton = {
        let button = SharesinsideButton(type: .system)
        button.style = SharesinsideButton.ButtonStyle(background: .clear, foreground: .grey, border: .clear)
        return button
    }()

    override func setupViewHierarchy() {
        [tableView, bottomSecondaryButton, bottomMainButton].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        bottomMainButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.bottom.equalBottomSafeArea(parentView).inset(Defaults.marginNormal)
        }
        
        bottomSecondaryButton.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.bottom.equalBottomSafeArea(parentView).inset(Defaults.marginNormal)
            make.trailing.lessThanOrEqualTo(bottomMainButton.snp.leading).inset(Defaults.marginNormal)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalTo(bottomMainButton.snp.top).inset(Defaults.marginNormal.negative())
        }
    }
}
