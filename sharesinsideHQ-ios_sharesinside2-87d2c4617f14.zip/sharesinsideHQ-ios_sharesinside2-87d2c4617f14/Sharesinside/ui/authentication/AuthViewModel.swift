//
//  AuthViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class AuthViewModel: BaseViewModel<HasCountriesRepository & HasAuthManager & HasProfileManager> {
    
    typealias LinkedInSignUpData = (pageType: AuthPage, userData: LinkedInRegisterUserData)
    
    let sectionsData = BehaviorRelay<[AuthSectionModel]>(value: [])
    let sectionUpdateNeed = PublishSubject<Int>()
    let sectionHeaderUpdateNeed = PublishSubject<Int>()
    let linkedInConnectionStatus = PublishSubject<LinkedInConnectionStatus>()
    let dataValid = BehaviorRelay<Bool>(value: false)
    
    var pageType: AuthPage = .login
    var linkedinUserData: LinkedInRegisterUserData?
    
    private lazy var countriesRepo = dependencies.countriesRepository
    private lazy var authManager = dependencies.authManager
    private lazy var profileSerice = dependencies.profileManager
    
    private var countriesLoading: Bool = false
    
    override func onViewDidLoad() {
        super.onViewDidLoad()
        fetchCountriesIfNeeded()
    }
    
    override func onViewWillAppear() {
        super.onViewWillAppear()
        sectionsData.accept(prepareSectionData(forScreen: pageType))
    }
    
    func formDataChanged() {
        dataValid.accept(isDataValid)
        fetchCountriesIfNeeded()
    }
    
    func proceedButtonDidTouch() {
        switch pageType {
        case .signUp: signUpUser()
        case .linkedInSignUp: signUpUserWithLinkedIn()
        case .login: loginUser()
        case .resetPassword: resetPassword()
        case .editProfile: return
        case .changePassword: changePassword()
        case .setPassword: setPassword()
        case .changeEmail: changeEmail()
        case .changeUsername: changeUsername()
        }
    }
    
    func secondaryButtonDidTouch() {
        if pageType == .login {
            router?.push(to: .auth(pageType: .resetPassword, linkedinUserData: nil), forcePush: true)
        }
    }
    
    // Private methods
    private var isDataValid: Bool {
        for section in sectionsData.value where !section.isValid {
            return false
        }
        return true
    }
    
    private func prepareSectionData(forScreen screen: AuthPage) -> [AuthSectionModel] {
        switch screen {
        case .signUp:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .email),
                InputAuthSectionModel(inputType: .username),
                InputAuthSectionModel(inputType: .password),
                InputAuthSectionModel(inputType: .repeatPassword),
                SearchCountrySectionModel(),
                TermsAuthSectionModel()
            ]
        case .linkedInSignUp:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .email, value: linkedinUserData?.email ?? ""),
                InputAuthSectionModel(inputType: .username),
                SearchCountrySectionModel(selectedCountry: linkedinUserData?.country),
                TermsAuthSectionModel()
            ]
        case .login:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .usernameOrEmail),
                InputAuthSectionModel(inputType: .password)
            ]
        case .resetPassword:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .email)
            ]
        case .editProfile:
            return properEditProfileSections(screen: screen)
        case .changePassword:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .oldPassword),
                InputAuthSectionModel(inputType: .newPassword),
                InputAuthSectionModel(inputType: .repeatPassword)
            ]
        case .changeUsername:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .newUsername, value: AppUser.current?.username ?? "")
            ]
        case .changeEmail:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .newEmail, value: AppUser.current?.email ?? "")
            ]
        case .setPassword:
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                InputAuthSectionModel(inputType: .newPassword),
                InputAuthSectionModel(inputType: .repeatPassword)
            ]
        }
    }
    
    private func properEditProfileSections(screen: AuthPage) -> [AuthSectionModel] {
        let connectedManually = AppUser.current?.isManualAccountConnected == true
        let linkedInStatus = AppUser.current?.linkedInConnectionStatus ?? .disconnected
        if connectedManually {
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                NavigateAuthSectionModel(type: .changeEmail),
                NavigateAuthSectionModel(type: .changeUsername),
                NavigateAuthSectionModel(type: .changePassword),
                NavigateAuthSectionModel(type: .privacyPolicy),
                MarginSectionModel(),
                LinkedInConnectSectionModel(status: linkedInStatus)
            ]
        } else {
            return [
                TitleAuthSectionModel(title: screen.localizable.sectionTitle, subtitle: screen.localizable.sectionSubtitle),
                NavigateAuthSectionModel(type: .changeEmail),
                NavigateAuthSectionModel(type: .changeUsername),
                NavigateAuthSectionModel(type: .privacyPolicy),
                MarginSectionModel(),
                NavigateAuthSectionModel(type: .setPassword),
                MarginSectionModel(),
                LinkedInConnectSectionModel(status: linkedInStatus)
            ]
        }
    }

    private func signUpUser() {
        guard let email = userEmail, !email.isEmpty,
            let username = userName, !username.isEmpty,
            let password = userPassword, !password.isEmpty,
            let repeatedPassword = userRepeatedPassword, !repeatedPassword.isEmpty,
            let country = userSelectedCountry, userTermsAccepted else {
                alert.accept(AlertData(message: Localizable.error.localized))
                return
        }
        
        authManager.signUpUser(name: username,
                               email: email,
                               password: password,
                               passwordConfiramtion: repeatedPassword,
                               countryId: country.id,
                               acceptTerms: true)
            .applyLoader(withMessage: nil, andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] _ in
                    self?.router?.push(to: .information(informationType: .confirmRegistration), routeFlag: .popCurrent)
                },
                onError: { [weak self] error in self?.handleApiError(error) })
            .disposed(by: disposeBag)
    }
    
    private func signUpUserWithLinkedIn() {
        guard let email = userEmail, !email.isEmpty,
            let username = userName, !username.isEmpty,
            let country = userSelectedCountry,
            let registerToken = linkedinUserData?.registrationKey, userTermsAccepted else {
                alert.accept(AlertData(message: Localizable.error.localized))
                return
        }
        
        authManager.signUpUserWithLinkedin(name: username, email: email, countryId: country.id,
                                           registrationKey: registerToken, acceptTerms: true)
            .applyLoader(withMessage: nil, andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] _ in
                    self?.router?.push(to: .information(informationType: .confirmRegistrationViaLinkedIn), routeFlag: .popCurrent)
                },
                onError: { [weak self] error in self?.handleApiError(error) })
            .disposed(by: disposeBag)
    }
    
    private func loginUser() {
        guard let password = userPassword, !password.isEmpty,
            let username = userNameOrEmail, !username.isEmpty else {
                alert.accept(AlertData(message: Localizable.error.localized))
                return
        }
        
        authManager.logInUser(username: username, password: password)
            .applyLoader(withMessage: nil, andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] _ in
                    if Config.isDemoAccount {
                        Config.Notifications.areAllowed = false
                        self?.router?.replace(with: .main)
                    } else {
                        self?.router?.push(to: .information(informationType: .notifications))
                    }
                }, onError: { [weak self] error in self?.handleInvalidCredentialsError(error) })
            .disposed(by: disposeBag)
    }

    private func resetPassword() {
        guard let email = userEmail else { return }
        authManager.resetPassword(for: email)
            .applyLoader(withMessage: nil, andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] _ in
                    self?.router?.push(to: .information(informationType: .passwordReset))
                },
                onError: { [weak self] error in
                    let errorMessage = error.localizedDescription != "" ? error.localizedDescription : Localizable.authResetPasswordError.localized
                    self?.alert.accept(AlertData(
                        message: errorMessage,
                        onPositiveTap: { self?.router?.pop(toDestination: .welcome) }))
                })
            .disposed(by: disposeBag)
    }
    
    private func changeUsername() {
        guard let newUsername = inputSection(forType: .newUsername)?.value else { return }
        
        profileSerice.changeUsername(with: newUsername)
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] in
                    self?.alert.accept(AlertData(message: $0.message))
                    AppUser.fetchCurrentUserDetails()
                },
                onError: { [weak self] in
                        self?.handleApiError($0)})
            .disposed(by: disposeBag)
    }
    
    private func changeEmail() {
        guard let newEmail = inputSection(forType: .newEmail)?.value else { return }
        
        profileSerice.changeEmail(with: newEmail)
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] in
                    self?.alert.accept(AlertData(message: $0.message))
                },
                onError: { [weak self] in
                    self?.handleApiError($0)
            })
            .disposed(by: disposeBag)
    }
    
    private func changePassword() {
        guard
            let oldPassword = inputSection(forType: .oldPassword)?.value,
            let newPassword = inputSection(forType: .newPassword)?.value,
            let repeatedPassword = inputSection(forType: .repeatPassword)?.value
        else { return }
        
        guard oldPassword != newPassword else {
            updateInputSection(errorMessage: Localizable.authUniqueNewPasswordError.localized, type: .newPassword)
            updateInputSection(type: .repeatPassword)
            return
        }
        profileSerice.changePassword(oldPassword: oldPassword, newPassword: newPassword, repeatedPassword: repeatedPassword)
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self] authData in
                    Config.accessToken = authData.accessToken
                    Config.refreshToken = authData.refreshToken ?? ""
                    
                    if let message = authData.message {
                        self?.alert.accept(AlertData(message: message))
                    }
                    AppUser.fetchCurrentUserDetails()
                },
                onError: { [weak self] error in
                    self?.handleApiError(error)
            })
            .disposed(by: disposeBag)
    }
    
    private func setPassword() {
        guard
            let newPassword = inputSection(forType: .newPassword)?.value,
            let repeatedPassword = inputSection(forType: .repeatPassword)?.value
        else { return }
        profileSerice.setPassword(newPassword: newPassword, repeatedPassword: repeatedPassword)
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self]_ in self?.updateUserWithPopAction() },
                onError: { [weak self] error in self?.handleApiError(error)})
            .disposed(by: disposeBag)
    }
    
    private func fetchCountriesIfNeeded() {
        guard let countrySection = countrySection(), countrySection.countries == nil, !countriesLoading else { return }
        countriesRepo.getCountries()
            .do(onSubscribe: { [unowned self] in
                self.countriesLoading = true
                },
                onDispose: { [weak self] in
                    self?.countriesLoading = false
            })
            .subscribe(onSuccess: { [weak self] countries in
                if let index = self?.sectionsData.value.index(where: { $0 is SearchCountrySectionModel }),
                    let searchCountrySectionModel = self?.sectionsData.value[index] as? SearchCountrySectionModel {
                    searchCountrySectionModel.countries = countries
                    self?.sectionUpdateNeed.onNext(index)
                }
            }) { error in printDebug(error) }
            .disposed(by: disposeBag)
    }
    
    private func updateUserWithPopAction() {
        AppUser.fetchCurrentUserDetails()
        AppUser.userUpdated
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] in self?.router?.pop()
            }).disposed(by: disposeBag)
    }
}

extension AuthViewModel {

    private var userEmail: String? { return inputSection(forType: .email)?.value }

    private var userName: String? { return inputSection(forType: .username)?.value }
    
    private var userNameOrEmail: String? { return inputSection(forType: .usernameOrEmail)?.value }

    private var userPassword: String? { return inputSection(forType: .password)?.value }

    private var userRepeatedPassword: String? { return inputSection(forType: .repeatPassword)?.value }

    private var userSelectedCountry: Country? {
        return (sectionsData.value.first(where: { $0 is SearchCountrySectionModel }) as? SearchCountrySectionModel)?.selectedCountry
    }

    private var userTermsAccepted: Bool {
        return (sectionsData.value.first(where: { $0 is TermsAuthSectionModel }) as? TermsAuthSectionModel)?.termsAccepted ?? false
    }

    private func inputSection(forType type: InputAuthSectionModel.InputSectionType) -> InputAuthSectionModel? {
        return (sectionsData.value.filter({ $0.sectionType == .input }) as? [InputAuthSectionModel])?.first(where: { $0.inputType == type })
    }
    private func navigateSection(forType type: NavigateAuthSectionModel.NavigateSectionType) -> NavigateAuthSectionModel? {
        return (sectionsData.value.filter { $0.sectionType == .input } as? [NavigateAuthSectionModel])?.first(where: { $0.type == type })
    }
    
    private func linkedInConnectSection() -> LinkedInConnectSectionModel? {
        return sectionsData.value.compactMap { $0 as? LinkedInConnectSectionModel }.first
    }
    
    private func indexOfLinkedInConnectSection() -> Int? {
        return sectionsData.value.firstIndex(where: {$0 is LinkedInConnectSectionModel})
    }
    
    private func indexOfInputSection(forType type: InputAuthSectionModel.InputSectionType) -> Int? {
        return sectionsData.value.index(where: { ($0 as? InputAuthSectionModel)?.inputType == type })
    }
    
    private func countrySection() -> SearchCountrySectionModel? {
        return sectionsData.value.first(where: { $0.sectionType == .searchCountry }) as? SearchCountrySectionModel
    }
}

extension AuthViewModel {
    
    private func handleApiError(_ error: Error) {
        guard let response = error as? ErrorResponse else { return }
        
        if let emailError = response.errors?["email"], let message = emailError.first {
            updateInputSection(errorMessage: message, type: .email)
        }
        if let usernameError = response.errors?["name"], let message = usernameError.first {
            updateInputSection(errorMessage: message, type: .username)
        }
        if let oldPasswordError = response.errors?["old_password"], let message = oldPasswordError.first {
            updateInputSection(errorMessage: message, type: .oldPassword)
        }
        if let newUsernameError = response.errors?["new_username"], let message = newUsernameError.first {
            updateInputSection(errorMessage: message, type: .newUsername)
        }
        if let linkedInConnectionError = response.errors?["linkedin_in"] ?? response.errors?["linkedin_id"], let message = linkedInConnectionError.first {
            alert.accept(AlertData(message: message))
            updateLinkedInConnectionSection()
            return
        }
        if response.errors?["new_email"] != nil {
            updateInputSection(type: .newEmail)
        }
        alert.accept(AlertData(message: response.message))
    }
    
    private func handleInvalidCredentialsError(_ error: Error) {
        guard let section = inputSection(forType: .password), let index = indexOfInputSection(forType: .password) else { return }
        
        section.forceClean = true
        sectionHeaderUpdateNeed.onNext(index)
        alert.accept(AlertData(message: error.localizedDescription))
    }
    
    private func updateInputSection(errorMessage message: String? = nil, type: InputAuthSectionModel.InputSectionType) {
        guard let section = inputSection(forType: type), let index = indexOfInputSection(forType: type) else { return }
        
        section.apiErrorOccurred = true
        sectionHeaderUpdateNeed.onNext(index)
        section.apiErrorOccurred.toggle()
        
        if let alertMessage = message {
            alert.accept(AlertData(message: alertMessage))
        }
    }
}

extension AuthViewModel: LinkedInAuthViewControllerDelegate {
    
    func didSuccessfullyConnectedWithLinkedIn(token: String) {
        connectWithLinkedIn(token: token)
    }
    
    func didFailToConnectWithLinkedIn() {
        updateLinkedInConnectionSection(status: .disconnected)
    }
    
    func connectOrDisconnectWithLinkedIn(with model: LinkedInConnectSectionModel) {
        switch model.status {
        case .disconnected:
            router?.push(to: .linkedInAuth(page: .connect, delegate: self))
        case .connected:
            askAboutDisconnectionWithLinkedIn()
        default: return
        }
    }
    
    private func askAboutDisconnectionWithLinkedIn() {
        alert.accept(AlertData(
            message: Localizable.linkedinAuthenticationDisconnectAlert.localized,
            title: nil,
            positiveButtonTitle: Localizable.yes,
            cancelButtonTitle: Localizable.cancel,
            onPositiveTap: { [weak self] in
                self?.disconnectFromLinkedIn()
            },
            onCancelTap: nil))
    }
    
    private func disconnectFromLinkedIn() {
        profileSerice.disconnectWithLinkedIn()
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self]_ in
                    self?.updateLinkedInConnectionSection(status: .disconnected)
                }, onError: { [weak self] error in
                    self?.handleApiError(error)
                })
            .disposed(by: disposeBag)
    }
    
    private func connectWithLinkedIn(token: String) {
        profileSerice.connectWithLinkedIn(token: token)
            .observeOn(MainScheduler.instance)
            .applyLoader(andBehaviorRelay: loading)
            .subscribe(
                onNext: { [weak self]_ in
                    self?.updateLinkedInConnectionSection(status: .connected)
                }, onError: { [weak self]error in
                    self?.handleApiError(error)
            })
            .disposed(by: disposeBag)
    }
    
    private func updateLinkedInConnectionSection(status: LinkedInConnectionStatus? = nil) {
        AppUser.fetchCurrentUserDetails()
        AppUser.userUpdated
            .observeOn(MainScheduler.instance)
            .subscribe(
                onNext: { [weak self] in
                    self?.linkedInConnectSection()?.status = status ?? AppUser.current?.linkedInConnectionStatus ?? .disconnected
                    if let index = self?.indexOfLinkedInConnectSection() {
                        self?.sectionHeaderUpdateNeed.onNext(index)
                    }
            }).disposed(by: disposeBag)
    }
}
