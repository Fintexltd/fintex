//
//  CountryCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CountryCell: UITableViewCell {

    // MARK: Views
    private lazy var countryLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.textAlignment = .left

        return label
    }()

    // MARK: Initialization

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    func configureWith(countryTitle: String, searchedText: String) {
        let boldRange = (countryTitle.uppercased() as NSString).range(of: searchedText.uppercased())

        let attrs = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .bold)]

        let attributedString = NSMutableAttributedString(string: countryTitle)
        attributedString.addAttributes(attrs, range: boldRange)
        countryLabel.attributedText = attributedString
    }
    
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        backgroundColor = highlighted ? UIColor.primary.withAlpha(0.5) : .background
    }
}

extension CountryCell {

    private func initializeView() {
        [countryLabel].forEach { addSubview($0) }
        backgroundColor = .background
        selectionStyle = .none

        countryLabel.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
    }
}
