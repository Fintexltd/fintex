//
//  ErrorMessageCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class ErrorMessageCell: UITableViewCell {

    // MARK: Views
    private lazy var messageLabel: UILabel = {
        let label = UILabelFactory.styled(
            textColor: .accent,
            withFontSize: Defaults.TextSize.small)
            .layoutable()
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()

    // MARK: Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    func configureWith(_ message: String) {
        messageLabel.text = message
    }
}

extension ErrorMessageCell {

    private func initializeView() {
        [messageLabel].forEach { addSubview($0) }
        backgroundColor = .error
        selectionStyle = .none
        isUserInteractionEnabled = false

        messageLabel.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
    }
}
