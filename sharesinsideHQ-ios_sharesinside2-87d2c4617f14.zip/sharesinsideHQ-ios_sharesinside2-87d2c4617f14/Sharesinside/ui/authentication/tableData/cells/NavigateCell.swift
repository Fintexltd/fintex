//
//  NavigateSectionView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 22.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class NavigateCell: UITableViewCell {
    
    lazy var leftLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small, fontWeight: .regular)
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    lazy var rightLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .primary, withFontSize: Defaults.TextSize.small, fontWeight: .regular)
        label.textAlignment = .right
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    var model: NavigateAuthSectionModel? {
        didSet {
            leftLabel.text = model?.value
            rightLabel.text = model?.subTitle
            setupDividerConstraints()
        }
    }
    // MARK: Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    private func initializeView() {
        selectionStyle = .none        
        [leftLabel, rightLabel, dividerView].forEach { addSubview($0) }
        leftLabel.snp.makeConstraints { make in
            make.top.bottom.leading.equalToSuperview().inset(Defaults.marginSmall)
        }
        let rightLabelMarginMultiplier: CGFloat = AppInfo.isIPad ? 2 : 1
        rightLabel.snp.makeConstraints { make in
            make.leading.equalTo(leftLabel.snp.trailing).offset(Defaults.marginMicro)
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().inset(Defaults.marginTremendous * rightLabelMarginMultiplier)
        }
        setupDividerConstraints()
    }
    
    private func setupDividerConstraints() {
        dividerView.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(model?.type.hasLongDivider == true ? 0 : Defaults.marginSmall)
            make.bottom.trailing.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
    }
}
