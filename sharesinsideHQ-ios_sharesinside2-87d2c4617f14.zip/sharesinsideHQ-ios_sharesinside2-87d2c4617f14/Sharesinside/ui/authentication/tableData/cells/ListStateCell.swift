//
//  ListStateCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 17.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

enum SearchListState {
    case loading
    case noResults
}

class ListStateCell: UITableViewCell {
    
    // MARK: Views
    private lazy var noResultsLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.text = Localizable.authNoResults.localized
        return label
    }()
    
    private lazy var loaderView: LoaderView = {
        let loader = LoaderView()
        loader.toggle(show: true)
        return loader
    }()
    
    private lazy var contentStackView: UIStackView = {
        let stackView = UIStackView.make(
            axis: .vertical,
            with: [
                noResultsLabel,
                loaderView
            ],
            spacing: 0
        )
        
        stackView.distribution = .fill
        stackView.alignment = .fill
        return stackView
    }()
    
    // MARK: Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    func configure(withState state: SearchListState) {
        loaderView.isHidden = state != .loading
        noResultsLabel.isHidden = state != .noResults
    }
    
}

extension ListStateCell {
    
    private func initializeView() {
        [contentStackView].forEach { addSubview($0) }
        backgroundColor = .background
        selectionStyle = .none
        isUserInteractionEnabled = false
        
        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
        
        loaderView.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Auth.countryLoadSpinnerSize)
        }
    }
}
