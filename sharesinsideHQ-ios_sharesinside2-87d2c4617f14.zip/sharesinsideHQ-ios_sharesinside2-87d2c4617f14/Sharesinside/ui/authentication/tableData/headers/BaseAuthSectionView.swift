//
//  BaseAuthSectionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class BaseAuthSectionView: UITableViewHeaderFooterView {

    // MARK: Initialization
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        initializeView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }

    func initializeView() { }

}
