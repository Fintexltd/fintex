//
//  InputTableViewCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import SnapKit
import IQKeyboardManagerSwift

protocol AuthInputSectionDelegate: class {
    func inputSection(_ section: InputAuthSectionView, didChangeInputValue newValue: String?)
}

class InputAuthSectionView: BaseAuthSectionView {

    weak var delegate: AuthInputSectionDelegate?

    private var textColor: UIColor = .primary

    private lazy var datePicker: UIDatePicker = {
        let datePicker = UIDatePicker()
        datePicker.maximumDate = Date()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(dataPickerValueSelected(datePicker:)), for: .valueChanged)

        return datePicker
    }()

    var dividerPadding: CGFloat = Defaults.marginNormal {
        didSet { setupDividerConstraints()}
    }
    // MARK: Views
    lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.setContentPriority(resistancePriority: UILayoutPriority.required,
            huggingPriority: UILayoutPriority.defaultHigh)
        return label
    }()

    lazy var textField: UITextField = {
        let field = UITextFieldFactory.styled(textColor: .primary, withFontSize: Defaults.TextSize.small)
        field.delegate = self
        field.textAlignment = .right
        field.setContentPriority(resistancePriority: .defaultLow)
        return field
    }()

    lazy var showHideButton: SharesinsideButton = {
        let button = SharesinsideButton(type: .system)
        button.style = SharesinsideButton.ButtonStyle(background: .clear, foreground: .grey, border: .clear)
        button.updateTitleMargins(left: 0, right: 0)
        button.setContentPriority(resistancePriority: UILayoutPriority.required.decreased(by: 1),
            huggingPriority: .defaultHigh)
        return button
    }()

    private lazy var contentStackView: UIStackView = {
        let stackView = UIStackView.make(
            axis: .horizontal,
            with: [
                titleLabel.embedInView(),
                textField,
                showHideButton
            ],
            spacing: Defaults.marginNormal
        )

        stackView.distribution = .fill
        stackView.alignment = .fill
        return stackView
    }()

    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    // MARK: Initialization

    var sectionModel: InputAuthSectionModel? {
        didSet {
            guard let model = sectionModel else { return }
            titleLabel.text = model.inputType.title
            showHideButton.isHidden = !model.inputType.isSecureText
            textField.isSecureTextEntry = model.inputType.isSecureText
            textField.keyboardType = model.inputType.keyboardType
            textField.autocapitalizationType = model.inputType.capitalization
            textField.text = model.forceClean ? "" : model.value
            textField.textColor = model.shouldShowError || model.apiErrorOccurred ? .error : textColor
            textField.inputView = (model.inputType == .dateOfBirth) ? datePicker : nil
            textField.placeholder = model.inputType.hint
        }
    }

    override func initializeView() {
        super.initializeView()

        contentView.backgroundColor = .accent
        [contentStackView, dividerView].forEach { addSubview($0) }
        setupConstraints()
        showHideButton.setTitle(Localizable.authPasswordShow.localized, for: .normal)
        showHideButton.addTarget(self, action: #selector(showHideButtonDidTouch), for: .touchUpInside)
        textField.addTarget(self, action: #selector(textFieldValueDidChange), for: .editingChanged)
    }

    func setupConstraints() {
        contentStackView.snp.makeConstraints { make in
            make.trailing.leading.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().offset(Defaults.marginMicro).priority(.highest)
            make.bottom.equalTo(dividerView.snp.top).offset(Defaults.marginMicro.negative())
        }
        titleLabel.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        setupDividerConstraints()
    }

    func setupDividerConstraints() {
        dividerView.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(dividerPadding)
            make.bottom.trailing.equalToSuperview().priority(.highest)
            make.height.equalTo(Defaults.dividerSize)
        }
    }

    @objc private func showHideButtonDidTouch() {
        let isSecure = textField.isSecureTextEntry
        textField.isSecureTextEntry = !isSecure
        showHideButton.setTitle((isSecure ? Localizable.authPasswordHide : Localizable.authPasswordShow).localized, for: .normal)
    }

    @objc private func textFieldValueDidChange() {
        sectionModel?.value = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    @objc private func dataPickerValueSelected(datePicker: UIDatePicker) {
        let dateString = datePicker.date.toString(withFromat: Date.Format.appDateFormat)
        sectionModel?.selectedDate = datePicker.date
        sectionModel?.value = dateString
        textField.text = dateString
    }
}

extension InputAuthSectionView: UITextFieldDelegate {

    func textFieldDidBeginEditing(_ textField: UITextField) {
        handleEditingChange(isEditing: true)
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        handleEditingChange(isEditing: false)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        IQKeyboardManager.shared.goNextOrResign()
        return true
    }

    private func handleEditingChange(isEditing: Bool) {
        sectionModel?.isEditing = isEditing
        sectionModel?.apiErrorOccurred = false
        delegate?.inputSection(self, didChangeInputValue: sectionModel?.value)
        textField.textColor = (sectionModel?.shouldShowError ?? false) ? .error : textColor
        if let model = sectionModel, model.inputType == .password, !model.isValid, isEditing {
            textField.text = ""
        }
    }
}

extension InputAuthSectionModel.InputSectionType {

    var keyboardType: UIKeyboardType {
        switch self {
        case .email, .newEmail: return .emailAddress
        case .postcode: return .numbersAndPunctuation
        case .phoneNumber: return .phonePad
        default: return .default
        }
    }

    var capitalization: UITextAutocapitalizationType {
        switch self {
        case .email, .newEmail, .usernameOrEmail: return .none
        default: return .sentences
        }
    }
}
