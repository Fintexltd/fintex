//
//  DocumentsCell.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol TermsAuthSectionDelegate: class {
    func termsAcceptationChanged(accepted: Bool)
    func showTermsAndConditions()
}

class TermsAuthSectionView: BaseAuthSectionView {

    weak var delegate: TermsAuthSectionDelegate?
    
    // MARK: Views
    private lazy var messageLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.textAlignment = .left
        return label
    }()

    private lazy var termsSwitch: UISwitch = {
        let termsSwitch = UISwitch().layoutable()
        termsSwitch.isOn = false

        return termsSwitch
    }()

    // MARK: Initialization
    
    var sectionModel: TermsAuthSectionModel? {
        didSet {
            termsSwitch.isOn = sectionModel?.isValid == true
        }
    }
    
    override func initializeView() {
        contentView.backgroundColor = .accent
        [messageLabel, termsSwitch].forEach { addSubview($0) }
        initializeTermsLabelText()
        setupConstraints()
        messageLabel.setupGestureRecognizer(target: self, selector: #selector(didTapMessageLabel(_:)))
        termsSwitch.addTarget(self, action: #selector(termsSwitchChangedValue), for: .valueChanged)
    }
    
    @objc private func didTapMessageLabel(_ recognizer: UIGestureRecognizer) {
        delegate?.showTermsAndConditions()
    }
    
    private func setupConstraints() {
        messageLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.trailing.equalTo(termsSwitch.snp.leading).inset(Defaults.marginNormal)
            make.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
        
        termsSwitch.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.centerY.equalTo(messageLabel.snp.centerY)
        }
        
    }
    fileprivate func initializeTermsLabelText() {
        let termsBoldText = Localizable.documentsTermAndConditions.localized
        let termsRegularText = "\(Localizable.authAccept.localized) "
        
        let attrs = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: Defaults.TextSize.small, weight: .bold),
                     NSAttributedString.Key.foregroundColor: UIColor.primary]
        let boldAttributedString = NSMutableAttributedString(string: termsBoldText, attributes: attrs)
        
        let attributedString = NSMutableAttributedString(string: termsRegularText)
        attributedString.append(boldAttributedString)
        
        messageLabel.attributedText = attributedString
    }
    
    @objc private func termsSwitchChangedValue() {
        sectionModel?.termsAccepted = termsSwitch.isOn
        delegate?.termsAcceptationChanged(accepted: termsSwitch.isOn)
    }
}
