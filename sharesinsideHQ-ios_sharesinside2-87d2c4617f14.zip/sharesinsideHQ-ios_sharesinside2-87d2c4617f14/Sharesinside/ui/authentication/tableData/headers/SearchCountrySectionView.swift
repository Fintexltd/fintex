//
//  SearchCountrySectionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

protocol SearchCountrySectionDelegate: class {
    func searchSection(_ section: SearchCountrySectionView, didChangeSearchValue newValue: String?)
    func searchSectionNeedUpdate(_ section: SearchCountrySectionView)
}

class SearchCountrySectionView: BaseAuthSectionView {
    
    weak var delegate: SearchCountrySectionDelegate?

    // MARK: Views
    lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey, withFontSize: Defaults.TextSize.small)
        label.text = Localizable.authCountry.localized
        label.setContentPriority(resistancePriority: UILayoutPriority.required)
        label.setContentPriority(huggingPriority: .defaultLow, huggingAxis: .vertical)
        label.setContentPriority(huggingPriority: .defaultHigh, huggingAxis: .horizontal)
        return label
    }()
    
    lazy var textField: UITextField = {
        let field = UITextFieldFactory.styled(textColor: .grey, withFontSize: Defaults.TextSize.small)
        field.delegate = self
        field.textAlignment = .left
        field.setContentPriority(resistancePriority: .defaultLow)
        return field
    }()

    private lazy var contentStackView: UIStackView = {
        let stackView = UIStackView.make(
            axis: .horizontal,
            with: [
                titleLabel.embedInView(),
                textField
            ],
            spacing: Defaults.marginNormal
        )
        
        stackView.distribution = .fill
        stackView.alignment = .fill
        return stackView
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()
    
    // MARK: public methods
    
    var dividerPadding: CGFloat = Defaults.marginNormal {
        didSet { setupDividerConstraints()}
    }
    
    func selectedCountry(_ country: Country?) {
        searchSectionModel?.selectedCountry = country
        searchSectionModel?.areSearchResultsExpanded = false
        
        textField.text = searchSectionModel?.value
        textField.textColor = country == nil ? .grey : .primary
        textField.textAlignment = country == nil ? .left : .right
    }
    
    // MARK: Initialization

    var searchSectionModel: SearchCountrySectionModel? {
        didSet {
            guard let model = searchSectionModel else { return }
            selectedCountry(model.selectedCountry)
        }
    }
    
    override func initializeView() {
        super.initializeView()
        contentView.backgroundColor = .accent
        [contentStackView, dividerView].forEach { addSubview($0) }
        
        contentStackView.snp.makeConstraints { make in
            make.trailing.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.top.equalToSuperview()
            make.bottom.equalTo(dividerView.snp.top)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
        
        setupDividerConstraints()        
        textField.addTarget(self, action: #selector(textFieldValueDidChange), for: .editingChanged)
    }
    
    func setupDividerConstraints() {
        dividerView.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(dividerPadding)
            make.bottom.trailing.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
    }
    
    @objc private func textFieldValueDidChange() {
        searchSectionModel?.value = textField.text ?? ""
        delegate?.searchSection(self, didChangeSearchValue: searchSectionModel?.value)
    }
}

extension SearchCountrySectionView: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.textColor = .grey
        textField.textAlignment = .left
        
        searchSectionModel?.areSearchResultsExpanded = true
        delegate?.searchSectionNeedUpdate(self)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        IQKeyboardManager.shared.goNextOrResign()
        return true
    }
}
