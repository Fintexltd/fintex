//
//  LinkedInConnectSectionView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol LinkedInConnectSectionDelegate: class {
    func didTapSection(_ linkedInSectionView: LinkedInConnectSectionView)
}

class LinkedInConnectSectionView: BaseAuthSectionView {
    
    weak var delegate: LinkedInConnectSectionDelegate?
    
    var sectionModel: LinkedInConnectSectionModel? {
        didSet {
            titleLabel.text = sectionModel?.localizedTitle
            titleLabel.textColor = sectionModel?.fontColor
        }
    }
    
    lazy var logo: UIImageView = UIImageView(image: #imageLiteral(resourceName: "IconLinkedinRect"))
    
    lazy var parentView = UIView().layoutable()
    
    lazy var titleLabel = UILabelFactory.styled(textColor: .primary, withFontSize: Defaults.TextSize.small)
    
    lazy var divider: UIView = UIView.horizontalDivider
    
    override func initializeView() {
        parentView.backgroundColor = .accent
        titleLabel.textAlignment = .left
        
        [logo, titleLabel, divider].forEach {
            $0.isUserInteractionEnabled = true
            $0.setupGestureRecognizer(target: self, selector: #selector(didTapSection))
            parentView.addSubview($0)
        }
        
        addSubview(parentView)
        setupConstraints()
    }
    
    private func setupConstraints() {
        logo.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(Defaults.marginMicro)
            make.leading.equalToSuperview().inset(Defaults.marginNormal)
            make.height.width.equalTo(Defaults.linkedInConnectIconSize).priority(.highest)
        }
        
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalTo(logo)
            make.leading.equalTo(logo.snp.trailing).offset(Defaults.marginSmall)
            make.trailing.lessThanOrEqualToSuperview().inset(Defaults.marginNormal)
        }
        
        parentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        divider.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    @objc func didTapSection() {
        delegate?.didTapSection(self)
    }
}
