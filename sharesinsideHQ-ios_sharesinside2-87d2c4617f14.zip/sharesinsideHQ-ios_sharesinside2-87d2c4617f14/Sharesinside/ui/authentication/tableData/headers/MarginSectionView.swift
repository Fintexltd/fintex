//
//  MarginSectionView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class MarginSectionView: BaseAuthSectionView {
    lazy var margin = UIView().layoutable()
    
    lazy var divider = UIView.horizontalDivider
    
    override func initializeView() {
        margin.backgroundColor = .accent
        [margin, divider].forEach { addSubview($0) }
        
        margin.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(Defaults.Auth.marginSectionHeight)
            make.bottom.equalTo(divider.snp.top)
        }
        divider.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
}
