//
//  TitleAuthSectionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class TitleAuthSectionView: BaseAuthSectionView {
    
    // MARK: Views
    
    private lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .primaryDark,
                                          withFontSize: Defaults.TextSize.big,
                                          fontWeight: .bold)
        label.textAlignment = .left
        return label
    }()
    
    private lazy var subtitleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.tiny)
        label.textAlignment = .left
        return label
    }()
    
    private lazy var contentStackView: UIStackView = {
        let stackView = UIStackView.make(
            axis: .vertical,
            with: [
                titleLabel.embedInView(),
                subtitleLabel.embedInView()
            ],
            spacing: 0
        )
        
        stackView.distribution = .fill
        stackView.alignment = .fill
        return stackView
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        return view
    }()

    // Initialization
    
    override func initializeView() {
        contentView.backgroundColor = .accent
        [contentStackView, dividerView].forEach { addSubview($0) }
        
        dividerView.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(Defaults.dividerSize)
        }
        
        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.equalToSuperview().priority(.highest)
            make.bottom.equalTo(dividerView.snp.top).offset(Defaults.marginBig.negative())
        }
        
        titleLabel.snp.makeConstraints { make in
            make.leading.trailing.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(Defaults.marginNormal).priority(.highest)
        }
        
        subtitleLabel.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview().inset(Defaults.marginTiny)
            make.bottom.equalToSuperview()
        }
    }
    
    var sectionModel: TitleAuthSectionModel? {
        didSet {
            if let model = sectionModel {
                titleLabel.text = model.title
                subtitleLabel.text = model.subtitle
                titleLabel.superview?.isHidden = model.title == nil
                subtitleLabel.superview?.isHidden = model.subtitle == nil
            }
        }
    }
}
