//
//  AuthTableDataSource.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol AuthTableDataDelegate: class {
    func tableFormDataChanged()
    func didSelectNavigateCell(with model: NavigateAuthSectionModel)
    func showTermsAndConditions()
    func didTapLinkedInConnectSection(_ sectionView: LinkedInConnectSectionView)
}

class AuthTableDataSource: NSObject {
    
    let tableView: UITableView
    
    weak var delegate: AuthTableDataDelegate?

    var authSections: [AuthSectionModel] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    init(with tableView: UITableView) {
        self.tableView = tableView
        super.init()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.registerHeaderFooter(TitleAuthSectionView.self)
        self.tableView.registerHeaderFooter(InputAuthSectionView.self)
        self.tableView.registerHeaderFooter(SearchCountrySectionView.self)
        self.tableView.registerHeaderFooter(TermsAuthSectionView.self)
        self.tableView.registerHeaderFooter(MarginSectionView.self)
        self.tableView.registerHeaderFooter(LinkedInConnectSectionView.self)
        self.tableView.registerCell(CountryCell.self)
        self.tableView.registerCell(ErrorMessageCell.self)
        self.tableView.registerCell(ListStateCell.self)
        self.tableView.registerCell(NavigateCell.self)
        self.tableView.cellLayoutMarginsFollowReadableWidth = false
        
        self.tableView.estimatedSectionHeaderHeight = Defaults.Auth.authSectionHeight
        self.tableView.estimatedRowHeight = Defaults.Auth.authSectionHeight
    }
    
    func reload(section: Int) {
        if authSections.indices.contains(section) {
            var sectionModel = authSections[section]
            let value = sectionModel.value
            sectionModel.value = value
            reloadTableViewSection(sectionNumber: section, numberOfElements: sectionModel.rowCount)
        }
    }
    
    func reloadSectionHeader(section: Int) {
        tableView.reloadSections(IndexSet(integer: section), with: .automatic)
    }
    
    fileprivate func reloadTableViewSection(sectionNumber: Int, numberOfElements: Int) {
        let numberOfVisibleRows = tableView.numberOfRows(inSection: sectionNumber)
        let rowsDifference = numberOfElements - numberOfVisibleRows
        
        var indexPaths = [IndexPath]()
        if rowsDifference > 0 {
            for index in numberOfVisibleRows ..< numberOfElements {
                indexPaths.append(IndexPath(row: index, section: sectionNumber))
            }
            tableView.insertRows(at: indexPaths, with: .top)
        } else if rowsDifference < 0 {
            for index in numberOfElements ..< numberOfVisibleRows {
                indexPaths.append(IndexPath(row: index, section: sectionNumber))
            }
            tableView.deleteRows(at: indexPaths, with: .top)
        }
        
        indexPaths.removeAll()
        for index in 0 ..< numberOfElements {
            indexPaths.append(IndexPath(row: index, section: sectionNumber))
        }
        
        if !indexPaths.isEmpty {
            tableView.reloadRows(at: indexPaths, with: .none)
        }
    }
}

extension AuthTableDataSource: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return authSections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authSections[section].rowCount
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = authSections[indexPath.section]

        switch section.sectionType {
        case .input:
            if let section = section as? InputAuthSectionModel,
                let cell: ErrorMessageCell = tableView.dequeueReusableCell(for: indexPath) {
                cell.configureWith(section.inputType.errorMessage ?? "")
                return cell
            }
        case .searchCountry:
            return prepareCountryCell(for: tableView, andIndexPath: indexPath)
        case .navigate:
            return prepareNavigateCell(for: tableView, andIndexPath: indexPath)
        default:
            return UITableViewCell()
        }

        return UITableViewCell()
    }
    
    private func prepareCountryCell(for tableView: UITableView, andIndexPath indexPath: IndexPath) -> UITableViewCell {
        guard let section = authSections[indexPath.section] as? SearchCountrySectionModel else {
            return UITableViewCell()
        }
        
        if let cell: ListStateCell = tableView.dequeueReusableCell(for: indexPath), section.loadingCountries {
            cell.configure(withState: .loading)
            return cell
        }
        
        if let cell: ListStateCell = tableView.dequeueReusableCell(for: indexPath), section.noCountriesFound {
            cell.configure(withState: .noResults)
            return cell
        }
        
        if let cell: CountryCell = tableView.dequeueReusableCell(for: indexPath) {
            let country = section.filteredCountries[indexPath.row]
            cell.configureWith(countryTitle: country.countryName,
                               searchedText: section.value)
            
            return cell
        }
        return UITableViewCell()
    }
    
    private func prepareNavigateCell(for tableView: UITableView, andIndexPath indexPath: IndexPath) -> UITableViewCell {
        guard let sectionModel = authSections[indexPath.section] as? NavigateAuthSectionModel else {
            return UITableViewCell()
        }
        if let cell: NavigateCell = tableView.dequeueReusableCell(for: indexPath) {
            cell.accessoryType = .disclosureIndicator
            cell.model = sectionModel
            return cell
        }
        return UITableViewCell()
    }
}

extension AuthTableDataSource: UITableViewDelegate {

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch authSections[section].sectionType {
        case .title, .description, .linkedInConnect, .margin: return UITableView.automaticDimension
        case .terms: return Defaults.Auth.termsSectionHeight
        case .navigate: return 0
        default: return Defaults.Auth.authSectionHeight
        }
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionModel = authSections[section]
        switch sectionModel.sectionType {
        case .title:
            if let sectionModel = sectionModel as? TitleAuthSectionModel,
                let header: TitleAuthSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.sectionModel = sectionModel
                return header
            }
        case .input:
            if let sectionModel = sectionModel as? InputAuthSectionModel,
                let header: InputAuthSectionView = tableView.dequeueReusableHeaderFooter() {
                let isLastCell = section == authSections.count - 1
                header.tag = section
                header.sectionModel = sectionModel
                header.delegate = self
                if isLastCell { header.dividerPadding = 0 }
                return header
            }
        case .searchCountry:
            if let sectionModel = sectionModel as? SearchCountrySectionModel,
                let header: SearchCountrySectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.searchSectionModel = sectionModel
                header.delegate = self
                return header
            }
        case .terms:
            if let sectionModel = sectionModel as? TermsAuthSectionModel,
                let header: TermsAuthSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.sectionModel = sectionModel
                header.delegate = self
                return header
            }
        case .margin:
            if sectionModel is MarginSectionModel,
                let header: MarginSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                return header
            }
        case .linkedInConnect:
            if let sectionModel = sectionModel as? LinkedInConnectSectionModel,
                let header: LinkedInConnectSectionView = tableView.dequeueReusableHeaderFooter() {
                header.tag = section
                header.sectionModel = sectionModel
                header.delegate = self
                return header
            }
        default: return nil
        }
        return nil
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let searchSection = tableView.headerView(forSection: indexPath.section) as? SearchCountrySectionView {
            searchSection.selectedCountry(searchSection.searchSectionModel?.filteredCountries[indexPath.row])
            reload(section: indexPath.section)
            delegate?.tableFormDataChanged()
        }
        if let navigateModel = authSections[indexPath.section] as? NavigateAuthSectionModel {
            delegate?.didSelectNavigateCell(with: navigateModel)
        }
    }
}

extension AuthTableDataSource: AuthInputSectionDelegate {
    
    func inputSection(_ section: InputAuthSectionView, didChangeInputValue newValue: String?) {
        guard let sectionModel = section.sectionModel else { return }
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
        
        if sectionModel.inputType == .password || sectionModel.inputType == .newPassword {
            checkRepeatedPassword(withValue: newValue)
        }
    }
    
    private func checkRepeatedPassword(withValue value: String?) {
        guard
            let repeatPasswordIndex = authSections.index(where: { ($0 as? InputAuthSectionModel)?.inputType == .repeatPassword }),
            let repeatPasswordModel = authSections[repeatPasswordIndex] as? InputAuthSectionModel,
            let sectionView = tableView.headerView(forSection: repeatPasswordIndex) as? InputAuthSectionView
        else { return }
        
        repeatPasswordModel.valueToComparison = value
        inputSection(sectionView, didChangeInputValue: repeatPasswordModel.value)
    }
}

extension AuthTableDataSource: SearchCountrySectionDelegate {
    func searchSection(_ section: SearchCountrySectionView, didChangeSearchValue newValue: String?) {
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
    }
    
    func searchSectionNeedUpdate(_ section: SearchCountrySectionView) {
        reload(section: section.tag)
        delegate?.tableFormDataChanged()
    }
}

extension AuthTableDataSource: TermsAuthSectionDelegate {
    
    func showTermsAndConditions() {
        delegate?.showTermsAndConditions()
    }
    
    func termsAcceptationChanged(accepted: Bool) {
        delegate?.tableFormDataChanged()
    }
}

extension AuthTableDataSource: LinkedInConnectSectionDelegate {
   
    func didTapSection(_ linkedInSectionView: LinkedInConnectSectionView) {
        delegate?.didTapLinkedInConnectSection(linkedInSectionView)
    }
}
