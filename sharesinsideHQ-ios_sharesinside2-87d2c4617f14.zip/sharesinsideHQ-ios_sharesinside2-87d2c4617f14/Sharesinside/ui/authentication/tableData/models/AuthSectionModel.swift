//
// Created by Damian Włodarczyk on 15.06.2018.
// Copyright (c) 2018 Kiss Digital. All rights reserved.
//

enum AuthSectionType {
    case title
    case input
    case searchCountry
    case terms
    case navigate
    case description
    case linkedInConnect
    case margin
}

protocol AuthSectionModel {
    var sectionType: AuthSectionType { get }
    var value: String { get set }
    var isValid: Bool { get }
    var shouldShowError: Bool { get }
    var rowCount: Int { get }
}
