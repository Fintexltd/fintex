//
//  LinkedInConnectSectionModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

enum LinkedInConnectionStatus {
    case disconnected
    case connectedOnlyWithLinkedIn
    case connected
}

class LinkedInConnectSectionModel: AuthSectionModel {
   
    var status: LinkedInConnectionStatus
    
    var sectionType: AuthSectionType = .linkedInConnect
    
    var value: String = ""
    
    var isValid: Bool {
        return true
    }
    
    var shouldShowError: Bool {
        return false
    }
    
    var rowCount: Int {
        return 0
    }
    
    var fontColor: UIColor {
        switch status {
        case .disconnected: return .primary
        case .connectedOnlyWithLinkedIn: return .appGreen
        case .connected: return .red
        }
    }
    
    var localizedTitle: String {
        switch status {
        case .disconnected: return Localizable.linkedinAuthenticationConnect.localized
        case .connected: return Localizable.linkedinAuthenticationDisconnect.localized
        case .connectedOnlyWithLinkedIn: return Localizable.linkedinAuthenticationConnected.localized
        }
    }
    
    init(status: LinkedInConnectionStatus) {
        self.status = status
    }
}
