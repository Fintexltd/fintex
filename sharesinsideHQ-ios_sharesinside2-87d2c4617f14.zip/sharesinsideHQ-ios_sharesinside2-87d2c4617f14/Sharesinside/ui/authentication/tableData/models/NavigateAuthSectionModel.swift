//
//  NavigateAuthSectionModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 22.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class NavigateAuthSectionModel: AuthSectionModel {
    var sectionType: AuthSectionType = .navigate
    
    var isValid: Bool { return true }
    
    var shouldShowError: Bool { return false }
    
    var rowCount: Int { return 1 }
    
    var value: String
    
    var subTitle: String?
    
    let type: NavigateSectionType
    
    init(type: NavigateSectionType) {
        self.value = type.title
        self.subTitle = type.subTitle
        self.type = type
    }
    
    enum NavigateSectionType {
        
        case changeEmail
        case changeUsername
        case changePassword
        case setPassword
        case privacyPolicy
        
        var destination: Destination {
            switch self {
            case .changeEmail: return .auth(pageType: .changeEmail, linkedinUserData: nil)
            case .changePassword: return .auth(pageType: .changePassword, linkedinUserData: nil)
            case .changeUsername: return .auth(pageType: .changeUsername, linkedinUserData: nil)
            case .setPassword: return .auth(pageType: .setPassword, linkedinUserData: nil)
            case .privacyPolicy: return .documents(type: .privacyPolicy)
            }
        }
        
        var title: String {
            switch self {
            case .changeUsername: return Localizable.authUsername.localized
            case .changePassword: return Localizable.authChangePassword.localized
            case .changeEmail: return Localizable.authEmail.localized
            case .setPassword: return Localizable.authSetPassword.localized
            case .privacyPolicy: return Localizable.authPrivacyPolicy.localized
            }
        }
        
        var subTitle: String? {
            switch self {
            case .changeUsername: return AppUser.current?.username
            case .changeEmail: return AppUser.current?.email
            default: return nil
            }
        }
        
        var hasLongDivider: Bool {
            switch self {
            case .setPassword, .privacyPolicy: return true
            default: return false
            }
        }
    }
}
