//
//  SearchCountrySectionModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class SearchCountrySectionModel: AuthSectionModel {
    
    init(selectedCountry: Country? = nil) {
        self.selectedCountry = selectedCountry
    }
    
    let sectionType: AuthSectionType = .searchCountry
        
    var countries: [Country]?
    
    private(set) var filteredCountries: [Country] = []
    
    var value: String = "" {
        didSet {
            filteredCountries = countries?.filter {
                value.isEmpty || $0.countryName.contains(value)
            } ?? []
            
            if filteredCountries.count > 1 {
                selectedCountry = nil
            }
        }
    }
    
    var selectedCountry: Country? {
        didSet {
            if let name = selectedCountry?.countryName {
                value = name
            }
        }
    }
    
    var areSearchResultsExpanded: Bool = false
    
    var isValid: Bool {
        return selectedCountry != nil
    }
    
    var shouldShowError: Bool {
        return !value.isEmpty && !isValid
    }
    
    var rowCount: Int {
        if !areSearchResultsExpanded {
            return 0
        }
        
        if loadingCountries || noCountriesFound {
            return 1
        }
        
        return filteredCountries.count
    }
    
    var noCountriesFound: Bool {
        return countries != nil && filteredCountries.isEmpty
    }
    
    var loadingCountries: Bool {
        return countries == nil
    }
    
}
