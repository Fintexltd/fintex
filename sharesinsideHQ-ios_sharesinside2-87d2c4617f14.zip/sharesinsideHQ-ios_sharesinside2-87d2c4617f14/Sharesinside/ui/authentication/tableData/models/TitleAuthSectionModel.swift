//
//  TitleAuthSectionModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class TitleAuthSectionModel: AuthSectionModel {
    
    var sectionType: AuthSectionType = .title
    
    var value: String = ""
    
    var isValid: Bool = true
    
    var shouldShowError: Bool = false
    
    var rowCount: Int = 0
    
    var title: String?
    
    var subtitle: String?
    
    init(title: String? = nil, subtitle: String? = nil) {
        self.title = title
        self.subtitle = subtitle
    }
}
