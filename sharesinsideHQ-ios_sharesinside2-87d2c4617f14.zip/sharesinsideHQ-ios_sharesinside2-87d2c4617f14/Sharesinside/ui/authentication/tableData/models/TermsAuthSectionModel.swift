//
//  TermsAuthSectionModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class TermsAuthSectionModel: AuthSectionModel {
    
    var sectionType: AuthSectionType = .terms
    
    var value: String = ""
    
    var isValid: Bool {
        return termsAccepted
    }
    
    var termsAccepted: Bool = false
    
    var shouldShowError: Bool = false
    
    var rowCount: Int = 0
}
