//
//  InputAuthSectionModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class InputAuthSectionModel: AuthSectionModel {
    
    enum InputSectionType {
        case email
        case newEmail
        case username
        case newUsername
        case password
        case newPassword
        case oldPassword
        case repeatPassword
        case usernameOrEmail
        case firstName
        case lastName
        case dateOfBirth
        case address
        case city
        case postcode
        case phoneNumber
    }
    
    let inputType: InputSectionType
    
    var sectionType: AuthSectionType { return .input }
    
    var isValid: Bool {
        guard inputType != .dateOfBirth else {
            return selectedDate != nil
        }
        
        guard let valueToComparison = valueToComparison else {
            return value.valid(withRegex: inputType.validationRegex)
        }
        
        return value == valueToComparison
    }
    
    var apiErrorOccurred: Bool = false
    
    var value: String = ""
    
    var selectedDate: Date?
    
    var valueToComparison: String?
    
    var isEditing: Bool = false

    var shouldShowError: Bool {
        return !isValid && !value.isEmpty && !isEditing
    }
    
    private var shouldForceClean = false
    
    var forceClean: Bool {
        get {
            defer { shouldForceClean = false }
            return shouldForceClean
        }
        set (newValue) { shouldForceClean = newValue}
    }
    
    var rowCount: Int {
        return shouldShowError ? 1 : 0
    }
    
    init(inputType: InputSectionType, value: String = "") {
        self.inputType = inputType
        self.value = value
    }
}

extension InputAuthSectionModel.InputSectionType {
    
    var title: String {
        switch self {
        case .email: return Localizable.authEmail.localized
        case .newEmail: return Localizable.authNewEmail.localized
        case .username: return Localizable.authUsername.localized
        case .newUsername: return Localizable.authNewUsername.localized
        case .usernameOrEmail: return Localizable.authUsernameOrEmail.localized
        case .password: return Localizable.authPassword.localized
        case .newPassword: return Localizable.authNewPassword.localized
        case .oldPassword: return Localizable.authOldPassword.localized
        case .repeatPassword: return Localizable.authRepeatPassword.localized
        case .firstName: return Localizable.shareholderFormFirstName.localized
        case .lastName: return Localizable.shareholderFormLastName.localized
        case .dateOfBirth: return Localizable.shareholderFormDateOfBirth.localized
        case .address: return Localizable.shareholderFormAddress.localized
        case .city: return Localizable.shareholderFormCity.localized
        case .postcode: return Localizable.shareholderFormPostcode.localized
        case .phoneNumber: return Localizable.shareholderFormPhone.localized
        }
    }
    
    var errorMessage: String? {
        switch self {
        case .email, .newEmail: return Localizable.authWrongEmail.localized
        case .username, .newUsername: return Localizable.authWrongUsername.localized
        case .usernameOrEmail: return Localizable.authWrongUsernameOrEmail.localized
        case .password: return Localizable.authWrongPassword.localized
        case .newPassword: return Localizable.authWrongPassword.localized
        case .oldPassword: return Localizable.authWrongPassword.localized
        case .repeatPassword: return Localizable.authWrongRepeatedPassword.localized
        case .dateOfBirth: return Localizable.shareholderFormEmptyDateError.localized
        case .firstName: return Localizable.shareholderValidationFirstName.localized
        case .lastName: return Localizable.shareholderValidationLastName.localized
        case .address: return Localizable.shareholderFormEmptyError.localized
        case .city: return Localizable.shareholderValidationCity.localized
        case .postcode: return Localizable.shareholderValidationPostalCode.localized
        case .phoneNumber: return Localizable.shareholderValidationPhoneNumber.localized
        }
    }
    
    var isSecureText: Bool {
        switch self {
        case .password, .newPassword, .oldPassword, .repeatPassword: return true
        default: return false
        }
    }
    
    var validationRegex: String {
        switch self {
        case .email, .newEmail: return Defaults.Regex.email
        case .username, .newUsername: return Defaults.Regex.username
        case .password, .newPassword, .oldPassword, .repeatPassword: return Defaults.Regex.password
        case .usernameOrEmail: return  Defaults.Regex.usernameOrEmail
        case .firstName, .lastName: return Defaults.Regex.alphabeticalTwoCharLong
        case .city: return Defaults.Regex.city
        case .postcode: return Defaults.Regex.postCode
        case .phoneNumber: return Defaults.Regex.phoneNumber
        case .dateOfBirth, .address: return Defaults.Regex.notEmpty
        }
    }
    
    var hint: String {
        switch self {
        case .phoneNumber: return Localizable.shareholderFormCityPlaceholder.localized
        default: return ""
        }
    }
}
