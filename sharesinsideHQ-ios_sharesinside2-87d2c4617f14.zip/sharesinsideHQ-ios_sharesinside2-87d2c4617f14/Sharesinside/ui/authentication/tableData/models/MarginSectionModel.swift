//
//  MarginSectionModel.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

class MarginSectionModel: AuthSectionModel {
    
    var sectionType: AuthSectionType = .margin
    
    var value: String = ""
    
    var isValid: Bool {
        return true
    }
    
    var shouldShowError: Bool {
        return false
    }
    
    var rowCount: Int {
        return 0
    }
}
