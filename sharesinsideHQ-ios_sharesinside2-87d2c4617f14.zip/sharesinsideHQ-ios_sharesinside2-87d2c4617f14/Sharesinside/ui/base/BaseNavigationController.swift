//
//  BaseNavigationController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

class BaseNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigationBar()
    }
    
    var rootViewController: UIViewController? {
        return viewControllers.first
    }
}

extension UINavigationController {
    func setupNavigationBar(withStyle style: NavigationBarStyle = .dark) {

        navigationBar.barStyle = style.barStyle
        navigationBar.isTranslucent = style == .transparent
        navigationBar.tintColor = style.tintColor
        navigationBar.barTintColor = style.barTintColor

        if #available(iOS 10.0, *) {
            navigationBar.setValue(true, forKey: "hidesShadow")
        }

        if style == .transparent {
            navigationBar.setBackgroundImage(UIImage(), for: .default)
            navigationBar.shadowImage = UIImage()
        }
    }
}

enum NavigationBarStyle {
    case dark
    case light
    case transparent
}

extension NavigationBarStyle {
    
    var barStyle: UIBarStyle {
        switch self {
        case .dark: return .black
        case .light: return .default
        case .transparent: return .black
        }
    }
    
    var tintColor: UIColor {
        switch self {
        case .dark: return .white
        case .light: return .darkGray
        case .transparent: return .white
        }
    }
    
    var barTintColor: UIColor {
        switch self {
        case .dark: return .primaryDark
        case .light: return .white
        case .transparent: return .clear
        }
    }
}
