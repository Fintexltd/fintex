//
//  BaseButton.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class BaseButton: UIButton {
    
    @available(*, unavailable) required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(frame: .zero)
        layoutable()
        setupViewHierarchy()
        setupConstraints()
        setupProperties()
        setupColors()
    }
    
    func setupViewHierarchy() {}
    
    func setupConstraints() {}
    
    func setupProperties() {}
    
    func setupColors() {}
    
    override static var requiresConstraintBasedLayout: Bool {
        return true
    }
}
