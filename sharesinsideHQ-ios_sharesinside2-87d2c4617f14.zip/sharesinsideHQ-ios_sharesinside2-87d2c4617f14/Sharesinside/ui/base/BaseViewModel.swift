//
//  BaseViewModel.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

protocol ViewModel: class {
    associatedtype Dependencies
    
    var dependencies: Dependencies! { get set }

    var alert: BehaviorRelay<AlertData?> { get set }
    
    var loading: BehaviorRelay<Bool> { get set }
    
    var router: Router? { get set }

    var disposeBag: DisposeBag { get }

    init()
    
    func onViewWillAppear()
    func onViewDidAppear()
    func onViewWillDisappear()
    func onViewDidLoad()
}

class BaseViewModel<DependenciesType>: ViewModel {
    
    required init() {}
    
    var dependencies: DependenciesType!
    
    var alert = BehaviorRelay<AlertData?>(value: nil)
    
    var loading = BehaviorRelay<Bool>(value: false)
    
    var router: Router?
    
    var disposeBag = DisposeBag()
    
    func onViewWillAppear() { }
    func onViewDidAppear() { }
    func onViewWillDisappear() { }
    func onViewDidLoad() {}
}
