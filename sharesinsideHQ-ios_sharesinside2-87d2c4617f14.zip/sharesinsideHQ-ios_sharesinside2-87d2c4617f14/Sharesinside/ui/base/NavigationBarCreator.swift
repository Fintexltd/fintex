//
//  NavigationBarCreator.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 06.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol NavigationBarCreator {
    
    var navigationItem: UINavigationItem? { get set }
    func setupNavigationBar()
}
