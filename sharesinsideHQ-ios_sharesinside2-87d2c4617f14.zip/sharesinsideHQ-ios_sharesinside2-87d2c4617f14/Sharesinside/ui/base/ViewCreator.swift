//
//  ViewCreator.swift
//  Oknoplast
//
//  Created by Damian Włodarczyk on 24.05.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol ViewCreator {

    var parentView: UIView { get }

    init(withParentView parent: UIView)
    // Add subviews to the view when called
    func setupViewHierarchy()

    // Add constraints to the view when called
    func setupConstraints()

    // Setup required properties when called
    func setupProperties()
}

extension ViewCreator {
    // Calls all other setup methods in proper order
    func setupView() {
        setupViewHierarchy()
        setupConstraints()
        setupProperties()
    }
}

class BaseViewCreator: ViewCreator {

    var parentView: UIView

    required init(withParentView parent: UIView) {
        self.parentView = parent
    }
    
    func setupViewHierarchy() {}
    
    func setupConstraints() {}
    
    func setupProperties() {}
}
