//
//  PageTabBarView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit
import SnapKit

protocol TabLayoutDelegate: class {
    func didSelect(pageIndex: Int)
}

internal final class TabLayout: BaseView {
    
    weak var delegate: TabLayoutDelegate?
    
    private(set) var currentIndex: Int = 0
    
    var tabViews: [TabView] = [] {
        didSet { fillTabBarWithItems() }
    }
    
    func select(index: Int, animated: Bool = true) {
        guard index >= 0, index < tabViews.count else { return }
        currentIndex = index
        updateAppearance(animated: animated)
    }
    
    private var dividerWidthConstraint: Constraint?
    private var dividerLeadingConstraint: Constraint?
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.bounces = false
        return scrollView
    }()
    
    private lazy var stackView: UIStackView = .make(
    axis: .horizontal,
    with: [],
    alignment: .center,
    distribution: AppInfo.isIPad ? .fillProportionally : .fill)
    
    private lazy var dividerView: UIView = {
        let dividerView = UIView()
        dividerView.backgroundColor = .accent
        
        return dividerView
    }()
    override func setupProperties() {
        backgroundColor = .primaryDark
    }

    override func setupViewHierarchy() {
        scrollView.addSubview(stackView)
        addSubview(scrollView)
        addSubview(dividerView)
    }
    
    override func setupConstraints() {
        scrollView.snp.makeConstraints { make in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(Defaults.CompanyDetails.tabLayoutHeight)
        }
        
        stackView.snp.makeConstraints { make in
            make.leading.top.bottom.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalToSuperview()
            
            if AppInfo.isIPad { make.width.equalToSuperview() }
        }
        self.layoutIfNeeded()
    }
    
    private func fillTabBarWithItems() {
        stackView.removeAllArrangedSubviews()
        tabViews.forEach {
            $0.delegate = self
            $0.tag = tabViews.index(of: $0) ?? 0
            stackView.addArrangedSubview($0)
        }
        updateAppearance(animated: false)
    }
    
    override func willMove(toWindow newWindow: UIWindow?) {
        super.willMove(toWindow: newWindow)
        stackView.layoutIfNeeded()
    }
}

extension TabLayout {
    
    private func updateAppearance(animated: Bool = true) {
        tabViews.forEach { $0.isSelected = $0.tag == currentIndex }
        updateDivider(animated: animated)
        updateScrollView(animated: animated)
    }
    
    private func updateDivider(animated: Bool) {
        dividerView.snp.remakeConstraints { make in
            make.height.equalTo(Defaults.CompanyDetails.tabLayoutDividerHeight)
            make.bottom.equalToSuperview()
            if tabViews.count - 1 >= currentIndex, tabViews.count > 0 {
                make.leading.trailing.equalTo(tabViews[currentIndex])
            } else {
                make.leading.trailing.equalToSuperview()
            }
            
        }
        
        UIView.animate(withDuration: animated ? 0.2 : 0, animations: {
            self.layoutIfNeeded()
        })
    }
    
    private func updateScrollView(animated: Bool) {
        let padding = scrollView.frame.width / 2
        let tabFrame = tabViews[currentIndex].frame
        let scrollFrame = CGRect(x: tabFrame.midX - padding, y: tabFrame.midY,
                                 width: padding * 2, height: tabFrame.height)
        
        scrollView.scrollRectToVisible(scrollFrame, animated: animated)
    }

}

extension TabLayout: TabViewDelegate {
    
    func didSelectTabView(withTag tag: Int) {
        select(index: tag)
        delegate?.didSelect(pageIndex: tag)
    }
}
