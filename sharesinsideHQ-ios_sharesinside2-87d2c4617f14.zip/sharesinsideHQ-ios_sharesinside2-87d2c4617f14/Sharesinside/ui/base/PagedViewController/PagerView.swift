//
//  PagedViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit
import RxSwift

protocol PagerViewDelegate: class {
    func didChangeScrollView(_ scrollView: UIScrollView)
}

protocol PagedViewControllerDelegate: class {
    func pagedScrollView(didScroll scrollView: UIScrollView)
}

internal final class PagerView: BaseView {
    
    weak var delegate: PagerViewDelegate?
    
    var viewControllers: [UIViewController] {
        didSet {
            collectionView.reloadData()
            setupInitialPage()
        }
    }
    
    var contentOffset: CGPoint {
        get { return viewControllers[currentSelectedPage].contentOffset }
        set { viewControllers[currentSelectedPage].contentOffset = newValue }
    }
    
    private let tabBarHeight: CGFloat
    private var initialPage: Int
    private var disposeBag = DisposeBag()
    
    private(set) var currentSelectedPage: Int {
        didSet {
            delegate?.didChangeScrollView(scrollView(from: currentSelectedPage))
        }
    }
    
    private lazy var tabLayout = TabLayout()
    
    private lazy var collectionView: UICollectionView = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.showsVerticalScrollIndicator = false
        collectionView.backgroundColor = .clear
        collectionView.isPagingEnabled = true
        collectionView.bounces = false
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.registerCell(PagerCell.self)
        
        return collectionView
    }()
    
    private lazy var containerStackView: UIStackView =
        .make(axis: .vertical,
              with: [
                tabLayout,
                collectionView
            ])
    
    init(with viewControllers: [UIViewController],
         tabBarHeight: CGFloat = Defaults.defaultTabHeight,
         initialPage: Int = 0) {
        
        self.viewControllers = viewControllers
        self.tabBarHeight = tabBarHeight
        self.initialPage = initialPage
        self.currentSelectedPage = initialPage
        super.init()
        setupInitialPage()
    }
    
    private func setupInitialPage() {
        DispatchQueue.main.async {
            self.collectionView.scrollToItem(at: IndexPath(item: self.initialPage, section: 0),
                                             at: .centeredHorizontally, animated: false)
            self.tabLayout.tabViews = self.viewControllers.compactMap({
                let title = $0.title?.uppercased() ?? ""
                return TabView(withText: title)
            })
            self.tabLayout.select(index: self.initialPage, animated: false)
        }
    }
    
    override func setupViewHierarchy() {
        addSubview(containerStackView)
    }
    
    override func setupConstraints() {
        containerStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        tabLayout.snp.makeConstraints { make in
            make.height.equalTo(tabBarHeight)
        }
    }
    
    override func setupProperties() {
        backgroundColor = .clear
        tabLayout.delegate = self
    }
    
    private func didSwipe(toIndex index: Int) {
        tabLayout.select(index: index)
    }
    
    func setInitialPage(_ newInitalPage: Int) {
        self.initialPage = newInitalPage
        delegate?.didChangeScrollView(scrollView(from: newInitalPage))
        tabLayout.select(index: newInitalPage, animated: false)
        collectionView.reloadData()
    }
    
    func scrollView(from page: Int) -> UIScrollView {
        // Unwrapped because pager child page has to have scrollView
        // Otherwise scrolling algorith in CompaniesDetailsViewController won't work
        return viewControllers[page].scrollView!
    }
}

extension PagerView: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewControllers.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell: PagerCell = collectionView.dequeueReusableCell(for: indexPath) {
            cell.controller = viewControllers[indexPath.row]
            return cell
        }
        
        return UICollectionViewCell()
    }
    
    func reloadPagerCells() {
        collectionView.reloadSections(IndexSet(integer: 0))
        collectionView.scrollToItem(
            at: IndexPath(item: currentSelectedPage, section: 0),
            at: UICollectionView.ScrollPosition.centeredHorizontally,
            animated: true)
    }
}

extension PagerView: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
}

extension PagerView: UIScrollViewDelegate {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let offset = scrollView.contentOffset.x
        let pageWidth = scrollView.contentSize.width / CGFloat(viewControllers.count)
        let currentPagePercentage = offset / pageWidth
        didSwipe(toIndex: Int(currentPagePercentage))
        currentSelectedPage = Int(currentPagePercentage)
    }
}

extension PagerView: TabLayoutDelegate {
    
    func didSelect(pageIndex: Int) {
        currentSelectedPage = pageIndex
        collectionView.scrollToItem(at: IndexPath(item: pageIndex, section: 0),
                                    at: .centeredHorizontally, animated: true)
    }
}

class PagerCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    var controller: UIViewController? {
        didSet {
            guard let controller = controller else { return }
            subviews.forEach { $0.removeFromSuperview() }
            addSubview(controller.view)
            controller.view.snp.makeConstraints { make in
                make.edges.equalToSuperview()
            }
        }
    }
}
