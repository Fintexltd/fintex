//
//  PageTabView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

protocol TabViewDelegate: class {
    func didSelectTabView(withTag tag: Int)
}

internal final class TabView: BaseView {
    
    weak var delegate: TabViewDelegate?
    
    init(withText text: String) {
        super.init()
        label.text = text
        layoutIfNeeded()
    }
    
    var isSelected = false {
        didSet {
            label.textColor = isSelected ? .accent : .grey
        }
    }
    
    private lazy var label = UILabelFactory.styled(withFontSize: Defaults.TextSize.small, fontWeight: .bold)
    
    private lazy var button: UIButton = {
        let button = UIButton()
        return button
    }()
    
    override func setupViewHierarchy() {
        addSubview(label)
        addSubview(button)
    }
    
    override func setupConstraints() {
        label.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginSmall)
            make.centerY.equalToSuperview()
        }
        
        button.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    override func setupProperties() {
        backgroundColor = .clear
        button.addTarget(self, action: #selector(tabViewDidTouch), for: .touchUpInside)
    }
    
    @objc private func tabViewDidTouch() {
        delegate?.didSelectTabView(withTag: tag)
    }
}
