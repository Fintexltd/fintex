//
//  BaseViewController.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit
import SnapKit
import RxCocoa
import RxSwift

protocol ReinitializableViewController: class {
    func reinitializeView(with id: Int)
}

protocol ViewController: class {
    
    var segueData: Any? { get }
    
    var alert: Alert { get set }
    
    var loader: LoaderView {get set }
    
    var router: Router {get set}
    
    var app: AppDelegate { get set }
    
    var hasLoadedView: BehaviorRelay<Bool> {get set}
    
    var topViewController: ViewController { get }
}

class BaseViewController<ProvidedViewModel: ViewModel>: UIViewController, ViewController {
    
    let disposeBag = DisposeBag()
    var segueData: Any?
    var alert: Alert = AlertView()
    var loader = LoaderView()
    lazy var router = Router(viewController: self)

    lazy var viewModel: ProvidedViewModel = {
        return ViewModelProvider.provide(for: ProvidedViewModel.self, withApp: app)
    }()
    
    var app = UIApplication.shared.delegate as! AppDelegate
    
    var hasLoadedView = BehaviorRelay<Bool>(value: false)
    
    var topViewController: ViewController {
        let presentedViewController = navigationController?.presentedViewController
        if let navigation = presentedViewController as? UINavigationController,
            let topController = navigation.topViewController as? ViewController {
            return topController
        }
        
        return (presentedViewController as? ViewController) ?? self
    }
    
    override var navigationController: BaseNavigationController? {
        return super.navigationController as? BaseNavigationController
    }
    
    // MARK: Lifecycle methods    
    override func loadView() {
        self.view = UIView()
        self.view.backgroundColor = .accent
        setupView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bindRxLifecycle()
        passDataToViewModel()
        initializeView()
        localize()
        bindViewModel()
        viewModel.onViewDidLoad()
        setupBackButton()
        setupLoader()
        hasLoadedView.accept(true)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShowSelector),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHideSelector),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.onViewWillAppear()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewModel.onViewDidAppear()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.onViewWillDisappear()
    }
    
    // MARK: Methods to override
    func setupView() {
        preconditionFailure("This method must be overridden")
    }
    
    func bindViewModel() {
        viewModel.alert.asDriver()
            .ignoreNil()
            .drive(onNext: { [weak self] alertData in
                self?.alert.showDefault(in: self, withData: alertData)
        }).disposed(by: disposeBag)
        
        viewModel.loading.asDriver()
            .drive(onNext: { [weak self] isLoading in
                self?.loader.toggle(show: isLoading, dimmedBackground: true)
            }).disposed(by: disposeBag)
    }
    
    func bindRxLifecycle() {}
    
    func initializeView() { }
    
    func localize() { }
    
    func passDataToViewModel() {
        viewModel.router = router
    }
    
    func setupLoader() {
        self.view.addSubview(loader)
        loader.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    func keyboardWillShow(withHeight height: CGFloat) { }
    
    func keyboardWillHide() { }
    
    // MARK: Keyboard notifications
    @objc fileprivate func keyboardWillShowSelector(notification: NSNotification) {
        guard let userInfo = notification.userInfo,
            let value = userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue else { return }
        var keyboardFrame: CGRect = value.cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        let height = keyboardFrame.size.height
        keyboardWillShow(withHeight: height)
    }
    
    @objc fileprivate func keyboardWillHideSelector(notification: NSNotification) {
        keyboardWillHide()
    }
}

// MARK: Common methods
extension BaseViewController {
    
    func setupBackButton(withTitle title: String = "") {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: title, style: .plain, target: nil, action: nil)
    }
    
    func embed(viewController: UIViewController, insideView containerView: UIView) {
        addChild(viewController)
        containerView.addSubview(viewController.view)
        viewController.view.snp.makeConstraints { (make) in
            make.edges.equalTo(containerView)
        }
        viewController.didMove(toParent: self)
    }
}
