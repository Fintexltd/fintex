//
//  BaseView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.07.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

internal class BaseView: UIView {
    
    @available(*, unavailable) required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init() {
        super.init(frame: .zero)
        layoutable()
        initializeView()
        setupViewHierarchy()
        setupConstraints()
        setupProperties()
    }
    
    func initializeView() {}
    
    func setupViewHierarchy() {}
    
    func setupConstraints() {}
    
    func setupProperties() {}
    
    override static var requiresConstraintBasedLayout: Bool {
        return true
    }
}
