//
//  Router.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 20.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol NotificationRouter: class {
    func push(with notification: PushNotification, forced: Bool)
    func present(with notification: PushNotification, forced: Bool)
    func dismissNavigationController(animated: Bool)
}

enum Destination {
    case welcome
    case auth(pageType: AuthPage, linkedinUserData: LinkedInRegisterUserData?)
    case linkedInAuth(page: LinkedInAuthPage, delegate: LinkedInAuthViewControllerDelegate?)
    case information(informationType: InformationType)
    case documents(type: DocumentType)
    case main
    case companyDetails(companyId: Int)
    case fundManagerDetails(fundManagerId: Int)
    case fundManagerDocumentsDetails(fundManagerId: Int, section: FundManagerDocumentSection)
    case fundDetails(fundId: Int)
    case startupDetails(startupId: Int)
    case filters(filterTypes: [FilterType], initialFilters: AdvancedFilters, delegate: FiltersDelegate)
    case singleFilter(filter: FilterSection, delegate: SingleFiltersDelegate)
    case allEmployees(employeesGroup: EmployeesGroup, delegate: EmployeesDelegate)
    case allShareprices(shareprices: [Symbol])
    case employeeDetails(employee: Employee, employerData: EmployerData?)
    case historicalDataSection(legalEntity: LegalEntity, sectionId: Int, sectionTitle: String)
    case newsDetails(newsId: Int)
    case eventDetails(eventId: Int)
    case projectDetails(projectId: Int)
    case profile
    case notificationSettings
    case assignAsShareholder(companyAbout: CompanyAbout, delegate: AssignAsShareholderViewControllerDelegate?)
    case assignAsInvestor(investmentType: InvestmentType, delegate: AssignAsInvestorViewControllerDelegate?)
    case watchlist
    case relations(delegate: RelationsCountHandler?)
    case requests(delegate: RelationsCountHandler?)
    case activateRelation(_ relation: RelationRequest)
    case albumDetails(album: Album, legalEntityName: String)
    case search(filters: AdvancedFilters?, delegate: SearchViewControllerDelegate)
    case locationSearch(initialLocation: String?, delegate: LocationSearchDelegate)
    case notifications
    case failure(message: String)
    case photoPreview(legalEntityName: String, photos: [Photo], initialIndex: Int)
}

enum RouteFlag {
    case none
    case popCurrent
    case popAll
}

class Router {

    private weak var viewController: UIViewController?

    init(viewController: UIViewController?) {
        self.viewController = viewController
    }

    func push(to destination: Destination, animated: Bool = true, forcePush: Bool = false, routeFlag: RouteFlag = .none) {
        let destinationViewController = destination.viewController
        guard let viewController = viewController, !viewController.isKind(of: destinationViewController.classForCoder) || forcePush else { return }

        guard let navigationController = viewController.navigationController as? BaseNavigationController ?? viewController.tabBarController?.moreNavigationController else {
            viewController.present(destinationViewController, animated: animated, completion: nil)
            return
        }

        navigationController.push(viewController: destinationViewController, animated: animated) {
            switch routeFlag {
            case .popCurrent: navigationController.remove(viewController: viewController)
            case .popAll: navigationController.removeOthers()
            default: break
            }
        }
    }

    func pop(animated: Bool = true, toDestination destination: Destination? = nil) {
        guard let navigationController = viewController?.navigationController else {
            viewController?.dismiss(animated: animated, completion: nil)
            return
        }

        if let destination = destination,
            let viewControllerToShow = navigationController.controllerOnStack(withType: destination.controllerClass) {
            navigationController.popToViewController(viewControllerToShow, animated: animated)
        } else if navigationController.viewControllers.count == 1 {
            navigationController.dismiss(animated: animated)
        } else {
            navigationController.popViewController(animated: animated)
        }
    }

    func replace(with destination: Destination, animated: Bool = true) {
        UIApplication.shared.keyWindow?.setRootViewController(
            destination.viewController,
            options: UIWindow.TransitionOptions(direction: .fromRight, style: .easeInOut)
        )
    }

    func present(destination: Destination, animated: Bool = true) {
        let destinationViewController = destination.viewController
        guard let viewController = viewController, !viewController.isKind(of: destinationViewController.classForCoder) else { return }

        let navigationDestinationController = BaseNavigationController(rootViewController: destinationViewController)
        guard let navigationController = viewController.navigationController as? BaseNavigationController else {
            viewController.present(navigationDestinationController, animated: animated, completion: nil)
            return
        }
        navigationController.present(navigationDestinationController, animated: animated)
    }
}

extension Router: NotificationRouter {
   
    func dismissNavigationController(animated: Bool = true) {
        if let navigationController = viewController?.navigationController {
            navigationController.dismiss(animated: true, completion: nil)
        }
    }

    func push(with notification: PushNotification, forced: Bool) {
        guard
            let destinationViewController = notification.destination?.viewController,
            let viewController = viewController,
            !viewController.isKind(of: destinationViewController.classForCoder),
            let navigationController = viewController.navigationController as? BaseNavigationController
        else { return }

        navigationController.push(viewController: destinationViewController, animated: !forced) {
            viewController.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        }
    }

    func present(with notification: PushNotification, forced: Bool) {
        guard
            let destinationViewController = notification.destination?.viewController,
            let viewController = viewController,
            !viewController.isKind(of: destinationViewController.classForCoder)
        else { return }

        let navigationDestinationController = BaseNavigationController(rootViewController: destinationViewController)

        guard let navigationController = viewController.navigationController as? BaseNavigationController else {
            viewController.present(navigationDestinationController, animated: !forced)
            return
        }
        navigationController.present(navigationDestinationController, animated: !forced)
    }

    private func showInformationAlert(in vc: UIViewController, message: String?) {
        if let viewController = vc as? ViewController {
            viewController.alert.showDefault(in: vc, withData: AlertData(message: message))
        }
    }
}

extension Destination {

    var viewController: UIViewController {
        switch self {
        case .welcome: return WelcomeViewController()
        case .auth(let pageType, let userData): return AuthViewController(authPage: pageType, linkedinUserData: userData)
        case .linkedInAuth(let page, let delegate): return LinkedInAuthViewController(page: page, delegate: delegate)
        case .documents(let type): return DocumentsViewController(type: type)
        case .main: return MainTabBarController()
        case .information(let informationType): return InformationViewController(informationDataType: informationType)
        case .companyDetails(let companyId): return CompanyDetailsViewController(companyId: companyId)
        case .startupDetails(let startupId): return StartupDetailsViewController(startupId: startupId)
        case .fundManagerDetails(let fundManagerId): return FundManagerDetailsViewController(fundManagerId: fundManagerId)
        case .filters(let filterTypes, let initialFilters, let delegate): return FiltersViewController(filterTypes: filterTypes, initialFilters: initialFilters, delegate: delegate)
        case .singleFilter(let filter, let delegate): return SingleFiltersViewController(filter: filter, delegate: delegate)
        case .allEmployees(let employeesGroup, let delegate): return AllEmployeesViewController(group: employeesGroup, delegate: delegate)
        case .allShareprices(let shareprices): return AllSharepricesViewController(shareprices: shareprices)
        case .employeeDetails(let employee, let employerData): return EmployeeDetailsViewController(employee: employee, employerData: employerData)
        case .historicalDataSection(let legalEntity, let sectionId, let sectionTitle):
            return HistoricalDataSectionViewController(legalEntity: legalEntity, sectionId: sectionId, sectionTitle: sectionTitle)
        case .newsDetails(let newsId): return NewsViewController(withNewsId: newsId)
        case .eventDetails(let eventId): return EventViewController(eventId: eventId)
        case .projectDetails(let projectId): return ProjectViewController(withProjectId: projectId)
        case .profile: return ProfileViewController()
        case .notificationSettings: return NotificationSettingsViewController()
        case .assignAsShareholder(let companyAbout, let delegate): return AssignAsShareholderViewController(companyAbout: companyAbout, delegate: delegate)
        case .assignAsInvestor(let investmentType, let delegate): return AssignAsInvestorViewController(investmentType: investmentType, delegate: delegate)
        case .watchlist: return WatchlistViewController()
        case .relations(let delegate): return RelationsViewController(delegate: delegate)
        case .requests(let delegate): return RequestsViewController(delegate: delegate)
        case .activateRelation(let request): return RelationActivationViewController(of: request)
        case .albumDetails(let album, let legalEntityName): return AlbumDetailsViewController(album: album, legalEntityName: legalEntityName)
        case .search(let filters, let delegate): return SearchViewController(filters: filters, delegate: delegate)
        case .locationSearch(let initialLocation, let delegate): return LocationSearchViewController(initialLocation: initialLocation, delegate: delegate)
        case .notifications: return NotificationsViewController()
        case .failure(let message): return FailureViewController(message: message)
        case .photoPreview(let legalEntityName,
                           let photos,
                           let initialIndex): return PhotoPreviewViewController(withLegalEntityName: legalEntityName,
                                                                                initialPhotoIndex: initialIndex,
                                                                                andPhotos: photos)
        case .fundDetails(let fundId):
            return FundDetailsViewController(fundId: fundId)
        case .fundManagerDocumentsDetails(let fundManagerId, let section):
            return FundManagerDocumentsDetailsViewController(fundManagerId: fundManagerId, section: section)
        }
    }

    var controllerClass: AnyClass {
        switch self {
        case .welcome: return WelcomeViewController.self
        case .auth: return AuthViewController.self
        case .linkedInAuth: return LinkedInAuthViewController.self
        case .documents: return DocumentsViewController.self
        case .main: return MainTabBarController.self
        case .information: return InformationViewController.self
        case .companyDetails: return CompanyDetailsViewController.self
        case .fundManagerDetails: return FundManagerDetailsViewController.self
        case .filters: return FiltersViewController.self
        case .singleFilter: return SingleFiltersViewController.self
        case .allEmployees: return AllEmployeesViewController.self
        case .allShareprices: return AllSharepricesViewController.self
        case .employeeDetails: return EmployeeDetailsViewController.self
        case .historicalDataSection: return HistoricalDataSectionViewController.self
        case .newsDetails: return NewsViewController.self
        case .eventDetails: return EventViewController.self
        case .projectDetails: return ProjectViewController.self
        case .profile: return ProfileViewController.self
        case .notificationSettings: return NotificationSettingsViewController.self
        case .assignAsShareholder: return AssignAsShareholderViewController.self
        case .assignAsInvestor: return AssignAsInvestorViewController.self
        case .watchlist: return WatchlistViewController.self
        case .relations: return RelationsViewController.self
        case .requests: return RequestsViewController.self
        case .activateRelation: return RelationActivationViewController.self
        case .albumDetails: return AlbumDetailsViewController.self
        case .search: return SearchViewController.self
        case .locationSearch: return LocationSearchViewController.self
        case .notifications: return NotificationsViewController.self
        case .failure: return FailureViewController.self
        case .photoPreview: return PhotoPreviewViewController.self
        case .fundDetails: return FundDetailsViewController.self
        case .startupDetails: return StartupDetailsViewController.self
        case .fundManagerDocumentsDetails: return FundManagerDocumentsDetailsViewController.self
        }
    }
}
