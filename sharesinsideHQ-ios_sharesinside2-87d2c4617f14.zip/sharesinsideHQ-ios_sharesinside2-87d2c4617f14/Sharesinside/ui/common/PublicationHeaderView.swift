//
//  PublicationHeaderView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher
import SnapKit

protocol PublicationHeaderDelegate: class {
    func didTapPublicationHeader(_ publicationHeader: PublicationHeaderView)
    func didTapShareButton(_ publicationHeader: PublicationHeaderView)
}

class PublicationHeaderView: UIView {
    
    weak var delegate: PublicationHeaderDelegate?
    
    private var companyLabelToSuperviewTrailing: Constraint?
    private var shareButtonToCompanyLabelLeading: Constraint?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initializeView()
    }
    
    func configure(with publication: Publication) {
        loadLogo(with: publication.logoUrl)
        let isAdHoc = (publication as? News)?.details.isAdHoc ?? false
        companyTitle.attributedText = attributedTitleWith(companyName: publication.issuerName,
                                                          type: publication.type,
                                                          isAdHoc: isAdHoc)
        
        userGroups.configure(withUserGroups: publication.userGroups.publicationGroups.map({ $0.title }))
        if let publishDate = publication.publishDate {
            dateLabel.text = publishDate.prettyPrintedWatchlist
        }
        
        if publication.type == .news || publication.type == .project {
            setupShareButton()
        }
        companyLabelToSuperviewTrailing?.isActive = publication.type == .event || publication.type == .project
        shareButtonToCompanyLabelLeading?.isActive = publication.type == .news || publication.type == .project
    }
    
    func configure(with news: NewsInformation) {
        loadLogo(with: news.logoUrl)
        companyTitle.attributedText = attributedTitleWith(companyName: news.issuerName,
                                                          type: .news,
                                                          isAdHoc: news.isAdHoc ?? false)
        
        userGroups.configure(withUserGroups: news.userGroups.publicationGroups.map({ $0.title }))
        dateLabel.text = news.publishDate?.prettyPrintedWatchlist
    }
    
    func configure(with event: EventInformation) {
        loadLogo(with: event.logoUrl)
        companyTitle.attributedText = attributedTitleWith(companyName: event.issuerName,
                                                          type: .event,
                                                          isAdHoc: false)
        
        userGroups.configure(withUserGroups: event.userGroups.publicationGroups.map({ $0.title }))
        dateLabel.text = event.publishDate?.prettyPrintedWatchlist
    }

    func configure(with project: ProjectInformation) {
        loadLogo(with: project.logoUrl)
        companyTitle.attributedText = attributedTitleWith(companyName: project.issuerName,
                                                          type: .project,
                                                          isAdHoc: false)

        userGroups.configure(withUserGroups: project.userGroups.publicationGroups.map({ $0.title }))
        dateLabel.text = project.publishDate?.prettyPrintedWatchlist
    }
    
    func configureShorted(with publication: Publication) {
        loadLogo(with: publication.logoUrl)
        companyTitle.attributedText = attributedPublicationType(publication.type)
    }
    
    private func loadLogo(with logoUrl: URL?) {
        if let logoUrl = logoUrl {
            companyLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl),
                                    options: [.backgroundDecode])
        }
    }
    
    // MARK: View
    let companyLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        imageView.backgroundColor = .white
        
        return imageView
    }()
    
    let companyTitle: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey,
                                          withFontSize: Defaults.TextSize.medium,
                                          fontWeight: .bold)
        label.textAlignment = .left
        label.backgroundColor = .white
        return label
    }()
    
    let shareButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "share"), for: .normal)
        button.imageEdgeInsets = UIEdgeInsets(top: Defaults.shareButtonImageInset,
                                              left: Defaults.shareButtonImageInset,
                                              bottom: Defaults.shareButtonImageInset,
                                              right: Defaults.shareButtonImageInset)
        return button
    }()
    
    let dateLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.small)
        label.numberOfLines = 1
        label.textAlignment = .left
        label.backgroundColor = .white
        return label
    }()
    
    let userGroups = ChipCollectionView()
    
    lazy var tagsStackView = UIStackView.make(
        axis: .horizontal,
        with: [
            dateLabel,
            userGroups
        ],
        spacing: Defaults.marginTiny)
    
    private func initializeView() {
        layoutable()
        setupProperties()
        setupViewHierarchy()
        setupConstraints()
    }
    
    private func setupProperties() {
        self.setupGestureRecognizer(target: self, selector: #selector(didTapPublicationHeader))
        userGroups.setupGestureRecognizer(target: self, selector: #selector(didTapUserGroups))
        shareButton.addTarget(self, action: #selector(didTapShareButton), for: .touchUpInside)
    }
    
    @objc func didTapPublicationHeader() {
        delegate?.didTapPublicationHeader(self)
    }
    
    @objc func didTapUserGroups() {
        delegate?.didTapPublicationHeader(self)
    }
    
    @objc func didTapShareButton() {
        delegate?.didTapShareButton(self)
    }
    
    private func setupViewHierarchy() {
        [companyLogo, companyTitle, tagsStackView].forEach { addSubview($0) }
    }
    
    private func setupConstraints() {
        companyLogo.snp.makeConstraints { make in
            make.leading.top.equalToSuperview()
            make.width.equalTo(Defaults.Company.logoSize)
            make.height.equalTo(companyLogo.snp.width).multipliedBy(1).priority(.highest)
            make.bottom.lessThanOrEqualToSuperview()
        }
        
        companyTitle.snp.makeConstraints { make in
            make.leading.equalTo(companyLogo.snp.trailing).offset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().priority(.highest)
            companyLabelToSuperviewTrailing = make.trailing.equalToSuperview().priority(.highest).constraint
        }
        
        tagsStackView.snp.makeConstraints { make in
            make.top.equalTo(companyTitle.snp.bottom).offset(Defaults.marginSmall)
            make.leading.equalTo(companyLogo.snp.trailing).offset(Defaults.marginNormal).priority(.highest)
            make.trailing.bottom.equalToSuperview()
        }
    }
    
    private func setupShareButton() {
        addSubview(shareButton)
        
        shareButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(Defaults.marginSmallest).priority(.highest)
            make.trailing.equalToSuperview().priority(.highest)
            make.width.equalTo(Defaults.shareButtonWidht).priority(.highest)
            make.height.equalTo(Defaults.shareButtonHeight).priority(.highest)
            shareButtonToCompanyLabelLeading = make.leading.equalTo(companyTitle.snp.trailing).offset(Defaults.marginMicro).priority(.highest).constraint
        }
    }
}

extension PublicationHeaderView {
    
    private func attributedTitleWith(companyName: String,
                                     type: PublicationType,
                                     isAdHoc: Bool) -> NSMutableAttributedString {
        let attributedTitle = attributedCompanyTitle(companyName)
        attributedTitle.append(NSAttributedString(string: " "))
        attributedTitle.append(attributedPublishedFlag())
        attributedTitle.append(NSAttributedString(string: " "))
        attributedTitle.append(attributedPublicationType(type))
        
        if isAdHoc {
            attributedTitle.append(NSAttributedString(string: " "))
            attributedTitle.append(attributedAdHocFlag())
        }
        
        return attributedTitle
    }
    
    private func attributedCompanyTitle(_ title: String) -> NSMutableAttributedString {
        return NSMutableAttributedString(string: title, attributes: [
            .font: UIFont.systemFont(ofSize: Defaults.TextSize.medium, weight: .bold),
            .foregroundColor: UIColor.darkGrey
            ])
    }
    
    private func attributedPublishedFlag() -> NSMutableAttributedString {
        return NSMutableAttributedString(string: Localizable.watchlistPublished.localized, attributes: [
            .font: UIFont.systemFont(ofSize: Defaults.TextSize.medium),
            .foregroundColor: UIColor.grey
            ])
    }
    
    private func attributedPublicationType(_ publicationType: PublicationType) -> NSMutableAttributedString {
        let textColor: UIColor
        switch publicationType {
        case .event:
            textColor = .event
        case .project:
            textColor = .project
        case .news:
            textColor = .news
        }
        let font = UIFont.systemFont(ofSize: Defaults.TextSize.medium)
        
        return NSMutableAttributedString(string: publicationType.title, attributes: [
            .font: font.boldItalic() ?? font,
            .foregroundColor: textColor
            ])
    }
    
    private func attributedAdHocFlag() -> NSMutableAttributedString {
        let font = UIFont.systemFont(ofSize: Defaults.TextSize.medium)
        return NSMutableAttributedString(string: Localizable.watchlistAdhoc.localized.uppercased(), attributes: [
            .font: font.boldItalic() ?? font,
            .foregroundColor: UIColor.primaryDark
            ])
    }
    
    func countLabelLines(label: UILabel) -> Int {
        self.layoutIfNeeded()
        let myText = label.text! as NSString
        
        let rect = CGSize(width: label.bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let labelSize = myText.boundingRect(with: rect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: label.font], context: nil)
        
        return Int(ceil(CGFloat(labelSize.height) / label.font.lineHeight))
    }
}
