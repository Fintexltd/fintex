//
//  SharesinsideSearchBar.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 02/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class SISearchBar: UISearchBar {
    
    override func willMove(toSuperview newSuperview: UIView?) {
        super.willMove(toSuperview: newSuperview)

        searchBarStyle = UISearchBar.Style.minimal
        sizeToFit()
        placeholder = Localizable.companiesPlaceholderSearch.localized
        tintColor = .gray

        let optionalTextField: UITextField?
        if #available(iOS 13.0, *) {
            optionalTextField = searchTextField
        } else {
            optionalTextField = value(forKey: "_searchField") as? UITextField
        }
        guard let textField = optionalTextField else { return }
        
        textField.borderStyle = .none
        textField.clipsToBounds = true
        textField.backgroundColor = .white
        textField.textColor = .darkText
        textField.tintColor = .primary
        textField.layer.cornerRadius = Defaults.Navigation.searchCornerRadius
        textField.leftView?.contentMode = .scaleAspectFit
        textField.leftView?.tintColor = .gray
        
        if #available(iOS 11.0, *) {
            textField.leftView?.frame = CGRect(x: 0,
                                               y: 0,
                                               width: (textField.leftView?.frame.width ?? 0) + Defaults.marginSmall,
                                               height: textField.leftView?.frame.height ?? 0)
        }
    }
}
