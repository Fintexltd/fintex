//
//  LoaderView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 17.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import JTMaterialSpinner

protocol Loader {
    func toggle(show: Bool, dimmedBackground: Bool, withMessage message: String?)
    var isSpinning: Bool { get set }
}

class LoaderView: UIView {
    
    var spinnerView = JTMaterialSpinner()
    
    fileprivate var isSpinnerActive: Bool = false {
        didSet {
            if isSpinnerActive {
                animate(toAlpha: 1, withDuration: 0)
                spinnerView.beginRefreshing()
            } else {
                animate(toAlpha: 0)
                spinnerView.endRefreshing()
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        addSubview(spinnerView)
        
        spinnerView.circleLayer.strokeColor = UIColor.primary.cgColor
        spinnerView.circleLayer.lineWidth = Defaults.loaderStrokeWidth
        spinnerView.animationDuration = 1.5
        
        spinnerView.snp.makeConstraints { make in
            make.leading.top.greaterThanOrEqualToSuperview()
            make.trailing.bottom.lessThanOrEqualToSuperview()
            make.height.equalTo(Defaults.defaultLoaderSize).priority(.low)
            make.width.equalTo(spinnerView.snp.height)
            make.center.equalToSuperview()
        }
    }
    
    private func animate(toAlpha alpha: CGFloat, withDuration duration: Double = 0.5) {
        superview?.bringSubviewToFront(self)
        UIView.animate(withDuration: duration, animations: {
            self.alpha = alpha
        }) { _ in
            if alpha == 0 { self.superview?.sendSubviewToBack(self) }
        }
    }
}

extension LoaderView: Loader {
    
    var isSpinning: Bool {
        get { return isSpinnerActive }
        set { isSpinnerActive = newValue }
    }
    
    func toggle(show: Bool,
                dimmedBackground: Bool = false,
                withMessage message: String? = nil) {
        isSpinnerActive = show
        self.backgroundColor = dimmedBackground ?
            UIColor.grey.withAlpha(Defaults.disabledAlpha) : UIColor.clear
    }
}
