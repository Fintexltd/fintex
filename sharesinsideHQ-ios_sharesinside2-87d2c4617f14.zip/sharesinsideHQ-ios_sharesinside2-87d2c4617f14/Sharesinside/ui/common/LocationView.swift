//
//  LocationView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import GoogleMaps

class LocationView: BaseView {
    
    func setup(withAddress address: String, longitude: Double, latitude: Double) {
        let map = mapView(withLatitude: latitude, longitude: longitude)
        contentStackView.insertArrangedSubview(map, at: 1)
        addressLabel.text = address
        
        let position = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        let marker = GMSMarker(position: position)
        marker.icon = #imageLiteral(resourceName: "IconMarker")
        marker.map = map
        
        map.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Publication.mapHeight)
        }
    }
    
    override func initializeView() {
        
    }
    
    override func setupViewHierarchy() {
        addSubview(contentStackView)
    }
    
    override func setupConstraints() {
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        locationLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(Defaults.marginBig)
            make.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
        }
        
        addressLabel.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview().inset(Defaults.marginBig)
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
    }
    
    private let locationLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .grey,
                                          withFontSize: Defaults.TextSize.medium,
                                          fontWeight: .regular)
        label.textAlignment = .left
        label.text = Localizable.publicationLocation.localized
        return label
    }()
    
    private let addressLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .darkGrey,
                                          withFontSize: Defaults.TextSize.medium)
        label.textAlignment = .left
        return label
    }()
    
    private func mapView(withLatitude latitude: Double, longitude: Double) -> GMSMapView {
        let camera = GMSCameraPosition.camera(withLatitude: latitude,
                                              longitude: longitude,
                                              zoom: 10)
        let mapView = GMSMapView.map(withFrame: CGRect.zero, camera: camera)

        do {
            if let styleURL = Bundle.main.url(forResource: "MapStyle", withExtension: "json") {
                mapView.mapStyle = try GMSMapStyle(contentsOfFileURL: styleURL)
            } else {
                printDebug("Unable to find style.json")
            }
        } catch {
            printDebug("One or more of the map styles failed to load. \(error)")
        }
        
        return mapView
    }
    
    private lazy var contentStackView: UIStackView = .make(
        axis: .vertical,
        with: [
            locationLabel.embedInView(),
            addressLabel.embedInView()
        ])
}
