//
//  TermsAndConditionsDialogViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 08/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit

final class TermsAndConditionsDialogViewController: UIViewController {

    private let link: String
    private let successHandler: (() -> Void)?
    private let failureHandler: (() -> Void)?

    init(link: String, successHandler: (() -> Void)?, failureHandler: (() -> Void)?) {
        self.link = link
        self.successHandler = successHandler
        self.failureHandler = failureHandler
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func loadView() {
        self.view = UIView()
        view.backgroundColor = .clear
        let contentView = TermsAndConditionsDialogView()
        contentView.didTapNegativeButton = { [weak self] in
            self?.presentingViewController?.dismiss(animated: false)
            self?.failureHandler?()
        }
        contentView.didTapPositiveButton = { [weak self] in
            self?.presentingViewController?.dismiss(animated: false)
            self?.successHandler?()
        }
        contentView.didTapUrl = { [unowned self] url in
            self.open(url: url)
        }
        contentView.link = link
        view.addSubview(contentView)
        contentView.snp.makeConstraints { make in
            make.centerX.centerY.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(AppInfo.isIPhone ? 0.7 : 0.5)
        }
    }
}
