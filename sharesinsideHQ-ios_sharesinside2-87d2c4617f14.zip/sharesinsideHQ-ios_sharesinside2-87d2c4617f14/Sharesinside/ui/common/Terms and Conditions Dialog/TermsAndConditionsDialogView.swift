//
//  TermsAndConditionsDialogView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 08/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import UIKit
import TTTAttributedLabel

final class TermsAndConditionsDialogView: BaseView {

    var didTapUrl: ((URL) -> Void)?
    var didTapPositiveButton: (() -> Void)?
    var didTapNegativeButton: (() -> Void)?

    var link: String? {
        didSet {
            textLabel.text = "You have to accept <a href=\"\(link ?? "")\">terms and conditions</a> before following this fund.".attributedFromHtml?.withSystemFont(ofSize: Defaults.TextSize.medium)
        }
    }

    private let contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = CGSize(width: 5, height: 5)
        view.layer.shadowRadius = 20
        view.layer.masksToBounds = false
        return view
    }()

    private lazy var contentStackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [textLabel, buttonsStackView])
        stackView.axis = .vertical
        stackView.layoutMargins = UIEdgeInsets(top: Defaults.marginNormal, left: Defaults.marginNormal, bottom: Defaults.marginNormal, right: Defaults.marginNormal)
        stackView.isLayoutMarginsRelativeArrangement = true
        stackView.spacing = Defaults.marginTiny
        return stackView
    }()

    private lazy var buttonsStackView: UIStackView = {
        let stackView = UIStackView(arrangedSubviews: [negativeButton, positiveButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        return stackView
    }()

    private let textLabel: TTTAttributedLabel = {
        let label = TTTAttributedLabel(frame: .zero)
        label.numberOfLines = 0
        label.isUserInteractionEnabled = true
        label.enabledTextCheckingTypes = NSTextCheckingResult.CheckingType.link.rawValue
        return label
    }()

    private lazy var positiveButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Accept", for: .normal)
        button.setTitleColor(.primaryDark, for: .normal)
        button.contentHorizontalAlignment = .center
        button.addTarget(self, action: #selector(didTapPositive), for: .touchUpInside)
        return button
    }()

    private lazy var negativeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Cancel", for: .normal)
        button.setTitleColor(.primaryDark, for: .normal)
        button.contentHorizontalAlignment = .center
        button.addTarget(self, action: #selector(didTapNegative), for: .touchUpInside)
        return button
    }()

    override func setupViewHierarchy() {
        super.setupViewHierarchy()
        addSubview(contentView)
        contentView.addSubview(contentStackView)
        textLabel.delegate = self
    }

    override func setupConstraints() {
        super.setupConstraints()
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        contentStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }

    @objc func didTapPositive() {
        didTapPositiveButton?()
    }

    @objc func didTapNegative() {
        didTapNegativeButton?()
    }
}

extension TermsAndConditionsDialogView: TTTAttributedLabelDelegate {
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        didTapUrl?(url)
    }
}
