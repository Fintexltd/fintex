//
//  AttachmentsViewCreator.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class AttachmentsViewCreator: BaseViewCreator {
    
    var titleLabel: UILabel = {
        let label = UILabelFactory
            .styled(
                textColor: .grey,
                withFontSize: Defaults.TextSize.medium,
                fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()
    
    var attachmentsStackView: UIStackView = {
        let stackView = UIStackView.make(
            axis: .horizontal,
            with: [],
            spacing: Defaults.marginSmall)
        return stackView
    }()
    
    var attachmentsScrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.alwaysBounceVertical = false
        
        scrollView.contentInset = UIEdgeInsets(top: 0,
                                               left: Defaults.marginNormal,
                                               bottom: 0,
                                               right: Defaults.marginNormal)
        return scrollView
    }()
    
    override func setupViewHierarchy() {
        attachmentsScrollView.addSubview(attachmentsStackView)
        [titleLabel, attachmentsScrollView].forEach { parentView.addSubview($0) }
    }
    
    override func setupConstraints() {
        titleLabel.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
        }

        attachmentsStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.height.equalToSuperview()
        }

        attachmentsScrollView.snp.makeConstraints { make in
            make.top.equalTo(titleLabel.snp.bottom)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().inset(Defaults.marginSmall)
        }
    }
}
