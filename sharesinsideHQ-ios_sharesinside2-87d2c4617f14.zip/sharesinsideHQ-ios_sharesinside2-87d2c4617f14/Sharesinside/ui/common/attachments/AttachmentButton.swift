//
//  LinkButton.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//
import UIKit

class AttachmentButton: BaseButton {
    
    var attachment: AttachmentType? {
        didSet {
            guard let attachment = attachment else { return }
            textLabel.text = attachment.name
            iconImageView.image = iconFor(type: attachment.iconType)
        }
    }
    
    private var textLabel: UILabel = {
        let label = UILabelFactory.styled(
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .semibold)
        label.textAlignment = .left
        return label
    }()
    
    private var iconImageView: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override func setAttributedTitle(_ title: NSAttributedString?, for state: UIControl.State) {
        textLabel.attributedText = title
    }
    
    override func setTitle(_ title: String?, for state: UIControl.State) {
        textLabel.text = title
    }
    
    override func setImage(_ image: UIImage?, for state: UIControl.State) {
        iconImageView.image = image
    }
    
    override func setupColors() {
        textLabel.textColor = .primary
        iconImageView.tintColor = .primary
        iconImageView.backgroundColor = .white
        backgroundColor = .white
    }
    
    override func setupViewHierarchy() {
        [textLabel, iconImageView].forEach { addSubview($0) }
    }
    
    override func setupConstraints() {
        setupImageViewConstraints()
        setupLabelConstraints()
    }
    
    private func setupImageViewConstraints() {
        iconImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview()
            make.height.width.equalTo(Defaults.attachmentIconSize)
        }
    }
    
    private func setupLabelConstraints() {
        textLabel.snp.makeConstraints { make in
            make.leading.equalTo(iconImageView.snp.trailing).offset(Defaults.marginMicro)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.trailing.equalToSuperview()
        }
    }
    
    private func iconFor(type: String) -> UIImage? {
        if type.starts(with: Defaults.AttachmentType.image) { return #imageLiteral(resourceName: "IconPicture") }
        if type.starts(with: Defaults.AttachmentType.video) { return #imageLiteral(resourceName: "IconVideo") }
        if type.contains(Defaults.AttachmentType.defaultType) ||
            type.contains(Defaults.AttachmentType.archivedVideo) ||
            type.contains(Defaults.AttachmentType.webcast) { return #imageLiteral(resourceName: "IconLink") }
        return #imageLiteral(resourceName: "IconFile")
    }
    
}
