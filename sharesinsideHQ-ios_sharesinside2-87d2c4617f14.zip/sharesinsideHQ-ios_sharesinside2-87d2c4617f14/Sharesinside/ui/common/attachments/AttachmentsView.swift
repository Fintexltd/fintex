//
//  AttachmentsView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol AttachmentsViewDelegate: class {
    func attachmentButtonDidTouch(button: AttachmentButton)
}

class AttachmentsView: UIView {
    
    weak var delegate: AttachmentsViewDelegate?
    
    private lazy var viewCreator = AttachmentsViewCreator(withParentView: self)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initializeView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
    private func initializeView() {
        layoutable()
        viewCreator.setupView()
        layoutIfNeeded()
    }
    
    func removeAllItems() {
        viewCreator.attachmentsStackView.removeAllArrangedSubviews()
    }

    func configure(with attachments: [AttachmentConvertible], title: String) {
        viewCreator.attachmentsStackView.removeAllArrangedSubviews()
        viewCreator.titleLabel.text = title
        attachments
            .map { $0.toAttachment() }
            .map { makeAttachmentButton(from: $0) }
            .forEach { viewCreator.attachmentsStackView.addArrangedSubview($0) }
    }
    
    private func makeAttachmentButton(from attachment: AttachmentType) -> AttachmentButton {
        let button = AttachmentButton()
        button.attachment = attachment
        button.addTarget(self, action: #selector(attachmentButtonDidTouchButton(_:)), for: .touchUpInside)
        return button
    }
    
    @objc func attachmentButtonDidTouchButton(_ button: AttachmentButton) {
        delegate?.attachmentButtonDidTouch(button: button)
    }
}
