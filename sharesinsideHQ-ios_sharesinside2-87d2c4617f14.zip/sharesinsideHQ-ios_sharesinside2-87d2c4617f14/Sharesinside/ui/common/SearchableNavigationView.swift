//
//  SearchableNavigationView.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 16.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class SearchableNavigationView: BaseView {
    
    var searchBar: UISearchBar = {
        let searchBar = SISearchBar().layoutable()
        searchBar.placeholder = Localizable.companiesPlaceholderSearch.localized
        return searchBar
    }()
    
    var accountButton: UIButton = {
        return ButtonFactory.makeAccountButton()
    }()
    
    override var intrinsicContentSize: CGSize {
        return UIView.layoutFittingExpandedSize
    }
    
    override func setupViewHierarchy() {
        [searchBar, accountButton].forEach { addSubview($0)}
    }
    
    override func setupConstraints() {
        accountButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().inset(Defaults.marginTiny)
            make.width.equalTo(Defaults.Navigation.itemWidth)
            make.height.equalTo(Defaults.Navigation.itemHeight)
        }

        searchBar.snp.makeConstraints { make in
            make.trailing.equalToSuperview()
            make.leading.equalTo(accountButton.snp.trailing).offset(Defaults.marginTiny)
            make.centerY.equalToSuperview()
            make.height.equalTo(48)
        }
        
        self.snp.makeConstraints { make in
            make.height.equalTo(Defaults.Navigation.barHeight)
        }
    }
    
    func setup(in navigationItem: UINavigationItem) {
        if #available(iOS 11.0, *) {
            navigationItem.titleView = self
        } else {
            navigationItem.titleView = searchBar
            navigationItem.leftBarButtonItem = UIBarButtonItem(customView: accountButton)
        }
        accountButton.addTarget(self, action: #selector(showProfile), for: .touchUpInside)
    }
    
    @objc private func showProfile() {
        let viewController = BaseNavigationController(rootViewController: ProfileViewController())
        accountButton.viewController?.present(viewController, animated: true, completion: nil)
    }
}
