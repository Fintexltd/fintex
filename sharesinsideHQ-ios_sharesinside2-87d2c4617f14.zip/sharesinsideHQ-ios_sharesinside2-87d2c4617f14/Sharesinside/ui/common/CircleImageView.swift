//
//  CircleImageView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class CircleImageView: UIImageView {
    
    init() {
        super.init(frame: .zero)
        initialize()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    private func initialize() {
        clipsToBounds = true
        contentMode = .scaleAspectFill
        layoutable()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = frame.size.width / 2
    }
}
