//
//  AlertView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 08.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

import UIKit

struct AlertData {
    let message: String?
    let title: String?
    let positiveButtonTitle: Localizable
    let cancelButtonTitle: Localizable?
    let onPositiveTap: (() -> Void)?
    let onCancelTap: (() -> Void)?
    let messageAttributes: [NSAttributedString.Key: Any]
    
    init(message: String?,
         title: String? = "",
         positiveButtonTitle: Localizable = .ok,
         cancelButtonTitle: Localizable? = nil,
         onPositiveTap: (() -> Void)? = nil,
         onCancelTap: (() -> Void)? = nil,
         messageAttributes: [NSAttributedString.Key: Any] = [:]) {
        self.message = message
        self.title = title
        self.positiveButtonTitle = positiveButtonTitle
        self.cancelButtonTitle = cancelButtonTitle
        self.onPositiveTap = onPositiveTap
        self.onCancelTap = onCancelTap
        self.messageAttributes = messageAttributes
    }
}

protocol Alert {
    func showDefault(in vc: UIViewController?, withData data: AlertData)
}

class AlertView: Alert {
    
    func showDefault(in vc: UIViewController?, withData data: AlertData) {
        let alertController = UIAlertController(title: data.title,
                                                message: data.message,
                                                preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: data.positiveButtonTitle.localized,
                                     style: .default,
                                     handler: { _ in data.onPositiveTap?() })
        alertController.addAction(okAction)
        
        if let cancelTitle = data.cancelButtonTitle?.localized {
            let cancelAction = UIAlertAction(title: cancelTitle,
                                             style: .cancel,
                                             handler: { _ in data.onCancelTap?() })
            alertController.addAction(cancelAction)
        }
        
        if !data.messageAttributes.isEmpty {
            let attributedMessage = NSMutableAttributedString(string: data.message ?? "",
                                                              attributes: data.messageAttributes)
            alertController.setValue(attributedMessage, forKey: "attributedMessage")
        }
        
        vc?.present(alertController, animated: true, completion: nil)
    }
}
