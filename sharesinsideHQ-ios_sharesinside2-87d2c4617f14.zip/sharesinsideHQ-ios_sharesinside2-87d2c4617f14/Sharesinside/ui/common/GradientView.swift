//
//  GradientView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 12/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class GradientView: UIView {

    private var gradient: CAGradientLayer?

    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }

    private func initialize() {
        layoutable()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradient?.frame = frame
        gradient?.layoutIfNeeded()
    }

    func initWith(colors: [CGColor], locations: [NSNumber]) {
        gradient = self.applyGradient(colors: colors, locations: locations)
        gradient?.frame = frame
    }
}
