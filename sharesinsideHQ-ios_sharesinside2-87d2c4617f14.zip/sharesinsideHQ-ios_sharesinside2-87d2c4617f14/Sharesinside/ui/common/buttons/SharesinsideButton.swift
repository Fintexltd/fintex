//
//  SharesinsideButton.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 11.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import SnapKit

class SharesinsideButton: UIButton {

    typealias ButtonStyle = (background: UIColor, foreground: UIColor, border: UIColor)

    enum Style {
        static let transparent = ButtonStyle(background: .clear, foreground: .accent, border: .clear)
        static let transparentWithBorder = ButtonStyle(background: .clear, foreground: .accent, border: .accent)
        static let transparentWithBorderPrimary = ButtonStyle(background: .clear, foreground: .primary, border: .primary)
        static let primaryDark = ButtonStyle(background: .primaryDark, foreground: .accent, border: .primaryDark)
        static let primary = ButtonStyle(background: .primary, foreground: .accent, border: .primary)
        static let accent = ButtonStyle(background: .accent, foreground: .primaryDark, border: .accent)
        static let linkedInWelcome = ButtonStyle(background: .accent, foreground: .primary, border: .accent)
        static let resign = ButtonStyle(background: .accent, foreground: .error, border: .error)
    }

    var style: ButtonStyle = Style.primaryDark {
        didSet {
            configureColors()
        }
    }
    // MARK: views
    lazy var textLabel: UILabel = {
        let label = UILabelFactory.styled(withFontSize: Defaults.TextSize.small,
                                          fontWeight: .bold)
        return label
    }()
    
    private lazy var iconImageView: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    func updateTitleMargins(left: CGFloat = Defaults.marginSmall,
                            top: CGFloat = Defaults.marginTiny,
                            right: CGFloat = Defaults.marginSmall,
                            bottom: CGFloat = Defaults.marginTiny) {
        textLabel.snp.remakeConstraints { make in
            make.top.greaterThanOrEqualToSuperview().offset(top)
            make.bottom.lessThanOrEqualToSuperview().inset(bottom)
            make.center.equalToSuperview().priority(.highest)
            
            if iconImageView.image != nil {
                make.leading.equalTo(iconImageView.snp.trailing).offset(left)
                make.trailing.lessThanOrEqualToSuperview().inset(right)
            } else {
                make.leading.equalToSuperview().inset(left)
                make.trailing.equalToSuperview().inset(right).priority(.highest)
            }
        }
    }

    // MARK: Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }

    // MARK: Overrides

    override func setTitle(_ title: String?, for state: UIControl.State) {
        textLabel.text = title
    }

    override func setAttributedTitle(_ title: NSAttributedString?, for state: UIControl.State) {
        textLabel.attributedText = title
    }

    override func setImage(_ image: UIImage?, for state: UIControl.State) {
        iconImageView.image = image
        iconImageView.isHidden = image == nil
        setupTitleConstraints(clipToImage: image != nil)
    }

    override var isHighlighted: Bool {
        didSet {
            configureColors()
        }
    }
    
    override var isEnabled: Bool {
        didSet {
            alpha = isEnabled ? 1.0 : Defaults.disabledAlpha
        }
    }

    // MARK: Private methods and params
    private func initialize() {
        layoutable()
        [iconImageView, textLabel].forEach { addSubview($0) }
        setupConstrainst()

        layer.borderWidth = Defaults.buttonBorderWidth
        layer.cornerRadius = Defaults.buttonCornerRadius
        iconImageView.contentMode = .scaleAspectFit
        configureColors()
    }

    private func setupConstrainst() {
        iconImageView.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(Defaults.marginNormal)   
            make.centerY.equalToSuperview().priority(.highest)
            make.top.greaterThanOrEqualToSuperview().offset(Defaults.marginTiny)
            make.bottom.lessThanOrEqualToSuperview().inset(Defaults.marginTiny)
            make.height.equalTo(Defaults.buttonIconSize).priority(.highest)
            make.width.equalTo(iconImageView.snp.height).multipliedBy(1)
        }

        setupTitleConstraints(clipToImage: iconImageView.image != nil)
    }

    private func setupTitleConstraints(clipToImage: Bool) {
        textLabel.snp.remakeConstraints { make in
            make.top.greaterThanOrEqualToSuperview().offset(Defaults.marginTiny)
            make.bottom.lessThanOrEqualToSuperview().inset(Defaults.marginTiny)
            make.center.equalToSuperview().priority(.highest)

            if clipToImage {
                make.leading.equalTo(iconImageView.snp.trailing).offset(Defaults.marginSmall)
                make.trailing.lessThanOrEqualToSuperview().inset(Defaults.marginSmall)
            } else {
                make.leading.equalToSuperview().inset(Defaults.marginSmall)
                make.trailing.equalToSuperview().inset(Defaults.marginSmall).priority(.highest)
            }
        }
    }

    private func configureColors() {
        let alpha: CGFloat = isHighlighted ? 0.5 : 1
        backgroundColor = style.background
        layer.borderColor = style.border.withAlpha(alpha).cgColor
        textLabel.textColor = style.foreground.withAlpha(alpha)
        iconImageView.tintColor = style.foreground.withAlpha(alpha)
    }
}
