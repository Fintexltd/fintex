//
//  AddressButton.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 19.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import SnapKit

protocol AddressButtonDelegate: class {
    func didTouchAddress(button: AddressButton)
}

class AddressButton: BaseButton {
    
    typealias ButtonStyle = (background: UIColor, iconTint: UIColor, textColor: UIColor)
    
    enum Style {
        static let primary = ButtonStyle(background: .white, iconTint: .primary, textColor: .darkGrey)
        static let transparentDark = ButtonStyle(background: .primaryDark, iconTint: .white, textColor: .white)
    }
    
    var style: ButtonStyle = Style.primary {
        didSet {
            setupColors()
        }
    }
    
    var address: AddressConvertible? {
        didSet {
            guard let address = address else { return }
            if let icon = iconFor(type: address.type) {
                iconImageView.image = icon
            } else {
                iconImageSizeConstraint?.deactivate()
            }
            textLabel.text = address.text
        }
    }

    var hasDivider: Bool = true {
        didSet { divider.isHidden = !hasDivider }
    }
    
    var textLabel: UILabel = {
        let label = UILabelFactory.styled(
            withFontSize: Defaults.TextSize.medium,
            fontWeight: .regular)
        label.textAlignment = .left
        return label
    }()
    
    var iconImageView: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    var divider: UIView = {
        let view = UIView()
        view.backgroundColor = .grey
        return view
    }()

    private var iconImageSizeConstraint: Constraint?
    
    private func iconFor(type: AddressDataType) -> UIImage? {
        switch type {
        case .phone: return #imageLiteral(resourceName: "IconPhone")
        case .email: return #imageLiteral(resourceName: "IconMail")
        case .location: return #imageLiteral(resourceName: "IconAdress")
        case .website: return #imageLiteral(resourceName: "IconWeb")
        case .attachment: return #imageLiteral(resourceName: "IconAttachement")
        case .termsAndConditions: return #imageLiteral(resourceName: "IconAttachement")
        }
    }

    func setFixedHeight(_ height: CGFloat) {
        self.snp.remakeConstraints { make in
            make.height.equalTo(height)
        }
    }
    
    override func setAttributedTitle(_ title: NSAttributedString?, for state: UIControl.State) {
        textLabel.attributedText = title
    }
    
    override func setTitle(_ title: String?, for state: UIControl.State) {
        textLabel.text = title
    }
    
    override func setImage(_ image: UIImage?, for state: UIControl.State) {
        iconImageView.image = image
    }
    
    override func setupColors() {
        textLabel.textColor = style.textColor
        iconImageView.tintColor = style.iconTint
        iconImageView.backgroundColor = style.background
        backgroundColor = style.background
    }
    
    override func setupViewHierarchy() {
        [textLabel, iconImageView, divider].forEach { addSubview($0) }
    }
    
    override func setupConstraints() {
        setupImageViewConstraints()
        setupLabelConstraints()
        AppInfo.isIPad ? setupVerticalDividerConstraints() : setupHorizontalDividerConstraints()
    }
    
    private func setupImageViewConstraints() {
        iconImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().inset(Defaults.marginSmall)
            self.iconImageSizeConstraint = make.height.width.equalTo(Defaults.addressIconSize).constraint
        }
    }
    
    private func setupLabelConstraints() {
        textLabel.snp.makeConstraints { make in
            make.leading.equalTo(iconImageView.snp.trailing).offset(Defaults.marginSmall)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.trailing.equalToSuperview().inset(Defaults.marginSmall)
        }
    }
    
    private func setupVerticalDividerConstraints() {
        divider.snp.makeConstraints { make in
            make.trailing.centerY.equalToSuperview()
            make.height.equalToSuperview().multipliedBy(0.7)
            make.width.equalTo(Defaults.dividerSize)
        }
    }
    
    private func setupHorizontalDividerConstraints() {
        divider.snp.makeConstraints { make in
            make.bottom.trailing.equalToSuperview()
            make.leading.equalToSuperview().inset(Defaults.marginSmall)
            make.height.equalTo(Defaults.dividerSize)
        }
    }
    static func make(from address: AddressConvertible, target: Any?, selector: Selector, controlEvents: UIControl.Event = .touchUpInside) -> AddressButton? {
        guard !address.text.isEmpty else {
            return nil
        }
        let button = AddressButton()
        button.address = address
        button.addTarget(target, action: selector, for: controlEvents)
        return button
    }
}
