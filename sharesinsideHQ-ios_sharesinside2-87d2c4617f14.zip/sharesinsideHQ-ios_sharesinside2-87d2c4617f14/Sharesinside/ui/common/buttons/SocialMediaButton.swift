//
//  SocialMediaButton.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 23.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

protocol SocialMediaButtonDelegate: class {
    func didTouchSocialMedia(button: SocialMediaButton)
}

class SocialMediaButton: BaseButton {
    
    var socialMedia: SocialMedia? {
        didSet {
            guard let socialMedia = socialMedia else { return }
            iconImageView.image = iconFor(type: socialMedia.type)
        }
    }
    
    private var iconImageView = UIImageView()
    
    override func setImage(_ image: UIImage?, for state: UIControl.State) {
        iconImageView.image = image
    }
    
    override func setupColors() {
        iconImageView.tintColor = .primary
    }
    
    override func setupViewHierarchy() {
        addSubview(iconImageView)
    }
    
    override func setupConstraints() {
        iconImageView.snp.makeConstraints { make in
            make.width.height.equalTo(Defaults.socialMediaIconSize)
            make.top.bottom.equalToSuperview().inset(Defaults.marginSmall)
            make.centerX.equalToSuperview()
        }
    }
    
    private func iconFor(type: String) -> UIImage? {
        if type.contains("linkedin") { return #imageLiteral(resourceName: "IconLinkedinRound") }
        if type.contains("facebook") { return #imageLiteral(resourceName: "IconFacebook") }
        if type.contains("twitter") { return #imageLiteral(resourceName: "IconTwitter") }
        return nil
    }
    
}
