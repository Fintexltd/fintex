//
//  BottomSheetDescriptionViewCreator.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class BottomSheetDescriptionViewCreator: BaseViewCreator {
    
    // MARK: Scroll view
    let scrollView: UIScrollView = {
        let scrollView = UIScrollView().layoutable()
        
        return scrollView
    }()
    
    let contentView = UIView().layoutable()
    
    let titleLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .accent,
                                          withFontSize: Defaults.TextSize.small,
                                          fontWeight: .bold,
                                          aligment: .left)
        label.numberOfLines = 1
        return label
    }()
    
    let shortDescriptionLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .accent,
                                          withFontSize: Defaults.TextSize.small,
                                          aligment: .left)
        label.numberOfLines = 1        
        return label
    }()
    
    let readMoreButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: Defaults.TextSize.small)
        button.setTitle(Localizable.watchlistReadMore.localized, for: .normal)
        button.setTitleColor(.grey, for: .normal)
        button.setContentCompressionResistancePriority(.required, for: .horizontal)
        
        return button
    }()
    
    let descriptionLabel: UILabel = {
        let label = UILabelFactory.styled(textColor: .accent,
                                          withFontSize: Defaults.TextSize.small,
                                          aligment: .left)
        label.alpha = 0
        return label
    }()
    
    lazy var subtitleStackView = UIStackView.make(
        axis: .horizontal,
        with: [
            shortDescriptionLabel,
            readMoreButton
        ])
    
    lazy var descriptionStackView = UIStackView.make(
        axis: .vertical,
        with: [
            titleLabel,
            descriptionLabel
        ],
        spacing: Defaults.marginMicro)
    
    let descriptionContainer: UIView = UIView().layoutable()
    
    let gradientView: GradientView = {
        let gradientView = GradientView()
        gradientView.initWith(colors: [
            UIColor.clear.cgColor,
            UIColor.black.cgColor,
            UIColor.black.cgColor
            ], locations: [0.0, 0.5, 1.0])

        return gradientView
    }()

    let gradientContainer: UIView = UIView().layoutable()
    
    let closeButton: UIButton = {
        let button = UIButton().layoutable()
        return button
    }()
    
    let descriptionButton: UIButton = {
        let button = UIButton().layoutable()
        return button
    }()
    
    override func setupViewHierarchy() {
        parentView.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        contentView.addSubview(descriptionStackView)
        contentView.addSubview(subtitleStackView)
        contentView.addSubview(descriptionButton)
        
        gradientContainer.addSubview(gradientView)
        gradientContainer.addSubview(closeButton)
    }
    
    override func setupProperties() {
        gradientContainer.alpha = 0
    }
    
    override func setupConstraints() {
        scrollView.snp.makeConstraints { make in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalBottomSafeArea(parentView)
        }
        
        contentView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            make.width.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        subtitleStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalTo(descriptionLabel.snp.top)
            make.height.equalTo(17)
        }
        
        descriptionStackView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
        }
        
        gradientView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        closeButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        
        descriptionButton.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
