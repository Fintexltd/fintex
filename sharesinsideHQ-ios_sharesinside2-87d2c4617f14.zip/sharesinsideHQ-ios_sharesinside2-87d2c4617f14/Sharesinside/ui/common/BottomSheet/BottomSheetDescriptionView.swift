//
//  BottomSheetDescriptionView.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

class BottomSheetDescriptionView: BaseView {

    private lazy var viewCreator = BottomSheetDescriptionViewCreator(withParentView: self)
    private var heightConstraint: NSLayoutConstraint?
    
    private lazy var gestureRecognizer: UIGestureRecognizer = {
        let gesture = UIPanGestureRecognizer.init(target: self, action: #selector(panGesture))
        gesture.delegate = self
        return gesture
    }()
    
    private var expandedY: CGFloat {
        return  max(Defaults.PhotoPreview.descriptionTopMargin,
                    (superview?.frame.height ?? 0) - viewCreator.scrollView.contentSize.height)
    }
    
    private var collapsedY: CGFloat {
        return (superview?.frame.height ?? 0) - Defaults.PhotoPreview.bottomBarCollapsedHeight
    }
    
    override func initializeView() {
        viewCreator.setupView()
        addGestureRecognizer()
        viewCreator.readMoreButton.addTarget(self, action: #selector(readMoreDidTouch), for: .touchUpInside)
        viewCreator.closeButton.addTarget(self, action: #selector(closeDescriptionDidTouch), for: .touchUpInside)
        viewCreator.descriptionButton.addTarget(self, action: #selector(descriptionDidTouch), for: .touchUpInside)
    }
    
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        
        guard let superview = superview else { return }
        self.snp.remakeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(superview.snp.bottom).inset(Defaults.PhotoPreview.bottomBarCollapsedHeight)
        }

        heightConstraint = self.heightAnchor.constraint(equalToConstant: Defaults.PhotoPreview.bottomBarCollapsedHeight)
        heightConstraint?.isActive = true
        addGradientViewToParent()
    }

    @objc private func panGesture(recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: self)
        let velocity = recognizer.velocity(in: self)
        
        let y = frame.minY
        let translationY = y + translation.y
        if (translationY >= expandedY) && (translationY <= collapsedY) {
            frame = CGRect(x: 0, y: translationY, width: frame.width, height: frame.height)
            recognizer.setTranslation(CGPoint.zero, in: self)
            
            let descriptionAlpha = abs(translationY - collapsedY) / abs((expandedY) - collapsedY)
            viewCreator.descriptionLabel.alpha = descriptionAlpha
            viewCreator.gradientContainer.alpha = descriptionAlpha
            viewCreator.subtitleStackView.alpha = 1 - descriptionAlpha
        }
        
        if recognizer.state == .ended {
            var duration =  velocity.y < 0 ? Double((y - expandedY) / -velocity.y) : Double((collapsedY - y) / velocity.y )
            duration = duration > 0.5 ? 0.3 : duration

            toggleBootomSheet(visible: velocity.y < 0, animationDuration: duration)
        }
    }
    
    @objc private func readMoreDidTouch() {
        expand()
    }
    
    @objc private func closeDescriptionDidTouch() {
        collapse()
    }
    
    @objc private func descriptionDidTouch() {
        self.frame.minY == expandedY ? collapse() : expand()
    }
    
    private func collapse() {
        toggleBootomSheet(visible: false, animationDuration: 0.3)
    }
    
    private func expand() {
        toggleBootomSheet(visible: true, animationDuration: 0.3)
    }
    
    private func toggleBootomSheet(visible: Bool, animationDuration: Double) {
        guard animationDuration > 0 else {
            return
        }
        
        UIView.animate(withDuration: animationDuration, delay: 0, animations: {
            let y = visible ? self.expandedY : self.collapsedY
            self.frame = CGRect(x: 0, y: y, width: self.frame.width, height: self.frame.height)
            self.viewCreator.descriptionLabel.alpha = visible ? 1 : 0
            self.viewCreator.subtitleStackView.alpha = visible ? 0 : 1
            self.viewCreator.gradientContainer.alpha = visible ? 1 : 0
        }, completion: { [weak self] _ in
            guard let self = self else { return }
            if visible {
                self.viewCreator.scrollView.isScrollEnabled = true
            }
        })
    }
    
    private func addGradientViewToParent() {
        guard viewCreator.gradientContainer.superview == nil else { return }
        superview?.insertSubview(viewCreator.gradientContainer, belowSubview: self)
        viewCreator.gradientContainer.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
    
    private func addGestureRecognizer() {
        removeGestureRecognizer(gestureRecognizer)
        addGestureRecognizer(gestureRecognizer)
    }
    
    override var alpha: CGFloat {
        didSet {
            if alpha == 0 { collapse() }
        }
    }
}

extension BottomSheetDescriptionView: UIGestureRecognizerDelegate {
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
        guard let gesture = gestureRecognizer as? UIPanGestureRecognizer else { return false }
        let direction = gesture.velocity(in: self).y
        
        let y = frame.minY
        viewCreator.scrollView.isScrollEnabled = !(
            (y == expandedY && viewCreator.scrollView.contentOffset.y == 0 && direction > 0) ||
            (y == collapsedY)
        )
        
        return false
    }
}

// MARK: Endpoints
extension BottomSheetDescriptionView {
    
    func configure(withLegalEntityName legalEntityName: String?, andDescription description: NSAttributedString?) {
        viewCreator.titleLabel.text = legalEntityName
        viewCreator.shortDescriptionLabel.attributedText = description

        viewCreator.descriptionLabel.attributedText = description
        
        viewCreator.descriptionLabel.numberOfLines = 1
        let shortDescriptionAlpha: CGFloat = viewCreator.descriptionLabel.isTruncated ? 1 : 0
        
        if viewCreator.descriptionLabel.isTruncated {
            addGestureRecognizer()
        } else {
            removeGestureRecognizer(gestureRecognizer)
        }
        
        viewCreator.shortDescriptionLabel.alpha = shortDescriptionAlpha
        viewCreator.readMoreButton.alpha = shortDescriptionAlpha
        viewCreator.descriptionLabel.numberOfLines = 0
        
        self.viewCreator.scrollView.layoutIfNeeded()
        self.layoutSubviews()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if let heightConstraint = heightConstraint, viewCreator.scrollView.contentSize.height != heightConstraint.constant {
            heightConstraint.constant = abs(min(viewCreator.scrollView.contentSize.height, (superview?.frame.height ?? 0) - expandedY))
        }
    }
}
