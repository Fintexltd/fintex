//
//  InvestmentType.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 23/08/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation

enum InvestmentType {
    case fund(FundAbout)
    case startup(StartupAbout)
}
