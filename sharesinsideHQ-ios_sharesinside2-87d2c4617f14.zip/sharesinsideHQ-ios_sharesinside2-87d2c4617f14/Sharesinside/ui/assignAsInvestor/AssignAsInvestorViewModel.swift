//
//  AssignAsInvestorViewModel.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa

class AssignAsInvestorViewModel: BaseViewModel<HasCountriesRepository & HasFundsRepository> {

    let sectionsData = BehaviorRelay<[AuthSectionModel]>(value: [])
    let sectionUpdateNeed = PublishSubject<Int>()
    let sectionHeaderUpdateNeed = PublishSubject<Int>()
    let dataValid = BehaviorRelay<Bool>(value: false)
    let asigned = PublishRelay<Bool>()

    var investmentType: InvestmentType?

    private lazy var countriesRepo = dependencies.countriesRepository
    private lazy var fundsRepository = dependencies.fundsRepository

    private var countriesLoading: Bool = false

    override func onViewDidLoad() {
        super.onViewDidLoad()

        let sectionData = prepareSectionData()
        guard !sectionData.isEmpty else {

            return
        }

        sectionsData.accept(prepareSectionData())
        fetchCountriesIfNeeded()
    }

    func formDataChanged() {
        dataValid.accept(isDataValid)
        fetchCountriesIfNeeded()
    }

    // Private methods
    private var isDataValid: Bool {
        for section in sectionsData.value where !section.isValid {
            return false
        }
        return true
    }

    private func prepareSectionData() -> [AuthSectionModel] {
        return [
            DescriptionSectionModel(description: Localizable.investorFormDescription.localized),
            InputAuthSectionModel(inputType: .firstName),
            InputAuthSectionModel(inputType: .lastName),
            InputAuthSectionModel(inputType: .dateOfBirth),
            SearchCountrySectionModel(),
            InputAuthSectionModel(inputType: .address),
            InputAuthSectionModel(inputType: .city),
            InputAuthSectionModel(inputType: .postcode),
            InputAuthSectionModel(inputType: .phoneNumber)
        ] + [
            investmentType?.fundId != nil ? TermsAuthSectionModel() : nil
        ].compactMap { $0 }
    }

    private func fetchCountriesIfNeeded() {
        guard let countrySection = countrySection(), countrySection.countries == nil, !countriesLoading else { return }
        countriesRepo.getCountries()
            .do(onSubscribe: { [unowned self] in
                self.countriesLoading = true
                },
                onDispose: { [weak self] in
                    self?.countriesLoading = false
            })
            .subscribe(onSuccess: { [weak self] countries in
                if let index = self?.sectionsData.value.index(where: { $0 is SearchCountrySectionModel }),
                    let searchCountrySectionModel = self?.sectionsData.value[index] as? SearchCountrySectionModel {
                    searchCountrySectionModel.countries = countries
                    self?.sectionUpdateNeed.onNext(index)
                }
            }) { error in printDebug(error) }
            .disposed(by: disposeBag)
    }

    private func handleApiError(_ error: Error) {
        guard let response = error as? ErrorResponse else {
            alert.accept(AlertData(message: error.localizedDescription))
            return
        }

        let errors = response.errors ?? [:]

        if errors.contains(where: { $0.key == "first_name" }) { updateInputSection(type: .firstName) }
        if errors.contains(where: { $0.key == "last_name" }) { updateInputSection(type: .lastName) }
        if errors.contains(where: { $0.key == "phone_number" }) { updateInputSection(type: .phoneNumber) }
        if errors.contains(where: { $0.key == "birth_date" }) { updateInputSection(type: .dateOfBirth) }
        if errors.contains(where: { $0.key == "address" }) { updateInputSection(type: .address) }
        if errors.contains(where: { $0.key == "post_code" }) { updateInputSection(type: .postcode) }
        if errors.contains(where: { $0.key == "city" }) { updateInputSection(type: .city) }

        alert.accept(AlertData(message: response.prettyPrintedErrors ?? error.localizedDescription))
    }

    private func updateInputSection(type: InputAuthSectionModel.InputSectionType) {
        guard let section = inputSection(forType: type), let index = indexOfInputSection(forType: type) else { return }

        section.apiErrorOccurred = true
        sectionHeaderUpdateNeed.onNext(index)
    }

    private func indexOfInputSection(forType type: InputAuthSectionModel.InputSectionType) -> Int? {
        return sectionsData.value.index(where: { ($0 as? InputAuthSectionModel)?.inputType == type })
    }

    // MARK: Public methods
    func assignAsInvestor() {
        guard let firstName = firstName, let lastName = lastName,
            let dateOfBirth = dateOfBirth?.toString(withFromat: Date.Format.ohlcDateFormat),
            let address = address, let city = city, let postalCode = postalCode,
            let phoneNumber = phoneNumber, let countryId = userSelectedCountry?.id else {
                return
        }

        let fundId = investmentType?.fundId
        let startupId = investmentType?.startupId

        let investorRequestData = InvestorRequestModel(fundId: fundId,
                                                       startupId: startupId,
                                                             firstName: firstName,
                                                             lastName: lastName,
                                                             phoneNumber: phoneNumber,
                                                             birthDate: dateOfBirth,
                                                             address: address,
                                                             postalCode: postalCode,
                                                             city: city,
                                                             countryId: countryId)

        fundsRepository.assignAsInvestor(requestData: investorRequestData)
            .applyLoader(andBehaviorRelay: loading)
            .observeOn(MainScheduler.instance)
            .subscribe(onNext: { [weak self] _ in
                self?.asigned.accept(true)
                self?.router?.push(to: .information(informationType: .requestSent), routeFlag: .popCurrent)
                }, onError: { [weak self] error in
                    self?.handleApiError(error)
            }).disposed(by: disposeBag)
    }
}

extension AssignAsInvestorViewModel {

    private var firstName: String? { return inputSection(forType: .firstName)?.value }

    private var lastName: String? { return inputSection(forType: .lastName)?.value }

    private var dateOfBirth: Date? { return inputSection(forType: .dateOfBirth)?.selectedDate }

    private var address: String? { return inputSection(forType: .address)?.value }

    private var city: String? { return inputSection(forType: .city)?.value }

    private var postalCode: String? { return inputSection(forType: .postcode)?.value }

    private var phoneNumber: String? { return inputSection(forType: .phoneNumber)?.value }

    private var userSelectedCountry: Country? {
        return (sectionsData.value.first(where: { $0 is SearchCountrySectionModel }) as? SearchCountrySectionModel)?.selectedCountry
    }

    private func countrySection() -> SearchCountrySectionModel? {
        return sectionsData.value.first(where: { $0.sectionType == .searchCountry }) as? SearchCountrySectionModel
    }

    private func inputSection(forType type: InputAuthSectionModel.InputSectionType) -> InputAuthSectionModel? {
        return (sectionsData.value.filter({ $0.sectionType == .input }) as? [InputAuthSectionModel])?.first(where: { $0.inputType == type })
    }

    private func authSection() -> TermsAuthSectionModel? {
        return (sectionsData.value.compactMap { $0 as? TermsAuthSectionModel }.first)
    }
}

private extension InvestmentType {
    var startupId: Int? {
        switch self {
        case let .startup(startupAbout):
            return startupAbout.id
        case let .fund:
            return nil
        }
    }

    var fundId: Int? {
        switch self {
        case let .startup:
            return nil
        case let .fund(fundAbout):
            return fundAbout.id
        }
    }
}
