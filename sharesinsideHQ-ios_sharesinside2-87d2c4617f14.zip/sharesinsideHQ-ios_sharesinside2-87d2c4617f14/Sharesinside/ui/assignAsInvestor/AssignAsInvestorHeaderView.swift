//
//  AssignAsInvestorHeaderView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

class AssignAsInvestorHeaderView: BaseView {

    private lazy var gradient: CAGradientLayer = gradientView
        .applyGradient(colors: [
            UIColor.primaryDark.withAlphaComponent(0.5).cgColor,
            UIColor.primaryDark.withAlphaComponent(0.9).cgColor,
            UIColor.primaryDark.cgColor
            ], locations: [0.0, 0.4, 0.6])

    private lazy var titleLabel: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.text = Localizable.fundAssignAsInvestor.localized
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)
        return label
    }()

    // MARK: Company basic information
    private lazy var backgroundImage: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .vertical)
        imageView.setContentPriority(resistancePriority: .defaultLow, resistanceAxis: .horizontal)

        return imageView
    }()

    private lazy var gradientView: UIView = {
        return UIView().layoutable()
    }()

    private lazy var fundLogo: UIImageView = {
        let imageView = UIImageView().layoutable()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .clear
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = Defaults.Company.cellCornerRadius
        return imageView
    }()

    private lazy var fundTitle: UILabel = {
        let label = UILabelFactory.styled(fontWeight: .bold)
        label.text = "--"
        label.textAlignment = .left
        label.setContentPriority(resistancePriority: .required, resistanceAxis: .vertical)
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)

        return label
    }()

    private lazy var fundGroup: UILabel = {
        let label = UILabelFactory.styled(withFontSize: Defaults.TextSize.small)
        label.text = "--"
        label.textAlignment = .left
        label.setContentHuggingPriority(.defaultHigh, for: .vertical)

        return label
    }()

    private lazy var fundDataContainer = UIView().layoutable()

    // MARK: Basic information StackView
    private lazy var contentStackView = UIStackView.make(
        axis: .vertical,
        with: [
            titleLabel,
            fundDataContainer.embedInView()
        ],
        spacing: Defaults.marginBig)

    // MARK: Header hover view
    private lazy var headerHoverView: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .primaryDark
        view.alpha = 0

        return view
    }()

    // MARK: Lifecycle

    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        gradient.frame = gradientView.frame
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        gradient.frame = gradientView.frame
    }

    // Initialization
    override func initializeView() {
        clipsToBounds = true
        backgroundColor = .primary
        [backgroundImage, gradientView, contentStackView, headerHoverView].forEach { addSubview($0) }
        [fundLogo, fundTitle, fundGroup].forEach { fundDataContainer.addSubview($0) }

        contentStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(Defaults.marginNormal).priority(.highest)
            make.top.equalToSuperview().inset(Defaults.Shareholder.headerTopMargin).priority(.highest)
        }

        fundLogo.snp.makeConstraints { make in
            make.top.leading.equalToSuperview()
            make.height.equalTo(Defaults.Company.logoSize)
            make.width.equalTo(fundLogo.snp.height)
        }

        fundTitle.snp.makeConstraints { make in
            make.leading.equalTo(fundLogo.snp.trailing).offset(Defaults.marginNormal)
            make.trailing.equalToSuperview()
            make.top.equalToSuperview()
        }

        fundGroup.snp.makeConstraints { make in
            make.leading.equalTo(fundLogo.snp.trailing).offset(Defaults.marginNormal)
            make.trailing.equalToSuperview()
            make.top.equalTo(fundTitle.snp.bottom).offset(Defaults.marginSmall).priority(.highest)
            make.bottom.equalToSuperview().inset(Defaults.Shareholder.headerBottomMargin)
        }

        fundDataContainer.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.greaterThanOrEqualToSuperview()
            make.trailing.lessThanOrEqualToSuperview()
            make.centerX.equalToSuperview()
        }

        backgroundImage.snp.makeConstraints { make in
            make.height.equalToSuperview()
            make.width.equalToSuperview()
            make.center.equalToSuperview()
        }

        gradientView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        headerHoverView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }

        snp.makeConstraints { make in
            make.bottom.equalTo(contentStackView.snp.bottom)
        }
    }

    // MARK: public methods

    var investmentType: InvestmentType? {
        didSet {
            if let investmentType = investmentType {
                let investorHeaderRepresentable = investmentType.investorHeaderRepresentable
                fundTitle.text = investorHeaderRepresentable.name
                fundGroup.text = investorHeaderRepresentable.group

                if let logo = investorHeaderRepresentable.logo, let logoUrl = URL.forQuery(using: logo) {
                    fundLogo.kf.setImage(with: ImageResource(downloadURL: logoUrl), options: [.backgroundDecode])
                }

                if let background = investorHeaderRepresentable.background, let logoUrl = URL(string: background) {
                    backgroundImage.kf.setImage(with: ImageResource(downloadURL: logoUrl))
                }
            }
        }
    }

    var hoverAlpha: CGFloat = 0 {
        didSet {
            headerHoverView.alpha = hoverAlpha
        }
    }

    func setTitle(_ title: String?) {
        self.titleLabel.text = title
    }
}

protocol InvestorHeaderRepresentable {
    var name: String? { get }
    var group: String? { get }
    var logo: String? { get }
    var background: String? { get }
}

extension FundAbout: InvestorHeaderRepresentable {
    var group: String? {
        fundTypes.first?.name
    }
}

extension StartupAbout: InvestorHeaderRepresentable {
    var group: String? {
        startupCategories.first?.name
    }
}

extension InvestmentType {
    var investorHeaderRepresentable: InvestorHeaderRepresentable {
        switch self {
        case let .fund(fundAbout):
            return fundAbout
        case let .startup(startupAbout):
            return startupAbout
        }
    }
}
