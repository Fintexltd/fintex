//
//  AssignAsInvestorViewController.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

protocol AssignAsInvestorViewControllerDelegate: class {
    func didSuccesfullyAsignAsInvestor()
}

class AssignAsInvestorViewController: BaseViewController<AssignAsInvestorViewModel>, UIScrollViewDelegate {

    weak var delegate: AssignAsInvestorViewControllerDelegate?

    private let investmentType: InvestmentType

    private lazy var viewCreator = AssignAsInvestorView(withParentView: self.view)

    private var tableViewOffsetY: CGFloat = 0

    private lazy var tableManager: ShareholderTableDataSource = {
        let dataSource = ShareholderTableDataSource(with: viewCreator.tableView)
        dataSource.delegate = self
        return dataSource
    }()

    init(investmentType: InvestmentType, delegate: AssignAsInvestorViewControllerDelegate?) {
        self.delegate = delegate
        self.investmentType = investmentType
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("NSCoding not supported")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setupNavigationBar(withStyle: .transparent)
        IQKeyboardManager.shared.shouldResignOnTouchOutside = false
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
    }

    override func setupView() {
        viewCreator.setupView()
    }

    override func passDataToViewModel() {
        super.passDataToViewModel()
        viewModel.investmentType = investmentType
    }

    override func localize() {
        super.localize()
        viewCreator.assignButton.setTitle(Localizable.shareholderFormAssign.localized.uppercased(), for: .normal)
    }

    override func initializeView() {
        automaticallyAdjustsScrollViewInsets = false
        initializeBarButtons()
        viewCreator.assignButton.addTarget(self, action: #selector(assignButtonDidTouch), for: .touchUpInside)
        viewCreator.headerView.investmentType = investmentType
    }

    override func bindViewModel() {
        super.bindViewModel()

        viewModel.sectionsData.asDriver()
            .drive(onNext: { [weak self] sectionsData in
                self?.tableManager.formSections = sectionsData
            }).disposed(by: disposeBag)

        viewModel.sectionUpdateNeed
            .subscribe(onNext: { [weak self] section in
                self?.tableManager.reload(section: section)
            }).disposed(by: disposeBag)

        viewModel.sectionHeaderUpdateNeed
            .subscribe(onNext: { [weak self] section in
                self?.tableManager.reloadSectionHeader(section: section)
            }).disposed(by: disposeBag)

        viewModel.dataValid
            .subscribe(onNext: { [weak self] dataValid in
                self?.viewCreator.assignButton.isEnabled = dataValid
            }).disposed(by: disposeBag)

        viewModel.asigned
            .subscribe(onNext: { [weak self]_ in
                self?.delegate?.didSuccesfullyAsignAsInvestor()
            }).disposed(by: disposeBag)
    }

    private func initializeBarButtons() {
        navigationItem.leftBarButtonItem = viewCreator.closeBarButtonItem
        viewCreator.closeButton.addTarget(self, action: #selector(closeButtonDidTouch), for: .touchUpInside)
    }

    @objc private func closeButtonDidTouch() {
        navigationController?.dismiss(animated: true)
    }

    @objc private func assignButtonDidTouch() {
        viewModel.assignAsInvestor()
    }
}

extension AssignAsInvestorViewController: ShareholderTableDataSourceDelegate {

    func tableFormDataChanged() {
        viewModel.formDataChanged()
    }

    func tableViewDidScroll(offsetY: CGFloat) {
        let navigationHeight = (navigationController?.navigationBar.frame.height ?? 0) + UIApplication.shared.statusBarFrame.height
        let maxHeaderScroll = (viewCreator.headerView.frame.height - navigationHeight)

        let navigationBarAlpha: CGFloat = min(offsetY / maxHeaderScroll, 0.99)
        viewCreator.headerView.hoverAlpha = navigationBarAlpha
        updateNaviagtionBar(withAlpha: navigationBarAlpha)

        let offset = min(offsetY, maxHeaderScroll)
        self.viewCreator.headerView.snp.updateConstraints { make in
            make.top.equalToSuperview().offset(offset.negative())
        }
    }

    func showTermsAndConditions() {
        guard let termsPath = investmentType.termsAndConditions?.url,
            let termsUrl = URL(string: termsPath) else {
                return
        }
        UIApplication.shared.openIfPossible(termsUrl)
    }

    private func updateNaviagtionBar(withAlpha alpha: CGFloat) {
        let image = UIImage(color: UIColor.primaryDark.withAlpha(alpha))
        navigationController?.navigationBar.setBackgroundImage(image, for: .default)
    }
}

extension InvestmentType {
    var termsAndConditions: TermsAndConditions? {
        switch self {
        case let .fund(fundAbout):
            return fundAbout.termsAndConditions
        case let .startup:
            return nil
        }
    }
}
