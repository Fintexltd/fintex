//
//  AssignAsInvestorView.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 22/03/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import UIKit

class AssignAsInvestorView: BaseViewCreator {

    // MARK: Bar buttons
    lazy var closeButton: UIButton = {
        let button = UIButton(type: .system)
        button.setImage(#imageLiteral(resourceName: "IconClose"), for: .normal)
        button.tintColor = .accent
        button.imageView?.contentMode = .scaleAspectFit
        button.imageEdgeInsets = UIEdgeInsets(top: Defaults.marginSmall,
                                              left: 0,
                                              bottom: Defaults.marginSmall,
                                              right: Defaults.marginSmall)

        return button
    }()

    lazy var closeBarButtonItem: UIBarButtonItem = {
        return UIBarButtonItem(customView: closeButton)
    }()

    let headerView = AssignAsInvestorHeaderView()

    // MARK: Views
    lazy var tableView: UITableView = {
        let tableView = UITableView().layoutable()
        tableView.separatorStyle = .none
        tableView.bounces = false
        tableView.backgroundColor = .clear
        tableView.showsVerticalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: Defaults.marginNormal, right: 0)

        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        }

        return tableView
    }()

    lazy var assignButton: SharesinsideButton = {
        let button = SharesinsideButton(type: .system)
        button.style = SharesinsideButton.Style.primary
        button.updateTitleMargins(left: Defaults.marginBig, right: Defaults.marginBig)
        return button
    }()

    let assignButtonContainer: UIView = {
        let view = UIView().layoutable()
        view.backgroundColor = .white
        view.layer.shadowColor = UIColor.darkGrey.cgColor
        view.layer.shadowOpacity = 0.8
        view.layer.shadowOffset = CGSize(width: 0, height: 2)

        return view
    }()

    override func setupViewHierarchy() {
        assignButtonContainer.addSubview(assignButton)
        [tableView, headerView, assignButtonContainer].forEach { parentView.addSubview($0) }
    }

    override func setupConstraints() {
        headerView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
        }

        closeBarButtonItem.customView?.snp.makeConstraints({ make in
            make.width.height.equalTo(Defaults.Filter.closeButtonHeight)
        })

        tableView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(headerView.snp.bottom)
            make.bottom.equalTo(assignButtonContainer.snp.top)
        }

        assignButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(Defaults.marginNormal)
            make.top.bottom.equalToSuperview().inset(Defaults.marginNormal)
        }

        assignButtonContainer.snp.makeConstraints { make in
            make.bottom.equalBottomSafeArea(parentView)
            make.leading.trailing.equalToSuperview()
        }
    }

}
