//
//  UIViewControllerExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 12.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UIViewController {

    var contentOffset: CGPoint {
        get {
            if let scroll = (self.view.subviews.first { $0 is UIScrollView }) as? UIScrollView {
                return scroll.contentOffset
            }

            return CGPoint(x: 0, y: 0)
        }
        set {
            self.scrollView?.contentOffset = contentOffset
        }
    }

    func enableScroll(_ enabled: Bool) {
        guard let scroll = (self.view.subviews.first { $0 is UIScrollView }) as? UIScrollView else {
            return
        }
        scroll.isScrollEnabled = enabled
    }

    var scrollView: UIScrollView? {
        return self.view.subviews.first { $0 is UIScrollView } as? UIScrollView
    }

    func update(badgeValue: Int?) {
        guard let index = self.tabBarController?.viewControllers?.index(where: {
            (($0 as? UINavigationController)?.topViewController ?? $0).isKind(of: self.classForCoder)
        }) else {
            return
        }
        
        let tabBarItem = self.tabBarController?.tabBar.items?[index]
        
        let maxBadgeValue = 9
        if let badgeValue = badgeValue {
            tabBarItem?.badgeValue = badgeValue > maxBadgeValue ? "\(maxBadgeValue)+" : "\(badgeValue)"
        } else {
            tabBarItem?.badgeValue = nil
        }
    }
    
    var isModal: Bool {
        if let index = navigationController?.viewControllers.index(of: self), index > 0 {
            return false
        } else if presentingViewController != nil {
            return true
        } else if navigationController?.presentingViewController?.presentedViewController == navigationController {
            return true
        } else if tabBarController?.presentingViewController is UITabBarController {
            return true
        } else {
            return false
        }
    }
    
    var isAuthentication: Bool {
        return self is AuthViewController || self is LinkedInAuthViewController 
    }
    
    func hideAllChildren(animated: Bool = false) {
        UIView.animate(withDuration: animated ? 0.4 : 0) {
            self.view.subviews.hideAll()
        }
    }
    
    func showAllChildren(animated: Bool = false) {
        UIView.animate(withDuration: animated ? 0.4 : 0) {
            self.view.subviews.showAll()
        }
    }
    
    var transitionAnimator: UIViewControllerAnimatedTransitioning? {
        if self is FailureViewController { return FadeInAnimator() }
        return nil
    }
    
    func shareNews(url: URL?) {
        guard let url = url else { return }
        let message = Localizable.shareMessage.localized
        
        let allData = [url.absoluteString, message].joined(separator: "\n")
        
        let items: [Any] = [allData]
        let controller = UIActivityViewController(activityItems: items,
                                                  applicationActivities: nil)
        
        if UIDevice.current.userInterfaceIdiom == .pad {
            controller.popoverPresentationController?.sourceView = view
            controller.popoverPresentationController?.sourceRect = view.frame
        }
        
        present(controller, animated: true)
    }

    func open(url: URL?) {
        var strippedUrl = url
        if strippedUrl?.scheme == "applewebdata" {
            let path = strippedUrl!.path
            var urlPart = String(path.suffix(from: path.index(after: path.startIndex)))
            if !urlPart.starts(with: "https://") && !urlPart.starts(with: "http://") {
                urlPart = "https://\(urlPart)"
            }
            strippedUrl = URL(string: urlPart)
        }
        UIApplication.shared.openIfPossible(strippedUrl)
    }
}
