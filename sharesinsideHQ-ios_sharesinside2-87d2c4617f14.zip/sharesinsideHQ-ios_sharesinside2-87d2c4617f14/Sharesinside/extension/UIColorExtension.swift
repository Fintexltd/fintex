//
//  UIColorExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

extension UIColor {
    
    class var primary: UIColor {
        return #colorLiteral(red: 0.2666666667, green: 0.4549019608, blue: 0.7137254902, alpha: 1) //4474B6
    }
    
    class var primaryDark: UIColor {
        return #colorLiteral(red: 0.09803921569, green: 0.2274509804, blue: 0.4039215686, alpha: 1) //193A67
    }
    
    class var grey: UIColor {
        return #colorLiteral(red: 0.5960784314, green: 0.6509803922, blue: 0.6941176471, alpha: 1) //98A6B1
    }
    
    class var lightGrey: UIColor {
        return #colorLiteral(red: 0.9411764706, green: 0.9411764706, blue: 0.9411764706, alpha: 1) //F0F0F0
    }
    
    class var darkGrey: UIColor {
        return #colorLiteral(red: 0.1176470588, green: 0.1294117647, blue: 0.137254902, alpha: 1) //1E2123
    }
    
    class var accent: UIColor {
        return .white
    }
    
    class var background: UIColor {
        return #colorLiteral(red: 0.9607843137, green: 0.9647058824, blue: 0.968627451, alpha: 1) //F5F6F7
    }
    
    class var error: UIColor {
        return #colorLiteral(red: 1, green: 0.03529411765, blue: 0.2274509804, alpha: 1) //FF093A
    }
    
    class var notification: UIColor {
        return #colorLiteral(red: 1, green: 0.4588235294, blue: 0.09803921569, alpha: 1) //FF7519
    }
    
    class var event: UIColor {
        return #colorLiteral(red: 1, green: 0.7058823529, blue: 0, alpha: 1) //FFB400
    }
    
    class var news: UIColor {
        return #colorLiteral(red: 0.262745098, green: 0.7450980392, blue: 0.9960784314, alpha: 1) //43BEFE
    }

    class var project: UIColor {
        return UIColor(red: 51/255, green: 154/255, blue: 66/255, alpha: 1)
    }
    
    class var appGreen: UIColor {
        return UIColor.init(red: 75/255, green: 192/255, blue: 84/255, alpha: 1)
    }
    
    func withAlpha(_ alpha: CGFloat) -> UIColor {
        if self == .clear {
            return self
        }
        
        return self.withAlphaComponent(alpha)
    }
    
    static var random: UIColor {
        var randomValue: CGFloat {
            return CGFloat(arc4random_uniform(255))/255.0
        }
        return UIColor(red: randomValue, green: randomValue, blue: randomValue, alpha: 1)
    }
}
