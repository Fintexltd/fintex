//
//  WKWebViewExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 20/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import WebKit

extension WKWebView {
    
    static func flushCookies() {
        let cookiesJar = HTTPCookieStorage.shared
        cookiesJar.cookies?.forEach { cookie in
            cookiesJar.deleteCookie(cookie)
        }
    }
}
