//
//  DateExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

extension Date {
    
    enum Format: String {
        case apiDateFormat = "yyy-MM-dd HH:mm:ss"
        case appDateFormat = "dd MMMM yyyy"
        case watchlistDateFormat = "dd.MM.yyyy"
        case ohlcDateFormat = "yyyy-MM-dd"
        case datePickerFormat = "dd MMM yyyy"
        case eventDateFormat = "dd MMM yyyy, h:mm a"
        case chartFormat = "dd.MM"
    }
    
    private static var localeUsFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US")
        return formatter
    }

    func toTimezone(timezone: TimeZone? = nil) -> Date? {
        guard let timezone = (timezone ?? TimeZone.autoupdatingCurrent) else {
            return nil
        }
        let seconds = TimeInterval(timezone.secondsFromGMT(for: self))
        return Date(timeInterval: seconds, since: self)
    }

    func toString(withFromat format: Format = Format.appDateFormat) -> String {
        let formatter = Date.localeUsFormatter
        formatter.dateFormat = format.rawValue

        return formatter.string(from: self)
    }
    
    static func from(string date: String, withFormat format: Format = Format.apiDateFormat) -> Date? {
        let formatter = Date.localeUsFormatter
        formatter.dateFormat = format.rawValue
        
        return formatter.date(from: date)
    }
    
    func weekOfYear() -> Int {
        return Calendar.current.component(.weekOfYear, from: self)
    }
    
    var prettyPrintedWatchlist: String {
        let calendar = NSCalendar.current
        let now = NSDate()
        let earliest = now.earlierDate(self)
        let latest = (earliest == (now as Date)) ? self : (now as Date)
        let components = calendar.dateComponents([.hour, .minute], from: earliest, to: latest)
        
        if let minutes = components.minute,
            let hours = components.hour, minutes == 0 && hours == 0 {
            return Localizable.watchlistJustNow.localized
        }
        
        if let minutes = components.minute, 1...60 ~= minutes, components.hour ?? 0 < 1 {
            return "\(minutes) \(Localizable.watchlistMinutesAgo.localized)"
        }
        
        let hourCount = hours(for: components)
        if 1...24 ~= hourCount {
            return "\(hourCount) \(Localizable.watchlistHoursAgo.localized)"
        }
        
        let formatter = Date.localeUsFormatter
        formatter.dateFormat = Format.watchlistDateFormat.rawValue
        return formatter.string(from: self)
    }
    
    private func hours(for components: DateComponents) -> Int {
        var hours = components.hour ?? 0
        if shouldRoundUpHours(for: components) { hours += 1 }
        
        return hours
    }
    
    private func shouldRoundUpHours(for components: DateComponents) -> Bool {
        return (components.hour ?? 0) > 0 && (components.minute ?? 0) >= 30
    }
    
    func startOfMonth() -> Date {
        let date =  Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Calendar.current.startOfDay(for: self)))!
        return date 
    }
    
    func endOfMonth() -> Date {
        return Calendar.current.date(byAdding: DateComponents(month: 1, day: -1), to: self.startOfMonth())!
    }

    var prettyPrintedNotificationsDate: String {
        let calendar = NSCalendar.current
        let now = NSDate()
        let earliest = now.earlierDate(self)
        let latest = (earliest == (now as Date)) ? self : (now as Date)
        let components = calendar.dateComponents([.hour, .minute, .day, .month, .year], from: earliest, to: latest)
        
        if let minutes = components.minute,
            let hours = components.hour, minutes == 0 && hours == 0 {
            return Localizable.watchlistJustNow.localized
        }
        
        let minutes = components.minute ?? 0
        let hourCount = components.hour ?? 0
        let days = components.day ?? 0
        let weeks = days / 7
        let months = components.month ?? 0
        let years = components.year ?? 0
        
        if years > 0 { return "\(years)\(Localizable.appNotificationsYearsAgo.localized)" }
        if months > 0 { return "\(months)\(Localizable.appNotificationsMonthsAgo.localized)" }
        if weeks > 0 { return "\(weeks)\(Localizable.appNotificationsWeeksAgo.localized)" }
        if days > 0 { return "\(days)\(Localizable.appNotificationsDaysAgo.localized)" }
        if hourCount > 0 { return "\(hourCount)\(Localizable.watchlistHoursAgo.localized)" }
        if minutes > 0 { return "\(minutes)\(Localizable.watchlistMinutesAgo.localized)" }
        return Localizable.watchlistJustNow.localized
    }
}
