//
//  ConstraintMakerExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 12.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import SnapKit

extension ConstraintMakerRelatable {
    
    @discardableResult
    func equalBottomSafeArea(_ other: UIView) -> ConstraintMakerEditable {
        if #available(iOS 11.0, *) {
            return equalTo(other.safeAreaLayoutGuide.snp.bottom)
        } else {
            return equalTo(other.snp.bottom)
        }
    }
    
    @discardableResult
    func equalTopSafeArea(_ other: UIView) -> ConstraintMakerEditable {
        if #available(iOS 11.0, *) {
            return equalTo(other.safeAreaLayoutGuide.snp.top)
        } else {
            return equalTo(other.snp.top)
        }
    }
}
