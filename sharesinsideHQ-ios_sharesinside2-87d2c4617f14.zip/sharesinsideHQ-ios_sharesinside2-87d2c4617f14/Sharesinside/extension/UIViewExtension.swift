//
//  UIViewExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

extension UIView {
    
    class var horizontalDivider: UIView {
        let view = UIView().layoutable()
        view.backgroundColor = .grey
        view.snp.makeConstraints { make in
            make.height.equalTo(Defaults.dividerSize)
        }
        return view
    }
    
    func snapshot() -> UIImage {
        UIGraphicsBeginImageContextWithOptions(bounds.size, false, UIScreen.main.scale)
        drawHierarchy(in: bounds, afterScreenUpdates: true)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return result!
    }

    func applyPrimaryGradient() -> CAGradientLayer {
        return applyGradient(colors: [UIColor.primary.cgColor, UIColor.primaryDark.cgColor], locations: [0.0, 0.7])
    }
    
    func applyGradient(colors: [CGColor], locations: [NSNumber]?) -> CAGradientLayer {
        let gradient = CAGradientLayer()
        gradient.frame = self.bounds
        gradient.colors = colors
        gradient.locations = locations
        self.layer.insertSublayer(gradient, at: 0)
        
        return gradient
    }

    @discardableResult
    func layoutable() -> Self {
        translatesAutoresizingMaskIntoConstraints = false
        return self
    }

    func embedInView() -> UIView {
        let view = UIView().layoutable()
        view.addSubview(self)
        return view
    }
    
    func embedInButton() -> UIButton {
        let button = UIButton(type: .custom).layoutable()
        button.addSubview(self)
        return button
    }

    func setContentPriority(resistancePriority: UILayoutPriority? = nil,
                            resistanceAxis: NSLayoutConstraint.Axis = .horizontal,
                            huggingPriority: UILayoutPriority? = nil,
                            huggingAxis: NSLayoutConstraint.Axis = .horizontal) {

        if let resistancePriority = resistancePriority {
            self.setContentCompressionResistancePriority(resistancePriority, for: resistanceAxis)
        }

        if let huggingPriority = huggingPriority {
            self.setContentHuggingPriority(huggingPriority, for: huggingAxis)
        }
    }
    
    func cornerRadius(_ radius: CGFloat = Defaults.buttonCornerRadius) {
        layer.cornerRadius = radius
        clipsToBounds = true
    }
    
    func round() {
        layer.cornerRadius = frame.width / 2
        clipsToBounds = true
    }
    
    func setupGestureRecognizer(target: Any, selector: Selector) {
        let recongnizer = UITapGestureRecognizer(target: target, action: selector)
        isUserInteractionEnabled = true
        addGestureRecognizer(recongnizer)
    }
    
}
// MARK: - Factory methods
extension UIView {
    
    static func makeSectionHeader(title: String) -> UIView {
        
        func setupConstraints(view: UIView, label: UILabel, divider: UIView) {
            label.snp.makeConstraints { make in
                make.leading.trailing.equalToSuperview().inset(Defaults.marginBig).priority(.highest)
                make.bottom.equalToSuperview().inset(Defaults.marginTiny)
            }
            divider.snp.makeConstraints { make in
                make.height.equalTo(Defaults.dividerSize)
                make.leading.trailing.bottom.equalToSuperview()
            }
            view.snp.makeConstraints { make in
                make.height.equalTo(Defaults.CompanyMember.headerHeight)
            }
        }
        let view = UIView().layoutable()
        let label = UILabelFactory.styled(textColor: .grey, withFontSize: Defaults.TextSize.medium, fontWeight: .regular)
        let divider = UIView.horizontalDivider
        view.backgroundColor = .background
        label.textAlignment = .left
        label.text = title.uppercased()
        view.addSubview(label)
        view.addSubview(divider)
        setupConstraints(view: view, label: label, divider: divider)
        
        return view
    }
}

extension Array where Element: UIView {
  
    func embedInView() -> UIView {
        let view = UIView()
        
        self.forEach { view.addSubview($0) }
        return view
    }
    
    func embedInStackView(axis: NSLayoutConstraint.Axis = .vertical) -> UIStackView {
        return UIStackView.make(axis: axis, with: self)
    }
    
}
