//
//  UIFontExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UIFont {
    
    func withTraits(traits: UIFontDescriptor.SymbolicTraits...) -> UIFont? {
        guard let descriptorL = self.fontDescriptor.withSymbolicTraits(UIFontDescriptor.SymbolicTraits(traits)) else {
            return nil
        }
        return UIFont(descriptor: descriptorL, size: 0)
    }
    
    func boldItalic() -> UIFont? {
        return withTraits(traits: .traitBold, .traitItalic)
    }
}
