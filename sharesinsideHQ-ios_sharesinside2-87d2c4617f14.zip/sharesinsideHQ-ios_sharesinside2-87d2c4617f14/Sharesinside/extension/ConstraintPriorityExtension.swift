//
//  ConstraintPriorityExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 11.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import SnapKit

extension ConstraintPriority {
    static let highest = ConstraintPriority(999)
}
