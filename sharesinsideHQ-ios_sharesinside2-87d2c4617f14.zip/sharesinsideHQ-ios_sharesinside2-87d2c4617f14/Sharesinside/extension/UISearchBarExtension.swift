//
//  UISearchBarExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 13/11/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UISearchBar {
    func changeTextColor(to color: UIColor) {
        if let searchTextField = self.value(forKey: "searchField") as? UITextField {
            searchTextField.textColor = color
        }
    }
}
