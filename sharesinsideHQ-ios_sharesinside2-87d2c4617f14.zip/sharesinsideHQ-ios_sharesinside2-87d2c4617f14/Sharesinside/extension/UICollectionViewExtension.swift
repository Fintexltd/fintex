//
//  UICollectionViewExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

extension UICollectionView {
    
    static func makeCustomCollectionView<T: UICollectionView>(type: T.Type, scrollDirection: UICollectionView.ScrollDirection = .vertical, lineSpacing: CGFloat = 0, interItemSpacing: CGFloat = 0) -> T {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = scrollDirection
        flowLayout.minimumLineSpacing = lineSpacing
        flowLayout.minimumInteritemSpacing = interItemSpacing
        
        let collectionView = T(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.layoutable()
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.backgroundColor = .clear
        collectionView.alwaysBounceVertical = true
        return collectionView
    }
    
    func registerCell(_ cellClass: UICollectionViewCell.Type) {
        self.register(cellClass, forCellWithReuseIdentifier: cellClass.className)
    }
    
    func registerHeaderView(_ headerClass: UICollectionReusableView.Type) {
        self.register(headerClass, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: headerClass.className)
    }
    
    func registerFooterView(_ footerClass: UICollectionReusableView.Type) {
        self.register(footerClass, forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: footerClass.className)
    }
    
    func dequeueReusableCell<T: UICollectionViewCell>(for indexPath: IndexPath) -> T? {
        return dequeueReusableCell(withReuseIdentifier: T.className, for: indexPath) as? T
    }
    
    func dequeueReusableHeaderView<T: UICollectionReusableView>(for indexPath: IndexPath) -> T? {
        return dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: T.className, for: indexPath) as? T
    }
    
    func dequeueReusableFooterView<T: UICollectionReusableView>(for indexPath: IndexPath) -> T? {
        return dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: T.className, for: indexPath) as? T
    }
    
    /// Return indexPath of cell that is visible in central point of collectionView
    var indexPathForCentralItem: IndexPath? {
        
        var visibleRect = CGRect()
        visibleRect.origin = contentOffset
        visibleRect.size = frame.size
        
        let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
        
        return indexPathForItem(at: visiblePoint)
    }
    
    /// Return cell that is visible in central point of collectionView
    var centralCell: UICollectionViewCell? {
        guard let centralIndex = indexPathForCentralItem else {
            return nil
        }
        return cellForItem(at: centralIndex)
    }
}
