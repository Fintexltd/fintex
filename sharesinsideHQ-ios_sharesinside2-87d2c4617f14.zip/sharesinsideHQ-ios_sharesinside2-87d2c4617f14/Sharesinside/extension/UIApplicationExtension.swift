//
//  UIApplicationExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 31.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UIApplication {
    
    func openIfPossible(_ url: URL?) {
        guard let url = url else { return }
        if canOpenURL(url) {
            open(url, options: convertToUIApplicationOpenExternalURLOptionsKeyDictionary([:]), completionHandler: nil)
        }
    }
    
    func logoutUser() {
        Config.logout()
        
        let welcomeController = BaseNavigationController(rootViewController: WelcomeViewController())
        keyWindow?.setRootViewController(welcomeController, options: UIWindow.TransitionOptions(direction: .fromRight, style: .easeInOut))
    }
    
    var visibleViewController: UIViewController? {
        return getTopMostViewController()
    }
    
    private func getTopMostViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return getTopMostViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return getTopMostViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return getTopMostViewController(base: presented)
        }
        return base
    }
}

// Helper function inserted by Swift 4.2 migrator.
private func convertToUIApplicationOpenExternalURLOptionsKeyDictionary(_ input: [String: Any]) -> [UIApplication.OpenExternalURLOptionsKey: Any] {
	return Dictionary(uniqueKeysWithValues: input.map { key, value in (UIApplication.OpenExternalURLOptionsKey(rawValue: key), value)})
}
