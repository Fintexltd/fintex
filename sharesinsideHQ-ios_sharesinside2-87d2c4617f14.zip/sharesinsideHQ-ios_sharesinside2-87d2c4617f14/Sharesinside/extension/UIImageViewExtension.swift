//
//  UIImageViewExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit
import Kingfisher

extension UIImageView {
    
    func load(with url: URL?) {
        guard let imageUrl = url else {
            backgroundColor = .lightGrey
            return
        }
        
        kf.setImage(with: ImageResource(downloadURL: imageUrl),
                    options: [.backgroundDecode]) { [weak self] (_, error, _, _) in
            self?.backgroundColor = error == nil ? .clear : .lightGrey
        }
    }
}
