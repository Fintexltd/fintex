//
//  EncodableExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

extension Encodable {
    func asDictionary() -> [String: Any]? {
        guard let data = try? JSONEncoder().encode(self) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data, options: .allowFragments)).flatMap { $0 as? [String: Any] }
    }
}
