//
//  UINavigationControllerExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 21.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UINavigationController {
    
    func controllerOnStack(withType type: AnyClass) -> UIViewController? {
        return self.viewControllers.reversed().first(where: { $0.isKind(of: type) })
    }
    
    func push(viewController: UIViewController, animated: Bool, completion: @escaping () -> Void = {}) {
            pushViewController(viewController, animated: animated)
        
        guard animated, let coordinator = transitionCoordinator else {
            completion()
            return
        }
        
        coordinator.animate(alongsideTransition: nil) { _ in
            completion()
        }
    }
    
    func remove(viewController: UIViewController) {
        if let index = viewControllers.index(of: viewController) {
            viewControllers.remove(at: index)
        }
    }
    
    func removeOthers() {
        viewControllers.removeSubrange(0 ..< (viewControllers.count - 1))
    }
}
