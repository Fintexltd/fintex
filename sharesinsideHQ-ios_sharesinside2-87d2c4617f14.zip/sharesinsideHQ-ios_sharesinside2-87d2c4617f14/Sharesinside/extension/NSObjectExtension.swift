//
//  NSObjectExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 05.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation

extension NSObject {
    
    class var className: String {
        let namespaceClassName = NSStringFromClass(self)
        return namespaceClassName.components(separatedBy: ".").last!
    }
    
    var className: String {
        let namespaceClassName = NSStringFromClass(self.classForCoder)
        return namespaceClassName.components(separatedBy: ".").last!
    }
}
