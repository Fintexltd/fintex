//
//  NSMutableAttributedTextExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 20.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension NSMutableAttributedString {
    
    func withSystemFont(ofSize size: CGFloat) -> Self {
        enumerateAttributes(in: NSRange(location: 0, length: self.length)) { (keys, range, _) in
            if let oldFont = keys[.font] as? UIFont {
                self.addAttribute(.font, value: UIFont.systemFont(ofSize: size)
                    .withTraits(traits: oldFont.fontDescriptor.symbolicTraits) ??
                    UIFont.systemFont(ofSize: size), range: range)
            }
        }
        return self
    }
    
    func with(breakMode: NSLineBreakMode) -> Self {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineBreakMode = breakMode
        let range = NSRange(location: 0, length: self.length)
        self.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
        return self
    }
}
