//
//  UILabelExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UILabel {

    var isTruncated: Bool {
        let size = (self.text as NSString?)?.size(withAttributes: [.font: self.font])
        return (size?.width ?? 0) > (self.bounds.size.width * CGFloat(self.numberOfLines))
    }
}
