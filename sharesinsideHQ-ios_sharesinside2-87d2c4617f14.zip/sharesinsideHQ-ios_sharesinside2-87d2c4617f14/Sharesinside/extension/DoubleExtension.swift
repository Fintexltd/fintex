//
//  DoubleExtension.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 08/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

extension Double {
    
    var cashFormat: String {
        let substrings = String(format: "%.2f", self).components(separatedBy: ".")
        let smallerThenOneValue: String = {
            if let value = substrings.last, value != "00" { return "." + value }
            return ".00"
        }()
        let formattedValue = substrings.first ?? "0"
        
        return formattedValue + smallerThenOneValue
    }
}
