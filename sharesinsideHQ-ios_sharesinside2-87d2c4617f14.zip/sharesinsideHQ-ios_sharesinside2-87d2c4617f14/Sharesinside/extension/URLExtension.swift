//
//  URLExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 24.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

extension URL {
    
    init?(string: String?) {
        guard let string = string?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) else { return nil }
        self.init(string: string)
    }

    static func forQuery(using string: String?) -> URL? {
        guard let string = string?.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) else { return nil }
        return URL(string: string)
    }
}
