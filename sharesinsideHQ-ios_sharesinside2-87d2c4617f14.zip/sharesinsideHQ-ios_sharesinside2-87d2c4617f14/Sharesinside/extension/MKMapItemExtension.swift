//
//  MKMapItemExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 30/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import MapKit

extension MKMapItem {
    
    static func openMaps(for address: GPSConvertible, distance: CLLocationDistance = 10000) {
        guard let coordinates = address.gpsCoordinates else { return }
        let regionSpan = MKCoordinateRegion(center: coordinates, latitudinalMeters: distance, longitudinalMeters: distance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = address.locationName
        mapItem.openInMaps(launchOptions: options)
    }
}
