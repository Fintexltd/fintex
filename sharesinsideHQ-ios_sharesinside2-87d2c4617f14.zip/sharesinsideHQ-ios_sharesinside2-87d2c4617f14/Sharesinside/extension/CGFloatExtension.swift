//
//  CGFloatExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 11.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension CGFloat {
    
    func negative() -> CGFloat {
        return self * (self < 0 ? 1 : -1)
    }
}
