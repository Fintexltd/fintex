//
//  UITableViewExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 07.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import UIKit

extension UITableView {
    
    func registerHeaderFooter(_ headerFooterClass: UITableViewHeaderFooterView.Type) {
        self.register(headerFooterClass, forHeaderFooterViewReuseIdentifier: headerFooterClass.className)
    }
    
    func registerCell(_ cellClass: UITableViewCell.Type) {
        self.register(cellClass, forCellReuseIdentifier: cellClass.className)
    }
    
    func dequeueReusableCell<T: UITableViewCell>(for indexPath: IndexPath) -> T? {
        return dequeueReusableCell(withIdentifier: T.className, for: indexPath) as? T
    }
    
    func dequeueReusableHeaderFooter<T: UIView>() -> T? {
        return dequeueReusableHeaderFooterView(withIdentifier: T.className) as? T
    }
    
    func layoutableTableHeaderView(header: UIView) {
        self.tableHeaderView = header
        header.setNeedsLayout()
        header.layoutIfNeeded()
        header.frame.size = header.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        self.tableHeaderView = header
    }
}
