//
//  UIStackViewExtension.swift
//  Oknoplast
//
//  Created by Damian Włodarczyk on 24.05.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UIStackView {
    
    static func make(axis: NSLayoutConstraint.Axis,
                     with views: [UIView],
                     spacing: CGFloat = 0,
                     alignment: UIStackView.Alignment = .fill,
                     distribution: UIStackView.Distribution = .fill) -> UIStackView {
        let stackView = UIStackView(arrangedSubviews: views).layoutable()
        stackView.axis = axis
        stackView.spacing = spacing
        stackView.alignment = alignment
        stackView.distribution = distribution
        
        return stackView
    }
    
    func removeAllArrangedSubviews() {
        
        let removedSubviews = arrangedSubviews.reduce([]) { (allSubviews, subview) -> [UIView] in
            self.removeArrangedSubview(subview)
            return allSubviews + [subview]
        }
        NSLayoutConstraint.deactivate(removedSubviews.flatMap({ $0.constraints }))
        removedSubviews.forEach({ $0.removeFromSuperview() })
    }
}
