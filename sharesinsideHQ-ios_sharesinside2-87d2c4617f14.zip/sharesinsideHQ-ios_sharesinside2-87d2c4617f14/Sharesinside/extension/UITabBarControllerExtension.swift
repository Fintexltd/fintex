//
//  UITabBarControllerExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 14.08.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UITabBarController {
    
    var baseNavigationControllers: [BaseNavigationController]? {
        return viewControllers?.compactMap { $0 as? BaseNavigationController }
    }

    func viewController(ofType type: AnyClass) -> ViewController? {
        return baseNavigationControllers?.first(where: {
            $0.rootViewController?.isKind(of: type) ?? false
        })?.rootViewController as? ViewController
    }
}
