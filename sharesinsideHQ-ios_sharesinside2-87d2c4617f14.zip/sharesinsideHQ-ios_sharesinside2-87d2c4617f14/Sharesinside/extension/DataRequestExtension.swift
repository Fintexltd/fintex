//
//  DataRequest.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import Alamofire
import RxSwift

extension DataRequest {
    func validateResponse<E: Decodable>(output: E.Type) -> Observable<E> {
        return Observable.create({ (subscriber) -> Disposable in
            self.validate { _, response, data in
                if var errorResponse = try? JSONDecoder().decode(ErrorResponse.self, from: data!) {
                    errorResponse.status = response.statusCode
                    printDebug(errorResponse)
                    subscriber.onError(errorResponse)
                    return .failure(errorResponse)
                }

                guard 200 ... 299 ~= response.statusCode else {
                    let errorDictionary = (try? JSONSerialization.jsonObject(with: data!) as? [String: Any])
                    let message = errorDictionary??["message"] as? String ?? ""
                    let error = ErrorResponse(message: message,
                                              status: response.statusCode,
                                              error: nil,
                                              errors: nil)
                    subscriber.onError(error)
                    return .failure(error)
                }

                do {
                    let responseModel = try JSONDecoder().decode(output, from: data!)
                    subscriber.onNext(responseModel)
                    subscriber.onCompleted()
                } catch {
                    printDebug(error)
                    subscriber.onError(error)
                    return .failure(error)
                }

                return .success
            }

            return Disposables.create()
        })
    }
}
