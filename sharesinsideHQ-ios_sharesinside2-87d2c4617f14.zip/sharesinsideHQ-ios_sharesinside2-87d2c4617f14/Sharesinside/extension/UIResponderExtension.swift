//
//  UIResponderExtension.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 03/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UIResponder {
    
    var viewController: UIViewController? {
        guard let nextResponder = self.next else { return nil }
        return nextResponder as? UIViewController ?? nextResponder.viewController
    }
    
}
