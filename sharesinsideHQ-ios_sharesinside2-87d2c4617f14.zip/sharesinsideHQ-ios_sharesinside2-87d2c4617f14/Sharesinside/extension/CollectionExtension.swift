//
//  CollectionExtension.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 13/08/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension Collection {
    func safeSuffix(_ maxLength: Int) -> [Element] {
        guard let index = self.index(endIndex, offsetBy: -maxLength, limitedBy: startIndex) else {
            return Array(self[startIndex ..< endIndex])
        }
        return Array(self[index ..< endIndex])
    }
}

extension Collection where Element == UIView {
    func hideAll() {
        forEach { $0.alpha = 0 }
    }
    
    func showAll() {
        forEach { $0.alpha = 1 }
    }
}
