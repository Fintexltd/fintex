//
//  CGPointExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 28/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension CGSize {
    
    static func galleryPhotoSize(for collectionView: UICollectionView) -> CGSize {
        let horizontalSpacing = (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.minimumInteritemSpacing ?? 0
        let insets = (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.sectionInset  ?? .zero
        let itemsInLine = CGSize.photosPerLine(for: collectionView)
        let availableSpace = collectionView.frame.width - (CGFloat(itemsInLine - 1) * horizontalSpacing) - insets.left - insets.right
        
        let size = availableSpace / CGFloat(itemsInLine)
        return CGSize(width: size, height: size)
    }
    
    private static func photosPerLine(for collectionView: UICollectionView) -> Int {
        let insets = (collectionView.collectionViewLayout as? UICollectionViewFlowLayout)?.sectionInset  ?? .zero
        let availableWidth = collectionView.frame.width - insets.left - insets.right
        let minItems = Defaults.CompanyDetails.Gallery.minItemsPerLine
        return max(minItems, Int(availableWidth / Defaults.CompanyDetails.Gallery.prefferedCellSize))
    }
}
