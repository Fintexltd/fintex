//
//  IQKeyboardManagerExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 22.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import IQKeyboardManagerSwift

extension IQKeyboardManager {
    
    func goNextOrResign() {
        _ = self.canGoNext ? self.goNext() : self.resignFirstResponder()
    }
}
