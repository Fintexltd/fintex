//
//  SequenceExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 26.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

extension Sequence where Iterator.Element: Equatable {

    var uniqueElements: [Iterator.Element] {
        return self.reduce([]) { uniqueElements, element in
            uniqueElements.contains(element)
                ? uniqueElements
                : uniqueElements + [element]
        }
    }
}

extension Sequence where Iterator.Element == Publication {
    
    var uniqueElements: [Iterator.Element] {
        return self.reduce([]) { uniqueElements, element in
            uniqueElements.contains(where: { $0.watchlistId == element.watchlistId })
                ? uniqueElements
                : uniqueElements + [element]
        }
    }
}

extension Sequence where Iterator.Element == Relation {
    
    var uniqueElements: [Iterator.Element] {
        return self.reduce([]) { uniqueElements, element in
            uniqueElements.contains(where: { $0.id == element.id })
                ? uniqueElements
                : uniqueElements + [element]
        }
    }
}

extension Sequence where Iterator.Element == Symbol {
    var validSymbols: [Iterator.Element] {
        return filter { $0.isValid }
    }
}

extension Sequence where Iterator.Element == UserGroup {
    var publicationGroups: [UserGroup] {
        return self.compactMap({
            ($0 == .shareholder || $0 == .vip) ? $0 : nil
        })
    }
}
