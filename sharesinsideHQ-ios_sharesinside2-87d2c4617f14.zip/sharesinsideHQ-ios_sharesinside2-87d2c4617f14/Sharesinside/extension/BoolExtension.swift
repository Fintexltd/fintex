//
//  BoolExtension.swift
//  Sharesinside
//
//  Created by Michał Wójtowicz on 12.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation

extension Bool {
    
    mutating func toggle() {
        self = !self
    }
}
