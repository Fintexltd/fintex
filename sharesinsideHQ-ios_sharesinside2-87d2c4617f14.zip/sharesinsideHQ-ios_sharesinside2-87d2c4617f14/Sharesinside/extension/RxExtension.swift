//
//  RxExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 09.05.2018.
//  Copyright © 2018 Damian Włodarczyk. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxAlamofire
import Alamofire

// MARK: Disposable extension
extension Disposable {

    public func managed(by disposable: CompositeDisposable) {
        _ = disposable.insert(self)
    }
}

// MARK: Helper for filtering nil values and return non optional value in onSubscribe
public protocol OptionalType {
    associatedtype Wrapped

    var optional: Wrapped? { get }
}

extension Optional: OptionalType {
    public var optional: Wrapped? { return self }
}

extension Driver where Element: OptionalType {
    func ignoreNil() -> Driver<Element.Wrapped> {
        return flatMap { value in
            value.optional.map { Driver<Element.Wrapped>.just($0) } ?? Driver<Element.Wrapped>.empty()
        }
    }
}

extension ObservableType where E: OptionalType {
    func ignoreNil() -> Observable<E.Wrapped> {
        return flatMap { value in
            value.optional.map { Observable<E.Wrapped>.just($0) } ?? Observable<E.Wrapped>.empty()
        }
    }
}

// MARK: Helpers for api requests
extension ObservableType {
    func applyLoader(withMessage message: String? = nil,
                     andBehaviorRelay loaderBehaviorRelay: BehaviorRelay<Bool>) -> Observable<E> {
        return self.do(onSubscribe: { loaderBehaviorRelay.accept(true) },
                       onDispose: { loaderBehaviorRelay.accept(false) })
    }
}

extension ObservableType where E == DataRequest {

    func mapToObject<E: Decodable>() -> Observable<E> {
        return self.flatMap { request in
            return request.log().validateResponse(output: E.self)
        }.catchError({ error -> Observable<E> in
            let errorCode = (error as NSError).code
            let noInternetConnectionErrorCode = -1009
            if errorCode == noInternetConnectionErrorCode {
                return Observable.error(ErrorResponse(message: Localizable.apiNoInternet.localized,
                                        status: errorCode, error: nil, errors: nil))
            }
            
            if let error = error as? ErrorResponse, error.status == ApiError.notAuthorized.rawValue {
                DispatchQueue.main.async {
                    (UIApplication.shared.delegate as? AppDelegate)?.userUnauthorized()
                }
            }
            return Observable.error(error)
        })
    }
}

extension Reactive where Base: UIViewController {
    
    var firstTimeViewDidAppear: Single<Void> {
        return sentMessage(#selector(Base.viewDidAppear(_:)))
            .map {_ in Void() }
            .take(1)
            .asSingle()
    }
}
