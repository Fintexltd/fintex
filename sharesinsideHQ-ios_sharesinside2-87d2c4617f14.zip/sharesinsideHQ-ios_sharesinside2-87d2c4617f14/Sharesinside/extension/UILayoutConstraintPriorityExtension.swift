//
//  UILayoutConstraintPriorityExtension.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 13.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import UIKit

extension UILayoutPriority {
    
    func decreased(by value: Float) -> UILayoutPriority {
        return UILayoutPriority(max(self.rawValue - value, 0))
    }
    
    func increased(by value: Float) -> UILayoutPriority {
        let newValue = self.rawValue + value
        return UILayoutPriority(min(newValue, UILayoutPriority.required.rawValue))
    }
}
