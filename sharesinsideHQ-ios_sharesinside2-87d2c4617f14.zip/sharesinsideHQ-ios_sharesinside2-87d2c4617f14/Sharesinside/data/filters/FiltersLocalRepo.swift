//
//  FiltersLocalRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FiltersLocalRepo {
    
    private let mostViewed = SortFilter(type: .mostViewed, sortType: .mostViewed, id: 0, name: Localizable.filtersMostViewed.localized, isSelected: false)
    
    private let adHoc = AdHocFilter(type: .adhoc, id: 0, name: Localizable.filtersAdhoc.localized, isSelected: false)
    
    private let location = LocationFilter(type: .location, id: 0, name: Localizable.filtersLocation.localized, isSelected: false)
    
    private let tomorrowEvents = TomorrowEventsFilter(type: .tomorrow, id: 0, name: Localizable.filtersTomorrow.localized, isSelected: false)
    
    private let todayEvents = TodayEventsFilter(type: .today, id: 0, name: Localizable.filtersToday.localized, isSelected: false)
   
    func getCompanyRelationFilters() -> Observable<[CompanyRelation]> {
        return Observable.just(Companies.relations)
    }

    func getFundManagerRelationFilters() -> Observable<[FundManagerRelation]> {
        return Observable.just(FundManagers.relations)
    }

    func getStartupRelationFilters() -> Observable<[StartupRelation]> {
        return Observable.just(Startups.relations)
    }
    
    func getWatchlistRelationFilters() -> Observable<[WatchlistRelation]> {
        return Observable.just(Watchlist.relations)
    }
    
    func getCompanyPredefinedFilters() -> Observable<[Filter]> {
        return Observable.just([mostViewed] + Companies.relations)
    }

    func getFundManagerPredefinedFilters() -> Observable<[Filter]> {
        return Observable.just(FundManagers.relations)
    }

    func getStartupPredefinedFilters() -> Observable<[Filter]> {
        return Observable.just(Startups.relations)
    }
    
    func getWatchlistPredefinedFilters() -> Observable<[Filter]> {
        return Observable.just([adHoc] + Watchlist.relations)
    }
    
    func getEventsPredefinedFilters() -> Observable<[Filter]> {
        return Observable.just([location] + [todayEvents] + [tomorrowEvents] + Watchlist.relations)
    }
    
    func getAttachments() -> Observable<[Attachment]> {
        return Observable.just(Watchlist.attachments)
    }
    
    func getRelationFilters() -> Observable<[RelationsRelation]> {
        return Observable.just(Relations.relations)
    }

    func getManagementFee() -> Observable<[ManagementFee]> {
        Observable.just([
            ManagementFee(id: 0, rangeType: .from, value: nil),
            ManagementFee(id: 1, rangeType: .to, value: nil)
        ])
    }

    func getPerformanceFee() -> Observable<[PerformanceFee]> {
        Observable.just([
            PerformanceFee(id: 0, rangeType: .from, value: nil),
            PerformanceFee(id: 1, rangeType: .to, value: nil)
        ])
    }

    func getRaisedAmount() -> Observable<[RaisedAmount]> {
        Observable.just([
            RaisedAmount(id: 0, rangeType: .from, value: nil),
            RaisedAmount(id: 1, rangeType: .to, value: nil)
        ])
    }

    func getDuration() -> Observable<[Duration]> {
        Observable.just([
            Duration(id: 0, rangeType: .from, value: nil),
            Duration(id: 1, rangeType: .to, value: nil)
        ])
    }

    func getTradingFrequency() -> Observable<[TradingFrequency]> {
        Observable.just(TradingFrequencyType.allCases.indices.map {
            TradingFrequency(id: $0, isSelected: false, tradingFrequencyType: TradingFrequencyType.allCases[$0])
        })
    }

    func getActivePassive() -> Observable<[ActivePassive]> {
        return Observable.just([
            ActivePassive(id: 0, isSelected: false, activePassiveType: .active),
            ActivePassive(id: 1, isSelected: false, activePassiveType: .passive)
        ])
    }

    func getEquityFund() -> Observable<[EquityFund]> {
        return Observable.just([
            EquityFund(id: 0, isSelected: false, equityFundType: .equity),
            EquityFund(id: 1, isSelected: false, equityFundType: .fund)
        ])
    }

    func getOpenClose() -> Observable<[OpenClose]> {
        return Observable.just([
            OpenClose(id: 0, isSelected: false, openCloseType: .open),
            OpenClose(id: 1, isSelected: false, openCloseType: .close)
        ])
    }
    
    func getPublicities() -> Observable<[Publicity]> {
        return Observable.just([
            Publicity(id: 0, name: "Public", isSelected: false, apiParam: "public"),
            Publicity(id: 1, name: "Shareholder", isSelected: false, apiParam: "business"),
            Publicity(id: 2, name: "VIP", isSelected: false, apiParam: "internal"),
            Publicity(id: 3, name: "Investor", isSelected: false, apiParam: "investor")
        ])
    }

    func getFundTypes() -> Observable<[FundTypeFilter]> {
        return Observable.just([
            FundTypeFilter(id: 0, name: "Non-regulated", isSelected: false, apiParam: "non-regulated"),
            FundTypeFilter(id: 1, name: "Professional investment", isSelected: false, apiParam: "professional-investment"),
            FundTypeFilter(id: 2, name: "Retail", isSelected: false, apiParam: "retail"),
            FundTypeFilter(id: 3, name: "Listed", isSelected: false, apiParam: "listed"),
            FundTypeFilter(id: 4, name: "UCTS", isSelected: false, apiParam: "ucts"),
            FundTypeFilter(id: 5, name: "ETF's", isSelected: false, apiParam: "etf-s")
        ])
    }
}

extension FiltersLocalRepo {
    private enum Companies {
        static let relations = [
            CompanyRelation(id: 0, name: "Follower", isSelected: false),
            CompanyRelation(id: 1, name: "Shareholder", isSelected: false),
            CompanyRelation(id: 2, name: "VIP", isSelected: false)
        ]
    }

    private enum FundManagers {
        static let relations = [
            FundManagerRelation(id: 0, name: "Follower", isSelected: false),
            FundManagerRelation(id: 1, name: "VIP", isSelected: false),
            FundManagerRelation(id: 2, name: "Investor", isSelected: false)
        ]
    }

    private enum Startups {
        static let relations = [
            StartupRelation(id: 0, name: "Follower", isSelected: false),
            StartupRelation(id: 1, name: "VIP", isSelected: false),
            StartupRelation(id: 2, name: "Investor", isSelected: false)
        ]
    }
    
    private enum Watchlist {
        static let relations = [
            WatchlistRelation(id: 0, name: "Shareholder", isSelected: false),
            WatchlistRelation(id: 1, name: "VIP", isSelected: false),
            WatchlistRelation(id: 2, name: "Investor", isSelected: false)
            ]
        
        static let attachments = [
            Attachment(id: 0, name: "Documents", isSelected: false),
            Attachment(id: 1, name: "Links", isSelected: false),
            Attachment(id: 2, name: "Images", isSelected: false),
            Attachment(id: 3, name: "Videos", isSelected: false)
        ]
    }
    
    private enum Relations {
        static var relations: [RelationsRelation] {
            var alwaysVisibleGroups: [UserGroup] = [.vip, .shareholder, .follower]
            alwaysVisibleGroups.append(contentsOf: AppUser.current?.userGroups.filter { !alwaysVisibleGroups.contains($0) } ?? [])
            
            return alwaysVisibleGroups.compactMap {
                $0.canBePresentedInRelations ? RelationsRelation(id: 0, name: $0.title, isSelected: false) : nil
            }
        }
    }
}

private extension UserGroup {
    var canBePresentedInRelations: Bool {
        switch self {
        case .globalAdmin, .shareholderPending, .shareholderToConfirm, .blocked: return false
        default: return true
        }
    }
}
