//
//  CountriesRemoteRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FiltersRemoteRepo {
    
    let apiManager: ApiManager
    
    init(apiManager: ApiManager) {
        self.apiManager = apiManager
    }
    
    func getIndustries() -> Observable<[Industry]> {
        return apiManager.fetchIndustries()
    }

    func getStartupCategories() -> Observable<[StartupCategory]> {
        return apiManager.fetchStartupCategories()
    }
    
    func getSectors() -> Observable<[EconomicSector]> {
        return apiManager.fetchSectors()
    }
    
    func getContinents() -> Observable<[Continent]> {
        return apiManager.fetchContinents()
    }

    func getCurrencies() -> Observable<[CurrencyFilter]> {
        return apiManager.fetchCurrencies()
    }

    func getAssetClasses() -> Observable<[AssetClass]> {
        return apiManager.fetchAssetClasses()
    }
    
    func searchLocations(withText text: String) -> Observable<LocationsResponse> {
        return apiManager.searchLocations(withText: text)
    }
    
    func fetchSuggestedLocations() -> Observable<LocationsResponse> {
        return apiManager.fetchSuggestedLocations()
    }
}
