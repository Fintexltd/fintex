//
//  CountriesRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FiltersRepository {

    private let remote: FiltersRemoteRepo
    private let local: FiltersLocalRepo

    init(remote: FiltersRemoteRepo, local: FiltersLocalRepo) {
        self.remote = remote
        self.local = local
    }

    func getIndustries() -> Observable<[Industry]> {
        return remote.getIndustries()
    }

    func getStartupCategories() -> Observable<[StartupCategory]> {
        return remote.getStartupCategories()
    }

    func getSectors() -> Observable<[EconomicSector]> {
        return remote.getSectors()
    }

    func getCompanyRelations() -> Observable<[CompanyRelation]> {
        return local.getCompanyRelationFilters()
    }

    func getFundManagerRelations() -> Observable<[FundManagerRelation]> {
        return local.getFundManagerRelationFilters()
    }

    func getStartupRelations() -> Observable<[StartupRelation]> {
        return local.getStartupRelationFilters()
    }

    func getWatchlistRelations() -> Observable<[WatchlistRelation]> {
        return local.getWatchlistRelationFilters()
    }

    func getActivePassive() -> Observable<[ActivePassive]> {
        local.getActivePassive()
    }

    func getEquityFund() -> Observable<[EquityFund]> {
        local.getEquityFund()
    }

    func getOpenClose() -> Observable<[OpenClose]> {
        local.getOpenClose()
    }

    func getContinents() -> Observable<[Continent]> {
        return remote.getContinents()
    }

    func getCurrencies() -> Observable<[CurrencyFilter]> {
        return remote.getCurrencies()
    }

    func getAssetClasses() -> Observable<[AssetClass]> {
        return remote.getAssetClasses()
    }

    func getManagementFee() -> Observable<[ManagementFee]> {
        local.getManagementFee()
    }

    func getPerformanceFee() -> Observable<[PerformanceFee]> {
        local.getPerformanceFee()
    }

    func getRaisedAmount() -> Observable<[RaisedAmount]> {
        local.getRaisedAmount()
    }

    func getDuration() -> Observable<[Duration]> {
        local.getDuration()
    }

    func getPublicity() -> Observable<[Publicity]> {
        return local.getPublicities()
    }

    func getFundTypes() -> Observable<[FundTypeFilter]> {
        return local.getFundTypes()
    }

    func getTradingFrequency() -> Observable<[TradingFrequency]> {
        local.getTradingFrequency()
    }

    func getCompanyPredefinedFilters() -> Observable<[Filter]> {
        return local.getCompanyPredefinedFilters()
    }

    func getFundManagerPredefinedFilters() -> Observable<[Filter]> {
        return local.getFundManagerPredefinedFilters()
    }

    func getStartupPredefinedFilters() -> Observable<[Filter]> {
        return local.getStartupPredefinedFilters()
    }

    func getWatchlistPredefinedFilters() -> Observable<[Filter]> {
        return local.getWatchlistPredefinedFilters()
    }
    
    func getEventsPredefinedFilters() -> Observable<[Filter]> {
        return local.getEventsPredefinedFilters()
    }

    func getAttachments() -> Observable<[Attachment]> {
        return local.getAttachments()
    }
    
    func searchLocations(withText text: String) -> Observable<LocationsResponse> {
        return remote.searchLocations(withText: text)
    }
    
    func fetchSuggestedLocations() -> Observable<LocationsResponse> {
        return remote.fetchSuggestedLocations()
    }
    
    func getRelationFilters() -> Observable<[RelationsRelation]> {
        return local.getRelationFilters()
    }
}
