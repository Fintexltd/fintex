//
//  FundsRepository.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FundsRepository {

    private let remote: FundsRemoteRepo

    init(remote: FundsRemoteRepo) {
        self.remote = remote
    }

    func getFundsAbout(fundId: Int) -> Observable<FundAbout> {
        return remote.getFund(fundId: fundId)
    }

    func getFunds(fromPage page: Int, fundManagerId: Int, withFilters filters: AdvancedFilters) -> Observable<FundsResponse> {
        return remote.getFunds(fromPage: page, fundManagerId: fundManagerId, withFilters: filters)
    }

    func getDocumentsDetails(fundId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return remote.getDocumentsDetails(fundId: fundId, sectionId: sectionId, page: page)
    }

    func getDocuments(fundId: Int) -> Observable<[HistoricalDataSection]> {
        return remote.getFundDocuments(fundId: fundId)
    }

    func assignAsInvestor(requestData: InvestorRequestModel) -> Observable<MessageResponse> {
        return remote.assignAsInvestor(requestData: requestData)
    }

    func getChartsData(fundId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        return remote.getChartsDataResponse(fundId: fundId)
    }

    func toggleFollowing(ofFundWithId id: Int, follow: Bool) -> Observable<MessageResponse> {
        if follow {
            return remote.followFund(id: id)
        } else {
            return remote.unfollowFund(id: id)
        }
    }
}
