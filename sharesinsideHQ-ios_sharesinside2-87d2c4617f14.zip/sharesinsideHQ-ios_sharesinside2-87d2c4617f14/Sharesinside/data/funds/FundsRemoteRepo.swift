//
//  FundsRemoteRepo.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 03/12/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FundsRemoteRepo {

    let apiManager: FundsService & ShareholderService

    init(apiManager: FundsService & ShareholderService) {
        self.apiManager = apiManager
    }

    func getFund(fundId: Int) -> Observable<FundAbout> {
        return apiManager.fetchFundDetails(id: fundId)
    }

    func getFunds(fromPage page: Int, fundManagerId: Int, withFilters filters: AdvancedFilters) -> Observable<FundsResponse> {
        return apiManager.fetchFunds(fromPage: page, fundManagerId: fundManagerId, withFilters: filters)
    }

    func getFundDocuments(fundId: Int) -> Observable<[HistoricalDataSection]> {
        return apiManager.fetchFundDocuments(fundId: fundId)
    }

    func getDocumentsDetails(fundId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return apiManager.fetchDocumentsDetails(fundId: fundId, sectionId: sectionId, page: page)
    }

    func assignAsInvestor(requestData: InvestorRequestModel) -> Observable<MessageResponse> {
        return apiManager.assignAsInvestor(requestData: requestData)
    }

    func getChartsDataResponse(fundId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        return apiManager.fetchChartsFundDataResponse(fundId: fundId)
    }

    func followFund(id: Int) -> Observable<MessageResponse> {
        return apiManager.followFund(id: id)
    }

    func unfollowFund(id: Int) -> Observable<MessageResponse> {
        return apiManager.unfollowFund(id: id)
    }
}
