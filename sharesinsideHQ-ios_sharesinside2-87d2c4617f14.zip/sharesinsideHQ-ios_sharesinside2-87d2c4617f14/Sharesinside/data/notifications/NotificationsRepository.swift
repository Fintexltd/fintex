//
//  NotificationsRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class NotificationsRepository {
    
    private let remote: NotificationsRemoteRepository
    
    init(remote: NotificationsRemoteRepository) {
        self.remote = remote
    }
    
    func fetchNotificationsSettings() -> Observable<NotificationSettingsModel> {
        return remote.fetchNotificationsSettings()
    }
    
    func pushNotificationsSettings(settings: NotificationSettingsModel) -> Observable<MessageResponse> {
        return remote.pushNotificationsSettings(settings: settings)
    }

    func fetchAppNotifications(fromPage page: Int) -> Observable<AppNotificationsResponse> {
        return remote.fetchAppNotifications(fromPage: page)
    }
    
    func getAppNotificationsIndicator() -> Observable<Int> {
        return remote.getAppNotificationsIndicator()
    }
}
