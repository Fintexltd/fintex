//
//  NotificationsRemoteRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 10.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class NotificationsRemoteRepository {
    
    let notificationsService: NotificationsService
    
    init(notificationsService: NotificationsService) {
        self.notificationsService = notificationsService
    }
    
    func fetchNotificationsSettings() -> Observable<NotificationSettingsModel> {
        return notificationsService.fetchNotificationsSettings()
    }

    func pushNotificationsSettings(settings: NotificationSettingsModel) -> Observable<MessageResponse> {
        return notificationsService.pushNotificationsSettings(settings: settings)
    }
    
    func fetchAppNotifications(fromPage page: Int) -> Observable<AppNotificationsResponse> {
        return notificationsService.fetchAppNotifications(forPage: page)
    }
    
    func getAppNotificationsIndicator() -> Observable<Int> {
        return notificationsService.getAppNotificationsIndicator().map { $0.indicator }
    }
}
