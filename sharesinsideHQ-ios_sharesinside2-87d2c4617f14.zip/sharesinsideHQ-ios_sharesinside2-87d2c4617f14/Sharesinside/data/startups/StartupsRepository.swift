//
//  StartupsRepository.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class StartupsRepository {

    private let remote: StartupsRemoteRepo

    init(remote: StartupsRemoteRepo) {
        self.remote = remote
    }

    func getStartupAbout(startupId: Int) -> Observable<StartupAbout> {
        return remote.getStartup(startupId: startupId)
    }

    func getEmployeesGroup(startupId: Int) -> Observable<[EmployeesGroup]> {
        return remote.getEmployeesGroup(startupId: startupId)
    }

    func getHistoricalData(startupId: Int) -> Observable<[HistoricalDataSection]> {
        return remote.getHistoricalDataResponse(startupId: startupId)
    }

    func getHistoricalDataSection(startupId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return remote.getHistoricalDataSection(startupId: startupId, sectionId: sectionId, page: page)
    }

    func getGalleries(startupId: Int) -> Observable<[Album]> {
        return remote.getGalleries(startupId: startupId)
    }

    func getStartups(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<ListResponse<Startup>> {
        return remote.getStartups(fromPage: page, withFilters: filters)
    }

    func toggleFollowing(ofStartupWithId id: Int, follow: Bool) -> Observable<MessageResponse> {
        if follow {
            return remote.followStartup(id: id)
        } else {
            return remote.unfollowStartup(id: id)
        }
    }

    func followAllStartups(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        return remote.followAllStartups(matching: filters)
    }

    func assignAsShareholder(requestData: ShareholderRequestModel) -> Observable<MessageResponse> {
        return remote.assignAsShareholder(requestData: requestData)
    }
}
