//
//  StartupsRemoteRepo.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 25/07/2020.
//  Copyright © 2020 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class StartupsRemoteRepo {

    let apiManager: StartupsService & ShareholderService

    init(apiManager: StartupsService & ShareholderService) {
        self.apiManager = apiManager
    }

    func getStartup(startupId: Int) -> Observable<StartupAbout> {
        return apiManager.fetchStartupDetails(id: startupId)
    }

    func getStartups(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<ListResponse<Startup>> {
        return apiManager.fetchStartups(fromPage: page, withFilters: filters)
    }

    func getEmployeesGroup(startupId: Int) -> Observable<[EmployeesGroup]> {
        return apiManager.fetchEmployeesGroup(startupId: startupId)
    }

    func getHistoricalDataResponse(startupId: Int) -> Observable<[HistoricalDataSection]> {
        return apiManager.fetchHistoricalDataResponse(startupId: startupId)
    }

    func getHistoricalDataSection(startupId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return apiManager.fetchHistoricalDataSection(startupId: startupId, sectionId: sectionId, page: page)
    }

    func getGalleries(startupId: Int) -> Observable<[Album]> {
        return apiManager.fetchGalleries(startupId: startupId)
    }

    func followStartup(id: Int) -> Observable<MessageResponse> {
        return apiManager.followStartup(id: id)
    }

    func unfollowStartup(id: Int) -> Observable<MessageResponse> {
        return apiManager.unfollowStartup(id: id)
    }

    func followAllStartups(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        return apiManager.followAllStartups(matching: filters)
    }

    func assignAsShareholder(requestData: ShareholderRequestModel) -> Observable<MessageResponse> {
        return apiManager.assignAsShareholder(requestModel: requestData)
    }
}
