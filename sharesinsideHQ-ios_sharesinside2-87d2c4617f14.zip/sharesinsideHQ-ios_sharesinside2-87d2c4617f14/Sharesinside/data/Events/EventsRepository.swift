//
//  EventsRepository.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class EventsRepository {
    
    private let remote: EventsRemoteRepo
    
    init(remote: EventsRemoteRepo) {
        self.remote = remote
    }
    
    func getDaysWithEvents(startDate: Date) -> Observable<CalendarDatesWithEventsReponse> {
        return remote.getDaysWithEvents(startDate: startDate)
    }
    
    func getEvents(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int?) -> Observable<WatchlistResponse> {
        return remote.getEvents(fromPage: page, withFilters: filters, itemsPerPage: itemsPerPage)
    }
    
    func searchEvents(withSearchText searchText: String, andFilters filters: AdvancedFilters?) -> Observable<[String]> {
        return remote.searchEvents(withSearchText: searchText, withFilters: filters)
    }
}
