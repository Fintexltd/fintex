//
//  EventsDisplayDateTypeRepository.swift
//  Sharesinside
//

import Foundation
import RxSwift
import RxCocoa

protocol EventsDisplayDateTypeRepository {
    var displayDateType: EventDateDisplayType? { get set }
    var displayDateTypeChange: Observable<EventDateDisplayType?> { get }
}

final class UserDefaultsEventsDisplayDateTypeRepository: EventsDisplayDateTypeRepository {

    private static let displayDateTypeKey = "displayDateTypeKey"

    private init() {}

    static let shared = UserDefaultsEventsDisplayDateTypeRepository()

    private var cachedValue: EventDateDisplayType?

    var displayDateType: EventDateDisplayType? {
        get {
            guard cachedValue == nil else {
                return cachedValue
            }
            guard let rawStoredType = UserDefaults.standard.string(forKey: UserDefaultsEventsDisplayDateTypeRepository.displayDateTypeKey) else {
                return nil
            }
            cachedValue = EventDateDisplayType(rawValue: rawStoredType)
            return cachedValue
        }
        set {
            UserDefaults.standard.set(newValue?.rawValue, forKey: UserDefaultsEventsDisplayDateTypeRepository.displayDateTypeKey)
            cachedValue = newValue
            displayDateTypeChangePublisher.accept(newValue)
        }
    }

    var displayDateTypeChange: Observable<EventDateDisplayType?> {
        displayDateTypeChangePublisher.asObservable()
    }

    private let displayDateTypeChangePublisher = PublishRelay<EventDateDisplayType?>()
}
