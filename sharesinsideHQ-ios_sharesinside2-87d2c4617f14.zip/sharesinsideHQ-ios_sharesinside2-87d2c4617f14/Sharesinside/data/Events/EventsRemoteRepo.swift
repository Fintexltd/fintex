//
//  EventsRemoteRepo.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 27/09/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class EventsRemoteRepo {
    
    let eventsService: EventsService
    
    init(eventsService: EventsService) {
        self.eventsService = eventsService
    }
    
    func getDaysWithEvents(startDate: Date) -> Observable<CalendarDatesWithEventsReponse> {
        return eventsService.fetchDaysWithEvents(startDate: startDate)
    }
    
    func getEvents(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int?) -> Observable<WatchlistResponse> {
        return eventsService.fetchEvents(fromPage: page, withFilters: filters, itemsPerPage: itemsPerPage)
    }
    
    func searchEvents(withSearchText searchText: String, withFilters filters: AdvancedFilters?) -> Observable<[String]> {
        return eventsService.searchEvents(withSearchText: searchText, andFilters: filters)
    }
}
