//
//  RequestsRemoteRepository.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 09/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class RequestsRemoteRepository {
    
    let requestsService: RequestsService
    
    init(requestsService: RequestsService) {
        self.requestsService = requestsService
    }
    
    func getRequests(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RequestsResponse> {
        return requestsService.fetchRequests(fromPage: page, withFilters: filters)
    }
    
    func cancel(_ request: RelationRequest) -> Observable<MessageResponse> {
        return requestsService.cancel(request)
    }
    
    func callApiResendCode(for request: RelationRequest) -> Observable<MessageResponse> {
        return requestsService.requestForResendCode(for: request)
    }
    
    func activate(_ request: RelationRequest, with code: String) -> Observable<MessageResponse> {
        return requestsService.activate(request, with: code)
    }
}
