//
//  RequestsRepository.swift
//  Sharesinside
//
//  Created by Aleksander Wędrychowski on 09/10/2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class RequestsRepository {
    
    private let remote: RequestsRemoteRepository
    
    init(remote: RequestsRemoteRepository) {
        self.remote = remote
    }
    
    func getRequests(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RequestsResponse> {
        return remote.getRequests(fromPage: page, withFilters: filters)
    }
    
    func cancel(_ request: RelationRequest) -> Observable<MessageResponse> {
        return remote.cancel(request)
    }
    
    func callApiResendCode(for request: RelationRequest) -> Observable<MessageResponse> {
        return remote.callApiResendCode(for: request)
    }
    
    func activate(_ request: RelationRequest, with code: String) -> Observable<MessageResponse> {
        return remote.activate(request, with: code)
    }
}
