//
// Created by Aleksander Wędrychowski on 06/08/2018.
// Copyright (c) 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class ProfileRemoteRepo {

    let apiManager: ProfileService

    init(apiManager: ProfileService) {
        self.apiManager = apiManager
    }

    func getProfileDetails() -> Observable<AppUser> {
        return apiManager.fetchProfileDetails()
    }
    
    func registerPushNotificationsInSIServer() {
        guard let token = Config.APNSToken else { return }
        apiManager.registerForPushNotifications(token)
    }
    
    func changeEmail(with newEmail: String) -> Observable<MessageResponse> {
        return apiManager.changeEmail(with: newEmail)
    }
    
    func changeUsername(with newUsername: String) -> Observable<MessageResponse> {
        return apiManager.changeUsername(with: newUsername)
    }
    
    func changePassword(oldPassword: String, newPassword: String, repeatedPassword: String) -> Observable<AuthData> {
        return apiManager.changePassword(oldPassword: oldPassword, newPassword: newPassword, repeatedPassword: repeatedPassword)
    }
    
    func setPassword(newPassword: String, repeatedPassword: String) -> Observable<MessageResponse> {
        return apiManager.setPassword(newPassword: newPassword, repeatedPassword: repeatedPassword)
    }
    
    func connectWithLinkedIn(token: String) -> Observable<MessageResponse> {
        return apiManager.connectWithLinkedIn(token: token)
    }
    
    func disconnectWithLinkedIn() -> Observable<MessageResponse> {
        return apiManager.disconnectWithLinkedIn()
    }
}
