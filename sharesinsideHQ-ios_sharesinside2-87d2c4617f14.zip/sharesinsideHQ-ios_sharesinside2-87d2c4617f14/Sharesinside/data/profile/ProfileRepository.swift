//
// Created by Aleksander Wędrychowski on 06/08/2018.
// Copyright (c) 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class ProfileRepository {

    private let remote: ProfileRemoteRepo

    init(remote: ProfileRemoteRepo) {
        self.remote = remote
    }

    func getUserDetails() -> Observable<AppUser> {
        return remote.getProfileDetails()
    }
    
    func registerPushNotificationsInSIServer() {
        remote.registerPushNotificationsInSIServer()
    }

    func changeEmail(with newEmail: String) -> Observable<MessageResponse> {
        return remote.changeEmail(with: newEmail)
    }
    
    func changeUsername(with newUsername: String) -> Observable<MessageResponse> {
        return remote.changeUsername(with: newUsername)
    }
    
    func changePassword(oldPassword: String, newPassword: String, repeatedPassword: String) -> Observable<AuthData> {
        return remote.changePassword(oldPassword: oldPassword, newPassword: newPassword, repeatedPassword: repeatedPassword)
    }
    
    func setPassword(newPassword: String, repeatedPassword: String) -> Observable<MessageResponse> {
        return remote.setPassword(newPassword: newPassword, repeatedPassword: repeatedPassword)
    }
    
    func connectWithLinkedIn(token: String) -> Observable<MessageResponse> {
        return remote.connectWithLinkedIn(token: token)
    }
    
    func disconnectWithLinkedIn() -> Observable<MessageResponse> {
        return remote.disconnectWithLinkedIn()
    }
}
