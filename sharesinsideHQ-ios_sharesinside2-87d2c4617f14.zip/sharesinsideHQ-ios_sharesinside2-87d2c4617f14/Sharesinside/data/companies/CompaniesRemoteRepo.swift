//
//  CountriesRemoteRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class CompaniesRemoteRepo {

    let apiManager: CompaniesService & ShareholderService

    init(apiManager: CompaniesService & ShareholderService) {
        self.apiManager = apiManager
    }
    
    func getCompany(companyId: Int) -> Observable<CompanyAbout> {
        return apiManager.fetchCompanyDetails(id: companyId)
    }

    func getCompanies(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<CompaniesResponse> {
        return apiManager.fetchCompanies(fromPage: page, withFilters: filters)
    }
    
    func getEmployeesGroup(companyId: Int) -> Observable<[EmployeesGroup]> {
        return apiManager.fetchEmployeesGroup(companyId: companyId)
    }
    
    func getHistoricalDataResponse(companyId: Int) -> Observable<[HistoricalDataSection]> {
        return apiManager.fetchHistoricalDataResponse(companyId: companyId)
    }
    
    func getHistoricalDataSection(companyId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return apiManager.fetchHistoricalDataSection(companyId: companyId, sectionId: sectionId, page: page)
    }
    
    func getGalleries(companyId: Int) -> Observable<[Album]> {
        return apiManager.fetchGalleries(companyId: companyId)
    }
    
    func getChartsDataResponse(companyId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        return apiManager.fetchChartsCompanyDataResponse(companyId: companyId)
    }

    func followCompany(id: Int) -> Observable<MessageResponse> {
        return apiManager.followCompany(id: id)
    }

    func unfollowCompany(id: Int) -> Observable<MessageResponse> {
        return apiManager.unfollowCompany(id: id)
    }
    
    func followAllCompanies(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        return apiManager.followAllCompanies(matching: filters)
    }
    
    func assignAsShareholder(requestData: ShareholderRequestModel) -> Observable<MessageResponse> {
        return apiManager.assignAsShareholder(requestModel: requestData)
    }
}
