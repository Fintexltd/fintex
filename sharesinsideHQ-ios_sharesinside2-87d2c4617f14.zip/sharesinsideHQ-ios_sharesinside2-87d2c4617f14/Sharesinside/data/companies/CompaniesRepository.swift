//
//  CountriesRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class CompaniesRepository {

    private let remote: CompaniesRemoteRepo

    init(remote: CompaniesRemoteRepo) {
        self.remote = remote
    }

    func getCompanyAbout(companyId: Int) -> Observable<CompanyAbout> {
        return remote.getCompany(companyId: companyId)
    }
    
    func getEmployeesGroup(companyId: Int) -> Observable<[EmployeesGroup]> {
        return remote.getEmployeesGroup(companyId: companyId)
    }
    
    func getHistoricalData(companyId: Int) -> Observable<[HistoricalDataSection]> {
        return remote.getHistoricalDataResponse(companyId: companyId)
    }
    
    func getHistoricalDataSection(companyId: Int, sectionId: Int, page: Int) -> Observable<HistoricalDataSectionResponse> {
        return remote.getHistoricalDataSection(companyId: companyId, sectionId: sectionId, page: page)
    }
    
    func getGalleries(companyId: Int) -> Observable<[Album]> {
        return remote.getGalleries(companyId: companyId)
    }
    
    func getChartsData(companyId: Int) -> Observable<CompanyCharts.CompanyChartsData> {
        return remote.getChartsDataResponse(companyId: companyId)
    }

    func getCompanies(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<CompaniesResponse> {
        return remote.getCompanies(fromPage: page, withFilters: filters)
    }

    func toggleFollowing(ofCompanyWithId id: Int, follow: Bool) -> Observable<MessageResponse> {
        if follow {
            return remote.followCompany(id: id)
        } else {
            return remote.unfollowCompany(id: id)
        }
    }
    
    func followAllCompanies(matching filters: AdvancedFilters) -> Observable<MessageResponse> {
        return remote.followAllCompanies(matching: filters)
    }
    
    func assignAsShareholder(requestData: ShareholderRequestModel) -> Observable<MessageResponse> {
        return remote.assignAsShareholder(requestData: requestData)
    }
}
