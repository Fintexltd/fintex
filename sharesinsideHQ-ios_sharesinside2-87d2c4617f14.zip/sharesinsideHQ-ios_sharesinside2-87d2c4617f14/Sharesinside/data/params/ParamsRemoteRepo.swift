//
//  CountriesRemoteRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class ParamsRemoteRepo {
    
    let apiManager: ParamsService
    
    init(apiManager: ParamsService) {
        self.apiManager = apiManager
    }
    
    func getParams() -> Observable<Params> {
        return apiManager.fetchParams()
            .flatMap({ paramsArray -> Observable<Params> in
                guard paramsArray.count >= 4 else {
                    return Observable.error(ErrorResponse(message: Localizable.apiUnknownError.localized,
                                                          status: 0, error: nil, errors: nil))
                }
                
                return Observable.just(Params(apiKey: paramsArray[0],
                                              apiSecret: paramsArray[1],
                                              redirectUrl: paramsArray[2],
                                              readScope: paramsArray[3]))
            })
    }
}
