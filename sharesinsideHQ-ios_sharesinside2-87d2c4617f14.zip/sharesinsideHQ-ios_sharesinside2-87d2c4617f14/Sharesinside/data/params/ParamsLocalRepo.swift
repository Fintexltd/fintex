//
//  FiltersLocalRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 16.07.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class ParamsLocalRepo {
    
    func getParams() -> Observable<Params?> {
        return Observable.just(Config.linkedinParams)
    }
}
