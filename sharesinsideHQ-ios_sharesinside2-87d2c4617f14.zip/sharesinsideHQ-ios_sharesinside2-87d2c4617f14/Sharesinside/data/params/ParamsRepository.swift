//
//  CountriesRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class ParamsRepository {

    private let remote: ParamsRemoteRepo
    private let local: ParamsLocalRepo

    init(remote: ParamsRemoteRepo, local: ParamsLocalRepo) {
        self.remote = remote
        self.local = local
    }

    func getParams(forceRefresh: Bool = false) -> Observable<Params> {
        return local.getParams()
            .flatMap { params -> Observable<Params> in
                if let params = params, !forceRefresh {
                    return Observable.just(params)
                }
                
                return self.remote.getParams()
            }
    }
}
