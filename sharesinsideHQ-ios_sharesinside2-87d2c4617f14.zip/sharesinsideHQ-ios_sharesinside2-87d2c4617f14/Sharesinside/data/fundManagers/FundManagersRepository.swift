//
//  FundManagersRepository.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FundManagersRepository {

    private let remote: FundManagersRemoteRepo

    init(remote: FundManagersRemoteRepo) {
        self.remote = remote
    }

    func getFundManagerAbout(fundManagerId: Int) -> Observable<FundManagerAbout> {
        return remote.getFundManager(fundManagerId: fundManagerId)
    }

    func getEmployeesGroup(fundManagerId: Int) -> Observable<[EmployeesGroup]> {
        return remote.getEmployeesGroup(fundManagerId: fundManagerId)
    }

    func getFundManagers(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<FundManagersResponse> {
        return remote.getFundManagers(fromPage: page, withFilters: filters)
    }

    func toggleFollowing(ofFundManagerWithId id: Int, follow: Bool) -> Observable<MessageResponse> {
        if follow {
            return remote.followFundManager(id: id)
        } else {
            return remote.unfollowFundManager(id: id)
        }
    }
}
