//
//  FundManagersRemoteRepo.swift
//  Sharesinside
//
//  Created by Bartosz Żmija on 19/11/2019.
//  Copyright © 2019 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class FundManagersRemoteRepo {

    let apiManager: FundManagersService

    init(apiManager: FundManagersService) {
        self.apiManager = apiManager
    }

    func getFundManager(fundManagerId: Int) -> Observable<FundManagerAbout> {
        return apiManager.fetchFundManagerDetails(id: fundManagerId)
    }

    func getEmployeesGroup(fundManagerId: Int) -> Observable<[EmployeesGroup]> {
        return apiManager.fetchEmployeesGroup(fundManagerId: fundManagerId)
    }

    func getFundManagers(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<FundManagersResponse> {
        return apiManager.fetchFundManagers(fromPage: page, withFilters: filters)
    }

    func followFundManager(id: Int) -> Observable<MessageResponse> {
        return apiManager.followFundManager(id: id)
    }

    func unfollowFundManager(id: Int) -> Observable<MessageResponse> {
        return apiManager.unfollowFundManager(id: id)
    }
}
