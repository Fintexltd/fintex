//
//  CountriesRemoteRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class CountriesRemoteRepo {
    
    let apiManager: ApiManager
    
    init(apiManager: ApiManager) {
        self.apiManager = apiManager
    }
    
    func getCountries() -> Single<[Country]> {
        return apiManager.fetchCountries()
    }
}
