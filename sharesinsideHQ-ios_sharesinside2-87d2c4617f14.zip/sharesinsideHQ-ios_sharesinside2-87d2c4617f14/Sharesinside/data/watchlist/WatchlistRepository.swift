//
//  CountriesRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class WatchlistRepository {

    private let remote: WatchlistRemoteRepo

    init(remote: WatchlistRemoteRepo) {
        self.remote = remote
    }

    func getWatchlist(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int? = nil) -> Observable<WatchlistResponse> {
        return remote.getWatchlist(fromPage: page, withFilters: filters, itemsPerPage: itemsPerPage)
    }
    
    func getCompanyNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getCompanyNews(id: id, page: page)
    }

    func getCompanyEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getCompanyEvents(id: id, page: page)
    }

    func getFundNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getFundNews(id: id, page: page)
    }

    func getFundEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getFundEvents(id: id, page: page)
    }

    func getFundManagerNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getFundManagerNews(id: id, page: page)
    }

    func getFundManagerEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getFundManagerEvents(id: id, page: page)
    }

    func getStartupNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getStartupNews(id: id, page: page)
    }

    func getStartupEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getStartupEvents(id: id, page: page)
    }

    func getStartupProjects(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return remote.getStartupProjects(id: id, page: page)
    }
    
    func getNewsDetails(id: Int) -> Observable<NewsInformation> {
        return remote.getNewsDetails(id: id)
    }

    func getProjectDetails(id: Int) -> Observable<ProjectInformation> {
        return remote.getProjectDetails(id: id)
    }

    func getEventDetails(id: Int) -> Observable<EventInformation> {
        return remote.getEventDetails(id: id)
    }
    
    func getLatestNews(for newsId: Int) -> Observable<[News]> {
        return remote.getLatestNews(for: newsId)
    }
    
    func getLatestEvents(for eventId: Int) -> Observable<[Event]> {
        return remote.getLatestEvents(for: eventId)
    }

    func getLatestProjects(for projectId: Int) -> Observable<[Project]> {
        return remote.getLatestProjects(for: projectId)
    }
}
