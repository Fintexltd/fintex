//
//  CountriesRemoteRepo.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 14.06.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class WatchlistRemoteRepo {

    let watchlistService: WatchlistService

    init(watchlistService: WatchlistService) {
        self.watchlistService = watchlistService
    }

    func getWatchlist(fromPage page: Int, withFilters filters: AdvancedFilters, itemsPerPage: Int?) -> Observable<WatchlistResponse> {
        return watchlistService.fetchWatchlist(fromPage: page, withFilters: filters, itemsPerPage: itemsPerPage)
    }
    
    func getCompanyNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchCompanyNews(id: id, page: page)
    }
   
    func getCompanyEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchCompanyEvents(id: id, page: page)
    }

    func getFundNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchFundNews(id: id, page: page)
    }

    func getFundEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchFundEvents(id: id, page: page)
    }

    func getFundManagerNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchFundManagerNews(id: id, page: page)
    }

    func getFundManagerEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchFundManagerEvents(id: id, page: page)
    }

    func getStartupNews(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchStartupNews(id: id, page: page)
    }

    func getStartupProjects(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchStartupProjects(id: id, page: page)
    }

    func getStartupEvents(id: Int, page: Int) -> Observable<WatchlistResponse> {
        return watchlistService.fetchStartupEvents(id: id, page: page)
    }
    
    func getNewsDetails(id: Int) -> Observable<NewsInformation> {
        return watchlistService.fetchNewsDetails(id: id)
    }

    func getProjectDetails(id: Int) -> Observable<ProjectInformation> {
        return watchlistService.fetchProjectDetails(id: id)
    }
    
    func getEventDetails(id: Int) -> Observable<EventInformation> {
        return watchlistService.fetchEventDetails(id: id)
    }
    
    func getLatestEvents(for eventId: Int) -> Observable<[Event]> {
        return watchlistService.fetchLatestEvents(for: eventId)
    }
    
    func getLatestNews(for newsId: Int) -> Observable<[News]> {
        return watchlistService.fetchLatestNews(for: newsId)
    }

    func getLatestProjects(for projectId: Int) -> Observable<[Project]> {
        return watchlistService.fetchLatestProjects(for: projectId)
    }
}
