//
//  RelationsRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class RelationsRepository {
    
    private let remote: RelationsRemoteRepository
    
    init(remote: RelationsRemoteRepository) {
        self.remote = remote
    }
    
    func getRelations(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RelationsResponse> {
        return remote.getRelations(fromPage: page, withFilters: filters)
    }
    
    func resign(from relation: Relation) -> Observable<MessageResponse> {
        return remote.resign(from: relation)
    }
}
