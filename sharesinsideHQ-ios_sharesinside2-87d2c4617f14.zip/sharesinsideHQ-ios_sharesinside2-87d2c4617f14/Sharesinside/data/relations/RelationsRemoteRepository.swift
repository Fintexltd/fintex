//
//  RelationsRemoteRepository.swift
//  Sharesinside
//
//  Created by Damian Włodarczyk on 18.09.2018.
//  Copyright © 2018 Kiss Digital. All rights reserved.
//

import Foundation
import RxSwift

class RelationsRemoteRepository {
    
    let relationsService: RelationsService
    
    init(relationsService: RelationsService) {
        self.relationsService = relationsService
    }
    
    func getRelations(fromPage page: Int, withFilters filters: AdvancedFilters) -> Observable<RelationsResponse> {
        return relationsService.fetchRelations(fromPage: page, withFilters: filters)
    }
    
    func resign(from relation: Relation) -> Observable<MessageResponse> {
        return relationsService.resign(from: relation)
    }
}
