@servers(['dev' => 'roboto', 'prod' => 'USER@HOST'])

@setup
$environment = isset($production) ? 'prod' : 'dev';
$paths = [
'dev' => '/var/www/sharesinside-v2.kissdev.zone/api',
'prod' => '/var/www/2.sharesinside.com/api',
]
@endsetup

@task('deploy', ['on' => $environment])
cd {{ $paths[$environment] }}
git fetch
php artisan down
git reset --hard origin/{{ $environment == 'prod' ? 'master' : 'develop' }}
composer install
php artisan migrate
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan queue:restart
php artisan up
@endtask