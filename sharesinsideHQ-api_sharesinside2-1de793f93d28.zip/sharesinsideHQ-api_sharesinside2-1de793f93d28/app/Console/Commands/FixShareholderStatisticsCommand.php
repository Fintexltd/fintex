<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\Shareholder;
use Illuminate\Console\Command;

class FixShareholderStatisticsCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:shareholderStats';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'fixes number of shareholders for data before 2018-10-08';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $dates = $this->getDatesCollection();

        \App\Entities\Shareholder::query()
//            ->where('is_accepted', true)
//            ->where('is_confirmed', true)
//            ->get()
            ->groupBy('company_id')
            ->each(function ($shareholders, $companyId) use ($dates) {
                $dates
                    ->mapWithKeys($this->getProperValueForDates($shareholders->pluck('created_at')))
                    ->each($this->updateOrCreateRecord($companyId));

                return true;
            });
    }

    private function getProperValueForDates($dates)
    {
        return function ($date) use ($dates) {
            $value = $dates
                ->filter(function ($createdAt) use ($date) {
                    return $createdAt->lte($date);
                })
                ->count();

            return [$date->toDateString() => $value];
        };
    }

    private function updateOrCreateRecord($companyId)
    {
        return function ($count, $date) use ($companyId) {

            $record = \App\Entities\CompanyStatistic
                ::query()
                ->where('company_id', $companyId)
                ->where('date', $date)
                ->first();

            if ($record) {
                $value = json_decode($record->value, true);
                $value['shareholders'] = $count;
                $value = json_encode($value);
                $record->update([
                    'value' => $value,
                ]);
            } else {
                \App\Entities\CompanyStatistic::create([
                    'company_id' => $companyId,
                    'date' => $date,
                    'value' => '{"followers":0,"shareholders":' . $count . ',"vips":0}'
                ]);
            }
        };
    }

    private function getDatesCollection()
    {
        $start = \Carbon\Carbon::createFromDate(2016, 1, 1);

        $end = \Carbon\Carbon::createFromDate(2018, 10, 8);

        $dates = [];

        while ($start->lt($end)) {
            $dates[] = clone $start;
            $start->addDay(1);
        }

        return collect($dates);
    }
}
