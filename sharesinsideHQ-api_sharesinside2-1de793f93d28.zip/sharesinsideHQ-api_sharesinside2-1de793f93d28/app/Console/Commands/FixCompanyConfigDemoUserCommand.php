<?php

namespace App\Console\Commands;

use App\Entities\Config;
use App\Services\DemoService;
use Illuminate\Console\Command;

class FixCompanyConfigDemoUserCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:companyConfigDemoUser';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fix companies database config keys for demo user';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $fixes = [
            'demo_user_follower_of_ids' => DemoService::DEMO_USER_FOLLOWER_OF_COMPANY_IDS,
            'demo_user_shareholder_of_ids' => DemoService::DEMO_USER_SHAREHOLDER_OF_COMPANY_IDS,
            'demo_user_vip_of_ids' => DemoService::DEMO_USER_VIP_OF_COMPANY_IDS,
        ];

        foreach ($fixes as $key => $value) {
            Config::where('id', $key)->update([
                'id' => $value
            ]);
        }
    }
}
