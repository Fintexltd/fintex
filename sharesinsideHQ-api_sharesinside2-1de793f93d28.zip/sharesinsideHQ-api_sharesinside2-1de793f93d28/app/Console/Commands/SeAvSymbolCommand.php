<?php

namespace App\Console\Commands;

use App\Exceptions\Handler;
use App\Services\SeAvProvider;
use Illuminate\Console\Command;

class SeAvSymbolCommand extends Command
{
    protected $seAvProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:se:av:symbol {symbol}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize symbol info from Alpha Vantage';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SeAvProvider $seAvProvider)
    {
        $this->seAvProvider = $seAvProvider;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $symbol = $this->argument('symbol');

        try {
            $this->seAvProvider->syncSymbolInfo($symbol);
        } catch (\Exception $e) {
            $h = new Handler(app());
            $h->report($e);
            return 1;
        }

        return 0;
    }
}
