<?php

namespace App\Console\Commands;

use App\Services\FeedProvider;
use Illuminate\Console\Command;

class StockCacheCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:stock:cache {--rate= : refresh rate in seconds} {--limit= : limit infinite loop}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run stock feed caching process';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(FeedProvider $feedProvider)
    {
        parent::__construct();

        $this->feedProvider = $feedProvider;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /** @var FeedProvider $service */
        $service = $this->feedProvider;

        $rate = $this->option('rate');
        if ($rate != null) {
            $rate = abs(intval($rate));
        }

        $limit = $this->option('limit');
        if ($limit != null) {
            $limit = abs(intval($limit));
        }

        $service->updateFeedCache($rate, $limit);
    }
}
