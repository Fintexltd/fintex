<?php

namespace App\Console\Commands;

use App\Services\FeedProvider;
use Illuminate\Console\Command;

class UpdateStockIndex extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'stockIndex:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates stock indices';

    /**
     * @var FeedProvider
     */
    protected $feedProvider;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(FeedProvider $feedProvider)
    {
        parent::__construct();

        $this->feedProvider = $feedProvider;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->feedProvider->updateSymbols();
    }
}
