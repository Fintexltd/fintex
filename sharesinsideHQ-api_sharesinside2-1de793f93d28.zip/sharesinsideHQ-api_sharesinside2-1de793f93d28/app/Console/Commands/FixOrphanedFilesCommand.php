<?php

namespace App\Console\Commands;

use App\Entities\Employee;
use App\Entities\Attachment;
use App\Entities\WatchlistItem;
use App\Repositories\AttachmentRepository;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class FixOrphanedFilesCommand extends Command
{
    /*const ATTACHABLE_TYPES_TO_DELETE = [
        WatchlistItem::class,
        Employee::class
    ];*/

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:orphanedFiles
        {--showUnattachedFiles : Show files that are not in the "attachments" table in the database}
        {--deleteUnattachedFiles : CAREFULLY!!! Delete files that are not in the "attachments" table in the database}
        {--showOrphanedDatabaseAttachments : Show records and files from database "attachments" table that are not related to any entities}
        {--deleteOrphanedDatabaseAttachments : CAREFULLY!!! Delete records and files from database "attachments" table that are not related to any entities}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Manage orphaned files';

    private $repository;

    private $files;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(AttachmentRepository $repository)
    {
        $this->repository = $repository;
        $this->files = collect(File::allFiles(storage_path('app/')))
            ->filter(function ($file) {
                return !Str::startsWith($file->getRelativePath(), ['public', 'testfiles']);
            });

        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('deleteUnattachedFiles') || $this->option('deleteOrphanedDatabaseAttachments')) {
            $confirm = $this->ask('!!!CAREFULLY!!! Are you sure you want to perform this operation? [YES, I am sure/NO]');

            if (strtoupper($confirm)!='YES, I AM SURE') {
                echo 'Abort'."\n";
                return 0;
            }
        }

        switch (true) {
            case $this->option('showUnattachedFiles'):
            case $this->option('deleteUnattachedFiles'):
                $this->unattachedFiles();
                break;
            case $this->option('showOrphanedDatabaseAttachments'):
            case $this->option('deleteOrphanedDatabaseAttachments'):
                $this->orphanedDatabaseAttachments();
                break;
        }

        return 0;
    }

    private function unattachedFiles()
    {
        $attachments = $this->repository->all(['path'])->map->only('path');

        $this->files->each(function ($file) use ($attachments) {
            $attachment = $attachments->firstWhere('path', $file->getFileName());

            if (!$attachment) {
                $path = storage_path('app/'.$file->getRelativePathname());

                if ($this->option('deleteUnattachedFiles') && file_exists($path)) {
                    unlink($path);
                    echo 'Delete: ';
                }

                echo $path."\n";
            }
        });
    }

    private function orphanedDatabaseAttachments()
    {
        $this->repository->getOrphans()->each(function ($attachment) {
            //if (in_array($attachment->attachable_type, self::ATTACHABLE_TYPES_TO_DELETE)) {
                try {
                    if ($this->option('deleteOrphanedDatabaseAttachments')) {
                        $attachment->delete();
                        echo 'Delete: ';
                    }

                    echo storage_path('app/'.$attachment->getPath())."\n";
                } catch (\ErrorException $e) {
                    if (Str::startsWith($e->getMessage(), ['Undefined index: ', 'Trying to get property '])) {
                        $file = $this->files->first(function ($file) use ($attachment) {
                            return $file->getFileName() == $attachment->path;
                        });

                        if ($file) {
                            $path = storage_path('app/'.$file->getRelativePathname());

                            if ($this->option('deleteOrphanedDatabaseAttachments') && file_exists($path)) {
                                unlink($path);
                            }
                        } else {
                            $path = 'NOT EXISTS: '.$attachment->path;
                        }

                        if ($this->option('deleteOrphanedDatabaseAttachments')) {
                            Attachment::where('id', $attachment->id)->delete();
                            echo 'Delete: ';
                        }

                        echo $path."\n";
                    }
                }
            //}
        });
    }


}
