<?php

namespace App\Console\Commands;

use App\Entities\News;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Entities\WatchlistItem;
use App\Events\SendEmailEvent;
use App\Mail\InformStockExchangeFailure;
use App\Mail\StockExchangeNotification;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class InformStockExchangeCommand extends Command
{

    const MAX_ACCEPTABLE_DELAY_IN_EMAIL_SENDING_TIME_IN_SECONDS = 10 * 60;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:watchlist:stock {--repeat : If should be run in loop}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generates emails for proper news from watchlist';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('repeat')) {
            $this->loop();
        } else {
            $this->action();
        }
    }

    //TODO: consider refactor
    private function loop($maxMinuteLimit = 10, $sleepRate = 10)
    {
        $endAt = Carbon::now()->addMinutes($maxMinuteLimit);

        while ($endAt->isFuture()) {
            $this->action();
            sleep($sleepRate);
        }
    }

    //TODO: find way to test this function
    private function action()
    {
        $now = Carbon::now()->toDateTimeString();

        WatchlistItem::query()
            ->where('notify_stock', true)
            ->where('is_draft', false)
            ->where(function ($query) use ($now) {
                $query->where('notify_stock_at', '<=', $now)
                    ->orWhereNull('notify_stock_at');
            })
            ->whereHas('company')
            ->whereHas('news')
            ->get()
            ->each(function ($watchlistItem) {
                $news = $watchlistItem->watchlistable;

                if ($this->isMaxAcceptableDelayExceeded($watchlistItem)) {
                    $this->notifyAboutFailure($news, $watchlistItem);

                    return;
                }

                $notification = $this->prepareEmail($watchlistItem, $news);

                try {
                    foreach ($news->StockExchangeEmails as $email) {
                        //event(new SendEmailEvent($email->email, $notification));
                        // send emails without queue, so errors can be handled
                        Mail::to($email->email)
                            ->send($notification);
                    }
                } catch (\Exception $exception) {
                    $this->notifyAboutFailure($news, $watchlistItem);

                    return;
                }

                $watchlistItem->update([
                    'notify_stock' => false,
                    'stock_informed_in_past' => true,
                ]);
            });
    }

    private function prepareEmail($watchlistItem, $news)
    {
        $companyName = data_get($watchlistItem, 'company.name', '');

        $publishAt = data_get($watchlistItem, 'publish_at');

        $publishDate = ($publishAt instanceof Carbon) ? (' on ' . $publishAt->toDateString() . ' at ' . $publishAt->toTimeString() . ' UTC') : '';

        $attachments = collect([]);

        $avaliable = ['files', 'videos', 'images', 'links'];

        foreach ($avaliable as $type) {
            if ($watchlistItem->$type) {
                $attachments->put($type, $watchlistItem->$type);
            }
        }

        $attachments = $attachments
            ->map(function ($collection) {
                return $collection
                    ->map(function ($urlable) {
                        return $urlable->getUrl();
                    })
                    ->all();
            })
            ->filter()
            ->all();

        $isAdHoc = (bool)$watchlistItem->is_ad_hoc;

        $notification = new StockExchangeNotification(
            $companyName,
            $publishDate,
            $news->title ?? '',
            $isAdHoc,
            $news->description ?? '',
            $attachments);

        return $notification;
    }

    private function isMaxAcceptableDelayExceeded(WatchlistItem $watchlistItem)
    {
        $publishAt = $watchlistItem->notify_stock_at;
        if (($publishAt instanceof Carbon)) {
            $publishAt->addSecond(self::MAX_ACCEPTABLE_DELAY_IN_EMAIL_SENDING_TIME_IN_SECONDS);

            return $publishAt->isPast();
        }

        return false;
    }

    private function notifyAboutFailure($news, WatchlistItem $watchlistItem)
    {
        $watchlistItem->update([
            'is_draft' => true,
        ]);

        //Email that sth went wrong should be send
        $email = $this->getCompanyRecipientEmail($watchlistItem->company);

        if (!$email) {
            return;
        }

        $notification = new InformStockExchangeFailure($news);

        event(new SendEmailEvent($email, $notification));
    }

    private function getCompanyRecipientEmail($company)
    {
        $types = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_EDITOR,
        ];

        $admin = null;

        foreach ($types as $type) {
            if (!$admin) {
                $admin = Relation::query()
                    ->where('related_id', $company->id)
                    ->where('type', $type)
                    ->whereHas('user')
                    ->first();
            }
        }

        return data_get($admin, 'user.email');
    }
}
