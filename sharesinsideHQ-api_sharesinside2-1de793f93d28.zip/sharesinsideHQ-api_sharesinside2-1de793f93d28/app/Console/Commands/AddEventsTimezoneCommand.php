<?php

namespace App\Console\Commands;

use App\Entities\Event;
use App\Services\GoogleApiService;
use Illuminate\Console\Command;
use Carbon\Carbon;

class AddEventsTimezoneCommand extends Command
{
    private $googleApiService;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:add:events:timezone';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get timezone from Google API by location and add event unix timestamp';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(GoogleApiService $googleApiService)
    {
        parent::__construct();
        $this->googleApiService = $googleApiService;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Event::query()
            ->whereNull('timezone_id')
            ->orWhereNull('event_timestamp')
            ->each(function ($event) {
                $timezone = $this->googleApiService->getTimezoneByLocation($event->latitude, $event->longitude);
                $timestamp = $timezone ? Carbon::createFromFormat('Y-m-d H:i:s', $event->event_date, $timezone)->timestamp : null;

                $event->update([
                    'timezone_id' => $timezone,
                    'event_timestamp' => $timestamp
                ]);
            });
    }
}
