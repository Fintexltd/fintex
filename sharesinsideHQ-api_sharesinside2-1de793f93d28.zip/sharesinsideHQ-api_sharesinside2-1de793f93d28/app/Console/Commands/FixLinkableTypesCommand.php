<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\Link;
use App\Entities\News;
use App\Entities\WatchlistItem;
use Illuminate\Console\Command;

class FixLinkableTypesCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:linkables';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add locations from events to location table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $fixableTypes = [
            News::class,
        ];

        Link::whereIn('linkable_type', $fixableTypes)
            ->get()
            ->each(function ($link) {
                $link->update([
                    'linkable_id' => $link->linkable->watchlistItem->id,
                    'linkable_type' => WatchlistItem::class,
                ]);

                return true;
            });
    }
}
