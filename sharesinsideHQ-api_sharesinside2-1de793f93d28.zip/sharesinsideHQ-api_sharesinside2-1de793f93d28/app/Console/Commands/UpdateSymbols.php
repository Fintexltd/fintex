<?php

namespace App\Console\Commands;

use App\Services\FeedProvider;
use Illuminate\Console\Command;

class UpdateSymbols extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'symbol:update {provider?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'updates symbols';

    /**
     * @var FeedProvider
     */
    protected $feedProvider;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(FeedProvider $feedProvider)
    {
        parent::__construct();

        $this->feedProvider = $feedProvider;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $provider = $this->argument('provider');

        switch ($provider) {
            case 'exante':
                $this->info('Updating exante');
                $this->feedProvider->updateAllSymbolsExante();
                break;
            case 'intrinio':
                $this->info('Updating intrinio');
                $this->feedProvider->updateAllSymbolsIntrinio();
                break;
            default:
                $this->info('Updating exante');
                $this->feedProvider->updateAllSymbolsExante();
                $this->info('Updating intrinio');
                $this->feedProvider->updateAllSymbolsIntrinio();
        }
    }
}
