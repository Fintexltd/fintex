<?php

namespace App\Console\Commands;

use App\Services\FeedProvider;
use Illuminate\Console\Command;

class StockOhlcCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:stock:ohlc {--force : force update all ohlc}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run stock ohlc update process';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(FeedProvider $feedProvider)
    {
        parent::__construct();
        $this->feedProvider = $feedProvider;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /** @var FeedProvider $service */
        $service = $this->feedProvider;

        $force = $this->option('force');

        $service->updateAllOhlc($force);
    }
}
