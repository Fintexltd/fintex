<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\WatchlistItem;
use App\Services\DescriptionSanitizer;
use Illuminate\Console\Command;

class FixAbstractsCommand extends Command
{
    protected $sanitizer;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:abstract';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'remove html tags from watchlist abstracts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(DescriptionSanitizer $sanitizer)
    {
        parent::__construct();

        $this->sanitizer = $sanitizer;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        WatchlistItem::all()
            ->each(function ($watchlistItem) {
                $fixed = $this
                    ->sanitizer
                    ->makeAbstract(data_get($watchlistItem, 'watchlistable.description'));
                $watchlistItem->update([
                    'abstract' => $fixed
                ]);

                return true;
            });
    }
}
