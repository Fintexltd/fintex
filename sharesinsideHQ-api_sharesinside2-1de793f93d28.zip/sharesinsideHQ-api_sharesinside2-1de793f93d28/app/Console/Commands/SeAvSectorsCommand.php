<?php

namespace App\Console\Commands;

use App\Services\SeAvProvider;
use Illuminate\Console\Command;

class SeAvSectorsCommand extends Command
{
    protected $seAvProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:se:av:sectors';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize sectors data from Alpha Vantage';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SeAvProvider $seAvProvider)
    {
        $this->seAvProvider = $seAvProvider;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->seAvProvider->syncSectorsData();
    }
}
