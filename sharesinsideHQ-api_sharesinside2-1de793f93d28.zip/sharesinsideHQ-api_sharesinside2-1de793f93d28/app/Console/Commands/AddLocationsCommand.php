<?php

namespace App\Console\Commands;

use App\Entities\Event;
use App\Services\LocationCreator;
use Illuminate\Console\Command;

class AddLocationsCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:locations:add';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add locations from events to location table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $locationCreator = new LocationCreator();

        Event::all()
            ->each(function ($event) use ($locationCreator) {
                $locationCreator->addLocation($event->adress);

                return true;
            });
    }
}
