<?php

namespace App\Console\Commands;

use App\Entities\Company;
use App\Jobs\CreateCompanyStatistic;
use App\Services\FeedProvider;
use Carbon\Carbon;
use Illuminate\Console\Command;
use App\Jobs\CreateCompanyStatisticMock;

class CreateCompanyStatisticMockCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:statistics:generate:mock {--all : create for all dates}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generate mock statistic for companies';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $all = $this->option('all');

        $yesterday = Carbon::yesterday()->toDateString();

        $companies = Company
            ::where(function ($query) {
                $query->whereHas('viewedBy')
                    ->orWhereHas('relations');
            })
            ->get();

        if (!$all) {

            $jobs = $companies
                ->each(function ($company) use ($yesterday) {
                    CreateCompanyStatisticMock::dispatch($company, $yesterday);
                    return true;
                });

        } else {
            $jobs = $companies
                ->each(function ($company) use ($yesterday) {
                    $currentDate = clone $company->created_at;
                    $date = '';
                    while ($date != $yesterday) {
                        $date = $currentDate->toDateString();
                        CreateCompanyStatisticMock::dispatch($company, $date);
                        $currentDate = $currentDate->modify('+1day');
                    }

                    return true;
                });
        }
    }
}
