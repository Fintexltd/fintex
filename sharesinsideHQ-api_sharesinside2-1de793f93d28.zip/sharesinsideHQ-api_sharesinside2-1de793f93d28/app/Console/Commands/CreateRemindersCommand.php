<?php

namespace App\Console\Commands;

use App\Entities\Reminder;
use App\Events\SocialMediaReminder;
use Carbon\Carbon;
use Illuminate\Console\Command;

class CreateRemindersCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:reminders:handle {--repeat : If should be run in loop}';


    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sends email and push reminders to create social media share';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('repeat')) {
            $this->loop();
        } else {
            $this->action();
        }
    }

    //TODO: consider refactor
    private function loop($maxMinuteLimit = 10, $sleepRate = 10)
    {
        $endAt = Carbon::now()->addMinutes($maxMinuteLimit);

        while ($endAt->isFuture()) {
            $this->action();
            sleep($sleepRate);
        }
    }

    public function action()
    {
        $now = Carbon::now()->toDateTimeString();

        Reminder::query()
            ->where('remind_at', '<=', $now)
            ->where('remind', true)
            ->where(function ($query) {
                $query
                    ->whereHas('news', function ($query) {
                        $query->whereHas('watchlistItem', function ($query) {
                            $query->where('is_draft', false);
                        });
                    })
                    ->orWhereHas('project', function ($query) {
                        $query->whereHas('watchlistItem', function ($query) {
                            $query->where('is_draft', false);
                        });
                    })
                    ->orWhereHas('event', function ($query) {
                        $query->whereHas('watchlistItem', function ($query) {
                            $query->where('is_draft', false);
                        });
                    });
            })
            ->with(['remindable', 'remindable.watchlistItem'])
            ->get()
            ->each(function ($reminder) {
                $publishedAt = $reminder->remindable->watchlistItem->publish_at;
                if ($publishedAt) {
                    $timestamp = $publishedAt->timestamp;
                    if ($timestamp < $reminder->remind_at->timestamp) {
                        event(new SocialMediaReminder($reminder));
                    }
                }

                $reminder->update([
                    'remind' => false,
                ]);
            });
    }
}
