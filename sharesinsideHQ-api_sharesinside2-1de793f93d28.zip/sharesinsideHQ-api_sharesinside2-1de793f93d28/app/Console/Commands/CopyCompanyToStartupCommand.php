<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\SocialMedia;
use App\Entities\Currency;
use App\Entities\Document;
use App\Entities\Employee;
use App\Entities\Relation;
use App\Entities\Company;
use App\Entities\CompanyStatisticMock;
use App\Entities\CompanyViewer;
use App\Entities\Exclusion;
use App\Entities\Link;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Entities\RelationInterface;
use App\Entities\Startup;
use App\Entities\StartupCategory;
use App\Entities\StartupStatisticMock;
use App\Entities\StartupViewer;
use App\Entities\WatchlistItem;
use App\Entities\News;
use App\Entities\Event;
use App\Entities\Project;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use DB;

class CopyCompanyToStartupCommand extends Command
{
    private $company;
    private $startup;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:cp:company-to-startup {companyId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Copy Company To Startup';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->copmany = Company::withTrashed()->findOrFail($this->argument('companyId'));
        $this->startup = new Startup();

        DB::transaction(function () {
            $this->copyCompanyToStartup();
            $this->copyAttachemts();
            $this->copyStatisticMocks();
            $this->copyViewers();
            $this->copyExclusions();
            $this->copyLinks();
            $this->copySocialMedia();
            $this->copyRelations();

            File::copyDirectory(storage_path('app/companies/'.$this->copmany->id), storage_path('app/startups/'.$this->startup->id));

            $this->copySections();
            $this->copyWatchlistItems();
        });

        echo $this->startup->id."\n";

        return 0;
    }

    private function copyCompanyToStartup()
    {
        $currency = Currency::firstOrFail();
        $startupCategory = StartupCategory::firstOrFail();

        $this->startup->fill([
            'name' => $this->copmany->name,
            'phone' => $this->copmany->phone,
            'email' => $this->copmany->email,
            'website' => $this->copmany->website,
            'address' => $this->copmany->adress,
            'longitude' => $this->copmany->longitude,
            'latitude' => $this->copmany->latitude,
            'title' => $this->copmany->title,
            'description' => $this->copmany->description,
            'raised_amount' => 0,
            'is_equity' => true,
            'is_accepted' => $this->copmany->is_accepted,
            'dont_allow_shareholders' => $this->copmany->dont_allow_shareholders,
            'views' => $this->copmany->views,
        ]);

        $this->startup->deleted_at = $this->copmany->deleted_at;
        $this->startup->created_at = $this->copmany->created_at;
        $this->startup->updated_at = $this->copmany->updated_at;

        $this->startup->save();

        $this->startup->currency()->associate($currency);
        $this->startup->country()->associate($this->copmany->country);
        $this->startup->startupCategories()->attach($startupCategory);

        $this->startup->save();
    }

    private function copyAttachemts()
    {
        Attachment::query()
            ->where('attachable_id', $this->copmany->id)
            ->where('attachable_type', Company::class)
            ->get()
            ->each(function ($companyAttachment) {
                $startupAttachment = $companyAttachment->replicate();
                $startupAttachment->type = str_replace('company', 'startup', $companyAttachment->type);
                $startupAttachment->created_at = $companyAttachment->created_at;
                $startupAttachment->updated_at = $companyAttachment->updated_at;
                $this->startup->attachments()->save($startupAttachment);
            });
    }

    private function copyStatisticMocks()
    {
        CompanyStatisticMock::query()
            ->where('company_id', $this->copmany->id)
            ->get()
            ->each(function ($companyStatisticMock) {
                $startupStatisticMock = new StartupStatisticMock();

                $startupStatisticMock->fill([
                    'date' => $companyStatisticMock->date,
                    'value' => $companyStatisticMock->value,
                    'startup_id' => $this->startup->id,
                ]);

                $startupStatisticMock->created_at = $companyStatisticMock->created_at;
                $startupStatisticMock->updated_at = $companyStatisticMock->updated_at;

                $startupStatisticMock->save();
            });
    }

    private function copyViewers()
    {
        CompanyViewer::query()
            ->where('company_id', $this->copmany->id)
            ->get()
            ->each(function ($companyViewer) {
                StartupViewer::create([
                    'startup_id' => $this->startup->id,
                    'user_id' => $companyViewer->user_id,
                    'profile' => $companyViewer->profile,
                    'news' => $companyViewer->news,
                    'events' => $companyViewer->events,
                    'projects' => $companyViewer->projects,
                    'date' => $companyViewer->date,
                ]);
            });
    }

    private function copyExclusions()
    {
        Exclusion::query()
            ->where('excludable_id', $this->copmany->id)
            ->where('excludable_type', Company::class)
            ->get()
            ->each(function ($companyExclusion) {
                $startupExclusion = $companyExclusion->replicate();
                $startupExclusion->created_at = $companyExclusion->created_at;
                $startupExclusion->updated_at = $companyExclusion->updated_at;
                $this->startup->excluded()->save($startupExclusion);
            });
    }

    private function copyLinks()
    {
        Link::query()
            ->where('linkable_id', $this->copmany->id)
            ->where('linkable_type', Company::class)
            ->get()
            ->each(function ($companyLink) {
                $startupLink = $companyLink->replicate();
                $startupLink->created_at = $companyLink->created_at;
                $startupLink->updated_at = $companyLink->updated_at;
                $this->startup->links()->save($startupLink);
            });
    }

    private function copySocialMedia()
    {
        SocialMedia::query()
            ->where('sociable_id', $this->copmany->id)
            ->where('sociable_type', Company::class)
            ->get()
            ->each(function ($companySocialMedia) {
                $startupSocialMedia = $companySocialMedia->replicate();
                $startupSocialMedia->created_at = $companySocialMedia->created_at;
                $startupSocialMedia->updated_at = $companySocialMedia->updated_at;
                $this->startup->socialMedia()->save($startupSocialMedia);
            });
    }


    private function copyRelations()
    {
        Relation::query()
            ->where('related_id', $this->copmany->id)
            ->where('related_type', Company::class)
            ->get()
            ->each(function ($companyRelation) {
                $startupRelation = $companyRelation->replicate();
                $startupRelation->related_id = $this->startup->id;
                $startupRelation->related_type = Startup::class;
                $startupRelation->created_at = $companyRelation->created_at;
                $startupRelation->updated_at = $companyRelation->updated_at;
                $startupRelation->save();

                switch ($companyRelation->type) {
                    case RelationInterface::RELATION_TYPE_SHAREHOLDER:
                    case RelationInterface::RELATION_TYPE_SHAREHOLDER_PENDING:
                    case RelationInterface::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM:
                        $this->copyShareholder($companyRelation, $startupRelation);
                        break;
                }
            });
    }

    private function copyShareholder($companyRelation, $startupRelation)
    {
        $companyShareholder = $companyRelation->shareholder;
        $startupShareholder = $companyShareholder->replicate();
        $startupShareholder->created_at = $companyShareholder->created_at;
        $startupShareholder->updated_at = $companyShareholder->updated_at;
        $startupRelation->shareholder()->save($startupShareholder);

        if($companyShareholderCode = $companyShareholder->shareholderCode) {
            $startupShareholderCode = $companyShareholderCode->replicate();
            $startupShareholderCode->created_at = $companyShareholderCode->created_at;
            $startupShareholderCode->updated_at = $companyShareholderCode->updated_at;
            $startupShareholder->shareholderCode()->save($startupShareholderCode);
        }
    }

    private function copySections()
    {
        Section::query()
            ->where('referenced_id', $this->copmany->id)
            ->where('referenced_type', Company::class)
            ->get()
            ->each(function ($companySection) {
                $startupSection = $companySection->replicate();
                $startupSection->created_at = $companySection->created_at;
                $startupSection->updated_at = $companySection->updated_at;
                $this->startup->sections()->save($startupSection);

                switch ($companySection->type) {
                    case SectionInterface::EMPLOYEE_SECTION:
                        $this->copyEmployees($companySection, $startupSection);
                        break;
                    case SectionInterface::HISTORICAL_DATA_SECTION:
                        $startupSection->update([
                            'type' => SectionInterface::DOCUMENT_SECTION
                        ]);
                        $this->copyHistoricalDatasToDocuments($companySection, $startupSection);
                        break;
                    case SectionInterface::COMPANY_GALLERY_ITEMS_SECTION:
                    case SectionInterface::COMPANY_GALLERY_ALBUM_SECTION:
                        $this->copyItems($companySection, $startupSection);
                        File::copyDirectory(storage_path('app/startups/'.$this->startup->id.'/gallery/'.$companySection->id), storage_path('app/startups/'.$this->startup->id.'/gallery/'.$startupSection->id));
                        break;
                }
            });
    }

    private function copyEmployees($companySection, $startupSection)
    {
        $companySection
            ->employees()
            ->get()
            ->each(function ($companyEmployee) use ($startupSection) {
                $startupEmployee = $companyEmployee->replicate();
                $startupEmployee->created_at = $companyEmployee->created_at;
                $startupEmployee->updated_at = $companyEmployee->updated_at;
                $startupSection->employees()->save($startupEmployee);

                if ($companyEmployee->photo) {
                    $startupEmployee->photo()->save($companyEmployee->photo->replicate());
                }

                if ($companyEmployee->attachment) {
                    $startupEmployee->attachment()->save($companyEmployee->attachment->replicate());
                }
            });
    }

    private function copyHistoricalDatasToDocuments($companySection, $startupSection)
    {
        $companySection
            ->historicalDataPiece()
            ->get()
            ->each(function ($historicalDataPiece) use ($startupSection) {
                $document = new Document();
                $document->title = $historicalDataPiece->title;
                $document->created_at = $historicalDataPiece->created_at;
                $document->updated_at = $historicalDataPiece->updated_at;
                $startupSection->documents()->save($document);

                $document->attachment()->save($historicalDataPiece->attachment->replicate());
            });
    }

    private function copyItems($companySection, $startupSection)
    {
        $companySection
            ->items()
            ->get()
            ->each(function ($companyItem) use ($startupSection) {
                $startupItem = $companyItem->replicate();
                $startupItem->created_at = $companyItem->created_at;
                $startupItem->updated_at = $companyItem->updated_at;
                $startupSection->items()->save($startupItem);

                $startupItem->file()->save($companyItem->file->replicate());
            });
    }

    private function copyWatchlistItems()
    {
        WatchlistItem::query()
            ->withTrashed()
            ->where('entitiable_id', $this->copmany->id)
            ->where('entitiable_type', Company::class)
            ->get()
            ->each(function ($companyWatchlistItem) {
                $companyWatchlistable = $companyWatchlistItem->watchlistable;
                $startupWatchlistable = $companyWatchlistable->replicate();
                $startupWatchlistable->created_at = $companyWatchlistable->created_at;
                $startupWatchlistable->updated_at = $companyWatchlistable->updated_at;
                $startupWatchlistable->save();

                $startupWatchlistItem = $companyWatchlistItem->replicate();
                $startupWatchlistItem->deleted_at = $companyWatchlistItem->deleted_at;

                $startupWatchlistItemData = $startupWatchlistItem->toArray();
                $startupWatchlistItemData['entitiable_id'] = $this->startup->id;
                $startupWatchlistItemData['entitiable_type'] = Startup::class;
                unset(
                    $startupWatchlistItemData['watchlistable_id'],
                    $startupWatchlistItemData['watchlistable_type'],
                    $startupWatchlistItemData['watchlistable']
                );
                $startupWatchlistable->watchlistItem->update($startupWatchlistItemData);

                $companyWatchlistItem->attachments->each(function ($companyAttachment) use ($startupWatchlistable) {
                    $startupAttachment = $companyAttachment->replicate();
                    $startupAttachment->created_at = $companyAttachment->created_at;
                    $startupAttachment->updated_at = $companyAttachment->updated_at;
                    $startupWatchlistable->watchlistItem->attachments()->save($startupAttachment);
                });

                switch ($companyWatchlistItem->watchlistable_type) {
                    case News::class:
                        $type = 'news';
                        break;
                    case Event::class:
                        $type = 'events';
                        break;
                    case Project::class:
                        $type = 'projects';
                        break;
                }

                File::copyDirectory(storage_path('app/startups/'.$this->startup->id.'/'.$type.'/'.$companyWatchlistable->id), storage_path('app/startups/'.$this->startup->id.'/'.$type.'/'.$startupWatchlistable->id));
            });
    }
}
