<?php

namespace App\Console\Commands;

use App\Entities\Startup;
use App\Services\FeedProvider;
use Carbon\Carbon;
use Illuminate\Console\Command;
use App\Jobs\CreateStartupStatisticMock;

class CreateStartupStatisticMockCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:startups-statistics:generate:mock {--all : create for all dates}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generate mock statistic for startups';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $all = $this->option('all');

        $yesterday = Carbon::yesterday()->toDateString();

        $startups = Startup
            ::where(function ($query) {
                $query->whereHas('viewedBy')
                    ->orWhereHas('relations');
            })
            ->get();

        if (!$all) {

            $jobs = $startups
                ->each(function ($startup) use ($yesterday) {
                    CreateStartupStatisticMock::dispatch($startup, $yesterday);
                    return true;
                });

        } else {
            $jobs = $startups
                ->each(function ($startup) use ($yesterday) {
                    $currentDate = clone $startup->created_at;
                    $date = '';
                    while ($date != $yesterday) {
                        $date = $currentDate->toDateString();
                        CreateStartupStatisticMock::dispatch($startup, $date);
                        $currentDate = $currentDate->modify('+1day');
                    }

                    return true;
                });
        }
    }
}
