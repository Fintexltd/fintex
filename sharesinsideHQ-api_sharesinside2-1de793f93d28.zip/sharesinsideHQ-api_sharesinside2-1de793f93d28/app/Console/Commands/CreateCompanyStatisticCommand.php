<?php

namespace App\Console\Commands;

use App\Entities\Company;
use App\Jobs\CreateCompanyStatistic;
use App\Services\FeedProvider;
use Carbon\Carbon;
use Illuminate\Console\Command;

class CreateCompanyStatisticCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:statistics:generate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generate statistic for companies';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $yesterday = Carbon::yesterday()->toDateString();

        $companies = Company
            ::where(function ($query) {
                $query->whereHas('viewedBy')
                    ->orWhereHas('relations');
            })
            ->get();

        $jobs = $companies
            ->each(function ($company) use ($yesterday) {
                CreateCompanyStatistic::dispatch($company, $yesterday);
                return true;
            });
    }
}
