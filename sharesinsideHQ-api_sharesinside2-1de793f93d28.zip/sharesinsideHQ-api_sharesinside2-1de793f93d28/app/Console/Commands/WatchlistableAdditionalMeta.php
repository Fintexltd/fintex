<?php

namespace App\Console\Commands;

use App\Entities\Fund;
use App\Entities\Event;
use App\Entities\News;
use App\Entities\Project;
use App\Entities\WatchlistItemInterface;
use Illuminate\Support\Facades\URL;
use Illuminate\Console\Command;

class WatchlistableAdditionalMeta extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:watchlistable:meta {watchlistableType} {watchlistableId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'returns meta for watchlistable type with selected id';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $watchlistableType = $this->argument('watchlistableType');
        $watchlistableId = $this->argument('watchlistableId');

        switch ($watchlistableType) {
            case WatchlistItemInterface::WATCHLISTABLE_TYPE_NEWS:
                $watchlistable = News::find($watchlistableId);
                break;
            case WatchlistItemInterface::WATCHLISTABLE_TYPE_PROJECT:
                $watchlistable = Project::find($watchlistableId);
                break;
            case WatchlistItemInterface::WATCHLISTABLE_TYPE_EVENT:
                $watchlistable = Event::find($watchlistableId);
                break;
        }

        if (
            !isset($watchlistable) ||
            empty($watchlistable) ||
            !($watchlistItem = array_get($watchlistable, 'watchlistItem', null)) ||
            $watchlistItem->is_excluded ||
            $watchlistItem->is_business ||
            $watchlistItem->is_internal ||
            $watchlistItem->notify_stock ||
            $watchlistItem->is_draft ||
            !($watchlistItem->publish_at ? $watchlistItem->publish_at->isPast() : false)
        ) {
            return '';
        }

        try {
            $logo = $watchlistItem->entitiable->logo ??
                (get_class($watchlistItem->entitiable)==Fund::class ?
                $watchlistItem->entitiable->fundsManager->logo :
                null);
            $image = URL::to($logo ? $logo->getPath() : '/');
        } catch (\Exception $e) {
            $image = URL::to('/');
        }

        list ($imageWidth, $imageHight) = getimagesize(storage_path('app/' . $logo->getPath()));

        echo implode('', [
            '<meta name="robots" content="noindex" />',
            '<meta name="twitter:card" content="summary" />',
            '<meta property="og:title" content="' . $watchlistable->title . '" />',
            '<meta property="og:type" content="article" />',
            '<meta property="og:image" content="' . $image . '" />',
            '<meta property="og:image:width" content="' . $imageWidth . '" />',
            '<meta property="og:image:height" content="' . $imageHight . '" />',
            '<meta property="og:description" content="' . $watchlistItem->abstract . '" />',
            '<!-- '.$watchlistItem->social_share_key.' -->'
        ]);
    }
}
