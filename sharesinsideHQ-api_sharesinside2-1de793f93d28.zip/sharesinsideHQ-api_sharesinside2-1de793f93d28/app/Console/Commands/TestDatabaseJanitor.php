<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\DatabaseJanitor;

class TestDatabaseJanitor extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:databasejanitor {functionName?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Test database janitor';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(DatabaseJanitor $service)
    {
        $this->service = $service;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $functionName = $this->argument('functionName');

        if ($functionName) {
            $this->service->handleFunction($functionName);
        } else {
            $this->service->handle();
        }
    }
}
