<?php

namespace App\Console\Commands;

use App\Entities\NotificationSettings;
use App\User;
use Illuminate\Console\Command;

class FixNotificationSettingsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:notification.settings';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add nottification settings for existing users';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        User::doesntHave('notificationSettings')
            ->where('accept_terms', true)
            ->get()
            ->each(function ($user) {
                return NotificationSettings::create(['user_id' => $user->id]);
            });
    }
}
