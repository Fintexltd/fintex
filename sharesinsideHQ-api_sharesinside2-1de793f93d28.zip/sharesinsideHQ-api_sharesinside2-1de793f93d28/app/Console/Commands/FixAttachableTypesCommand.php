<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\News;
use App\Entities\WatchlistItem;
use Illuminate\Console\Command;

class FixAttachableTypesCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:attachables';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add locations from events to location table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $fixableTypes = [
            News::class,
        ];

        Attachment::whereIn('attachable_type', $fixableTypes)
            ->get()
            ->each(function ($attachment) {
                $attachment->update([
                    'attachable_id' => $attachment->attachable->watchlistItem->id,
                    'attachable_type' => WatchlistItem::class,
                ]);

                return true;
            });
    }
}
