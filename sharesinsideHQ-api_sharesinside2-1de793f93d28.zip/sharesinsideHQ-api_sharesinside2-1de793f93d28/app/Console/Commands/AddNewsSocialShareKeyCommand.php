<?php

namespace App\Console\Commands;

use App\Entities\News;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

class AddNewsSocialShareKeyCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:news:addsocialsharekey';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add social share keys for news';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        News::whereHas('watchlistItem', function ($query){
            $query->whereNull('social_share_key');
        })->get()->each(function ($news){
            $key = Str::random(16);
            $news->watchlistItem->social_share_key = $key;
            $news->watchlistItem->save();
            $this->info('Update news ID: '.$news->id.' [watchlistItem ID: '.$news->watchlistItem->id.'] with social_share_key: '.$key);
        });
    }
}
