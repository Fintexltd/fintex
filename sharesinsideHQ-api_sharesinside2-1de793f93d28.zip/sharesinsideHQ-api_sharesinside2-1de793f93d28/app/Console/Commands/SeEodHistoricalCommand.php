<?php

namespace App\Console\Commands;

use App\Exceptions\Handler;
use App\Services\SeEodProvider;
use Illuminate\Console\Command;

class SeEodHistoricalCommand extends Command
{
    protected $seEodProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:se:eod:historical {symbol} {--deleteNonExists}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize symbol historical data from EOD Historical Data';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SeEodProvider $seEodProvider)
    {
        $this->seEodProvider = $seEodProvider;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $symbol = $this->argument('symbol');
        $deleteNonExists = $this->option('deleteNonExists') ? true : false;

        try {
            $this->seEodProvider->syncHistoricalData($symbol, $deleteNonExists);
        } catch (\Exception $e) {
            $h = new Handler(app());
            $h->report($e);
            return 1;
        }

        return 0;
    }
}
