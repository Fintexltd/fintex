<?php

namespace App\Console\Commands;

use App\Entities\Fund;
use App\Services\FeedProvider;
use Carbon\Carbon;
use Illuminate\Console\Command;
use App\Jobs\CreateFundStatisticMock;

class CreateFundStatisticMockCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:funds-statistics:generate:mock {--all : create for all dates}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generate mock statistic for funds';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $all = $this->option('all');

        $yesterday = Carbon::yesterday()->toDateString();

        $funds = Fund
            ::where(function ($query) {
                $query->whereHas('viewedBy')
                    ->orWhereHas('relations');
            })
            ->get();

        if (!$all) {

            $jobs = $funds
                ->each(function ($fund) use ($yesterday) {
                    CreateFundStatisticMock::dispatch($fund, $yesterday);
                    return true;
                });

        } else {
            $jobs = $funds
                ->each(function ($fund) use ($yesterday) {
                    $currentDate = clone $fund->created_at;
                    $date = '';
                    while ($date != $yesterday) {
                        $date = $currentDate->toDateString();
                        CreateFundStatisticMock::dispatch($fund, $date);
                        $currentDate = $currentDate->modify('+1day');
                    }

                    return true;
                });
        }
    }
}
