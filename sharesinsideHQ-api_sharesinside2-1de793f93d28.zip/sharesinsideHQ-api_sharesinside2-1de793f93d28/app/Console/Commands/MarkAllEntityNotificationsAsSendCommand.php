<?php

namespace App\Console\Commands;

use App\Entities\Company;
use App\Entities\EntityNotification;
use App\Entities\FundsManager;
use App\Entities\Fund;
use App\Entities\Startup;
use Illuminate\Console\Command;
use Carbon\Carbon;

class MarkAllEntityNotificationsAsSendCommand extends Command
{
    private $googleApiService;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:add:entity-notifications:mark-all-send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Mark all entity notifications as send';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $timestamp = Carbon::now();

        $insertData = collect()
            ->merge(Company::doesnthave('entityNotifications')->get())
            ->merge(FundsManager::doesnthave('entityNotifications')->get())
            ->merge(Fund::doesnthave('entityNotifications')->get())
            ->merge(Startup::doesnthave('entityNotifications')->get())
            ->map(function ($entity) use ($timestamp) {
                return [
                    'notificable_type' => get_class($entity),
                    'notificable_id' => $entity->id,
                    'created_at' =>  $timestamp,
                    'updated_at' => $timestamp
                ];
            })
            ->toArray();

        if (count($insertData)) {
            EntityNotification::insert($insertData);
        }
    }
}
