<?php

namespace App\Console\Commands;

use App\Exceptions\Handler;
use App\Services\LondonStockExchangeProvider;
use Illuminate\Console\Command;

class LondonStockExchangeCommand extends Command
{
    protected $provider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:london-stock-exchange';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch data from the London Stock Exchange';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(LondonStockExchangeProvider $provider)
    {
        $this->provider = $provider;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //try {
            $this->provider->fetchAndStore();
        //} catch (\Exception $e) {
        //    $h = new Handler(app());
        //    $h->report($e);
        //    return 1;
        //}

        return 0;
    }
}
