<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use Illuminate\Console\Command;

class FixMimeTypesCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:mimes';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add locations from events to location table';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $fixableTypes = [
            'doc',
            'docx',
            'mp4',
            'pdf',
            'pptx',
            'xlsx',
            'jpeg',
            'png',
            'gif',
            '.jpeg',
            '.png',
            '.gif',
        ];

        $fixes = [
            'pdf' => 'application/pdf',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'doc' => 'application/msword',
            'mp4' => 'video/mp4',
            'gif' => 'image/gif',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            '.gif' => 'image/gif',
            '.jpeg' => 'image/jpeg',
            '.png' => 'image/png',
        ];

        Attachment::whereIn('mime_type', $fixableTypes)
            ->get()
            ->each(function ($attachment) use ($fixes){
                $attachment->update([
                    'mime_type' => $fixes[$attachment->mime_type],
                ]);

                return true;
            });
    }
}
