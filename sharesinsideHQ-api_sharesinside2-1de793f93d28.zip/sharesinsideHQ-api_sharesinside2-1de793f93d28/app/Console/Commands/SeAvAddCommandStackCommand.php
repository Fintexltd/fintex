<?php

namespace App\Console\Commands;

use App\Exceptions\Handler;
use App\Services\SeAvCommandStackService;
use Illuminate\Console\Command;

class SeAvAddCommandStackCommand extends Command
{
    protected $service;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:se:av:add-command-stack';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add commands to stack for Alpha Vantage API';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SeAvCommandStackService $service)
    {
        $this->service = $service;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try {
            $this->service->addCommands();
        } catch (\Exception $e) {
            $h = new Handler(app());
            $h->report($e);
            return 1;
        }

        return 0;
    }
}
