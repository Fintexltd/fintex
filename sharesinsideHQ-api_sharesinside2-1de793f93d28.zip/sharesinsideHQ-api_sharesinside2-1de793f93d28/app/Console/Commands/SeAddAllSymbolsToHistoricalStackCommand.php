<?php

namespace App\Console\Commands;

use App\Entities\SeSymbol;
use App\Repositories\SeCommandStackRepository;
use App\Services\SeCommandStackService;
use Illuminate\Console\Command;

class SeAddAllSymbolsToHistoricalStackCommand extends Command
{
    protected $service;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:se:all-to-historical';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add all symbols to historical stack';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(SeCommandStackService $service)
    {
        $this->service = $service;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        SeSymbol::where('is_valid', true)->get()->each(function ($symbol) {
            $this->service->addCommand(SeCommandStackRepository::SE_COMMAND_STACK_COMMAND_HISTORICAL, $symbol);
        });

        return 0;
    }
}
