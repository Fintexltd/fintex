<?php

namespace App\Console\Commands;

use App\Entities\FundsManager;
use App\Services\FeedProvider;
use Carbon\Carbon;
use Illuminate\Console\Command;
use App\Jobs\CreateFundsManagerStatisticMock;

class CreateFundsManagerStatisticMockCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:funds-managers-statistics:generate:mock {--all : create for all dates}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generate mock statistic for funds managers';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $all = $this->option('all');

        $yesterday = Carbon::yesterday()->toDateString();

        $fundsManagers = FundsManager
            ::where(function ($query) {
                $query->whereHas('viewedBy')
                    ->orWhereHas('relations');
            })
            ->get();

        if (!$all) {

            $jobs = $fundsManagers
                ->each(function ($fundsManager) use ($yesterday) {
                    CreateFundsManagerStatisticMock::dispatch($fundsManager, $yesterday);
                    return true;
                });

        } else {
            $jobs = $fundsManagers
                ->each(function ($fundsManager) use ($yesterday) {
                    $currentDate = clone $fundsManager->created_at;
                    $date = '';
                    while ($date != $yesterday) {
                        $date = $currentDate->toDateString();
                        CreateFundsManagerStatisticMock::dispatch($fundsManager, $date);
                        $currentDate = $currentDate->modify('+1day');
                    }

                    return true;
                });
        }
    }
}
