<?php

namespace App\Console\Commands;

use App\Criteria\ActiveEntitiesCriteria;
use App\Entities\WatchlistItem;
use App\Events\WatchlistItemPublished;
use Carbon\Carbon;
use Illuminate\Console\Command;

class CreateWatchlistNotificationsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:watchlist:push {--repeat : If should be run in loop}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'generates pushes for new publications on watchlist';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if ($this->option('repeat')) {
            $this->loop();
        } else {
            $this->action();
        }
    }

    //TODO: consider refactor
    private function loop($maxMinuteLimit = 10, $sleepRate = 10)
    {
        $endAt = Carbon::now()->addMinutes($maxMinuteLimit);

        while ($endAt->isFuture()) {
            $this->action();
            sleep($sleepRate);
        }
    }

    private function action()
    {
        $now = Carbon::now()->toDateTimeString();

        $activeEntitiesCriteria = new ActiveEntitiesCriteria();

        WatchlistItem::query()
            ->where('notify_publicity', true)
            ->where('notify_stock', false)
            ->where('is_draft', false)
            ->where('publish_at', '<=', $now)
            ->where($activeEntitiesCriteria->appendQuery())
            ->get()
            ->each(function ($watchlistItem) {
                event(new WatchlistItemPublished($watchlistItem));

                $watchlistItem->update([
                    'notify_publicity' => false,
                ]);
            });
    }
}
