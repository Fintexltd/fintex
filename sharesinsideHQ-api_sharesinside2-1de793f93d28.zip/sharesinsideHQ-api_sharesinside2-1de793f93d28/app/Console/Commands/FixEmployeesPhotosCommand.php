<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\Employee;
use App\Entities\News;
use App\Entities\WatchlistItem;
use App\Repositories\AttachmentRepository;
use App\Services\ImageResizer;
use Illuminate\Console\Command;

class FixEmployeesPhotosCommand extends Command
{
    protected $failed = 0;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:employees';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'resize employees photos if needed.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $photos = Attachment::query()
            ->where('attachable_type', Employee::class)
            ->where('type', AttachmentRepository::TYPE_IMAGE)
            ->get()
            ->map(function ($photo) {
                return storage_path('app/' . $photo->getPath());
            })
            ->filter(function ($path) {
                return file_exists($path);
            })
            ->each(function ($path) {
                try {
                    ImageResizer::resize(($path));
                } catch (\Exception $e) {
                    $this->failed++;
                }
            });

        if ($this->failed) {
            echo 'Failted attempts: ' . $this->failed;
        }
    }
}
