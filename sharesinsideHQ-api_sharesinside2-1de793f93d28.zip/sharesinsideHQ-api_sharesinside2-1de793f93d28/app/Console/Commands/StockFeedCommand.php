<?php

namespace App\Console\Commands;

use App\Services\FeedProvider;
use Illuminate\Console\Command;

class StockFeedCommand extends Command
{
    protected $feedProvider;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:stock:feed {--limit= : limit infinite loop} {--id= : id of process stack} {--stop : stop current running processes}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run Stock feed, use --limit option to limit infinite loop';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(FeedProvider $feedProvider)
    {
        parent::__construct();
        $this->feedProvider = $feedProvider;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /** @var FeedProvider $service */
        $service = $this->feedProvider;
        $stop = $this->option('stop');

        if (!empty($stop)) {
            $service->stop();
            return;
        }

        $limit = $this->option('limit');

        if ($limit != null) {
            $limit = intval($limit);
        }

        $id = intval($this->option('id'));

        if ($id != null) {
            $service->updateFeed($id, $limit);
        } else {
            $service->runFeedProcess($limit);
        }
    }
}
