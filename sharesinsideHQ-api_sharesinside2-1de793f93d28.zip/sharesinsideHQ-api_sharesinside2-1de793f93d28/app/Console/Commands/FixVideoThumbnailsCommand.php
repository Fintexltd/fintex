<?php

namespace App\Console\Commands;

use App\Entities\Attachment;
use App\Entities\Link;
use App\Entities\WatchlistItem;
use App\Events\ShouldCreateThumbnailEvent;
use App\Repositories\LinkRepository;
use App\Services\DescriptionSanitizer;
use App\Services\VideoLinkThumbnailService;
use Illuminate\Console\Command;

class FixVideoThumbnailsCommand extends Command
{
    protected $sanitizer;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:fix:videoThumbnails';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'add thumbnails for watchlist videos';

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Attachment::query()
            ->where('type', 'type_video')
            ->whereDoesntHave('thumbnail')
//            ->whereHas('attachable')
            ->get()
            ->filter(function($attachment){
                return $attachment->attachable;
            })
            ->each(function ($attachment) {
                event(new ShouldCreateThumbnailEvent($attachment));
            });

        Link::query()
            ->whereDoesntHave('thumbnail')
            ->where('type', LinkRepository::TYPE_VIDEO)
            ->get()
            ->each(function ($link) {
                VideoLinkThumbnailService::createThumbnailForLinkIfVimeo($link);
            });
    }
}
