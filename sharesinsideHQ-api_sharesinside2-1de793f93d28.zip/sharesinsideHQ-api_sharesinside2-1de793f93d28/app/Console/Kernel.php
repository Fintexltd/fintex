<?php

namespace App\Console;

use App\Console\Commands\AddEventsTimezoneCommand;
use App\Console\Commands\CreateCompanyStatisticCommand;
use App\Console\Commands\LondonStockExchangeCommand;
use App\Console\Commands\SeAvSectorsCommand;
//use App\Console\Commands\StockFeedCommand;
//use App\Console\Commands\StockOhlcCommand;
use App\Tasks\FlushExpiredDemoAccounts;
use App\Tasks\FlushExpiredNotifications;
use App\Tasks\FlushExpiredSecurityTokens;
use App\Tasks\FlushOldDeletedEntries;
use App\Services\SeCommandStackService;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule
            ->call(function () {
                FlushExpiredSecurityTokens::run();
                FlushExpiredDemoAccounts::run();
            })
            ->everyFiveMinutes();

        $schedule
            ->command(SeAvSectorsCommand::class)
            ->everyFiveMinutes();

        $schedule
            ->call(function () {
                FlushOldDeletedEntries::run();
                SeCommandStackService::resetUnprocessed();
            })
            ->hourly();

        $schedule
            ->command(LondonStockExchangeCommand::class)
            ->hourly();

        $schedule
            ->call(function () {
                FlushExpiredNotifications::run();
                SeCommandStackService::flushProcessed();
            })
            ->daily();

        $schedule
            ->command(CreateCompanyStatisticCommand::class)
            ->cron('25 1 * * *');

        $schedule
            ->command(AddEventsTimezoneCommand::class)
            ->cron('10 3 * * *');

//        //TODO: consider what to do with this one
//        if (env('APP_ENV') == 'production') {
//
//            $schedule
//                ->command(StockOhlcCommand::class, [
//                    '--env=prod',
//                ])
//                ->cron('*/30 * * * *');
//
//            $schedule
//                ->command(StockFeedCommand::class, [
//                    '--stop',
//                    '--env=prod',
//                ])
//                ->cron('25 2 * * *');
//
//            //TODO: consider if env('SUPERVISOR_PATH') should be moved to config
//            $schedule
//                ->exec(env('SUPERVISOR_PATH') . ' -c ' . base_path('.config/' . env('SUPERVISOR_CONFIG', 'supervisord.conf')) . ' restart all')
//                ->cron('20 2 * * *');
//        }
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
