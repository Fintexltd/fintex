<?php

namespace App\Http\Controllers;

use App\Entities\StartupCategory;
use App\Events\StartupCategoryCreated;
use App\Http\Requests\StartupCategoryDeleteRequest;
use App\Http\Requests\StartupCategoryIndexRequest;
use App\Http\Requests\StartupCategoryStoreRequest;
use App\Http\Requests\StartupCategoryUpdateRequest;
use App\Http\Resources\StartupCategoryCollection;
use App\Http\Resources\MessageResource;
use Illuminate\Http\Request;

class StartupCategoryController extends Controller
{
    /**
     * @param StartupCategoryIndexRequest $request
     * @return StartupCategoryCollection
     */
    public function index(StartupCategoryIndexRequest $request)
    {
        $query = StartupCategory::query();

        if ($search = $request->get('search')) {
            $query->where('name', 'LIKE', "%$search%");
        }

        $results = $query
            ->orderBy('sort_order', 'ASC')
            ->orderBy('name', 'ASC')
            ->get();

        return new StartupCategoryCollection($results);
    }

    /**
     * @param StartupCategoryStoreRequest $request
     * @return MessageResource
     */
    public function store(StartupCategoryStoreRequest $request)
    {
        $data = $request->validated();
        $data['sort_order'] = $data['name'];

        $startupCategory = StartupCategory::create($data);

        event(new StartupCategoryCreated($startupCategory));

        $response = [
            'message' => 'Startup category created',
            'startup_category_id' => $startupCategory->id,
        ];

        return new MessageResource($response);
    }

    /**
     * @param StartupCategoryUpdateRequest $request
     * @param StartupCategory $startupCategory
     * @return MessageResource
     */
    public function update(StartupCategoryUpdateRequest $request, StartupCategory $startupCategory)
    {
        $data = $request->validated();
        $data['sort_order'] = $data['name'];

        $startupCategory->update($data);

        $response = ['message' => 'Startup category updated'];

        return new MessageResource($response);
    }

    /**
     * @param StartupCategoryDeleteRequest $request
     * @param StartupCategory $startupCategory
     * @return MessageResource
     */
    public function destroy(StartupCategoryDeleteRequest $request, StartupCategory $startupCategory)
    {
        $startupCategory->delete();

        $response = ['message' => 'Startup category removed'];

        return new MessageResource($response);
    }
}
