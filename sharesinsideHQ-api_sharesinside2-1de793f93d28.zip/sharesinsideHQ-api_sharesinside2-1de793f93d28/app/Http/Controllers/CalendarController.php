<?php

namespace App\Http\Controllers;

use App\Criteria\WatchlistExclusionCriteria;
use App\Criteria\WatchlistItemUserRoleCriteria;
use App\Criteria\WatchlistSortByCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Http\Requests\WatchlistEventCalendarRequest;
use App\Http\Resources\WatchlistCalendarResource;
use App\Repositories\WatchlistItemRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;

class CalendarController extends Controller
{
    protected $repository;

    public function __construct(WatchlistItemRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param WatchlistEventCalendarRequest
     * @return WatchlistCalendarResource
     */
    public function eventCalendar(WatchlistEventCalendarRequest $request)
    {
        $data = $request->validated();
        $data['event_from'] = array_get($data, 'event_from', Carbon::now()->subYear()->toDateString());
        $data['event_to'] = array_get($data, 'event_to', Carbon::now()->addYear()->toDateString());
        $data['type'] = ['event'];

        $this->repository->applyRequestCriteria($data);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_UPCOMING_EVENTS));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
            ])
            ->get();

        $response = new WatchlistCalendarResource($results);
        $response->withoutWrapping();

        return $response;
    }
}
