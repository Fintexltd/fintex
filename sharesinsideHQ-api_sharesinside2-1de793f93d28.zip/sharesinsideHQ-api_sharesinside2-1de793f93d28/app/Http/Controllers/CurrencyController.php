<?php

namespace App\Http\Controllers;

use App\Entities\Currency;
use App\Http\Requests\CurrencyIndexRequest;
use App\Http\Resources\CurrencyCollection;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{

    /**
     * @param CurrencyIndexRequest $request
     * @return CurrencyCollection
     */
    public function index(CurrencyIndexRequest $request)
    {
        $resource = Currency::orderBy('sort_order', 'ASC')
            ->get();

        return new CurrencyCollection($resource);
    }
}
