<?php

namespace App\Http\Controllers\Traits;

use App\Criteria\QueryColumnCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Entities\Reminder;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

trait WatchlistableControllerTrait
{
    private function roleAllowToSeeUnpublish(array $userRoles, Model $entity)
    {
        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_EDITOR,
        ];

        if (get_class($entity)==Company::class) {
            $allowedRoles[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
        }

        return (bool)array_intersect($allowedRoles, $userRoles);
    }

    private function allowToSeeUnpublish($allowToSeeUnpublish)
    {
        if ($allowToSeeUnpublish) {
            $this->repository->popCriteria(QueryColumnCriteria::class);
        } else {
            $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));
        }
    }

    private function handleReminder(Model $watchlistableEntity, int $userId, array $data)
    {
        if (array_has($data, 'remind') && !$data['remind']) {
            if ($reminder = $watchlistableEntity->reminder) {
                $reminder->delete();
            }
        } else {
            if (array_has($data, 'remind_at')) {
                $reminder = Reminder::query()
                    ->firstOrCreate([
                        'remindable_id' => $watchlistableEntity->id,
                        'remindable_type' => get_class($watchlistableEntity),
                        'user_id' => $userId,
                    ]);

                $reminder->update([
                    'remind_at' => Carbon::createFromTimestamp($data['remind_at']),
                ]);
            }
        }
    }
}
