<?php

namespace App\Http\Controllers\Traits;

use App\User;

trait FundsManagerAndFundRelationControllerTrait
{
    private function prepareCriteriaData(array $data)
    {
        $prepared['search'] = data_get($data, 'search');

        switch ($data['relation']) {
            case 'admin':
                $prepared['relations'] = [
                    User::RELATION_TYPE_PRIMARY_ADMIN,
                    User::RELATION_TYPE_SECONDARY_ADMIN,
                ];
                break;
            default:
                $prepared['relations'] = [
                    $data['relation']
                ];
        }

        return $prepared;
    }
}
