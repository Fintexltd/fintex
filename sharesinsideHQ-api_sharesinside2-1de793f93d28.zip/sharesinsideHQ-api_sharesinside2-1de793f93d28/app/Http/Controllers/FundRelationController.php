<?php

namespace App\Http\Controllers;

use App\Criteria\FundRelationsCriteria;
use App\Entities\Fund;
use App\Http\Controllers\Traits\FundsManagerAndFundRelationControllerTrait;
use App\Http\Requests\RelationNamesRequest;
use App\Http\Requests\UserRelationIndexRequest;
use App\Http\Requests\UserRelationsIndexRequest;
use App\Http\Resources\NameCollection;
use App\Http\Resources\UserRelationCollection;
use App\Http\Resources\RelationFundForUserAdminCollection;
use App\Repositories\RelationRepository;
use App\User;

class FundRelationController extends Controller
{
    use FundsManagerAndFundRelationControllerTrait;

    const DEFAULT_PER_PAGE = 10;

    protected $repository;

    public function __construct(RelationRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param UserRelationIndexRequest
     * @return UserRelationCollection
     */
    public function index(UserRelationIndexRequest $request)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $criteria = new FundRelationsCriteria($request->user(), $request->validated());

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        return new UserRelationCollection($result);
    }

    /**
     * @param RelationNamesRequest
     * @return NameCollection
     */
    public function fundNames(RelationNamesRequest $request)
    {
        $result = $this->repository->getEntityNames($request->user(), $request->validated(), Fund::class);

        $response = new NameCollection($result);
        $response->withoutWrapping();

        return $response;
    }

    public function indexUserRelations(UserRelationsIndexRequest $request, User $user)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $data = $this->prepareCriteriaData($request->validated());

        $criteria = new FundRelationsCriteria($user, $data, true);

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        $response = new RelationFundForUserAdminCollection($result);

        return $response;
    }
}
