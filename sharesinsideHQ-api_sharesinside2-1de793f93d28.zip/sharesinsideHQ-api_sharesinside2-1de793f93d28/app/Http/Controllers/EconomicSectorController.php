<?php

namespace App\Http\Controllers;

use App\Entities\EconomicSector;
use App\Http\Requests\EconomicSectorIndexRequest;
use App\Http\Resources\EconomicSectorCollection;
use Illuminate\Http\Request;

class EconomicSectorController extends Controller
{

    /**
     * @param EconomicSectorIndexRequest $request
     * @return EconomicSectorCollection
     */
    public function index(EconomicSectorIndexRequest $request)
    {
        return new EconomicSectorCollection(EconomicSector::all());
    }
}
