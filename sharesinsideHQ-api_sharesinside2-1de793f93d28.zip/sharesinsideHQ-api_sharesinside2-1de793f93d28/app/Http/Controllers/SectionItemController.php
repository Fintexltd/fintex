<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Entities\SectionItem;
use App\Entities\Startup;
use App\Http\Requests\GalleryItemDeleteRequest;
use App\Http\Requests\GalleryItemStoreRequest;
use App\Http\Requests\GalleryItemUpdateRequest;
use App\Http\Requests\SectionItemIndexRequest;
use App\Http\Resources\AlbumItemCollection;
use App\Http\Resources\MessageResource;
use App\Repositories\SectionItemRepository;
use App\Services\GalleryItemCreator;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class SectionItemController extends Controller
{
    protected $galleryItemCreator;

    protected $repository;

    /**
     * SectionItemController constructor.
     */
    public function __construct(GalleryItemCreator $galleryItemCreator, SectionItemRepository $repository)
    {
        $this->galleryItemCreator = $galleryItemCreator;
        $this->repository = $repository;
    }

    /**
     * @param GalleryItemStoreRequest $request
     * @return MessageResource
     */
    public function store(GalleryItemStoreRequest $request)
    {
        $galleryItem = $this->galleryItemCreator
            ->handleGalleryItemStore($request->all());

        $content = [
            'message' => 'Gallery item was created.',
            'section_item_id' => $galleryItem->id,
        ];

        return new MessageResource($content);
    }

    /**
     * @param GalleryItemUpdateRequest $request
     * @param SectionItem $galleryItem
     * @return MessageResource
     */
    public function update(GalleryItemUpdateRequest $request, SectionItem $galleryItem)
    {
        $this->galleryItemCreator
            ->handleGalleryItemUpdate($galleryItem, $request->all());

        $content = ['message' => 'Gallery item was updated.'];

        return new MessageResource($content);
    }

    /**
     * @param GalleryItemDeleteRequest $request
     * @param SectionItem $galleryItem
     * @return MessageResource
     */
    public function destroy(GalleryItemDeleteRequest $request, SectionItem $galleryItem)
    {
        $this->galleryItemCreator
            ->handleGalleryItemDestroy($galleryItem);
        $content = ['message' => 'Gallery item was deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param SectionItemIndexRequest $request
     * @param Company $company
     * @return AlbumItemCollection
     */
    public function companyIndexAll(SectionItemIndexRequest $request, Company $company)
    {
        return $this->indexAll($request, $company);
    }

    /**
     * @param SectionItemIndexRequest $request
     * @param Startup $startup
     * @return AlbumItemCollection
     */
    public function startupIndexAll(SectionItemIndexRequest $request, Startup $startup)
    {
        return $this->indexAll($request, $startup);
    }

    /**
     * @param SectionItemIndexRequest $request
     * @param Model $entity
     * @return AlbumItemCollection
     */
    public function indexAll(SectionItemIndexRequest $request, Model $entity)
    {
        $results = $this
            ->repository
            ->allForEntity($entity)
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        return new AlbumItemCollection($results);
    }
}
