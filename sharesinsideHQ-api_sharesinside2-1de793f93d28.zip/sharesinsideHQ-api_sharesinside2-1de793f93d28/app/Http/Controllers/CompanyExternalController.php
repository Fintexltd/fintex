<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Criteria\CompanyManagedCriteria;
use App\Criteria\CompanySortByCriteria;
use App\Http\Resources\EntityListCollection;
use App\Http\Requests\CompanyExternalIndexRequest;
use App\Repositories\CompanyRepository;

class CompanyExternalController extends Controller
{
    protected $repository;

    public function __construct(
        CompanyRepository $repository
    )
    {
        $this->repository = $repository;
    }

    /**
     * @param CompanyExternalIndexRequest $request
     * @return EntityListCollection
     */
    public function index(CompanyExternalIndexRequest $request)
    {
        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->pushCriteria(new CompanyManagedCriteria(auth()->user()));
        $this->repository->pushCriteria(new CompanySortByCriteria(CompanySortByCriteria::SORT_NEW_FIRST));

        return new EntityListCollection($this->repository->get());
    }

}
