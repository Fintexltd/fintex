<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Criteria\QueryLimitCriteria;
use App\Criteria\WatchlistAdminRoleCriteria;
use App\Criteria\WatchlistEventDateCriteria;
use App\Criteria\WatchlistFromCriteria;
use App\Criteria\WatchlistItemEntitiableCriteria;
use App\Criteria\WatchlistItemPublicityCriteria;
use App\Criteria\WatchlistItemUserRoleCriteria;
use App\Criteria\WatchlistSortByCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Entities\Company;
use App\Entities\Event;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Startup;
use App\Http\Controllers\Traits\WatchlistableControllerTrait;
use App\Http\Requests\EventAdminIndexRequest;
use App\Http\Requests\EventDeleteRequest;
use App\Http\Requests\EventEditRequest;
use App\Http\Requests\EventIndexRequest;
use App\Http\Requests\EventLatestRequest;
use App\Http\Requests\EventShowRequest;
use App\Http\Requests\EventStoreRequest;
use App\Http\Requests\EventUpcomingRequest;
use App\Http\Requests\EventUpdateRequest;
use App\Http\Resources\EventEditResource;
use App\Http\Resources\EventResource;
use App\Http\Resources\EventsUpcomingCollection;
use App\Http\Resources\MessageResource;
use App\Http\Resources\WatchlistItemCollection;
use App\Repositories\EventRepository;
use App\Repositories\WatchlistItemRepository;
use App\Services\EventCreator;
use App\Services\RoleResolver;
use App\Services\ViewsCounter;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    use WatchlistableControllerTrait;

    protected $eventCreator;
    protected $repository;
    protected $viewsCounter;

    const WATCHLIST_ITEMS_PER_PAGE = 16;
    const UPCOMING_EVENTS_LIMIT = 2;

    public function __construct(EventCreator $eventCreator, EventRepository $repository, ViewsCounter $viewsCounter)
    {
        $this->eventCreator = $eventCreator;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param EventIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
     public function companyIndex(EventIndexRequest $request, Company $entity)
     {
         return self::index($request, $entity);
     }

     /**
      * @param EventIndexRequest $request
      * @param Startup $entity
      * @return WatchlistItemCollection
      */
      public function startupIndex(EventIndexRequest $request, Startup $entity)
      {
          return self::index($request, $entity);
      }

     /**
      * @param EventIndexRequest $request
      * @param Fund $entity
      * @return WatchlistItemCollection
      */
      public function fundIndex(EventIndexRequest $request, Fund $entity)
      {
          return self::index($request, $entity);
      }

      /**
       * @param EventIndexRequest $request
       * @param FundsManager $entity
       * @return WatchlistItemCollection
       */
       public function fundsManagerIndex(EventIndexRequest $request, FundsManager $entity)
       {
           return self::index($request, $entity);
       }

    /**
     * @param EventIndexRequest $request
     * @param Model $entity
     * @return WatchlistItemCollection
     */
    public function index(EventIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', Event::class));

        $this->repository->pushCriteria(new WatchlistItemPublicityCriteria(array_get($request->validated(), 'publicity', [])));

        $data = $request->validated();

        $publishedFromTimestamp = array_get($data, 'from');
        $publishedToTimestamp = array_get($data, 'to');
        $eventDateFrom = array_get($data, 'event_from');
        $eventDateTo = array_get($data, 'event_to');

        if ($publishedFromTimestamp) {
            $this->repository->pushCriteria(new WatchlistFromCriteria($publishedFromTimestamp));
        }

        if ($publishedToTimestamp) {
            $this->repository->pushCriteria(new WatchlistToCriteria($publishedToTimestamp));
        }

        if ($eventDateFrom || $eventDateTo) {
            $this->repository->pushCriteria(new WatchlistEventDateCriteria($eventDateFrom, $eventDateTo));
        }

        $this->repository->pushCriteria(new WatchlistSortByCriteria());

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param EventUpcomingRequest $request
     * @param Company $company
     * @return EventsUpcomingCollection
     */
     public function companyUpcoming(EventUpcomingRequest $request, Company $company)
     {
         return self::upcoming($request, $company);
     }

     /**
      * @param EventUpcomingRequest $request
      * @param Startup $startup
      * @return EventsUpcomingCollection
      */
      public function startupUpcoming(EventUpcomingRequest $request, Startup $startup)
      {
          return self::upcoming($request, $startup);
      }

     /**
      * @param EventUpcomingRequest $request
      * @param Fund $fund
      * @return EventsUpcomingCollection
      */
      public function fundUpcoming(EventUpcomingRequest $request, Fund $fund)
      {
          return self::upcoming($request, $fund);
      }

      /**
       * @param EventUpcomingRequest $request
       * @param FundsManager $fundsManager
       * @return EventsUpcomingCollection
       */
       public function FundsManagerUpcoming(EventUpcomingRequest $request, FundsManager $fundsManager)
       {
           return self::upcoming($request, $fundsManager);
       }

    /**
     * @param EventUpcomingRequest $request
     * @param Model $entity
     * @return EventsUpcomingCollection
     */
    public function upcoming(EventUpcomingRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', Event::class));

        $this->repository->pushCriteria(new WatchlistEventDateCriteria(Carbon::now()->toDateString()));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_UPCOMING_EVENTS));

        $this->repository->pushCriteria(new QueryLimitCriteria(self::UPCOMING_EVENTS_LIMIT));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo',
            ])
            ->get();

        $response = new EventsUpcomingCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param EventAdminIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
    public function companyAdminIndex(EventAdminIndexRequest $request, Company $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param EventAdminIndexRequest $request
     * @param Startup $entity
     * @return WatchlistItemCollection
     */
    public function startupAdminIndex(EventAdminIndexRequest $request, Startup $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param EventAdminIndexRequest $request
     * @param Fund $entity
     * @return WatchlistItemCollection
     */
    public function fundAdminIndex(EventAdminIndexRequest $request, Fund $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param EventAdminIndexRequest $request
     * @param FundsManager $entity
     * @return WatchlistItemCollection
     */
    public function fundsManagerAdminIndex(EventAdminIndexRequest $request, FundsManager $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param EventAdminIndexRequest $request
     * @param Company $company
     * @return WatchlistItemCollection
     */
    public function adminIndex(EventAdminIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $allowToSeeUnpublish = false;

        $roles = RoleResolver::getRoles($request->user(), $entity);
        $allowToSeeUnpublish = $this->roleAllowToSeeUnpublish($roles, $entity);
        $this->allowToSeeUnpublish($allowToSeeUnpublish);

        $this->repository->pushCriteria(new WatchlistAdminRoleCriteria($roles, $entity));

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', Event::class));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_DRAFTS_FIRST_THEN_NEWEST_FIRST));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param EventStoreRequest $request
     * @return MessageResource
     */
    public function store(EventStoreRequest $request)
    {
        $event = $this->eventCreator->handleStoreEvent($request->validated());

        $content = [
            'message' => 'Event created.',
            'id' => $event->id,
        ];

        return new MessageResource($content);
    }

    /**
     * @param EventShowRequest $request
     * @param Event $event
     * @return EventResource
     */
    public function show(EventShowRequest $request, Event $event)
    {
        $event->load([
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'country',
            'attachments',
            'links',
        ]);

        $this->viewsCounter->handleEventView($event, $request->user());

        $response = new EventResource($event);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param EventEditRequest $request
     * @param Event $event
     * @return EventEditResource
     */
    public function edit(EventEditRequest $request, Event $event)
    {
        $event->load([
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'country',
            'attachments',
            'links',
        ]);

        $this->viewsCounter->handleEventView($event, $request->user());

        $response = new EventEditResource($event);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param EventUpdateRequest $request
     * @param Event $event
     * @return MessageResource
     */
    public function update(EventUpdateRequest $request, Event $event)
    {
        $this->eventCreator->handleUpdateEvent($event, $request->validated());

        $content = ['message' => 'Event updated.'];

        return new MessageResource($content);
    }

    /**
     * @param EventDeleteRequest $request
     * @param Event $event
     * @return MessageResource
     */
    public function destroy(EventDeleteRequest $request, Event $event)
    {
        $event->delete();

        $content = ['message' => 'Event deleted.'];

        return new MessageResource($content);
    }

    //TODO: write tests for this part
    /**
     * @param EventLatestRequest $request
     * @param Event $event
     * @return EventsUpcomingCollection
     */
    public function latest(EventLatestRequest $request, Event $event)
    {
        $results = $this->repository->latest($event->id, $request->user());

        return new EventsUpcomingCollection($results);
    }
}
