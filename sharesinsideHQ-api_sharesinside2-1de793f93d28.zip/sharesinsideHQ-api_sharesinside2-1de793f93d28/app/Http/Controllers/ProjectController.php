<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Criteria\WatchlistAdminRoleCriteria;
use App\Criteria\WatchlistExclusionCriteria;
use App\Criteria\WatchlistItemEntitiableCriteria;
use App\Criteria\WatchlistItemPublicityCriteria;
use App\Criteria\WatchlistItemUserRoleCriteria;
use App\Criteria\WatchlistSortByCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Project;
use App\Entities\Startup;
use App\Http\Controllers\Traits\WatchlistableControllerTrait;
use App\Http\Requests\ProjectAdminIndexRequest;
use App\Http\Requests\ProjectDeleteRequest;
use App\Http\Requests\ProjectEditRequest;
use App\Http\Requests\ProjectIndexRequest;
use App\Http\Requests\ProjectLatestRequest;
use App\Http\Requests\ProjectShowRequest;
use App\Http\Requests\ProjectShowSocialShareRequest;
use App\Http\Requests\ProjectLatestSocialShareRequest;
use App\Http\Requests\ProjectStoreRequest;
use App\Http\Requests\ProjectUpdateRequest;
use App\Http\Requests\SocialShareKeyRequest;
use App\Http\Resources\MessageResource;
use App\Http\Resources\ProjectEditResource;
use App\Http\Resources\ProjectResource;
use App\Http\Resources\WatchlistItemCollection;
use App\Http\Resources\SocialShareKeyResource;
use App\Repositories\ProjectRepository;
use App\Repositories\WatchlistItemRepository;
use App\Services\ProjectCreator;
use App\Services\RoleResolver;
use App\Services\ViewsCounter;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ProjectController extends Controller
{
    use WatchlistableControllerTrait;

    protected $newsCreator;
    protected $repository;
    protected $viewsCounter;

    const WATCHLIST_ITEMS_PER_PAGE = 16;

    public function __construct(ProjectCreator $projectCreator, ProjectRepository $repository, ViewsCounter $viewsCounter)
    {
        $this->projectCreator = $projectCreator;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param ProjectIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
     public function companyIndex(ProjectIndexRequest $request, Company $entity)
     {
         return self::index($request, $entity);
     }

     /**
      * @param ProjectIndexRequest $request
      * @param Startup $entity
      * @return WatchlistItemCollection
      */
      public function startupIndex(ProjectIndexRequest $request, Startup $entity)
      {
          return self::index($request, $entity);
      }

     /**
      * @param ProjectIndexRequest $request
      * @param Fund $entity
      * @return WatchlistItemCollection
      */
      public function fundIndex(ProjectIndexRequest $request, Fund $entity)
      {
          return self::index($request, $entity);
      }

      /**
       * @param ProjectIndexRequest $request
       * @param FundsManager $entity
       * @return WatchlistItemCollection
       */
       public function fundsManagerIndex(ProjectIndexRequest $request, FundsManager $entity)
       {
           return self::index($request, $entity);
       }

    /**
     * @param ProjectIndexRequest $request
     * @param Model $entity
     * @return WatchlistItemCollection
     */
    private function index(ProjectIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', Project::class));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemPublicityCriteria(array_get($request->validated(), 'publicity', [])));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_DRAFTS_FIRST_THEN_NEWEST_FIRST));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param ProjectAdminIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
    public function companyAdminIndex(ProjectAdminIndexRequest $request, Company $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param ProjectAdminIndexRequest $request
     * @param Startup $entity
     * @return WatchlistItemCollection
     */
    public function startupAdminIndex(ProjectAdminIndexRequest $request, Startup $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param ProjectAdminIndexRequest $request
     * @param Fund $entity
     * @return WatchlistItemCollection
     */
    public function fundAdminIndex(ProjectAdminIndexRequest $request, Fund $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param ProjectAdminIndexRequest $request
     * @param FundsManager $entity
     * @return WatchlistItemCollection
     */
    public function fundsManagerAdminIndex(ProjectAdminIndexRequest $request, FundsManager $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param ProjectAdminIndexRequest $request
     * @param Model $entity
     * @return WatchlistItemCollection
     */
    private function adminIndex(ProjectAdminIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $allowToSeeUnpublish = false;

        $roles = RoleResolver::getRoles($request->user(), $entity);
        $allowToSeeUnpublish = $this->roleAllowToSeeUnpublish($roles, $entity);
        $this->allowToSeeUnpublish($allowToSeeUnpublish);

        $this->repository->pushCriteria(new WatchlistAdminRoleCriteria($roles, $entity));

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', Project::class));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_DEFAULT_WITH_UNPUBLISHED));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param ProjectStoreRequest $request
     * @return MessageResource
     */
    public function store(ProjectStoreRequest $request)
    {
        $project = $this->projectCreator->handleStoreProject($request->validated());

        $params = $request->only('remind', 'remind_at');
        $userId = $request->user()->id;
        $this->handleReminder($project, $userId, $params);

        $content = [
            'message' => 'Project created.',
            'id' => data_get($project, 'id'),
        ];

        return new MessageResource($content);
    }

    /**
     * @param ProjectEditRequest $request
     * @param Project $project
     * @return ProjectEditResource
     */
    public function edit(ProjectEditRequest $request, Project $project)
    {
        $project->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
            'watchlistItem.excluded',
            'watchlistItem.excluded.country',
        ]);

        $this->viewsCounter->handleProjectView($project, $request->user());

        $response = new ProjectEditResource($project);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param ProjectShowRequest $request
     * @param Project $project
     * @return ProjectResource
     */
    public function show(ProjectShowRequest $request, Project $project)
    {
        $project->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
        ]);

        $this->viewsCounter->handleProjectView($project, $request->user());

        $response = new ProjectResource($project);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param ProjectShowSocialShareRequest $request
     * @param Project $project
     * @return ProjectResource
     */
    public function showSocialShare(ProjectShowSocialShareRequest $request, Project $project)
    {
        $project->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
        ]);

        $this->viewsCounter->handleSocialShareProjectView($project);

        $response = new ProjectResource($project);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param ProjectDeleteRequest $request
     * @param Project $project
     * @return MessageResource
     */
    public function destroy(ProjectDeleteRequest $request, Project $project)
    {
        $project->delete();

        $content = ['message' => 'Project deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param ProjectUpdateRequest $request
     * @param Project $project
     * @return MessageResource
     */
    public function update(ProjectUpdateRequest $request, Project $project)
    {
        $this->projectCreator->handleUpdateProject($project, $request->validated());

        $params = $request->only('remind', 'remind_at');
        $userId = $request->user()->id;
        $this->handleReminder($project, $userId, $params);

        $content = [
            'message' => 'Project updated.',
            'id' => $project->id,
        ];

        return new MessageResource($content);
    }

    /**
     * @param ProjectLatestRequest $request
     * @param Project $project
     * @return WatchlistItemCollection
     */
    public function latest(ProjectLatestRequest $request, Project $project)
    {
        $results = $this->repository->latest($project->id, $request->user());
        $response = new WatchlistItemCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param ProjectLatestSocialShareRequest $request
     * @param Project $project
     * @return WatchlistItemCollection
     */
    public function latestSocialShare(ProjectLatestSocialShareRequest $request, Project $project)
    {
        $results = $this->repository->latestSocialShare($project->id);
        $response = new WatchlistItemCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param SocialShareKeyRequest $request
     * @param Project $project
     * @return SocialShareKeyResource
     */
    public function checkSocialShareKey(SocialShareKeyRequest $request, Project $project)
    {
        if($project->watchlistItem->social_share_key===$request->route('shareKey'))
        {
            return new SocialShareKeyResource($project);
        }

        abort(404);
    }
}
