<?php

namespace App\Http\Controllers;

use App\Http\Requests\ExchangeIndexRequest;
use App\Http\Resources\ExchangeCollection;
use App\Repositories\SymbolRepository;
use Illuminate\Http\Request;

class ExchangeController extends Controller
{
    protected $symbolRepository;

    public function __construct(SymbolRepository $symbolRepository)
    {
        $this->symbolRepository = $symbolRepository;
    }

    /**
     * @param ExchangeIndexRequest $request
     * @return ExchangeCollection
     */
    public function index(ExchangeIndexRequest $request)
    {
        return new ExchangeCollection($this->symbolRepository->getExchanges());
    }
}
