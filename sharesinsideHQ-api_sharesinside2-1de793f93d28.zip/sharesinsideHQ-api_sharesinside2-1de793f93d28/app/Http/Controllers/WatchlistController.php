<?php

namespace App\Http\Controllers;

use App\Criteria\WatchlistDemoCriteria;
use App\Criteria\QueryLimitCriteria;
use App\Criteria\ActiveEntitiesCriteria;
use App\Criteria\WatchlistEventLocationCriteria;
use App\Criteria\WatchlistExclusionCriteria;
use App\Criteria\WatchlistItemTypeCriteria;
use App\Criteria\WatchlistItemEntitiableTypesCriteria;
use App\Criteria\WatchlistItemUserRoleCriteria;
use App\Criteria\WatchlistSortByCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Criteria\WatchlistUniqueTitlesCriteria;
use App\Entities\Event;
use App\Http\Requests\EventTypeaheadRequest;
use App\Http\Requests\WatchlistEventCalendarRequest;
use App\Http\Requests\WatchlistIndexRequest;
use App\Http\Requests\WatchlistSidebarRequest;
use App\Http\Resources\EventTypeaheadCollection;
use App\Http\Resources\WatchlistCalendarResource;
use App\Http\Resources\WatchlistItemCollection;
use App\Repositories\WatchlistItemRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;

class WatchlistController extends Controller
{
    protected $repository;

    const WATCHLIST_ITEMS_PER_PAGE = 16;

    const WATCHLIST_SIDEBAR_ITEMS_PER_PAGE = 5;

    public function __construct(WatchlistItemRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param WatchlistIndexRequest
     * @return WatchlistItemCollection
     */
    public function index(WatchlistIndexRequest $request)
    {
        $this->repository->applyRequestCriteria($request->validated());

        $sortBy = request()->get('sort_by');

        $itemsPerPage = (int)($request->get('per_page') ?: self::WATCHLIST_ITEMS_PER_PAGE);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new WatchlistSortByCriteria($sortBy));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'urlLinks',
                'videoLinks',
                'entitiable',
                'entitiable.logo',
            ])
            ->paginate($itemsPerPage, ['*']);

        return new WatchlistItemCollection($results);
    }

    public function events(WatchlistIndexRequest $request)
    {
        $this->repository->pushCriteria(new WatchlistItemTypeCriteria([Event::class]));

        $location = $request->get('location');
        if ($location) {
            $this->repository->pushCriteria(new WatchlistEventLocationCriteria($location));
        }

        $this->repository->applyRequestCriteria($request->validated());

        $itemsPerPage = (int)($request->get('per_page') ?: self::WATCHLIST_ITEMS_PER_PAGE);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_UPCOMING_EVENTS));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'urlLinks',
                'videoLinks',
                'entitiable',
                'entitiable.logo',
            ])
            ->paginate($itemsPerPage, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param EventTypeaheadRequest
     * @return EventTypeaheadCollection
     */
    public function eventsTypeahead(EventTypeaheadRequest $request)
    {
        $this->repository->pushCriteria(new WatchlistItemTypeCriteria([Event::class]));

        $location = $request->get('location');
        if ($location) {
            $this->repository->pushCriteria(new WatchlistEventLocationCriteria($location));
        }

        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new QueryLimitCriteria(self::WATCHLIST_ITEMS_PER_PAGE));

        $this->repository->pushCriteria(new WatchlistUniqueTitlesCriteria(self::WATCHLIST_ITEMS_PER_PAGE));

//        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_UPCOMING_EVENTS));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
            ])
            ->get()
            ->pluck('title');

        return new EventTypeaheadCollection($results);
    }

    /**
     * @param WatchlistSidebarRequest
     * @return WatchlistItemCollection
     */
    public function sidebar(WatchlistSidebarRequest $request)
    {
        $itemsPerPage = (int)($request->get('per_page') ?? self::WATCHLIST_SIDEBAR_ITEMS_PER_PAGE);

        $this->repository->pushCriteria(new WatchlistDemoCriteria($request->user()));

        $this->repository->pushCriteria(new ActiveEntitiesCriteria());

        if ($entitiableTypes = data_get($request, 'entitiable_types')) {
            $this->repository->pushCriteria(new WatchlistItemEntitiableTypesCriteria($entitiableTypes));
        }

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new WatchlistSortByCriteria());

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'urlLinks',
                'videoLinks',
                'entitiable',
                'entitiable.logo',
            ])
            ->paginate($itemsPerPage, ['*']);

        return new WatchlistItemCollection($results);
    }
}
