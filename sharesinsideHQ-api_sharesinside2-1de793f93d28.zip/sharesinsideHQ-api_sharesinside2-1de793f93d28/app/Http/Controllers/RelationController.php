<?php

namespace App\Http\Controllers;

use App\Http\Requests\RelationDeleteRequest;
use App\Services\RelationService;

class RelationController extends Controller
{
    protected $service;

    public function __construct(RelationService $service)
    {
        $this->service = $service;
    }

    /**
     * @param RelationDeleteRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(RelationDeleteRequest $request)
    {
        $this->service->handleResign($request->validated());

        return response()->json(['message' => 'relation deleted.'], 200);
    }
}
