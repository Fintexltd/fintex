<?php

namespace App\Http\Controllers;


use App\Http\Requests\ContactMessageRequest;
use App\Http\Resources\MessageResource;
use App\Mail\ContactMessage;
use Illuminate\Support\Facades\Mail;

class ContactMessageController extends Controller
{
    /**
     * @param ContactMessageRequest $request
     * @return MessageResource
     */
    public function send(ContactMessageRequest $request)
    {
        Mail::to(config('mail.contact_address'))->send(new ContactMessage($request->get('email'), $request->get('name'), $request->get('message')));
        $content = ['message' => 'Message has been sent.'];

        return new MessageResource($content);
    }
}
