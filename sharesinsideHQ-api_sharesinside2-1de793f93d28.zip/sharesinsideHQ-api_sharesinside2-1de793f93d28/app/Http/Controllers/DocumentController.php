<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Entities\Document;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Startup;
use App\Http\Requests\DocumentDeleteRequest;
use App\Http\Requests\DocumentIndexRequest;
use App\Http\Requests\DocumentRecentRequest;
use App\Http\Requests\DocumentStoreRequest;
use App\Http\Requests\DocumentUpdateRequest;
use App\Http\Resources\DocumentCollection;
use App\Http\Resources\DocumentRecentCollection;
use App\Http\Resources\DocumentResource;
use App\Http\Resources\MessageResource;
use App\Repositories\DocumentRepository;
use App\Services\DocumentCreator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class DocumentController extends Controller
{
    protected $creator;
    protected $repository;

    const ITEMS_PER_PAGE = 10;

    public function __construct(DocumentCreator $creator, DocumentRepository $repository)
    {
        $this->creator = $creator;
        $this->repository = $repository;
    }

    /**
     * @param DocumentRecentRequest $request
     * @param Startup $startup
     * @return DocumentRecentCollection
     */
    public function startupRecent(DocumentRecentRequest $request, Startup $startup)
    {
        return $this->recent($request, $startup);
    }

    /**
     * @param DocumentRecentRequest $request
     * @param FundsManager $fundsManager
     * @return DocumentRecentCollection
     */
    public function fundsManagerRecent(DocumentRecentRequest $request, FundsManager $fundsManager)
    {
        return $this->recent($request, $fundsManager);
    }

    /**
     * @param DocumentRecentRequest $request
     * @param Fund $fund
     * @return DocumentRecentCollection
     */
    public function fundRecent(DocumentRecentRequest $request, Fund $fund)
    {
        return $this->recent($request, $fund);
    }

    /**
     * @param DocumentRecentRequest $request
     * @param Model $entity
     * @return DocumentRecentCollection
     */
    public function recent(DocumentRecentRequest $request, Model $entity)
    {
        $data = $this->repository->getLatest($entity);

        $resource = new DocumentRecentCollection($data);

        $resource->withoutWrapping();

        return $resource;
    }

    /**
     * @param DocumentIndexRequest $request
     * @param Startup $startup
     * @return DocumentCollection
     */
    public function startupIndex(DocumentIndexRequest $request, Startup $startup)
    {
        return $this->index($request, $startup);
    }

    /**
     * @param DocumentIndexRequest $request
     * @param FundsManager $fundsManager
     * @return DocumentCollection
     */
    public function fundsManagerIndex(DocumentIndexRequest $request, FundsManager $fundsManager)
    {
        return $this->index($request, $fundsManager);
    }

    /**
     * @param DocumentIndexRequest $request
     * @param Fund $fund
     * @return DocumentCollection
     */
    public function fundIndex(DocumentIndexRequest $request, Fund $fund)
    {
        return $this->index($request, $fund);
    }

    /**
     * @param DocumentIndexRequest $request
     * @param Model $entity
     * @return DocumentCollection
     */
    public function index(DocumentIndexRequest $request, Model $entity)
    {
        $sectionId = $request->get('section_id');

        $this->repository->pushCriteria(new QueryColumnCriteria('section_id', $sectionId));

        $results = $this
            ->repository
            ->with([
                'attachment',
            ])
            ->orderBy('created_at', 'desc')
            ->paginate(self::ITEMS_PER_PAGE, ['*']);

        return new DocumentCollection($results);
    }

    /**
     * @param DocumentStoreRequest $request
     * @return DocumentResource
     */
    public function store(DocumentStoreRequest $request)
    {
        $resource = $this->creator->handleStore($request->all());

        $response = new DocumentResource($resource);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param HistoricalDataUpdateRequest $request
     * @param HistoricalDataPiece $document
     * @return DocumentResource
     */
    public function update(DocumentUpdateRequest $request, Document $document)
    {
        $resource = $this->creator->handleUpdate($document, $request->all());

        $response = new DocumentResource($resource);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param HistoricalDataDeleteRequest $request
     * @param HistoricalDataPiece $document
     * @return MessageResource
     */
    public function destroy(DocumentDeleteRequest $request, Document $document)
    {
        $document->delete();

        $content = ['message' => 'Document deleted.'];

        return new MessageResource($content);
    }
}
