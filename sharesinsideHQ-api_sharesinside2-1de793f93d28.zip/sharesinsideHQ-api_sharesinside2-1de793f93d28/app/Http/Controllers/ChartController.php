<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Http\Resources\ChartCollection;
use App\Http\Requests\ChartsRequest;
use Illuminate\Http\Request;

class ChartsController extends Controller
{
    /**
     * @param ChartsRequest
     * @return ChartCollection
     */
    public function index(ChartsRequest $request, Company $company)
    {
        $company->load([
            'symbols',
            'symbols.stockOhlcYear'
        ]);

        $resource = new ChartCollection($company->symbols);
        $resource->withoutWrapping();

        return $resource;
    }
}
