<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\SeCache;
use App\Http\Resources\SeChartCollection;
use App\Http\Requests\SeCompanyChartsRequest;
use App\Http\Requests\SeFundChartsRequest;
use App\Http\Requests\SeSectorIndexRequest;
use App\Http\Requests\SeSearchForSymbolRequest;
use App\Services\SeProvider;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Database\Eloquent\Model;

class SeController extends Controller
{
    /**
     * @param SeCompanyChartsRequest $request
     * @param Company $company
     * @return SeChartCollection
     */
    public function companyChart(SeCompanyChartsRequest $request, Company $company)
    {
        return $this->chart($request, $company);
    }

    /**
     * @param SeFundChartsRequest $request
     * @param Fund $fund
     * @return SeChartCollection
     */
    public function fundChart(SeFundChartsRequest $request, Fund $fund)
    {
        return $this->chart($request, $fund);
    }

    /**
     * @param FormRequest $request
     * @param Model $entity
     * @return SeChartCollection
     */
    public function chart(FormRequest $request, Model $entity)
    {
        $entity->load([
            'seSymbols',
            'seSymbols.seOhlcChart'
        ]);

        $resource = new SeChartCollection($entity->seSymbols);
        $resource->withoutWrapping();

        return $resource;
    }

    /**
     * @param SeSearchForSymbolRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function searchForSymbol(SeProvider $seProvider, SeSearchForSymbolRequest $request)
    {
        return response()->json($seProvider->searchForSymbol($request->input('search'), $request->input('type')));
    }

    /**
     * @param SeSectorIndexRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sectors(SeSectorIndexRequest $request)
    {
        $sectors = SeCache::where('key', 'sectors')->first();

        try{
            $response = $sectors ? \GuzzleHttp\json_decode($sectors->value) : [];
        } catch (\Exception $e){
            $response = [];
        }

        return response()->json($response);
    }
}
