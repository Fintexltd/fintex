<?php

namespace App\Http\Controllers;

use App\Http\Requests\NewsExternalStoreRequest;

class NewsExternalController extends NewsController
{
    /**
     * @param NewsExternalStoreRequest $request
     * @return MessageResource
     */
    public function storeNews(NewsExternalStoreRequest $request)
    {
        return $this->storeData($request);
    }
}
