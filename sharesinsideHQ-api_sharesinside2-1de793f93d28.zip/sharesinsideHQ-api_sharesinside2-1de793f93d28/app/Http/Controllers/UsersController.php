<?php

namespace App\Http\Controllers;

use App\Criteria\QueryOrCriteria;
//use App\Criteria\UserCompanyCriteria;
use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Entities\Startup;
use App\Events\SendEmailEvent;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Requests\AdminBlockShareholderRequest;
use App\Http\Requests\AdminDeleteUserRequest;
use App\Http\Requests\AdminResetPasswordRequest;
use App\Http\Requests\AdminRolesInfoRequest;
use App\Http\Requests\AdminRolesUpdateRequest;
use App\Http\Requests\ChangeEmailRequest;
use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\ChangeUsernameRequest;
use App\Http\Requests\ChangeUserSettingsRequest;
use App\Http\Requests\DeleteUserRequest;
//use App\Http\Requests\DomesticAdminUpdateRequest;
use App\Http\Requests\ManageCompanyRoleRequest;
use App\Http\Requests\ManageFundsRoleRequest;
use App\Http\Requests\ManageFundsManagerRoleRequest;
use App\Http\Requests\ManageStartupRoleRequest;
use App\Http\Requests\RemoveDomesticAdminRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Requests\UserIndexRequest;
use App\Http\Requests\UserMeRequest;
use App\Http\Resources\AdminRolesInfoResource;
use App\Http\Resources\MessageResource;
//use App\Http\Resources\UserCompanyRelatedCollection;
use App\Http\Resources\UserManageListCollection;
use App\Http\Resources\UserManageListResource;
use App\Http\Resources\UserResource;
use App\Mail\OrphanedCompanies;
use App\Mail\OrphanedFunds;
use App\Mail\OrphanedFundsManagers;
use App\Mail\OrphanedStartups;
use App\Repositories\UserRepository;
use App\Services\CompaniesAdminManager;
use App\Services\RoleResolver;
use App\Services\DeleteAndForgetService;
use App\Services\AdminRolesService;
use App\Services\EmailChangeService;
use App\Services\FundsAdminManager;
use App\Services\FundsManagersAdminManager;
use App\Services\PasswordReset;
use App\Services\StartupsAdminManager;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UsersController extends Controller
{
    protected $companiesAdminManager;
    protected $startupsAdminManager;
    protected $fundsManagersAdminManager;
    protected $fundsAdminManager;
    protected $repository;
    protected $adminRolesService;

    const ITEMS_PER_PAGE = 10;

    public function __construct(
        CompaniesAdminManager $companiesAdminManager,
        StartupsAdminManager $startupsAdminManager,
        FundsManagersAdminManager $fundsManagersAdminManager,
        FundsAdminManager $fundsAdminManager,
        AdminRolesService $adminRolesService,
        UserRepository $repository)
    {
        $this->companiesAdminManager = $companiesAdminManager;
        $this->startupsAdminManager = $startupsAdminManager;
        $this->fundsManagersAdminManager = $fundsManagersAdminManager;
        $this->fundsAdminManager = $fundsAdminManager;
        $this->adminRolesService = $adminRolesService;
        $this->repository = $repository;
    }


    /**
     * @param UserMeRequest $request
     * @return UserResource
     */
    public function me(UserMeRequest $request)
    {
        $user = $request->user();

        $relationsForLoad = [
            'country',
        ];

        if ($request->get('relations')) {
            $relationsForLoad[] = 'relations';
            $relationsForLoad[] = 'relations.related';
        }

        $user->load($relationsForLoad);

        $response = new UserResource($user);
        $response->withoutWrapping();

        return $response;
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $user->update(
            array_filter(
                $request->validated(),
                function ($item) {
                    return !empty($item);
                })
        );

        return response()->json(['message' => 'User updated.']);
    }

//    public function indexCompanyRelated(UserIndexRequest $request)
//    {
//        $perPage = $request->get('per_page', self::ITEMS_PER_PAGE);
//
//        if (!RoleResolver::isGlobalAdmin($request->user())) {
//            $companies = $request->user()->managedCompanies->pluck('id')->all();
//            $this->repository->pushCriteria(new UserCompanyCriteria($companies));
//        }
//
//        $this->repository->applyRequestCriteria($request->validated());
//
//        $results = $this
//            ->repository
//            ->orderBy('created_at', 'desc')
//            ->with([
//                'country',
//            ])
//            ->paginate($perPage, ['*']);
//
//        $response = new UserCompanyRelatedCollection($results);
//
//        return $response;
//    }

    /**
     * @param UserIndexRequest $request
     * @return UserManageListCollection
     */
    public function index(UserIndexRequest $request)
    {
        $perPage = $request->get('per_page', self::ITEMS_PER_PAGE);

        $this->repository->applyRequestCriteria($request->validated());

        $results = $this
            ->repository
            ->orderBy('created_at', 'desc')
            ->with([
                'country',
                'relations',
                'relations.related',
            ])
            ->paginate($perPage, ['*']);

        return new UserManageListCollection($results);
    }

    /**
     * @param ManageCompanyRoleRequest $request
     * @return MessageResource
     */
    public function manageCompanyRole(ManageCompanyRoleRequest $request)
    {
        $company = $request->company;
        $user = $request->getCandidate();
        $action = $request->get('action');

        $this->companiesAdminManager->handleUserRelation($user, $company, $action);

        $response = $this->companiesAdminManager->prepareResponse($action);

        return response()->json($response['payload'], $response['code']);
    }

    /**
     * @param ManageStartupRoleRequest $request
     * @return MessageResource
     */
    public function manageStartupRole(ManageStartupRoleRequest $request, Startup $startup)
    {
        $user = $request->getCandidate();
        $action = $request->get('action');

        $this->startupsAdminManager->handleUserRelation($user, $startup, $action);

        $response = $this->startupsAdminManager->prepareResponse($action);

        return response()->json($response['payload'], $response['code']);
    }

    /**
     * @param ManageFundsManagerRoleRequest $request
     * @return MessageResource
     */
    public function manageFundsManagerRole(ManageFundsManagerRoleRequest $request, FundsManager $fundsManager)
    {
        $user = $request->getCandidate();
        $action = $request->get('action');

        $this->fundsManagersAdminManager->handleUserRelation($user, $fundsManager, $action);

        $response = $this->fundsManagersAdminManager->prepareResponse($action);

        return response()->json($response['payload'], $response['code']);
    }

    /**
     * @param ManageFundsRoleRequest $request
     * @return MessageResource
     */
    public function manageFundsRole(ManageFundsRoleRequest $request, FundsManager $fundsManager)
    {
        $user = $request->getCandidate();
        $action = $request->get('action');

        if ($request->input('fund_ids') && count($request->input('fund_ids'))) {
            $this->fundsAdminManager->handleUserRelation($user, $action, $request->input('fund_ids'));
        }

        if($request->input('assign_to_funds_manager')) {
            $this->fundsManagersAdminManager->handleUserRelation($user, $fundsManager, $action);
        }

        $response = $this->fundsAdminManager->prepareResponse($action);

        return response()->json($response['payload'], $response['code']);
    }

    /**
     * @param ChangePasswordRequest $request
     * @return MessageResource
     */
    public function changePassword(ChangePasswordRequest $request)
    {
        $user = $request->user();
        $user->password = Hash::make($request->get('new_password'));
        $user->save();

        $user->tokens
            ->each(function ($token) {
                $token->revoke();
            });

        $token = $user->createToken(null);

        $content = [
            "token_type" => "Bearer",
            "expires_in" => LoginController::DEFAULT_SOCIALITE_EXPIRES_IN,
            "access_token" => $token->accessToken,
            "refresh_token" => null,
            "message" => "Password has been changed"
        ];

        return new MessageResource($content);
    }

    /**
     * @param ChangeEmailRequest $request
     * @return MessageResource
     */
    public function changeEmail(ChangeEmailRequest $request)
    {
        EmailChangeService::requestChange(Auth::user(), $request->get('new_email'));

        $content = ['message' => 'Email change has been requested'];

        return new MessageResource($content);
    }

    public function changeEmailConfirm(string $token)
    {
        if (!empty($token)) {
            EmailChangeService::clearExpiredTokens();
            if (EmailChangeService::changeByToken($token)) {
                return redirect()->away(config('app.params.web_base_url') . '/email-change/confirm');
            }
        }

        return redirect()->away(config('app.params.web_base_url') . '/email-change/failure');
    }

    /**
     * @param ChangeUsernameRequest $request
     * @return MessageResource
     */
    public function changeUsername(ChangeUsernameRequest $request)
    {
        $user = Auth::user();
        $user->name = $request->get('new_username');
        $user->save();

        $content = ['message' => 'Username has been changed'];

        return new MessageResource($content);
    }

    /**
     * @param ChangeUserSettingsRequest $request
     * @return MessageResource
     */
    public function changeUserSettings(ChangeUserSettingsRequest $request)
    {
        $user = $request->user();

        if (data_get($request->validated(), 'new_password')) {
            $user->password = Hash::make($request->get('new_password'));
            $user->save();

            $user->tokens
                ->each(function ($token) {
                    $token->revoke();
                });

            $token = $user->createToken(null);

            $data = [
                "token_type" => "Bearer",
                "expires_in" => LoginController::DEFAULT_SOCIALITE_EXPIRES_IN,
                "access_token" => $token->accessToken,
                "refresh_token" => null,
                "message" => "Password has been changed"
            ];
        }

        if (data_get($request->validated(), 'new_email')) {
            EmailChangeService::requestChange($user, $request->get('new_email'));
        }

        if (data_get($request->validated(), 'new_username')) {
            $user->name = $request->get('new_username');
            $user->save();
        }

        $data['message'] = 'Your auth data was changed.';

        return new MessageResource($data);
    }

    /**
     * @param DeleteUserRequest $request
     * @return MessageResource
     */
    public function delete(DeleteUserRequest $request)
    {
        $user = $request->user();

        if (
            RoleResolver::isPrimaryInAny(Company::class, $user) ||
            RoleResolver::isPrimaryInAny(Startup::class, $user) ||
            RoleResolver::isPrimaryInAny(Fund::class, $user) ||
            RoleResolver::isPrimaryInAny(FundsManager::class, $user)
        ) {
            $this->informAdmins($user);
        }

        DeleteAndForgetService::deleteUser($user);

        $content = ['message' => 'User has been deleted and signed out.'];

        return new MessageResource($content);
    }

    public function adminResetPassword(AdminResetPasswordRequest $request, User $user, PasswordReset $passwordReset)
    {
        $passwordReset->setRandomPassword($user);

        $content = ['message' => 'User password has been changed'];

        return new MessageResource($content);
    }

    public function adminBlockShareholder(AdminBlockShareholderRequest $request, User $user)
    {
        Relation::create([
            'user_id' => $user->id,
            'type' => RelationInterface::RELATION_TYPE_BLOCK_AS_SHAREHOLDER,
        ]);

        $content = ['message' => 'User sahreholder requests were blocked'];

        return new MessageResource($content);
    }

    public function adminDelete(AdminDeleteUserRequest $request)
    {
        User::find(data_get($request->validated(), 'users', []))
            ->each(function ($user) {
                DeleteAndForgetService::deleteUser($user);
            });

        $content = ['message' => 'Users have been deleted and signed out.'];

        return new MessageResource($content);
    }

    //TODO: remove this:
    /**
     * @param DomesticAdminUpdateRequest $request
     * @return MessageResource
     */
    /*public function domesticAdmin(DomesticAdminUpdateRequest $request)
    {
        $user = User::query()
            ->where('email', $request->get('email'))
            ->first();
        $countryIds = $request->get('country_ids');

        $payload = $this->service->sync($user, $countryIds);

        return new MessageResource($payload);
    }*/

    /**
     * @param AdminRolesInfoRequest $request
     * @return AdminRolesInfoResource
     */
    public function adminRolesInfo(AdminRolesInfoRequest $request)
    {
        $rolesInfo = $this->adminRolesService->rolesInfo($request->validated());

        return new AdminRolesInfoResource($rolesInfo);
    }

    /**
     * @param AdminRolesUpdateRequest $request
     * @return MessageResource
     */
    public function adminRolesUpdate(AdminRolesUpdateRequest $request)
    {
        $this->adminRolesService->rolesUpdate($request->validated());

        return new MessageResource([
            'message' => 'Admin roles updated'
        ]);
    }

    private function informAdmins(User $user)
    {
        $companyIds = $this->getPrimaryAdminRelatedEntityIds(Company::class, $user);
        $fundsManagerIds = $this->getPrimaryAdminRelatedEntityIds(FundsManager::class, $user);
        $fundIds = $this->getPrimaryAdminRelatedEntityIds(Fund::class, $user);
        $startupIds = $this->getPrimaryAdminRelatedEntityIds(Startup::class, $user);

        $admins = Relation::query()
            ->where('type', RelationInterface::RELATION_TYPE_GLOBAL_ADMIN)
            ->get(['user_id'])
            ->pluck('user_id')
            ->all();

        $emails = User::query()
            ->find($admins)
            ->pluck('email')
            ->filter()
            ->all();

        if(count($companyIds)) {
            $mailableCompanies = new OrphanedCompanies($companyIds);
            event(new SendEmailEvent($emails, $mailableCompanies));
        }

        if(count($fundsManagerIds)) {
            $mailableFundsManagers = new OrphanedFundsManagers($fundsManagerIds);
            event(new SendEmailEvent($emails, $mailableFundsManagers));
        }

        if(count($fundIds)) {
            $mailableFunds = new OrphanedFunds($fundIds);
            event(new SendEmailEvent($emails, $mailableFunds));
        }

        if(count($startupIds)) {
            $mailableStartups = new OrphanedStartups($startupIds);
            event(new SendEmailEvent($emails, $mailableStartups));
        }
    }

    private function getPrimaryAdminRelatedEntityIds(string $entityClass, User $user)
    {
        return Relation::query()
            ->where('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
            ->where('user_id', $user->id)
            ->where('related_type', $entityClass)
            ->get(['related_id'])
            ->pluck('related_id')
            ->all();
    }
}
