<?php

namespace App\Http\Controllers;

use App\Entities\JobOffer;
use App\Entities\SecurityToken;
use App\Http\Requests\JobOfferDeleteRequest;
use App\Http\Requests\JobOfferFormRequest;
use App\Http\Requests\JobOfferIndexRequest;
use App\Http\Requests\JobOfferShowRequest;
use App\Http\Requests\JobOfferStoreRequest;
use App\Http\Requests\JobOfferUpdateRequest;
use App\Http\Resources\JobOfferResource;
use App\Http\Resources\JobOfferTileCollection;
use App\Http\Resources\MessageResource;
use App\Mail\JobOfferReply;
use App\Repositories\JobOfferRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class JobOfferController extends Controller
{
    const PER_PAGE = 10;

    protected $repository;

    public function __construct(JobOfferRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param JobOfferIndexRequest $request
     * @return JobOfferTileCollection
     */
    public function index(JobOfferIndexRequest $request)
    {
        $results = $this->repository
            ->applyRequestCriteria($request->validated())
            ->with(['country'])
            ->paginate(self::PER_PAGE, ['*']);

        return new JobOfferTileCollection($results);
    }

    /**
     * @param JobOfferShowRequest $request
     * @param JobOffer $jobOffer
     * @return JobOfferResource
     */
    public function show(JobOfferShowRequest $request, JobOffer $jobOffer)
    {
        return new JobOfferResource($jobOffer);
    }

    /**
     * @param JobOfferStoreRequest $request
     * @return MessageResource
     */
    public function store(JobOfferStoreRequest $request)
    {
        $data = array_map($this->getArrayEncodeMapFunction(), $request->validated());

        $jobOffer = JobOffer::create($data);

        $response = [
            'message' => 'Job offer created',
            'job_offer_id' => $jobOffer->id,
        ];

        return new MessageResource($response);
    }

    /**
     * @param JobOfferUpdateRequest $request
     * @param JobOffer $jobOffer
     * @return MessageResource
     */
    public function update(JobOfferUpdateRequest $request, JobOffer $jobOffer)
    {
        $data = array_map($this->getArrayEncodeMapFunction(), $request->validated());

        $jobOffer->update($data);

        $response = ['message' => 'Job offer updated'];

        return new MessageResource($response);
    }

    /**
     * @param JobOfferDeleteRequest $request
     * @param JobOffer $jobOffer
     * @return MessageResource
     */
    public function destroy(JobOfferDeleteRequest $request, JobOffer $jobOffer)
    {
        $jobOffer->delete();

        $response = ['message' => 'Job offer deleted'];

        return new MessageResource($response);
    }

    public function form(JobOfferFormRequest $request)
    {
        $validated = $request->validated();

        $validated['files'] = array_map(function ($token) {
            return SecurityToken::where('token', $token)->with('attachment')->first();
        }, $validated['files']);

        $mail = new JobOfferReply($validated);

        Mail::to(env('MAIL_JOB_OFFER_REPLY_TO_ADDRESS'))
            ->send($mail);

        foreach ($validated['files'] as $token) {
            $token->attachment->delete();
            $token->delete();
        }
//        unlink($validated['files']->getPathName());

        $response = ['message' => 'OK'];

        return new MessageResource($response);
    }

    private function getArrayEncodeMapFunction()
    {
        return function ($item) {
            return is_array($item) ? \GuzzleHttp\json_encode(array_values($item)) : $item;
        };
    }
}
