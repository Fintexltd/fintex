<?php

namespace App\Http\Controllers;

use App\Entities\Country;
//use App\Http\Requests\CountryDomainRequest;
use App\Http\Requests\CountryIndexRequest;
use App\Http\Resources\CountryCollection;
use App\Http\Resources\CountryDomainCollection;
use App\User;

class CountryController extends Controller
{

    /**
     * @param CountryIndexRequest $request
     * @return CountryCollection
     */
    public function index(CountryIndexRequest $request)
    {
        return new CountryCollection(Country::orderBy('country_name')->get());
    }

    //TODO: remove this:
    /**
     * @param CountryDomainRequest $request
     * @return CountryDomainCollection
     */
    /*public function domesticDomain(CountryDomainRequest $request)
    {
        $user = User::query()
            ->where('email', $request->get('email'))
            ->get()
            ->first();

        $rel = Country::query()
            ->select('countries.*', 'relations.user_id')
            ->leftJoin('relations', 'relations.related_id', '=', 'countries.id')
            ->where('relations.related_type', Country::class)
            ->get();

        $ids = $rel->pluck('id')->all();

        $userDomain = $rel
            ->filter(function ($country) use ($user) {
                return $country->user_id === $user->id;
            });

        $countries = Country::all()
            ->filter(function ($country) use ($ids) {
                return !in_array($country->id, $ids);
            })
            ->concat($userDomain)
            ->sortBy('country_name');

        return new CountryDomainCollection($countries);
    }*/
}
