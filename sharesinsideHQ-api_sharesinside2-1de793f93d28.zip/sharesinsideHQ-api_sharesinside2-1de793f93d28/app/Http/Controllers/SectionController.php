<?php

namespace App\Http\Controllers;

use App\Entities\Section;
use App\Http\Requests\SectionDeleteRequest;
use App\Http\Requests\SectionStoreRequest;
use App\Http\Requests\SectionUpdateRequest;
use App\Services\SectionsCreator;
use Illuminate\Http\Request;

class SectionController extends Controller
{
    protected $sectionCreator;

    public function __construct(SectionsCreator $sectionsCreator)
    {
        $this->sectionCreator = $sectionsCreator;
    }

    /**
     * @param SectionStoreRequest
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(SectionStoreRequest $request)
    {
        $section = $this->sectionCreator->handleStoreSection($request->all(), $request->get('type'));

        return response()->json([
            'message' => 'Section created.',
            'sectionId' => $section->id,
        ], 200);
    }

    /**
     * @param SectionUpdateRequest
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(SectionUpdateRequest $request, Section $section)
    {
        $this->sectionCreator->handleUpdateSection($section, $request->validated());

        return response()->json(['message' => 'Section updated.'], 200);
    }

    /**
     * @param SectionDeleteRequest
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(SectionDeleteRequest $request, Section $section)
    {
        $this->sectionCreator->handleDestroySection($section);

        return response()->json(['message' => 'Section deleted.'], 200);
    }
}
