<?php

namespace App\Http\Controllers\Auth;

use App\Entities\Country;
use App\Entities\MobileDevice;
use App\Entities\SecurityToken;
use App\Http\Controllers\Controller;
use App\Http\Requests\AppendLinkedinRequest;
use App\Http\Requests\AppendManualLoginRequest;
use App\Http\Requests\DeleteLinkedinRequest;
use App\Http\Requests\LinkedinRedirectTokenRequest;
use App\Http\Requests\LogoutRequest;
use App\Http\Resources\MessageResource;
use App\Services\UserRegister;
use App\User;
use Carbon\Carbon;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\Hash;
use Socialite;

class LoginController extends Controller
{
    /**
     * default time that socialite token is valid given in seconds
     */
    const DEFAULT_SOCIALITE_EXPIRES_IN = 31536000;

    protected $userRegister;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRegister $userRegister)
    {
        $this->userRegister = $userRegister;
    }

    /**
     * Redirect the user to the LinkedIn authentication page.
     *
     * @return \Illuminate\Http\Response
     */
    public function redirectToProvider()
    {
        $linkedinToken = request('token');

        if (empty($linkedinToken)) {
            return Socialite::driver('linkedin')->redirect();
        }

        $user = $this->getUser($linkedinToken);

        return $this->handleLinkedinUserData($user, false);
    }

    /**
     * Obtain the user information from LinkedIn.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback()
    {
        $user = $this->getUser();

        return $this->handleLinkedinUserData($user);
    }

    public function handleLinkedinRedirectToken(LinkedinRedirectTokenRequest $request)
    {
        $token = $request->getToken();

        $array = json_decode($token->value, true);
        $token->delete();

        return response()->json($array['data'], $array['code']);
    }

    public function logout(LogoutRequest $request)
    {
        $token = $request->get('device_token');
        if ($token) {
            $this->deleteUserDevice($request->user(), $token);
        }

        return response()->json(['message' => 'logout success'], 200);
    }

    public function linkedinAppend(AppendLinkedinRequest $request)
    {
        $user = $request->user();

        $linkedinToken = request('linkedin_token');

        if ($linkedinToken) {
            $linkedinId = data_get($this->getUser($linkedinToken), 'id');
        } else {
            $securityToken = SecurityToken::where('token', $request['register_token'])
                ->first();
            $linkedinId = $securityToken->value;
        }

        SecurityToken::where('type', SecurityToken::LINKEDIN_REGISTER)
            ->where('value', $linkedinId)
            ->delete();

        $condition = (bool)User::query()->where('linkedin_id', $linkedinId)->count();
        if ($condition) {
            return response()->json([
                "message" => "The given data was invalid.",
                "errors" => [
                    "linkedin_id" => ["There is already a user connected with this LinkedIn account."],
                ],
            ], 422);
        }


        $user->update([
            'linkedin_id' => $linkedinId,
        ]);

        $content = ["message" => "OK"];

        return new MessageResource($content);
    }

    public function linkedinDelete(DeleteLinkedinRequest $request)
    {
        $request->user()->update([
            'linkedin_id' => null,
        ]);

        $content = ['message' => 'External authorization removed.'];

        return new MessageResource($content);
    }

    public function manualAppend(AppendManualLoginRequest $request)
    {
        $user = $request->user();

        $password = Hash::make($request->get('password'));

        $user->update([
            'password' => $password,
        ]);

        return response()->json([
            "message" => "OK",
        ], 200);
    }

    private function deleteUserDevice(User $user, string $token)
    {
        MobileDevice::where('token', $token)
            ->where('user_id', $user->id)
            ->delete();
    }

    protected function handleLinkedinUserData($user, $useRedirect = true)
    {
        $registeredUser = User::where('linkedin_id', $user->id)->first();

        $code = 200;
        $data = $this->prepareLinkedInResponse($user);

        if ($registeredUser) {
            if ($registeredUser->email_confirmed) {
                $token = $this->createAccesToken($registeredUser);

                $data = [
                    "token_type" => "Bearer",
                    "expires_in" => self::DEFAULT_SOCIALITE_EXPIRES_IN,
                    "access_token" => $token->accessToken,
                    "refresh_token" => null,
                ];
            } else {
                $this->userRegister->requestEmailConfirmation($registeredUser);

                $data = [
                    "error" => "account_not_confirmed",
                    "errors" => [
                        "linkedin" => "Account connected with this LinkedIn profile was not confirmed. Confirmation email was resent for that account email adress."
                    ],
                    "message" => "Account connected with this LinkedIn profile was not confirmed. Confirmation email was resent for that account email adress."
                ];
                $code = 422;
            }
        }

        if ($useRedirect) {
            $token = $this->prepareLinkedinRedirectToken($data, $code);
            return redirect(config('app.params.linkedin_front_redirect') . '?token=' . $token->token);
        }

        return response()->json($data, $code);
    }

    private function prepareLinkedinRedirectToken($data, $code)
    {
        $value = \GuzzleHttp\json_encode([
            'data' => $data,
            'code' => $code,
        ]);

        $token = $this->createSecurityToken($value, SecurityToken::LINKEDIN_REDIRECT_TOKEN);

        return $token;
    }

    protected function prepareLinkedInResponse($user)
    {
        $token = $this->createSecurityToken($user->id, SecurityToken::LINKEDIN_REGISTER);

        $country = Country::where('linkedin_code', array_get($user->user, 'location.country.code'))->first();

        $data = [
            'linkedin_register' => $token->token,
            'name' => preg_replace('/\s/', '', $user->name),
            'email' => $user->email,
            'country' => $country,
        ];

        return $data;
    }

    protected function createSecurityToken($value, string $type)
    {
        $token = new SecurityToken();
        $token->type = $type;
        $token->generateUniqueToken();
        $token->valid_until = \Carbon\Carbon::now()
            ->addHours(SecurityToken::TOKEN_VALID_PERIOD_IN_HOURS[$type]);
        $token->value = $value;
        $token->save();

        return $token;
    }

    protected function createAccesToken(User $user)
    {
        return $user->createToken(null);
    }

    protected function getUser($token = null)
    {
        try {
            if (empty($token)) {
                $user = Socialite::driver('linkedin')->stateless()->user();
            } else {
                $user = Socialite::driver('linkedin')->userFromToken($token);
            }
        } catch (\Exception $e) {
            abort(401, 'Wrong token.');
        }

        return $user;
    }
}
