<?php

namespace App\Http\Controllers\Auth;

use App\Entities\EntitiableInterface;
use App\Services\DemoService;
use App\Http\Controllers\Controller;
use App\Http\Requests\DemoIndividualKeyAccountLoginRequest;
use App\User;

class DemoController extends Controller
{
    protected $service;

    public function __construct(DemoService $service)
    {
        $this->service = $service;
        $this->middleware([
            'guest',
            'api',
            'throttle:10,1',
        ]);
    }

    public function demoAccount()
    {
        $demoUser = $this->service->createDemoUser();
        $data =  $this->getTokenResponse($demoUser);

        return response()->json($data, 200);
    }

    public function demoIndividualKeyAccount(DemoIndividualKeyAccountLoginRequest $request)
    {
        $demoKey = $this->service->getDemoIndividualKey($request['key']);

        $data = $this->getTokenResponse($demoKey->user);
        $data['entitiable_type'] = EntitiableInterface::ENTITIABLE_TYPE[$demoKey->entitiable_type];
        $data['entitiable_id'] = $demoKey->entitiable_id;

        return response()->json($data, 200);
    }

    protected function getTokenResponse(User $user)
    {
        $token = $user->createToken(null);

        $data = [
            "token_type" => "Bearer",
            "expires_in" => LoginController::DEFAULT_SOCIALITE_EXPIRES_IN,
            "access_token" => $token->accessToken,
            "refresh_token" => null,
        ];

        return $data;
    }
}
