<?php

namespace App\Http\Controllers\Auth;

use Laravel\Passport\Passport;
use App\Http\Resources\OAuthScopeCollection;
use App\Http\Requests\OAuthScopeIndexRequest;
use App\Http\Controllers\Controller;

class OAuthScopeController extends Controller
{
    /**
     * @param OAuthScopeIndexRequest $request
     * @return OAuthScopeCollection
     */
    public function index(OAuthScopeIndexRequest $request)
    {
        $scopes = Passport::scopes()->filter(function ($value) {
            if (starts_with($value->id, 'manage-se-') && !auth()->user()->seExternalApiUser()->where('is_active', true)->first()) {
                return false;
            }

            return true;
        });

        return new OAuthScopeCollection($scopes);
    }
}
