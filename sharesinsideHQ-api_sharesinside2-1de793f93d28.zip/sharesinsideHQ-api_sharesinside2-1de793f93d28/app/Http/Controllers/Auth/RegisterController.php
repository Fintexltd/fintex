<?php

namespace App\Http\Controllers\Auth;

use App\Events\EmailConfirmEvent;
use App\Http\Requests\EmailConfirmationRequest;
use App\Http\Requests\RegisterUserRequest;
use App\Services\UserRegister;
use App\Http\Controllers\Controller;
use App\User;

class RegisterController extends Controller
{

    protected $userRegister;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(UserRegister $userRegister)
    {
        $this->userRegister = $userRegister;
        $this->middleware('guest');
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function register(RegisterUserRequest $request)
    {
        $this->userRegister->registerUser($request->all());
        return response()->json(['message' => 'Registration successful.'], 201);
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function confirmEmail(EmailConfirmationRequest $request)
    {
        if ($request->has('token')) {
            $token = $request->get('token');
            event(new EmailConfirmEvent($token));
            return redirect(config('app.params.email_confirmed_redirect_url'));
        }

        if ($request->has('email')) {
            $user = User::where('email', $request->get('email'))->first();
            $this->userRegister->requestEmailConfirmation($user);
            return response()->json(['message' => 'Confirmation email was resent.', 200]);
        }
    }
}
