<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;
use App\Services\PasswordReset;
use App\User;

class ResetPasswordController extends Controller
{
    protected $passwordResset;

    public function __construct(PasswordReset $passwordReset)
    {
        $this->passwordResset = $passwordReset;
    }

    public function reset(ResetPasswordRequest $request)
    {
        $user = User::where('email', $request->get('email'))->first();
        if ($user) {
            $this->passwordResset->setRandomPassword($user);
        }

        return response()->json(['message' => 'Email with reseted password was send.'], 200);
    }
}
