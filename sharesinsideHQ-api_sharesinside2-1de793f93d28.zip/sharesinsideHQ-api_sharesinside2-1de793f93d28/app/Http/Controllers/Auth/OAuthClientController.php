<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Response;
use App\Repositories\OAuthClientRepository;
use App\Http\Requests\OAuthClientForUserRequest;
use App\Http\Requests\OAuthClientDestroyRequest;
use App\Http\Requests\OAuthClientStoreRequest;
use App\Http\Requests\OAuthClientUpdateRequest;
use App\Http\Controllers\Controller;
use App\Http\Resources\OAuthClientResource;
use App\Http\Resources\OAuthClientCollection;
use App\Http\Resources\MessageResource;

class OAuthClientController extends Controller
{
    protected $clients;

    public function __construct(OAuthClientRepository $clients)
    {
        $this->clients = $clients;
    }

    /**
     * @param OAuthClientForUserRequest $request
     * @return OAuthClientCollection
     */
    public function forUser(OAuthClientForUserRequest $request)
    {
        $userId = auth()->user()->getKey();
        $clients = $this->clients->activeForUser($userId)->makeVisible('secret');

        return new OAuthClientCollection($clients);
    }

    /**
     * @param OAuthClientStoreRequest $request
     * @return OAuthClientResource
     */
    public function store(OAuthClientStoreRequest $request)
    {
        $client =  $this->clients->create(
            $request->user()->getKey(), $request->name, $request->redirect
        )->makeVisible('secret');

        return new OAuthClientResource($client);
    }

    /**
     * @param OAuthClientUpdateRequest $request
     * @return OAuthClientResource
     */
    public function update(OAuthClientUpdateRequest $request, $clientId)
    {
        $client = $this->clients->findForUser($clientId, $request->user()->getKey());

        if (! $client) {
            return new Response('', 404);
        }

        $clientUpdate = $this->clients->update(
            $client, $request->name, $request->redirect
        );

        return new OAuthClientResource($clientUpdate);
    }

    /**
     * @param OAuthClientDestroyRequest $request
     * @return MessageResource
     */
    public function destroy(OAuthClientDestroyRequest $request, $clientId)
    {
        $client = $this->clients->findForUser($clientId, auth()->user()->getKey());

        if (! $client) {
            return new Response('', 404);
        }

        $this->clients->delete($client);

        return new MessageResource(['message' => 'Client deleted.']);
    }
}
