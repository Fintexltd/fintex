<?php

namespace App\Http\Controllers\Auth;

use App\Http\Requests\OAuthBearerStoreRequest;
use App\Http\Requests\OAuthBearerRevokeRequest;
use App\Http\Resources\OAuthTokenResource;
use App\Services\PassportToken\PassportTokenService;
use App\Entities\OAuthToken;
use App\Http\Controllers\Controller;
use App\Http\Resources\MessageResource;

class OAuthBearerController extends Controller
{
    /**
     * @param OAuthBearerStoreRequest $request
     * @return OAuthTokenResource
     */
    public function store(OAuthBearerStoreRequest $request, PassportTokenService $tokenService)
    {
        $token = $tokenService->createPassportTokenByUser(auth()->user(), $request->input('client_id'), $request->input('scopes'));

        return new OAuthTokenResource(OAuthToken::find($token['access_token']->getIdentifier()));
    }

    /**
     * @param OAuthClientDestroyRequest $request
     * @return MessageResource
     */
    public function revoke(OAuthBearerRevokeRequest $request, string $token)
    {
        $token = $request->user()->tokens->find($token);
        $token->revoke();

        return new MessageResource(['message' => 'Token revoked.']);
    }
}
