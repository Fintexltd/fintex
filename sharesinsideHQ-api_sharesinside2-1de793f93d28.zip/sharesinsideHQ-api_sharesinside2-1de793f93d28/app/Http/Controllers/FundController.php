<?php

namespace App\Http\Controllers;

use App\Criteria\FundFollowedCriteria;
use App\Criteria\FundManagedCriteria;
use App\Criteria\FundSortByCriteria;
use App\Criteria\QueryColumnCriteria;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Http\Requests\FundsAcceptRequest;
use App\Http\Requests\FundsDestroyRequest;
use App\Http\Requests\FundAdminIndexRequest;
use App\Http\Requests\FundDemoIndexRequest;
use App\Http\Requests\FundEditRequest;
use App\Http\Requests\FollowRequest;
use App\Http\Requests\FundIndexRequest;
use App\Http\Requests\FundListRequest;
use App\Http\Requests\FundOtherRequest;
use App\Http\Requests\FundRequestAdminIndexRequest;
use App\Http\Requests\FundShowRequest;
use App\Http\Requests\FundStoreRequest;
use App\Http\Requests\UnfollowRequest;
use App\Http\Requests\FundUpdateRequest;
use App\Http\Requests\FundFollowFiltersRequest;
use App\Http\Resources\FundCollection;
use App\Http\Resources\FundCollectionWithDefaultSorting;
use App\Http\Resources\FundDemoCollection;
use App\Http\Resources\FundEditResource;
use App\Http\Resources\EntityListCollection;
use App\Http\Resources\FundRequestCollection;
use App\Http\Resources\FundResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\OtherFundTileCollection;
use App\Repositories\FundRepository;
use App\Services\FundCreator;
use App\Services\RoleResolver;
use App\Services\FollowService;
use App\Services\ViewsCounter;
use Illuminate\Http\Request;

class FundController extends Controller
{
    protected $fundCreator;
    protected $followService;
    protected $repository;
    protected $viewsCounter;

    const FUNDS_PER_PAGE = 16;
    const FUNDS_REQUESTS_PER_PAGE = 10;

    public function __construct(
        FundCreator $fundCreator,
        FundRepository $repository,
        FollowService $followService,
        ViewsCounter $viewsCounter
    )
    {
        $this->fundCreator = $fundCreator;
        $this->followService = $followService;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param FundStoreRequest $request
     * @return MessageResource
     */
    public function store(FundStoreRequest $request)
    {
        $this->fundCreator->handleStoreFund($request->validated());

        $content = ['message' => 'Fund created.'];

        return new MessageResource($content);
    }

    /**
     * @param FundEditRequest $request
     * @param Fund $fund
     * @return FundEditResource
     */
    public function edit(FundEditRequest $request, Fund $fund)
    {
        $fund->load([
            'logo',
            'background',
            'country',
            'country.continent',
            'currency',
            'attachments',
            'links',
            'seSymbols',
            'seSymbols.seOhlcv52',
            'socialMedia',
            'fundTypes',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'fundsManager',
            'fundsManager.logo',
        ]);

        $this->viewsCounter->handleEntityView($fund, $request->user());

        $response = new FundEditResource($fund);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FundUpdateRequest $request
     * @param Fund $fund
     * @return MessageResource
     */
    public function update(FundUpdateRequest $request, Fund $fund)
    {
        $this->fundCreator->handleUpdateFund($fund, $request->validated());

        $content = ['message' => 'Fund updated.'];

        return new MessageResource($content);
    }

    /**
     * @param FundIndexRequest $request
     * @param FundsManager $fundsManager
     * @return FundCollection
     */
    public function index(FundIndexRequest $request, FundsManager $fundsManager = null)
    {
        $validated = $request->validated();

        $this->repository->applyRequestCriteria($validated);

        if($fundsManager) {
            $this->repository->pushCriteria(new QueryColumnCriteria('funds_manager_id', $fundsManager->id));
        }

        $sortBy = request()->get('sort_by');

        if (data_get($validated, 'sort_by', FundSortByCriteria::SORT_DEFAULT) === FundSortByCriteria::SORT_DEFAULT) {

            srand((int)$validated['seed']);
            $ids = $this->repository->get(['id'])->pluck('id')->all();
            $total = count($ids);
            $lastPage = (int)ceil($total / self::FUNDS_PER_PAGE) ?: 1;
            shuffle($ids);
            $page = (int)data_get($validated, 'page', 1);

            $links = [
                'first' => route('funds.index', array_merge($validated, ['page' => 1])),
                'last' => route('funds.index', array_merge($validated, ['page' => $lastPage])),
                'prev' => $page ? null : route('funds.index', array_merge($validated, ['page' => $page - 1])),
                'next' => ($page < $lastPage) ? route('funds.index', array_merge($validated, ['page' => $page + 1])) : null,
            ];

            $offset = ($page - 1) * self::FUNDS_PER_PAGE;
            $records = array_slice($ids, $offset, self::FUNDS_PER_PAGE);
            $results = $this
                ->repository
                ->scopeQuery(function ($query) use ($records) {
                    return $query->whereIn('id', $records);
                })
                ->with([
                    'logo',
                    'fundsManager',
                    'fundsManager.logo',
                    'fundTypes',
                ])
                ->get()
                ->keyBy('id');

            $isFollowingAll = $this->repository->pushCriteria(new FundFollowedCriteria($request->user()))->get(['id'])->count() === $total;

            $meta = [
                'current_page' => $page,
                'from' => count($records) ? ($offset + 1) : null,
                'last_page' => $lastPage,
                'path' => route('funds.index'),
                'per_page' => self::FUNDS_PER_PAGE,
                'to' => count($records) ? ($offset + count($records)) : null,
                'total' => $total,
                'is_following_all' => $isFollowingAll,
            ];

            $data = collect($records)
                ->map(function ($id) use ($results) {
                    return $results->get($id);
                });

            $object = (object)[
                'data' => $data,
                'links' => $links,
                'meta' => $meta
            ];

            $response = new FundCollectionWithDefaultSorting($object);

            return $response;
        }

        $this->repository->pushCriteria(new FundSortByCriteria($sortBy));

        $results = $this
            ->repository
            ->with([
                'logo',
                'fundsManager',
                'fundsManager.logo',
                'fundTypes',
            ])
            ->paginate(self::FUNDS_PER_PAGE, ['*']);

        $isFollowingAll = $this->repository->pushCriteria(new FundFollowedCriteria($request->user()))->get(['id'])->count() === $results->total();

        $results->isFollowingAll = $isFollowingAll;

        $response = new FundCollection($results);

        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FundListRequest $request
     * @return EntityListCollection
     */
    public function fundsList(FundListRequest $request, FundsManager $fundsManager = null)
    {
        $query = Fund::query()
            ->where('is_accepted', true)
            ->orderBy('name');

        if($fundsManager) {
            $query->where('funds_manager_id', $fundsManager->id);
        }

        $user = $request->user();

        if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
            $query
                ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                });
        }

        $result = $query->get(['id', 'name']);

        return new EntityListCollection($result);
    }

    /**
     * @param FundRequestAdminIndexRequest $request
     * @return FundRequestCollection
     */
    public function requestIndex(FundRequestAdminIndexRequest $request)
    {
        $perPage = (int)array_get($request->validated(), 'per_page', self::FUNDS_REQUESTS_PER_PAGE);

        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->pushCriteria(new QueryColumnCriteria('is_accepted', false));

        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new FundSortByCriteria(FundSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'fundTypes',
            ])
            ->paginate($perPage);

        return new FundRequestCollection($results);
    }

    /**
     * @param FundAdminIndexRequest $request
     * @return FundCollection
     */
    public function adminIndex(FundAdminIndexRequest $request, FundsManager $fundsManager = null)
    {
        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->applyRequestCriteria($request->validated());

        if($fundsManager) {
            $this->repository->pushCriteria(new QueryColumnCriteria('funds_manager_id', $fundsManager->id));
        }

        $this->repository->pushCriteria(new FundManagedCriteria($request->user()));

        $this->repository->pushCriteria(new FundSortByCriteria(FundSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
                'fundsManager',
                'fundsManager.logo',
                'fundTypes',
            ])
            ->paginate(self::FUNDS_PER_PAGE, ['*']);

        return new FundCollection($results);
    }

    /**
     * @param FundAdminIndexRequest $request
     * @return FundDemoCollection
     */
    /*public function adminDemoIndex(FundDemoIndexRequest $request)
    {
        $data = $request->validated();
        $data['demo_relations'] = data_get($data, 'relations');
        unset($data['relations']);

        $this->repository->applyRequestCriteria($data);

        $this->repository->pushCriteria(new FundSortByCriteria(FundSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo'
            ])
            ->paginate(self::FUNDS_PER_PAGE, ['*']);

        return new FundDemoCollection($results);
    }*/

    /**
     * @param FundsAcceptRequest $request
     * @return MessageResource
     */
    public function acceptFunds(FundsAcceptRequest $request)
    {
        $accept = $request->get('fund_ids') ?? [];

        $this->fundCreator->accept($accept);

        $content = ['message' => 'Funds accepted.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsDestroyRequest $request
     * @return MessageResource
     */
    public function destroyFunds(FundsDestroyRequest $request)
    {
        $delete = $request->get('fund_ids') ?? [];

        $this->fundCreator->destroy($delete);

        $content = ['message' => 'Funds deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param FundOtherRequest $request
     * @param Fund $fund
     * @return OtherFundTileCollection
     */
    public function other(FundOtherRequest $request, Fund $fund)
    {
        $result = $this->repository->otherFunds($fund, $request->all());

        return new OtherFundTileCollection($result);
    }

    /**
     * @param FundShowRequest $request
     * @param Fund $fund
     * @return FundResource
     */
    public function show(FundShowRequest $request, Fund $fund)
    {
        $fund->load([
            'logo',
            'background',
            'country',
            'country.continent',
            'currency',
            'attachments',
            'links',
            'seSymbols',
            'seSymbols.seOhlcv52',
            'socialMedia',
            'fundTypes',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'fundsManager',
            'fundsManager.logo',
        ]);

        $this->viewsCounter->handleEntityView($fund, $request->user());

        $response = new FundResource($fund);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FollowRequest $request
     * @param Fund $fund
     * @return MessageResource
     */
    public function follow(FollowRequest $request, Fund $fund)
    {
        $user = $request->user();

        $this->followService->follow($fund, $user);

        $content = ['message' => 'You now are following fund.'];

        return new MessageResource($content);
    }

    /**
     * @param UnfollowRequest $request
     * @param Fund $fund
     * @return MessageResource
     */
    public function unfollow(UnfollowRequest $request, Fund $fund)
    {
        $user = $request->user();
        $this->followService->unfollow($fund, $user);

        $content = ['message' => 'You now are not following fund.'];

        return new MessageResource($content);
    }

    /**
     * @param FundFollowFiltersRequest $request
     * @param Fund $fund
     * @return MessageResource
     */
    public function followFilters(FundFollowFiltersRequest $request, Fund $fund, FundsManager $fundsManager = null)
    {
        $user = $request->user();
        $this->repository->applyRequestCriteria($request->validated());

        if($fundsManager) {
            $this->repository->pushCriteria(new QueryColumnCriteria('funds_manager_id', $fundsManager->id));
        }

        $results = $this
            ->repository
            ->get(['id']);

        $this->followService->followFilters($fund, $results, $user, $request->get('type'));

        $content = ['message' => 'Followed funds changed.'];

        return new MessageResource($content);
    }
}
