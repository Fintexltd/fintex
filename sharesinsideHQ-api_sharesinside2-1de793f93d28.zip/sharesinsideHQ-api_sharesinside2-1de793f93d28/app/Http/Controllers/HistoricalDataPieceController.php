<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Entities\Company;
use App\Entities\HistoricalDataPiece;
use App\Http\Requests\HistoricalDataDeleteRequest;
use App\Http\Requests\HistoricalDataPieceIndexRequest;
use App\Http\Requests\HistoricalDataRecentRequest;
use App\Http\Requests\HistoricalDataStoreRequest;
use App\Http\Requests\HistoricalDataUpdateRequest;
use App\Http\Resources\HistoricalDataCollection;
use App\Http\Resources\HistoricalDataRecentCollection;
use App\Http\Resources\HistoricalDataResource;
use App\Http\Resources\MessageResource;
use App\Repositories\HistoricalDataPieceRepository;
use App\Services\HistoricalDataCreator;
use Illuminate\Http\Request;

class HistoricalDataPieceController extends Controller
{
    protected $creator;
    protected $repository;

    const ITEMS_PER_PAGE = 10;

    public function __construct(HistoricalDataCreator $creator, HistoricalDataPieceRepository $repository)
    {
        $this->creator = $creator;
        $this->repository = $repository;
    }

    /**
     * @param HistoricalDataRecentRequest $request
     * @param Company $company
     * @return HistoricalDataRecentCollection
     */
    public function recent(HistoricalDataRecentRequest $request, Company $company)
    {
        $data = $this->repository->getLatest($company->id);

        $resource = new HistoricalDataRecentCollection($data);

        $resource->withoutWrapping();

        return $resource;
    }

    /**
     * @param HistoricalDataPieceIndexRequest $request
     * @param Company $company
     * @return HistoricalDataCollection
     */
    public function index(HistoricalDataPieceIndexRequest $request, Company $company)
    {
        $sectionId = $request->get('section_id');

        $this->repository->pushCriteria(new QueryColumnCriteria('company_id', $company->id));
        $this->repository->pushCriteria(new QueryColumnCriteria('section_id', $sectionId));

        $this->repository->applyRequestCriteria();

        $results = $this
            ->repository
            ->with([
                'attachment',
            ])
            ->orderBy('created_at', 'desc')
            ->paginate(self::ITEMS_PER_PAGE, ['*']);

        return new HistoricalDataCollection($results);
    }

    /**
     * @param HistoricalDataStoreRequest $request
     * @return HistoricalDataResource
     */
    public function store(HistoricalDataStoreRequest $request)
    {
        $resource = $this->creator->handleStore($request->all());

        $responce = new HistoricalDataResource($resource);
        $responce->withoutWrapping();

        return $responce;
    }

    /**
     * @param HistoricalDataUpdateRequest $request
     * @param HistoricalDataPiece $historical_datum
     * @return HistoricalDataResource
     */
    public function update(HistoricalDataUpdateRequest $request, HistoricalDataPiece $historical_datum)
    {
        $resource = $this->creator->handleUpdate($historical_datum, $request->all());

        $responce = new HistoricalDataResource($resource);
        $responce->withoutWrapping();

        return $responce;
    }

    /**
     * @param HistoricalDataDeleteRequest $request
     * @param HistoricalDataPiece $historical_datum
     * @return MessageResource
     */
    public function destroy(HistoricalDataDeleteRequest $request, HistoricalDataPiece $historical_datum)
    {
        $historical_datum->delete();

        $content = ['message' => 'Historical data deleted.'];

        return new MessageResource($content);
    }
}
