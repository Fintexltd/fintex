<?php

namespace App\Http\Controllers;

use App\Criteria\StartupRelationsCriteria;
use App\Criteria\RelationsForStartupCriteria;
use App\Entities\Startup;
use App\Http\Requests\DeleteStartupRelationsRequest;
use App\Http\Requests\RelationNamesRequest;
use App\Http\Requests\RelationStartupUsersIndexRequest;
use App\Http\Requests\UserRelationIndexRequest;
use App\Http\Requests\UserRelationsIndexRequest;
use App\Http\Resources\NameCollection;
use App\Http\Resources\RelationStartupForUserAdminCollection;
use App\Http\Resources\RelationUsersForStartupAdminCollection;
use App\Http\Resources\UserRelationCollection;
use App\Repositories\RelationRepository;
use App\Services\StartupRelationService;
use App\User;
use Illuminate\Http\Request;


class StartupRelationController extends Controller
{
    const DEFAULT_PER_PAGE = 10;

    protected $repository;
    protected $service;

    public function __construct(RelationRepository $repository, StartupRelationService $service)
    {
        $this->repository = $repository;
        $this->service = $service;
    }

    /**
     * @param UserRelationIndexRequest
     * @return UserRelationCollection
     */
    public function index(UserRelationIndexRequest $request)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $criteria = new StartupRelationsCriteria($request->user(), $request->validated());

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        return new UserRelationCollection($result);
    }

    /**
     * @param RelationNamesRequest
     * @return NameCollection
     */
    public function startupNames(RelationNamesRequest $request)
    {
        $result = $this->repository->getEntityNames($request->user(), $request->validated(), Startup::class);

        $response = new NameCollection($result);
        $response->withoutWrapping();

        return $response;
    }

    public function indexStartupRelated(RelationStartupUsersIndexRequest $request, Startup $startup)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $data = $request->validated();

        $criteria = new RelationsForStartupCriteria($startup, $data);

        $result = $this->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load([
            'related',
            'user',
            'user.country',
        ]);

        $response = new RelationUsersForStartupAdminCollection($result);

        return $response;
    }

    public function indexUserRelations(UserRelationsIndexRequest $request, User $user)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $data = $this->prepareCriteriaData($request->validated());

        $criteria = new StartupRelationsCriteria($user, $data);

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        $response = new RelationStartupForUserAdminCollection($result);

        return $response;
    }

    private function prepareCriteriaData(array $data)
    {
        $prepared['search'] = data_get($data, 'search');

        switch ($data['relation']) {
            case 'admin':
                $prepared['relations'] = [
                    User::RELATION_TYPE_PRIMARY_ADMIN,
                    User::RELATION_TYPE_SECONDARY_ADMIN,
                    User::RELATION_TYPE_DOMESTIC_ADMIN,
                ];
                break;
            default:
                $prepared['relations'] = [
                    $data['relation']
                ];
        }

        return $prepared;
    }

    public function deleteStartupRelated(DeleteStartupRelationsRequest $request, Startup $startup)
    {
        $this->service->handleMassResign($request->validated());
    }
}
