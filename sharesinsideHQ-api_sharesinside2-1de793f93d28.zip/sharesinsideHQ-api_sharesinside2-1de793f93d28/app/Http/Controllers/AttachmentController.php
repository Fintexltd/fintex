<?php

namespace App\Http\Controllers;

use App\Http\Requests\AttachmentStoreRequest;
use App\Http\Requests\FormAttachmentStoreRequest;
use App\Services\AttachmentsCreator;
use App\Repositories\AttachmentRepository;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Pion\Laravel\ChunkUpload\Exceptions\UploadMissingFileException;
use Pion\Laravel\ChunkUpload\Handler\AbstractHandler;
use Pion\Laravel\ChunkUpload\Handler\HandlerFactory;
use Pion\Laravel\ChunkUpload\Receiver\FileReceiver;

class AttachmentController extends Controller
{
    protected $attachmentsCreator;

    public function __construct(AttachmentsCreator $attachmentsCreator)
    {
        $this->attachmentsCreator = $attachmentsCreator;
    }

//    public function store(AttachmentStoreRequest $request)
//    {
//        $user = Auth::user();
//
//        $token = $this->attachmentsCreator->createSecurityToken($user, $request->get('type'));
//        $attachment = $this->attachmentsCreator->saveAttachment($request->file('attachment'), $token, $request->get('type'));
//
//        return response()->json([
//            'message' => 'File uploaded.',
//            'token' => $token->token,
//            ], 200);
//    }

    /**
     * Handles the file upload
     *
     * @param Request
     *
     * @return \Illuminate\Http\JsonResponse
     *
     * @throws UploadMissingFileException
     * @throws \Pion\Laravel\ChunkUpload\Exceptions\UploadFailedException
     */
    public function store(AttachmentStoreRequest $request)
    {
        // create the file receiver
        $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));

        // check if the upload is success, throw exception or return response you need
        if ($receiver->isUploaded() === false) {
            throw new UploadMissingFileException();
        }

        // receive the file
        $save = $receiver->receive();

        // check if the upload has finished (in chunk mode it will send smaller files)
        if ($save->isFinished()) {
            // save the file and return any response you need, current example uses `move` function. If you are
            // not using move, you need to manually delete the file by unlink($save->getFile()->getPathname())
            return $this->saveFile($save->getFile(), $request->get('type'));
        }

        // we are in chunk mode, lets send the current progress
        /** @var AbstractHandler $handler */
        $handler = $save->handler();

        return response()->json([
            "done" => $handler->getPercentageDone(),
            'status' => true
        ]);
    }

    public function storeFormAttachment(FormAttachmentStoreRequest $request)
    {
        // create the file receiver
        $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));

        // check if the upload is success, throw exception or return response you need
        if ($receiver->isUploaded() === false) {
            throw new UploadMissingFileException();
        }

        // receive the file
        $save = $receiver->receive();

        // check if the upload has finished (in chunk mode it will send smaller files)
        if ($save->isFinished()) {
            // save the file and return any response you need, current example uses `move` function. If you are
            // not using move, you need to manually delete the file by unlink($save->getFile()->getPathname())
            return $this->saveFile($save->getFile(), $request->get('type'));
        }

        // we are in chunk mode, lets send the current progress
        /** @var AbstractHandler $handler */
        $handler = $save->handler();

        return response()->json([
            "done" => $handler->getPercentageDone(),
            'status' => true
        ]);
    }

    /**
     * Saves the file
     *
     * @param UploadedFile $file
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function saveFile(UploadedFile $file, string $type)
    {
        $user = Auth::user();

        $error = $this->attachmentsCreator->fileValidation($file, $type);
        if ($error) {
            return response()->json([
                'message' => 'The given data was invalid.',
                'errors' => [
                    'file' => $error,
                ],
            ], 422);
        }

        $token = $this->attachmentsCreator->createSecurityToken($user, $type);
        $this->attachmentsCreator->saveAttachment($file, $token, $type);

        return response()->json([
            'message' => 'File uploaded.',
            'token' => $token->token,
        ], 201);
    }
}
