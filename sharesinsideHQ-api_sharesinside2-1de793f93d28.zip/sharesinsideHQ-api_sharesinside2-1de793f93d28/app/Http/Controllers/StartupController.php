<?php

namespace App\Http\Controllers;

use App\Criteria\StartupFollowedCriteria;
use App\Criteria\StartupManagedCriteria;
use App\Criteria\StartupSortByCriteria;
use App\Criteria\QueryColumnCriteria;
use App\Entities\Startup;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Http\Requests\StartupsAcceptRequest;
use App\Http\Requests\StartupsDestroyRequest;
use App\Http\Requests\StartupDemoIndexRequest;
use App\Http\Requests\StartupAdminIndexRequest;
use App\Http\Requests\StartupEditRequest;
use App\Http\Requests\FollowRequest;
use App\Http\Requests\StartupIndexRequest;
use App\Http\Requests\StartupListRequest;
use App\Http\Requests\StartupOtherRequest;
use App\Http\Requests\StartupRequestAdminIndexRequest;
use App\Http\Requests\StartupShowRequest;
use App\Http\Requests\StartupStoreRequest;
use App\Http\Requests\UnfollowRequest;
use App\Http\Requests\StartupUpdateRequest;
use App\Http\Requests\StartupFollowFiltersRequest;
use App\Http\Resources\StartupCollection;
use App\Http\Resources\StartupCollectionWithDefaultSorting;
use App\Http\Resources\StartupDemoCollection;
use App\Http\Resources\StartupEditResource;
use App\Http\Resources\EntityListCollection;
use App\Http\Resources\StartupRequestCollection;
use App\Http\Resources\StartupResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\OtherStartupTileCollection;
use App\Repositories\StartupRepository;
use App\Services\StartupsCreator;
use App\Services\RoleResolver;
use App\Services\FollowService;
use App\Services\ViewsCounter;
use Illuminate\Http\Request;

class StartupController extends Controller
{
    protected $startupsCreator;
    protected $followService;
    protected $repository;
    protected $viewsCounter;

    const STARTUPS_PER_PAGE = 16;
    const STARTUPS_REQUESTS_PER_PAGE = 10;

    public function __construct(
        StartupsCreator $startupsCreator,
        StartupRepository $repository,
        FollowService $followService,
        ViewsCounter $viewsCounter
    )
    {
        $this->startupsCreator = $startupsCreator;
        $this->followService = $followService;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param StartupStoreRequest $request
     * @return MessageResource
     */
    public function store(StartupStoreRequest $request)
    {
        $this->startupsCreator->handleStoreStartup($request->validated());

        $content = ['message' => 'Startup created.'];

        return new MessageResource($content);
    }

    /**
     * @param StartupEditRequest $request
     * @param Startup $startup
     * @return StartupEditResource
     */
    public function edit(StartupEditRequest $request, Startup $startup)
    {
        $startup->load([
            'logo',
            'background',
            'country',
            'country.continent',
            'currency',
            'attachments',
            'links',
            'socialMedia',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'startupCategories',
            'demoIndividualKeys',
        ]);

        $this->viewsCounter->handleEntityView($startup, $request->user());

        $response = new StartupEditResource($startup);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param StartupUpdateRequest $request
     * @param Startup $startup
     * @return MessageResource
     */
    public function update(StartupUpdateRequest $request, Startup $startup)
    {
        $this->startupsCreator->handleUpdateStartup($startup, $request->validated());

        $content = ['message' => 'Startup updated.'];

        return new MessageResource($content);
    }

    /**
     * @param StartupIndexRequest $request
     * @return StartupCollection
     */
    public function index(StartupIndexRequest $request)
    {
        $validated = $request->validated();

        $this->repository->applyRequestCriteria($validated);

        $sortBy = request()->get('sort_by');

        if (data_get($validated, 'sort_by', StartupSortByCriteria::SORT_DEFAULT) === StartupSortByCriteria::SORT_DEFAULT) {

            srand((int)$validated['seed']);
            $ids = $this->repository->get(['id'])->pluck('id')->all();
            $total = count($ids);
            $lastPage = (int)ceil($total / self::STARTUPS_PER_PAGE) ?: 1;
            shuffle($ids);
            $page = (int)data_get($validated, 'page', 1);

            $links = [
                'first' => route('startups.index', array_merge($validated, ['page' => 1])),
                'last' => route('startups.index', array_merge($validated, ['page' => $lastPage])),
                'prev' => $page ? null : route('startups.index', array_merge($validated, ['page' => $page - 1])),
                'next' => ($page < $lastPage) ? route('startups.index', array_merge($validated, ['page' => $page + 1])) : null,
            ];

            $offset = ($page - 1) * self::STARTUPS_PER_PAGE;
            $records = array_slice($ids, $offset, self::STARTUPS_PER_PAGE);
            $results = $this
                ->repository
                ->scopeQuery(function ($query) use ($records) {
                    return $query->whereIn('id', $records);
                })
                ->with([
                    'logo',
                    'country',
                    'country.continent',
                    'currency',
                    'startupCategories',
                ])
                ->get()
                ->keyBy('id');

            $isFollowingAll = $this->repository->pushCriteria(new StartupFollowedCriteria($request->user()))->get(['id'])->count() === $total;

            $meta = [
                'current_page' => $page,
                'from' => count($records) ? ($offset + 1) : null,
                'last_page' => $lastPage,
                'path' => route('startups.index'),
                'per_page' => self::STARTUPS_PER_PAGE,
                'to' => count($records) ? ($offset + count($records)) : null,
                'total' => $total,
                'is_following_all' => $isFollowingAll,
            ];

            $data = collect($records)
                ->map(function ($id) use ($results) {
                    return $results->get($id);
                });

            $object = (object)[
                'data' => $data,
                'links' => $links,
                'meta' => $meta
            ];

            $response = new StartupCollectionWithDefaultSorting($object);

            return $response;
        }

        $this->repository->pushCriteria(new StartupSortByCriteria($sortBy));

        $results = $this
            ->repository
            ->with([
                'logo',
                'country',
                'country.continent',
                'currency',
                'startupCategories',
            ])
            ->paginate(self::STARTUPS_PER_PAGE, ['*']);

        $isFollowingAll = $this->repository->pushCriteria(new StartupFollowedCriteria($request->user()))->get(['id'])->count() === $results->total();

        $results->isFollowingAll = $isFollowingAll;

        $response = new StartupCollection($results);

        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param StartupListRequest $request
     * @return EntityListCollection
     */
    public function startupsList(StartupListRequest $request)
    {
        $query = Startup::query()
            ->where('is_accepted', true)
            ->orderBy('name');

        $user = $request->user();

        if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
            $query
                ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                });
        }

        $result = $query->get(['id', 'name']);

        return new EntityListCollection($result);
    }

    /**
     * @param StartupRequestAdminIndexRequest $request
     * @return StartupRequestCollection
     */
    public function requestIndex(StartupRequestAdminIndexRequest $request)
    {
        $perPage = (int)array_get($request->validated(), 'per_page', self::STARTUPS_REQUESTS_PER_PAGE);

        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->pushCriteria(new QueryColumnCriteria('is_accepted', false));

        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new StartupSortByCriteria(StartupSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'country',
                'country.continent',
                'currency',
                'startupCategories',
            ])
            ->paginate($perPage);

        return new StartupRequestCollection($results);
    }

    /**
     * @param StartupAdminIndexRequest $request
     * @return StartupCollection
     */
    public function adminIndex(StartupAdminIndexRequest $request)
    {
        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new StartupManagedCriteria($request->user()));

        $this->repository->pushCriteria(new StartupSortByCriteria(StartupSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
                'country',
                'country.continent',
                'currency',
                'startupCategories',
            ])
            ->paginate(self::STARTUPS_PER_PAGE, ['*']);

        return new StartupCollection($results);
    }

    /**
     * @param StartupDemoIndexRequest $request
     * @return StartupDemoCollection
     */
    public function adminDemoIndex(StartupDemoIndexRequest $request)
    {
        $data = $request->validated();
        $data['demo_relations'] = data_get($data, 'relations');
        unset($data['relations']);

        $this->repository->applyRequestCriteria($data);

        $this->repository->pushCriteria(new StartupSortByCriteria(StartupSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
                'country',
                'country.continent',
                'currency',
                'startupCategories',
            ])
            ->paginate(self::STARTUPS_PER_PAGE, ['*']);

        return new StartupDemoCollection($results);
    }

    /**
     * @param StartupsAcceptRequest $request
     * @return MessageResource
     */
    public function acceptStartups(StartupsAcceptRequest $request)
    {
        $accept = $request->get('startup_ids') ?? [];

        $this->startupsCreator->accept($accept);

        $content = ['message' => 'Startups accepted.'];

        return new MessageResource($content);
    }

    /**
     * @param StartupsDestroyRequest $request
     * @return MessageResource
     */
    public function destroyStartups(StartupsDestroyRequest $request)
    {
        $delete = $request->get('startup_ids') ?? [];

        $this->startupsCreator->destroy($delete);

        $content = ['message' => 'Startups deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param StartupOtherRequest $request
     * @param Startup $startup
     * @return OtherStartupTileCollection
     */
    public function other(StartupOtherRequest $request, Startup $startup)
    {
        $result = $this->repository->otherStartups($startup, $request->all());

        return new OtherStartupTileCollection($result);
    }

    /**
     * @param StartupShowRequest $request
     * @param Startup $startup
     * @return StartupResource
     */
    public function show(StartupShowRequest $request, Startup $startup)
    {
        $startup->load([
            'logo',
            'background',
            'country',
            'country.continent',
            'currency',
            'attachments',
            'links',
            'socialMedia',
            'videos',
            'videoLinks',
            'startupCategories'
        ]);

        $this->viewsCounter->handleEntityView($startup, $request->user());

        $response = new StartupResource($startup);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FollowRequest $request
     * @param Startup $startup
     * @return MessageResource
     */
    public function follow(FollowRequest $request, Startup $startup)
    {
        $user = $request->user();

        $this->followService->follow($startup, $user);

        $content = ['message' => 'You now are following startup.'];

        return new MessageResource($content);
    }

    /**
     * @param UnfollowRequest $request
     * @param Startup $startup
     * @return MessageResource
     */
    public function unfollow(UnfollowRequest $request, Startup $startup)
    {
        $user = $request->user();
        $this->followService->unfollow($startup, $user);

        $content = ['message' => 'You now are not following startup.'];

        return new MessageResource($content);
    }

    /**
     * @param StartupFollowFiltersRequest $request
     * @param Startup $startup
     * @return MessageResource
     */
    public function followFilters(StartupFollowFiltersRequest $request, Startup $startup)
    {
        $user = $request->user();
        $this->repository->applyRequestCriteria($request->validated());

        $results = $this
            ->repository
            ->get(['id']);

        $this->followService->followFilters($startup, $results, $user, $request->get('type'));

        $content = ['message' => 'Followed startups changed.'];

        return new MessageResource($content);
    }
}
