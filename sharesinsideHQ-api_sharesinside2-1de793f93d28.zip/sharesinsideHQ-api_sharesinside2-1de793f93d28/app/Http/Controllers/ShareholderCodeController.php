<?php

namespace App\Http\Controllers;

use App\Http\Requests\ShareholderCodeStoreRequest;
use App\Http\Resources\MessageResource;
use App\Services\ShareholderCodesCreator;
use Illuminate\Http\Request;

class ShareholderCodeController extends Controller
{
    protected $creator;

    public function __construct(ShareholderCodesCreator $creator)
    {
        $this->creator = $creator;
    }

    /**
     * @param ShareholderCodeStoreRequest $request
     * @return MessageResource
     */
    public function store(ShareholderCodeStoreRequest $request)
    {
        $this->creator->handleStore($request->shareholder);

        $content = [
            'Code was send to your email.'
        ];

        return new MessageResource($content);
    }
}
