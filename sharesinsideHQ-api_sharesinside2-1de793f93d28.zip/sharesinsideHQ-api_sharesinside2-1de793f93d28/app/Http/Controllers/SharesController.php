<?php

namespace App\Http\Controllers;

use App\Entities\RelationInterface;
use App\Entities\Share;
use App\Entities\WatchlistItemInterface;
use App\Http\Requests\ShareStoreRequest;
use App\Services\RoleResolver;
use Illuminate\Http\Request;

class SharesController extends Controller
{
    public function store(ShareStoreRequest $request)
    {
        $watchlistItem = $request->watchlistable->watchlistItem;

        $concernedRelations = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_EDITOR,
        ];

        $userRelations = RoleResolver::getRoles($request->user(), $watchlistItem->entitiable);

        if (array_intersect($userRelations, $concernedRelations)) {
            $params = array_merge($request->except(['watchlistable_id', 'watchlistable_type', 'news_id']), [
                'user_id' => $request->user()->id,
                'shareable_type' => WatchlistItemInterface::WATCHLISTABLE_TYPE_CLASS[$request->input('watchlistable_type')],
                'shareable_id' => $request->input('watchlistable_id'),
            ]);

            Share::query()->firstOrCreate($params);
        }

        return response(['OK'], 200);
    }
}
