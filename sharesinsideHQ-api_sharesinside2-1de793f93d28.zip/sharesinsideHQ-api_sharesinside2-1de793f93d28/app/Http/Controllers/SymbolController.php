<?php

namespace App\Http\Controllers;

use App\Http\Requests\SymbolIndexRequest;
use App\Repositories\SymbolRepository;
use Illuminate\Http\Request;
use App\Http\Resources\SymbolCollection;

class SymbolController extends Controller
{
    protected $symbolRepository;

    public function __construct(SymbolRepository $symbolRepository)
    {
        $this->symbolRepository = $symbolRepository;
    }

    /**
     * @param SymbolIndexRequest $request
     * @return SymbolCollection
     */
    public function index(SymbolIndexRequest $request)
    {
        $resource = new SymbolCollection($this->symbolRepository->getSymbolsForExchange($request->get('exchange')));
//        $resource->withoutWrapping();

        return $resource;
    }
}
