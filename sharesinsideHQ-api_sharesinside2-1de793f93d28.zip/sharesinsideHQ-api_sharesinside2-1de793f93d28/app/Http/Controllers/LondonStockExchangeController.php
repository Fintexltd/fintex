<?php

namespace App\Http\Controllers;

use App\Http\Requests\LseAcceptAsCompanyRequest;
use App\Http\Requests\LseAssetIndexRequest;
use App\Http\Requests\LseEntitySearchRequest;
use App\Http\Requests\LseRejectRequest;
use App\Http\Requests\LseAttachToCompanyRequest;
use App\Http\Requests\LsePreviewRequest;
use App\Http\Resources\EntityListCollection;
use App\Http\Resources\LseCompanyPreviewResource;
use App\Http\Resources\LseAssetCollection;
use App\Http\Resources\MessageResource;
use App\Repositories\LseAssetRepository;
use App\Services\LondonStockExchangeProvider;
use App\Entities\LseAsset;

class LondonStockExchangeController extends Controller
{
    const ASSETS_PER_PAGE = 12;

    private $repository;
    private $provider;

    public function __construct(LseAssetRepository $repository, LondonStockExchangeProvider $provider)
    {
        $this->repository = $repository;
        $this->provider = $provider;
    }

    /**
     * @param LseAssetIndexRequest $request
     * @return LseAssetCollection
     */
    public function index(LseAssetIndexRequest $request)
    {
        $this->repository->applyRequestCriteria($request->validated());

        $results = $this
            ->repository
            ->paginate(self::ASSETS_PER_PAGE, [
                'id',
                'name',
                'lse_profile',
                'website',
                'isin',
                'category',
                'additional_data',
            ]);

        $results->load([
            'lseLivestreams'
        ]);

        $response = new LseAssetCollection($results);

        return $response;
    }

    /**
     * @param LseEntitySearchRequest $request
     * @return EntityListCollection
     */
    public function entitySearch(LseEntitySearchRequest $request)
    {
        $data = $request->validated();
        $results = $this->provider->search($data['search'], $data['entitiable_type']);

        return new EntityListCollection($results);
    }

    /**
     * @param LseRejectRequest $request
     * @param LseAsset $lseAsset
     * @return MessageResource
     */
    public function reject(LseRejectRequest $request, LseAsset $lseAsset)
    {
        $this->provider->reject($lseAsset);

        return new MessageResource([
            'message' => 'Rejected.'
        ]);
    }

    /**
     * @param LseAcceptAsCompanyRequest $request
     * @param LseAsset $lseAsset
     * @return MessageResource
     */
    public function acceptAsCompany(LseAcceptAsCompanyRequest $request, LseAsset $lseAsset)
    {
        $this->provider->accept($request->validated(), $lseAsset);

        return new MessageResource([
            'message' => 'Accepted as company.'
        ]);
    }

    /**
     * @param LseAttachToCompanyRequest $request
     * @param LseAsset $lseAsset
     * @return MessageResource
     */
    public function attachToCompany(LseAttachToCompanyRequest $request, LseAsset $lseAsset)
    {
        $this->provider->accept($request->validated(), $lseAsset);

        return new MessageResource([
            'message' => 'Attached to company.'
        ]);
    }

    /**
     * @param LsePreviewRequest $request
     * @param LseAsset $lseAsset
     * @return LseCompanyPreviewResource
     */
    public function companyPreview(LsePreviewRequest $request, LseAsset $lseAsset)
    {
        $lseAsset->load([
            'logo',
            'background',
            'socialMedia',
            'videoLinks'
        ]);

        return new LseCompanyPreviewResource($lseAsset);
    }
}
