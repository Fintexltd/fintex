<?php

namespace App\Http\Controllers;

use App\Http\Requests\PushRegister;
use App\Http\Resources\MessageResource;
use App\Services\PushService;

class PushController extends Controller
{
    /**
     * @param PushRegister $request
     * @return MessageResource
     */
    public function register(PushRegister $request)
    {
        $pushService = new PushService();
        $pushService->register($request->user(), $request->get('system'), $request->get('token'), $request->get('language'));

        $content = ['message' => 'ok'];

        return new MessageResource($content);
    }
}