<?php

namespace App\Http\Controllers;

use App\Criteria\CompanyFollowedCriteria;
use App\Criteria\CompanyManagedCriteria;
use App\Criteria\CompanySortByCriteria;
use App\Criteria\QueryColumnCriteria;
use App\Entities\Company;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Http\Requests\CompaniesAcceptRequest;
use App\Http\Requests\CompaniesDestroyRequest;
use App\Http\Requests\CompanyAdminIndexRequest;
use App\Http\Requests\CompanyDemoIndexRequest;
use App\Http\Requests\CompanyEditRequest;
use App\Http\Requests\FollowRequest;
use App\Http\Requests\CompanyIndexRequest;
use App\Http\Requests\CompanyListRequest;
use App\Http\Requests\CompanyOtherRequest;
use App\Http\Requests\CompanyRequestAdminIndexRequest;
use App\Http\Requests\CompanyShowRequest;
use App\Http\Requests\CompanyStoreRequest;
use App\Http\Requests\UnfollowRequest;
use App\Http\Requests\CompanyUpdateRequest;
use App\Http\Requests\CompanyFollowFiltersRequest;
use App\Http\Resources\CompanyCollection;
use App\Http\Resources\CompanyCollectionWithDefaultSorting;
use App\Http\Resources\CompanyDemoCollection;
use App\Http\Resources\CompanyEditResource;
use App\Http\Resources\EntityListCollection;
use App\Http\Resources\CompanyRequestCollection;
use App\Http\Resources\CompanyResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\OtherCompanyTileCollection;
use App\Repositories\CompanyRepository;
use App\Services\CompaniesCreator;
use App\Services\FollowService;
use App\Services\ViewsCounter;
use App\Services\RoleResolver;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    protected $companiesCreator;
    protected $followService;
    protected $repository;
    protected $viewsCounter;

    const COMPANIES_PER_PAGE = 16;
    const COMPANIES_REQUESTS_PER_PAGE = 10;

    public function __construct(
        CompaniesCreator $companiesCreator,
        CompanyRepository $repository,
        FollowService $followService,
        ViewsCounter $viewsCounter
    )
    {
        $this->companiesCreator = $companiesCreator;
        $this->followService = $followService;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param CompanyStoreRequest $request
     * @return MessageResource
     */
    public function store(CompanyStoreRequest $request)
    {
        $this->companiesCreator->handleStoreCompany($request->validated());

        $content = ['message' => 'Company created.'];

        return new MessageResource($content);
    }

    /**
     * @param CompanyEditRequest $request
     * @param Company $company
     * @return CompanyEditResource
     */
    public function edit(CompanyEditRequest $request, Company $company)
    {
        $company->load([
            'logo',
            'background',
            'industry',
            'country',
            'country.continent',
            'attachments',
            'links',
            'symbols',
            'symbols.ohlc52',
            'symbols.stockFeed',
            'seSymbols',
            'seSymbols.seOhlcv52',
            'socialMedia',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'demoIndividualKeys',
        ]);

        $this->viewsCounter->handleEntityView($company, $request->user());

        $response = new CompanyEditResource($company);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param CompanyUpdateRequest $request
     * @param Company $company
     * @return MessageResource
     */
    public function update(CompanyUpdateRequest $request, Company $company)
    {
        $this->companiesCreator->handleUpdateCompany($company, $request->validated());

        $content = ['message' => 'Company updated.'];

        return new MessageResource($content);
    }

    /**
     * @param CompanyIndexRequest $request
     * @return CompanyCollection
     */
    public function index(CompanyIndexRequest $request)
    {
        $validated = $request->validated();

        $this->repository->applyRequestCriteria($validated);

        $sortBy = request()->get('sort_by');

        if (data_get($validated, 'sort_by', CompanySortByCriteria::SORT_DEFAULT) === CompanySortByCriteria::SORT_DEFAULT && !RoleResolver::isDemoUser($request->user())) {

            srand((int)$validated['seed']);
            $ids = $this->repository->get(['id'])->pluck('id')->all();
            $total = count($ids);
            $lastPage = (int)ceil($total / self::COMPANIES_PER_PAGE) ?: 1;
            shuffle($ids);
            $page = (int)data_get($validated, 'page', 1);

            $links = [
                'first' => route('companies.index', array_merge($validated, ['page' => 1])),
                'last' => route('companies.index', array_merge($validated, ['page' => $lastPage])),
                'prev' => $page ? null : route('companies.index', array_merge($validated, ['page' => $page - 1])),
                'next' => ($page < $lastPage) ? route('companies.index', array_merge($validated, ['page' => $page + 1])) : null,
            ];

            $offset = ($page - 1) * self::COMPANIES_PER_PAGE;
            $records = array_slice($ids, $offset, self::COMPANIES_PER_PAGE);
            $results = $this
                ->repository
                ->scopeQuery(function ($query) use ($records) {
                    return $query->whereIn('id', $records);
                })
                ->with([
                    'logo',
                    'industry',
                    //TODO: to consider
//                    'symbols' => function($query){
//                        return $query->wherePivot('is_default', true);
//                    },
                    'country',
                ])
                ->get()
                ->keyBy('id');

            $isFollowingAll = $this->repository->pushCriteria(new CompanyFollowedCriteria($request->user()))->get(['id'])->count() === $total;

            $meta = [
                'current_page' => $page,
                'from' => count($records) ? ($offset + 1) : null,
                'last_page' => $lastPage,
                'path' => route('companies.index'),
                'per_page' => self::COMPANIES_PER_PAGE,
                'to' => count($records) ? ($offset + count($records)) : null,
                'total' => $total,
                'is_following_all' => $isFollowingAll,
            ];

            $data = collect($records)
                ->map(function ($id) use ($results) {
                    return $results->get($id);
                });

            $object = (object)[
                'data' => $data,
                'links' => $links,
                'meta' => $meta
            ];

            $response = new CompanyCollectionWithDefaultSorting($object);

            return $response;
        }

        $this->repository->pushCriteria(new CompanySortByCriteria($sortBy));

        $results = $this
            ->repository
            ->with([
                'logo',
                'industry',
                //TODO: to consider
//                'symbols' => function($query){
//                    return $query->wherePivot('is_default', true);
//                },
                'country',
            ])
            ->paginate(self::COMPANIES_PER_PAGE, ['*']);

        $isFollowingAll = $this->repository->pushCriteria(new CompanyFollowedCriteria($request->user()))->get(['id'])->count() === $results->total();

        $results->isFollowingAll = $isFollowingAll;

        $response = new CompanyCollection($results);

        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param CompanyListRequest $request
     * @return EntityListCollection
     */
    public function companiesList(CompanyListRequest $request)
    {
        $query = Company::query()
            ->where('is_accepted', true)
            ->orderBy('name');

        $user = $request->user();

        if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
            $managedRegions = Relation::query()
                ->where('user_id', $request->user()->id)
                ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
                ->pluck('related_id')
                ->all();

            $query->where(function ($query) use ($user, $managedRegions) {
                $query
                    ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                        $query->where('user_id', $user->id);
                    })
                    ->orWhereIn('country_id', $managedRegions);
            });
        }

        $result = $query->get(['id', 'name']);

        return new EntityListCollection($result);
    }

    /**
     * @param CompanyRequestAdminIndexRequest $request
     * @return CompanyRequestCollection
     */
    public function requestIndex(CompanyRequestAdminIndexRequest $request)
    {
        $perPage = (int)array_get($request->validated(), 'per_page', self::COMPANIES_REQUESTS_PER_PAGE);

        if (!RoleResolver::isGlobalAdmin($request->user()) && !RoleResolver::isContentAdmin($request->user())) {

            $managedCountries = Relation::query()
                ->where('user_id', $request->user()->id)
                ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
                ->pluck('related_id')
                ->all();

            $this->repository->scopeQuery(function ($query) use ($managedCountries) {
                return $query->whereIn('country_id', $managedCountries);
            });
        }

        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->pushCriteria(new QueryColumnCriteria('is_accepted', false));

        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new CompanySortByCriteria(CompanySortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'country',
                'country.continent',
                'industry',
                'industry.economicSector',
            ])
            ->paginate($perPage);

        return new CompanyRequestCollection($results);
    }

    /**
     * @param CompanyAdminIndexRequest $request
     * @return CompanyCollection
     */
    public function adminIndex(CompanyAdminIndexRequest $request)
    {
        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new CompanyManagedCriteria($request->user()));

        $this->repository->pushCriteria(new CompanySortByCriteria(CompanySortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
                'industry',
            ])
            ->paginate(self::COMPANIES_PER_PAGE, ['*']);

        return new CompanyCollection($results);
    }

    /**
     * @param CompanyAdminIndexRequest $request
     * @return CompanyDemoCollection
     */
    public function adminDemoIndex(CompanyDemoIndexRequest $request)
    {
        $data = $request->validated();
        $data['demo_relations'] = data_get($data, 'relations');
        unset($data['relations']);

        $this->repository->applyRequestCriteria($data);

        $this->repository->pushCriteria(new CompanySortByCriteria(CompanySortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
                'industry',
            ])
            ->paginate(self::COMPANIES_PER_PAGE, ['*']);

        return new CompanyDemoCollection($results);
    }

    /**
     * @param CompaniesAcceptRequest $request
     * @return MessageResource
     */
    public function acceptCompanies(CompaniesAcceptRequest $request)
    {
        $accept = $request->get('company_ids') ?? [];

        $this->companiesCreator->accept($accept);

        $content = ['message' => 'Companies accepted.'];

        return new MessageResource($content);
    }

    /**
     * @param CompaniesDestroyRequest $request
     * @return MessageResource
     */
    public function destroyCompanies(CompaniesDestroyRequest $request)
    {
        $delete = $request->get('company_ids') ?? [];

        $this->companiesCreator->destroy($delete);

        $content = ['message' => 'Companies deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param CompanyOtherRequest $request
     * @param Company $company
     * @return OtherCompanyTileCollection
     */
    public function other(CompanyOtherRequest $request, Company $company)
    {
        $result = $this->repository->otherCompanies($company, $request->all());

        return new OtherCompanyTileCollection($result);
    }

    /**
     * @param CompanyShowRequest $request
     * @param Company $company
     * @return CompanyResource
     */
    public function show(CompanyShowRequest $request, Company $company)
    {
        $company->load([
            'logo',
            'background',
            'industry',
            'country',
            'country.continent',
            'attachments',
            'links',
            'symbols',
            'symbols.ohlc52',
            'symbols.stockFeed',
            'seSymbols',
            'seSymbols.seOhlcv52',
            'socialMedia',
            'videos',
            'videoLinks'
        ]);

        $this->viewsCounter->handleEntityView($company, $request->user());

        $response = new CompanyResource($company);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FollowRequest $request
     * @param Company $company
     * @return MessageResource
     */
    public function follow(FollowRequest $request, Company $company)
    {
        $user = $request->user();

        $this->followService->follow($company, $user);

        $content = ['message' => 'You now are following company.'];

        return new MessageResource($content);
    }

    /**
     * @param UnfollowRequest $request
     * @param Company $company
     * @return MessageResource
     */
    public function unfollow(UnfollowRequest $request, Company $company)
    {
        $user = $request->user();
        $this->followService->unfollow($company, $user);

        $content = ['message' => 'You now are not following company.'];

        return new MessageResource($content);
    }

    /**
     * @param CompanyFollowFiltersRequest $request
     * @param Company $company
     * @return MessageResource
     */
    public function followFilters(CompanyFollowFiltersRequest $request, Company $company)
    {
        $user = $request->user();
        $this->repository->applyRequestCriteria($request->validated());

        $results = $this
            ->repository
            ->get(['id']);

        $this->followService->followFilters($company, $results, $user, $request->get('type'));

        $content = ['message' => 'Followed companies changed.'];

        return new MessageResource($content);
    }
}
