<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Startup;
use App\Http\Requests\StatisticsRequest;
use App\Http\Resources\StatisticCollection;
use App\Services\StatisticsService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class StatisticController extends Controller
{
    protected $service;

    public function __construct(StatisticsService $service)
    {
        $this->service = $service;
    }

    /**
     * @param StatisticsRequest $request
     * @param Company $entity
     * @return StatisticCollection
     */
    public function companyIndex(StatisticsRequest $request, Company $entity)
    {
        return self::index($request, $entity);
    }

    /**
     * @param StatisticsRequest $request
     * @param Startup $entity
     * @return StatisticCollection
     */
    public function startupIndex(StatisticsRequest $request, Startup $entity)
    {
        return self::index($request, $entity);
    }

    /**
     * @param StatisticsRequest $request
     * @param Fund $entity
     * @return StatisticCollection
     */
    public function fundIndex(StatisticsRequest $request, Fund $entity)
    {
        return self::index($request, $entity);
    }

    /**
     * @param StatisticsRequest $request
     * @param FundsManager $entity
     * @return StatisticCollection
     */
    public function fundsManagerIndex(StatisticsRequest $request, FundsManager $entity)
    {
        return self::index($request, $entity);
    }

    /**
     * @param StatisticsRequest $request
     * @param Model $entity
     * @return StatisticCollection
     */
    public function index(StatisticsRequest $request, Model $entity)
    {
        $params = $request->validated();
        $now = Carbon::now();

        $params['to'] = array_get($params, 'to') ?: $now->toDateString();
        $params['from'] = array_get($params, 'from') ?: $now->subYear()->toDateString();

        //$collection = $entity->statistics()
        $collection = $entity->statisticMocks()
            ->whereDate('date', '>=', $params['from'])
            ->whereDate('date', '<=', $params['to'])
            ->get();

        $result = $this
            ->service
            ->prepareData($collection, $params);

        $response = new StatisticCollection($result);
        $response->withoutWrapping();

        return $response;
    }
}
