<?php

namespace App\Http\Controllers;

use App\Criteria\ShareholderAcceptCriteria;
use App\Criteria\ShareholderEntityCriteria;
use App\Criteria\ShareholderStatusCriteria;
use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\Shareholder;
use App\Entities\Startup;
use App\Http\Requests\ShareholderActivateRequest;
use App\Http\Requests\ShareholderCancelRequest;
use App\Http\Requests\ShareholderMassUpdateRequest;
use App\Http\Requests\ShareholderRequestsIndexRequest;
use App\Http\Requests\ShareholderRequestsUserIndexRequest;
use App\Http\Requests\ShareholderStoreRequest;
use App\Http\Requests\ShareholderUpdateRequest;
use App\Http\Resources\AdminShareholderRequestCollection;
use App\Http\Resources\MessageResource;
use App\Http\Resources\UserShareholderRequestCollection;
use App\Repositories\ShareholderRepository;
use App\Services\RoleResolver;
use App\Services\ShareholderActivator;
use App\Services\ShareholdersCreator;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

//TODO
//TODO-STARTUPS
//refactor thiss and related class
class ShareholderController extends Controller
{
    protected $activator;
    protected $creator;
    protected $repository;

    const WATCHLIST_ITEMS_PER_PAGE = 10;

    public function __construct(ShareholderActivator $activator, ShareholdersCreator $creator, ShareholderRepository $repository)
    {
        $this->activator = $activator;
        $this->creator = $creator;
        $this->repository = $repository;
    }

    /**
     * @param ShareholderRequestsIndexRequest $request
     * @return AdminShareholderRequestCollection
     */
    public function requestsIndex(ShareholderRequestsIndexRequest $request)
    {
        $className = $this->getClassName($request);

        $this->repository->pushCriteria(new ShareholderAcceptCriteria());
        $this->repository->applyRequestCriteria($request->validated());

        $user = $request->user();
        if (!RoleResolver::isGlobalAdmin($user)) {
            $managed = $user
                ->relations()
                ->whereIn('type', [
                    User::RELATION_TYPE_PRIMARY_ADMIN,
                    User::RELATION_TYPE_SECONDARY_ADMIN,
                ])
                ->where('related_type', $className)
                ->get(['related_id'])
                ->pluck('related_id')
                ->all();

            $this->repository->pushCriteria(new ShareholderEntityCriteria($managed));
        }

        $results = $this
            ->repository
            ->scopeQuery(function ($query) use ($className){
                //TODO: refactor this bit
                $query = $query->whereHas('relation', function($query) use ($className){
                    if($className==Company::class) {
                        $query->whereHas('company');
                    } else if($className==Startup::class) {
                        $query->whereHas('startup');
                    } else {
                        $query->whereHas('fund', function($query){
                            $query->whereHas('fundsManager');
                        });
                    }

                });
                return $query;
            })
            ->with([
                'relation',
                'relation.user',
                'relation.related',
            ])
            ->paginate($request->query('per_page', self::WATCHLIST_ITEMS_PER_PAGE), ['*']);


        return new AdminShareholderRequestCollection($results);
    }

    /**
     * @param ShareholderRequestsUserIndexRequest $request
     * @return UserShareholderRequestCollection
     */
    public function requestsUserIndex(ShareholderRequestsUserIndexRequest $request)
    {
        $className = $this->getClassName($request);

        $userId = $request->user()->id;
        $search = $request->get('search');

        //TODO: refactor
        $this
            ->repository
            ->scopeQuery(function ($query) use ($userId, $search, $className) {
                return $query->whereHas('relation', function ($query) use ($userId, $search, $className) {
                    $query->where('user_id', $userId)
                        ->where(function ($query) use ($search, $className) {
                            if($className==Company::class) {
                                $table = 'company';
                            } else if($className==Startup::class) {
                                $table = 'startup';
                            } else {
                                $table = 'fund';
                            }

                            $query->whereHas($table, function ($query) use ($search) {
                                if ($search) {
                                    $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
                                    $query->where('name', 'LIKE', "%$search%");
                                };
                            });
                        });
                });
            });

        if ($request->get('status')) {
            $this->repository->pushCriteria(new ShareholderStatusCriteria($request->get('status')));
        }

        $results = $this
            ->repository
            ->with([
                'company',
                'fund',
                'startup',
                'user',
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new UserShareholderRequestCollection($results);
    }

    /**
     * @param ShareholderStoreRequest $request
     * @return MessageResource
     */
    public function store(ShareholderStoreRequest $request)
    {
        $this->creator->handleStoreShareholder($request->all());

        $content = ['message' => 'Shareholder request was sended.'];

        return new MessageResource($content);
    }

    /**
     * @param ShareholderUpdateRequest $request
     * @param Shareholder $shareholder
     * @return MessageResource
     */
    public function update(ShareholderUpdateRequest $request, Shareholder $shareholder)
    {
        $this->creator->handleUpdate($shareholder, $request->all());

        $content = ['message' => 'shareholder updated'];

        return new MessageResource($content);
    }

    /**
     * @param ShareholderMassUpdateRequest $request
     * @return MessageResource
     */
    public function massUpdate(ShareholderMassUpdateRequest $request)
    {
        $this->creator->handleMassUpdate($request->all());

        $content = ['message' => 'shareholders updated'];

        return new MessageResource($content);
    }

    /**
     * @param ShareholderActivateRequest $request
     * @return MessageResource
     */
    public function activate(ShareholderActivateRequest $request)
    {
        $shareholder = $request->shareholder;
        $response = $this
            ->activator
            ->processCode($shareholder, $request->get('code'));

        return response()->json($response['payload'], $response['code']);
    }

    /**
     * @param ShareholderCancelRequest $request
     * @param Shareholder $shareholder
     * @return MessageResource
     */
    public function destroy(ShareholderCancelRequest $request, Shareholder $shareholder)
    {
        $shareholder->relation()->delete();
        $shareholder->delete();

        $content = ['message' => 'Request was canceled.'];

        return new MessageResource($content);
    }

    private function getClassName($request)
    {
        $className = '';
        switch($request->route('type')) {
            case 'shareholders':
                $className = Company::class;
                break;
            case 'investors':
                $className = Fund::class;
                break;
            case 'startup-investors':
                $className = Startup::class;
                break;
        }

        return $className;
    }
}
