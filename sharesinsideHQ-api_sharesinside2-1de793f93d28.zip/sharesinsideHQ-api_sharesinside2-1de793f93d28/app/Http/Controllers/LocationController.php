<?php

namespace App\Http\Controllers;

use App\Http\Requests\LocationIndexRequest;
use App\Http\Requests\LocationSuggestedRequest;
use App\Http\Resources\LocationCollection;
use App\Repositories\LocationRepository;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    protected $repository;

    public function __construct(LocationRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param LocationIndexRequest $request
     * @return LocationCollection
     */
    public function index(LocationIndexRequest $request)
    {
        $results = $this->repository
            ->getLocations();

        return new LocationCollection($results);
    }

    /**
     * @param LocationSuggestedRequest $request
     * @return LocationCollection
     */
    public function suggested(LocationSuggestedRequest $request)
    {
        $results = $this->repository
            ->getSuggested($request->user());

        return new LocationCollection($results);
    }
}
