<?php

namespace App\Http\Controllers;

use App\Http\Requests\SeExternalManageSymbolRequest;
use App\Http\Requests\SeExternalManagePriceRequest;
use App\Http\Resources\MessageResource;
use App\Services\SeExternalService;

class SeExternalController extends Controller
{
    private $service;

    public function __construct(SeExternalService $service)
    {
        $this->service = $service;
    }

    /**
     * @param SeCompanyChartsRequest $request
     * @return MessageResource
     */
    public function manageSymbol(SeExternalManageSymbolRequest $request)
    {
        $this->service->handleManageSymbol($request->validated());

        return new MessageResource(['message' => 'Success']);
    }

    /**
     * @param SeFundChartsRequest $request
     * @return MessageResource
     */
    public function managePrice(SeExternalManagePriceRequest $request)
    {
        $this->service->handleManagePrice($request->validated());

        return new MessageResource(['message' => 'Success']);
     }

}
