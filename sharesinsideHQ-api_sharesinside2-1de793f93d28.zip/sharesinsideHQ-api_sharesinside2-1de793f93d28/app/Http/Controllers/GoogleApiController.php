<?php

namespace App\Http\Controllers;

use App\Http\Requests\GoogleApiAddressInfoRequest;
use App\Services\GoogleApiService;

class GoogleApiController extends Controller
{
    private $googleApiService;

    public function __construct(GoogleApiService $googleApiService)
    {
        $this->googleApiService = $googleApiService;
    }

    /**
     * @param GoogleApiAddressInfoRequest
     * @return \Illuminate\Http\JsonResponse
     */
    public function addressInfo(GoogleApiAddressInfoRequest $request)
    {
        $addressInfo = $this->googleApiService->getAddressInfo($request['address']);
        return response()->json($addressInfo, 201);
    }
}
