<?php

namespace App\Http\Controllers;

use App\Criteria\FundsManagerFollowedCriteria;
use App\Criteria\FundsManagerManagedCriteria;
use App\Criteria\FundsManagerSortByCriteria;
use App\Criteria\QueryColumnCriteria;
use App\Entities\FundsManager;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Http\Requests\FundsManagersAcceptRequest;
use App\Http\Requests\FundsManagersDestroyRequest;
use App\Http\Requests\FundsManagerAdminIndexRequest;
use App\Http\Requests\FundsManagerDemoIndexRequest;
use App\Http\Requests\FundsManagerEditRequest;
use App\Http\Requests\FollowRequest;
use App\Http\Requests\FundsManagerIndexRequest;
use App\Http\Requests\FundsManagerListRequest;
use App\Http\Requests\FundsManagerListWithFundsRequest;
use App\Http\Requests\FundsManagerOtherRequest;
use App\Http\Requests\FundsManagerRequestAdminIndexRequest;
use App\Http\Requests\FundsManagerShowRequest;
use App\Http\Requests\FundsManagerStoreRequest;
use App\Http\Requests\UnfollowRequest;
use App\Http\Requests\FundsManagerUpdateRequest;
use App\Http\Requests\FundsManagerFollowFiltersRequest;
use App\Http\Resources\FundsManagerCollection;
use App\Http\Resources\FundsManagerCollectionWithDefaultSorting;
use App\Http\Resources\FundsManagerDemoCollection;
use App\Http\Resources\FundsManagerEditResource;
use App\Http\Resources\EntityListCollection;
use App\Http\Resources\FundsManagerListWithFundsCollection;
use App\Http\Resources\FundsManagerRequestCollection;
use App\Http\Resources\FundsManagerResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\OtherFundsManagerTileCollection;
use App\Repositories\FundsManagerRepository;
use App\Services\FundsManagerCreator;
use App\Services\RoleResolver;
use App\Services\FollowService;
use App\Services\ViewsCounter;
use Illuminate\Http\Request;

class FundsManagerController extends Controller
{
    protected $fundsManagerCreator;
    protected $followService;
    protected $repository;
    protected $viewsCounter;

    const FUNDS_MANAGERS_PER_PAGE = 16;
    const FUNDS_MANAGERS_REQUESTS_PER_PAGE = 10;

    public function __construct(
        FundsManagerCreator $fundsManagerCreator,
        FundsManagerRepository $repository,
        FollowService $followService,
        ViewsCounter $viewsCounter
    )
    {
        $this->fundsManagerCreator = $fundsManagerCreator;
        $this->followService = $followService;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param FundsManagerStoreRequest $request
     * @return MessageResource
     */
    public function store(FundsManagerStoreRequest $request)
    {
        $this->fundsManagerCreator->handleStoreFundsManager($request->validated());

        $content = ['message' => 'Funds manager created.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsManagerEditRequest $request
     * @param FundsManager $fundsManager
     * @return FundsManagerEditResource
     */
    public function edit(FundsManagerEditRequest $request, FundsManager $fundsManager)
    {
        $fundsManager->load([
            'logo',
            'background',
            'countryCallingCode',
            'attachments',
            'links',
            'socialMedia',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'termsAndConditions',
            'termsAndConditionsLinks',
            'demoIndividualKeys',
        ]);

        $this->viewsCounter->handleEntityView($fundsManager, $request->user());

        $response = new FundsManagerEditResource($fundsManager);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FundsManagerUpdateRequest $request
     * @param FundsManager $fundsManager
     * @return MessageResource
     */
    public function update(FundsManagerUpdateRequest $request, FundsManager $fundsManager)
    {
        $this->fundsManagerCreator->handleUpdateFundsManager($fundsManager, $request->validated());

        $content = ['message' => 'Funds manager updated.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsManagerIndexRequest $request
     * @return FundsManagerCollection
     */
    public function index(FundsManagerIndexRequest $request)
    {
        $validated = $request->validated();

        $this->repository->applyRequestCriteria($validated);

        $sortBy = request()->get('sort_by');

        if (data_get($validated, 'sort_by', FundsManagerSortByCriteria::SORT_DEFAULT) === FundsManagerSortByCriteria::SORT_DEFAULT) {

            srand((int)$validated['seed']);
            $ids = $this->repository->get(['id'])->pluck('id')->all();
            $total = count($ids);
            $lastPage = (int)ceil($total / self::FUNDS_MANAGERS_PER_PAGE) ?: 1;
            shuffle($ids);
            $page = (int)data_get($validated, 'page', 1);

            $links = [
                'first' => route('funds-managers.index', array_merge($validated, ['page' => 1])),
                'last' => route('funds-managers.index', array_merge($validated, ['page' => $lastPage])),
                'prev' => $page ? null : route('funds-managers.index', array_merge($validated, ['page' => $page - 1])),
                'next' => ($page < $lastPage) ? route('funds-managers.index', array_merge($validated, ['page' => $page + 1])) : null,
            ];

            $offset = ($page - 1) * self::FUNDS_MANAGERS_PER_PAGE;
            $records = array_slice($ids, $offset, self::FUNDS_MANAGERS_PER_PAGE);
            $results = $this
                ->repository
                ->scopeQuery(function ($query) use ($records) {
                    return $query->whereIn('id', $records);
                })
                ->with([
                    'logo'
                ])
                ->get()
                ->keyBy('id');

            $isFollowingAll = $this->repository->pushCriteria(new FundsManagerFollowedCriteria($request->user()))->get(['id'])->count() === $total;

            $meta = [
                'current_page' => $page,
                'from' => count($records) ? ($offset + 1) : null,
                'last_page' => $lastPage,
                'path' => route('funds-managers.index'),
                'per_page' => self::FUNDS_MANAGERS_PER_PAGE,
                'to' => count($records) ? ($offset + count($records)) : null,
                'total' => $total,
                'is_following_all' => $isFollowingAll,
            ];

            $data = collect($records)
                ->map(function ($id) use ($results) {
                    return $results->get($id);
                });

            $object = (object)[
                'data' => $data,
                'links' => $links,
                'meta' => $meta
            ];

            $response = new FundsManagerCollectionWithDefaultSorting($object);

            return $response;
        }

        $this->repository->pushCriteria(new FundsManagerSortByCriteria($sortBy));

        $results = $this
            ->repository
            ->with([
                'logo'
            ])
            ->paginate(self::FUNDS_MANAGERS_PER_PAGE, ['*']);

        $isFollowingAll = $this->repository->pushCriteria(new FundsManagerFollowedCriteria($request->user()))->get(['id'])->count() === $results->total();

        $results->isFollowingAll = $isFollowingAll;

        $response = new FundsManagerCollection($results);

        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FundsManagerListRequest $request
     * @return EntityListCollection
     */
    public function fundsManagersList(FundsManagerListRequest $request)
    {
        $query = FundsManager::query()
            ->where('is_accepted', true)
            ->orderBy('name');

        $user = $request->user();

        if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
            $query->where(function ($query) use ($user) {
                $query
                    ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                        $query->where('user_id', $user->id);
                    });
            });
        }

        $result = $query->get(['id', 'name']);

        return new EntityListCollection($result);
    }

    /**
     * @param FundsManagerListWithFundsRequest $request
     * @return FundsManagerListWithFundsCollection
     */
    public function fundsManagersListWithFunds(FundsManagerListWithFundsRequest $request)
    {
        $user = $request->user();

        $query = FundsManager::query()
            ->with([
                'funds' => function ($query) use ($user) {
                    $query
                        ->where('is_accepted', true)
                        ->orderBy('name');

                    if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
                        $query
                            ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                                $query->where('user_id', $user->id);
                            });
                    }
                }
            ])
            ->where('is_accepted', true)
            ->orderBy('name');

        if (!RoleResolver::isGlobalAdmin($user) && !RoleResolver::isContentAdmin($user)) {
            $query
                ->whereHas('primaryAndSecondary', function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                });
        }

        $result = $query->get();

        return new FundsManagerListWithFundsCollection($result);
    }

    /**
     * @param FundsManagerRequestAdminIndexRequest $request
     * @return FundsManagerRequestCollection
     */
    public function requestIndex(FundsManagerRequestAdminIndexRequest $request)
    {
        $perPage = (int)array_get($request->validated(), 'per_page', self::FUNDS_MANAGERS_REQUESTS_PER_PAGE);

        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->pushCriteria(new QueryColumnCriteria('is_accepted', false));

        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new FundsManagerSortByCriteria(FundsManagerSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'countryCallingCode'
            ])
            ->paginate($perPage);

        return new FundsManagerRequestCollection($results);
    }

    /**
     * @param FundsManagerAdminIndexRequest $request
     * @return FundsManagerCollection
     */
    public function adminIndex(FundsManagerAdminIndexRequest $request)
    {
        $this->repository->popCriteria(QueryColumnCriteria::class);
        $this->repository->applyRequestCriteria($request->validated());

        $this->repository->pushCriteria(new FundsManagerManagedCriteria($request->user()));

        $this->repository->pushCriteria(new FundsManagerSortByCriteria(FundsManagerSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo'
            ])
            ->paginate(self::FUNDS_MANAGERS_PER_PAGE, ['*']);

        return new FundsManagerCollection($results);
    }

    /**
     * @param FundsManagerDemoIndexRequest $request
     * @return FundsManagerDemoCollection
     */
    public function adminDemoIndex(FundsManagerDemoIndexRequest $request)
    {
        $data = $request->validated();
        $data['demo_relations'] = data_get($data, 'relations');
        unset($data['relations']);

        $this->repository->applyRequestCriteria($data);

        $this->repository->pushCriteria(new FundsManagerSortByCriteria(FundsManagerSortByCriteria::SORT_NEW_FIRST));

        $results = $this
            ->repository
            ->with([
                'logo',
            ])
            ->paginate(self::FUNDS_MANAGERS_PER_PAGE, ['*']);

        return new FundsManagerDemoCollection($results);
    }

    /**
     * @param FundsManagersAcceptRequest $request
     * @return MessageResource
     */
    public function acceptFundsManagers(FundsManagersAcceptRequest $request)
    {
        $accept = $request->get('funds_manager_ids') ?? [];

        $this->fundsManagerCreator->accept($accept);

        $content = ['message' => 'Funds managers accepted.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsManagersDestroyRequest $request
     * @return MessageResource
     */
    public function destroyFundsManagers(FundsManagersDestroyRequest $request)
    {
        $delete = $request->get('funds_manager_ids') ?? [];

        $this->fundsManagerCreator->destroy($delete);

        $content = ['message' => 'Funds managers deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsManagerOtherRequest $request
     * @param FundsManager $fundsManager
     * @return OtherFundsManagerTileCollection
     */
    public function other(FundsManagerOtherRequest $request, FundsManager $fundsManager)
    {
        $result = $this->repository->otherFundsManagers($fundsManager, $request->all());

        return new OtherFundsManagerTileCollection($result);
    }

    /**
     * @param FundsManagerShowRequest $request
     * @param FundsManager $fundsManager
     * @return FundsManagerResource
     */
    public function show(FundsManagerShowRequest $request, FundsManager $fundsManager)
    {
        $fundsManager->load([
            'logo',
            'background',
            'countryCallingCode',
            'attachments',
            'links',
            'socialMedia',
            'excluded',
            'excluded.country',
            'videos',
            'videoLinks',
            'termsAndConditions',
            'termsAndConditionsLinks'
        ]);

        $this->viewsCounter->handleEntityView($fundsManager, $request->user());

        $response = new FundsManagerResource($fundsManager);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param FollowRequest $request
     * @param FundsManager $fundsManager
     * @return MessageResource
     */
    public function follow(FollowRequest $request, FundsManager $fundsManager)
    {
        $user = $request->user();

        $this->followService->follow($fundsManager, $user);

        $content = ['message' => 'You now are following funds manager.'];

        return new MessageResource($content);
    }

    /**
     * @param UnfollowRequest $request
     * @param FundsManager $fundsManager
     * @return MessageResource
     */
    public function unfollow(UnfollowRequest $request, FundsManager $fundsManager)
    {
        $user = $request->user();
        $this->followService->unfollow($fundsManager, $user);

        $content = ['message' => 'You now are not following funds manager.'];

        return new MessageResource($content);
    }

    /**
     * @param FundsManagerFollowFiltersRequest $request
     * @param FundsManager $fundsManager
     * @return MessageResource
     */
    public function followFilters(FundsManagerFollowFiltersRequest $request, FundsManager $fundsManager)
    {
        $user = $request->user();
        $this->repository->applyRequestCriteria($request->validated());

        $results = $this
            ->repository
            ->get(['id']);

        $this->followService->followFilters($fundsManager, $results, $user, $request->get('type'));

        $content = ['message' => 'Followed funds managers changed.'];

        return new MessageResource($content);
    }
}
