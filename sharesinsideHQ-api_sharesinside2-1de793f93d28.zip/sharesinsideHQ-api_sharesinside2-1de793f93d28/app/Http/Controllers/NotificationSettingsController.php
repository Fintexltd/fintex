<?php

namespace App\Http\Controllers;

use App\Entities\NotificationSettings;
use App\Http\Requests\NotificationSettingsShowRequest;
use App\Http\Requests\NotificationSettingsUpdateRequest;
use App\Http\Resources\MessageResource;
use App\Http\Resources\NotificationSettingsResource;
use App\Services\NotificationSettingsService;
use Illuminate\Http\Request;

class NotificationSettingsController extends Controller
{
    protected $service;

    public function __construct(NotificationSettingsService $service)
    {
        $this->service = $service;
    }

    /**
     * @param NotificationSettingsShowRequest $request
     * @return NotificationSettingsResource
     */
    public function show(NotificationSettingsShowRequest $request)
    {
        //TODO: consder if this is necessary - registered user alway should have notifficationSettings
        $response = new NotificationSettingsResource($request->user()->NotificationSettings ?: new NotificationSettings());
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param NotificationSettingsUpdateRequest $request
     * @return MessageResource
     */
    public function update(NotificationSettingsUpdateRequest $request)
    {
        $this->service->handleUpdate($request->user(), $request->validated());

        $content = ['message' => 'Notification settings updated.'];

        return new MessageResource($content);
    }
}
