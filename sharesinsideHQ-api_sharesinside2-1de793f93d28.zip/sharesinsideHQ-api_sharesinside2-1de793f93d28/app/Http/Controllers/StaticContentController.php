<?php

namespace App\Http\Controllers;

use App\Http\Requests\EditStaticContentRequest;
use App\Http\Requests\UpdateStaticContentRequest;
use App\Http\Resources\MessageResource;
use App\Services\StaticContentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class StaticContentController extends Controller
{
    protected $service;

    public function __construct(StaticContentService $service)
    {
        $this->service = $service;
    }

    /**
     * @param string $type
     * @return MessageResource|\Illuminate\Http\JsonResponse
     */
    public function getContent(string $type)
    {
        switch ($type) {
            case 'terms':
                $viewName = 'static.terms';
                break;
            case 'privacy_policy':
                $viewName = 'static.privacy_policy';
                break;
            default:
                return response()->json(['error' => 'The type of document should be either terms or privacy_policy.'], 405);
        }

        $file = $this->service->getFilePath($type);

        $content = file_exists($file) ? file_get_contents($file) : $content = View::make($viewName)->render();

        return new MessageResource(['message' => $content]);
    }

    /**
     * @param EditStaticContentRequest $request
     * @param string $type
     * @return MessageResource
     */
    public function edit(EditStaticContentRequest $request, string $type)
    {
        $response = $this->service->getType($type);

        return new MessageResource($response);
    }

    /**
     * @param UpdateStaticContentRequest $request
     * @param string $type
     * @return MessageResource
     */
    public function update(UpdateStaticContentRequest $request, string $type)
    {
        $this->service->handleUpdate($type, $request->validated());

        $response = ['message' => "$type updated."];

        return new MessageResource($response);
    }

}
