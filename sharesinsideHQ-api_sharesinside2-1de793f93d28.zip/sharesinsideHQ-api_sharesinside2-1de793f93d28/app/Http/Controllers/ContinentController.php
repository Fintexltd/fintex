<?php

namespace App\Http\Controllers;

use App\Entities\Continent;
use App\Http\Requests\ContinentIndexRequest;
use App\Http\Resources\ContinentCollection;
use Illuminate\Http\Request;

class ContinentController extends Controller
{

    /**
     * @param ContinentIndexRequest $request
     * @return ContinentCollection
     */
    public function index(ContinentIndexRequest $request)
    {
        $resource = Continent::orderBy('continent_name', 'ASC')
            ->get();

        return new ContinentCollection($resource);
    }
}
