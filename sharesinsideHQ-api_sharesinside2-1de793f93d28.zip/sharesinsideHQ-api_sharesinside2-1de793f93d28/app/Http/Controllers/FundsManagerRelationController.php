<?php

namespace App\Http\Controllers;

use App\Criteria\FundsManagerRelationsCriteria;
use App\Criteria\RelationsForFundsRoleByFundsManagerCriteria;
use App\Criteria\RelationsForFundsManagerCriteria;
use App\Entities\FundsManager;
use App\Http\Controllers\Traits\FundsManagerAndFundRelationControllerTrait;
use App\Http\Requests\DeleteFundsManagerRelationsRequest;
use App\Http\Requests\DeleteFundsRelationsRequest;
use App\Http\Requests\RelationNamesRequest;
use App\Http\Requests\RelationFundsManagerUsersIndexRequest;
use App\Http\Requests\UserRelationIndexRequest;
use App\Http\Requests\UserRelationsIndexRequest;
use App\Http\Resources\NameCollection;
use App\Http\Resources\RelationFundsManagerForUserAdminCollection;
use App\Http\Resources\RelationUsersForFundsManagerAdminCollection;
use App\Http\Resources\UserRelationCollection;
use App\Repositories\RelationRepository;
use App\Services\FundsManagerRelationService;
use App\User;

class FundsManagerRelationController extends Controller
{
    use FundsManagerAndFundRelationControllerTrait;

    const DEFAULT_PER_PAGE = 10;

    protected $repository;
    protected $service;

    public function __construct(RelationRepository $repository, FundsManagerRelationService $service)
    {
        $this->repository = $repository;
        $this->service = $service;
    }

    /**
     * @param UserRelationIndexRequest
     * @return UserRelationCollection
     */
    public function index(UserRelationIndexRequest $request)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $criteria = new FundsManagerRelationsCriteria($request->user(), $request->validated());

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        return new UserRelationCollection($result);
    }

    /**
     * @param RelationNamesRequest
     * @return NameCollection
     */
    public function fundsManagerNames(RelationNamesRequest $request)
    {
        $result = $this->repository->getEntityNames($request->user(), $request->validated(), FundsManager::class);

        $response = new NameCollection($result);
        $response->withoutWrapping();

        return $response;
    }

    public function indexFundsManagerRelated(RelationFundsManagerUsersIndexRequest $request, FundsManager $fundsManager)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $data = $request->validated();

        if ($request->get('relation')=='admins') {
            $criteria = new RelationsForFundsManagerCriteria($fundsManager, $data);
        } else {
            $criteria = new RelationsForFundsRoleByFundsManagerCriteria($fundsManager, $data);
        }

        $result = $this->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->loadMissing([
            'related',
            'user',
            'user.country',
        ]);

        $response = new RelationUsersForFundsManagerAdminCollection($result);

        return $response;
    }

    public function indexUserRelations(UserRelationsIndexRequest $request, User $user)
    {
        $perPage = array_get($request->validated(), 'per_page', self::DEFAULT_PER_PAGE);

        $data = $this->prepareCriteriaData($request->validated());

        $criteria = new FundsManagerRelationsCriteria($user, $data);

        $result = $this
            ->repository
            ->scopeQuery($criteria->appendQuery())
            ->paginate($perPage, ['*']);

        $result->load('related');

        $response = new RelationFundsManagerForUserAdminCollection($result);

        return $response;
    }

    public function deleteFundsManagerRelated(DeleteFundsManagerRelationsRequest $request, FundsManager $fundsManager)
    {
        $this->service->handleMassResign($request->validated());
    }

    public function deleteFundsRelated(DeleteFundsRelationsRequest $request, FundsManager $fundsManager)
    {
        $this->service->handleFundsMassResign($request->validated());
    }
}
