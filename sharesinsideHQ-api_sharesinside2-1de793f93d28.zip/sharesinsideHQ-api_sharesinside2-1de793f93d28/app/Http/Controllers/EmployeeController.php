<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Entities\Employee;
use App\Entities\FundsManager;
use App\Entities\Section;
use App\Entities\Startup;
use App\Entities\SectionInterface;
use App\Http\Requests\EmployeeDeleteRequest;
use App\Http\Requests\EmployeeRequestIndex;
use App\Http\Requests\EmployeeStoreRequest;
use App\Http\Requests\EmployeeUpdateRequest;
use App\Http\Resources\EmployeeSectionCollection;
use App\Http\Resources\MessageResource;
use App\Services\EmployeeCreator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    protected $employeeCreator;

    const COMPANIES_PER_PAGE = 16;

    public function __construct(EmployeeCreator $employeeCreator)
    {
        $this->employeeCreator = $employeeCreator;
    }

    /**
     * @param EmployeeStoreRequest $request
     * @return MessageResource
     */
    public function store(EmployeeStoreRequest $request)
    {
        $this->employeeCreator->handleStoreEmployee($request->all());

        $content = ['message' => 'Employee created.'];

        return new MessageResource($content);
    }

    /**
     * @param EmployeeUpdateRequest $request
     * @param Employee $employee
     * @return MessageResource
     */
    public function update(EmployeeUpdateRequest $request, Employee $employee)
    {
        $this->employeeCreator->handleUpdateEmployee($employee, $request->validated());

        $content = ['message' => 'Employee updated.'];

        return new MessageResource($content);
    }

    /**
     * @param EmployeeDeleteRequest $request
     * @param Employee $employee
     * @return MessageResource
     */
    public function destroy(EmployeeDeleteRequest $request, Employee $employee)
    {
        $this->employeeCreator->handleDestroyEmployee($employee);

        $content = ['message' => 'Employee deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param EmployeeRequestIndex $request
     * @param Company $company
     * @return EmployeeSectionCollection
     */
    public function companyIndex(EmployeeRequestIndex $request, Company $company)
    {
        return $this->index($request, $company);
    }

    /**
     * @param EmployeeRequestIndex $request
     * @param Startup $startup
     * @return EmployeeSectionCollection
     */
    public function startupIndex(EmployeeRequestIndex $request, Startup $startup)
    {
        return $this->index($request, $startup);
    }

    /**
     * @param EmployeeRequestIndex $request
     * @param FundsManager $fundsManager
     * @return EmployeeSectionCollection
     */
    public function fundsManagerIndex(EmployeeRequestIndex $request, FundsManager $fundsManager)
    {
        return $this->index($request, $fundsManager);
    }

    /**
     * @param EmployeeRequestIndex $request
     * @param Company $company
     * @return EmployeeSectionCollection
     */
    public function index(EmployeeRequestIndex $request, Model $entity)
    {
        $sections = $entity->sections()
            ->where('type', SectionInterface::EMPLOYEE_SECTION)
            ->with([
                'employees',
                'employees.photo',
                'employees.attachment',
            ])
            ->get();

        $response = new EmployeeSectionCollection($sections);
        $response->withoutWrapping();

        return $response;
    }

}
