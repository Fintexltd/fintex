<?php

namespace App\Http\Controllers;

use App\Criteria\RelationUserCriteria;
use App\Entities\RelationInterface;
use App\Entities\SecurityToken;
use App\Http\Requests\ExportRelationDataRequest;
use App\Http\Requests\UserDataExportTokenRequest;
use App\Http\Requests\UserDataPreviewRequest;
use App\Http\Resources\MessageResource;
use App\Http\Resources\RelationCollection;
use App\Http\Resources\UserDataCollection;
use App\Repositories\RelationRepository;
use App\Services\UserDataService;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class UserDataController extends Controller
{

    const ITEMS_PER_PAGE = 10;

    protected $repository;

    public function __construct(RelationRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param UserDataPreviewRequest $request
     * @return UserDataCollection
     */
    public function preview(UserDataPreviewRequest $request)
    {
        $this->repository->pushCriteria(new RelationUserCriteria($request->user()));

        $relations = data_get($request, 'relations', ['follower', 'shareholder', 'vip']);

        $results = [];

        foreach ($relations as $type) {
            $result = $this
                ->repository
                ->with(['related', 'shareholder', 'shareholder.country'])
                ->scopeQuery($this->resolveScope($type))
                ->paginate(self::ITEMS_PER_PAGE, ['*']);

            $results[$type] = new RelationCollection($result);
        }

        return $results;
    }

    public function createSecurityToken(UserDataExportTokenRequest $request)
    {
        $token = new SecurityToken();
        $token->type = SecurityToken::EXPORT_MY_RELATION_DATA;
        $token->generateUniqueToken();
        $token->valid_until = \Carbon\Carbon::now()
            ->addHours(SecurityToken::TOKEN_VALID_PERIOD_IN_HOURS[SecurityToken::EXPORT_MY_RELATION_DATA]);
        $token->user_id = $request->user()->id;
        $token->save();

        $content = [
            'token' => $token->token,
        ];

        return new MessageResource($content);
    }

    public function file(ExportRelationDataRequest $request)
    {
        $service = new UserDataService();

        $token = SecurityToken::query()->where('token', $request->get('token'))->first();

        $user = $token->user;

        $token->delete();

        $file = $service->exportData($user);

        $response = new BinaryFileResponse($file);
        $response->deleteFileAfterSend(true);
        $response->headers->add([
            'Content-disposition' => 'attachment; filename="sharesinside-data.xls"'
        ]);

        return $response;
    }

    private function resolveScope(string $type)
    {
        switch ($type) {
            case RelationInterface::RELATION_TYPE_SHAREHOLDER:
                $array = [
                    RelationInterface::RELATION_TYPE_SHAREHOLDER,
                    RelationInterface::RELATION_TYPE_SHAREHOLDER_PENDING,
                    RelationInterface::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM,
                ];
                break;
            default:
                $array = [$type];
        }

        return function ($query) use ($array) {
            return $query->whereIn('type', $array);
        };
    }

}
