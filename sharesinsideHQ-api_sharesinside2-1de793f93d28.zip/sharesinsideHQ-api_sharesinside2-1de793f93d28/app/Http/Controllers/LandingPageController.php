<?php

namespace App\Http\Controllers;

use App\Http\Requests\LandingPageIndexRequest;
use App\Http\Requests\LandingPageUpdateRequest;
use App\Http\Resources\MessageResource;
use App\Services\LandingPageService;
use Illuminate\Http\Request;

class LandingPageController extends Controller
{

    protected $service;

    public function __construct(LandingPageService $service)
    {
        $this->service = $service;
    }

    /**
     * @param LandingPageIndexRequest $request
     * @return MessageResource
     */
    public function index(LandingPageIndexRequest $request)
    {
        return new MessageResource($this->service->index());
    }

    /**
     * @param LandingPageUpdateRequest $request
     * @return MessageResource
     */
    public function update(LandingPageUpdateRequest $request)
    {
        $this->service->update($request->all());

        $response = ['message' => 'Landing page updated.'];

        return new MessageResource($response);
    }
}
