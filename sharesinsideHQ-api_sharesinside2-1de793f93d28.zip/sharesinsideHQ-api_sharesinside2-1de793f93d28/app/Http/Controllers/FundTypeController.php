<?php

namespace App\Http\Controllers;

use App\Entities\FundType;
use App\Events\FundTypeCreated;
use App\Http\Requests\FundTypeDeleteRequest;
use App\Http\Requests\FundTypeIndexRequest;
use App\Http\Requests\FundTypeStoreRequest;
use App\Http\Requests\FundTypeUpdateRequest;
use App\Http\Resources\FundTypeCollection;
use App\Http\Resources\MessageResource;
use Illuminate\Http\Request;

class FundTypeController extends Controller
{
    /**
     * @param FundTypeIndexRequest $request
     * @return FundTypeCollection
     */
    public function index(FundTypeIndexRequest $request)
    {
        $query = FundType::query();

        if ($search = $request->get('search')) {
            $query->where('name', 'LIKE', "%$search%");
        }

        $results = $query
            ->orderBy('sort_order', 'ASC')
            ->orderBy('name', 'ASC')
            ->get();

        return new FundTypeCollection($results);
    }

    /**
     * @param FundTypeStoreRequest $request
     * @return MessageResource
     */
    public function store(FundTypeStoreRequest $request)
    {
        $data = $request->validated();
        $data['sort_order'] = $data['name'];

        $fundType = FundType::create($data);

        event(new FundTypeCreated($fundType));

        $response = [
            'message' => 'Fund type created',
            'fund_type_id' => $fundType->id,
        ];

        return new MessageResource($response);
    }

    /**
     * @param FundTypeUpdateRequest $request
     * @param FundType $fundType
     * @return MessageResource
     */
    public function update(FundTypeUpdateRequest $request, FundType $fundType)
    {
        $data = $request->validated();
        $data['sort_order'] = $data['name'];

        $fundType->update($data);

        $response = ['message' => 'Fund type updated'];

        return new MessageResource($response);
    }

    /**
     * @param FundTypeDeleteRequest $request
     * @param FundType $fundType
     * @return MessageResource
     */
    public function destroy(FundTypeDeleteRequest $request, FundType $fundType)
    {
        $fundType->delete();

        $response = ['message' => 'Fund type removed'];

        return new MessageResource($response);
    }
}
