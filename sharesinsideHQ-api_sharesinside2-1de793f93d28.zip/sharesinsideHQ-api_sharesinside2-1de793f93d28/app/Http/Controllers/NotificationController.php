<?php

namespace App\Http\Controllers;

use App\Entities\Notification;
use App\Http\Requests\NotificationDeleteRequest;
use App\Http\Requests\NotificationIndexRequest;
use App\Http\Requests\NotificationIndicatorRequest;
use App\Http\Requests\NotificationShowRequest;
use App\Http\Resources\MessageResource;
use App\Http\Resources\NotificationCollection;
use App\Http\Resources\NotificationIndicatorResource;
use App\Http\Resources\NotificationResource;
use App\Repositories\NotificationRepository;
use App\Services\NotificationListService;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    protected $repository;
    protected $service;

    /**
     * NotificationController constructor.
     */
    public function __construct(NotificationRepository $repository, NotificationListService $service)
    {
        $this->repository = $repository;
        $this->service = $service;
    }

    /**
     * @param NotificationIndexRequest $request
     * @return NotificationCollection
     */
    public function index(NotificationIndexRequest $request)
    {
        $this->service->setReadAll($request->user());

        $result = $this
            ->repository
            ->applyRequestCriteria([
                'user_id' => $request->user()->id,
            ])
            ->paginate(10);

        return new NotificationCollection($result);
    }

    /**
     * @param NotificationShowRequest $request
     * @param Notification $notification
     * @return NotificationResource
     */
    public function show(NotificationShowRequest $request, Notification $notification)
    {
        $notification = $this->service->setRead($notification, $request->user());

        return new NotificationResource($notification);
    }

    /**
     * @param NotificationIndicatorRequest $request
     * @return NotificationIndicatorResource
     */
    public function indicator(NotificationIndicatorRequest $request)
    {
        $counter = $this->repository->getUnreadCount($request->user());

        return new NotificationIndicatorResource($counter);
    }

    /**
     * @param NotificationDeleteRequest $request
     * @param Notification $notification
     * @return MessageResource
     */
    public function destroy(NotificationDeleteRequest $request, Notification $notification)
    {
        $this->service->delete($notification, $request->user());

        $content = ['message' => 'Notification deleted.'];

        return new MessageResource($content);
    }
}
