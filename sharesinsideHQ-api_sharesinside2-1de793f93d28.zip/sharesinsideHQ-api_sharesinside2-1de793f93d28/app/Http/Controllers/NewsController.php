<?php

namespace App\Http\Controllers;

use App\Criteria\QueryColumnCriteria;
use App\Criteria\WatchlistAdminRoleCriteria;
use App\Criteria\WatchlistExclusionCriteria;
use App\Criteria\WatchlistItemEntitiableCriteria;
use App\Criteria\WatchlistItemPublicityCriteria;
use App\Criteria\WatchlistItemUserRoleCriteria;
use App\Criteria\WatchlistSortByCriteria;
use App\Criteria\WatchlistToCriteria;
use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\News;
use App\Entities\Startup;
use App\Http\Controllers\Traits\WatchlistableControllerTrait;
use App\Http\Requests\NewsAdminIndexRequest;
use App\Http\Requests\NewsDeleteRequest;
use App\Http\Requests\NewsEditRequest;
use App\Http\Requests\NewsIndexRequest;
use App\Http\Requests\NewsLatestRequest;
use App\Http\Requests\NewsShowRequest;
use App\Http\Requests\NewsShowSocialShareRequest;
use App\Http\Requests\NewsLatestSocialShareRequest;
use App\Http\Requests\NewsStoreRequest;
use App\Http\Requests\NewsUpdateRequest;
use App\Http\Requests\SocialShareKeyRequest;
use App\Http\Resources\MessageResource;
use App\Http\Resources\NewsEditResource;
use App\Http\Resources\NewsResource;
use App\Http\Resources\NewsSocialShareResource;
use App\Http\Resources\WatchlistItemCollection;
use App\Http\Resources\SocialShareKeyResource;
use App\Repositories\NewsRepository;
use App\Repositories\WatchlistItemRepository;
use App\Services\NewsCreator;
use App\Services\RoleResolver;
use App\Services\ViewsCounter;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class NewsController extends Controller
{
    use WatchlistableControllerTrait;

    protected $newsCreator;
    protected $repository;
    protected $viewsCounter;

    const WATCHLIST_ITEMS_PER_PAGE = 16;

    public function __construct(NewsCreator $newsCreator, NewsRepository $repository, ViewsCounter $viewsCounter)
    {
        $this->newsCreator = $newsCreator;
        $this->repository = $repository;
        $this->viewsCounter = $viewsCounter;
    }

    /**
     * @param NewsIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
     public function companyIndex(NewsIndexRequest $request, Company $entity)
     {
         return self::index($request, $entity);
     }

     /**
      * @param NewsIndexRequest $request
      * @param Startup $entity
      * @return WatchlistItemCollection
      */
      public function startupIndex(NewsIndexRequest $request, Startup $entity)
      {
          return self::index($request, $entity);
      }

     /**
      * @param NewsIndexRequest $request
      * @param Fund $entity
      * @return WatchlistItemCollection
      */
      public function fundIndex(NewsIndexRequest $request, Fund $entity)
      {
          return self::index($request, $entity);
      }

      /**
       * @param NewsIndexRequest $request
       * @param FundsManager $entity
       * @return WatchlistItemCollection
       */
       public function fundsManagerIndex(NewsIndexRequest $request, FundsManager $entity)
       {
           return self::index($request, $entity);
       }

    /**
     * @param NewsIndexRequest $request
     * @param Model $entity
     * @return WatchlistItemCollection
     */
    private function index(NewsIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistToCriteria(Carbon::now()->timestamp));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', News::class));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemPublicityCriteria(array_get($request->validated(), 'publicity', [])));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_TYPE_DRAFTS_FIRST_THEN_NEWEST_FIRST));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param NewsAdminIndexRequest $request
     * @param Company $entity
     * @return WatchlistItemCollection
     */
    public function companyAdminIndex(NewsAdminIndexRequest $request, Company $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param NewsAdminIndexRequest $request
     * @param Startup $entity
     * @return WatchlistItemCollection
     */
    public function startupAdminIndex(NewsAdminIndexRequest $request, Startup $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param NewsAdminIndexRequest $request
     * @param Fund $entity
     * @return WatchlistItemCollection
     */
    public function fundAdminIndex(NewsAdminIndexRequest $request, Fund $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param NewsAdminIndexRequest $request
     * @param FundsManager $entity
     * @return WatchlistItemCollection
     */
    public function fundsManagerAdminIndex(NewsAdminIndexRequest $request, FundsManager $entity)
    {
        return self::adminIndex($request, $entity);
    }

    /**
     * @param NewsAdminIndexRequest $request
     * @param Model $entity
     * @return WatchlistItemCollection
     */
    private function adminIndex(NewsAdminIndexRequest $request, Model $entity)
    {
        $this->repository = resolve(WatchlistItemRepository::class);

        $allowToSeeUnpublish = false;

        $roles = RoleResolver::getRoles($request->user(), $entity);
        $allowToSeeUnpublish = $this->roleAllowToSeeUnpublish($roles, $entity);
        $this->allowToSeeUnpublish($allowToSeeUnpublish);

        $this->repository->pushCriteria(new WatchlistAdminRoleCriteria($roles, $entity));

        $this->repository->pushCriteria(new WatchlistItemUserRoleCriteria($request->user()));

        $this->repository->pushCriteria(new WatchlistItemEntitiableCriteria($entity));

        $this->repository->pushCriteria(new WatchlistExclusionCriteria($request->user()));

        $this->repository->pushCriteria(new QueryColumnCriteria('watchlistable_type', News::class));

        $this->repository->pushCriteria(new WatchlistSortByCriteria(WatchlistSortByCriteria::SORT_DEFAULT_WITH_UNPUBLISHED));

        $results = $this
            ->repository
            ->with([
                'watchlistable',
                'attachments',
                'files',
                'videos',
                'images',
                'links',
                'entitiable',
                'entitiable.logo'
            ])
            ->paginate(self::WATCHLIST_ITEMS_PER_PAGE, ['*']);

        return new WatchlistItemCollection($results);
    }

    /**
     * @param NewsStoreRequest $request
     * @return MessageResource
     */
    public function store(NewsStoreRequest $request)
    {
        return $this->storeData($request);
    }

    protected function storeData($request)
    {
        $news = $this->newsCreator->handleStoreNews($request->validated());

        $params = $request->only('remind', 'remind_at');
        $userId = $request->user()->id;
        $this->handleReminder($news, $userId, $params);

        $content = [
            'message' => 'News created.',
            'id' => data_get($news, 'id'),
        ];

        return new MessageResource($content);
    }

    /**
     * @param NewsEditRequest $request
     * @param News $news
     * @return NewsEditResource
     */
    public function edit(NewsEditRequest $request, News $news)
    {
        $news->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
            'watchlistItem.excluded',
            'watchlistItem.excluded.country',
        ]);

        $this->viewsCounter->handleNewsView($news, $request->user());

        $response = new NewsEditResource($news);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param NewsShowRequest $request
     * @param News $news
     * @return NewsResource
     */
    public function show(NewsShowRequest $request, News $news)
    {
        $news->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
        ]);

        $this->viewsCounter->handleNewsView($news, $request->user());

        $response = new NewsResource($news);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param NewsShowSocialShareRequest $request
     * @param News $news
     * @return NewsSocialShareResource
     */
    public function showSocialShare(NewsShowSocialShareRequest $request, News $news)
    {
        $news->load([
            'watchlistItem',
            'watchlistItem.entitiable',
            'watchlistItem.entitiable.logo',
            'watchlistItem.files',
            'watchlistItem.videos',
            'watchlistItem.images',
            'watchlistItem.links',
            'watchlistItem.videoLinks',
        ]);

        $this->viewsCounter->handleSocialShareNewsView($news);

        $response = new NewsResource($news);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param NewsDeleteRequest $request
     * @param News $news
     * @return MessageResource
     */
    public function destroy(NewsDeleteRequest $request, News $news)
    {
        $news->delete();

        $content = ['message' => 'News deleted.'];

        return new MessageResource($content);
    }

    /**
     * @param NewsUpdateRequest $request
     * @param News $news
     * @return MessageResource
     */
    public function update(NewsUpdateRequest $request, News $news)
    {
        $this->newsCreator->handleUpdateNews($news, $request->validated());

        $params = $request->only('remind', 'remind_at');
        $userId = $request->user()->id;
        $this->handleReminder($news, $userId, $params);

        $content = [
            'message' => 'News updated.',
            'id' => $news->id,
        ];

        return new MessageResource($content);
    }

    /**
     * @param NewsLatestRequest $request
     * @param News $news
     * @return WatchlistItemCollection
     */
    public function latest(NewsLatestRequest $request, News $news)
    {
        $results = $this->repository->latest($news->id, $request->user());
        $response = new WatchlistItemCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param NewsLatestRequest $request
     * @param News $news
     * @return WatchlistItemCollection
     */
    public function latestSocialShare(NewsLatestSocialShareRequest $request, News $news)
    {
        $results = $this->repository->latestSocialShare($news->id);
        $response = new WatchlistItemCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param SocialShareKeyRequest $request
     * @param News $news
     * @return SocialShareKeyResource
     */
    public function checkSocialShareKey(SocialShareKeyRequest $request, News $news)
    {
        if($news->watchlistItem->social_share_key===$request->route('shareKey'))
        {
            return new SocialShareKeyResource($news);
        }

        abort(404);
    }
}
