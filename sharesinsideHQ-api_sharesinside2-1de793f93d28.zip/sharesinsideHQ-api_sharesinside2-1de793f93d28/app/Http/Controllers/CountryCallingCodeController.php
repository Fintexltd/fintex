<?php

namespace App\Http\Controllers;

use App\Entities\CountryCallingCode;
use App\Http\Requests\CountryCallingCodeIndexRequest;
use App\Http\Resources\CountryCallingCodeCollection;
use Illuminate\Http\Request;

class CountryCallingCodeController extends Controller
{

    /**
     * @param CountryCallingCodeIndexRequest $request
     * @return CountryCallingCodeCollection
     */
    public function index(CountryCallingCodeIndexRequest $request)
    {
        $results = CountryCallingCode::all();

        return new CountryCallingCodeCollection($results);
    }
}
