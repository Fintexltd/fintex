<?php

namespace App\Http\Controllers;

use App\Entities\StockFeedCache;
use App\Http\Requests\StockTopFiveIndexRequest;
use App\Http\Requests\StockTopFiveRequest;
use Illuminate\Http\Request;

class StockTopFiveController extends Controller
{


    public function index(StockTopFiveIndexRequest $request)
    {
        $cache = StockFeedCache::first();

        try{
            $response = $cache ? \GuzzleHttp\json_decode($cache->value) : [];
        } catch (\Exception $e){
            $response = [];
        }

        return response()->json($response);
    }
}
