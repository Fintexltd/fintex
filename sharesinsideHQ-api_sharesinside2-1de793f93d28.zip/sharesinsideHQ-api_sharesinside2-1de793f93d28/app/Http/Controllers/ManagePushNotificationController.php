<?php

namespace App\Http\Controllers;

use App\Criteria\EntitySortByCriteria;
use App\Http\Requests\ManagePushNotificationCompanyIndexRequest;
use App\Http\Requests\ManagePushNotificationFundIndexRequest;
use App\Http\Requests\ManagePushNotificationFundManagerIndexRequest;
use App\Http\Requests\ManagePushNotificationStartupIndexRequest;
use App\Http\Requests\ManagePushNotificationSendRequest;
use App\Http\Resources\ManagePushNotificationEntitiesCollection;
use App\Http\Resources\MessageResource;
use App\Repositories\CompanyRepository;
use App\Repositories\FundRepository;
use App\Repositories\FundsManagerRepository;
use App\Repositories\StartupRepository;
use App\Services\ManagePushNotificationService;
use Illuminate\Http\Request;
use Prettus\Repository\Eloquent\BaseRepository;

class ManagePushNotificationController extends Controller
{

    const ENTITIES_PER_PAGE = 30;

    /**
     * @param ManagePushNotificationCompanyIndexRequest
     * @param CompanyRepository
     * @return ManagePushNotificationEntitiesCollection
     */
    public function companiesList(ManagePushNotificationCompanyIndexRequest $request, CompanyRepository $repository)
    {
        return $this->entitiesList($request, $repository);
    }

    /**
     * @param ManagePushNotificationFundIndexRequest
     * @param FundRepository
     * @return ManagePushNotificationEntitiesCollection
     */
    public function fundsList(ManagePushNotificationFundIndexRequest $request, FundRepository $repository)
    {
        return $this->entitiesList($request, $repository);
    }

    /**
     * @param ManagePushNotificationFundManagerIndexRequest
     * @param FundManagerRepository
     * @return ManagePushNotificationEntitiesCollection
     */
    public function fundsManagersList(ManagePushNotificationFundManagerIndexRequest $request, FundsManagerRepository $repository)
    {
        return $this->entitiesList($request, $repository);
    }

    /**
     * @param ManagePushNotificationStartupIndexRequest
     * @param StartupRepository
     * @return ManagePushNotificationEntitiesCollection
     */
    public function startupsList(ManagePushNotificationStartupIndexRequest $request, StartupRepository $repository)
    {
        return $this->entitiesList($request, $repository);
    }

    /**
     * @param Request
     * @param BaseRepository
     * @return ManagePushNotificationEntitiesCollection
     */
    private function entitiesList(Request $request, BaseRepository $repository)
    {
        $validated = $request->validated();

        $repository->applyRequestCriteria($validated);
        $repository->pushCriteria(new EntitySortByCriteria(EntitySortByCriteria::SORT_NEW_FIRST));

        $results = $repository
            ->with([
                'entityNotifications',
            ])
            ->paginate(self::ENTITIES_PER_PAGE, ['*']);

        $response = new ManagePushNotificationEntitiesCollection($results);
        $response->withoutWrapping();

        return $response;
    }

    /**
     * @param ManagePushNotificationSendRequest
     * @param ManagePushNotificationService
     * @return MessageResource
     */
    public function send(ManagePushNotificationSendRequest $request, ManagePushNotificationService $service)
    {
        $service->addToSend($request->validated());

        return new MessageResource([
            'message' => 'Added to send.'
        ]);
    }
}
