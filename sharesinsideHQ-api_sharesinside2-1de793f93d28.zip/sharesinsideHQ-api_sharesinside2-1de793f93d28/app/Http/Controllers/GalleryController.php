<?php

namespace App\Http\Controllers;

use App\Entities\Company;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Entities\SectionItem;
use App\Entities\Startup;
use App\Http\Requests\DeleteGalleryItemsRequest;
use App\Http\Requests\GalleryDeleteRequest;
use App\Http\Requests\CompanyGalleryIndexRequest;
use App\Http\Requests\StartupGalleryIndexRequest;
use App\Http\Requests\GalleryStoreRequest;
use App\Http\Requests\GalleryUpdateRequest;
use App\Http\Resources\AlbumCollection;
use App\Http\Resources\MessageResource;
use App\Services\SectionsCreator;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;

class GalleryController extends Controller
{
    protected $sectionsCreator;

    public function __construct(SectionsCreator $sectionsCreator)
    {
        $this->sectionsCreator = $sectionsCreator;
    }

    /**
     * @param CompanyGalleryIndexRequest $request
     * @param Company $company
     * @return AlbumCollection
     */
    public function companyIndex(CompanyGalleryIndexRequest $request, Company $company)
    {
        return $this->index($request, $company);
    }

    /**
     * @param StartupGalleryIndexRequest $request
     * @param Startup $startup
     * @return AlbumCollection
     */
    public function startupIndex(StartupGalleryIndexRequest $request, Startup $startup)
    {
        return $this->index($request, $startup);
    }

    /**
     * @param Request $request
     * @param Model $entity
     * @return AlbumCollection
     */
    public function index(Request $request, Model $entity)
    {
        $results = Section::whereIn('type', SectionInterface::GALLERY_TYPES)
            ->where('referenced_id', $entity->id)
            ->where('referenced_type', get_class($entity))
            ->with([
                'items',
                'items.file',
            ])
            ->get();

        $resource = new AlbumCollection($results);
        $resource->withoutWrapping();

        return $resource;
    }

    /**
     * @param GalleryStoreRequest $request
     * @return MessageResource
     */
    public function store(GalleryStoreRequest $request)
    {
        $section = $this->sectionsCreator
            ->handleStoreSection($request->all(), SectionInterface::COMPANY_GALLERY_ALBUM_SECTION);

        $content = [
            'message' => 'Gallery was created',
            'section_id' => $section->id,
        ];

        return new MessageResource($content);
    }

    /**
     * @param GalleryUpdateRequest $request
     * @param Section $gallery
     * @return MessageResource
     */
    public function update(GalleryUpdateRequest $request, Section $gallery)
    {
        $this->sectionsCreator
            ->handleUpdateSection($gallery, $request->all());

        $content = ['message' => 'Gallery was updated'];

        return new MessageResource($content);
    }

    /**
     * @param GalleryDeleteRequest $request
     * @param Section $gallery
     * @return MessageResource
     */
    public function destroy(GalleryDeleteRequest $request, Section $gallery)
    {
        $this->sectionsCreator
            ->handleDestroySection($gallery);

        $content = ['message' => 'Gallery was deleted'];

        return new MessageResource($content);
    }

    /**
     * @param DeleteGalleryItemsRequest $request
     * @param Section $section
     * @return MessageResource
     */
    public function deleteItems(DeleteGalleryItemsRequest $request, Section $section)
    {
        SectionItem::query()
            ->find($request->get('delete_ids'))
            ->each(function ($item) {
                return $item->delete();
            });

        $content = ['message' => 'Gallery items were deleted'];

        return new MessageResource($content);
    }
}
