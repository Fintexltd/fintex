<?php

namespace App\Http\Controllers;

use App\Entities\Industry;
use App\Events\IndustryCreated;
use App\Http\Requests\IndustryDeleteRequest;
use App\Http\Requests\IndustryIndexRequest;
use App\Http\Requests\IndustryStoreRequest;
use App\Http\Requests\IndustryUpdateRequest;
use App\Http\Resources\IndustryCollection;
use App\Http\Resources\MessageResource;
use Illuminate\Http\Request;

class IndustryController extends Controller
{
    /**
     * @param IndustryIndexRequest $request
     * @return IndustryCollection
     */
    public function index(IndustryIndexRequest $request)
    {
        $query = Industry::query();

        if ($search = $request->get('search')) {
            $query->where('name', 'LIKE', "%$search%");
        }

        if ($sectors = $request->get('economic_sectors')) {
            $query->whereIn('economic_sector_id', $sectors);
        }

        if ($request->get('with_sector')) {
            $query->with(['economicSector']);
        }

        $results = $query
            ->orderBy('sort_order', 'ASC')
            ->orderBy('name', 'ASC')
            ->get();

        return new IndustryCollection($results);
    }

    /**
     * @param IndustryStoreRequest $request
     * @return MessageResource
     */
    public function store(IndustryStoreRequest $request)
    {
        $data = $request->validated();
        $data['sort_order'] = $data['name'];

        $industry = Industry::create($data);

        event(new IndustryCreated($industry));

        $response = [
            'message' => 'Industry created',
            'industry_id' => $industry->id,
        ];

        return new MessageResource($response);
    }

    /**
     * @param IndustryUpdateRequest $request
     * @param Industry $industry
     * @return MessageResource
     */
    public function update(IndustryUpdateRequest $request, Industry $industry)
    {
        $industry->update(collect($request->validated())->filter()->all());

        $response = ['message' => 'Industry updated'];

        return new MessageResource($response);
    }

    /**
     * @param IndustryDeleteRequest $request
     * @param Industry $industry
     * @return MessageResource
     */
    public function destroy(IndustryDeleteRequest $request, Industry $industry)
    {
        $industry->delete();

        $response = ['message' => 'Industry removed'];

        return new MessageResource($response);
    }
}
