<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateDemoAccountRequest;
use App\Http\Requests\DemoIndividualKeyStoreRequest;
use App\Http\Resources\MessageResource;
use App\Services\DemoService;
use Illuminate\Http\Request;

class DemoController extends Controller
{
    protected $service;

    /**
     * DemoController constructor.
     */
    public function __construct(DemoService $service)
    {
        $this->service = $service;
    }

    /**
     * @param UpdateDemoAccountRequest $request
     * @return MessageResource
     */
    public function update(UpdateDemoAccountRequest $request)
    {
        $response = ['message' => $this->service->updateDemoUserSettings($request->validated())];

        return new MessageResource($response);

    }

    /**
     * @param DemoIndividualKeyStoreRequest $request
     * @return MessageResource
     */
    public function individualKey(DemoIndividualKeyStoreRequest $request)
    {
        $response = [
            'message' => 'Key created',
            'key' => $this->service->createDemoIndividualKey($request)
        ];

        return new MessageResource($response);
    }
}
