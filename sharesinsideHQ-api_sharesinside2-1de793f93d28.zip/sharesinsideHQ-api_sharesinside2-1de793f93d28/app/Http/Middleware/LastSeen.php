<?php

namespace App\Http\Middleware;

use App\Entities\UnreadPushCounter;
use App\Services\RoleResolver;
use Carbon\Carbon;
use Closure;

class LastSeen
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = $request->user();

        if ($user && !RoleResolver::isDemoUser($user)) {
            $unreadPushCounter = $user->unreadPushCounter;
            if ($unreadPushCounter) {
                $unreadPushCounter->update([
                    'last_seen' => Carbon::now(),
                    'counter' => 0,
                ]);
            } else {
                UnreadPushCounter::create([
                    'user_id' => $user->id,
                    'last_seen' => Carbon::now(),
                ]);
            }
        }

        return $next($request);
    }
}
