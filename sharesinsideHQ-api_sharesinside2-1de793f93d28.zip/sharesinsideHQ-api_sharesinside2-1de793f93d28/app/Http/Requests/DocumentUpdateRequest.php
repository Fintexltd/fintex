<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\DocumentUpdateAndDeleteRequestTrait;

class DocumentUpdateRequest extends DocumentStoreRequest
{
    use DocumentUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();

        unset($rules['section_id']);
        $rules['title'][0] = 'nullable';
        $rules['file'][0] = 'nullable';

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "document"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Document ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/DocumentUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  DocumentUpdate:
    type: "object"
    required:
    - "_method"
    properties:
      _method:
        type: "string"
        enum:
        - "put"
      title:
        type: "string"
      file:
        \$ref: "#/definitions/AttachmentToken"
EOT;

        return ['HistoricalDataUpdate' => $def];
    }
}
