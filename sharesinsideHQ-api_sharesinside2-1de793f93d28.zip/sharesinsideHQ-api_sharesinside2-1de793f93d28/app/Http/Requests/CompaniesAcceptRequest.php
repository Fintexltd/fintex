<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class CompaniesAcceptRequest extends CompanyAdminIndexRequest
{
    public function authorize()
    {
        $user = $this->user();

        if (RoleResolver::isGlobalAdmin($user) || RoleResolver::isContentAdmin($user)) {
            return true;
        }

        $conditions = Company::query()
            ->find($this->company_ids)
            ->map(function ($company) use ($user) {
                return RoleResolver::isDomesticInCompany($user, $company);
            })
            ->all();

        return !in_array(false, $conditions);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'company_ids' => [
                'array',
            ],
            'company_ids.*' => [
                'integer',
                Rule::exists('companies', 'id')
                    ->where(function ($query) {
                        $query->where('is_accepted', false);
                    }),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'company_ids.*.exists' => 'There is no company you can accept with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "companies"
      summary: "accept selected companies"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminCompanyActionArray"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  AdminCompanyActionArray:
    type: "object"
    properties:
      company_ids:
        type: "array"
        items:
          type: "integer"
        description: "apply action for companies present on list"
EOT;

        return ['AdminCompanyActionArray' => $def];
    }
}
