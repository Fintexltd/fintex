<?php

namespace App\Http\Requests;

use App\Repositories\AttachmentRepository;
use App\Services\RoleResolver;
use App\Services\DescriptionSanitizer;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class LandingPageUpdateRequest extends FormRequest
{
    const MAX_HEROTEXT_LENGTH = 2000;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    protected function prepareForValidation()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        $input = $this->all();
        $input['heroText'] = $this->descriptionSanitizer->sanitize($input['heroText']);
        $this->merge($input);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'heroTitle' => 'required|string|max:24',
            'heroSubTitle' => 'required|string|max:64',
            'heroText' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_HEROTEXT_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_HEROTEXT_LENGTH . '.');
                    }
                    if (!strlen(trim(strip_tags($value)))) {
                        return $fail('Description is required.');
                    }
                },
            ],

            'bannerImage' => [
                'nullable',
                'string',
            ],
            'bannerImageToken' => [
                'nullable',
                'string',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_IMAGE);
                }),
            ],
            'bannerUrl' => [
                'present',
                'string',
            ],

            'benefitsTitle' => 'required|string|max:64',
            'benefitsSubTitle1' => 'required|string|max:32',
            'benefitsList1' => 'required|array',
            'benefitsList1.*' => 'required|string|max:200',

            'benefitsSubTitle2' => 'required|string|max:32',
            'benefitsList2' => 'required|array',
            'benefitsList2.*' => 'required|string|max:200',

            'aboutTitle' => 'required|string|max:32',
            'aboutText' => 'required|string|max:1000',

            'platformTitle' => 'required|string|max:32',
            'platformText' => 'required|string|max:1000',

            'aboutImage' => [
                'required_without_all:aboutImageToken,aboutVideo',
                'string',
            ],
            'aboutImageToken' => [
                'required_without_all:aboutImage,aboutVideo',
                'string',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_IMAGE);
                }),
            ],
            'aboutVideo' => [
                'required_without_all:aboutImage,aboutImageToken',
                'string',
            ],
            'platformImage' => [
                'required_without_all:platformImageToken,platformVideo',
                'string',
            ],
            'platformImageToken' => [
                'required_without_all:platformImage,platformVideo',
                'string',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_IMAGE);
                }),
            ],
            'platformVideo' => [
                'required_without_all:platformImage,platformImageToken',
                'string',
            ],

            'contactTitle' => 'required|string|max:32',
            'contactText' => 'required|string|max:200',

            'supportTitle' => 'required|string|max:32',
            'supportText' => 'required|string|max:200',

            'supportImage' => [
                'required_without_all:supportImageToken',
                'string',
            ],
            'supportImageToken' => [
                'required_without_all:supportImage',
                'string',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_IMAGE);
                }),
            ],

            'supportName' => 'required|string|max:64',
            'supportPosition' => 'required|string|max:64',
            'supportEmail' => 'required|email',
            'supportPhone' => 'required|string',

            'officesTitle' => 'required|string|max:32',
            'offices' => 'required|array',
            'offices.*.country' => 'required|string|max:64',
            'offices.*.name' => 'present|string|max:64',
            'offices.*.email' => 'present|email',
            'offices.*.phone' => 'present|string',
            'offices.*.address' => 'present|string|max:64',
            'offices.*.soon' => 'required|boolean',

            'corporateTitle' => 'required|string|max:32',
            'corporateText1' => 'required|string|max:800',
            'corporateText2' => 'present|string|max:800',
            'corporateText3' => 'required|string|max:400',
            'corporateText4' => 'required|string|max:400',
            'corporateQuote1' => 'required|string|max:200',
            'corporateQuote2' => 'required|string|max:200',

            'partners' => 'required|array',
            'partners.*.partner' => 'required|string|max:100',
            'partners.*.website' => 'required|string',

        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            $bannerImagePresent = array_key_exists('bannerImage', $this->all());
            $bannerImageTokenPresent = array_key_exists('bannerImageToken', $this->all());

            if (!($bannerImagePresent || $bannerImageTokenPresent)) {
                $validator
                    ->errors()
                    ->add('bannerImage', 'One of following fields must be present in request: bannerImage, bannerImageToken.');
            }
        });
    }
}
