<?php

namespace App\Http\Requests;

use App\Entities\FundsManager;
use App\Http\Requests\Traits\WatchlistableStoreRequestTrait;
use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\Services\DescriptionSanitizer;
use App\Services\ReceiversService;
use App\Services\Validation\Url;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class EventStoreRequest extends FormRequest
{
    use WatchlistableStoreRequestTrait;

    const MAX_DESCRIPTION_LENGTH = 8000;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        return [
            'entitiable_type' => [], //validated by prepareForValidation() at WatchlistableStoreRequestTrait
            'entitiable_id' => [], //validated by prepareForValidation() at WatchlistableStoreRequestTrait
            'title' => [
                'required',
                'string',
                'max:200'
            ],
            'description' => [
                'nullable',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                },
            ],
            'is_internal' => [
                'boolean',
                'forbidden_with:is_business',
            ],
            'is_business' => [
                'boolean',
                'forbidden_with:is_internal',
                function ($attribute, $value, $fail) {
                    if (get_class($this->entity)==FundsManager::class && $value) {
                        return $fail("is_business cannot be true for funds manager event.");
                    }
                },
            ],
            'event_date' => [
                'required',
                'bail',
                'regex:/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/',
                function ($attribute, $value, $fail) {
                    $date = Carbon::createFromFormat('Y-m-d H:i:s', $value);
                    $condition = $date->toDateTimeString() !== $value;
                    if ($condition) {
                        return $fail('event_date must have right format - "Y-m-d H:i:s".');
                    }
//                    $condition = $date->lessThan(Carbon::now()->subDay());
//                    if ($condition) {
//                        return $fail('Can not add event with date in the past.');
//                    }
                }
            ],
            'is_draft' => [
                'nullable',
                'boolean',
            ],
            'files' => 'array',
            'files.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FILE);
                })
            ],
            'links' => 'array',
            'links.*.name' => 'required|max:64',
            'links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'links.*.type' => 'required|distinct|in:' . implode(',', LinkRepository::EVENT_LINKS_TYPES),

            'adress' => 'nullable|string|max:191',
            'city' => 'required|string|max:191',

            'country_id' => 'required|exists:countries,id',
            'longitude' => 'required|numeric|min:-180|max:180',
            'latitude' => 'required|numeric|min:-90|max:90',
            'publish_at' => [
                'required_if:publish_now,0,false',
                'integer',
                function ($attribute, $value, $fail) {
                    if (!data_get($this, 'publish_now')) {
                        if (!($value)) {
                            return $fail('The publish at field is required when publish now is false.');
                        }
                    };
                },
            ],
            'publish_now' => [
                'required_without:publish_at',
                'boolean',
                function ($attribute, $value, $fail) {
                    if ($this->get('publish_at')) {
                        if ($value) {
                            return $fail('Cannot set publishing date if publish now is true.');
                        }
                    }
                },
            ],
            'is_local' => [
                'nullable',
                'boolean',
            ],
            'receivers' => 'nullable|array',
            'receivers.*' => [
                'string',
                'in:' . implode(',', ReceiversService::AVALIABLE_TYPES),
                function ($attribute, $value, $fail) {
                    if ($this->get('is_internal')) {
                        if ($value !== ReceiversService::TYPE_VIPS) {
                            return $fail("$value cannot be receiver of internal event.");
                        }
                    }
                },
                function ($attribute, $value, $fail) {
                    if (get_class($this->entity)==FundsManager::class && $value == ReceiversService::TYPE_SHAREHOLDERS) {
                        return $fail("$value cannot be receiver of funds manager event.");
                    }
                },
            ],
        ];
    }

    public function messages()
    {
        return [
            'links.*.type.in' => 'Link type should be one of following: "' . implode('", "', LinkRepository::EVENT_LINKS_TYPES) . '".',
            'company_id.required' => 'Company id is required when fund id is not set.',
            'fund_id.required' => 'Fund id is required when company id is not set.',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "events"
      summary: "Creates event for company or fund"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/EventStore"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  EventStore:
    type: "object"
    required:
    - "entitiable_type"
    - "entitiable_id"
    - "adress"
    - "longitude"
    - "latitude"
    - "country_id"
    - "event_date"
    - "company_id"
    - "title"
    properties:
      entitiable_type:
        type: "string"
        description: "Required."
        enum:
        - "company"
        - "startup"
        - "fund"
        - "funds_manager"
      entitiable_id:
        type: "integer"
        description: "ID of company, startup, funds manager or fund."
      adress:
        type: "string"
        description: "Required. Event adress."
      longitude:
        type: "number"
        description: "Required. Event longitude."
      latitude:
        type: "number"
        description: "Required. Event latitude."
      country_id:
        type: "integer"
        description: "Required. Event country id."
      event_date:
        type: "number"
        description: "Required. Event date in Y-m-d H:i:s format."
      title:
        type: "string"
        description: "Required. 200 characters max."
      description:
        type: "string"
        description: "Optional. max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
      is_draft:
        type: "integer"
        description: "1 or 0; flag for news"
      files:
        type: "array"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      publish_now:
        description: "Required if publish_at is not set."
      publish_at:
        type: "integer"
        description: "nullable, required if publish now is not true. Must be null if publish_now is true. timestamp when news should be published."
EOT;

        $linkDef = <<<EOT
  Link:
    type: "object"
    required:
    - "name"
    - "url"
    properties:
      name:
        type: "string"
        description: "displayed name"
      url:
        type: "string"
        description: "link url"
      type:
        type: "string"
        description: "link type, required for event links"
        enum:
        - 'type_default'
        - 'type_video'
        - 'type_webcast'
        - 'type_archived_video'
EOT;


        return [
            'EventStore' => $def,
            'Link' => $linkDef,
        ];
    }
}
