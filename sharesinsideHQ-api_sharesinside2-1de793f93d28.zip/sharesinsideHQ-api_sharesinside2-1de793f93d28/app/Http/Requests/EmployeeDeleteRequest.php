<?php

namespace App\Http\Requests;

use App\Entities\RelationInterface;
use App\Http\Requests\Traits\EmployeeUpdateAndDeleteRequestTrait;
use Illuminate\Foundation\Http\FormRequest;

class EmployeeDeleteRequest extends FormRequest
{
    use EmployeeUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "employees"
      summary: "deletes employee"
      parameters:
      - name: "id"
        in: "path"
        type: "integer"
        required: true
        description: "Required. Must exist in database."
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      produces:
      - "application/json"
EOT;

    }
}
