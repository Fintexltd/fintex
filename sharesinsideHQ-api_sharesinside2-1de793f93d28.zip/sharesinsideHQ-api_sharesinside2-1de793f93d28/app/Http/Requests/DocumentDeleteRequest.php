<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\DocumentUpdateAndDeleteRequestTrait;
use Illuminate\Foundation\Http\FormRequest;

class DocumentDeleteRequest extends FormRequest
{
    use DocumentUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "document"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Document ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
