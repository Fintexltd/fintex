<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class FundAdminIndexRequest extends FundIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();
        unset($rules['sort_by']);
        unset($rules['seed']);
        unset($rules['relation']);

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "funds"
      summary: "list of fund tiles"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for fund tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, fund with maching name are returned"
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "fund_type"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "currency"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "active"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - "0"
        - "1"
      - name: "passive"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - "0"
        - "1"
EOT;

    }
}
