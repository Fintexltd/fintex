<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EmployeeRequestIndex extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT

    get:
      tags:
      - "employees"
      summary: "Creates new company"
      parameters:
      - name: "id"
        in: "path"
        type: "integer"
        required: true
        description: "Required. Must exist in database."
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      produces:
      - "application/json"
EOT;

    }
}
