<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use App\Services\StaticContentService;
use Illuminate\Foundation\Http\FormRequest;

class EditStaticContentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            if (!in_array($this->route('type'), StaticContentService::AVALIABLE_TYPES)) {
                $validator
                    ->errors()
                    ->add('type', 'The type should be one of following: "' . implode(StaticContentService::AVALIABLE_TYPES, '", "') . '"."');
            }
        });
    }
}
