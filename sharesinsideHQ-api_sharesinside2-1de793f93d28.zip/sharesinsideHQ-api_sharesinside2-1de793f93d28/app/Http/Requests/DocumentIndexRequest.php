<?php

namespace App\Http\Requests;

use App\Entities\SectionInterface;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DocumentIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'section_id' => [
                'required',
                'integer',
                Rule::exists('sections', 'id')->where(function($query){
                    $query->where('type', SectionInterface::DOCUMENT_SECTION);
                }),
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "document"
      summary: "Paginated list of documents"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Entity ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "section_id"
        in: "query"
        required: true
        type: "integer"
        description: "Section ID"
      - name: "page"
        in: "query"
        required: false
        type: "integer"
        description: "selected page"
      produces:
      - "application/json"
EOT;

    }
}
