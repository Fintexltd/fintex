<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\GalleryAndGalleryItemUpdateAndDeleteRequestTrait;
use App\Entities\Section;
use App\Repositories\AttachmentRepository;
use App\Services\DescriptionSanitizer;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class GalleryItemUpdateRequest extends FormRequest
{
    use GalleryAndGalleryItemUpdateAndDeleteRequestTrait;

    const MAX_DESCRIPTION_LENGTH = 512;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $descriptionSanitizer = new DescriptionSanitizer();

        $rules = [
            'file' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->whereIn('value', AttachmentRepository::GALLERY_ITEM_TYPES),
            ],
            'description' => [
                'nullable',
                'string',
                function ($attribute, $value, $fail) use ($descriptionSanitizer) {
                    $condition = $descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                },
            ],
            'section_id' => [
                'nullable',
                'integer',
                function ($attribute, $value, $fail) {
                    $previousSection = $this->galleryItem->section;
                    $targetSection = Section::query()->find($value);

                    $cond1 = $previousSection->referenced_type !== $targetSection->referenced_type;
                    $cond2 = $previousSection->referenced_id !== $targetSection->referenced_id;

                    if ($cond1 || $cond2) {
                        return $fail('Invalid section id.');
                    }
                },
            ],
        ];

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "company gallery"
      summary: "Updates company gallery item"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "id"
        in: "path"
        type: "string"
        required: true
        description: "Required. Must exist in database."
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyGalleryItemUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyGalleryItemUpdate:
    type: "object"
    required:
    - "_method"
    properties:
      _method:
        type: "string"
        enum:
        - "put"
      description:
        type: "string"
      file:
        type: "string"
        description: "token from uploaded file - if file should be altered"
EOT;

        return ['CompanyGalleryItemUpdate' => $def];

    }
}
