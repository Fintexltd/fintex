<?php

namespace App\Http\Requests;

use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class DeleteFundsRelationsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $userRoles = RoleResolver::getRoles($this->user(), $this->fundsManager);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'relations' => [
                'required',
                'array',
            ],
            'relations.*' => [
                'required',
                'integer',
                Rule::exists('relations', 'id')->where(function ($query) {
                    $query
                        ->where(function ($query) {
                            $query->where(function ($query) {
                                $query->whereIn('type', [
                                    User::RELATION_TYPE_EDITOR,
                                    User::RELATION_TYPE_VIP,
                                    User::RELATION_TYPE_SHAREHOLDER,
                                ])
                                ->where('related_type', Fund::class)
                                ->whereIn('related_id', $this->fundsManager->funds->pluck('id')->toArray());
                            })
                            ->orWhere(function ($query) {
                                $query->whereIn('type', [
                                    User::RELATION_TYPE_EDITOR,
                                    User::RELATION_TYPE_VIP,
                                ])
                                ->where('related_type', FundsManager::class)
                                ->where('related_id', $this->fundsManager->id);
                            });
                        });
                }),
            ],
        ];
    }
}
