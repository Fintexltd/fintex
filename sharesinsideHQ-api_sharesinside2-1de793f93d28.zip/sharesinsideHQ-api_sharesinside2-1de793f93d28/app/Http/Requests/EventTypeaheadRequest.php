<?php

namespace App\Http\Requests;

class EventTypeaheadRequest extends WatchlistIndexRequest
{
    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "events"
      summary: "list of events"
      produces:
      - "application/json"
      parameters:
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for watchlist."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, searches in titles and description"
      - name: "from"
        in: "query"
        type: "integer"
        required: false
        description: "timestamp, searches watchlist items with publish date later than parameter"
      - name: "to"
        in: "query"
        type: "integer"
        required: false
        description: "timestamp, searches watchlist items with publish date earlier than parameter"
      - name: "attachments"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - 'documents'
          - 'files'
          - 'videos'
          - 'images'
          - 'links'
        required: false
        description: "'documents' is alias for 'files'."
      - name: "event_from"
        in: "query"
        type: "string"
        required: false
        description: "date in Y-m-d format, filters events with event date equal or later than parameter"
      - name: "event_to"
        in: "query"
        type: "string"
        required: false
        description: "date in Y-m-d format, filters events with event date equal or earlier than parameter"
      - name: "sort_by"
        in: "query"
        type: "string"
        required: false
        description: "possible values: most_viewed, default"
      - name: "location"
        in: "query"
        type: "string"
        required: false
        description: "filters events with maching location, existing locations can be find with /api/locations endpoint"

EOT;

    }
}
