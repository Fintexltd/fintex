<?php

namespace App\Http\Requests;

use App\Entities\SectionInterface;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class HistoricalDataPieceIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'section_id' => [
                'required',
                'integer',
//                'in:' . implode(',', HistoricalDataPieceInterface::AVALIABLE_TYPES),
                Rule::exists('sections', 'id')->where(function($query){
                    $query->where('type', SectionInterface::HISTORICAL_DATA_SECTION);
                }),
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "historical-data"
      summary: "Paginated list of selected historical data type"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "type"
        in: "query"
        required: true
        type: "string"
        description: "requested historical data type"
        enum:
        - "type_divident"
        - "type_report"
        - "type_presentation"
      - name: "page"
        in: "query"
        required: false
        type: "integer"
        description: "selected page"
      produces:
      - "application/json"
EOT;

    }
}
