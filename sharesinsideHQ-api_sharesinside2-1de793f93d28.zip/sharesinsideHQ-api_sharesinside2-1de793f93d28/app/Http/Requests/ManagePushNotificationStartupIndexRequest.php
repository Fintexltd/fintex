<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class ManagePushNotificationStartupIndexRequest extends StartupIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();

        unset($rules['sort_by'], $rules['seed']);

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "startups"
      summary: "manage-push-notification"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, startups with maching name are returned"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only startups that have maching relation with user"
      - name: "startup_category"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "equity"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "fund"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only startups having continent maching id in request"
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only startups having country maching id in request"
      - name: "raised_amount_from"
        in: "query"
        type: "number"
        required: false
        minimum: 0.00000001
        maximum: 99999999.99999999
      - name: "raised_amount_to"
        in: "query"
        type: "number"
        required: false
        minimum: 0.00000001
        maximum: 99999999.99999999
      - name: "currency"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for startups tiles list."
EOT;

    }
}
