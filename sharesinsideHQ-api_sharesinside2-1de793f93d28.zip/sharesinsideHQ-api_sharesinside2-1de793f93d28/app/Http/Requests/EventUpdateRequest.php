<?php

namespace App\Http\Requests;

use App\Entities\Fund;
use Carbon\Carbon;

class EventUpdateRequest extends EventStoreRequest
{

    public function authorize()
    {
        return $this->user()->can('update', $this->event);
    }

    protected function prepareForValidation()
    {
        parent::prepareForValidation();

        $input = $this->all();
        $input['entitiable_type'] = null;
        $input['entitiable_id'] = null;
        $this->merge($input);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if (!data_get($this, 'event.watchlistItem.entitiable') || (get_class(data_get($this, 'event.watchlistItem.entitiable'))==Fund::class && !data_get($this, 'event.watchlistItem.entitiable.fundsManager'))) {
            abort(404, 'The event you\'re looking for was removed');
        }

        $parentRules = parent::rules();
        unset($parentRules['event_date'][0]);
        unset($parentRules['timezone_id'][0]);
        unset($parentRules['event_timestamp'][0]);

        $event = $this
            ->route('event')
            ->load([
                'watchlistItem',
                'watchlistItem.attachments',
                'watchlistItem.links',
            ]);

        $attachmentsIds = $event->watchlistItem->attachments->pluck('id')->all();
        $linksIds = $event->watchlistItem->links->pluck('id')->all();

        $publishAt = $event->watchlistItem->publish_at ?? Carbon::now();
        $alreadyPublished = ((!$event->watchlistItem->is_draft) && $publishAt->isPast());
        if ($alreadyPublished) {
            $parentRules['is_draft'][1] = 'in:0';
            $parentRules['publish_now'][0] = 'nullable';
            $parentRules['publish_at'][1] = 'in:' . $publishAt->timestamp;
        }

        $parentRules['title'][0] = 'nullable';

        $rules = [
            'city' => 'nullable|required_with:country_id,longitude,latitude|string|max:191',
            'country_id' => 'nullable|required_with:city,longitude,latitude|exists:countries,id',
            'longitude' => 'nullable|required_with:city,country_id,latitude|numeric|min:-180|max:180',
            'latitude' => 'nullable|required_with:city,country_id,longitude|numeric|min:-90|max:90',

            'delete_links' => 'array',
            'delete_links.*' => [
                'integer',
                'in:' . implode(',', $linksIds),
            ],

            'delete_attachments' => 'array',
            'delete_attachments.*' => [
                'integer',
                'in:' . implode(',', $attachmentsIds),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'is_draft.in' => 'cannot change published event to draft',
            'publish_at.in' => 'You cannot reschedule an already published event.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "events"
      summary: "Updates event"
      consumes:
      - "multipart/form-data"
      produces:
      - "application/json"
      parameters:
        - in: "path"
          name: "id"
          required: true
          type: "integer"
          minimum: 1
          description: "Event ID"
        - name: "Accept"
          in: "header"
          type: "string"
          enum:
          - "application/json"
        - in: "body"
          name: "body"
          description: "json object with registration data"
          required: true
          schema:
            \$ref: "#/definitions/EventUpdate"
EOT;

    }

    public static function definitions()
    {
        $ref = <<<EOT
  EventUpdate:
    type: "object"
    required:
    - "entitiable_type"
    - "entitiable_id"
    properties:
      entitiable_type:
        type: "string"
        description: "Required."
        enum:
        - "company"
        - "startup"
        - "fund"
        - "funds_manager"
      entitiable_id:
        type: "integer"
        description: "ID of company, startup, funds manager or fund."
      adress:
        type: "string"
        description: "Required with longitude, latitude and country_id. Event adress."
      longitude:
        type: "number"
        description: "Required with adress, latitude and country_id. Event longitude."
      latitude:
        type: "number"
        description: "Required with adress, longitude and country_id. Event latitude."
      country_id:
        type: "integer"
        description: "Required with adress, longitude and latitude. Event country id."
      event_date:
        type: "number"
        description: "Event date in Y-m-d H:i:s format."
      title:
        type: "string"
        description: "200 characters max."
      description:
        type: "string"
        description: "Optional. max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
      is_draft:
        type: "integer"
        description: "1 or 0; flag for news"
      files:
        type: "array"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      delete_links:
        description: "array of links ids to delete"
        type: "array"
        items:
          type: "integer"
      delete_attachments:
        description: "array of attachments ids to delete"
        type: "array"
        items:
          type: "integer"
      publish_now:
        description: "Required if publish_at is not set."
      publish_at:
        type: "integer"
        description: "nullable, required if publish now is not true. Must be null if publish_now is true. timestamp when news should be published."
EOT;

        return ['EventUpdate' => $ref];
    }
}
