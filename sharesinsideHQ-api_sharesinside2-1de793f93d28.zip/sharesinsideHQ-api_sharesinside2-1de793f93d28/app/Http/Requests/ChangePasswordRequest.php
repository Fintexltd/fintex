<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use App\Rules\OldPassword;
use Illuminate\Support\Facades\Auth;

class ChangePasswordRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check() && !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'new_password' => [
                'required',
                'string',
                'min:8',
                'regex:(\w+\d+)',
                'not_in:' . $this->get('old_password', ''),
            ],
            'old_password' => [
                'required_with:new_password,repeat_password',
                new OldPassword($this->user())
            ],
            'repeat_password' => 'required_with:new_password,old_password|string|same:new_password',
        ];
    }

    public function messages()
    {
        return [
            'new_password.not_in' => 'New and old password cannot be the same.',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
        - "users"
      summary: "Changes users password"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with old and new password"
        required: true
        schema:
          \$ref: "#/definitions/PasswordChange"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  PasswordChangeResponse:
    type: "object"
    properties:
      token_type:
        type: "string"
        description: "Not present if password was not changed. Acces token type."
        enum:
        - "Bearer"
      expires_in:
        type: "integer"
        description: "Not present if password was not changed. Amount of seconds until token expires."
        example: 31536000
      access_token:
        type: "string"
        description: "Not present if password was not changed. Access token."
      refresh_token:
        type: "string"
        description: "Not present if password was not changed. Nullable. Refresh token."
      message:
        type: "string"
EOT;

        return ['PasswordChangeResponse' => $def];
    }
}
