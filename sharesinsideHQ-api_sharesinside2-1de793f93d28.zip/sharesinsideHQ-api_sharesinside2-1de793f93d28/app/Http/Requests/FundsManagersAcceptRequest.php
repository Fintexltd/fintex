<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundsManagersAcceptRequest extends FundsManagerAdminIndexRequest
{
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'funds_manager_ids' => [
                'array',
            ],
            'funds_manager_ids.*' => [
                'integer',
                Rule::exists('funds_managers', 'id')
                    ->where(function ($query) {
                        $query->where('is_accepted', false);
                    }),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'funds_manager_ids.*.exists' => 'There is no funds manager you can accept with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "funds managers"
      summary: "accept selected funds managers"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminFundsManagerActionArray"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  AdminFundsManagerActionArray:
    type: "object"
    properties:
      funds_manager_ids:
        type: "array"
        items:
          type: "integer"
        description: "apply action for funds managers present on list"
EOT;

        return ['AdminFundsManagerActionArray' => $def];
    }
}
