<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;

class HistoricalDataUpdateRequest extends HistoricalDataStoreRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $companyId = data_get($this, 'historical_datum.company_id');

        $company = Company::find($companyId);
        if (!$company) {
            return false;
        }

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $company);

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();

        unset($rules['company_id']);
        unset($rules['section_id']);
        $rules['title'][0] = 'nullable';
//        $rules['type'][0] = 'nullable';
        $rules['fiscal_year'][0] = 'nullable';
        $rules['file'][0] = 'nullable';

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "historical-data"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Historical Data Piece ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/HistoricalDataUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  HistoricalDataUpdate:
    type: "object"
    required:
    - "_method"
    properties:
      _method:
        type: "string"
        enum:
        - "put"
      company_id:
        type: "integer"
      title:
        type: "string"
      type:
        type: "string"
      fiscal_year:
        type: "integer"
      file:
        \$ref: "#/definitions/AttachmentToken"
EOT;

        return ['HistoricalDataUpdate' => $def];
    }
}
