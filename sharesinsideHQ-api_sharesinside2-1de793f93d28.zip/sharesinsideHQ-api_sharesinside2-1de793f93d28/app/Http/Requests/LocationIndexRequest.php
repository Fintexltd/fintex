<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LocationIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'search' => 'nullable|string',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "events"
      summary: "list of locations maching search field"
      produces:
      - "application/json"
      parameters:
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, searches in location"
EOT;

    }
}
