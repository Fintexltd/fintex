<?php

namespace App\Http\Requests;

use App\Entities\EntitiableInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class LseEntitySearchRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'search' => [
                'required',
                'string',
            ],
            'entitiable_type' => [
                'required',
                //'in:' . implode(',', EntitiableInterface::ENTITIABLE_TYPE),
                'in:' . EntitiableInterface::ENTITIABLE_TYPE_COMPANY,
            ],
        ];
    }

    public function messages()
    {
        return [
            //'entitiable_type.in' => 'Must be one of values: "' . implode('", "', EntitiableInterface::ENTITIABLE_TYPE) . '".',
            'entitiable_type.in' => 'Must be one of values: "' . EntitiableInterface::ENTITIABLE_TYPE_COMPANY . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "london-stock-exchange"
      summary: "entity search"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "search"
        in: "query"
        type: "string"
        required: true
        description: "urlencoded, entity with maching name are returned"
      - name: "entitiable_type"
        in: "query"
        type: "string"
        required: true
        description: "entity type"
        enum:
        - "company"
EOT;

    }
}
