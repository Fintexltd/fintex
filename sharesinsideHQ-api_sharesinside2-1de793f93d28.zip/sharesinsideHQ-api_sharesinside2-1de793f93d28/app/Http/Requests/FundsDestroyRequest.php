<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundsDestroyRequest extends FundAdminIndexRequest
{

    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'fund_ids' => [
                'required',
                'array',
            ],
            'fund_ids.*' => [
                'required',
                'integer',
                Rule::exists('funds', 'id'),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'fund_ids.*.exists' => 'There is no fund with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "funds"
      summary: "deletes selected funds"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminFundActionArray"
EOT;
    }
}
