<?php

namespace App\Http\Requests;

use App\Criteria\LseAssetSortByCriteria;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class LseAssetIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'rejected' => [
                'nullable',
                'boolean',
            ],
            'sort_by' => [
                'nullable',
                'in:' . implode(',', LseAssetSortByCriteria::AVALIABLE_SORT_TYPES),
            ],
            'page' => [
                'integer',
            ],
        ];
    }

    public function messages()
    {
        return [
            'sort_by.in' => 'Must be one of values: "' . implode('", "', LseAssetSortByCriteria::AVALIABLE_SORT_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "london-stock-exchange"
      summary: "list of asset"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "rejected"
        in: "query"
        type: "boolean"
        required: false
        description: "show rejected assets"
      - name: "sort_by"
        in: "query"
        type: "string"
        required: false
        description: "sort order for assets"
        enum:
        - "default"
        - "new_first"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for asset list"
EOT;
    }
}
