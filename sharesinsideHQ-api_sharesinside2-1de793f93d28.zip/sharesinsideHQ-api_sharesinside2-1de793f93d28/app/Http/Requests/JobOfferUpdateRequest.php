<?php

namespace App\Http\Requests;

class JobOfferUpdateRequest extends JobOfferStoreRequest
{
}
