<?php

namespace App\Http\Requests;

use App\Entities\CountryCallingCode;
use App\Repositories\AttachmentRepository;
use App\Repositories\SeSymbolRepository;
use App\Repositories\SocialMediaRepository;
use App\Services\DescriptionSanitizer;
use App\Services\RoleResolver;
use App\Services\Validation\Url;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CompanyStoreRequest extends FormRequest
{
    const MAX_DESCRIPTION_LENGTH = 8000;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        $rules = [
            'name' => [
                'required',
                'string',
                'max:64'
            ],
            'title' => [
                'nullable',
                'string',
                'max:128',
            ],
            'description' => [
                'required',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                    if (!strlen(trim(strip_tags($value)))) {
                        return $fail('Description is required.');
                    }
                },
            ],
            'phone' => [
                'phone'
            ],
            'email' => 'nullable|email',
            'country_id' => [
                'required',
                'exists:countries,id',
            ],
            'industry_id' => [
                'required',
                'exists:industries,id',
            ],
            'website' => [
                'required',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
                'max:191',
            ],
            'adress' => [
                'required',
                'string',
                'max:191',
            ],
            'longitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'latitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'logo' => [
                'required',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_COMPANY_LOGO);
                })
            ],
            'background' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_COMPANY_BACKGROUND);
                })
            ],
            'symbols' => [
                'nullable',
                'array',
                function ($attribute, $value, $fail) {
                    if (count($value)) {
                        $condition = collect($value)
                                ->pluck('default')
                                ->filter()
                                ->count() !== 1;
                        if ($condition) {
                            return $fail('One of symbol is required to be default.');
                        }
                    }
                },
            ],
            'symbols.*.id' => [
                'required',
                'distinct',
                'exists:symbols,id',
            ],
            'symbols.*.default' => [
                'required',
                'sometimes',
                'boolean',
            ],
            'se_symbols' => [
                'nullable',
                'array',
                function ($attribute, $value, $fail) {
                    if (count($value)) {
                        $condition = collect($value)
                                ->pluck('default')
                                ->filter()
                                ->count() !== 1;
                        if ($condition) {
                            return $fail('One of symbol is required to be default.');
                        }
                    }
                },
            ],
            'se_symbols.*.symbol' => [
                'required',
                'distinct',
            ],
            'se_symbols.*.default' => [
                'required',
                'sometimes',
                'boolean',
            ],
            'se_symbols.*.provider' => [
                'required',
                'in:' . implode(',', SeSymbolRepository::SE_SYMBOL_PROVIDERS),
            ],
            'social_media' => [
                'nullable',
                'array',
            ],
            'social_media.*.type' => [
                'required',
                'distinct',
                'in:' . implode(',', SocialMediaRepository::MEDIA_TYPES),
            ],
            'social_media.*.url' => [
                'nullable',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'social_media.*' => [
                function ($attribute, $value, $fail) {
                    $pattern = '/' . array_get($value, 'type') . '\.com/';
                    $string = array_get($value, 'url');
                    $condition = preg_match($pattern, $string) || empty($string);

                    if (!$condition) {
                        return $fail('Social media link should mach social media type.');
                    }
                },
            ],
            'attachments' => 'array',
            'attachments.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FILE);
                })
            ],
            'links' => 'array',
            'links.*.name' => 'required|max:64',
            'links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'excluded' => [
                'nullable',
                'array',
            ],
            'excluded.*' => [
                'integer',
                Rule::exists('countries', 'id'),
                'not_in:' . $this->user()->country_id,
            ],
            'stock_exchange_emails' => 'nullable|array',
            'stock_exchange_emails.*' => [
                'string',
                'max:191',
                'email',
                'distinct',
            ],
            'dont_allow_shareholders' => [
                'boolean',
            ],
            'videos' => 'array|forbidden_with:video_links',
            'videos.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_VIDEO);
                }),
            ],
            'video_links' => 'array|forbidden_with:videos',
            'video_links.*.name' => 'required|max:64',
            'video_links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
                'regex:/youtu\.?be|vimeo/',
            ],
        ];

        return $rules;
    }

    public function messages()
    {
        return [
            'excluded.*.not_in' => 'You cannot exclude company from your country.',
            'excluded.*.exists' => 'There is no country with selected id.',
            'social_media.*.type.in' => 'Media type should be one of following: "' . implode('", "', SocialMediaRepository::MEDIA_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "companies"
      summary: "Creates new company"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyStore"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyStore:
    type: "object"
    required:
    - "logo"
    - "name"
    - "description"
    - "country_id"
    - "industry_id"
    - "website"
    - "adress"
    - "longitude"
    - "latitude"
    - "symbols"
    properties:
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
          # - "string"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      logo:
        type: "string"
        description: "Required. Company logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Company background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "Required. 64 characters max."
        example: "Company Name"
      title:
        type: "string"
        description: "Optional. Title for company description."
        example: "company description title"
      description:
        type: "string"
        description: "Required. max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "company description"
      phone:
        type: "string"
        description: "Optional. A valid phone number."
        example: "123 456 789"
      email:
        type: "string"
        description: "Optional. A valid email address."
        example: "Jon Doe"
      country_id:
        type: "number"
        description: "Required. Must exist in countres table in database."
        example: "12"
      industry_id:
        type: "number"
        description: "Required. Must exist in industry table in database."
        example: "155"
      website:
        type: "string"
        description: "Required. Must be a valid URL. Max 191 chars."
        example: "www.sharesinside.com"
      adress:
        type: "string"
        description: "Required. Address search powered by Google. Google maps are embedded underneath."
        example: "Some kind of adress"
      longitude:
        type: "string"
        description: "Required. Longitude."
        example: "50"
      latitude:
        type: "string"
        description: "Required. Latitude."
        example: "50"
      symbols:
        type: "array"
        items:
          \$ref: "#/definitions/Symbol"
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
      excluded:
        type: "array"
        items:
          type: "integer"
        description: "array of countries for excluding news"
      stock_exchange_emails:
        type: "array"
        items:
          type: "string"
        description: "array of stock exchange emails"
EOT;

        return [
            'CompanyStore' => $def,
        ];
    }
}
