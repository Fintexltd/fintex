<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\FollowFiltersRequestTrait;

class FundsManagerFollowFiltersRequest extends FundsManagerIndexRequest
{
    use FollowFiltersRequestTrait;

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds managers"
      summary: "follows or unfollows funds managers maching filters"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
        - name: "Accept"
          in: "header"
          type: "string"
          enum:
          - "application/json"
        - name: "search"
          in: "query"
          type: "string"
          required: false
          description: "urlencoded, funds managers with maching name are returned"
        - name: "relation"
          in: "query"
          type: "array"
          items:
            type: "string"
          required: false
          description: "result contains only funds managers that have maching relation with user"
        - name: "type"
          in: "query"
          type: "string"
          required: true
          enum:
          - "follow"
          - "unfollow"
EOT;

    }
}
