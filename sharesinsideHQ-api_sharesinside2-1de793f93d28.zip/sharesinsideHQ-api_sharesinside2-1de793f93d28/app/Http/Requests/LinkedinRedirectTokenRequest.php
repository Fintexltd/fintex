<?php

namespace App\Http\Requests;

use App\Entities\SecurityToken;
use Illuminate\Foundation\Http\FormRequest;

class LinkedinRedirectTokenRequest extends FormRequest
{
    protected $token;

    public function getToken()
    {
        return $this->token;
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->token = SecurityToken::where('token', $this->get('token'))
//            ->where('type', SecurityToken::LINKEDIN_REDIRECT_TOKEN)
//            ->where('valid_until', '>', Carbon::now()->toDateString())
            ->first();

        return [
            'token' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    if (empty($this->token)) {
                        return $fail('Wrong token.');
                    }
                }
            ],
        ];
    }
}
