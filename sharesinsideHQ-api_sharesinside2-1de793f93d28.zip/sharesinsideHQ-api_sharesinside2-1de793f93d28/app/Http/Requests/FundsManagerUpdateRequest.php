<?php

namespace App\Http\Requests;

use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Entities\Attachment;
use App\Entities\Link;
use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundsManagerUpdateRequest extends FundsManagerStoreRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $allowedRoles = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $this->fundsManager);

        return (bool)array_intersect($allowedRoles, $userRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();
        $parentRules['name'][0] = 'nullable';
        $parentRules['logo'][0] = 'nullable';
        $parentRules['description'][0] = 'nullable';
        $parentRules['background'][0] = 'nullable';
        $parentRules['country_calling_code_id'][0] = 'nullable';
        $parentRules['address'][0] = 'nullable';
        $parentRules['longitude'][0] = 'nullable';
        $parentRules['latitude'][0] = 'nullable';
        $parentRules['excluded'][0] = 'nullable';
        $parentRules['terms_and_conditions'] = [
            'array',
            'forbidden_with:terms_and_conditions_links',
            function ($attribute, $value, $fail) {
                if (!$value && !$this->terms_and_conditions_links && is_array($this->delete_attachments) && count($this->delete_attachments)) {
                    $tcId = Attachment::where('attachable_type', FundsManager::class)
                        ->where('attachable_id', $this->fundsManager->id)
                        ->where('type', AttachmentRepository::TYPE_TERMS_AND_CONDITIONS)->first()->id;
                    if(in_array($tcId, $this->delete_attachments)) {
                        return $fail($attribute.' is required when remove old '.$attribute.' and terms_and_conditions_links is empty.');
                    }
                }
            }
        ];
        $parentRules['terms_and_conditions_links'] = [
            'array',
            'forbidden_with:terms_and_conditions',
            function ($attribute, $value, $fail) {
                if (!$value && !$this->terms_and_conditions && is_array($this->delete_links) && count($this->delete_links)) {
                    $linkId = Link::where('linkable_type', FundsManager::class)
                        ->where('linkable_id', $this->fundsManager->id)
                        ->where('type', LinkRepository::TYPE_TERMS_AND_CONDITIONS)->first()->id;
                    if(in_array($linkId, $this->delete_links)) {
                        return $fail($attribute.' is required when remove old '.$attribute.' and terms_and_conditions is empty.');
                    }
                }
            }
        ];

        $rules = [
            'delete_background' => [
                'boolean',
            ],
            'delete_attachments' => 'array',
            'delete_attachments.*' => [
                'integer',
                Rule::exists('attachments', 'id')->where(function ($query) {
                    $query
                        ->where('attachable_type', FundsManager::class)
                        ->where('attachable_id', $this->fundsManager->id);
                }),
            ],
            'delete_links' => 'array',
            'delete_links.*' => [
                Rule::exists('links', 'id')->where(function ($query) {
                    $query
                        ->where('linkable_type', FundsManager::class)
                        ->where('linkable_id', $this->fundsManager->id);
                }),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "funds managers"
      summary: "updates funds manager"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Funds manager ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/FundsManagerUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  FundsManagerUpdate:
    type: "object"
    properties:
      logo:
        type: "string"
        description: "Funds manager logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Funds manager background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "64 characters max."
        example: "Funds manager Name"
      title:
        type: "string"
        description: "Optional. Title for funds manager description. 500 characters max."
        example: "funds manager description title"
      description:
        type: "string"
        description: "Max 20000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "funds manager description"
      phone:
        type: "string"
        description: "Optional. A valid phone number."
        example: "123 456 789"
      email:
        type: "string"
        description: "Optional. A valid email address."
        example: "Jon Doe"
      country_calling_code_id:
        type: "number"
        description: "Must exist in country_calling_codes table in database."
        example: "12"
      website:
        type: "string"
        description: "Must be a valid URL. Max 191 chars."
        example: "www.sharesinside.com"
      address:
        type: "string"
        description: "Address search powered by Google. Google maps are embedded underneath."
        example: "Some kind of address"
      longitude:
        type: "string"
        description: "Longitude."
        example: "50"
      latitude:
        type: "string"
        description: "Latitude."
        example: "50"
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
      excluded:
        type: "array"
        items:
          type: "integer"
        description: "array of countries for excluding news"
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      videos:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      video_links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      terms_and_conditions:
        type: "array"
        description: "Sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      terms_and_conditions_links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      delete_background:
        type: "boolean"
      delete_attachments:
        type: "array"
        items:
          type: "integer"
      delete_links:
        type: "array"
        items:
          type: "integer"
EOT;

        return [
            'FundsManagerUpdate' => $def,
        ];
    }
}
