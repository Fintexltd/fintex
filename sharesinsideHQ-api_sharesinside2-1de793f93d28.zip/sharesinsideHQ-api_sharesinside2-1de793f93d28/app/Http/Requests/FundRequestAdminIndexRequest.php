<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class FundRequestAdminIndexRequest extends FundIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();
        unset($rules['sort_by']);
        unset($rules['seed']);
        unset($rules['relation']);

        $rules['per_page'] = [
            'nullable',
            'integer',
            'in:10,20,50',
        ];

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "funds"
      summary: "list of fund tiles"
      produces:
      - "application/json"
      parameters:
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for fund tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, funds with maching name are returned"
      - name: "per_page"
        in: "query"
        type: "integer"
        enum:
        - 10
        - 20
        - 50
        required: false
        description: "number of records per page, default 10"
EOT;

    }
}
