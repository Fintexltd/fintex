<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EconomicSectorIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
      tags:
      - "avaliable options"
      summary:
        "returns list of avaliable economic sectors"
      produces:
      - "application/json"
EOT;

    }
}
