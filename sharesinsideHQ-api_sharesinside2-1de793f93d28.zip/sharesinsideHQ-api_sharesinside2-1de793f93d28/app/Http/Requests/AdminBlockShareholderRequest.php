<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class AdminBlockShareholderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            $userId = $this->route('user')->id;

            $condition = (bool)Relation::query()
                ->where('user_id', $userId)
                ->where('type', RelationInterface::RELATION_TYPE_BLOCK_AS_SHAREHOLDER)
                ->count();

            if ($condition) {
                $validator
                    ->errors()
                    ->add('user', 'This user is already blocked from shareholder requests.');
            }
        });
    }
}
