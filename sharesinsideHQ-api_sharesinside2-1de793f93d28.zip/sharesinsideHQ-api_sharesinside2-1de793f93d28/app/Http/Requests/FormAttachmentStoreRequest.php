<?php

namespace App\Http\Requests;

use App\Repositories\AttachmentRepository;
use Illuminate\Foundation\Http\FormRequest;

class FormAttachmentStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $attachmentType = $this->get('type');

        switch ($attachmentType) {
            default:
                $rules = [
                    'type' => [
                        'required',
                        'in:' . AttachmentRepository::TYPE_FORM,
                    ],
                    'file' => [
                        'required',
                        'file',
                    ],
                ];
        }

        return $rules;
    }

    public function messages()
    {
        return [
            'type.in' => 'Attachment type should be one of following: "' . AttachmentRepository::TYPE_FORM . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    - name: "Accept"
      in: "header"
      type: "string"
      enum:
      - "application/json"
    post:
      produces:
      - "application/json"
      consumes:
      - "multipart/form-data"
      parameters:
      - name: "file"
        in: "formData"
        type: "file"
        required: true
        description: "Required. File to upload"
      - name: "type"
        in: "query"
        type: "string"
        required: true
        description: "Required. One of predefined types."
        enum:
        - "type_form"
EOT;

    }
}
