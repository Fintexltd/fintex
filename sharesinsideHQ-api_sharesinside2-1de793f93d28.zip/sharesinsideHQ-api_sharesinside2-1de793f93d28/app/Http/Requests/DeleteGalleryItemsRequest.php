<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\GalleryAndGalleryItemUpdateAndDeleteRequestTrait;
use App\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DeleteGalleryItemsRequest extends FormRequest
{
    use GalleryAndGalleryItemUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'delete_ids' => [
                'required',
                'array',
            ],
            'delete_ids.*' => [
                'required',
                'integer',
                Rule::exists('section_items', 'id')
                    ->where(function ($query) {
                        $query->where('section_id', $this->section->id);
                    }),
            ]
        ];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "albums"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/DeleteGalleryItemsRequest"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  DeleteGalleryItemsRequest:
    type: "object"
    required:
    - "delete_ids"
    properties:
      delete_ids:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          type: "string"
EOT;

        return ['DeleteGalleryItemsRequest' => $def];
    }
}
