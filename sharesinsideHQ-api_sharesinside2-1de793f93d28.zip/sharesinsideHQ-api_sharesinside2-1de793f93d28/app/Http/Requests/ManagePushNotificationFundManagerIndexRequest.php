<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class ManagePushNotificationFundManagerIndexRequest extends FundsManagerIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();

        unset($rules['sort_by'], $rules['seed']);

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "manage-push-notification"
      summary: "list of funds managers"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for funds managers list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, funds managers with maching name are returned"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only funds managers that have maching relation with user"
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "fund_type"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "currency"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "active"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "passive"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "trading_frequency"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "daily"
          - "weekly"
          - "monthly"
          - "yearly"
        required: false
      - name: "kind_of_fund"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "non-regulated"
          - "professional-investment"
          - "retail"
          - "listed"
          - "ucts"
          - "etf-s"
        required: false
      - name: "open_closed"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "open"
          - "closed"
        required: false
      - name: "management_fee_from"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "management_fee_to"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "performance_fee_from"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "performance_fee_to"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "duration_from"
        in: "query"
        type: "integer"
        required: false
        minimum: 1
        maximum: 4294967295
      - name: "duration_to"
        in: "query"
        type: "integer"
        required: false
        minimum: 1
        maximum: 4294967295
EOT;

    }
}
