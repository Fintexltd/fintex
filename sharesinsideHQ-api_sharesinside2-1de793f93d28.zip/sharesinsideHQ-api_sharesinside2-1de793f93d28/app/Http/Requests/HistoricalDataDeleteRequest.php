<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class HistoricalDataDeleteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $companyId = data_get($this, 'historical_datum.company_id');

        $company = Company::find($companyId);
        if (!$company) {
            return false;
        }

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $company);

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "historical-data"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Historical Data Piece ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
