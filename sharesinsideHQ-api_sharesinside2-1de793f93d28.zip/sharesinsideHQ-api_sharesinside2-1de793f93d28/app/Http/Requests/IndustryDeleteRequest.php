<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class IndustryDeleteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {

            $condition = Company::query()
                ->where('industry_id', $this->industry->id)
                ->count();

            if ($condition) {
                $validator
                    ->errors()
                    ->add('industry_id', 'Cannot remove industry assigned to existing company!');
            }
        });
    }
}
