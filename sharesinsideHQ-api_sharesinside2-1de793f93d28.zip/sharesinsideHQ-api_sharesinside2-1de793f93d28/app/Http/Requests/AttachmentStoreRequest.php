<?php

namespace App\Http\Requests;

use App\Repositories\AttachmentRepository;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class AttachmentStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $attachmentType = $this->get('type');

        switch ($attachmentType) {
//            case AttachmentRepository::TYPE_COMPANY_BACKGROUND:
//                $rules = [
//                    'attachment' => 'required|image|mimes:jpeg,png|dimensions:min_width=940|max:64000',
//                ];
//                break;
//            case AttachmentRepository::TYPE_COMPANY_LOGO:
//                $rules = [
//                    'attachment' => 'required|image|mimes:jpeg,png|dimensions:min_width=200,min_height=200|max:64000',
//                ];
//                break;
//            case AttachmentRepository::TYPE_FILE:
//                $rules = [
//                    'attachment' => [
//                        'required',
//                        'file',
//                        'max:64000',
//                        'mimes:' . implode(',', config('validation.allowed_extensions')),
//                        function ($attribute, $value, $fail) {
//                            $extension = $value->getClientOriginalExtension();
//                            $array = config('validation.allowed_extensions');
//
//                            $condition = in_array($extension, $array);
//
//                            if (!$condition) {
//                                return $fail("Only following extensions are avaliable: '." . implode("', '.", $array) . "'.");
//                            }
//                        },
//                        function ($attribute, $value, $fail) {
//                            $mimeType = $value->getMimeType();
//
//                            $condition = in_array($mimeType, config('validation.restricted_mime_types'));
//
//                            if ($condition) {
//                                return $fail('Executable files are not allowed.');
//                            }
//                        }
//                    ],
//                ];
//                break;
//            case AttachmentRepository::TYPE_IMAGE:
//                $rules = [
//                    'attachment' => 'required|file|max:64000|image|mimes:jpeg,jpg,png',
//                ];
//                break;
//            case AttachmentRepository::TYPE_VIDEO:
//                $rules = [
//                    'attachment' => 'required|file|max:2000000|mimes:flv,mp4,mov,avi,wmv,qt',
//                ];
//                break;
            default:
                $rules = [
                    'type' => [
                        'required',
                        'in:' . implode(',', AttachmentRepository::ATTACHMENT_TYPES),
                    ],
                    'file' => [
                        'required',
                        'file',
                    ],
                ];
        }

        return $rules;
    }

    public function messages()
    {
        return [
            'type.in' => 'Attachment type should be one of following: "' . implode('", "', AttachmentRepository::ATTACHMENT_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    - name: "Accept"
      in: "header"
      type: "string"
      enum:
      - "application/json"
    post:
      produces:
      - "application/json"
      consumes:
      - "multipart/form-data"
      parameters:
      - name: "file"
        in: "formData"
        type: "file"
        required: true
        description: "Required. File to upload"
      - name: "type"
        in: "query"
        type: "string"
        required: true
        description: "Required. One of predefined types."
        enum:
        - "type_file"
        - "type_image"
        - "type_video"
        - "type_company_logo"
        - "type_company_background"
        - "type_funds_manager_logo"
        - "type_funds_manager_background"
        - "type_fund_logo"
        - "type_fund_background"
        - "type_terms_and_conditions"
EOT;

    }
}
