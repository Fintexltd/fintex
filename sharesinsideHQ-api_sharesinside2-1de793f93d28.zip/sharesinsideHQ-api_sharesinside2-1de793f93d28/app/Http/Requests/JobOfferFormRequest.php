<?php

namespace App\Http\Requests;

use App\Repositories\AttachmentRepository;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class JobOfferFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'id' => 'required|integer|exists:job_offers',
            'name' => 'required|string|min:1',
            'surname' => 'required|string|min:1',
            'email' => 'required|email',
            'contact' => 'required|string|min:9|max:16|regex:/^\+\d{8,15}$/',
            'country_id' => 'required|integer|exists:countries,id',
            'files' => [
                'required',
                'array',
                'max:3',
            ],
            'files.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query
                        ->where('value', AttachmentRepository::TYPE_FORM)
                        ->where('type', 'uploaded_file')
                        ->where('value', 'type_form')
                        ->where('valid_until', '>=', Carbon::now())
                        ;
                }),
            ],
        ];
    }

    public function messages()
    {
        return [
            'contact.regex' => 'Valid contact number starts with + followed by at least 8, at most 15 digits.',
        ];
    }
}
