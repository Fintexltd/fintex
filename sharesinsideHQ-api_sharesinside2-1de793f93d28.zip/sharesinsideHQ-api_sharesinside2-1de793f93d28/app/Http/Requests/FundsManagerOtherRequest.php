<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FundsManagerOtherRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:

    get:
      tags:
      - "funds managers"
      summary: "list of funds manager tiles"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Funds manager ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, funds managers with maching name are returned"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only funds managers that have maching relation with user"
EOT;

    }
}
