<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class DeleteLinkedinRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if (empty($this->user()->password)) {
                $validator
                    ->errors()
                    ->add('password', 'Cannot remove external login if password is not set!');
            }
            if (empty($this->user()->linkedin_id)) {
                $validator
                    ->errors()
                    ->add('linkedin_id', 'This account is not connected with LinkedIn.');
            }
        });
    }
}
