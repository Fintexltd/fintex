<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\GalleryAndGalleryItemUpdateAndDeleteRequestTrait;
use Illuminate\Foundation\Http\FormRequest;

class GalleryItemDeleteRequest extends FormRequest
{
    use GalleryAndGalleryItemUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "company gallery"
      summary: "Deletes company gallery item"
      parameters:
      - name: "id"
        in: "path"
        type: "string"
        required: true
        description: "Required. Must exist in database."
      produces:
      - "application/json"
EOT;

    }
}
