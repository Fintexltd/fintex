<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundsManagersDestroyRequest extends FundsManagerAdminIndexRequest
{

    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'funds_manager_ids' => [
                'required',
                'array',
            ],
            'funds_manager_ids.*' => [
                'required',
                'integer',
                Rule::exists('funds_managers', 'id'),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'funds_manager_ids.*.exists' => 'There is no funds manager with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "funds managers"
      summary: "deletes selected funds managers"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminFundsManagerActionArray"
EOT;
    }
}
