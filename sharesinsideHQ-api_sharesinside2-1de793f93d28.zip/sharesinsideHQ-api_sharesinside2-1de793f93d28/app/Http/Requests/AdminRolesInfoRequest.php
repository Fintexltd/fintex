<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AdminRolesInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => [
                'required',
                'string',
                'min:1',
                Rule::exists('users', 'email')->where(function ($query) {
                    $query->where('email_confirmed', true);
                }),
            ],
        ];
    }

    public function messages()
    {
        return [
            'email.exists' => 'This user doesn\'t exist.',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "admin"
      summary: "list of countries that user is domestic admin and info that user is global/content admin"
      produces:
      - "application/json"
      parameters:
      - name: "email"
        in: "query"
        type: "string"
EOT;
    }
}
