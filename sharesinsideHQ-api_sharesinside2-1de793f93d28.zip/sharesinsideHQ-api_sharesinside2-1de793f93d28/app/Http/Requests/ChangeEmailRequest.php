<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class ChangeEmailRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check() && !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'new_email' => [
                'required',
                'email',
                'unique:users,email',
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
        - "users"
      summary: "Changes users email"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with new email"
        required: true
        schema:
          \$ref: "#/definitions/EmailChange"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  EmailChange:
    type: "object"
    required:
    - "new_email"
    properties:
      new_email:
        type: "string"
        description: "Required. Cannot exists in database"
EOT;

        return ['EmailChange' => $def];
    }
}
