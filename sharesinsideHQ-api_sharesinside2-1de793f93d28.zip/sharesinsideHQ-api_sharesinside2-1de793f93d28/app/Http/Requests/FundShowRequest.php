<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class FundShowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ($this->fund->is_accepted) {
            return true;
        }

        $allowedRoles = [
            Relation::RELATION_TYPE_GLOBAL_ADMIN,
            Relation::RELATION_TYPE_CONTENT_ADMIN,
            Relation::RELATION_TYPE_PRIMARY_ADMIN,
            Relation::RELATION_TYPE_SECONDARY_ADMIN,
        ];
        
        $userRoles = RoleResolver::getRoles($this->user(), $this->fund->fundsManager);

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "funds"
      summary: "Fund about"
      consumes:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Fund ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      produces:
      - "application/json"
EOT;

    }
}
