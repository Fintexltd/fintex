<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class ChangeUsernameRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return Auth::check() && !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'new_username' => [
                'required',
                'string',
                'min:3',
                'max:32',
                'unique:users,name',
                'regex:/^[\w\.]+$/',
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    - name: "Accept"
      in: "header"
      type: "string"
      enum:
      - "application/json"
    post:
      tags:
        - "users"
      summary: "Changes users username"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with new username"
        required: true
        schema:
          \$ref: "#/definitions/UsernameChange"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  UsernameChange:
    type: "object"
    required:
    - "new_username"
    properties:
      new_username:
        type: "string"
        description: "Required. Cannot exists in database"
EOT;
        return ['UsernameChange' => $def];

    }
}
