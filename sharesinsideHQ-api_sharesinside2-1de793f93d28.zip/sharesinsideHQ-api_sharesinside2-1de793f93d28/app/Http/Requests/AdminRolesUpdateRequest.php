<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AdminRolesUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = User::query()
            ->where('email', $this->get('email'))
            ->where('email_confirmed', true)
            ->first();

        return [
            'email' => [
                'required',
                'string',
                'email',
                function ($attribute, $value, $fail) use ($user) {
                    if (!$user) {
                        return $fail('This user doesn\'t exist');
                    }
                }
            ],
            'country_ids' => 'array|nullable',
            'country_ids.*' => [
                'required',
                'integer',
                'exists:countries,id',
                function ($attribute, $value, $fail) use ($user) {
                    $condition = (bool)Relation::query()
                        ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
                        ->where('user_id', '!=', data_get($user, 'id'))
                        ->where('related_id', $value)
                        ->count();

                    if ($condition) {
                        return $fail('This country already has a domestic admin');
                    }
                }
            ],
            'is_global_admin' => [
                'boolean',
                'nullable',
                function ($attribute, $value, $fail) use ($user) {
                    if (data_get($user, 'id')==auth()->user()->id) {
                        return $fail('You cannot modify your own global admin role');
                    }
                }
            ],
            'is_content_admin' => 'boolean|nullable',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "domestic"
      summary: "create/updated domestic admin"
      produces:
      - "application/json"
      parameters:
      - name: "email"
        in: "query"
        type: "string"
        required: true
      - name: "country_ids"
        in: "body"
        type: "array"
          items:
            type: "string"
        required: true
EOT;
    }

}
