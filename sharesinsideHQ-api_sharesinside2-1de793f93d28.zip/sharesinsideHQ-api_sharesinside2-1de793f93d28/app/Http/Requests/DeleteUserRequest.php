<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class DeleteUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return \Auth::check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      tags:
        - "users"
      summary: "Removes user from database"
      produces:
      - "application/json"
EOT;

    }
}
