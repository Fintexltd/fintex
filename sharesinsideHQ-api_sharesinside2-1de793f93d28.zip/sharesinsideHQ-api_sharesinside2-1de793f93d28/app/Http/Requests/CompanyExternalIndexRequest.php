<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class CompanyExternalIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      produces:
      - "application/json"
EOT;

    }
}
