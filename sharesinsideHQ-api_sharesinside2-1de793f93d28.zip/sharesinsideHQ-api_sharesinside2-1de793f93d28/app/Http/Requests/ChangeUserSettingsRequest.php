<?php

namespace App\Http\Requests;

class ChangeUserSettingsRequest extends ChangePasswordRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return parent::authorize();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
//        $request = resolve(ChangeUsernameRequest::class);
//        $usernameRules = $request->rules();
        $usernameRules = [
            'new_username' => [
                'required',
                'string',
                'min:3',
                'max:32',
                'unique:users,name',
                'regex:/^[\w\.]+$/',
            ],
        ];
        $usernameRules['new_username'][0] = 'required_without_all:new_email,new_password';

//        $request = resolve(ChangeEmailRequest::class);
//        $emailRules = $request->rules();
        $emailRules = [
            'new_email' => [
                'required',
                'email',
                'unique:users,email',
            ],
        ];
        $emailRules['new_email'][0] = 'required_without_all:new_username,new_password';

        $passwordRules = parent::rules();
        $passwordRules['new_password'][0] = 'required_without_all:new_username,new_email';

        return array_merge($usernameRules, $emailRules, $passwordRules);
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
        - "users"
      summary: "Changes users password"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with old and new password"
        required: true
        schema:
          \$ref: "#/definitions/UserSettingsChange"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  UserSettingsChange:
    type: "object"
    properties:
      new_username:
        type: "string"
        description: "Required without new_password and new_email. Cannot exists in database"
      old_password:
        type: "string"
        description: "Required with new_password."
      new_password:
        type: "string"
        description: "Required without news_username and new_email. Min 8 chars including 1 or more digits"
      repeat_password:
        type: "string"
        description: "Required with new_password. Must be the same as new_password"
      new_email:
        type: "string"
        description: "Required without new_username and new_password. Cannot exists in database"
EOT;

        return ['UserSettingsChange' => $def];
    }
}
