<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EventLatestRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "event"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Event ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
