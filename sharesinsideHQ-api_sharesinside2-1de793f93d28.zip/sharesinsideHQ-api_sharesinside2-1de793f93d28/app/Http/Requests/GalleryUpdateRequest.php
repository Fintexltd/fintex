<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\GalleryAndGalleryItemUpdateAndDeleteRequestTrait;
use App\Entities\RelationInterface;
use Illuminate\Foundation\Http\FormRequest;

class GalleryUpdateRequest extends FormRequest
{
    use GalleryAndGalleryItemUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    post:
      tags:
      - "company gallery"
      summary: "Updates company gallery"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "id"
        in: "path"
        type: "string"
        required: true
        description: "Required. Must exist in database."
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyGalleryUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyGalleryUpdate:
    type: "object"
    required:
    - "name"
    - "_method"
    properties:
      name:
        type: "string"
      _method:
        type: "string"
        enum:
        - "put"
EOT;
        return ['CompanyGalleryUpdate' => $def];

    }
}
