<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundsAcceptRequest extends FundAdminIndexRequest
{
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'fund_ids' => [
                'array',
            ],
            'fund_ids.*' => [
                'integer',
                Rule::exists('funds', 'id')
                    ->where(function ($query) {
                        $query->where('is_accepted', false);
                    }),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'fund_ids.*.exists' => 'There is no fund you can accept with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "funds"
      summary: "accept selected funds"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminFundActionArray"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  AdminFundActionArray:
    type: "object"
    properties:
      fund_ids:
        type: "array"
        items:
          type: "integer"
        description: "apply action for funds present on list"
EOT;

        return ['AdminFundActionArray' => $def];
    }
}
