<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Http\Requests\Traits\EmployeeUpdateAndDeleteRequestTrait;

class EmployeeUpdateRequest extends EmployeeStoreRequest
{
    use EmployeeUpdateAndDeleteRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();
        unset($parentRules['section_id']);
        $parentRules['name'][0] = 'nullable';

        $parentRules['delete_attachment'] = 'nullable|boolean';

        return $parentRules;
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "employees"
      summary: "updates employee"
      consumes:
      - "multipart/form-data"
      produces:
      - "application/json"
      parameters:
      - name: "id"
        in: "path"
        type: "integer"
        required: true
        description: "Required. Must exist in database."
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/EmployeeUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOF
  EmployeeUpdate:
    type: "object"
    properties:
      section_id:
        type: "string"
        description: "Must exist in database."
      name:
        type: "string"
        description: "Team member name. 64 characters max."
      photo:
        type: "string"
        description: "uploaded file token"
      position:
        type: "string"
        description: "Team member position. Optional. 64 characters max."
      description:
        type: "string"
        description: "Team member short description. Optional. 512 characters max."
      email:
        type: "string"
        description: "Team member email address. Optional. 64 characters max, must be a valid email address."
      phone_number:
        type: "string"
        description: "Team member phone number. Optional. 12 digits max, only digits."
      attachment:
        \$ref: "#/definitions/AttachmentToken"
      delete_attachment:
        type: "boolean"
        description: "if should delete previously attached file."
EOF;

        return ['EmployeeUpdate' => $def];
    }
}
