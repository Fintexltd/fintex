<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FundOtherRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:

    get:
      tags:
      - "funds"
      summary: "list of fund tiles"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Fund ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, funds with maching name are returned"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only funds that have maching relation with user"
EOT;

    }
}
