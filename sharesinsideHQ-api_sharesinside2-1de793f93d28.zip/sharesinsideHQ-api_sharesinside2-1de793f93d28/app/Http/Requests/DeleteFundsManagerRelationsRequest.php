<?php

namespace App\Http\Requests;

use App\Entities\FundsManager;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class DeleteFundsManagerRelationsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $restrictedTypes = $this->getRestrictedTypes();

        $types = Relation::query()
            ->find($this->get('relations'))
            ->pluck('type')
            ->all();

        return !(bool)array_intersect($restrictedTypes, $types);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'relations' => [
                'required',
                'array',
            ],
            'relations.*' => [
                'required',
                'integer',
                Rule::exists('relations', 'id')->where(function ($query) {
                    $query
                        ->where('related_type', FundsManager::class)
                        ->where('type', '!=', User::RELATION_TYPE_PRIMARY_ADMIN)
                        ->where('related_id', data_get($this, 'fundsManager.id'));
                }),
            ],
        ];
    }

    private function getRestrictedTypes()
    {
        $restrictedTypes = [];

        $userRoles = RoleResolver::getRoles($this->user(), $this->fundsManager);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        if (!(bool)array_intersect($allowedRoles, $userRoles)) {
            $restrictedTypes = [
                RelationInterface::RELATION_TYPE_EDITOR,
                RelationInterface::RELATION_TYPE_FOLLOWER,
            ];
        }

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
        ];

        if (!(bool)array_intersect($allowedRoles, $userRoles)) {
            $restrictedTypes[] = RelationInterface::RELATION_TYPE_SECONDARY_ADMIN;
        }

        return $restrictedTypes;
    }
}
