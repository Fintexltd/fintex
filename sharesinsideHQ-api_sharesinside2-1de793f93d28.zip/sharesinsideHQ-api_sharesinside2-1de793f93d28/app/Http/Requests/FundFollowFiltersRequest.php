<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\FollowFiltersRequestTrait;

class FundFollowFiltersRequest extends FundIndexRequest
{
    use FollowFiltersRequestTrait;

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds"
      summary: "follows or unfollows funds maching filters"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
        - name: "Accept"
          in: "header"
          type: "string"
          enum:
          - "application/json"
        - name: "search"
          in: "query"
          type: "string"
          required: false
          description: "urlencoded, funds with maching name are returned"
        - name: "relation"
          in: "query"
          type: "array"
          items:
            type: "string"
          required: false
          description: "result contains only funds that have maching relation with user"
        - name: "type"
          in: "query"
          type: "string"
          required: true
          enum:
          - "follow"
          - "unfollow"
EOT;

    }
}
