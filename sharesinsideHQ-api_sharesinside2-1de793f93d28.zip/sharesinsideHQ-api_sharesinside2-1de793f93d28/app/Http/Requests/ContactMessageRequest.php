<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContactMessageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'email' => 'required|email',
            'message' => 'required|string'
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      summary: "Sends a message from contact form"
      consumes:
      - "multipart/form-data"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with contact message data"
        required: true
        schema:
          \$ref: "#/definitions/ContactMessage"
EOT;

    }

    public static function definitons()
    {
        $def = <<<EOT
  ContactMessage:
    type: "object"
    required:
    - "email"
    - "name"
    - "message"
    properties:
      email:
        type: "string"
        description: "Required. Email of the sender."
      name:
        type: "string"
        description: "Required. Name of the sender."
      message:
        type: "string"
        description: "Required. Message content."
EOT;

        return ['ContactMessage' => $def];
    }

}
