<?php

namespace App\Http\Requests;

use App\Entities\Startup;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\StartupsAdminManager;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class ManageStartupRoleRequest extends FormRequest
{
    protected $candidate;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $roles = RoleResolver::getRoles($this->user(), $this->startup);

        switch ($this->get('action')) {
            case StartupsAdminManager::SET_PRIMARY_ADMIN_ACTION:
            case StartupsAdminManager::SET_SECONDARY_ADMIN_ACTION:
                $allowedRoles = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                    RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
                ];
                break;
            case StartupsAdminManager::SET_EDITOR_ACTION:
            case StartupsAdminManager::ADD_VIP_ACTION:
                $allowedRoles = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                    RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
                    RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
                ];
                break;
            default:
                $allowedRoles = [];
        }

        return (bool)array_intersect($allowedRoles, $roles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $candidate = User::where('email', $this->get('user_email'))->first();
        $this->setCandidate($candidate);

        return [
            'action' => [
                'required',
                'string',
                'in:' . implode(',', StartupsAdminManager::AVALIABLE_ACTIONS),
                function ($attribute, $value, $fail) {
                    switch ($value) {
                        case StartupsAdminManager::SET_PRIMARY_ADMIN_ACTION:
                            $primaryAdminId = $this->startup
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('User is already primary admin in this startup.');
                            }
                            break;
                        case StartupsAdminManager::SET_SECONDARY_ADMIN_ACTION:
                            $primaryAdminId = $this->startup
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('Cannot change primary admin role.');
                            }

                            $condition = (bool)Relation::query()
                                ->where('type', RelationInterface::RELATION_TYPE_SECONDARY_ADMIN)
                                ->where('related_type', Startup::class)
                                ->where('related_id', $this->startup->id)
                                ->where('user_id', $userId)
                                ->count();


                            if ($condition) {
                                return $fail('This user is already a secondary admin in that startup.');
                            }
                            break;
                        case StartupsAdminManager::SET_EDITOR_ACTION:
                            $primaryAdminId = $this->startup
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('Cannot change primary admin role.');
                            }

                            $condition = (bool)Relation::query()
                                ->where('type', RelationInterface::RELATION_TYPE_EDITOR)
                                ->where('related_type', Startup::class)
                                ->where('related_id', $this->startup->id)
                                ->where('user_id', $userId)
                                ->count();


                            if ($condition) {
                                return $fail('This user is already an editor in that startup.');
                            }
                            break;
                        case StartupsAdminManager::ADD_VIP_ACTION:
                            $condition = Relation::query()
                                ->where('related_type', Startup::class)
                                ->where('related_id', $this->startup->id)
                                ->where('user_id', data_get($this->candidate, 'id'))
                                ->where('type', RelationInterface::RELATION_TYPE_VIP)
                                ->first();

                            if ($condition) {
                                return $fail('This user is already a VIP in that startup.');
                            }
                            break;
                    }
                }
            ],
            'user_email' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    if (empty($this->candidate)) {
                        return $fail("This user doesn't exist.");
                    }

                    if (!$this->candidate->email_confirmed) {
                        $message = 'You can’t add ';

                        switch ($this->get('action')) {
                            case StartupsAdminManager::SET_PRIMARY_ADMIN_ACTION:
                                $message .= 'Primary Admin, t';
                                break;
                            case StartupsAdminManager::SET_SECONDARY_ADMIN_ACTION:
                                $message .= 'Secondary Admin, t';
                                break;
                            case StartupsAdminManager::SET_EDITOR_ACTION:
                                $message .= 'Editor, t';
                                break;
                            case StartupsAdminManager::ADD_VIP_ACTION:
                                $message .= 'VIP, t';
                                break;
                            default:
                                $message = 'T';
                                break;
                        }

                        return $fail($message . 'his account was not confirmed.');
                    }
                },
            ],
        ];
    }

    private function setCandidate($candidate)
    {
        $this->candidate = $candidate;
    }

    private function getCandidateId()
    {
        return $this->candidate ? $this->candidate->id : 0;
    }

    public function getCandidate()
    {
        return $this->candidate;
    }

    public function messages()
    {
        return [
            'action.in' => 'Action should be one of: "' . implode('", "', StartupsAdminManager::AVALIABLE_ACTIONS) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "startups"
      summary: "Manage startup primary admin, secondary admins and editors."
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Startup ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/StartupManageAdminRequest"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  StartupManageAdminRequest:
    type: "object"
    required:
    - "action"
    - "user_id"
    properties:
      action:
        type: "string"
        enum:
        - 'set_primary_admin'
        - 'set_secondary_admin'
        - 'set_editor'
        - 'add_vip'
      user_email:
        type: "string"
EOT;

        return ['StartupManageAdminRequest' => $def];
    }
}
