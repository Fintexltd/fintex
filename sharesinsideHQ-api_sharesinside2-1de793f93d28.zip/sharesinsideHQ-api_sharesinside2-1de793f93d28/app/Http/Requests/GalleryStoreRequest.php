<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\EntitiableInterface;
use App\Entities\RelationInterface;
use App\Entities\Startup;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class GalleryStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $userRoles = RoleResolver::getRoles($this->user(), $this->entity);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        if (get_class($this->entity)==Company::class) {
            $allowedRoles[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
        }

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    protected function prepareForValidation()
    {
        $this->validate([
            'entitiable_type' => [
                'required_without:section_id',
                'in:' . implode(',', EntitiableInterface::ENTITIABLE_TYPE),
            ],
            'entitiable_id' => [
                'required_without:section_id',
                'integer',
                function ($attribute, $value, $fail) {
                    switch ($this->input('entitiable_type')) {
                        case EntitiableInterface::ENTITIABLE_TYPE_COMPANY:
                            $this->entity = Company::find($value);
                            break;
                        case EntitiableInterface::ENTITIABLE_TYPE_STARTUP:
                            $this->entity = Startup::find($value);
                            break;
                    }

                    if (!$this->entity ) {
                        return $fail('There is no such entitiable_type with this entitiable_id.');
                    }
                },
            ],
        ]);

        $input = $this->all();
        $input['entitiable_type'] = EntitiableInterface::ENTITIABLE_TYPE_CLASS[$input['entitiable_type']];
        $this->merge($input);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
                'max:64',
            ],
            /*'company_id' => [
                'required',
                'integer',
                'exists:companies,id',
            ]*/
            'entitiable_type' => [], //validated by prepareForValidation()
            'entitiable_id' => [], //validated by prepareForValidation()
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "company gallery"
      summary: "Creates new company gallery"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyGalleryStore"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyGalleryStore:
    type: "object"
    required:
    - "name"
    - "company_id"
    properties:
      name:
        type: "string"
      company_id:
        type: "integer"
EOT;

        return ['CompanyGalleryStore' => $def];
    }
}
