<?php

namespace App\Http\Requests;

use App\Entities\SecurityToken;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ExportRelationDataRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'token' => [
                'required',
                'string',
                Rule::exists('security_tokens', 'token')
                    ->where(function ($query) {
                        $query
                            ->where('type', SecurityToken::EXPORT_MY_RELATION_DATA)
                            ->where('valid_until', '>=', Carbon::now());
                    })
            ]
        ];
    }
}
