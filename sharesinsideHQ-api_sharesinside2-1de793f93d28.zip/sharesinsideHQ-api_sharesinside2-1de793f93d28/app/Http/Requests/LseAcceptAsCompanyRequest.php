<?php

namespace App\Http\Requests;

use App\Entities\EntitiableInterface;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class LseAcceptAsCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return (RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user())) && $this->lseAsset && !$this->lseAsset->is_accepted;
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'entitiable_type' => EntitiableInterface::ENTITIABLE_TYPE_COMPANY
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'industry_id' => [
                'required',
                'integer',
                'exists:industries,id',
            ],
            'country_id' => [
                'required',
                'integer',
                'exists:countries,id',
            ],
            'address' => [
                'required',
                'string',
                'max:191',
            ],
            'longitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'latitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'entitiable_type' => [
                'required',
                'in:'.EntitiableInterface::ENTITIABLE_TYPE_COMPANY
            ]
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "london-stock-exchange"
      summary: "accept asset"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Asset ID"
      - in: "body"
        name: "body"
        description: "json object with asset data"
        required: true
        schema:
          \$ref: "#/definitions/LseAcceptAsCompany"
EOT;
    }
        public static function definitions()
        {
            $def = <<<EOT
      LseAcceptAsCompany:
        type: "object"
        required:
        - "industry_id"
        - "country_id"
        - "address"
        - "longitude"
        - "latitude"
        properties:
          industry_id:
            type: "number"
            description: "Required. Must exist in industry table in database."
            example: "155"
          country_id:
            type: "number"
            description: "Required. Must exist in countres table in database."
            example: "12"
          address:
            type: "string"
            description: "Required. Address search powered by Google. Google maps are embedded underneath."
            example: "Some kind of adress"
          longitude:
            type: "string"
            description: "Required. Longitude."
            example: "50"
          latitude:
            type: "string"
            description: "Required. Latitude."
            example: "50"
EOT;

            return [
                'LseAcceptAsCompany' => $def,
            ];
        }
}
