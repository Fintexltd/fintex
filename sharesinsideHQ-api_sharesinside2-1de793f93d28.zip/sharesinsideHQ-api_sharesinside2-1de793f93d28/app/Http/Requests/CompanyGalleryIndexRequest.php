<?php

namespace App\Http\Requests;

class CompanyGalleryIndexRequest extends CompanyShowRequest
{
    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      summary: "Returns list of company galleries"
      parameters:
      - name: "id"
        in: "path"
        type: "integer"
        required: true
        description: "Required. Must exist in database."
      produces:
      - "application/json"
EOT;

    }
}
