<?php

namespace App\Http\Requests;

use App\Entities\FundsManager;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\FundsManagersAdminManager;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class ManageFundsManagerRoleRequest extends FormRequest
{
    protected $candidate;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $roles = RoleResolver::getRoles($this->user(), $this->fundsManager);

        /*switch ($this->get('action')) {
            case FundsManagersAdminManager::SET_PRIMARY_ADMIN_ACTION:
                $allowedRoles = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                ];
                break;
            case FundsManagersAdminManager::SET_SECONDARY_ADMIN_ACTION:
                $allowedRoles = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                ];
                break;
            case FundsManagersAdminManager::SET_EDITOR_ACTION:
                $allowedRoles = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                    RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
                ];
                break;
            default:
                $allowedRoles = [];
        }*/

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
        ];

        return (bool)array_intersect($allowedRoles, $roles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $candidate = User::where('email', $this->get('user_email'))->first();
        $this->setCandidate($candidate);

        return [
            'action' => [
                'required',
                'string',
                'in:' . implode(',', FundsManagersAdminManager::AVALIABLE_ACTIONS),
                function ($attribute, $value, $fail) {
                    switch ($value) {
                        case FundsManagersAdminManager::SET_PRIMARY_ADMIN_ACTION:
                            $primaryAdminId = $this->fundsManager
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('User is already primary admin in this funds manager.');
                            }
                            break;
                        case FundsManagersAdminManager::SET_SECONDARY_ADMIN_ACTION:
                            $primaryAdminId = $this->fundsManager
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('Cannot change primary admin role.');
                            }

                            $condition = (bool)Relation::query()
                                ->where('type', RelationInterface::RELATION_TYPE_SECONDARY_ADMIN)
                                ->where('related_type', FundsManager::class)
                                ->where('related_id', $this->fundsManager->id)
                                ->where('user_id', $userId)
                                ->count();


                            if ($condition) {
                                return $fail('This user is already a secondary admin in that funds manager.');
                            }
                            break;
                        /*case FundsManagersAdminManager::SET_EDITOR_ACTION:
                            $primaryAdminId = $this->fundsManager
                                ->admins()
                                ->wherePivot('type', RelationInterface::RELATION_TYPE_PRIMARY_ADMIN)
                                ->get()
                                ->pluck('id')
                                ->first();

                            $userId = $this->getCandidateId();
                            $condition = $primaryAdminId === $userId;

                            if ($condition) {
                                return $fail('Cannot change primary admin role.');
                            }

                            $condition = (bool)Relation::query()
                                ->where('type', RelationInterface::RELATION_TYPE_EDITOR)
                                ->where('related_type', FundsManager::class)
                                ->where('related_id', $this->fundsManager->id)
                                ->where('user_id', $userId)
                                ->count();


                            if ($condition) {
                                return $fail('This user is already an editor in that funds manager.');
                            }
                            break;*/
                    }
                }
            ],
            'user_email' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    if (empty($this->candidate)) {
                        return $fail("This user doesn't exist.");
                    }

                    if (!$this->candidate->email_confirmed) {
                        $message = 'You can’t add ';

                        switch ($this->get('action')) {
                            case FundsManagersAdminManager::SET_PRIMARY_ADMIN_ACTION:
                                $message .= 'Primary Admin, t';
                                break;
                            case FundsManagersAdminManager::SET_SECONDARY_ADMIN_ACTION:
                                $message .= 'Secondary Admin, t';
                                break;
                            /*case FundsManagersAdminManager::SET_EDITOR_ACTION:
                                $message .= 'Editor, t';
                                break;*/
                            default:
                                $message = 'T';
                                break;
                        }

                        return $fail($message . 'his account was not confirmed.');
                    }
                },
            ],
        ];
    }

    private function setCandidate($candidate)
    {
        $this->candidate = $candidate;
    }

    private function getCandidateId()
    {
        return $this->candidate ? $this->candidate->id : 0;
    }

    public function getCandidate()
    {
        return $this->candidate;
    }

    public function messages()
    {
        return [
            'action.in' => 'Action should be one of: "' . implode('", "', FundsManagersAdminManager::AVALIABLE_ACTIONS) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds managers"
      summary: "Manage funds manager primary admin and secondary admins."
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Funds manager ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/ManageFundsManagerRoleRequest"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  ManageFundsManagerRoleRequest:
    type: "object"
    required:
    - "action"
    - "user_email"
    properties:
      action:
        type: "string"
        enum:
        - 'set_primary_admin'
        - 'set_secondary_admin'
      user_email:
        type: "string"
EOT;

        return ['ManageFundsManagerRoleRequest' => $def];
    }
}
