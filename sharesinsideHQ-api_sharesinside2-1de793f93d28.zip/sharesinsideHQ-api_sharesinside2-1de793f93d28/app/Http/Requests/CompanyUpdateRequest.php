<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class CompanyUpdateRequest extends CompanyStoreRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $allowedRoles = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $this->company);

        return (bool)array_intersect($allowedRoles, $userRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();
        $parentRules['name'][0] = 'nullable';
        $parentRules['logo'][0] = 'nullable';
        $parentRules['description'][0] = 'nullable';
        $parentRules['background'][0] = 'nullable';
        $parentRules['country_id'][0] = 'nullable';
        $parentRules['industry_id'][0] = 'nullable';
        $parentRules['website'][0] = 'nullable';
        $parentRules['adress'][0] = 'nullable';
        $parentRules['longitude'][0] = 'nullable';
        $parentRules['latitude'][0] = 'nullable';
        $parentRules['logo'][0] = 'nullable';
        $parentRules['excluded'][0] = 'nullable';

        $rules = [
            'delete_background' => [
                'boolean',
            ],
            'delete_attachments' => 'array',
            'delete_attachments.*' => [
                'integer',
                Rule::exists('attachments', 'id')->where(function ($query) {
                    $query
                        ->where('attachable_type', Company::class)
                        ->where('attachable_id', $this->company->id);
                }),
            ],
            'delete_links' => 'array',
            'delete_links.*' => [
                Rule::exists('links', 'id')->where(function ($query) {
                    $query
                        ->where('linkable_type', Company::class)
                        ->where('linkable_id', $this->company->id);
                }),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "companies"
      summary: "updates company"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyUpdate:
    type: "object"
    required:
    - "_method"
    properties:
      _method:
        type: "string"
        enum:
        - "put"
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
          # - "string"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      logo:
        type: "string"
        description: "Company logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Company background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "64 characters max."
        example: "Company Name"
      title:
        type: "string"
        description: "Optional. Title for company description."
        example: "company description title"
      description:
        type: "string"
        description: "Optional. max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "company description"
      phone:
        type: "string"
        description: "Optional. A valid phone number."
        example: "123 456 789"
      email:
        type: "string"
        description: "Optional. A valid email address."
        example: "Jon Doe"
      country_id:
        type: "number"
        description: "Must exist in countres table in database."
        example: "12"
      industry_id:
        type: "number"
        description: "Must exist in industry table in database."
        example: "155"
      website:
        type: "string"
        description: "Must be a valid URL."
        example: "www.sharesinside.com"
      adress:
        type: "string"
        description: "Address search powered by Google. Google maps are embedded underneath."
        example: "Some kind of adress"
      longitude:
        type: "string"
        description: "Longitude."
        example: "50"
      latitude:
        type: "string"
        description: "Latitude."
        example: "50"
      symbols:
        type: "array"
        items:
          \$ref: "#/definitions/Symbol"
        description: "if present symbols will be sync with passed array - if null, symbols would not change"
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
        description: "if present social media will be sync with passed array - if null, social media would not change"
      delete_background:
        type: "boolean"
      delete_attachments:
        type: "array"
        items:
          type: "integer"
      delete_links:
        type: "array"
        items:
          type: "integer"
      stock_exchange_emails:
        type: "array"
        items:
          type: "string"
        description: "array of stock exchange emails"
EOT;

        return ['CompanyUpdate' => $def];
    }
}
