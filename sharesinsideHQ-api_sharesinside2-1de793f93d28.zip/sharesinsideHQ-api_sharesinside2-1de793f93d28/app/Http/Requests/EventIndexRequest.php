<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\WatchlistableIndexRequestTrait;
use Illuminate\Foundation\Http\FormRequest;
use Carbon\Carbon;

class EventIndexRequest extends FormRequest
{
    use WatchlistableIndexRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'from' => [
                'nullable',
                'integer',
            ],
            'to' => [
                'nullable',
                'integer',
                function ($attribute, $value, $fail) {
                    $condition = !($value >= request()->get('from'));
                    if ($condition) {
                        return $fail('Date to must be greater than date from.');
                    }
                }
            ],
            'event_from' => [
                'nullable',
                'string',
                'bail',
                'regex:/^\d{4}-\d{2}-\d{2}$/',
                function ($attribute, $value, $fail) {
                    $condition = Carbon::createFromFormat('Y-m-d', $value)->toDateString() !== $value;
                    if ($condition) {
                        return $fail('event_from must have right format - "Y-m-d".');
                    }
                }
            ],
            'event_to' => [
                'nullable',
                'string',
                'bail',
                'regex:/^\d{4}-\d{2}-\d{2}$/',
                function ($attribute, $value, $fail) {
                    $condition = Carbon::createFromFormat('Y-m-d', $value)->toDateString() !== $value;
                    if ($condition) {
                        return $fail('event_to must have right format - "Y-m-d".');
                    }
                }
            ],
            'publicity' => 'array',
            'publicity.*' => [
                'string',
                'in:public,business,internal',
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "events"
      summary: "list of events"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for watchlist."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, searches in titles and description"
      - name: "from"
        in: "query"
        type: "integer"
        required: false
        description: "timestamp, searches watchlist items with publish date later than parameter"
      - name: "to"
        in: "query"
        type: "integer"
        required: false
        description: "timestamp, searches watchlist items with publish date earlier than parameter"
      - name: "attachments"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - 'documents'
          - 'files'
          - 'videos'
          - 'images'
          - 'links'
        required: false
        description: "'documents' is alias for 'files'."
      - name: "event_from"
        in: "query"
        type: "string"
        required: false
        description: "date in Y-m-d format, filters events with event date equal or later than parameter"
      - name: "event_to"
        in: "query"
        type: "string"
        required: false
        description: "date in Y-m-d format, filters events with event date equal or earlier than parameter"
      - name: "sort_by"
        in: "query"
        type: "string"
        required: false
        description: "possible values: most_viewed, default"
      - name: "location"
        in: "query"
        type: "string"
        required: false
        description: "filters events with maching location, existing locations can be find with /api/locations endpoint"
EOT;

    }
}
