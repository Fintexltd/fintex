<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class FundsManagerDemoIndexRequest extends FundsManagerIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();
        unset($rules['sort_by']);
        unset($rules['seed']);

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "funds managers"
      summary: "list of funds manager tiles"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for funds manager tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, funds managers with maching name are returned"
      - name: "relations"
        in: "query"
        type: "array"
        items:
          type: "string"
EOT;

    }
}
