<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FollowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "companies"
      - "funds managers"
      - "funds"
      summary: "Follow a company, funds manager or fund"
      consumes:
      - "multipart/form-data"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID, funds manager ID or fund ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      produces:
      - "application/json"
EOT;

    }
}
