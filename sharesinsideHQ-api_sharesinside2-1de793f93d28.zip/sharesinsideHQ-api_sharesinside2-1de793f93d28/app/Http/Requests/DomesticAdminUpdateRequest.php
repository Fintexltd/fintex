<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

//TODO: remove this file
class DomesticAdminUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $domestic = User::query()
            ->where('email', $this->get('email'))
            ->where('email_confirmed', true)
            ->first();

        return [
            'email' => [
                'required',
                'string',
                'min:1',
                Rule::exists('users', 'email')->where(function ($query) {
                    $query->where('email_confirmed', true);
                }),
            ],
            'country_ids' => 'array|present',
            'country_ids.*' => [
                'integer',
                'exists:countries,id',
                function ($attribute, $value, $fail) use ($domestic) {
                    $condition = (bool)Relation::query()
                        ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
                        ->where('user_id', '!=', data_get($domestic, 'id'))
                        ->where('related_id', $value)
                        ->count();

                    if ($condition) {
                        return $fail('This country already has a domestic admin.');
                    }

                }
            ]
        ];
    }

    public function messages()
    {
        return [
            'email.exists' => 'This user doesn\'t exist.',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "domestic"
      summary: "create/updated domestic admin"
      produces:
      - "application/json"
      parameters:
      - name: "email"
        in: "query"
        type: "string"
        required: true
      - name: "country_ids"
        in: "body"
        type: "array"
          items:
            type: "string"
        required: true
EOT;
    }

}
