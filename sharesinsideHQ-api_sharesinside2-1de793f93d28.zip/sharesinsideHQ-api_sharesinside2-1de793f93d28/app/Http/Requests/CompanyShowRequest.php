<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class CompanyShowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ($this->company->is_accepted) {
            return true;
        }

        $allowedRoles = [
            Relation::RELATION_TYPE_GLOBAL_ADMIN,
            Relation::RELATION_TYPE_CONTENT_ADMIN,
            Relation::RELATION_TYPE_DOMESTIC_ADMIN,
            Relation::RELATION_TYPE_PRIMARY_ADMIN,
            Relation::RELATION_TYPE_SECONDARY_ADMIN,
            Relation::RELATION_TYPE_EDITOR,
        ];
        $userRoles = RoleResolver::getRoles($this->user(), $this->company);

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      summary: "Company about"
      consumes:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      produces:
      - "application/json"
EOT;

    }
}
