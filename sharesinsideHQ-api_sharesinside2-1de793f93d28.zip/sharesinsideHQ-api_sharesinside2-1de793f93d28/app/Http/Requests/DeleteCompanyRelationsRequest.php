<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class DeleteCompanyRelationsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
//        $allowedRoles = [
//            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
//            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
//            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
//            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
//        ];
//
//        $userRoles = RoleResolver::getRoles($this->user(), $this->company);
//
//        return (bool)array_intersect($allowedRoles, $userRoles);

        $restrictedTypes = $this->getRestrictedTypes();

        $types = Relation::query()
            ->find($this->get('relations'))
            ->pluck('type')
            ->all();

        return !(bool)array_intersect($restrictedTypes, $types);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'relations' => [
                'required',
                'array',
            ],
            'relations.*' => [
                'required',
                'integer',
                Rule::exists('relations', 'id')->where(function ($query) {
                    $query
                        ->where('related_type', Company::class)
                        ->where('type', '!=', User::RELATION_TYPE_PRIMARY_ADMIN)
                        ->where('related_id', data_get($this, 'company.id'));

//                    $restrictedTypes = $this->getRestrictedTypes();
//
//                    if ($restrictedTypes) {
//                        $query->whereNotIn('type', $restrictedTypes);
//                    }
                }),
            ],
        ];
    }

    private function getRestrictedTypes()
    {
        $restrictedTypes = [];

        $userRoles = RoleResolver::getRoles($this->user(), $this->company);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        if (!(bool)array_intersect($allowedRoles, $userRoles)) {
            $restrictedTypes = [
                RelationInterface::RELATION_TYPE_SHAREHOLDER,
                RelationInterface::RELATION_TYPE_EDITOR,
                RelationInterface::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM,
                RelationInterface::RELATION_TYPE_VIP,
                RelationInterface::RELATION_TYPE_FOLLOWER,
            ];
        }

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
        ];

        if (!(bool)array_intersect($allowedRoles, $userRoles)) {
            $restrictedTypes[] = RelationInterface::RELATION_TYPE_SECONDARY_ADMIN;
        }

        return $restrictedTypes;
    }

    private function shouldRestrictPermissions()
    {
        $unrestricted = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $this->company);

        return !(bool)array_intersect($unrestricted, $userRoles);
    }
}
