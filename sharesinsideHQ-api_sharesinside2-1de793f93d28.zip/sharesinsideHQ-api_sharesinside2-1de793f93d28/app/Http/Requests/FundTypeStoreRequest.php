<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class FundTypeStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
                'min:1',
                'max:128',
                'unique:fund_types',
            ]
        ];
    }

    public function messages()
    {
        return [
            'name.max' => 'Name must be at most 128 characters',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "fund types"
      summary: "create fund type"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with fund type data"
        required: true
        schema:
          \$ref: "#/definitions/FundTypeStore"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  FundTypeStore:
    type: "object"
    required:
    - "name"
    properties:
      name:
        type: "string"
        description: "Required. 128 characters max."
EOT;

        return [
            'FundTypeStore' => $def,
        ];
    }
}
