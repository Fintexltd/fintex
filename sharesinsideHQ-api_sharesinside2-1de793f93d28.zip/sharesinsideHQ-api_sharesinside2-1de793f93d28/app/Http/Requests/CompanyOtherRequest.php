<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyOtherRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:

    get:
      tags:
      - "companies"
      summary: "list of company tiles"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, companies with maching name are returned"
      - name: "sector"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having sector maching id in request"
      - name: "industry"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having industry maching id in request"
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having continent maching id in request"
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having country maching id in request"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only companies that have maching relation with user"
EOT;

    }
}
