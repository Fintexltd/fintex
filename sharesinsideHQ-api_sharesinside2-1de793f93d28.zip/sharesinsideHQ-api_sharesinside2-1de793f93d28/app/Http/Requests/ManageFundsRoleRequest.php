<?php

namespace App\Http\Requests;

use App\Entities\RelationInterface;
use App\Services\FundsAdminManager;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class ManageFundsRoleRequest extends FormRequest
{
    protected $candidate;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $roles = RoleResolver::getRoles($this->user(), $this->fundsManager);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        return (bool)array_intersect($allowedRoles, $roles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->candidate = User::where('email', $this->get('user_email'))->first();

        return [
            'action' => [
                'required',
                'string',
                'in:' . implode(',', FundsAdminManager::AVALIABLE_ACTIONS),
            ],
            'user_email' => [
                'required',
                'string',
                function ($attribute, $value, $fail) {
                    if (empty($this->candidate)) {
                        return $fail("This user doesn't exist.");
                    }

                    if (!$this->candidate->email_confirmed) {
                        $message = 'You can’t add ';

                        switch ($this->get('action')) {
                            case FundsAdminManager::SET_EDITOR_ACTION:
                                $message .= 'Editor, t';
                                break;
                            case FundsAdminManager::ADD_VIP_ACTION:
                                $message .= 'VIP, t';
                                break;
                            default:
                                $message = 'T';
                                break;
                        }

                        return $fail($message . 'his account was not confirmed.');
                    }
                },
            ],
            'fund_ids' => [
                'array',
                'nullable'
            ],
            'fund_ids.*' => [
                'required',
                'integer',
                'exists:funds,id',
                function ($attribute, $value, $fail) {
                    $fundIds = $this->fundsManager->funds->pluck('id')->toArray();
                    if (!in_array($value, $fundIds)) {
                        return $fail($attribute.' has not been assigned to this funds manager.');
                    }
                },
            ],
            'assign_to_funds_manager' => [
                'nullable',
                'boolean'
            ],
        ];
    }

    public function getCandidate()
    {
        return $this->candidate;
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds managers"
      summary: "Manage funds editors for a specific funds manager."
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Funds manager ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/ManageFundsEditorsRoleRequest"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  ManageFundsEditorsRoleRequest:
    type: "object"
    required:
    - "fund_ids"
    - "user_email"
    properties:
      fund_ids:
        type: "array"
        items:
          type: "integer"
        description: "array of fund IDs"
      user_email:
        type: "string"
EOT;

        return ['ManageFundsEditorsRoleRequest' => $def];
    }
}
