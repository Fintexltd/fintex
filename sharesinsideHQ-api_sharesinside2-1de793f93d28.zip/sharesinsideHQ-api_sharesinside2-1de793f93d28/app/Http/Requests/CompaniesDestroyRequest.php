<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class CompaniesDestroyRequest extends CompanyAdminIndexRequest
{

    public function authorize()
    {
        $user = $this->user();

        if (RoleResolver::isGlobalAdmin($user) || RoleResolver::isContentAdmin($user)) {
            return true;
        }

        $conditions = Company::query()
            ->find($this->company_ids)
            ->map(function ($company) use ($user) {
                return RoleResolver::isDomesticInCompany($user, $company);
            })
            ->all();

        return !in_array(false, $conditions);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();

        $rules = [
            'company_ids' => [
                'required',
                'array',
            ],
            'company_ids.*' => [
                'required',
                'integer',
                Rule::exists('companies', 'id'),
            ],
        ];

        return array_merge($parentRules, $rules);
    }

    public function messages()
    {
        $parentMessages = parent::messages();
        $messages = [
            'company_ids.*.exists' => 'There is no company with such id.',
        ];

        return array_merge($parentMessages, $messages);
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "companies"
      summary: "deletes selected companies"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/AdminCompanyActionArray"
EOT;
    }
}
