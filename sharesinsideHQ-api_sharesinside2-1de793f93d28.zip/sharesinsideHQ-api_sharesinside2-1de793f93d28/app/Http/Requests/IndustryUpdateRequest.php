<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class IndustryUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => [
                'required_without:economic_sector_id',
                'string',
                'min:1',
                'max:32',
                Rule::unique('industries')->ignore($this->industry->id),
            ],
            'economic_sector_id' => [
                'required_without:name',
                'integer',
                'exists:industries',
            ],
        ];
    }

    public function messages()
    {
        return [
            'name.max' => 'Name must be at most 32 characters',
        ];
    }
}
