<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\EntitiableInterface;
use App\Entities\RelationInterface;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Entities\Startup;
use App\Repositories\AttachmentRepository;
use App\Services\DescriptionSanitizer;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class GalleryItemStoreRequest extends FormRequest
{

    const MAX_DESCRIPTION_LENGTH = 512;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $userRoles = RoleResolver::getRoles($this->user(), $this->entity);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        if (get_class($this->entity)==Company::class) {
            $allowedRoles[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
        }

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    protected function prepareForValidation()
    {
        if ($this->get('section_id')) {
            $this->validate([
                'section_id' => [
                    'required_without:entitiable_type,entitiable_id',
                    'integer',
                    function ($attribute, $value, $fail) {
                        $section = Section::where('id', $value)->where('type', SectionInterface::COMPANY_GALLERY_ALBUM_SECTION)->first();

                        if ($section) {
                            $this->entity = $section->referenced;
                        } else {
                            return $fail('The selected section id is invalid.');
                        }
                    }
                ]
            ]);
        } else {
            $this->validate([
                'entitiable_type' => [
                    'required_without:section_id',
                    'in:' . implode(',', EntitiableInterface::ENTITIABLE_TYPE),
                ],
                'entitiable_id' => [
                    'required_without:section_id',
                    'integer',
                    function ($attribute, $value, $fail) {
                        switch ($this->input('entitiable_type')) {
                            case EntitiableInterface::ENTITIABLE_TYPE_COMPANY:
                                $this->entity = Company::find($value);
                                break;
                            case EntitiableInterface::ENTITIABLE_TYPE_STARTUP:
                                $this->entity = Startup::find($value);
                                break;
                        }

                        if (!$this->entity ) {
                            return $fail('There is no such entitiable_type with this entitiable_id.');
                        }
                    },
                ],
            ]);

            $input = $this->all();
            $input['entitiable_type'] = EntitiableInterface::ENTITIABLE_TYPE_CLASS[$input['entitiable_type']];
            $this->merge($input);
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $descriptionSanitizer = new DescriptionSanitizer();

        $rules = [
            'entitiable_type' => [], //validated by prepareForValidation()
            'entitiable_id' => [], //validated by prepareForValidation()
            'section_id' => [], //validated by prepareForValidation()
            /*'company_id' => [
                'required_without:section_id',
                'integer',
                'exists:companies,id'
            ],*/
            /*'section_id' => [
                'required_without:company_id',
                'integer',
                Rule::exists('sections', 'id')
                    ->where('type', SectionInterface::COMPANY_GALLERY_ALBUM_SECTION),
            ],*/
            'file' => [
                'required',
                Rule::exists('security_tokens', 'token')->whereIn('value', AttachmentRepository::GALLERY_ITEM_TYPES),
            ],
            'description' => [
                'nullable',
                'string',
                function ($attribute, $value, $fail) use ($descriptionSanitizer) {
                    $condition = $descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                    if (!strlen(trim(strip_tags($value)))) {
                        return $fail('Description is required.');
                    }
                },
            ],
        ];

        return $rules;
    }

    public static function doc()
    {
        return <<<EOF
    post:
      tags:
      - "company gallery"
      summary: "Creates new company gallery item"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/CompanyGalleryItemStore"
EOF;

    }

    public static function definitions()
    {
        $def = <<<EOT
  CompanyGalleryItemStore:
    type: "object"
    required:
    - "file"
    properties:
      company_id:
        type: "integer"
        description: "If present item would be append to default company gallery. Required if section_id is not present."
      section_id:
        type: "integer"
        description: "Ignored if company_id is present, otherwise required. Section to which item should be append."
      description:
        type: "string"
      file:
        type: "string"
        description: "token from uploaded file"
EOT;

        return ['CompanyGalleryItemStore' => $def];
    }
}
