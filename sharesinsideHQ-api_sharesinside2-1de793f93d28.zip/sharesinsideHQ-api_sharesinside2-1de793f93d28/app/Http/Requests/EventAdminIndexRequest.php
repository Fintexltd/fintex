<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\WatchlistableAdminIndexRequestTrait;
use Illuminate\Foundation\Http\FormRequest;

class EventAdminIndexRequest extends FormRequest
{
    use WatchlistableAdminIndexRequestTrait;

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "events"
      summary: "list of events in admin panel"
      produces:
      - "application/json"
      parameters:
      - name: "id"
        in: "path"
        type: "integer"
        required: true
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for watchlist."
EOT;

    }
}
