<?php

namespace App\Http\Requests;

use App\Entities\CountryCallingCode;
use App\Repositories\AttachmentRepository;
use App\Repositories\SocialMediaRepository;
use App\Services\RoleResolver;
use App\Services\DescriptionSanitizer;
use App\Services\Validation\Url;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class FundsManagerStoreRequest extends FormRequest
{
    const MAX_DESCRIPTION_LENGTH = 20000;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        $rules = [
            'name' => [
                'required',
                'string',
                'max:64'
            ],
            'title' => [
                'nullable',
                'string',
                'max:500',
            ],
            'description' => [
                'required',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                    if (!strlen(trim(strip_tags($value)))) {
                        return $fail('Description is required.');
                    }
                },
            ],
            'phone' => [
                'phone'
            ],
            'email' => 'nullable|email',
            'country_calling_code_id' => [
                'required',
                'exists:country_calling_codes,id',
            ],
            'website' => [
                'nullable',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
                'max:191',
            ],
            'address' => [
                'required',
                'string',
                'max:191',
            ],
            'longitude' => [
                'required',
                'numeric',
                'min:-180',
                'max:180',
            ],
            'latitude' => [
                'required',
                'numeric',
                'min:-90',
                'max:90',
            ],
            'logo' => [
                'required',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FUNDS_MANAGER_LOGO);
                })
            ],
            'background' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FUNDS_MANAGER_BACKGROUND);
                })
            ],
            'social_media' => [
                'nullable',
                'array',
            ],
            'social_media.*.type' => [
                'required',
                'distinct',
                'in:' . implode(',', SocialMediaRepository::MEDIA_TYPES),
            ],
            'social_media.*.url' => [
                'nullable',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'social_media.*' => [
                function ($attribute, $value, $fail) {
                    $pattern = '/' . array_get($value, 'type') . '\.com/';
                    $string = array_get($value, 'url');
                    $condition = preg_match($pattern, $string) || empty($string);

                    if (!$condition) {
                        return $fail('Social media link should mach social media type.');
                    }
                },
            ],
            'attachments' => 'array',
            'attachments.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FILE);
                })
            ],
            'links' => 'array',
            'links.*.name' => 'required|max:64',
            'links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'excluded' => [
                'nullable',
                'array',
            ],
            'excluded.*' => [
                'integer',
                Rule::exists('countries', 'id'),
                'not_in:' . $this->user()->country_id,
            ],
            'videos' => 'array|forbidden_with:video_links',
            'videos.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_VIDEO);
                }),
            ],
            'video_links' => 'array|forbidden_with:videos',
            'video_links.*.name' => 'required|max:64',
            'video_links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
                'regex:/youtu\.?be|vimeo/',
            ],
            'terms_and_conditions' => [
                'array',
                'required_without:terms_and_conditions_links',
                'forbidden_with:terms_and_conditions_links'
            ],
            'terms_and_conditions.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_TERMS_AND_CONDITIONS);
                })
            ],
            'terms_and_conditions_links' => [
                'array',
                'required_without:terms_and_conditions',
                'forbidden_with:terms_and_conditions'
            ],
            'terms_and_conditions_links.*.name' => [
                'required',
                'max:64'
            ],
            'terms_and_conditions_links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
        ];

        return $rules;
    }

    public function messages()
    {
        return [
            'excluded.*.not_in' => 'You cannot exclude funds manager from your country.',
            'excluded.*.exists' => 'There is no country with selected id.',
            'social_media.*.type.in' => 'Media type should be one of following: "' . implode('", "', SocialMediaRepository::MEDIA_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds managers"
      summary: "Creates new funds manager"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/FundsManagerStore"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  FundsManagerStore:
    type: "object"
    required:
    - "logo"
    - "name"
    - "description"
    - "country_calling_code_id"
    - "address"
    - "longitude"
    - "latitude"
    properties:
      logo:
        type: "string"
        description: "Required. Funds manager logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Funds manager background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "Required. 64 characters max."
        example: "Funds manager Name"
      title:
        type: "string"
        description: "Optional. Title for funds manager description. 500 characters max."
        example: "funds manager description title"
      description:
        type: "string"
        description: "Required. max 20000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "funds manager description"
      phone:
        type: "string"
        description: "Optional. A valid phone number."
        example: "123 456 789"
      email:
        type: "string"
        description: "Optional. A valid email address."
        example: "Jon Doe"
      country_calling_code_id:
        type: "number"
        description: "Required. Must exist in country_calling_codes table in database."
        example: "12"
      website:
        type: "string"
        description: "Required. Must be a valid URL. Max 191 chars."
        example: "www.sharesinside.com"
      address:
        type: "string"
        description: "Required. Address search powered by Google. Google maps are embedded underneath."
        example: "Some kind of address"
      longitude:
        type: "string"
        description: "Required. Longitude."
        example: "50"
      latitude:
        type: "string"
        description: "Required. Latitude."
        example: "50"
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
      excluded:
        type: "array"
        items:
          type: "integer"
        description: "array of countries for excluding news"
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      videos:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      video_links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      terms_and_conditions:
        type: "array"
        description: "Required if terms_and_conditions_links empty. Sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      terms_and_conditions_links:
        type: "array"
        description: "Required if terms_and_conditions empty."
        items:
          \$ref: "#/definitions/Link"
EOT;

        return [
            'FundsManagerStore' => $def,
        ];
    }
}
