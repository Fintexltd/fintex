<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\CountryCallingCode;
use App\Entities\RelationInterface;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Repositories\AttachmentRepository;
use App\Services\RoleResolver;
use App\Services\DescriptionSanitizer;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class EmployeeStoreRequest extends FormRequest
{
    const MAX_DESCRIPTION_LENGTH = 1000;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if(
            !($section = Section::where('id', $this->input('section_id'))->where('type', SectionInterface::EMPLOYEE_SECTION)->first()) ||
            !($entity = $section->referenced)
        ) {
            return false;
        }

        $roles = RoleResolver::getRoles($this->user(), $entity);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        if (get_class($entity)==Company::class) {
            $allowedRoles[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
        }

        return (bool)array_intersect($roles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        return [
            'section_id' => [
                'required',
                'exists:sections,id',
            ],
            'name' => [
                'required',
                'string',
                'max:64',
            ],
            'photo' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_IMAGE);
                }),
            ],
            'position' => 'nullable|string|max:64',
            'description' => [
                'nullable',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                },
            ],
            'email' => 'nullable|email|max:64',
            'phone_number' => [
                'phone'
            ],
            'attachment' => [
                'nullable',
                'string',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FILE);
                }),
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "employees"
      summary: "Creates new company"
      consumes:
      - "multipart/form-data"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/EmployeeStore"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  EmployeeStore:
    type: "object"
    required:
    - 'section_id'
    - 'name'
    properties:
      section_id:
        type: "string"
        description: "Required. Must exist in database."
      name:
        type: "string"
        description: "Team member name. Required, 64 characters max."
      photo:
        type: "string"
        description: "uploaded file token"
      position:
        type: "string"
        description: "Team member position. Optional. 64 characters max."
      description:
        type: "string"
        description: "Team member short description. Optional. 512 characters max."
      email:
        type: "string"
        description: "Team member email address. Optional. 64 characters max, must be a valid email address."
      phone_number:
        type: "string"
        description: "Team member phone number. Optional. 12 digits max, only digits."
      attachment:
        \$ref: "#/definitions/AttachmentToken"
EOT;

        return ['EmployeeStore' => $def];
    }
}
