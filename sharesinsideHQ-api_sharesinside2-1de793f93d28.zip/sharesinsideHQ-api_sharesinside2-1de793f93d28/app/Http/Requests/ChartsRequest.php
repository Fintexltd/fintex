<?php

namespace App\Http\Requests;

class ChartsRequest extends CompanyShowRequest
{
    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      summary: "Company charts"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Company ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
