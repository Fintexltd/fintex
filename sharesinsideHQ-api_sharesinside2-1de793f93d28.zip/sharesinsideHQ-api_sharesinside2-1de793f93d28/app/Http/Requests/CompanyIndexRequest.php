<?php

namespace App\Http\Requests;

use App\Criteria\CompanySortByCriteria;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class CompanyIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'search' => [
                'nullable',
                'string',
            ],
            'sort_by' => [
                'nullable',
                'in:' . implode(',', CompanySortByCriteria::AVALIABLE_SORT_TYPES),
            ],
            'sector' => 'array',
            'sector.*' => [
                'integer',
                'exists:economic_sectors,id',
            ],
            'industry' => 'array',
            'industry.*' => [
                'integer',
                'exists:industries,id',
            ],
            'continent' => 'array',
            'continent.*' => [
                'integer',
                'exists:continents,id',
            ],
            'country' => 'array',
            'country.*' => [
                'integer',
                'exists:countries,id',
            ],
            'relations' => [
                'array',
                'in:' . implode(',', User::USER_COMPANY_RELATION_TYPES),
            ],
            'seed' => [
                'required_without:sort_by',
                'integer',
                'required_if:sort_by,' . CompanySortByCriteria::SORT_DEFAULT],
            'page' => [
                'integer',
            ],
        ];
    }

    public function messages()
    {
        return [
            'sort_by.in' => 'Must be one of values: "' . implode('", "', CompanySortByCriteria::AVALIABLE_SORT_TYPES) . '".',
            'relation.in' => 'Must be one of values: "' . implode('", "', User::USER_COMPANY_RELATION_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      summary: "list of company tiles"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for company tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, companies with maching name are returned"
      - name: "sector"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having sector maching id in request"
      - name: "industry"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having industry maching id in request"
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having continent maching id in request"
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having country maching id in request"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only companies that have maching relation with user"
      - name: "sort_by"
        in: "query"
        type: "string"
        required: false
        description: "sort order for companies"
        enum:
        - "default"
        - "most_viewed"
      - name: "seed"
        in: "query"
        type: "integer"
        required: false
        description: "seed for default sort order. Reqquired id 'sort_by' filed is not present or has default value."
EOT;

    }
}
