<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;

class CompanyAdminIndexRequest extends CompanyIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();
        unset($rules['sort_by']);
        unset($rules['seed']);
        unset($rules['relation']);

        return $rules;
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "companies"
      summary: "list of company tiles"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for company tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, companies with maching name are returned"
      - name: "sector"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having sector maching id in request"
      - name: "industry"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having industry maching id in request"
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having continent maching id in request"
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
        description: "result contains only companies having country maching id in request"
EOT;

    }
}
