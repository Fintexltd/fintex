<?php

namespace App\Http\Requests;

use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Repositories\AttachmentRepository;
use App\Repositories\SeSymbolRepository;
use App\Repositories\SocialMediaRepository;
use App\Services\RoleResolver;
use App\Services\DescriptionSanitizer;
use App\Services\Validation\Url;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class FundStoreRequest extends FormRequest
{
    const MAX_DESCRIPTION_LENGTH = 8000;

    protected $descriptionSanitizer;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if($fundsManager = FundsManager::find($this->get('funds_manager_id')))
        {
            $allowedRoles = [
                RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
                RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            ];

            $userRoles = RoleResolver::getRoles($this->user(), $fundsManager);
        }

        return (bool)$fundsManager && (bool)array_intersect($allowedRoles, $userRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $this->descriptionSanitizer = new DescriptionSanitizer();

        $rules = [
            'funds_manager_id' => [
                'required',
                'integer',
                Rule::exists('funds_managers', 'id')->whereNull('deleted_at'),
            ],
            'country_id' => [
                'required',
                'integer',
                Rule::exists('countries', 'id'),
            ],
            'currency_id' => [
                'required',
                'integer',
                Rule::exists('currencies', 'id'),
            ],
            'name' => [
                'required',
                'string',
                'max:64'
            ],
            'title' => [
                'nullable',
                'string',
                'max:128',
            ],
            'description' => [
                'required',
                function ($attribute, $value, $fail) {
                    $condition = $this->descriptionSanitizer->strlen($value) > self::MAX_DESCRIPTION_LENGTH;
                    if ($condition) {
                        return $fail('Description max length is ' . self::MAX_DESCRIPTION_LENGTH . '.');
                    }
                    if (!strlen(trim(strip_tags($value)))) {
                        return $fail('Description is required.');
                    }
                },
            ],
            'management_fee' => [
                'required',
                'numeric',
                'between:0,99999999.99'
            ],
            'performance_fee' => [
                'required',
                'numeric',
                'between:0,99999999.99'
            ],
            'duration' => [
                'required',
                'integer',
                'between:1,4294967295'
            ],
            'is_active' => [
                Rule::requiredIf(function () {
                    return $this->is_active!==true && $this->is_passive!==true;
                }),
                'boolean',
                'true_if_reference_not_true:is_passive',
                'forbidden_with:is_passive'
            ],
            'is_passive' => [
                Rule::requiredIf(function () {
                    return $this->is_active!==true && $this->is_passive!==true;
                }),
                'boolean',
                'true_if_reference_not_true:is_active',
                'forbidden_with:is_active'
            ],
            'trading_frequency' => [
                'nullable',
                'in:daily,weekly,monthly,yearly,quarterly,halfyearly'
            ],
            'kind_of_fund' => [
                'required',
                'in:non-regulated,professional-investment,retail,listed,ucts,etf-s'
            ],
            'open_closed' => [
                'required',
                'in:open,closed'
            ],
            'logo' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FUND_LOGO);
                })
            ],
            'background' => [
                'nullable',
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FUND_BACKGROUND);
                })
            ],
            'se_symbols' => [
                'nullable',
                'array',
                function ($attribute, $value, $fail) {
                    if (count($value)) {
                        $condition = collect($value)
                                ->pluck('default')
                                ->filter()
                                ->count() !== 1;
                        if ($condition) {
                            return $fail('One of symbol is required to be default.');
                        }
                    }
                },
            ],
            'se_symbols.*.symbol' => [
                'required',
                'distinct',
            ],
            'se_symbols.*.default' => [
                'required',
                'sometimes',
                'boolean',
            ],
            'se_symbols.*.provider' => [
                'required',
                'in:' . implode(',', SeSymbolRepository::SE_SYMBOL_PROVIDERS),
            ],
            'social_media' => [
                'nullable',
                'array',
            ],
            'social_media.*.type' => [
                'required',
                'distinct',
                'in:' . implode(',', SocialMediaRepository::MEDIA_TYPES),
            ],
            'social_media.*.url' => [
                'nullable',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'social_media.*' => [
                function ($attribute, $value, $fail) {
                    $pattern = '/' . array_get($value, 'type') . '\.com/';
                    $string = array_get($value, 'url');
                    $condition = preg_match($pattern, $string) || empty($string);

                    if (!$condition) {
                        return $fail('Social media link should mach social media type.');
                    }
                },
            ],
            'attachments' => 'array',
            'attachments.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_FILE);
                })
            ],
            'links' => 'array',
            'links.*.name' => 'required|max:64',
            'links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
            ],
            'excluded' => [
                'nullable',
                'array',
            ],
            'excluded.*' => [
                'integer',
                Rule::exists('countries', 'id'),
                'not_in:' . $this->user()->country_id,
            ],
            'fund_types' => [
                'required',
                'array',
            ],
            'fund_types.*' => [
                'required',
                'integer',
                Rule::exists('fund_types', 'id')
            ],
            'videos' => 'array|forbidden_with:video_links',
            'videos.*' => [
                Rule::exists('security_tokens', 'token')->where(function ($query) {
                    $query->where('value', AttachmentRepository::TYPE_VIDEO);
                }),
            ],
            'video_links' => 'array|forbidden_with:videos',
            'video_links.*.name' => 'required|max:64',
            'video_links.*.url' => [
                'required',
                'max:128',
//                'url',
                Url::getValidationFunction(),
                'regex:/\.\w{2}/',
                'regex:/youtu\.?be|vimeo/',
            ],
        ];

        return $rules;
    }

    protected function prepareForValidation()
    {
        $input = $this->all();
        $input['trading_frequency'] = isset($input['trading_frequency']) && !empty($input['trading_frequency']) ? $input['trading_frequency'] : null;
        $this->merge($input);
    }

    public function messages()
    {
        return [
            'excluded.*.not_in' => 'You cannot exclude fund from your country.',
            'excluded.*.exists' => 'There is no country with selected id.',
            'social_media.*.type.in' => 'Media type should be one of following: "' . implode('", "', SocialMediaRepository::MEDIA_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "funds"
      summary: "Creates new fund"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/FundStore"
EOT;
    }

    public static function definitions()
    {
        $def = <<<EOT
  FundStore:
    type: "object"
    required:
    - "funds_manager_id"
    - "country_id"
    - "currency_id"
    - "name"
    - "description"
    - "management_fee"
    - "performance_fee"
    - "duration"
    - "fund_types"
    properties:
      logo:
        type: "string"
        description: "Optional. Fund logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Fund background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "Required. 64 characters max."
        example: "Fund Name"
      title:
        type: "string"
        description: "Optional. Title for fund description. 128 characters max."
        example: "fund description title"
      description:
        type: "string"
        description: "Required. max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "fund description"
      funds_manager_id:
        type: "number"
        description: "Required. Must exist in funds_managers table in database."
        example: "2"
      country_id:
        type: "number"
        description: "Required. Must exist in countries table in database."
        example: "12"
      currency_id:
        type: "number"
        description: "Required. Must exist in currencies table in database."
        example: "1"
      management_fee:
        type: "number"
        description: "Required. Management fee. Number between: 0 - 99999999.99."
        example: "1.99"
      performance_fee:
        type: "number"
        description: "Required. Performance fee. Number between: 0 - 99999999.99."
        example: "2.99"
      duration:
        type: "number"
        description: "Required. Duration."
        example: "2"
      is_active:
        type: "boolean"
        description: "Required true if is_passive is false or not set."
      is_passive:
        type: "boolean"
        description: "Required true if is_active is false or not set."
      trading_frequency:
        type: "string"
        enum:
        - "daily"
        - "weekly"
        - "monthly"
        - "yearly"
      kind_of_fund:
        type: "string"
        description: "Required"
        enum:
        - "non-regulated"
        - "professional-investment"
        - "retail"
        - "listed"
        - "ucts"
        - "etf-s"
      open_closed:
        type: "string"
        description: "Required"
        enum:
        - "open"
        - "closed"
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
      excluded:
        type: "array"
        items:
          type: "integer"
        description: "array of countries for excluding news"
      fund_types:
        type: "array"
        items:
          type: "integer"
        description: "array of fund types"
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      videos:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      video_links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
EOT;

        return [
            'FundStore' => $def,
        ];
    }
}
