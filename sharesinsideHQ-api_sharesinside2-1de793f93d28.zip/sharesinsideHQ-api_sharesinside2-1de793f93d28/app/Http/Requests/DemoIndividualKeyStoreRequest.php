<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\EntitiableInterface;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\Startup;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class DemoIndividualKeyStoreRequest extends FormRequest
{
    public $entity;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $entitiableTypes = EntitiableInterface::ENTITIABLE_TYPE;
        unset($entitiableTypes[Fund::class]);

        return [
            'entitiable_type' => [
                'required',
                'in:' . implode(',', $entitiableTypes),
            ],
            'entitiable_id' => [
                'required',
                'integer',
                function ($attribute, $value, $fail) {
                    switch ($this->input('entitiable_type')) {
                        case EntitiableInterface::ENTITIABLE_TYPE_COMPANY:
                            $this->entity = Company::find($value);
                            break;
                        case EntitiableInterface::ENTITIABLE_TYPE_STARTUP:
                            $this->entity = Startup::find($value);
                            break;
                        case EntitiableInterface::ENTITIABLE_TYPE_FUNDS_MANAGER:
                            $this->entity = FundsManager::find($value);
                            break;
                    }

                    if (!$this->entity ) {
                        return $fail('There is no such entitiable_type with this entitiable_id.');
                    }
                },
            ],
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $input = $this->all();
            $input['entitiable_type'] = EntitiableInterface::ENTITIABLE_TYPE_CLASS[$input['entitiable_type']];
            $this->merge($input);
        });
    }
}
