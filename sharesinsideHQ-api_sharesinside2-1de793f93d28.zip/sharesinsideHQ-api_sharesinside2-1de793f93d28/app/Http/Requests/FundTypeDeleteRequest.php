<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class FundTypeDeleteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if ($this->fund_type->funds->count()) {
                $validator
                    ->errors()
                    ->add('fund_type_id', 'Cannot remove fund type assigned to existing fund!');
            }
        });
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "fund types"
      summary: "deletes fund type"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Fund type ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
