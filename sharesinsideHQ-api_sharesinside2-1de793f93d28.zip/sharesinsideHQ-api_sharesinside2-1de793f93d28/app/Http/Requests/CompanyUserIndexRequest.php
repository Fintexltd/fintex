<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Services\RoleResolver;
use App\User;

class CompanyUserIndexRequest extends UserIndexRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $isGlobal = RoleResolver::isGlobalAdmin($this->user());
        $isContent = RoleResolver::isContentAdmin($this->user());
        $isPrimary = RoleResolver::isPrimaryInAny(Company::class, $this->user());
        $isSecondary = RoleResolver::isSecondaryInAny(Company::class, $this->user());

        return $isGlobal || $isContent || $isPrimary || $isSecondary;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = parent::rules();

        if(!RoleResolver::isGlobalAdmin($this->user()) && !RoleResolver::isContentAdmin($this->user())){
            $rules['company.*'] = 'in:' . implode(',', $this->user()->managedCompanies->pluck('id')->all());
        }

        return $rules;
    }

    public function messages()
    {
        return [
            'login_method.*.in' => 'Login method must be one of following: "' . implode('", "', User::AVALIABLE_LOGIN_METHODS) . '".',
            'relation.*.in' => 'Relation must be one of following: "' . implode('", "', User::ADMIN_MANAGEMENT_LIST_RELATION_TYPES) . '".',
        ];
    }
}
