<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class LsePreviewRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return (RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user())) && $this->lseAsset && !$this->lseAsset->is_accepted;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "london-stock-exchange"
      summary: "preview london stock exchange asset"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Asset ID"
EOT;

    }
}
