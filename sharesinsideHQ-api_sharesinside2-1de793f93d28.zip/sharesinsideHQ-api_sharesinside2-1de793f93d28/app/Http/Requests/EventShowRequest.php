<?php

namespace App\Http\Requests;

use App\Entities\Fund;
use Illuminate\Foundation\Http\FormRequest;

class EventShowRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return $this->user()->can('view', $this->event);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if (!data_get($this, 'event.watchlistItem.entitiable') || (get_class(data_get($this, 'event.watchlistItem.entitiable'))==Fund::class && !data_get($this, 'event.watchlistItem.entitiable.fundsManager'))) {
            abort(404, 'The event you\'re looking for was removed');
        }

        return [
            //
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "events"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Event ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
EOT;

    }
}
