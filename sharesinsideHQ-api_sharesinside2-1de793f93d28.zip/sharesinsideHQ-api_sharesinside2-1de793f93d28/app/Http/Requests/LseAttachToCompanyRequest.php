<?php

namespace App\Http\Requests;

use App\Entities\EntitiableInterface;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class LseAttachToCompanyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return (RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user())) && $this->lseAsset && !$this->lseAsset->is_accepted;
    }

    protected function prepareForValidation()
    {
        $this->merge([
            'entitiable_type' => EntitiableInterface::ENTITIABLE_TYPE_COMPANY
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'entitiable_id' => [
                'required',
                'integer',
                'exists:companies,id',
            ],
            'entitiable_type' => [
                'required',
                'in:'.EntitiableInterface::ENTITIABLE_TYPE_COMPANY
            ]
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "london-stock-exchange"
      summary: "attach asset to company"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Asset ID"
      - in: "body"
        name: "body"
        description: "json object with asset data"
        required: true
        schema:
          \$ref: "#/definitions/LseAttachToCompany"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  LseAttachToCompany:
    type: "object"
    required:
    - "entitiable_id"
    properties:
      entitiable_id:
        type: "integer"
        description: "Required. Must exist in companies table in database."
        example: "155"
EOT;

        return [
            'LseAttachToCompany' => $def,
        ];
    }
}
