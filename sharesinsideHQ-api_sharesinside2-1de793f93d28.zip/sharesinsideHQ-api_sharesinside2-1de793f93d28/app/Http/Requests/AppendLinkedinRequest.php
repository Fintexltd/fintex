<?php

namespace App\Http\Requests;

use App\Entities\SecurityToken;
use App\Services\RoleResolver;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class AppendLinkedinRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !RoleResolver::isDemoUser($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $now = Carbon::now();

        return [
            'linkedin_token' => [
                'required_without:register_token',
                'string',
            ],
            'register_token' => [
                'required_without:linkedin_token',
                'string',
                Rule::exists('security_tokens', 'token')
        ->where(function ($query) use ($now) {
                    $query
                        ->where('valid_until', '>=', $now)
                        ->where('type', SecurityToken::LINKEDIN_REGISTER);
                })
            ],
        ];
    }
}
