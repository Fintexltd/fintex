<?php

namespace App\Http\Requests;

use App\Entities\Relation;
use App\Services\RoleResolver;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class AdminDeleteUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'users' => 'array|required',
            'users.*' => [
                'required',
                'integer',
                'distinct',
                'exists:users,id',
                function ($attribute, $value, $fail) {
                    $condition = (bool)Relation::query()
                        ->where('user_id', $value)
                        ->where('type', User::RELATION_TYPE_PRIMARY_ADMIN)
                        ->count();

                    if ($condition) {
                        return $fail('Cannot delete user with primary admin role.');
                    }
                },
            ],
        ];
    }
}
