<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Entities\Section;
use App\Entities\SectionInterface;
use App\Entities\Startup;
use App\Repositories\AttachmentRepository;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DocumentStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if(
            !($section = Section::where('id', $this->input('section_id'))->where('type', SectionInterface::DOCUMENT_SECTION)->first()) ||
            !($entity = $section->referenced)
        ) {
            return false;
        }

        $roles = RoleResolver::getRoles($this->user(), $entity);

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        switch (get_class($entity)) {
            case Company::class:
                $allowedRoles[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
                break;
            case Fund::class:
                $allowedRoles[] = RelationInterface::RELATION_TYPE_EDITOR;
                break;
        }

        return (bool)array_intersect($roles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'section_id' => [
                'required',
            ],
            'title' => [
                'required',
                'string',
                'max:64',
            ],
            'file' => [
                'required',
                'string',
                Rule::exists('security_tokens', 'token')->where('value', AttachmentRepository::TYPE_FILE),
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    - name: "Accept"
      in: "header"
      type: "string"
      enum:
      - "application/json"
    post:
      tags:
      - "document"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/DocumentStore"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  DocumentStore:
    type: "object"
    required:
    - "entitiable_id"
    - "entitiable_type"
    - "title"
    - "file"
    properties:
      entitiable_id:
        type: "integer"
      entitiable_type:
        type: "string"
      title:
        type: "string"
      file:
        \$ref: "#/definitions/AttachmentToken"
EOT;

        return ['DocumentStore' => $def];
    }
}
