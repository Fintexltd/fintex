<?php

namespace App\Http\Requests;

use App\Entities\Fund;
use App\Entities\RelationInterface;
use App\Entities\Attachment;
use App\Entities\Link;
use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\Services\RoleResolver;
use Illuminate\Validation\Rule;

class FundUpdateRequest extends FundStoreRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if($this->fund && $this->fund->fundsManager)
        {
            $allowedRoles = [
                RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
                RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            ];

            $userRoles = RoleResolver::getRoles($this->user(), $this->fund->fundsManager);
        }

        return (bool)($this->fund && $this->fund->fundsManager) && (bool)array_intersect($allowedRoles, $userRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $parentRules = parent::rules();
        $parentRules['funds_manager_id'][0] = 'nullable';
        $parentRules['country_id'][0] = 'nullable';
        $parentRules['currency_id'][0] = 'nullable';
        $parentRules['name'][0] = 'nullable';
        $parentRules['description'][0] = 'nullable';
        $parentRules['management_fee'][0] = 'nullable';
        $parentRules['performance_fee'][0] = 'nullable';
        $parentRules['duration'][0] = 'nullable';
        $parentRules['fund_types'][0] = 'nullable';
        $parentRules['kind_of_fund'][0] = 'nullable';
        $parentRules['open_closed'][0] = 'nullable';
        $parentRules['is_active'] = [
            'nullable',
            'boolean',
            function ($attribute, $value, $fail) {
                if($value==$this->is_passive) {
                    return $fail($attribute.' must be '.json_encode(!$value).' when is_passive is '.json_encode($value));
                }
            },
            'forbidden_with:is_passive'
        ];
        $parentRules['is_passive'] = [
            'nullable',
            'boolean',
            function ($attribute, $value, $fail) {
                if($value==$this->is_active) {
                    return $fail($attribute.' must be '.json_encode(!$value).' when is_active is '.json_encode($value));
                }
            },
            'forbidden_with:is_active'
        ];

        $rules = [
            'delete_logo' => [
                'boolean',
            ],
            'delete_background' => [
                'boolean',
            ],
            'delete_attachments' => 'array',
            'delete_attachments.*' => [
                'integer',
                Rule::exists('attachments', 'id')->where(function ($query) {
                    $query
                        ->where('attachable_type', Fund::class)
                        ->where('attachable_id', $this->fund->id);
                }),
            ],
            'delete_links' => 'array',
            'delete_links.*' => [
                Rule::exists('links', 'id')->where(function ($query) {
                    $query
                        ->where('linkable_type', Fund::class)
                        ->where('linkable_id', $this->fund->id);
                }),
            ]
        ];

        return array_merge($parentRules, $rules);
    }

    public function withValidator($validator)
    {
        $validator->after(function () {
            $data = parent::validationData();

            if(isset($data['is_active']) && $data['is_active']===true)
            {
                $data['is_passive']=false;
            }

            if(isset($data['is_passive']) && $data['is_passive']===true)
            {
                $data['is_active']=false;
            }

            $this->merge($data);
        });
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "funds"
      summary: "updates funds manager"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Funds manager ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/FundsManagerUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  FundUpdate:
    type: "object"
    properties:
      logo:
        type: "string"
        description: "Fund logo; min 200x200px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      background:
        type: "string"
        description: "Fund background; min width 940px; allowed formats:jpeg, png - sholud use token returned from upload endpoint"
      name:
        type: "string"
        description: "64 characters max."
        example: "Fund Name"
      title:
        type: "string"
        description: "Title for fund description. 128 characters max."
        example: "fund description title"
      description:
        type: "string"
        description: "max 8000 chars. Allows basic formating (not counted to max chars limit). This parameter is treated as html text, allowed html tags are p and b, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)"
        example: "fund description"
      funds_manager_id:
        type: "number"
        description: "Must exist in funds_managers table in database."
        example: "2"
      country_id:
        type: "number"
        description: "Must exist in countries table in database."
        example: "12"
      currency_id:
        type: "number"
        description: "Must exist in currencies table in database."
        example: "1"
      management_fee:
        type: "number"
        description: "Management fee. Number between: 0 - 99999999.99."
        example: "1.99"
      performance_fee:
        type: "number"
        description: "Performance fee. Number between: 0 - 99999999.99."
        example: "2.99"
      duration:
        type: "number"
        description: "Duration."
        example: "2"
      is_active:
        type: "boolean"
        description: "True if is_passive is false or not set."
      is_passive:
        type: "boolean"
        description: "True if is_active is false or not set."
      social_media:
        type: "array"
        items:
          \$ref: "#/definitions/SocialMedia"
      excluded:
        type: "array"
        items:
          type: "integer"
        description: "array of countries for excluding news"
      fund_types:
        type: "array"
        items:
          type: "integer"
        description: "array of fund types"
      attachments:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      videos:
        type: "array"
        description: "sholud use token returned from upload endpoint"
        items:
          \$ref: "#/definitions/AttachmentToken"
      video_links:
        type: "array"
        items:
          \$ref: "#/definitions/Link"
      delete_logo:
        type: "boolean"
      delete_background:
        type: "boolean"
      delete_attachments:
        type: "array"
        items:
          type: "integer"
      delete_links:
        type: "array"
        items:
          type: "integer"
EOT;

        return [
            'FundUpdate' => $def,
        ];
    }
}
