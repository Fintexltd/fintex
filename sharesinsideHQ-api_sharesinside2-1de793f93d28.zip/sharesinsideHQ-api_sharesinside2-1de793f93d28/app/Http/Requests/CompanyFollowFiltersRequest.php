<?php

namespace App\Http\Requests;

use App\Http\Requests\Traits\FollowFiltersRequestTrait;

class CompanyFollowFiltersRequest extends CompanyIndexRequest
{
    use FollowFiltersRequestTrait;

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "companies"
      summary: "follows or unfollows companies maching filters"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
        - name: "Accept"
          in: "header"
          type: "string"
          enum:
          - "application/json"
        - name: "search"
          in: "query"
          type: "string"
          required: false
          description: "urlencoded, companies with maching name are returned"
        - name: "sector"
          in: "query"
          type: "array"
          items:
            type: "integer"
          required: false
          description: "result contains only companies having sector maching id in request"
        - name: "industry"
          in: "query"
          type: "array"
          items:
            type: "integer"
          required: false
          description: "result contains only companies having industry maching id in request"
        - name: "continent"
          in: "query"
          type: "array"
          items:
            type: "integer"
          required: false
          description: "result contains only companies having continent maching id in request"
        - name: "country"
          in: "query"
          type: "array"
          items:
            type: "integer"
          required: false
          description: "result contains only companies having country maching id in request"
        - name: "relation"
          in: "query"
          type: "array"
          items:
            type: "string"
          required: false
          description: "result contains only companies that have maching relation with user"
        - name: "type"
          in: "query"
          type: "string"
          required: true
          enum:
          - "follow"
          - "unfollow"
EOT;

    }
}
