<?php

namespace App\Http\Requests;

use App\Entities\SecurityToken;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class EmailConfirmationRequest extends FormRequest
{

    //TODO: find way to get this value from env
    protected $redirect = 'https://www.sharesinside.com/auth';

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'token' => [
                'required_without:email',
                Rule::exists('security_tokens', 'token')->where(function ($query){
                    $query->where('type', SecurityToken::EMAIL_CONFIRMATION)
                        ->where('valid_until', '>', Carbon::now()->format('Y-m-d H:i:s'));
                }),
            ],
            'email' => [
                'required_without:token',
                'email',
                Rule::exists('users', 'email')->where('email_confirmed', 0),
            ],
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "register"
      summary: "Depending on present parameter confirms email or resend confirmation email"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "token"
        in: "query"
        description: "Required if email parameter is not present. Email confirmation token."
        required: false
        type: "string"
      - name: "email"
        in: "query"
        description: "Required if token parameter is not present. User`s unconfirmed email adress."
        required: false
        type: "string"
EOT;

    }
}
