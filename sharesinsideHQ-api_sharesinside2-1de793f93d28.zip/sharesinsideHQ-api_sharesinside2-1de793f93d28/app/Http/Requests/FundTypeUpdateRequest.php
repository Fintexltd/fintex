<?php

namespace App\Http\Requests;

use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class FundTypeUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
                'min:1',
                'max:128',
                Rule::unique('fund_types')->ignore($this->fund_type->id),
            ]
        ];
    }

    public function messages()
    {
        return [
            'name.max' => 'Name must be at most 128 characters',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    put:
      tags:
      - "fund types"
      summary: "update fund type"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "path"
        name: "id"
        required: true
        type: "integer"
        minimum: 1
        description: "Fund type ID"
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with fund type data"
        required: true
        schema:
          \$ref: "#/definitions/FundTypeUpdate"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  FundTypeUpdate:
  type: "object"
  required:
  - "name"
  properties:
    name:
      type: "string"
EOT;

        return ['FundTypeUpdate' => $def];
    }
}
