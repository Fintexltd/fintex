<?php

namespace App\Http\Requests;

use App\Criteria\FundSortByCriteria;
use App\User;
use Illuminate\Foundation\Http\FormRequest;

class FundIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'search' => [
                'nullable',
                'string',
            ],
            'sort_by' => [
                'nullable',
                'in:' . implode(',', FundSortByCriteria::AVALIABLE_SORT_TYPES),
            ],
            'continent' => 'array',
            'continent.*' => [
                'integer',
                'exists:continents,id',
            ],
            'country' => 'array',
            'country.*' => [
                'integer',
                'exists:countries,id',
            ],
            'fund_type' => 'array',
            'fund_type.*' => [
                'integer',
                'exists:fund_types,id',
            ],
            'currency' => 'array',
            'currency.*' => [
                'integer',
                'exists:currencies,id',
            ],
            'active' => [
                'nullable',
                'boolean',
            ],
            'passive' => [
                'nullable',
                'boolean',
            ],
            'trading_frequency' => 'array',
            'trading_frequency.*' => [
                'in:daily,weekly,monthly,yearly,quarterly,halfyearly'
            ],
            'kind_of_fund' => 'array',
            'kind_of_fund.*' => [
                'in:non-regulated,professional-investment,retail,listed,ucts,etf-s'
            ],
            'open_closed' => 'array',
            'open_closed.*' => [
                'in:open,closed'
            ],
            'management_fee_from' => [
                'nullable',
                'numeric',
                'between:0.01,99999999.99'
            ],
            'management_fee_to' => [
                'nullable',
                'numeric',
                'between:0.01,99999999.99'
            ],
            'performance_fee_from' => [
                'nullable',
                'numeric',
                'between:0.01,99999999.99'
            ],
            'performance_fee_to' => [
                'nullable',
                'numeric',
                'between:0.01,99999999.99'
            ],
            'duration_from' => [
                'nullable',
                'integer',
                'between:1,4294967295'
            ],
            'duration_to' => [
                'nullable',
                'integer',
                'between:1,4294967295'
            ],
            'relations' => [
                'array',
                'in:' . implode(',', User::USER_FUND_RELATION_TYPES),
            ],
            'seed' => [
                'required_without:sort_by',
                'integer',
                'required_if:sort_by,' . FundSortByCriteria::SORT_DEFAULT],
            'page' => [
                'integer',
            ],
        ];
    }

    public function messages()
    {
        return [
            'sort_by.in' => 'Must be one of values: "' . implode('", "', FundSortByCriteria::AVALIABLE_SORT_TYPES) . '".',
            'relation.in' => 'Must be one of values: "' . implode('", "', User::USER_FUND_RELATION_TYPES) . '".',
        ];
    }

    public static function doc()
    {
        return <<<EOT
    get:
      tags:
      - "funds"
      summary: "list of fund tiles"
      produces:
      - "application/json"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - name: "page"
        in: "query"
        type: "integer"
        required: false
        description: "pagination for fund tiles list."
      - name: "search"
        in: "query"
        type: "string"
        required: false
        description: "urlencoded, fund with maching name are returned"
      - name: "relation"
        in: "query"
        type: "array"
        items:
          type: "string"
        required: false
        description: "result contains only fund that have maching relation with user"
      - name: "sort_by"
        in: "query"
        type: "string"
        required: false
        description: "sort order for funds"
        enum:
        - "default"
        - "most_viewed"
      - name: "seed"
        in: "query"
        type: "integer"
        required: false
        description: "seed for default sort order. Reqquired if 'sort_by' filed is not present or has default value."
      - name: "continent"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "country"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "fund_type"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "currency"
        in: "query"
        type: "array"
        items:
          type: "integer"
        required: false
      - name: "active"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "passive"
        in: "query"
        type: "boolean"
        required: false
        enum:
        - 0
        - 1
      - name: "trading_frequency"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "daily"
          - "weekly"
          - "monthly"
          - "yearly"
        required: false
      - name: "kind_of_fund"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "non-regulated"
          - "professional-investment"
          - "retail"
          - "listed"
          - "ucts"
          - "etf-s"
        required: false
      - name: "open_closed"
        in: "query"
        type: "array"
        items:
          type: "string"
          enum:
          - "open"
          - "closed"
        required: false
      - name: "management_fee_from"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "management_fee_to"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "performance_fee_from"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "performance_fee_to"
        in: "query"
        type: "number"
        required: false
        minimum: 0.01
        maximum: 99999999.99
      - name: "duration_from"
        in: "query"
        type: "integer"
        required: false
        minimum: 1
        maximum: 4294967295
      - name: "duration_to"
        in: "query"
        type: "integer"
        required: false
        minimum: 1
        maximum: 4294967295
EOT;

    }
}
