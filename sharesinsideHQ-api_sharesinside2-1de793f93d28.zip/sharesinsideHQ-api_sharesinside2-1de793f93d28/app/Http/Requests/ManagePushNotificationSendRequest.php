<?php

namespace App\Http\Requests;

use App\Entities\EntitiableInterface;
use App\Entities\Fund;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;

class ManagePushNotificationSendRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return RoleResolver::isGlobalAdmin($this->user()) || RoleResolver::isContentAdmin($this->user());
    }

    protected function prepareForValidation()
    {
        $input = $this->all();

        if (isset($input['notificable_type']) && isset(EntitiableInterface::ENTITIABLE_TYPE_CLASS[$input['notificable_type']])) {
            $input['notificable_type'] = EntitiableInterface::ENTITIABLE_TYPE_CLASS[$input['notificable_type']];
        }

        $this->merge($input);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'notificable_type' => [
                'required',
                'in:' . implode(',', EntitiableInterface::ENTITIABLE_TYPE_CLASS),
            ],
            'notificable_ids' => [
                'required',
                'array',
            ],
            'notificable_ids.*' => [
                'required',
                'integer',
                function ($attribute, $value, $fail) {
                    $query = resolve($this->input('notificable_type'))
                        ->where('is_accepted', true)
                        ->whereNull('deleted_at')
                        ->where('id', $value);

                    if($this->input('notificable_type')==Fund::class) {
                        $query->whereHas('fundsManager', function ($query) {
                            $query->where('is_accepted', true)->whereNull('deleted_at');
                        });
                    }

                    $entity = $query->first();

                    if (!$entity) {
                        return $fail($attribute.' with value '.$value.' does not exist or is inactive.');
                    }
                },
            ]
        ];
    }

    public static function doc()
    {
        return <<<EOT
    post:
      tags:
      - "manage-push-notification"
      parameters:
      - name: "Accept"
        in: "header"
        type: "string"
        enum:
        - "application/json"
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/ManagePushNotificationSendRequest"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  ManagePushNotificationSendRequest:
    type: "object"
    required:
    - "notificable_type"
    - "notificable_ids"
    properties:
      notificable_type:
        type: "string"
        description: "Required."
        enum:
        - "company"
        - "startup"
        - "fund"
      notificable_ids:
        type: "array"
        items:
          type: "integer"
EOT;

        return ['ManagePushNotificationSendRequest' => $def];
    }
}
