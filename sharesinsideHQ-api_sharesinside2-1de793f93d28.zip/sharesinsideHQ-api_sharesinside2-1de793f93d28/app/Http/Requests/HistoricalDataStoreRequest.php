<?php

namespace App\Http\Requests;

use App\Entities\Company;
use App\Entities\HistoricalDataPieceInterface;
use App\Entities\RelationInterface;
use App\Entities\SectionInterface;
use App\Repositories\AttachmentRepository;
use App\Services\RoleResolver;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class HistoricalDataStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $company = Company::find($this->get('company_id'));
        if (!$company) {
            return false;
        }

        $allowedRoles = [
            RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
            RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
            RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN,
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        ];

        $userRoles = RoleResolver::getRoles($this->user(), $company);

        return (bool)array_intersect($userRoles, $allowedRoles);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'company_id' => [
                'required',
                'exists:companies,id',
            ],
            'title' => [
                'required',
                'string',
                'max:64',
            ],
//            'type' => [
//                'required',
//                'in:' . implode(',', HistoricalDataPieceInterface::AVALIABLE_TYPES),
//            ],
            'fiscal_year' => [
                'required',
                'integer',
                'min:1',
                'max:9999',
            ],
            'file' => [
                'required',
                'string',
                Rule::exists('security_tokens', 'token')->where('value', AttachmentRepository::TYPE_FILE),
            ],
            'section_id' => [
                'required',
                Rule::exists('sections', 'id')->where(function($query){
                    $query
                        ->where('type', SectionInterface::HISTORICAL_DATA_SECTION)
                        ->where('referenced_id', $this->get('company_id'))
                        ->where('referenced_type', Company::class);
                }),
            ],
        ];
    }

    public function messages()
    {
        return [
            'type.in' => 'type must be one of: "' . implode('", "', HistoricalDataPieceInterface::AVALIABLE_TYPES) . '".'
        ];
    }

    public static function doc()
    {
        return <<<EOT
    parameters:
    - name: "Accept"
      in: "header"
      type: "string"
      enum:
      - "application/json"
    post:
      tags:
      - "historical-data"
      consumes:
      - "application/json"
      produces:
      - "application/json"
      parameters:
      - in: "body"
        name: "body"
        description: "json object with registration data"
        required: true
        schema:
          \$ref: "#/definitions/HistoricalDataStore"
EOT;

    }

    public static function definitions()
    {
        $def = <<<EOT
  HistoricalDataStore:
    type: "object"
    required:
    - "company_id"
    - "title"
    - "type"
    - "fiscal_year"
    - "file"
    properties:
      company_id:
        type: "integer"
      title:
        type: "string"
      type:
        type: "string"
        description: "Must be one of: type_divident, type_report, type_presentation"
      fiscal_year:
        type: "integer"
      file:
        \$ref: "#/definitions/AttachmentToken"
EOT;

        return ['HistoricalDataStore' => $def];
    }
}
