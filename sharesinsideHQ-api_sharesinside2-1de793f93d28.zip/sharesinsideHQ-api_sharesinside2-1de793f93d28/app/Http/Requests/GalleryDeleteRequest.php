<?php

namespace App\Http\Requests;

class GalleryDeleteRequest extends GalleryUpdateRequest
{
    public function rules()
    {
        return [];
    }

    public static function doc()
    {
        return <<<EOT
    delete:
      tags:
      - "company gallery"
      summary: "Deletes company gallery"
      parameters:
      - name: "id"
        in: "path"
        type: "string"
        required: true
        description: "Required. Must exist in database."
      produces:
      - "application/json"
EOT;

    }
}
