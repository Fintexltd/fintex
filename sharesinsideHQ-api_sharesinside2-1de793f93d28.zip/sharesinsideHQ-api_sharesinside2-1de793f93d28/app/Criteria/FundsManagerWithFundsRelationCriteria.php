<?php

namespace App\Criteria;

use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Criteria\Traits\ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

class FundsManagerWithFundsRelationCriteria extends EntityRelationCriteria
{
    use ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query
                    ->where('related_type', FundsManager::class)
                    ->whereIn('type', $this->relationArray)
                    ->where('user_id', data_get($this->user, 'id'));
            })->orWhereHas('funds', function ($query) {
                $query
                    ->whereHas('relations', function ($query) {
                        $query
                            ->where('related_type', Fund::class)
                            ->whereIn('type', $this->relationArray)
                            ->where('user_id', data_get($this->user, 'id'));
                    });
            });;
        };
    }
}
