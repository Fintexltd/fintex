<?php

namespace App\Criteria;

class FundCountryCriteria extends EntityCountryCriteria
{

}
