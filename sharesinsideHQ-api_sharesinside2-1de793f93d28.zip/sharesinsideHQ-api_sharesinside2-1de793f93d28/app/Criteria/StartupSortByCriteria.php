<?php

namespace App\Criteria;

class StartupSortByCriteria extends EntitySortByCriteria
{

}
