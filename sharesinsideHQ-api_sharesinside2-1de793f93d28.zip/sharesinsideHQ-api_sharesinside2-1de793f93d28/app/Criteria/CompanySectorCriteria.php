<?php

namespace App\Criteria;

use Illuminate\Support\Facades\DB;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class CompanySectorCriteria implements CriteriaInterface
{

    protected $sectors;
//    protected $industries;

    public function __construct(array $sectors)
    {
        $this->sectors = $sectors;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
//            $this->industries = DB::table('economic_sector_industry')
//                ->select('industry_id')
//                ->whereIn('economic_sector_id', $this->sectors)
//                ->get()
//                ->pluck('industry_id')
//                ->all();

            $query->where(function ($query) {
                $query->whereHas('industry', function ($query2) {
                    $query2->whereIn('economic_sector_id', $this->sectors);
//                    $query2->whereIn('id', $this->industries);
                });
            });
        };
    }
}