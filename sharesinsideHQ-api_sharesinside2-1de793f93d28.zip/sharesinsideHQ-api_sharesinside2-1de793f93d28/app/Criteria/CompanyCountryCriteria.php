<?php

namespace App\Criteria;

class CompanyCountryCriteria extends EntityCountryCriteria
{

}
