<?php

namespace App\Criteria;

use App\Entities\Event;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistUniqueTitlesCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $model
            ->join('events', function ($join) {
                $join->on('watchlist_items.watchlistable_id', '=', 'events.id')
                    ->where('watchlist_items.watchlistable_type', '=', Event::class);
            })
            ->select('title')
            ->distinct();

        return $model;
    }
}