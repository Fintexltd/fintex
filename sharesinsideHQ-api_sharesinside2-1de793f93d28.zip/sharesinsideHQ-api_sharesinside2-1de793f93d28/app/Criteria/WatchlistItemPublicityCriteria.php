<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Fund;
use App\Entities\Startup;
use App\Entities\WatchlistItemInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistItemPublicityCriteria implements CriteriaInterface
{
    protected $publicity;

    public function __construct(array $publicity)
    {
        $this->publicity = $publicity;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        $functions = [];

        if (in_array(WatchlistItemInterface::PUBLICITY_TYPE_PUBLIC, $this->publicity)){
            $functions[] = function ($query) {
                $query->where('is_internal', 0)
                    ->where('is_business', 0);
            };
        }

        if (in_array(WatchlistItemInterface::PUBLICITY_TYPE_BUSINESS, $this->publicity)){
            $functions[] = function ($query) {
                $query->where('is_business', 1)->where('entitiable_type', Company::class);
            };
        }

        if (in_array(WatchlistItemInterface::PUBLICITY_TYPE_INVESTOR, $this->publicity)){
            $functions[] = function ($query) {
                $query->where('is_business', 1)->whereIn('entitiable_type', [
                    Fund::class,
                    Startup::class
                ]);
            };
        }

        if (in_array(WatchlistItemInterface::PUBLICITY_TYPE_INTERNAL, $this->publicity)){
            $functions[] = function ($query) {
                $query->where('is_internal', 1);
            };
        }

        $criteria = new QueryOrCriteria($functions);

        return $criteria->appendQuery();
    }
}
