<?php

namespace App\Criteria;

use App\Entities\EntitiableInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistItemEntitiableTypesCriteria implements CriteriaInterface
{
    protected $entitiableTypes;

    public function __construct(array $entitiableTypes)
    {
        $this->entitiableTypes = $entitiableTypes;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $entitiableTypes = [];

        foreach ($this->entitiableTypes as $entitiableType) {
            $entitiableTypes[] = EntitiableInterface::ENTITIABLE_TYPE_CLASS[$entitiableType];
        }

        $model->whereIn('entitiable_type', $entitiableTypes);

        return $model;
    }
}
