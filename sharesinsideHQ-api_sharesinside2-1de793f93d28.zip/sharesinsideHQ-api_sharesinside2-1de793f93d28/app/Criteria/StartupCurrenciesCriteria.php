<?php

namespace App\Criteria;

class StartupCurrenciesCriteria extends EntityCurrenciesCriteria
{

}
