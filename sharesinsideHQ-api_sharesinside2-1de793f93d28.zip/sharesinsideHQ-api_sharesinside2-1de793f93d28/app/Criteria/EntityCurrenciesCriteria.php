<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class EntityCurrenciesCriteria implements CriteriaInterface
{

    protected $currencies;

    public function __construct(array $currencies)
    {
        $this->currencies = $currencies;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereIn('currency_id', $this->currencies);
        };
    }
}
