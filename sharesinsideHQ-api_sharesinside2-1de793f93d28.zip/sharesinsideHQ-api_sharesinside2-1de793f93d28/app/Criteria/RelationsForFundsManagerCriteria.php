<?php

namespace App\Criteria;

use App\Criteria\Traits\RelationsForCriteriaTrait;
use App\Entities\FundsManager;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class RelationsForFundsManagerCriteria implements CriteriaInterface
{
    use RelationsForCriteriaTrait;

    protected $fundsManager;
    protected $data;

    public function __construct(FundsManager $fundsManager, array $data)
    {
        $this->fundsManager = $fundsManager;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $fundsManager = $this->fundsManager;
            $search = array_get($data, 'search', '');
            $relations = $this->getRelations($data);
            $loginMethods = data_get($data, 'login_methods', []);

            $query = $query->whereHas('fundsManager')->where('related_id', $fundsManager->id);

            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $countries = data_get($data, 'countries', []);

            $query
                ->where(function ($query) use ($countries, $loginMethods, $search) {
                    $query->whereHas('user', function ($query) use ($countries, $loginMethods, $search) {
                        if ($countries) {
                            $query->whereIn('country_id', $countries);
                        };

                        if (in_array(User::LOGIN_METHOD_MANUAL, $loginMethods)) {
                            $query->whereNotNull('password');
                        }

                        if (in_array(User::LOGIN_METHOD_LINKEDIN, $loginMethods)) {
                            $query->whereNotNull('linkedin_id');
                        }

                        if ($search) {
                            $query->where(function ($query) use ($search) {
                                $query->where('name', 'LIKE', $search)
                                    ->orWhere('email', 'LIKE', $search);
                            });
                        }
                    });
                });

            if ($relations) {
                $query->whereIn('type', $relations);
            }

            /*$query = $query
                ->select('relations.*', 'funds_managers.name')
                ->leftJoin('funds_managers', function ($join) {
                    $join->on('relations.related_id', '=', 'funds_managers.id')
                        ->where('relations.related_type', '=', FundsManager::class);
                })
                ->orderBy('funds_managers.name');*/

            return $query;
        };
    }
}
