<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\RelationInterface;
use App\Services\DemoService;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class CompanyDemoRelationCriteria implements CriteriaInterface
{
    protected $relationArray;
    protected $user;

    public function __construct(array $relationArray)
    {
        $this->relationArray = $relationArray;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->where(function ($query) {
                if (in_array(RelationInterface::RELATION_TYPE_VIP, $this->relationArray)) {
                    $vipOf = DemoService::vipOf(Company::class);
                    $query->orWhereIn('id', $vipOf);
                }
                if (in_array(RelationInterface::RELATION_TYPE_SHAREHOLDER, $this->relationArray)) {
                    $shareholderOf = DemoService::shareholderOf(Company::class);
                    $query->orWhereIn('id', $shareholderOf);
                }
                if (in_array(RelationInterface::RELATION_TYPE_FOLLOWER, $this->relationArray)) {
                    $followerOf = DemoService::followerOf(Company::class);
                    $query->orWhereIn('id', $followerOf);
                }
            });
        };
    }
}
