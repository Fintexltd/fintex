<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerRelationsCriteria implements CriteriaInterface
{
    protected $user;
    protected $data;

    public function __construct(User $user, array $data)
    {
        $this->user = $user;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $user = $this->user;
            $search = array_get($data, 'search', '');
            $relations = array_get($data, 'relations', [
                Relation::RELATION_TYPE_PRIMARY_ADMIN,
                Relation::RELATION_TYPE_SECONDARY_ADMIN,
                Relation::RELATION_TYPE_EDITOR,
                Relation::RELATION_TYPE_FOLLOWER,
                Relation::RELATION_TYPE_VIP,
            ]);

            $query = $query->where('user_id', $user->id);

            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $query = $query
                ->whereHas('fundsManager', function ($query) use ($search) {
                    if ($search) {
                        $query->where('name', 'LIKE', $search);
                    }
                });

            if ($relations) {
                $query = $query
                    ->whereIn('type', $relations);
            }

            $query = $query
                ->select('relations.*', 'funds_managers.name')
                ->leftJoin('funds_managers', function ($join) {
                    $join->on('relations.related_id', '=', 'funds_managers.id')
                        ->where('relations.related_type', '=', FundsManager::class);
                })
                ->orderBy('funds_managers.name');

            return $query;
        };
    }
}
