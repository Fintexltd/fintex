<?php

namespace App\Criteria;

class StartupSearchCriteria extends EntitySearchCriteria
{

}
