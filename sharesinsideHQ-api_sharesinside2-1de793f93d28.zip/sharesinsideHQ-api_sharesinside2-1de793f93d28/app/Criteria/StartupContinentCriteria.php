<?php

namespace App\Criteria;

class StartupContinentCriteria extends EntityContinentCriteria
{

}
