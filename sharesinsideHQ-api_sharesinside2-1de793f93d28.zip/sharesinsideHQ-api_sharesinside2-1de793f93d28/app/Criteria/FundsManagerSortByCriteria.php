<?php

namespace App\Criteria;

class FundsManagerSortByCriteria extends EntitySortByCriteria
{

}
