<?php

namespace App\Criteria;

use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

abstract class EntityRelationCriteria implements CriteriaInterface
{
    protected $relationArray;
    protected $user;

    public function __construct(array $relationArray, User $user)
    {
        $this->relationArray = $relationArray;
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    abstract public function appendQuery();
}
