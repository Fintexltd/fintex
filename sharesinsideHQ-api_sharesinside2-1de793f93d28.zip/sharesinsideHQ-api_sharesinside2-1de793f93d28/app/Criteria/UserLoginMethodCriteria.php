<?php

namespace App\Criteria;

use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class UserLoginMethodCriteria implements CriteriaInterface
{
    protected $loginMethods;

    public function __construct(array $loginMethods)
    {
        $this->loginMethods = array_flip($loginMethods);
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            if (array_has($this->loginMethods, User::LOGIN_METHOD_MANUAL)) {
                $query->whereNotNull('password');
            }
            if (array_has($this->loginMethods, User::LOGIN_METHOD_LINKEDIN)) {
                $query->whereNotNull('linkedin_id');
            }
        };
    }
}