<?php

namespace App\Criteria\Traits;

use App\User;

trait RelationsForCriteriaTrait
{
    public function getRelations(array $data)
    {
        return array_reduce(
            array_filter(
                array_merge(
                    array_get($data, 'relations', []),
                    [array_get($data, 'relation', null)]
                ),
                function ($item) {
                    return !empty($item);
                }
            ),
            function ($carry, $item) {
                if ($item == 'admins') {
                    $carry[] = User::RELATION_TYPE_PRIMARY_ADMIN;
                    $carry[] = User::RELATION_TYPE_SECONDARY_ADMIN;
                } else {
                    $carry[] = $item;
                }

                return $carry;
            },
            []
        );
    }
}
