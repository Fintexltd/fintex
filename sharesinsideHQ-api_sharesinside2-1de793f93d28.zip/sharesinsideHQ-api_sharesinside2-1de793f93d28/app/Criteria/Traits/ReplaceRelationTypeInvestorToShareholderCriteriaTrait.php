<?php

namespace App\Criteria\Traits;

use App\User;

trait ReplaceRelationTypeInvestorToShareholderCriteriaTrait
{
    public function __construct(array $relationArray, User $user)
    {
        $replaceMap = [User::RELATION_TYPE_INVESTOR => User::RELATION_TYPE_SHAREHOLDER];
        $this->relationArray = array_map(function($value) use ($replaceMap) {
            return str_replace(array_keys($replaceMap), array_values($replaceMap), $value);
        }, $relationArray);
        $this->user = $user;
    }
}
