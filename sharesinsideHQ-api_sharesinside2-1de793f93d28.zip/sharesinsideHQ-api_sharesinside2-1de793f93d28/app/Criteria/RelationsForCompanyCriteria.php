<?php

namespace App\Criteria;

use App\Criteria\Traits\RelationsForCriteriaTrait;
use App\Entities\Company;
use App\Entities\Country;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class RelationsForCompanyCriteria implements CriteriaInterface
{
    use RelationsForCriteriaTrait;

    protected $company;
    protected $data;

    public function __construct(Company $company, array $data)
    {
        $this->company = $company;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $company = $this->company;
            $search = array_get($data, 'search', '');
            $relations = $this->getRelations($data);

            $loginMethods = data_get($data, 'login_methods', []);

            $query = $query->where('related_id', $company->id);


            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $countries = data_get($data, 'countries', []);

            $query = $query
                ->where(function ($query) use ($countries, $loginMethods, $search) {
                    $query->whereHas('user', function ($query) use ($countries, $loginMethods, $search) {
                        if ($countries) {
                            $query->whereIn('country_id', $countries);
                        };

                        if (in_array(User::LOGIN_METHOD_MANUAL, $loginMethods)) {
                            $query->whereNotNull('password');
                        }

                        if (in_array(User::LOGIN_METHOD_LINKEDIN, $loginMethods)) {
                            $query->whereNotNull('linkedin_id');
                        }

                        if ($search) {
                            $query->where(function ($query) use ($search) {
                                $query->where('name', 'LIKE', $search)
                                    ->orWhere('email', 'LIKE', $search);
                            });
                        }
                    });
                });

            $query = $query
                ->where(function ($query) {
                    $query
                        ->whereHas('company')
                        ->orWhereHas('country');
                });

            if ($relations) {
                $query = $query
                    ->whereIn('type', $relations);
            }

//            if (in_array(User::RELATION_TYPE_SHAREHOLDER, $relations)) {
//                $query = $query
//                    ->whereHas('shareholder', function ($query) {
//                        $query
//                            ->where('is_accepted', true)
//                            ->where('is_confirmed', true);
//                    });
//            }

            $query = $query
                ->select('relations.*', 'companies.name', 'countries.country_name')
                ->leftJoin('companies', function ($join) {
                    $join->on('relations.related_id', '=', 'companies.id')
                        ->where('relations.related_type', '=', Company::class);
                })
                ->leftJoin('countries', function ($join) {
                    $join->on('relations.related_id', '=', 'countries.id')
                        ->where('relations.related_type', '=', Country::class);
                })
                ->orderBy('companies.name');

            return $query;
        };
    }
}
