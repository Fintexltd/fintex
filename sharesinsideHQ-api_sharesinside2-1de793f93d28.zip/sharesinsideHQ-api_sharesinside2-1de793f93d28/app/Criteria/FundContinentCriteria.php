<?php

namespace App\Criteria;

class FundContinentCriteria extends EntityContinentCriteria
{

}
