<?php

namespace App\Criteria;

class FundSearchCriteria extends EntitySearchCriteria
{

}
