<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerByFundsContinentCriteria implements CriteriaInterface
{

    protected $continents;

    public function __construct(array $continents)
    {
        $this->continents = $continents;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('funds', function ($query) {
                $query->whereHas('country', function ($query) {
                    $query->whereIn('continent_id', $this->continents);
                });
            });
        };
    }
}
