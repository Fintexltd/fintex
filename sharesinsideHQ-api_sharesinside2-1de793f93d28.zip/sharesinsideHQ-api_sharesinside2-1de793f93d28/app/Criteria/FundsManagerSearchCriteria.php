<?php

namespace App\Criteria;

class FundsManagerSearchCriteria extends EntitySearchCriteria
{

}
