<?php

namespace App\Criteria;

use App\Services\RoleResolver;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistExclusionCriteria implements CriteriaInterface
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $query->where('is_excluded', false);

            if (!RoleResolver::isDemoUser($this->user)) {
                $query
                    ->orWhere(function ($query) {
                        $query
                            ->where('is_excluded', true)
                            ->whereDoesntHave('excluded', function ($query) {
                                $query->where('country_id', $this->user->country_id);
                            });
                    });
            }
        };
    }
}
