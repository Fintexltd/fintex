<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistSearchCriteria implements CriteriaInterface
{
    protected $search;

    public function __construct($search)
    {
        $this->search = $search;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where(function ($query) {
            $query
                ->whereHas('news', function ($query) {
                    $query
                        ->where('title', 'LIKE', '%' . $this->search . '%')
                        ->orWhere('text_description', 'LIKE', '%' . $this->search . '%');
                })->orWhereHas('event', function ($query) {
                    $query
                        ->where('title', 'LIKE', '%' . $this->search . '%')
                        ->orWhere('text_description', 'LIKE', '%' . $this->search . '%');
                })->orWhereHas('project', function ($query) {
                    $query
                        ->where('title', 'LIKE', '%' . $this->search . '%')
                        ->orWhere('text_description', 'LIKE', '%' . $this->search . '%');
                });
        });

        return $model;
    }
}
