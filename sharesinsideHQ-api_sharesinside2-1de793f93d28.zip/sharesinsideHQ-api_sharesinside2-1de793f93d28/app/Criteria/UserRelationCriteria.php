<?php

namespace App\Criteria;

use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class UserRelationCriteria implements CriteriaInterface
{
    protected $relations;

    public function __construct(array $relations)
    {
        $this->relations = $relations;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query->whereIn('relations.type', $this->relations);
            });
        };
    }
}