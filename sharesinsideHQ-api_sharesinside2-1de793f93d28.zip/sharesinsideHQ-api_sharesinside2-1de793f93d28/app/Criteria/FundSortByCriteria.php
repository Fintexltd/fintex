<?php

namespace App\Criteria;

class FundSortByCriteria extends EntitySortByCriteria
{

}
