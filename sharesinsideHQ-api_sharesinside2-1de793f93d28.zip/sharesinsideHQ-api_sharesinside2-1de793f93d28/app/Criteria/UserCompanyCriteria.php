<?php

namespace App\Criteria;

use App\Entities\Company;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class UserCompanyCriteria implements CriteriaInterface
{
    protected $companies;

    public function __construct(array $companies)
    {
        $this->companies = $companies;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query
                    ->whereIn('related_id', $this->companies)
                    ->where('related_type', Company::class);
            });
        };
    }
}