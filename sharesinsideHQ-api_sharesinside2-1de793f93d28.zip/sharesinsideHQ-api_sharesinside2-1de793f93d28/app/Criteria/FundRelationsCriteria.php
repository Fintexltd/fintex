<?php

namespace App\Criteria;

use App\Entities\Fund;
use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundRelationsCriteria implements CriteriaInterface
{
    protected $user;
    protected $data;
    private $withAdmins;

    public function __construct(User $user, array $data, bool $withAdmins = false)
    {
        $this->user = $user;
        $this->data = $data;
        $this->withAdmins = $withAdmins;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $relationTypes = [
                Relation::RELATION_TYPE_EDITOR,
                Relation::RELATION_TYPE_FOLLOWER,
                Relation::RELATION_TYPE_VIP,
                Relation::RELATION_TYPE_SHAREHOLDER,
                Relation::RELATION_TYPE_INVESTOR,
            ];

            if($this->withAdmins) {
                $relationTypes[] = Relation::RELATION_TYPE_PRIMARY_ADMIN;
                $relationTypes[] = Relation::RELATION_TYPE_SECONDARY_ADMIN;
            }

            $data = $this->data;
            $user = $this->user;
            $search = array_get($data, 'search', '');
            $relations = array_get($data, 'relations', $relationTypes);

            $query = $query->where('user_id', $user->id);

            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $query = $query
                ->whereHas('fund', function ($query) use ($search) {
                    $query->whereHas('fundsManager');

                    if ($search) {
                        $query->where('name', 'LIKE', $search);
                    }
                });

            if ($relations) {
                $replaceMap = [Relation::RELATION_TYPE_INVESTOR => Relation::RELATION_TYPE_SHAREHOLDER];
                $relations = array_map(function($value) use ($replaceMap) {
                    return str_replace(array_keys($replaceMap), array_values($replaceMap), $value);
                }, $relations);

                $query = $query
                    ->whereIn('type', $relations);
            }

            $query = $query
                ->select('relations.*', 'funds.name')
                ->leftJoin('funds', function ($join) {
                    $join->on('relations.related_id', '=', 'funds.id')
                        ->where('relations.related_type', '=', Fund::class);
                })
                ->orderBy('funds.name');

            return $query;
        };
    }
}
