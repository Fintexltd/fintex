<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistAttachmentCriteria implements CriteriaInterface
{
    protected $attachments;

    public function __construct(array $attachments)
    {
        $this->attachments = $attachments;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function($query) {
            foreach ($this->attachments as $attachment) {
                $query->orWhereHas($attachment);
            }
        };
    }
}