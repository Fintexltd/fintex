<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistItemEntitiableCriteria implements CriteriaInterface
{
    protected $entity;

    public function __construct($entity)
    {
        $this->entity = $entity;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model
            ->where('entitiable_type', get_class($this->entity))
            ->where('entitiable_id', $this->entity->id);

        return $model;
    }
}
