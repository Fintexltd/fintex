<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerWithFundsSearchCriteria implements CriteriaInterface
{

    protected $search;

    public function __construct($search)
    {
        $this->search = $search;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->where(function ($query) {
                $query->where('name', 'LIKE', '%' . $this->search . '%')
                ->orWhereHas('funds', function ($query) {
                    $query
                        ->where('is_accepted', 1)
                        ->where('name', 'LIKE', '%' . $this->search . '%');
                });
            });
        };
    }
}
