<?php

namespace App\Criteria;

use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistRelationCriteria implements CriteriaInterface
{
    protected $user;
    protected $relations;

    public function __construct(User $user, array $relations)
    {
        $this->user = $user;
        $this->relations = $relations;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('company', function ($query) {
                $query->whereHas('relations', function ($query) {
                    $query
                        ->where('user_id', $this->user->id)
                        ->whereIn('type', $this->relations)
//                        ->where(function($query){
//                            $query->whereDoesntHave('shareholder')
//                                ->orWhereHas('shareholder', function($query){
//                                    $query
//                                        ->where('is_accepted', true)
//                                        ->where('is_confirmed', true);
//                                });
//                        })
                    ;
                });
            })
            ->orWhereHas('startup', function ($query) {
                $query->whereHas('relations', function ($query) {
                    $query
                        ->where('user_id', $this->user->id)
                        ->whereIn('type', $this->replacedRelations());
                });
            })
            ->orWhereHas('fund', function ($query) {
                $query->whereHas('fundsManager')->whereHas('relations', function ($query) {
                    $query
                        ->where('user_id', $this->user->id)
                        ->whereIn('type', $this->replacedRelations());
                });
            })
            ->orWhereHas('fundsManager', function ($query) {
                $query->whereHas('relations', function ($query) {
                    $query
                        ->where('user_id', $this->user->id)
                        ->whereIn('type', $this->relations);
                });
            });
        };
    }

    private function replacedRelations()
    {
        $replaceMap = [User::RELATION_TYPE_INVESTOR => User::RELATION_TYPE_SHAREHOLDER];
        $relations = array_map(function($value) use ($replaceMap) {
            if($value!==User::RELATION_TYPE_SHAREHOLDER) {
                return str_replace(array_keys($replaceMap), array_values($replaceMap), $value);
            }
        }, $this->relations);

        return $relations;
    }
}
