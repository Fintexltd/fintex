<?php

namespace App\Criteria;

use Illuminate\Support\Facades\DB;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class EntitySortByCriteria implements CriteriaInterface
{
    const SORT_DEFAULT = 'default';
    const SORT_MOST_VIEWED = 'most_viewed';
    const SORT_NEW_FIRST = 'new_first';

    const AVALIABLE_SORT_TYPES = [
        self::SORT_DEFAULT,
        self::SORT_MOST_VIEWED,
    ];

    protected $sortOrder;

    public function __construct($sortOrder = self::SORT_DEFAULT)
    {
        $this->sortOrder = $sortOrder;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        switch ($this->sortOrder) {
            case self::SORT_MOST_VIEWED:
                $model = $model->orderBy('views', 'desc')
                    ->orderBy('name', 'asc');
                break;
            case self::SORT_NEW_FIRST:
                $model = $model->orderBy('created_at', 'desc')
                    ->orderBy('name', 'asc');
                break;
            default:
                $seed = (int)(request()->get('seed') ?? rand());
                //TODO: rethink what should be default for this switch
                switch (config('database.default')){
                    case 'sqlite':
                        $model = $model->inRandomOrder();
                        break;
                    default:
                        $model = $model->orderBy(DB::raw("RAND($seed)"));
                }
        }

        return $model;
    }
}
