<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderCountryCriteria implements CriteriaInterface
{

    protected $countries;

    public function __construct(array $countries)
    {
        $this->countries = $countries;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereIn('country_id', $this->countries);
        };
    }
}