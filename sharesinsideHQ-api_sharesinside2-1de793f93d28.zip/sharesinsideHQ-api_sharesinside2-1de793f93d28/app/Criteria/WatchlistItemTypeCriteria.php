<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistItemTypeCriteria implements CriteriaInterface
{
    protected $types;

    public function __construct(array $types)
    {
        $this->types = $types;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->whereIn('watchlistable_type', $this->types);

        return $model;
    }
}
