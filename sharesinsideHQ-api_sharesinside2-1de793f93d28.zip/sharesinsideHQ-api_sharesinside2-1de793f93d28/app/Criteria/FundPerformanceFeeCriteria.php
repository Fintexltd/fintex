<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundPerformanceFeeCriteria implements CriteriaInterface
{
    protected $from;
    protected $to;

    public function __construct(?string $from = null, ?string $to = null)
    {
        $this->from = $from;
        $this->to = $to;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where(function ($query) {
            if ($this->from) {
                $query->where('performance_fee', '>=', $this->from);
            }
            if ($this->to) {
                $query->where('performance_fee', '<=', $this->to);
            }
        });

        return $model;
    }
}
