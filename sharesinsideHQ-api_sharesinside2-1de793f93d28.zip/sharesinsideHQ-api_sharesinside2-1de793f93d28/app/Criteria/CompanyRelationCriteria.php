<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Services\RoleResolver;
use App\Services\DemoService;
use App\User;

class CompanyRelationCriteria extends EntityRelationCriteria
{
    public function appendQuery()
    {
        return function ($query) {
            $query->where(function ($query) {
                if (RoleResolver::isDemoUser($this->user)) {
                    if (in_array(User::RELATION_TYPE_VIP, $this->relationArray)) {
                        $vipOf = DemoService::vipOf(Company::class);
                        $query->orWhereIn('id', $vipOf);
                    }
                    if (in_array(User::RELATION_TYPE_SHAREHOLDER, $this->relationArray)) {
                        $shareholderOf = DemoService::shareholderOf(Company::class);
                        $query->orWhereIn('id', $shareholderOf);
                    }
                }

                foreach ($this->relationArray as $relation) {
                    $query->orWhereHas('relations', function ($query) {
                        $query
                            ->where('related_type', Company::class)
                            ->whereIn('type', $this->relationArray)
                            ->where('user_id', data_get($this->user, 'id'))
//                            ->where(function($query){
//                                $query
//                                    ->whereDoesntHave('shareholder')
//                                    ->orWhereHas('shareholder', function($query){
//                                        $query->where('is_confirmed', true)
//                                            ->where('is_accepted', true);
//                                    });
//                            })
                        ;
                    });
                }

            });
        };
    }
}
