<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Services\DemoService;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerDemoRelationCriteria implements CriteriaInterface
{
    protected $relationArray;
    protected $user;

    public function __construct(array $relationArray)
    {
        $this->relationArray = $relationArray;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->where(function ($query) {
                if (in_array(RelationInterface::RELATION_TYPE_VIP, $this->relationArray)) {
                    $vipOf = DemoService::vipOf(FundsManager::class);
                    $query->orWhereIn('id', $vipOf);
                }
                if (in_array(RelationInterface::RELATION_TYPE_SHAREHOLDER, $this->relationArray)) {
                    $shareholderOf = DemoService::shareholderOf(FundsManager::class);
                    $query->orWhereIn('id', $shareholderOf);
                }
                if (in_array(RelationInterface::RELATION_TYPE_FOLLOWER, $this->relationArray)) {
                    $followerOf = DemoService::followerOf(FundsManager::class);
                    $query->orWhereIn('id', $followerOf);
                }
            });
        };
    }
}
