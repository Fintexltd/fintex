<?php

namespace App\Criteria;

use App\Criteria\Traits\RelationsForCriteriaTrait;
use App\Entities\Startup;
use App\Entities\Country;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class RelationsForStartupCriteria implements CriteriaInterface
{
    use RelationsForCriteriaTrait;

    protected $startup;
    protected $data;

    public function __construct(Startup $startup, array $data)
    {
        $this->startup = $startup;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $startup = $this->startup;
            $search = array_get($data, 'search', '');
            $relations = $this->getRelations($data);
            $loginMethods = data_get($data, 'login_methods', []);

            $query = $query->whereHas('startup')->where('related_id', $startup->id);


            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $countries = data_get($data, 'countries', []);

            $query
                ->where(function ($query) use ($countries, $loginMethods, $search) {
                    $query->whereHas('user', function ($query) use ($countries, $loginMethods, $search) {
                        if ($countries) {
                            $query->whereIn('country_id', $countries);
                        };

                        if (in_array(User::LOGIN_METHOD_MANUAL, $loginMethods)) {
                            $query->whereNotNull('password');
                        }

                        if (in_array(User::LOGIN_METHOD_LINKEDIN, $loginMethods)) {
                            $query->whereNotNull('linkedin_id');
                        }

                        if ($search) {
                            $query->where(function ($query) use ($search) {
                                $query->where('name', 'LIKE', $search)
                                    ->orWhere('email', 'LIKE', $search);
                            });
                        }
                    });
                });

            if ($relations) {
                $query = $query
                    ->whereIn('type', $relations);
            }

            return $query;
        };
    }
}
