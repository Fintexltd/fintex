<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class StartupRaisedAmountCriteria implements CriteriaInterface
{
    protected $from;
    protected $to;

    public function __construct(?string $from = null, ?string $to = null)
    {
        $this->from = $from;
        $this->to = $to;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where(function ($query) {
            if ($this->from) {
                $query->where('raised_amount', '>=', $this->from);
            }
            if ($this->to) {
                $query->where('raised_amount', '<=', $this->to);
            }
        });

        return $model;
    }
}
