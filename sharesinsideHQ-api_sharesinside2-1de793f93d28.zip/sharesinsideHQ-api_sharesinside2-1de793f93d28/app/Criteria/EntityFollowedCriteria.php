<?php

namespace App\Criteria;

use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class EntityFollowedCriteria implements CriteriaInterface
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('followers', function($query){
                $query->where('users.id', $this->user->id);
            });

//            $followedCompanyIds = $this
//                ->user
//                ->relations()
//                ->where('type', User::RELATION_TYPE_FOLLOWER)
//                ->get(['related_id'])
//                ->pluck('related_id')
//                ->all();
//
//            $query->whereIn('id', $followedCompanyIds);
        };
    }
}
