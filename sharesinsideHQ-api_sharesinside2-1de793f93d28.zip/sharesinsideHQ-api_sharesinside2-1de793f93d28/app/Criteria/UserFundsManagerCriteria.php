<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class UserFundsManagerCriteria implements CriteriaInterface
{
    protected $fundsManagers;

    public function __construct(array $fundsManagers)
    {
        $this->fundsManagers = $fundsManagers;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query
                    ->whereIn('related_id', $this->fundsManagers)
                    ->where('related_type', FundsManager::class);
            });
        };
    }
}
