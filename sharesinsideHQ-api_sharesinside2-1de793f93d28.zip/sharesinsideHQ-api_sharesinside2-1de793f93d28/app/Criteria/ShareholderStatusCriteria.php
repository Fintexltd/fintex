<?php

namespace App\Criteria;

use App\Entities\Relation;
use App\Entities\ShareholderInterface;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderStatusCriteria implements CriteriaInterface
{

    protected $statuses;

    public function __construct(array $statuses = [])
    {
//        $this->statuses = array_flip($statuses);

        $this->statuses = array_map(
            function ($item) {
                switch ($item) {
                    case ShareholderInterface::STATUS_PENDING:
                        return Relation::RELATION_TYPE_SHAREHOLDER_PENDING;
                    case ShareholderInterface::STATUS_ACTIVE:
                        return Relation::RELATION_TYPE_SHAREHOLDER;
                    case ShareholderInterface::STATUS_TO_CONFIRM:
                        return Relation::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM;
                }
            },
            $statuses
        );
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        if ($this->statuses) {
            return function ($query) {
                $query->whereHas('relation', function ($query) {
                    $query->whereIn('type', $this->statuses);
                });
            };
        } else {
            return function ($query) {

            };
        }
//
//        $functions = [];
//
//        if (array_has($this->statuses, ShareholderInterface::STATUS_PENDING)) {
//            $functions[] = function ($query) {
//                $query->where('is_accepted', 0);
//            };
//        }
//
//        if (array_has($this->statuses, ShareholderInterface::STATUS_ACTIVE)) {
//            $functions[] = function ($query) {
//                $query->where('is_accepted', 1)
//                    ->where('is_confirmed', 1);
//            };
//        }
//
//        if (array_has($this->statuses, ShareholderInterface::STATUS_TO_CONFIRM)) {
//            $functions[] = function ($query) {
//                $query->where('is_accepted', 1)
//                    ->where('is_confirmed', 0);
//            };
//        }
//
//        $criteria = new QueryOrCriteria($functions);
//
//        return $criteria->appendQuery();
    }
}