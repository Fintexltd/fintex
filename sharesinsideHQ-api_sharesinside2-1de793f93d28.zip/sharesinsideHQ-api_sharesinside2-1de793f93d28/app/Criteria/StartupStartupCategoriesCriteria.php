<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class StartupStartupCategoriesCriteria implements CriteriaInterface
{

    protected $startupCategories;

    public function __construct(array $startupCategories)
    {
        $this->startupCategories = $startupCategories;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('startupCategories', function ($query) {
                $query->whereIn('startup_category_id', $this->startupCategories);
            });
        };
    }
}
