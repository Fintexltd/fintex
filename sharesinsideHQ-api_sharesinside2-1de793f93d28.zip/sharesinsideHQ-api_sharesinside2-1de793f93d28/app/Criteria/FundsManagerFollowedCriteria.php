<?php

namespace App\Criteria;

class FundsManagerFollowedCriteria extends EntityFollowedCriteria
{

}
