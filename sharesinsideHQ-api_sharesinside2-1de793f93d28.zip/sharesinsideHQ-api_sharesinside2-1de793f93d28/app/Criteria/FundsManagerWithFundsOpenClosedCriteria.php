<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerWithFundsOpenClosedCriteria implements CriteriaInterface
{

    protected $openClosed;

    public function __construct(array $openClosed)
    {
        $this->openClosed = $openClosed;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('funds', function ($query) {
                $query->whereIn('open_closed', $this->openClosed);
            });
        };
    }
}
