<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class CompanyManagedCriteria implements CriteriaInterface
{

    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            if (!RoleResolver::isGlobalAdmin($this->user) && !RoleResolver::isContentAdmin($this->user)) {
                $managed = $this->user->relations()
                    ->where('related_type', Company::class)
                    ->whereIn('type', [
                        User::RELATION_TYPE_PRIMARY_ADMIN,
                        User::RELATION_TYPE_SECONDARY_ADMIN,
                        User::RELATION_TYPE_EDITOR,
                    ])
                    ->get()
                    ->pluck('related_id')
                    ->all();

                $managedRegions = Relation::query()
                    ->where('user_id', $this->user->id)
                    ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
                    ->pluck('related_id')
                    ->all();

                $query
                    ->whereIn('id', $managed)
                    ->orWhereIn('country_id', $managedRegions);
            }
        };
    }
}
