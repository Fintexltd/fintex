<?php

namespace App\Criteria;

class CompanySearchCriteria extends EntitySearchCriteria
{

}
