<?php

namespace App\Criteria;

class StartupFollowedCriteria extends EntityFollowedCriteria
{

}
