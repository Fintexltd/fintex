<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistSortByCriteria implements CriteriaInterface
{
    const SORT_DEFAULT = 'default';
    const SORT_DEFAULT_WITH_UNPUBLISHED = 'sort_default_with_unpublished';
    const SORT_TYPE_UPCOMING_EVENTS = 'sort_type_upcoming_events';
    const SORT_TYPE_DRAFTS_FIRST_THEN_NEWEST_FIRST = 'sort_type_drafts_first_then_newest_first';
    const SORT_MOST_VIEWED = 'most_viewed';

    const AVALIABLE_SORT_TYPES = [
        self::SORT_DEFAULT,
        self::SORT_MOST_VIEWED,
    ];

    protected $sortOrder;

    public function __construct($sortOrder = self::SORT_DEFAULT)
    {
        $this->sortOrder = $sortOrder;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        switch ($this->sortOrder) {
            case self::SORT_MOST_VIEWED:
                $model = $model->orderBy('views', 'desc');
                break;
            case self::SORT_DEFAULT_WITH_UNPUBLISHED:
                if (config('database.default') === 'sqlite') {
                    $expression = '(`publish_at`  > datetime() || `publish_at` IS NULL) DESC, `publish_at` IS NULL ASC, `publish_at` DESC';
                } else {
                    $expression = '(`publish_at`  > NOW() || `publish_at` IS NULL) DESC, `publish_at` IS NULL ASC, `publish_at` DESC';
                }
                $model = $model->orderByRaw($expression);

                break;
            case self::SORT_TYPE_UPCOMING_EVENTS:
                $model->join('events', 'events.id', '=', 'watchlist_items.watchlistable_id');
                $model->orderBy('events.event_date', 'asc');
                $model->select('watchlist_items.*');
                break;
            case self::SORT_TYPE_DRAFTS_FIRST_THEN_NEWEST_FIRST:
                $model = $model
                    ->orderBy('is_draft', 'desc')
                    ->orderBy('id', 'desc');
                break;
            default:
                $model->orderBy('publish_at', 'desc');
        }

        return $model;
    }
}