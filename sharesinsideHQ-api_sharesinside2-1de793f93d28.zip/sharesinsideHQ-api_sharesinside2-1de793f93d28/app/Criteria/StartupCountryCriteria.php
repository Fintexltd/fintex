<?php

namespace App\Criteria;

class StartupCountryCriteria extends EntityCountryCriteria
{

}
