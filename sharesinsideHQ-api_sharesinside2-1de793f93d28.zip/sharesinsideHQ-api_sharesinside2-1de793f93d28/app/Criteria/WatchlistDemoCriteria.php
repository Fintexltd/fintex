<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Startup;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Services\DemoService;
use App\Services\RoleResolver;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistDemoCriteria implements CriteriaInterface
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            if (RoleResolver::isDemoUser($this->user)) {
                $query->where(function ($query) {
                    if ($this->user->name) {
                        $ids = $this
                            ->user
                            ->relations()
                            ->where('related_type', Company::class)
                            ->get()
                            ->pluck('related_id')
                            ->toArray();
                    } else {
                        $vipOf = DemoService::vipOf(Company::class);
                        $shareholderOf = DemoService::shareholderOf(Company::class);
                        $followerOf = DemoService::followerOf(Company::class);

                        $ids = array_unique(array_merge($vipOf, $shareholderOf, $followerOf));
                    }

                    $query->where('entitiable_type', Company::class)->whereIn('entitiable_id', $ids);
                })->orWhere(function ($query) {
                    if ($this->user->name) {
                        $ids = $this
                            ->user
                            ->relations()
                            ->where('related_type', Startup::class)
                            ->get()
                            ->pluck('related_id')
                            ->toArray();
                    } else {
                        $vipOf = DemoService::vipOf(Startup::class);
                        $shareholderOf = DemoService::shareholderOf(Startup::class);
                        $followerOf = DemoService::followerOf(Startup::class);

                        $ids = array_unique(array_merge($vipOf, $shareholderOf, $followerOf));
                    }

                    $query->where('entitiable_type', Startup::class)->whereIn('entitiable_id', $ids);
                })->orWhere(function ($query) {
                    if ($this->user->name) {
                        $ids = $this
                            ->user
                            ->relations()
                            ->where('related_type', FundsManager::class)
                            ->get()
                            ->pluck('related_id')
                            ->toArray();
                    } else {
                        $vipOf = DemoService::vipOf(FundsManager::class);
                        $shareholderOf = DemoService::shareholderOf(FundsManager::class);
                        $followerOf = DemoService::followerOf(FundsManager::class);

                        $ids = array_unique(array_merge($vipOf, $shareholderOf, $followerOf));
                    }

                    $query->where(function ($query) use ($ids) {
                        $query->where('entitiable_type', FundsManager::class)->whereIn('entitiable_id', $ids);
                    })->orWhere(function ($query) use ($ids) {
                        $query
                            ->where('entitiable_type', Fund::class)
                            ->whereHas('fund', function ($query) use ($ids) {
                                $query->whereIn('funds_manager_id', $ids);
                            });
                    });
                });
            }
        };
    }
}
