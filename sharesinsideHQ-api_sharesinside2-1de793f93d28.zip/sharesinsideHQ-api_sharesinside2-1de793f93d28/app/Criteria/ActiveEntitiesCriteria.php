<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ActiveEntitiesCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('company', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');
            })
            ->orWhereHas('startup', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');
            })
            ->orWhereHas('fund', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');

                $query->whereHas('fundsManager', function ($query) {
                    $query->where('is_accepted', true)->whereNull('deleted_at');
                });
            })
            ->orWhereHas('fundsManager', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');
            });
        };
    }
}
