<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class LseAssetSortByCriteria implements CriteriaInterface
{
    const SORT_DEFAULT = 'default';
    const SORT_NEW_FIRST = 'new_first';

    const AVALIABLE_SORT_TYPES = [
        self::SORT_DEFAULT,
        self::SORT_NEW_FIRST,
    ];

    protected $sortOrder;

    public function __construct($sortOrder = self::SORT_DEFAULT)
    {
        $this->sortOrder = $sortOrder;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        switch ($this->sortOrder) {
            case self::SORT_NEW_FIRST:
                $model = $model->orderBy('created_at', 'desc')
                    ->orderBy('name', 'asc');
                break;
            default:
                $model = $model->orderBy('name', 'asc');
        }

        return $model;
    }
}
