<?php

namespace App\Criteria;

use App\Entities\Relation;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderAcceptCriteria implements CriteriaInterface
{

    protected $condition;

    public function __construct(bool $condition = false)
    {
        $this->condition = $condition;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query
                ->whereHas('relation', function ($query) {

                    $concerned = $this->condition ? [
                        Relation::RELATION_TYPE_SHAREHOLDER,
                        Relation::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM,
                    ] : [
                        Relation::RELATION_TYPE_SHAREHOLDER_PENDING
                    ];

                    $query->whereIn('type', $concerned);
                });
        };
    }
}