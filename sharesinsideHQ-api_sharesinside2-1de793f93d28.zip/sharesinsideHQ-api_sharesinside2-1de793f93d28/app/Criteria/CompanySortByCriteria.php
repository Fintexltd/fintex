<?php

namespace App\Criteria;

class CompanySortByCriteria extends EntitySortByCriteria
{

}
