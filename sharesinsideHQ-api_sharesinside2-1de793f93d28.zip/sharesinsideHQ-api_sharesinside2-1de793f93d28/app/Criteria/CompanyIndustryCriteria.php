<?php

namespace App\Criteria;

use Illuminate\Support\Facades\DB;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class CompanyIndustryCriteria implements CriteriaInterface
{

    protected $industries;

    public function __construct(array $industries)
    {
        $this->industries = $industries;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereIn('industry_id', $this->industries);
        };
    }
}