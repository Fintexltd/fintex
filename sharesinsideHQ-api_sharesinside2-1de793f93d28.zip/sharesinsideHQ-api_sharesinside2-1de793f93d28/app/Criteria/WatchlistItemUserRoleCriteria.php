<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Country;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\Entities\Startup;
use App\Services\RoleResolver;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistItemUserRoleCriteria implements CriteriaInterface
{
    const INTERNAL_RELATION_TYPES = [
        RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
        RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        RelationInterface::RELATION_TYPE_VIP,
    ];

    const BUSINESS_RELATION_TYPES = [
        RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
        RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
        RelationInterface::RELATION_TYPE_VIP,
        RelationInterface::RELATION_TYPE_SHAREHOLDER,
    ];

    protected $user;
    private $relations;

    public function __construct(User $user)
    {
        $this->user = $user;
        $this->relations = $this->user->relations()->get();
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        //TODO: probably should refactor this for efficiency reasons
        return function ($query) {

            if (!RoleResolver::isGlobalAdmin($this->user) && !RoleResolver::isContentAdmin($this->user)) {
                $query->where($this->businessQuery());
            }

            $query->where($this->internalQuery());
        };
    }

    private function businessQuery()
    {
            return function ($query) {
                $query->where('is_business', false)
                    ->orWhere(function ($query) {
                        $canSeeBusinessCompanies = array_merge(
                            $this->getEntitiableIdsFromUserRelation(Company::class, self::BUSINESS_RELATION_TYPES),
                            $this->getDomesticCompanyIdsFromUserRelation()
                        );

                        $query
                            ->where('entitiable_type', Company::class)
                            ->whereIn('entitiable_id', $canSeeBusinessCompanies);
                    })
                    ->orWhere(function ($query) {
                        $canSeeBusinessStartups = $this
                            ->getEntitiableIdsFromUserRelation(Startup::class, self::BUSINESS_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', Startup::class)
                            ->whereIn('entitiable_id', $canSeeBusinessStartups);
                    })
                    ->orWhere(function ($query) {
                        $canSeeBusinessFunds = $this
                            ->getEntitiableIdsFromUserRelation(Fund::class, self::BUSINESS_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', Fund::class)
                            ->whereIn('entitiable_id', $canSeeBusinessFunds);
                    });
            };
    }

    private function internalQuery()
    {
            return function ($query) {
                $query->where('is_internal', false)
                    ->orWhere(function ($query) {
                        $canSeeInternalCompanies = $this
                            ->getEntitiableIdsFromUserRelation(Company::class, self::INTERNAL_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', Company::class)
                            ->whereIn('entitiable_id', $canSeeInternalCompanies);
                    })
                    ->orWhere(function ($query) {
                        $canSeeInternalStartups = $this
                            ->getEntitiableIdsFromUserRelation(Startup::class, self::INTERNAL_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', Startup::class)
                            ->whereIn('entitiable_id', $canSeeInternalStartups);
                    })
                    ->orWhere(function ($query) {
                        $canSeeInternalFunds = $this
                            ->getEntitiableIdsFromUserRelation(Fund::class, self::INTERNAL_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', Fund::class)
                            ->whereIn('entitiable_id', $canSeeInternalFunds);
                    })
                    ->orWhere(function ($query) {
                        $canSeeInternalFundsManagers = $this
                            ->getEntitiableIdsFromUserRelation(FundsManager::class, self::INTERNAL_RELATION_TYPES);

                        $query
                            ->where('entitiable_type', FundsManager::class)
                            ->whereIn('entitiable_id', $canSeeInternalFundsManagers);
                    });
            };
    }

    private function getEntitiableIdsFromUserRelation(string $entitiableType, array $relationTypes)
    {
        return $this->relations
            ->where('related_type', $entitiableType)
            ->whereIn('type', $relationTypes)
            ->pluck('related_id')
            ->all();
    }

    private function getDomesticCompanyIdsFromUserRelation()
    {
        $domesticInCountries = $this->relations
            ->where('type', RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN)
            ->pluck('related_id')
            ->all();

        return Company::query()
            ->whereIn('country_id', $domesticInCountries)
            ->pluck('id')
            ->all();
    }
}
