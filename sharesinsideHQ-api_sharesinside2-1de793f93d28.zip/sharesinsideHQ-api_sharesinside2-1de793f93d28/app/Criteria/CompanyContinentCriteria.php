<?php

namespace App\Criteria;

class CompanyContinentCriteria extends EntityContinentCriteria
{

}
