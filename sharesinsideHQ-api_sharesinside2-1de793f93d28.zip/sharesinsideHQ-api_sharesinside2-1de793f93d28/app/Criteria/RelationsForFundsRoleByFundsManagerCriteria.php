<?php

namespace App\Criteria;

use App\Criteria\Traits\RelationsForCriteriaTrait;
use App\Entities\Fund;
use App\Entities\FundsManager;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class RelationsForFundsRoleByFundsManagerCriteria implements CriteriaInterface
{
    use RelationsForCriteriaTrait;

    protected $fundsManager;
    protected $data;

    public function __construct(FundsManager $fundsManager, array $data)
    {
        $this->fundsManager = $fundsManager;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $fundIds = $this->fundsManager->funds ? $this->fundsManager->funds->pluck('id') : [];
            $search = array_get($data, 'search', '');
            $relations = $this->getRelations($data);
            $loginMethods = data_get($data, 'login_methods', []);

            $query = $query
                ->select('user_id')
                ->where(function ($query) use ($fundIds, $relations){
                    $query->where(function ($query) use ($fundIds, $relations){
                        $query->whereHas('fund', function($query){
                            $query->whereHas('fundsManager');
                        })
                        ->whereIn('related_id', $fundIds);

                        if ($relations) {
                            $query->whereIn('type', $relations);
                        }
                    })
                    ->orWhere(function ($query) use ( $relations){
                        $query->whereHas('fundsManager')->where('related_id', $this->fundsManager->id);

                        if ($relations) {
                            $query->whereIn('type', $relations);
                        }
                    });
                })
                ->groupBy('user_id');

            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $countries = data_get($data, 'countries', []);

            $query
                ->where(function ($query) use ($countries, $loginMethods, $search) {
                    $query->whereHas('user', function ($query) use ($countries, $loginMethods, $search) {
                        if ($countries) {
                            $query->whereIn('country_id', $countries);
                        };

                        if (in_array(User::LOGIN_METHOD_MANUAL, $loginMethods)) {
                            $query->whereNotNull('password');
                        }

                        if (in_array(User::LOGIN_METHOD_LINKEDIN, $loginMethods)) {
                            $query->whereNotNull('linkedin_id');
                        }

                        if ($search) {
                            $query->where(function ($query) use ($search) {
                                $query->where('name', 'LIKE', $search)
                                    ->orWhere('email', 'LIKE', $search);
                            });
                        }
                    });
                });

            $query->with(['user.relations' => function ($query) use ($fundIds, $relations) {
                $query
                    ->where(function ($query) use ($fundIds, $relations){
                        $query->where(function ($query) use ($fundIds, $relations){
                            $query->whereIn('related_id', $fundIds)
                            ->where('related_type', Fund::class);

                            if ($relations) {
                                $query->whereIn('type', $relations);
                            }
                        })
                        ->orWhere(function ($query) use ($relations) {
                            $query->where('related_id', $this->fundsManager->id)
                            ->where('related_type', FundsManager::class);

                            if ($relations) {
                                $query->whereIn('type', $relations);
                            }
                        });
                    })
                    ->with(['related']);
            }]);

            return $query;
        };
    }
}
