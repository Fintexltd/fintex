<?php

namespace App\Criteria;

use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;
use Carbon\Carbon;

class WatchlistSocialShareCriteria implements CriteriaInterface
{
    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query
                ->where('is_excluded', false)
                ->where('is_business', false)
                ->where('is_internal', false)
                ->where('notify_stock', false)
                ->where('is_draft', false)
                ->whereNotNull('publish_at')
                ->where('publish_at', '<=', Carbon::now()->toDateTimeString()
            );
        };
    }
}
