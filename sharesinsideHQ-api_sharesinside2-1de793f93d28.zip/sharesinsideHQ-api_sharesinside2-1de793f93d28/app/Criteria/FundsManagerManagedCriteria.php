<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use App\Entities\Fund;
use App\Entities\Relation;
use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerManagedCriteria implements CriteriaInterface
{

    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            if (!RoleResolver::isGlobalAdmin($this->user) && !RoleResolver::isContentAdmin($this->user)) {
                $managed = $this->user->relations()
                    ->where('related_type', FundsManager::class)
                    ->whereIn('type', [
                        User::RELATION_TYPE_PRIMARY_ADMIN,
                        User::RELATION_TYPE_SECONDARY_ADMIN,
                        User::RELATION_TYPE_EDITOR,
                    ])
                    ->get()
                    ->pluck('related_id')
                    ->all();

                $managedFunds = $this->user->relations()
                    ->where('related_type', Fund::class)
                    ->whereIn('type', [
                        User::RELATION_TYPE_EDITOR,
                    ])
                    ->with('related')
                    ->get()
                    ->each(function ($managedFund) use (&$managed) {
                        if(!in_array($managedFund->related->funds_manager_id, $managed)) {
                            $managed[] = $managedFund->related->funds_manager_id;
                        }
                    });

                $query
                    ->whereIn('id', $managed);
            }
        };
    }
}
