<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistAdHocCriteria implements CriteriaInterface
{
    protected $isAdHoc;

    public function __construct(int $isAdHoc)
    {
        $this->isAdHoc = $isAdHoc;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        switch ($this->isAdHoc) {
            case 0:
                $model->where(function ($query) {
                    $query->where('is_ad_hoc', $this->isAdHoc)
                        ->orWhereNull('is_ad_hoc');
                });
                break;
            case 1:
                $model->where('is_ad_hoc', $this->isAdHoc);
                break;
            default:
        }

        return $model;
    }
}