<?php

namespace App\Criteria;

class CompanyFollowedCriteria extends EntityFollowedCriteria
{

}
