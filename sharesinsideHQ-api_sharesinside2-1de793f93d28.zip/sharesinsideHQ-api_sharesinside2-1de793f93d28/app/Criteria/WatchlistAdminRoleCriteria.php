<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use App\Entities\RelationInterface;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistAdminRoleCriteria implements CriteriaInterface
{
    protected $roles;
    private $entity;

    public function __construct(array $roles, Model $entity)
    {
        $this->roles = $roles;
        $this->entity = $entity;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $allowSeeInternal = [
                RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            ];

            if (!(bool)array_intersect($allowSeeInternal, $this->roles)) {
                $query->where('is_internal', false);
            }

            if (get_class($this->entity)!=FundsManager::class) {
                $allowSeeBusiness = [
                    RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
                    RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
                    RelationInterface::RELATION_TYPE_GLOBAL_ADMIN,
                    RelationInterface::RELATION_TYPE_CONTENT_ADMIN,
                ];

                if (get_class($this->entity)==Company::class) {
                    $allowSeeBusiness[] = RelationInterface::RELATION_TYPE_DOMESTIC_ADMIN;
                }

                if (!(bool)array_intersect($allowSeeBusiness, $this->roles)) {
                    $query->where('is_business', false);
                }
            }
        };
    }
}
