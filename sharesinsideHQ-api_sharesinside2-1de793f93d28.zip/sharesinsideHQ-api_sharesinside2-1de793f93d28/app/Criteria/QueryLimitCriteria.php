<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class QueryLimitCriteria implements CriteriaInterface
{
    protected $limit;

    public function __construct(int $limit)
    {
        $this->limit = $limit;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->limit($this->limit);

        return $model;
    }
}