<?php

namespace App\Criteria;

use App\Services\DemoService;
use App\Services\RoleResolver;
use App\User;
use App\Entities\FundsManager;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundDemoCriteria implements CriteriaInterface
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        if (RoleResolver::isDemoUser($this->user)) {
            $model = $model->where($this->appendQuery());
        }

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('fundsManager', function ($query) {
                if ($this->user->name) {
                    $ids = $this
                        ->user
                        ->relations()
                        ->where('related_type', FundsManager::class)
                        ->get()
                        ->pluck('related_id')
                        ->toArray();
                } else {
                    $vipOf = DemoService::vipOf(FundsManager::class);
                    $shareholderOf = DemoService::shareholderOf(FundsManager::class);
                    $followerOf = DemoService::followerOf(FundsManager::class);

                    $ids = array_unique(array_merge($vipOf, $shareholderOf, $followerOf));
                }

                $query->whereIn('id', $ids);
            });
        };
    }
}
