<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class FundsManagerWithFundsKindOfFundsCriteria implements CriteriaInterface
{

    protected $kindOfFunds;

    public function __construct(array $kindOfFunds)
    {
        $this->kindOfFunds = $kindOfFunds;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('funds', function ($query) {
                $query->whereIn('kind_of_fund', $this->kindOfFunds);
            });
        };
    }
}
