<?php

namespace App\Criteria;

use App\Entities\FundsManager;
use App\Criteria\Traits\ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

class FundsManagerRelationCriteria extends EntityRelationCriteria
{
    use ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query
                    ->where('related_type', FundsManager::class)
                    ->whereIn('type', $this->relationArray)
                    ->where('user_id', data_get($this->user, 'id'));
            });
        };
    }
}
