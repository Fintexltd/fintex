<?php

namespace App\Criteria;

use Carbon\Carbon;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistFromCriteria implements CriteriaInterface
{
    protected $from;

    public function __construct(int $from)
    {
        $this->from = Carbon::createFromTimestamp($from);
        $this->from->setTimezone('UTC');
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where('publish_at', '>=', $this->from->toDateTimeString());

        return $model;
    }
}