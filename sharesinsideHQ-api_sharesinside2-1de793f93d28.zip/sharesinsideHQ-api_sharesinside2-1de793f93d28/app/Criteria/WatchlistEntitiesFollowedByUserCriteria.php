<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Fund;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistEntitiesFollowedByUserCriteria implements CriteriaInterface
{
    protected $userId;

    public function __construct(int $userId)
    {
        $this->userId = $userId;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('company', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');

                $query->whereHas('relations', function ($query2) {
                    $query2->where('user_id', $this->userId)
                        ->where('type', User::RELATION_TYPE_FOLLOWER);
                });
            })
            ->orWhereHas('startup', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');

                $query->whereHas('relations', function ($query2) {
                    $query2->where('user_id', $this->userId)
                        ->where('type', User::RELATION_TYPE_FOLLOWER);
                });
            })
            ->orWhereHas('fund', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');

                $query->whereHas('relations', function ($query2) {
                    $query2->where('user_id', $this->userId)
                        ->where('type', User::RELATION_TYPE_FOLLOWER);
                });

                $query->whereHas('fundsManager', function ($query3) {
                    $query3->where('is_accepted', true)->whereNull('deleted_at');
                });
            })
            ->orWhereHas('fundsManager', function ($query) {
                $query->where('is_accepted', true)->whereNull('deleted_at');

                $query->whereHas('relations', function ($query2) {
                    $query2->where('user_id', $this->userId)
                        ->where('type', User::RELATION_TYPE_FOLLOWER);
                });
            });
        };
    }
}
