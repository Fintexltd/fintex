<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class JobOfferSearchCriteria implements CriteriaInterface
{
    protected $search;

    public function __construct($search)
    {
        $sanitized = str_replace(['%', '_'], ['\%', '\_'], $search);
        $this->search = "%$sanitized%";
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->where(function ($q) {
                $q->where('title', 'LIKE', $this->search);
            });
        };
    }
}