<?php

namespace App\Criteria;

use Carbon\Carbon;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistToCriteria implements CriteriaInterface
{
    protected $to;

    public function __construct(int $from)
    {
        $this->to = Carbon::createFromTimestamp($from);
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where('publish_at', '<=', $this->to->toDateTimeString());

        return $model;
    }
}