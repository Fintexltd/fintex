<?php

namespace App\Criteria;

use App\Entities\Startup;
use App\Criteria\Traits\ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

class StartupRelationCriteria extends EntityRelationCriteria
{
    use ReplaceRelationTypeInvestorToShareholderCriteriaTrait;

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relations', function ($query) {
                $query
                    ->where('related_type', Startup::class)
                    ->whereIn('type', $this->relationArray)
                    ->where('user_id', data_get($this->user, 'id'));
            });
        };
    }
}
