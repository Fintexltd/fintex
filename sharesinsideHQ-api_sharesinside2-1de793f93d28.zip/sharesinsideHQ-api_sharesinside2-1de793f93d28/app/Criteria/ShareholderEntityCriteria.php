<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderEntityCriteria implements CriteriaInterface
{

    protected $entities;

    public function __construct(array $entities)
    {
        $this->entities = $entities;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $query->whereHas('relation', function ($query) {
                $query->whereIn('related_id', $this->entities);
            });
        };
    }
}
