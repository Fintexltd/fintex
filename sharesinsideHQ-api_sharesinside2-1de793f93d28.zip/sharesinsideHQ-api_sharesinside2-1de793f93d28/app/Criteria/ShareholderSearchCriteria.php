<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderSearchCriteria implements CriteriaInterface
{

    protected $search;

    public function __construct(string $search)
    {
        $sanitized = str_replace(['%', '_'], ['\%', '\_'], $search);

        $this->search = array_map(
            function ($item) {
                return "%$item%";
            },
            explode(' ', $sanitized)
        );
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            return array_reduce(
                $this->search,
                function ($query, $search) {
                    return $query->where(function ($query) use ($search) {
                        $query->where('first_name', 'LIKE', $search)
                            ->orWhere('last_name', 'LIKE', $search);
                    });
                }, $query)
                ->orWhereHas('relation', function ($query) {
                    $query->whereHas('user', function ($query) {
                        $query->where('email', 'LIKE', implode($this->search, ' '))
                            ->orWhere('name', 'LIKE', implode($this->search, ' '));
                    });
                });
        };
    }
}