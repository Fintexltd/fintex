<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class WatchlistEventLocationCriteria implements CriteriaInterface
{
    protected $location;

    public function __construct(?string $location)
    {
        $this->location = '%' . $location . '%';
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model->where(function ($query) {
            $query->whereHas('event', function ($query) {
                $query->where('adress', 'LIKE', $this->location)
                    ->orWhere('city', 'LIKE', $this->location);
            });
        });

        return $model;
    }
}