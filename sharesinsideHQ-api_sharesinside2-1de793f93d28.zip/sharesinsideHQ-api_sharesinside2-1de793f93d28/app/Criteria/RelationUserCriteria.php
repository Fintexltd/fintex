<?php

namespace App\Criteria;

use App\Entities\Company;
use App\Entities\Country;
use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class RelationUserCriteria implements CriteriaInterface
{
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            return $query->where('user_id', $this->user->id)
                ->where(function($query){
                    $query->whereHas('company')
                        ->orWhereHas('country');
                });
        };
    }
}