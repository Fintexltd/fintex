<?php

namespace App\Criteria;

class FundCurrenciesCriteria extends EntityCurrenciesCriteria
{
    
}
