<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class ShareholderLoginCriteria implements CriteriaInterface
{

    protected $loginMethods;

    public function __construct(array $loginMethods)
    {
        $this->loginMethods = $loginMethods;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            $criteria = new UserLoginMethodCriteria($this->loginMethods);
            $query->whereHas('relation', function ($query) use ($criteria) {
                $query->whereHas('user', $criteria->appendQuery());
            });
        };
    }
}