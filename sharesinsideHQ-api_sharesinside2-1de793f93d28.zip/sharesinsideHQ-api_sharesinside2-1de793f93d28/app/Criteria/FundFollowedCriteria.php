<?php

namespace App\Criteria;

class FundFollowedCriteria extends EntityFollowedCriteria
{

}
