<?php

namespace App\Criteria;

use App\Entities\Startup;
use App\Entities\Relation;
use App\User;
use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class StartupRelationsCriteria implements CriteriaInterface
{
    protected $user;
    protected $data;

    public function __construct(User $user, array $data)
    {
        $this->user = $user;
        $this->data = $data;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {

            $data = $this->data;
            $user = $this->user;
            $search = array_get($data, 'search', '');
            $relations = array_get($data, 'relations', [
                Relation::RELATION_TYPE_PRIMARY_ADMIN,
                Relation::RELATION_TYPE_SECONDARY_ADMIN,
                Relation::RELATION_TYPE_EDITOR,
                Relation::RELATION_TYPE_VIP,
                Relation::RELATION_TYPE_SHAREHOLDER,
                Relation::RELATION_TYPE_FOLLOWER,
            ]);

            $query = $query->where('user_id', $user->id);

            if ($search) {
                $search = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            }

            $query = $query
                ->whereHas('startup', function ($query) use ($search) {
                    if ($search) {
                        $query->where('name', 'LIKE', $search);
                    }
                });

            if ($relations) {
                $query = $query
                    ->whereIn('type', $relations);
            }

            $query = $query
                ->select('relations.*', 'startups.name')
                ->leftJoin('startups', function ($join) {
                    $join->on('relations.related_id', '=', 'startups.id')
                        ->where('relations.related_type', '=', Startup::class);
                })
                ->orderBy('startups.name');

            return $query;
        };
    }
}
