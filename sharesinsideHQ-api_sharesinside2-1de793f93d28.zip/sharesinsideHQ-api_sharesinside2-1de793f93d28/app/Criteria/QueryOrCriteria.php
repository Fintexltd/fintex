<?php

namespace App\Criteria;

use Prettus\Repository\Contracts\RepositoryInterface;
use Prettus\Repository\Contracts\CriteriaInterface;

class QueryOrCriteria implements CriteriaInterface
{

    protected $functions;

    public function __construct(array $functions)
    {
        $this->functions = $functions;
    }

    public function apply($model, RepositoryInterface $repository)
    {
        $model = $model->where($this->appendQuery());

        return $model;
    }

    public function appendQuery()
    {
        return function ($query) {
            foreach ($this->functions as $function) {
                $query->orWhere($function);
            }
        };
    }
}