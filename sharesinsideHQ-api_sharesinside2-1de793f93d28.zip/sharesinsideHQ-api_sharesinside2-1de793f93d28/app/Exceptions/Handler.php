<?php

namespace App\Exceptions;

use App\Mail\InformDeveloperAboutException;
use App\Events\SendEmailEvent;
use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];

    /**
     * Report or log an exception.
     *
     * @param  \Exception $exception
     * @return void
     */
    public function report(Exception $exception)
    {
        event(new SendEmailEvent(env('MAIL_DEVELOPER'), new InformDeveloperAboutException($exception->__toString())));

        // Kill reporting if this is an "access denied" (code 9) OAuthServerException.
        if ($exception instanceof \League\OAuth2\Server\Exception\OAuthServerException && $exception->getCode() == 9) {
            return;
        }

        parent::report($exception);
    }

    /**
     * Render an exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Exception $exception
     * @return \Illuminate\Http\Response
     */
    public function render($request, Exception $exception)
    {
        if ($exception instanceof \Illuminate\Database\Eloquent\ModelNotFoundException) {
            $model = $exception->getModel();

            return response()->json([
                'message' => $this->prepareMessage($model),
            ], 404);
        }

        return parent::render($request, $exception);
    }

    private function prepareMessage(string $modelClass)
    {
        $modelName = substr($modelClass, strrpos($modelClass, '\\') + 1);

        $array = [
            'News',
            'Event',
            'Company',
            'FundsManager',
            'Fund',
            'Startup'
        ];

        if (in_array($modelName, $array)){
            $name = lcfirst($modelName);
            $message = "The $name you're looking for was removed";
        } else {
            $message = $modelName . ' not found.';
        }

        return $message;
    }
}
