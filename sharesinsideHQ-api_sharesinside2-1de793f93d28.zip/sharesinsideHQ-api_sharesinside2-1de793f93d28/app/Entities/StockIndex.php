<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StockIndex extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'name',
        'description',
        'symbol',
        'currency',
    ];

    public function createOrUpdateIndex($index)
    {
        $result = self::where('symbol', $index['symbol'])->count();


        if ($result === 0) {
            $new = self::create($index);
        }
    }

    public function removeUnusedIndexes($list)
    {
        $result = self::whereNotIn('symbol', $list)->get();

        foreach ($result as $index) {
            $index->delete();
        }
    }
}
