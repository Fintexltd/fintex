<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class HistoricalDataPiece extends Model
{
    protected $fillable = [
        'company_id',
        'title',
//        'type',
        'fiscal_year',
        'section_id',
    ];

    public function attachment()
    {
        return $this->morphOne(Attachment::class, 'attachable');
    }
}
