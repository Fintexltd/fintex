<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class NotificationSettings extends Model
{
    protected $fillable = [
        'user_id',
        'allow_push',
        'followed_events',
        'followed_news',
        'shareholder_events',
        'shareholder_news',
        'followed_startup_events',
        'followed_startup_news',
        'investor_startup_events',
        'investor_startup_news',
        'followed_fund_events',
        'followed_fund_news',
        'investor_fund_events',
        'investor_fund_news',
        'followed_funds_manager_events',
        'followed_funds_manager_news',
        'followed_startup_projects',
        'investor_startup_projects'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
