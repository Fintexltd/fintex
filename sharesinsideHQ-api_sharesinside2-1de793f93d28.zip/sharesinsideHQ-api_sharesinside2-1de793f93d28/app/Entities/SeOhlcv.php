<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class SeOhlcv extends Model
{
    protected $fillable = [
        'se_symbol_id',
        'date',
        'open',
        'high',
        'low',
        'close',
        'volume',
        'previous_close',
        'change',
        'change_percent',
    ];

    public function seSymbol()
    {
        return $this->belongsTo(SeSymbol::class, 'se_symbol_id', 'id');
    }

}
