<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class CompanyStatisticMock extends Model
{
    protected $table = 'company_statistic_mocks';

    protected $fillable = [
        'company_id',
        'date',
        'value',
    ];
}

