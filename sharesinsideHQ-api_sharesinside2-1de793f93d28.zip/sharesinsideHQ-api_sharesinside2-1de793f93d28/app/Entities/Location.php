<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{
    //TODO: this entity, it's service and table in db is probably redundant
    public $timestamps = false;

    protected $fillable = [
        'location',
    ];

    protected $hidden = [
        'id',
    ];
}
