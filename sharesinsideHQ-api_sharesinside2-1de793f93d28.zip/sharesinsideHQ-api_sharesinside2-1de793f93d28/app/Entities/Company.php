<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Scout\Searchable;

class Company extends Model
{
    use SoftDeletes;
    use Searchable;

    public $asYouType = true;

    protected $fillable = [
        'name',
        'title',
        'description',
        'phone',
        'email',
        'country_id',
        'industry_id',
        'website',
        'adress',
        'longitude',
        'latitude',
        'is_accepted',
        'dont_allow_shareholders',
    ];

    protected $dates = ['deleted_at'];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Company $company) {
            $company->watchlistItems()->delete();
            $company->notifications()->delete();
            $company->seSymbols()->detach();
//            $logo = $company->logo;
//            if($logo){$logo->delete();}
//            $background = $company->background;
//            if($background){$background->delete();}
//            $company->links()->delete();
//            $company->attachments->each(function ($item) {
//                return $item->delete();
//            });
//            $company->socialMedia()->delete();
//            $company->sections->each(function ($item) {
//                return $item->delete();
//            });
//            $company->historicalData()->delete();
        });
    }

    /**
     * Get the indexable data array for the model.
     *
     * @return array
     */
    public function toSearchableArray()
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'title' => $this->title,
            //'description' => $this->description,
            'phone' => $this->phone,
            'email' => $this->email,
            'country' => $this->country ? $this->country->country_name : null,
            'website' => $this->website,
            'adress' => $this->adress,
        ];
    }

    public function logo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_COMPANY_LOGO);
    }

    public function background()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_COMPANY_BACKGROUND);
    }

    public function industry()
    {
        return $this->belongsTo(Industry::class, 'industry_id', 'id');
    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function links()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereNotIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FILE);
    }

    public function videos()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_VIDEO);
    }

    public function videoLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function symbols()
    {
        return $this->belongsToMany(Symbol::class, 'company_symbol', 'company_id', 'symbol_id')
            ->withPivot('is_default');
    }

    public function seSymbols()
    {
        return $this->morphToMany(SeSymbol::class, 'se_symbolable')
            ->withPivot('is_default')
            ->withTimestamps();
    }

    public function mainStockPrice()
    {
        //TODO: to consider, one could eager load symbols relation and than use this
        //      function, but condition that symbol is default must done when symbol
        //      is loaded. In order to achieve that following syntax can be used
        //      symbols => function($query){
        //          return $query->wherePivot('is_default', true);
        //      }
        //      Then following value can be replaced by this:
        //      $mainStock = $this->symbols->first();
        $mainStock = $this->symbols()->wherePivot('is_default', true)->first();

        $response = '';
        if ($mainStock) {

            $price = null;

            $date = null;

            if (!$mainStock->ohlc52->isEmpty()) {
                $date = $mainStock->ohlc52->first()->timestamp;
                $price = $mainStock->ohlc52->first()->close;
            }

            $stockFeed = $mainStock->stockFeed;
            if ($stockFeed) {
                if ($stockFeed->timestamp >= $date) {
                    $price = $stockFeed->ask;
                }
            }

            $response .= $mainStock->currency . ' ' . ($price ?? '');

        }

        return $response;
    }

    public function seMainStockPrice()
    {
        $symbol = $this->seSymbols()->wherePivot('is_default', true)->first();
        $response = '';

        if($symbol) {
            $ohlcv = $symbol->seOhlcvs()->orderByDesc('date')->first();
            $response = $symbol->currency;

            if ($ohlcv) {

                $response .= ' '.round($ohlcv->close, 2);
            }
        }

        return $response;
    }

    /*public function socialMedia()
    {
        return $this->hasMany(SocialMedia::class, 'company_id', 'id');
    }*/

    public function socialMedia()
    {
        return $this->morphMany(SocialMedia::class, 'sociable');
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notificable');
    }

    public function sections()
    {
        return $this->hasMany(Section::class, 'referenced_id', 'id')
            ->where('referenced_type', Company::class);
    }

    /*public function employees()
    {
        return $this->hasMany(Employee::class, 'company_id', 'id');
    }*/

    public function employees()
    {
        return $this->hasManyThrough(Employee::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function entityNotifications()
    {
        return $this->morphMany(EntityNotification::class, 'notificable');
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'company_user', 'company_id', 'user_id')
            ->withPivot(['type']);
    }

    public function vips()
    {
        return $this->belongsToMany(User::class, 'company_user', 'company_id', 'user_id')
            ->wherePivot('type', User::RELATION_TYPE_VIP);
    }

    public function admins()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
                User::RELATION_TYPE_EDITOR,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function primaryAndSecondary()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function followers()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivot('type', User::RELATION_TYPE_FOLLOWER)
            ->wherePivot('related_type', self::class);
    }

    public function historicalData()
    {
        return $this->hasMany(HistoricalDataPiece::class, 'company_id', 'id');
    }

    public function watchlistItems()
    {
        //return $this->hasMany(WatchlistItem::class);
        return $this->morphMany(WatchlistItem::class, 'entitiable');
    }

    public function lseAssets()
    {
        return $this->morphMany(LseAsset::class, 'entitiable');
    }

    public function demoIndividualKeys()
    {
        return $this->morphMany(DemoIndividualKey::class, 'entitiable');
    }

    public function shareholders()
    {
        return $this->hasMany(Shareholder::class);
    }

    public function viewedBy()
    {
        return $this->belongsToMany(User::class, 'company_viewer', 'company_id', 'user_id')
            ->withPivot('profile', 'news', 'events')
            ->withTrashed();
    }

    public function statistics()
    {
        return $this->hasMany(CompanyStatistic::class);
    }

    public function statisticMocks()
    {
        return $this->hasMany(CompanyStatisticMock::class);
    }

    public function excluded()
    {
        return $this->morphMany(Exclusion::class, 'excludable');
    }

    public function StockExchangeEmails()
    {
        return $this->morphMany(StockExchangeEmail::class, 'mailable');
    }

    public function relations()
    {
        return $this->hasMany(Relation::class, 'related_id', 'id')
            ->where('related_type', self::class);
    }
}
