<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class FundStatisticMock extends Model
{
    protected $table = 'fund_statistic_mocks';

    protected $fillable = [
        'fund_id',
        'date',
        'value',
    ];
}
