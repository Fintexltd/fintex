<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class EconomicSector extends Model
{
    public $timestamps = false;

    public function industry()
    {
        return $this->hasMany(Industry::class);
    }

    public function industries()
    {
        return $this->belongsToMany(Industry::class, 'economic_sector_industry', 'economic_sector_id', 'industry_id');
    }
}
