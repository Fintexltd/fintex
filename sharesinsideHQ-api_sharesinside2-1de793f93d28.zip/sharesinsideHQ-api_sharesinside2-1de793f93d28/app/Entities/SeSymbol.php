<?php

namespace App\Entities;

use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class SeSymbol extends Model
{
    protected $fillable = [
        'provider',
        'symbol',
        'name',
        'type',
        'region',
        'market_open',
        'market_close',
        'timezone',
        'currency',
        'stock_exchange_symbol',
        'stock_symbol',
        'is_valid',
        'date_symbol_check',
        'date_ohlcv_check',
    ];

    public function companies()
    {
        return $this->morphedByMany(Company::class, 'se_symbolable')
            ->withPivot('is_default')
            ->withTimestamps();
    }

    public function funds()
    {
        return $this->morphedByMany(Fund::class, 'se_symbolable')
            ->withPivot('is_default')
            ->withTimestamps();
    }

    public function fundsManagers()
    {
        return $this->morphedByMany(FundsManager::class, 'se_symbolable')
            ->withPivot('is_default')
            ->withTimestamps();
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class, 'currency_id', 'id');
    }

    public function seOhlcvs()
    {
        return $this->hasMany(SeOhlcv::class);
    }

    public function seOhlcv52()
    {
        return $this->hasMany(SeOhlcv::class)
            ->where('date', '>=', Carbon::now()->subYear()->toDateString())
            ->orderBy('date', 'desc');
    }

    public function seOhlcChart()
    {
        return $this->hasMany(SeOhlcv::class)
            ->where('date', '>', Carbon::now()->subYear()->toDateString())
            ->orderBy('date', 'asc');;
    }

    public function seCommandStacks()
    {
        return $this->hasMany(SeCommandStack::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class, 'se_symbol_user')->withTimestamps();
    }
}
