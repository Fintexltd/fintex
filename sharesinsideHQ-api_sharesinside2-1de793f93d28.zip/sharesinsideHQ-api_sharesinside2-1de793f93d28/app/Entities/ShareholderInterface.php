<?php

namespace App\Entities;

interface ShareholderInterface
{
    const STATUS_PENDING = 'pending';
    const STATUS_ACTIVE = 'active';
    const STATUS_TO_CONFIRM = 'to_confirm';

    const AVALIABLE_STATUSES = [
        self::STATUS_ACTIVE,
        self::STATUS_PENDING,
        self::STATUS_TO_CONFIRM,
    ];

    const MAX_ATTEPMTS_BEFORE_BLOCADE = 3;

}