<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    public $timestamps = false;

    public function continent()
    {
        return $this->belongsTo(Continent::class, 'continent_id', 'id');
    }

    public function countryCallingCodes()
    {
        return $this->hasMany(CountryCallingCode::class);
    }

    public function relations()
    {
        return $this->hasMany(Relation::class, 'related_id', 'id')
            ->where('related_type', self::class);
    }
}
