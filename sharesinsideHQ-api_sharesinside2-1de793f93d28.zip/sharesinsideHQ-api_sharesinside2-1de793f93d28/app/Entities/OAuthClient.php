<?php

namespace App\Entities;

use Laravel\Passport\Client;

class OAuthClient extends Client
{
    public function tokens()
    {
        return $this->hasMany(OAuthToken::class, 'client_id');
    }
}
