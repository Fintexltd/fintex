<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StartupStatisticMock extends Model
{
    protected $table = 'startup_statistic_mocks';

    protected $fillable = [
        'startup_id',
        'date',
        'value',
    ];
}
