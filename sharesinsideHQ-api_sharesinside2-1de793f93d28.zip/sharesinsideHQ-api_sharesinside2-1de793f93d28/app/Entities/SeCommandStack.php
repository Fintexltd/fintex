<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class SeCommandStack extends Model
{
    protected $fillable = [
        'se_symbol_id',
        'command',
        'args',
        'heartbeat',
        'in_process',
        'is_processed',
    ];

    public function seSymbol()
    {
        return $this->belongsTo(SeSymbol::class, 'se_symbol_id', 'id');
    }
}
