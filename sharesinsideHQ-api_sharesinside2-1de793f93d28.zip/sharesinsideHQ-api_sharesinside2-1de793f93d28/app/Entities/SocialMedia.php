<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class SocialMedia extends Model
{
    protected $fillable = [
        'url',
        'type',
        'sociable_id',
        'sociable_type'
    ];

    /*public function company()
    {
        return $this->belongsTo(Company::class, 'company_id', 'id');
    }*/

    public function sociable()
    {
        return $this->morphTo();
    }
}
