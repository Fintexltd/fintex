<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class SeExternalApiUser extends Model
{
    protected $fillable = [
        'user_id',
        'is_active',
    ];

    public function user()
    {
        return $this->hasOne(User::class);
    }
}
