<?php

namespace App\Entities;

interface PhoneInterface
{
    const ALLOWED_PHONE_NON_DIGIT_CHARS_WITHOUT_LEADING_PLUS = [
        ' ',
        '-',
        '(',
        ')',
    ];
}
