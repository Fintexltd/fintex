<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StockExchangeEmail extends Model
{
    protected $fillable = [
        'email',
        'mailable_id',
        'mailable_type',
    ];

    public function mailable()
    {
        return $this->morphTo();
    }
}
