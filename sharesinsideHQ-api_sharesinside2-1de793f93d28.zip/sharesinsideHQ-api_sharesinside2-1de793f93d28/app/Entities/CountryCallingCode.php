<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class CountryCallingCode extends Model
{
    public $timestamps = false;

    protected $hidden = [
        'id',
        'country_id',
    ];

    public function country()
    {
        return $this->belongsTo(Country::class);
    }
}
