<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Continent extends Model
{
    public $timestamps = false;

    public function countries()
    {
        return $this->hasMany(Country::class, 'continent_id', 'id');
    }
}