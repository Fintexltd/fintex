<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class OAuthRefreshToken extends Model
{
    protected $table = 'oauth_refresh_tokens';

    protected $dates = [
        'expires_at',
    ];

    public $incrementing = false;

    protected $casts = [
        'revoked' => 'bool',
    ];

    public function token()
    {
        return $this->hasOne(OAuthToken::class, 'id', 'access_token_id');
    }
}
