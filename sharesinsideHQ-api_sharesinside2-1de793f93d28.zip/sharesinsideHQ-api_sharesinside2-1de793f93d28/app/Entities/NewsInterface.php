<?php

namespace App\Entities;

interface NewsInterface
{
    const MIN_TIME_BEFORE_PUBLISH_WHEN_INFORM_STOCK_EXCHANGE_IN_MINUTES = 30;
}