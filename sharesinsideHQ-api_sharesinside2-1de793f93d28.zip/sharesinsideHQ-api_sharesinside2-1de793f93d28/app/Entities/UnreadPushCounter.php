<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class UnreadPushCounter extends Model
{
    protected $primaryKey = 'user_id';

    protected $fillable = [
        'user_id',
        'last_seen',
        'counter',
    ];

    public $timestamps = false;

    protected $dates = [
        'last_seen',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
