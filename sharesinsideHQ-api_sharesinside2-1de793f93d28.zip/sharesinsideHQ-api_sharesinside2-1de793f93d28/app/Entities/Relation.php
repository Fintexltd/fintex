<?php

namespace App\Entities;

use App\User;
use App\Entities\Fund;
use App\Entities\FundsManager;
use Illuminate\Database\Eloquent\Model;

class Relation extends Model implements RelationInterface
{
    public $fillable = [
        'user_id',
        'related_id',
        'related_type',
        'type',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function related()
    {
        return $this->morphTo();
    }

    public function shareholder()
    {
        return $this->hasOne(Shareholder::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class, 'related_id', 'id')
            ->where('related_type', Company::class);
    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'related_id', 'id')
            ->where('related_type', Country::class);
    }

    public function fundsManager()
    {
        return $this->belongsTo(FundsManager::class, 'related_id', 'id')
            ->where('related_type', FundsManager::class);
    }

    public function fund()
    {
        return $this->belongsTo(Fund::class, 'related_id', 'id')
            ->where('related_type', Fund::class);
    }

    public function startup()
    {
        return $this->belongsTo(Startup::class, 'related_id', 'id')
            ->where('related_type', Startup::class);
    }
}
