<?php

namespace App\Entities;

use App\Services\AttachmentsCreator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\URL;

class Attachment extends Model
{
    const ATTACHMENT_ENTITIABLE_TYPES = [
        Company::class => 'companies',
        Startup::class => 'startups',
        Fund::class => 'funds',
        FundsManager::class => 'fundsmanagers',
        LseAsset::class => 'lseassets',
    ];

    protected $fillable = [
        'oryginal_name',
        'path',
        'mime_type',
        'attachable_id',
        'attachable_type',
        'type',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Attachment $attachment) {
            $path = storage_path('app/' . $attachment->getPath());
            if (file_exists($path)) {
                unlink($path);
            }
        });
    }

    public function attachable()
    {
        return $this->morphTo();
    }

    public function getPath(?string $attachableType = null)
    {
        $attachableType = $attachableType ?? $this->attachable_type;

        switch ($attachableType) {
            case Company::class:
                $companyId = $this->attachable_id;
                $basePath = "companies/$companyId/";
                break;
            case Startup::class:
                $startupId = $this->attachable_id;
                $basePath = "startups/$startupId/";
                break;
            case FundsManager::class:
                $fundsManagerId = $this->attachable_id;
                $basePath = "fundsmanagers/$fundsManagerId/";
                break;
            case Fund::class:
                $fundId = $this->attachable_id;
                $basePath = "funds/$fundId/";
                break;
            case LseAsset::class:
                $lseAssetId = $this->attachable_id;
                $basePath = "lseassets/$lseAssetId/";
                break;
            case WatchlistItem::class:
                $attachable = $this->attachable;
                //$companyId = data_get($attachable, 'company_id');
                //$fundId = data_get($attachable, 'fund_id');
                $entitiableType = data_get($attachable, 'entitiable_type');
                $entitiableId = data_get($attachable, 'entitiable_id');

                switch (data_get($attachable, 'watchlistable_type')) {
                    case News::class:
                        $type = 'news';
                        break;
                    case Event::class:
                        $type = 'events';
                        break;
                    case Project::class:
                        $type = 'projects';
                        break;
                }

                //$type = data_get($attachable, 'watchlistable_type') === News::class ? 'news' : 'events';
                $id = data_get($attachable, 'watchlistable_id');
                //$basePath = $companyId ? "companies/$companyId/$type/$id/" : "funds/$fundId/$type/$id/";
                $basePath = self::ATTACHMENT_ENTITIABLE_TYPES[$entitiableType]."/$entitiableId/$type/$id/";
                break;
            case Link::class:
                $attachable = $this->attachable;
                $linkable = $attachable->linkable;

                if (get_class($attachable->linkable)==WatchlistItem::class) {
                    $entitiableType = data_get($linkable, 'entitiable_type');
                    $entitiableId = data_get($linkable, 'entitiable_id');

                    switch (data_get($linkable, 'watchlistable_type')) {
                        case News::class:
                            $type = 'news';
                            break;
                        case Event::class:
                            $type = 'events';
                            break;
                        case Project::class:
                            $type = 'projects';
                            break;
                        default:
                            $type = null;
                    }

                    $id = data_get($linkable, 'watchlistable_id');
                } else {
                    $entitiableType = data_get($attachable, 'linkable_type');
                    $entitiableId = data_get($attachable, 'linkable_id');
                }

                $basePath = self::ATTACHMENT_ENTITIABLE_TYPES[$entitiableType]."/$entitiableId/".(isset($type, $id) ? "$type/$id/" : "");
                break;
            case Employee::class:
                //$companyId = data_get($this->attachable, 'company_id');
                //$basePath = "companies/$companyId/employees/";;
                $section = $this->attachable->section;
                $entitiableType = data_get($section, 'referenced_type');
                $entitiableId = data_get($section, 'referenced_id');
                $basePath = self::ATTACHMENT_ENTITIABLE_TYPES[$entitiableType]."/$entitiableId/employees/";
                break;
            case SectionItem::class:
                /*$sectionId = $this->attachable->section->id;
                $companyId = Section::find($sectionId)->referenced_id;
                $basePath = "companies/$companyId/gallery/$sectionId/";*/
                $section = $this->attachable->section;
                $entitiableType = data_get($section, 'referenced_type');
                $entitiableId = data_get($section, 'referenced_id');
                $basePath = self::ATTACHMENT_ENTITIABLE_TYPES[$entitiableType]."/$entitiableId/gallery/$section->id/";
                break;
            case HistoricalDataPiece::class:
                $companyId = data_get($this->attachable, 'company_id');
                $basePath = "companies/" . $companyId . "/historical/";
                break;
            case Document::class:
                $section = $this->attachable->section;
                $entitiableType = data_get($section, 'referenced_type');
                $entitiableId = data_get($section, 'referenced_id');
                $basePath = self::ATTACHMENT_ENTITIABLE_TYPES[$entitiableType]."/$entitiableId/documents/";
                break;
            case self::class:
            case Config::class:
                $basePath = "public/";
                break;
            case SecurityToken::class:
                $basePath = AttachmentsCreator::UPLOAD_FILES_DIRECTORY . '/';
                break;
            default:
                $basePath = 'companies/';
        }

        return $basePath . $this->path;
    }

    public function getUrl()
    {
        return URL::to($this->getPath());
    }

    public function thumbnail()
    {
        return $this->morphOne(Attachment::class, 'attachable');
    }
}
