<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;

class LseAsset extends Model
{
    protected $fillable = [
        'entitiable_type',
        'entitiable_id',
        'issuer_identifier',
        'name',
        'lse_profile',
        'website',
        'isin',
        'category',
        'additional_data',
        'info',
        'alldata',
        'profile',
        'is_accepted',
        'is_rejected',
    ];

    protected $casts = [
        'additional_data' => 'array',
        'info' => 'array',
        'alldata' => 'array',
        'profile' => 'array',
    ];

    public function lseLivestreams()
    {
        return $this->hasMany(LseLivestream::class, 'lse_asset_id', 'id');
    }

    public function company()
    {
        return $this
            ->belongsTo(Company::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Company::class)
            ->withTrashed();
    }

    public function startup()
    {
        return $this
            ->belongsTo(Startup::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Startup::class)
            ->withTrashed();
    }

    public function fund()
    {
        return $this
            ->belongsTo(Fund::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Fund::class)
            ->withTrashed();
    }

    public function fundsManager()
    {
        return $this
            ->belongsTo(FundsManager::class, 'entitiable_id', 'id')
            ->where('entitiable_type', FundsManager::class)
            ->withTrashed();
    }

    public function logo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_LSEASSET_LOGO);
    }

    public function background()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_LSEASSET_BACKGROUND);
    }

    public function videoLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function socialMedia()
    {
        return $this->morphMany(SocialMedia::class, 'sociable');
    }
}
