<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\User;
use App\Entities\StartupCategory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Startup extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'country_id',
        'currency_id',
        'name',
        'phone',
        'email',
        'website',
        'address',
        'longitude',
        'latitude',
        'title',
        'description',
        'raised_amount',
        'is_equity',
        'is_fund',
        'is_accepted',
        'dont_allow_shareholders',
        'views',
    ];

    protected $dates = ['deleted_at'];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Startup $startup) {
            $startup->watchlistItems()->delete();
            $startup->notifications()->delete();
        });
    }

    public function logo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_STARTUP_LOGO);
    }

    public function background()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_STARTUP_BACKGROUND);
    }

    public function continent()
    {
        return $this->belongsTo(Continent::class, 'continent_id', 'id');
    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class, 'currency_id', 'id');
    }

    public function entityNotifications()
    {
        return $this->morphMany(EntityNotification::class, 'notificable');
    }

    public function links()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereNotIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FILE);
    }

    public function videos()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_VIDEO);
    }

    public function videoLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function socialMedia()
    {
        return $this->morphMany(SocialMedia::class, 'sociable');
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notificable');
    }

    public function admins()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
                User::RELATION_TYPE_EDITOR,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function primaryAndSecondary()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function followers()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivot('type', User::RELATION_TYPE_FOLLOWER)
            ->wherePivot('related_type', self::class);
    }

    public function startupCategories()
    {
        return $this->belongsToMany(StartupCategory::class, 'startup_startup_category')->withTimestamps();
    }

    public function watchlistItems()
    {
        return $this->morphMany(WatchlistItem::class, 'entitiable');
    }

    public function lseAssets()
    {
        return $this->morphMany(LseAsset::class, 'entitiable');
    }

    public function demoIndividualKeys()
    {
        return $this->morphMany(DemoIndividualKey::class, 'entitiable');
    }

    /*public function sections()
    {
        return $this->hasMany(Section::class, 'referenced_id', 'id')
            ->where('referenced_type', Startup::class);
    }*/

    public function sections()
    {
        return $this->morphMany(Section::class, 'referenced');
    }

    public function employees()
    {
        return $this->hasManyThrough(Employee::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function documents()
    {
        return $this->hasManyThrough(Document::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function excluded()
    {
        return $this->morphMany(Exclusion::class, 'excludable');
    }

    public function relations()
    {
        return $this->hasMany(Relation::class, 'related_id', 'id')
            ->where('related_type', self::class);
    }

    public function viewedBy()
    {
        return $this->belongsToMany(User::class, 'startup_viewer', 'startup_id', 'user_id')
            ->withPivot('profile', 'news', 'events')
            ->withTrashed();
    }

    public function statisticMocks()
    {
        return $this->hasMany(StartupStatisticMock::class);
    }
}
