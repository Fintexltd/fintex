<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class CompanyStatistic extends Model
{
    protected $fillable = [
        'company_id',
        'date',
        'value',
    ];
}
