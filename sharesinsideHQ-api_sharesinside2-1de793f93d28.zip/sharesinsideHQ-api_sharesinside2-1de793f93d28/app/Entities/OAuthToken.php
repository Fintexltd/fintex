<?php

namespace App\Entities;

use Laravel\Passport\Token;
use Carbon\Carbon;

class OAuthToken extends Token
{
    protected $dates = [
        'expires_at',
        'created_at',
        'updated_at'
    ];

    public function scopeActive($query)
    {
        return $query->where('revoked', 0)->where('expires_at', '>', Carbon::now());
    }

    public function refreshToken()
    {
        return $this->hasOne(OAuthRefreshToken::class, 'access_token_id', 'id');
    }
}
