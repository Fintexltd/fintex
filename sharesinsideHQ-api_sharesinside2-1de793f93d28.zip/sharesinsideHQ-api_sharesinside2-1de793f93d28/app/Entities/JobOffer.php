<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class JobOffer extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'country_id',
        'title',
        'address',
        'description',
        'responsibilities',
        'offers',
    ];

    public function country()
    {
        return $this->belongsTo(Country::class);
    }
}
