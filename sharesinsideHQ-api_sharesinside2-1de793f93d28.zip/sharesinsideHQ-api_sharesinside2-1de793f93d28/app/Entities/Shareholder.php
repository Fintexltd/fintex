<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Shareholder extends Model implements ShareholderInterface
{
    protected $fillable = [
        'first_name',
        'last_name',
        'phone_number',
        'birth_date',
        'address',
        'post_code',
        'city',
        'country_id',
        'relation_id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function fund()
    {
        return $this->belongsTo(Fund::class);
    }

    public function startup()
    {
        return $this->belongsTo(Startup::class);
    }

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function getStatus()
    {
        switch ($this->relation->type) {
            case Relation::RELATION_TYPE_SHAREHOLDER:
                return self::STATUS_ACTIVE;
            case Relation::RELATION_TYPE_SHAREHOLDER_PENDING:
                return self::STATUS_PENDING;
            case Relation::RELATION_TYPE_SHAREHOLDER_TO_CONFIRM:
                return self::STATUS_TO_CONFIRM;
        }
//
//        if (!$this->is_accepted) {
//            return self::STATUS_PENDING;
//        }
//
//        if ($this->is_confirmed) {
//            return self::STATUS_ACTIVE;
//        }
//
//        return self::STATUS_TO_CONFIRM;
    }

    public function relation()
    {
        return $this->belongsTo(Relation::class);
    }

    public function shareholderCode()
    {
        return $this->hasOne(ShareholderCode::class);
    }
}
