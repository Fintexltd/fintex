<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Symbol extends Model
{
    public function companies()
    {
        return $this->belongsToMany(Company::class, 'company_symbol', 'symbol_id', 'company_id')
            ->withPivot('is_default');
    }

    public function stockOhlcYear()
    {
        return $this->hasMany(StockOhlc::class, 'symbol_list_id', 'id')
            ->where('timestamp', '>', Carbon::now()->subYear()->toDateString());
    }

    public function ohlc52()
    {
        return $this->hasMany(StockOhlc::class, 'symbol_list_id', 'id')
            ->where('timestamp', '>=', Carbon::now()->subYear()->toDateString())
            ->orderBy('timestamp', 'desc');
    }

    public function stockFeed()
    {
        return $this->hasOne(StockFeed::class, 'symbol_list_id', 'id')
            ->where('timestamp', '>=', Carbon::now()->subYear()->timestamp)
            ->latest('timestamp');
    }
}
