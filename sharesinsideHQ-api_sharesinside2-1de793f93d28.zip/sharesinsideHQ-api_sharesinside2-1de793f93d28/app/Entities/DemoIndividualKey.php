<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class DemoIndividualKey extends Model
{
    protected $fillable = [
        'user_id',
        'entitiable_type',
        'entitiable_id',
        'key'
    ];

    public function entitiable()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function company()
    {
        return $this
            ->belongsTo(Company::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Company::class)
            ->withTrashed();
    }

    public function startup()
    {
        return $this
            ->belongsTo(Startup::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Startup::class)
            ->withTrashed();
    }

    public function fundsManager()
    {
        return $this
            ->belongsTo(FundsManager::class, 'entitiable_id', 'id')
            ->where('entitiable_type', FundsManager::class)
            ->withTrashed();
    }
}
