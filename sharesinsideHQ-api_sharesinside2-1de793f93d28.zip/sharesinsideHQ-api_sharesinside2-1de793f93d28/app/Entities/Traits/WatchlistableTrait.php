<?php

namespace App\Entities\Traits;

use App\Entities\RelationInterface;
use App\Services\RoleResolver;
use App\User;

trait WatchlistableTrait
{
    public function getSharedTypes(?User $user)
    {
        if(!$user) {
            return [];
        }

        $roles = [
            RelationInterface::RELATION_TYPE_PRIMARY_ADMIN,
            RelationInterface::RELATION_TYPE_SECONDARY_ADMIN,
            RelationInterface::RELATION_TYPE_EDITOR,
        ];

        $entity = $this->watchlistItem->entitiable;

        $userRoles = RoleResolver::getRoles($user, $entity);

        if (!array_intersect($roles, $userRoles)) {
            return [];
        }

        return $this->shares()
            ->whereHas('user', function ($query) use ($entity) {
                $query
                    ->whereHas('relations', function ($query) use ($entity) {
                        $query
                            ->where('related_type', get_class($entity))
                            ->where('related_id', $entity->id);
                    });
            })
            ->get()
            ->pluck('type')
            ->unique()
            ->all();
    }
}
