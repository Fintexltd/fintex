<?php

namespace App\Entities;

interface RelationInterface
{
    const RELATION_TYPE_FOLLOWER = 'follower';

    const RELATION_TYPE_SHAREHOLDER = 'shareholder';
    const RELATION_TYPE_SHAREHOLDER_PENDING = 'shareholder_pending';
    const RELATION_TYPE_SHAREHOLDER_TO_CONFIRM = 'shareholder_to_confirm';

    const RELATION_TYPE_INVESTOR = 'investor';

    const RELATION_TYPE_VIP = 'vip';
    const RELATION_TYPE_BLOCKED = 'blocked';

    const RELATION_TYPE_GLOBAL_ADMIN = 'global_admin';
    const RELATION_TYPE_DOMESTIC_ADMIN = 'domestic_admin';
    const RELATION_TYPE_CONTENT_ADMIN = 'content_admin';

    const RELATION_TYPE_PRIMARY_ADMIN = 'primary_admin';
    const RELATION_TYPE_SECONDARY_ADMIN = 'secondary_admin';
    const RELATION_TYPE_EDITOR = 'editor';

    const RELATION_TYPE_BLOCK_AS_SHAREHOLDER = 'block_as_shareholder';
}
