<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StockOhlc extends Model
{
    protected $fillable = [
        'symbol',
        'timestamp',
        'open',
        'close',
        'high',
        'low',
        'symbol_list_id',
    ];

    protected $dates = [
        'timestamp',
    ];
}
