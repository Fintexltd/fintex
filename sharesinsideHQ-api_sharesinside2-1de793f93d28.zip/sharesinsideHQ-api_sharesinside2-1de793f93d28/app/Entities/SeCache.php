<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class SeCache extends Model
{
    protected $fillable = [
        'key',
        'value',
    ];

}
