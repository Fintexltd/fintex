<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class SectionItem extends Model
{
    protected $fillable = [
        'description',
        'section_id',
    ];

    protected $touches = ['section'];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (SectionItem $item) {
            $item->file->delete();
        });
    }

    public function file()
    {
        return $this->morphOne(Attachment::class, 'attachable');
    }

    public function section()
    {
        return $this->belongsTo(Section::class);
    }
}
