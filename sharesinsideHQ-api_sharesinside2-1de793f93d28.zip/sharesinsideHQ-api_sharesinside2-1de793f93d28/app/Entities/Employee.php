<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'section_id',
        'company_id',
        'name',
        'position',
        'description',
        'email',
        'phone_number',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Employee $entity) {
            $photo = $entity->photo;
            if($photo){$photo->delete();}
            $attachment = $entity->attachment;
            if($attachment){$attachment->delete();}
        });
    }

    public function section()
    {
        return $this->belongsTo(Section::class, 'section_id', 'id');
    }

    public function photo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_IMAGE);
    }

    public function attachment()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FILE);
    }
}
