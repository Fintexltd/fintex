<?php

namespace App\Entities;

use App\Entities\Traits\WatchlistableTrait;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use WatchlistableTrait;

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $fillable = [
        'title',
        'description',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Project $project) {
            $project->watchlistItem->delete();
        });

        static::created(function (Project $project) {
            WatchlistItem::create([
                'watchlistable_id' => $project->id,
                'watchlistable_type' => self::class,
            ]);
        });
    }

    public function watchlistItem()
    {
        return $this->morphOne(WatchlistItem::class, 'watchlistable');
    }

    public function reminder()
    {
        return $this->morphOne(Reminder::class, 'remindable');
    }

    /*public function shares()
    {
        return $this->hasMany(Share::class);
    }*/

    public function shares()
    {
        return $this->morphMany(Share::class, 'shareable');
    }
}
