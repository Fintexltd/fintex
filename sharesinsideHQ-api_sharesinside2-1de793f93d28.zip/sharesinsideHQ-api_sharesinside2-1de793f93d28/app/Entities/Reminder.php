<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Reminder extends Model
{
    protected $fillable = [
        'news_id',
        'user_id',
        'remindable_id',
        'remindable_type',
        'remind',
        'remind_at',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'remind_at',
    ];

    public function remindable()
    {
        return $this->morphTo();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /*public function news()
    {
        return $this->belongsTo(News::class);
    }*/

    public function news()
    {
        return $this
            ->belongsTo(News::class, 'remindable_id', 'id')
            ->where('remindable_type', News::class);
    }

    public function event()
    {
        return $this
            ->belongsTo(Event::class, 'remindable_id', 'id')
            ->where('remindable_type', Event::class);
    }

    public function project()
    {
        return $this
            ->belongsTo(Project::class, 'remindable_id', 'id')
            ->where('remindable_type', Project::class);
    }
}
