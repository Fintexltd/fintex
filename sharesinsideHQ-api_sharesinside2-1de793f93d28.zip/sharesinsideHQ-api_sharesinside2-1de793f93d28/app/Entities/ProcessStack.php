<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class ProcessStack extends Model
{
    protected $fillable = [
        'name',
        'args',
        'heartbeat',
        'command',
    ];
}
