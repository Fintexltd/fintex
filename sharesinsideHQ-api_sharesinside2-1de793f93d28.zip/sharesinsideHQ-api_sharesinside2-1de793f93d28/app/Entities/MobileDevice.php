<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class MobileDevice extends Model
{
    const MOBILE_DEVICE_ANDROID = 'Android';
    const MOBILE_DEVICE_IOS = 'iOS';

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}