<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Section extends Model implements SectionInterface
{
    protected $fillable = [
        'name',
        'referenced_id',
        'referenced_type',
        'order',
        'type',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Section $section) {
            $section->employees->each(function ($item) {
                return $item->delete();
            });
            $section->items->each(function ($item) {
                return $item->delete();
            });
            $section->documents->each(function ($item) {
                return $item->touch();
            });
        });
    }

    public function employees()
    {
        return $this->hasMany(Employee::class, 'section_id', 'id');
    }

    public function historicalDataPiece()
    {
        return $this->hasMany(HistoricalDataPiece::class, 'section_id', 'id');
    }

    public function documents()
    {
        return $this->hasMany(Document::class, 'section_id', 'id');
    }

    public function items()
    {
        return $this->hasMany(SectionItem::class, 'section_id', 'id')->orderBy('created_at', 'desc');
    }

    public function referenced()
    {
        return $this->morphTo();
    }
}
