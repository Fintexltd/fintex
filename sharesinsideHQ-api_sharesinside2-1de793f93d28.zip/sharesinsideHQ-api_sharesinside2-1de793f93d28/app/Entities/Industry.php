<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Industry extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'name',
        'sort_order',
        'economic_sector_id',
    ];

    protected $hidden = [
        'sort_order',
    ];

    public function economicSector()
    {
        return $this->belongsTo(EconomicSector::class, 'economic_sector_id', 'id');
    }

    public function economicSectors()
    {
        return $this->belongsToMany('App\Entities\EconomicSector', 'economic_sector_industry', 'industry_id', 'economic_sector_id');
    }

    public function companies()
    {
        return $this->hasMany(Company::class, 'industry_id', 'id');
    }
}
