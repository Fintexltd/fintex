<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'symbol',
        'name',
        'sort_order'
    ];

    protected $hidden = [
        'sort_order',
    ];

    public function funds()
    {
        return $this->hasMany(Fund::class, 'currency_id', 'id');
    }

    public function seSymbols()
    {
        return $this->hasMany(SeSymbol::class, 'currency_id', 'id');
    }
}
