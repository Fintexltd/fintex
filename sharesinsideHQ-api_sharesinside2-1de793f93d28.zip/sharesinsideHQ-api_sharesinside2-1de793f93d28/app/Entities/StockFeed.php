<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StockFeed extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'symbol',
        'index_id',
        'bid',
        'ask',
        'timestamp',
        'symbol_list_id',
    ];

    protected $dates = [
        'timestamp',
    ];

//    public function getFeed($provider)
//    {
//        $this->getEntityManager()->flush();
//        $this->getEntityManager()->clear();
//        /** @var SymbolList[] $indexes */
//        $indexes = $this->getEntityManager()->getRepository(SymbolList::class)->getIndexes($provider);
//
//        $result = [];
//        foreach($indexes as $index) {
//            $row = [
//                'symbol' => $index->getSymbol(),
//                'name' => $index->getName(),
//                'description' => $index->getDescription(),
//                'currency' => $index->getCurrency(),
//                'date' => null,
//                'now_ask' => null,
//                'now_bid' => null,
//                'yesterday_ask' => null,
//                'yesterday_bid' => null,
//                'lastMonth_ask' => null,
//                'lastMonth_bid' => null,
//                'dailyPercentualChange' => null,
//                'monthlyPercentualChange' => null,
//            ];
//            $now = $this->getNow($index->getSymbol());
//            if ($now) {
//                $row['date'] = $now->getTimestamp()->format(DATE_ISO8601);
//                $row['now_ask'] = $now->getAsk();
//                $row['now_bid'] = $now->getBid();
//            }
//            $timestamp = $now ? $now->getTimestamp() : new \DateTime;
//
//            $yesterday = $this->getYesterday($index, $timestamp);
//            if ($yesterday) {
//                $row['yesterday_date'] = $yesterday->getTimestamp()->format(DATE_ISO8601);
//                $row['yesterday_ask'] = $yesterday->getClose();
//                $row['yesterday_bid'] = $yesterday->getClose();
//                $row['dailyPercentualChange'] = $this->getDailyChange($row, 'ask');
//            }
//
//            $lastMonth = $this->getLastMonth($index);
//            if ($lastMonth) {
//                $row['lastMonth_ask'] = $lastMonth->getClose();
//                $row['lastMonth_bid'] = $lastMonth->getClose();
//                $row['monthlyPercentualChange'] = $this->getMonthlyChange($row, 'ask');
//            }
//            $result[] = $row;
//        }
//
//        return $result;
//    }

    /**
     * @param $symbol
     * @return StockFeed|null
     */
    private function getNow($symbol)
    {
        $now = (new \DateTime);

        $result = self::where('symbol', $symbol)
            ->where('timestamp', '<', $now)
            ->orderBy('timestamp', 'desc')
            ->first();

        return $result;
    }

    public function getSymbol($symbol)
    {
        return $this->getNow($symbol);
    }

//    /**
//     * @param $symbol
//     * @return StockOhlc|null
//     */
//    private function getYesterday(SymbolList $symbol, \DateTime $current)
//    {
//        $yesterday = clone $current;
//        $yesterday->modify('-1day');
//        $qb = $this->getEntityManager()->createQueryBuilder()
//            ->select('o')
//            ->from(StockOhlc::class, 'o')
//            ->where('o.symbol = :symbol')
//            ->andWhere('o.timestamp <= :yesterday')
//            ->orderBy('o.timestamp', 'DESC')
//            ->setParameter('symbol', $symbol->getSymbol())
//            ->setParameter('yesterday', $yesterday)
//            ->setMaxResults(1);
//
//        $result = $qb->getQuery()->getResult();
//
//        if (!empty($result)) {
//            return $result[0];
//        }
//
//        return null;
//    }
//
//    /**
//     * @param $symbol
//     * @return StockOhlc|null
//     */
//    private function getLastMonth(SymbolList $symbol)
//    {
//        $lastMonth = (new \DateTime)->modify('-30day');
//
//        $qb = $this->getEntityManager()->createQueryBuilder()
//            ->select('o')
//            ->from(StockOhlc::class, 'o')
//            ->where('o.symbol = :symbol')
//            ->andWhere('o.timestamp <= :yesterday')
//            ->orderBy('o.timestamp', 'DESC')
//            ->setParameter('symbol', $symbol->getSymbol())
//            ->setParameter('yesterday', $lastMonth)
//            ->setMaxResults(1);
//
//        $result = $qb->getQuery()->getResult();
//
//        if (empty($result)) {
//            $qb = $this->getEntityManager()->createQueryBuilder()
//                ->select('o')
//                ->from(StockOhlc::class, 'o')
//                ->where('o.symbol = :symbol')
//                ->andWhere('o.timestamp > :yesterday')
//                ->orderBy('o.timestamp', 'DESC')
//                ->setParameter('symbol', $symbol->getSymbol())
//                ->setParameter('yesterday', $lastMonth)
//                ->setMaxResults(1);
//
//            $result = $qb->getQuery()->getResult();
//        }
//        if (!empty($result)) {
//            return $result[0];
//        }
//
//        return null;
//    }
//
//    private function getDailyChange($row, $type)
//    {
//        $percent = null;
//
//        if ($row['now_'.$type] && $row['yesterday_'.$type]) {
//            $diff = $row['now_'.$type] - $row['yesterday_'.$type];
//            $percent = ($diff * 100) / $row['yesterday_'.$type];
//        }
//
//        return $percent;
//    }
//
//    private function getMonthlyChange($row, $type)
//    {
//        $percent = null;
//
//        if ($row['now_'.$type] && $row['lastMonth_'.$type]) {
//            $diff = $row['now_'.$type] - $row['lastMonth_'.$type];
//            $percent = ($diff * 100) / $row['lastMonth_'.$type];
//        }
//
//        return $percent;
//    }
}
