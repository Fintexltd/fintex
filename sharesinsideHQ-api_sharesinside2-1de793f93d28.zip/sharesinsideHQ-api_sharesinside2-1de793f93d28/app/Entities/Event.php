<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $dates = [
        'created_at',
        'updated_at',
        'event_date',
    ];

    protected $fillable = [
//        'company_id',
        'title',
        'description',
        'thirdparty_content',
        'event_date',
        'timezone_id',
        'event_timestamp',
        'city',
        'adress',
        'longitude',
        'latitude',
        'country_id',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Event $event) {
            $event->watchlistItem->delete();
        });

        static::created(function (Event $event) {
            WatchlistItem::create([
                'watchlistable_id' => $event->id,
                'watchlistable_type' => self::class,
            ]);
        });
    }

//    public function company()
//    {
//        return $this->belongsTo(Company::class, 'company_id', 'id');
//    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function attachments()
    {
        return $this->watchlistItem->attachments();
    }

    public function links()
    {
        return $this->watchlistItem->links();
    }

    public function viewCounter()
    {
        return $this->watchlistItem->viewCounter();
    }

    public function getPublishedTimestamp()
    {
        return $this->publish_at ? $this->publish_at->timestamp : null;
    }

    public function watchlistItem()
    {
        return $this->morphOne(WatchlistItem::class, 'watchlistable');
    }

    public function reminder()
    {
        return $this->morphOne(Reminder::class, 'remindable');
    }
}
