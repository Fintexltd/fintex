<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{
    protected $fillable = [
        'name',
        'url',
        'linkable_id',
        'linkable_type',
        'type',
    ];

    public function linkable()
    {
        return $this->morphTo();
    }

    public function getUrl()
    {
        return $this->url;
    }

    public function thumbnail()
    {
        return $this->morphOne(Attachment::class, 'attachable');
    }
}
