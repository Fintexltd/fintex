<?php

namespace App\Entities;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class ShareholderCode extends Model
{
    protected $fillable = [
        'code',
        'expires_at',
        'delete_at',
        'attempt_counter',
        'shareholder_id',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'expires_at',
        'delete_at',
    ];

    protected $attributes = [
        'attempt_counter' => 0,
    ];

    public function shareholder()
    {
        return $this->belongsTo(Shareholder::class);
    }
}
