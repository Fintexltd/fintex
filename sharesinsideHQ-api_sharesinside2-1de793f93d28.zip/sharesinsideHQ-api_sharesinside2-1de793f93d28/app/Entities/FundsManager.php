<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class FundsManager extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'title',
        'description',
        'phone',
        'email',
        'country_calling_code_id',
        'website',
        'address',
        'longitude',
        'latitude',
        'is_accepted',
        'views',
    ];

    protected $dates = ['deleted_at'];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (FundsManager $fundsManager) {
            $fundsManager->watchlistItems()->delete();
            $fundsManager->notifications()->delete();
//            $logo = $company->logo;
//            if($logo){$logo->delete();}
//            $background = $company->background;
//            if($background){$background->delete();}
//            $company->links()->delete();
//            $company->attachments->each(function ($item) {
//                return $item->delete();
//            });
//            $company->socialMedia()->delete();
//            $company->sections->each(function ($item) {
//                return $item->delete();
//            });
//            $company->historicalData()->delete();
        });

       static::bootSoftDeletes();
    }

    public function logo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FUNDS_MANAGER_LOGO);
    }

    public function background()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FUNDS_MANAGER_BACKGROUND);
    }

    public function countryCallingCode()
    {
        return $this->belongsTo(CountryCallingCode::class, 'country_calling_code_id', 'id');
    }

    public function entityNotifications()
    {
        return $this->morphMany(EntityNotification::class, 'notificable');
    }

    public function links()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereNotIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
                LinkRepository::TYPE_TERMS_AND_CONDITIONS,
            ]);
    }

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FILE);
    }

    public function termsAndConditions()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_TERMS_AND_CONDITIONS);
    }

    public function videos()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_VIDEO);
    }

    public function videoLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function termsAndConditionsLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->where('type', LinkRepository::TYPE_TERMS_AND_CONDITIONS);
    }

    public function socialMedia()
    {
        return $this->morphMany(SocialMedia::class, 'sociable');
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notificable');
    }

    public function admins()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
                //User::RELATION_TYPE_EDITOR,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function primaryAndSecondary()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function followers()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivot('type', User::RELATION_TYPE_FOLLOWER)
            ->wherePivot('related_type', self::class);
    }

    public function funds()
    {
        return $this->hasMany(Fund::class);
    }

    public function watchlistItems()
    {
        return $this->morphMany(WatchlistItem::class, 'entitiable');
    }

    public function lseAssets()
    {
        return $this->morphMany(LseAsset::class, 'entitiable');
    }

    public function demoIndividualKeys()
    {
        return $this->morphMany(DemoIndividualKey::class, 'entitiable');
    }

    public function sections()
    {
        return $this->hasMany(Section::class, 'referenced_id', 'id')
            ->where('referenced_type', FundsManager::class);
    }

    public function documents()
    {
        return $this->hasManyThrough(Document::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function employees()
    {
        return $this->hasManyThrough(Employee::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function excluded()
    {
        return $this->morphMany(Exclusion::class, 'excludable');
    }

    public function relations()
    {
        return $this->hasMany(Relation::class, 'related_id', 'id')
            ->where('related_type', self::class);
    }

    public function viewedBy()
    {
        return $this->belongsToMany(User::class, 'funds_manager_viewer', 'funds_manager_id', 'user_id')
            ->withPivot('profile', 'news', 'events')
            ->withTrashed();
    }

    public function statisticMocks()
    {
        return $this->hasMany(FundsManagerStatisticMock::class);
    }
}
