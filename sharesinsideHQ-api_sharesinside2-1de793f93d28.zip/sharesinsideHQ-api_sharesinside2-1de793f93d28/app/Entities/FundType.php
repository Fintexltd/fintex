<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class FundType extends Model
{
    protected $fillable = [
        'name',
        'sort_order'
    ];

    protected $hidden = [
        'sort_order',
    ];

    public function funds()
    {
        return $this->belongsToMany(Fund::class, 'fund_fund_type')->withTimestamps();
    }
}
