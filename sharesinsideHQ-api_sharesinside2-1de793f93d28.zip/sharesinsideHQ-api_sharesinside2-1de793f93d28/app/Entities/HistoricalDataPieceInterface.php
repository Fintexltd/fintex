<?php

namespace App\Entities;

interface HistoricalDataPieceInterface
{
    const TYPE_DIVIDENT = 'type_divident';
    const TYPE_REPORT = 'type_report';
    const TYPE_PRESENTATION = 'type_presentation';

    const AVALIABLE_TYPES = [
        self::TYPE_DIVIDENT,
        self::TYPE_REPORT,
        self::TYPE_PRESENTATION,
    ];
}