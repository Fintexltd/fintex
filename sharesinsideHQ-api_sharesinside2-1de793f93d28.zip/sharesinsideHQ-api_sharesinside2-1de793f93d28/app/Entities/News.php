<?php

namespace App\Entities;

use App\Entities\Traits\WatchlistableTrait;
use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    use WatchlistableTrait;

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $fillable = [
//        'company_id',
        'title',
        'description',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (News $news) {
            $news->watchlistItem->delete();
        });

        static::created(function (News $news) {
            WatchlistItem::create([
                'watchlistable_id' => $news->id,
                'watchlistable_type' => self::class,
            ]);
        });
    }

    public function watchlistItem()
    {
        return $this->morphOne(WatchlistItem::class, 'watchlistable');
    }

    public function StockExchangeEmails()
    {
        return $this->morphMany(StockExchangeEmail::class, 'mailable');
    }

    /*public function reminder()
    {
        return $this->hasOne(Reminder::class);
    }*/

    public function reminder()
    {
        return $this->morphOne(Reminder::class, 'remindable');
    }

    /*public function shares()
    {
        return $this->hasMany(Share::class);
    }*/

    public function shares()
    {
        return $this->morphMany(Share::class, 'shareable');
    }
}
