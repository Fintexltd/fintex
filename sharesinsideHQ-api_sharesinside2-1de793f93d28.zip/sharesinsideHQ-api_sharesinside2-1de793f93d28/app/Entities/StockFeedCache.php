<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StockFeedCache extends Model
{
    protected $fillable = [
        'value',
        'timestamp',
    ];
}
