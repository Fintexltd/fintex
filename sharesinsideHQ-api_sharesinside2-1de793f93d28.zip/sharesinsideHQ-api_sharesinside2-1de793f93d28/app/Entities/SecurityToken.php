<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;

class SecurityToken extends Model
{
    const TOKEN_SEEDER_STRING_LENGTH = 16;
    const LINKEDIN_REGISTER = 'linkedin_register';
    const EMAIL_CONFIRMATION = 'email_confirmation';
    const LINKEDIN_REDIRECT_TOKEN = 'linkedin_redirect_token';
    const UPLOADED_FILE = 'uploaded_file';
    const EXPORT_MY_RELATION_DATA = 'export_my_relation_data';

    const TOKEN_VALID_PERIOD_IN_HOURS = [
        self::LINKEDIN_REGISTER => 1,
        self::EMAIL_CONFIRMATION => 24,
        self::LINKEDIN_REDIRECT_TOKEN => 1,
        self::UPLOADED_FILE => 24,
        self::EXPORT_MY_RELATION_DATA => 1,
    ];

    public function generateUniqueToken()
    {
        do {
            $token = Hash::make(self::getSeed());
        } while (self::where('token', $token)->first());

        $this->token = $token;

        return $this;
    }

    protected function getSeed()
    {
        return time() . str_random(self::TOKEN_SEEDER_STRING_LENGTH);
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function attachment()
    {
        return $this->morphOne(Attachment::class, 'attachable');
    }
}
