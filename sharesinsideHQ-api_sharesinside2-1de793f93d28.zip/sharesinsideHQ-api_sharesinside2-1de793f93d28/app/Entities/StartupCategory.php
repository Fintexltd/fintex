<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class StartupCategory extends Model
{
    protected $fillable = [
        'name',
        'sort_order'
    ];

    protected $hidden = [
        'sort_order',
    ];

    public function startups()
    {
        return $this->belongsToMany(Startup::class, 'startup_startup_category')->withTimestamps();
    }
}
