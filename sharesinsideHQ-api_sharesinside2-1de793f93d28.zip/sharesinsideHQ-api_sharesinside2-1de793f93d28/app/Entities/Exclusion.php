<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class Exclusion extends Model
{
    public $fillable = [
        'country_id',
        'excludable_type',
        'excludable_id',
    ];

    public function country()
    {
        return $this->belongsTo(Country::class);
    }

    public function excludable()
    {
        return $this->morphTo();
    }
}
