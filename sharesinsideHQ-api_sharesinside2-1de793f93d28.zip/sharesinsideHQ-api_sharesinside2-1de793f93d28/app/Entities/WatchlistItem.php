<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WatchlistItem extends Model implements WatchlistItemInterface
{
    use SoftDeletes;

    public $timestamps = false;

    protected $dates = [
        'notify_stock_at',
        'publish_at',
        'deleted_at',
    ];

    protected $fillable = [
        'watchlistable_id',
        'watchlistable_type',
        'publish_at',
        'notify_stock_at',
        'notify_publicity',
        'notify_stock',
        'is_ad_hoc',
        'is_draft',
        'abstract',
        'text_description',
        'entitiable_id',
        'entitiable_type',
        'company_id',
        'fund_id',
        'is_internal',
        'is_business',
        'is_excluded',
        'stock_informed_in_past',
        'is_local',
        'receivers',
        'social_share_key',
        'views',
        'views_social_share',
        'deleted_at',
    ];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (WatchlistItem $item) {
            if ($item->isForceDeleting()) {
                $item->attachments()->delete();
                $item->links()->delete();
                $item->watchlistable()->delete();
                $item->excluded()->delete();
            }
//            $item->attachments()->delete();
//            $item->links()->delete();
//            $item->watchlistable()->delete();
        });
    }

    public function watchlistable()
    {
        return $this->morphTo();
    }

    public function entitiable()
    {
        return $this->morphTo();
    }

    public function news()
    {
        return $this
            ->belongsTo(News::class, 'watchlistable_id', 'id')
            ->where('watchlistable_type', News::class);
    }

    public function event()
    {
        return $this
            ->belongsTo(Event::class, 'watchlistable_id', 'id')
            ->where('watchlistable_type', Event::class);
    }

    public function project()
    {
        return $this
            ->belongsTo(Project::class, 'watchlistable_id', 'id')
            ->where('watchlistable_type', Project::class);
    }

    public function company()
    {
        //return $this->belongsTo(Company::class, 'company_id', 'id')->withTrashed();
        return $this
            ->belongsTo(Company::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Company::class)
            ->withTrashed();
    }

    public function startup()
    {
        return $this
            ->belongsTo(Startup::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Startup::class)
            ->withTrashed();
    }

    public function fund()
    {
        //return $this->belongsTo(Fund::class, 'fund_id', 'id')->withTrashed();
        return $this
            ->belongsTo(Fund::class, 'entitiable_id', 'id')
            ->where('entitiable_type', Fund::class)
            ->withTrashed();
    }

    public function fundsManager()
    {
        return $this
            ->belongsTo(FundsManager::class, 'entitiable_id', 'id')
            ->where('entitiable_type', FundsManager::class)
            ->withTrashed();
    }

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable');
    }

    public function files()
    {
        return $this->attachments()
            ->where('type', AttachmentRepository::TYPE_FILE);
    }

    public function videos()
    {
        return $this->attachments()
            ->where('type', AttachmentRepository::TYPE_VIDEO);
    }

    public function images()
    {
        return $this->attachments()
            ->where('type', AttachmentRepository::TYPE_IMAGE);
    }

    public function links()
    {
        return $this->morphMany(Link::class, 'linkable');
    }

    public function urlLinks()
    {
        return $this->links()
            ->where('type', LinkRepository::TYPE_DEFAULT);
    }

    public function videoLinks()
    {
        return $this->links()
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function getPublishedTimestamp()
    {
        return $this->publish_at ? $this->publish_at->timestamp : null;
    }

    public function excluded()
    {
        return $this->morphMany(Exclusion::class, 'excludable');
    }
}
