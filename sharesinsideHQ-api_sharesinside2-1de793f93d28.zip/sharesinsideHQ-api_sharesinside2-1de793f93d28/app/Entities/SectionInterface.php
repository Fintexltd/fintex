<?php

namespace App\Entities;

interface SectionInterface
{
    const EMPLOYEE_SECTION = 'employee_section';
    const COMPANY_GALLERY_ITEMS_SECTION = 'company_gallery_items_section';
    const COMPANY_GALLERY_ALBUM_SECTION = 'company_gallery_album_section';
    const HISTORICAL_DATA_SECTION = 'historical_data_section';
    const DOCUMENT_SECTION = 'document_section';

    const SECTION_TYPES = [
        self::EMPLOYEE_SECTION,
        self::COMPANY_GALLERY_ITEMS_SECTION,
        self::COMPANY_GALLERY_ALBUM_SECTION,
        self::HISTORICAL_DATA_SECTION,
        self::DOCUMENT_SECTION,
    ];

    const GALLERY_TYPES = [
        self::COMPANY_GALLERY_ITEMS_SECTION,
        self::COMPANY_GALLERY_ALBUM_SECTION,
    ];

}
