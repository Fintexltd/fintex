<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Share extends Model implements ShareInterface
{
    protected $fillable = [
        'user_id',
        'news_id',
        'type',
        'shareable_type',
        'shareable_id'
    ];

    public function shareable()
    {
        return $this->morphTo();
    }

    public function news()
    {
        return $this
            ->belongsTo(News::class, 'shareable_id', 'id')
            ->where('shareable_type', News::class);
    }

    public function event()
    {
        return $this
            ->belongsTo(Event::class, 'shareable_id', 'id')
            ->where('shareable_type', Event::class);
    }

    public function project()
    {
        return $this
            ->belongsTo(Project::class, 'shareable_id', 'id')
            ->where('shareable_type', Project::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
