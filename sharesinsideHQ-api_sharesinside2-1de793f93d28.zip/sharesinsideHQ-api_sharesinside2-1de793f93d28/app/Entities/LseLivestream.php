<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class LseLivestream extends Model
{
    protected $fillable = [
        'uuid',
        'item',
        'livestream'
    ];

    public function lseAsset()
    {
        return $this->belongsTo(LseAsset::class, 'lse_asset_id', 'id');
    }
}
