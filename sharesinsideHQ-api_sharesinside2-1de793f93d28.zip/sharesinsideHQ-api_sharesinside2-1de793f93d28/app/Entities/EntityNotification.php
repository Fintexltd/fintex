<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class EntityNotification extends Model
{
    protected $fillable = [
        'notificable_type',
        'notificable_id',
        'is_prepared'
    ];

    public function notificable()
    {
        return $this->morphTo();
    }
}
