<?php

namespace App\Entities;

interface WatchlistItemInterface
{
    const PUBLICITY_TYPE_PUBLIC = 'public';
    const PUBLICITY_TYPE_BUSINESS = 'business';
    const PUBLICITY_TYPE_INVESTOR = 'investor';
    const PUBLICITY_TYPE_INTERNAL = 'internal';

    const AVALIABLE_PUBLICITY_TYPES = [
        self::PUBLICITY_TYPE_PUBLIC,
        self::PUBLICITY_TYPE_BUSINESS,
        self::PUBLICITY_TYPE_INVESTOR,
        self::PUBLICITY_TYPE_INTERNAL,
    ];

    const WATCHLISTABLE_TYPE_NEWS = 'news';
    const WATCHLISTABLE_TYPE_PROJECT = 'project';
    const WATCHLISTABLE_TYPE_EVENT = 'event';

    const WATCHLISTABLE_TYPE = [
        News::class => self::WATCHLISTABLE_TYPE_NEWS,
        Project::class => self::WATCHLISTABLE_TYPE_PROJECT,
        Event::class => self::WATCHLISTABLE_TYPE_EVENT,
    ];

    const WATCHLISTABLE_TYPE_CLASS = [
        self::WATCHLISTABLE_TYPE_NEWS => News::class,
        self::WATCHLISTABLE_TYPE_PROJECT => Project::class,
        self::WATCHLISTABLE_TYPE_EVENT => Event::class,
    ];
}
