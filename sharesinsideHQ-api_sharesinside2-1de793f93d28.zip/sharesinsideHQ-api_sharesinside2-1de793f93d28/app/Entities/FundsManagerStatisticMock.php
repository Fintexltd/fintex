<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class FundsManagerStatisticMock extends Model
{
    protected $table = 'funds_manager_statistic_mocks';

    protected $fillable = [
        'funds_manager_id',
        'date',
        'value',
    ];
}
