<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    public $fillable = [
        'title',
        'message',
        'destination',
        'destination_id',
        'company_id',
        'funds_manager_id',
        'fund_id',
        'notificable_id',
        'notificable_type'
    ];

    public function notificable()
    {
        return $this->morphTo();
    }

    public function users()
    {
        return $this
            ->belongsToMany(User::class);
    }
}
