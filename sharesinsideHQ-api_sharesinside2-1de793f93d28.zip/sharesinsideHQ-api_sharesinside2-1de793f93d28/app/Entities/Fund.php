<?php

namespace App\Entities;

use App\Repositories\AttachmentRepository;
use App\Repositories\LinkRepository;
use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Fund extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'funds_manager_id',
        'country_id',
        'currency_id',
        'name',
        'title',
        'description',
        'kind_of_fund',
        'open_closed',
        'management_fee',
        'performance_fee',
        'duration',
        'is_active',
        'is_passive',
        'trading_frequency',
        'is_accepted',
        'views',
    ];

    protected $dates = ['deleted_at'];

    protected static function boot()
    {
        parent::boot();

        static::deleting(function (Fund $fund) {
            $fund->watchlistItems()->delete();
            $fund->notifications()->delete();
            $fund->seSymbols()->detach();
//            $logo = $company->logo;
//            if($logo){$logo->delete();}
//            $background = $company->background;
//            if($background){$background->delete();}
//            $company->links()->delete();
//            $company->attachments->each(function ($item) {
//                return $item->delete();
//            });
//            $company->socialMedia()->delete();
//            $company->sections->each(function ($item) {
//                return $item->delete();
//            });
//            $company->historicalData()->delete();
        });
    }

    public function logo()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FUND_LOGO);
    }

    public function background()
    {
        return $this->morphOne(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FUND_BACKGROUND);
    }

    public function continent()
    {
        return $this->belongsTo(Continent::class, 'continent_id', 'id');
    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class, 'currency_id', 'id');
    }

    public function entityNotifications()
    {
        return $this->morphMany(EntityNotification::class, 'notificable');
    }

    public function links()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereNotIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function attachments()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_FILE);
    }

    public function videos()
    {
        return $this->morphMany(Attachment::class, 'attachable')
            ->where('type', AttachmentRepository::TYPE_VIDEO);
    }

    public function videoLinks()
    {
        return $this->morphMany(Link::class, 'linkable')
            ->whereIn('type', [
                LinkRepository::TYPE_VIDEO,
                LinkRepository::TYPE_WEBCAST,
                LinkRepository::TYPE_ARCHIVED_VIDEO,
            ]);
    }

    public function seSymbols()
    {
        return $this->morphToMany(SeSymbol::class, 'se_symbolable')
            ->withPivot('is_default')
            ->withTimestamps();
    }

    public function seMainStockPrice()
    {
        $symbol = $this->seSymbols()->wherePivot('is_default', true)->first();
        $response = '';

        if($symbol) {
            $ohlcv = $symbol->seOhlcvs()->orderByDesc('date')->first();
            $response = $symbol->currency;

            if ($ohlcv) {

                $response .= ' '.round($ohlcv->close, 2);
            }
        }

        return $response;
    }

    public function socialMedia()
    {
        return $this->morphMany(SocialMedia::class, 'sociable');
    }

    public function notifications()
    {
        return $this->morphMany(Notification::class, 'notificable');
    }

    public function admins()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
                User::RELATION_TYPE_EDITOR,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function primaryAndSecondary()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivotIn('type', [
                User::RELATION_TYPE_PRIMARY_ADMIN,
                User::RELATION_TYPE_SECONDARY_ADMIN,
            ])
            ->wherePivot('related_type', self::class);
    }

    public function followers()
    {
        return $this->belongsToMany(User::class, 'relations', 'related_id', 'user_id')
            ->wherePivot('type', User::RELATION_TYPE_FOLLOWER)
            ->wherePivot('related_type', self::class);
    }

    public function fundsManager()
    {
        return $this->belongsTo(FundsManager::class);
    }

    public function fundTypes()
    {
        return $this->belongsToMany(FundType::class, 'fund_fund_type')->withTimestamps();
    }

    public function watchlistItems()
    {
        //return $this->hasMany(WatchlistItem::class);
        return $this->morphMany(WatchlistItem::class, 'entitiable');
    }

    public function lseAssets()
    {
        return $this->morphMany(LseAsset::class, 'entitiable');
    }

    public function sections()
    {
        return $this->hasMany(Section::class, 'referenced_id', 'id')
            ->where('referenced_type', Fund::class);
    }

    public function documents()
    {
        return $this->hasManyThrough(Document::class, Section::class, 'referenced_id')->where('referenced_type', static::class);
    }

    public function excluded()
    {
        return $this->morphMany(Exclusion::class, 'excludable');
    }

    public function relations()
    {
        return $this->hasMany(Relation::class, 'related_id', 'id')
            ->where('related_type', self::class);
    }

    public function viewedBy()
    {
        return $this->belongsToMany(User::class, 'fund_viewer', 'fund_id', 'user_id')
            ->withPivot('profile', 'news', 'events')
            ->withTrashed();
    }

    public function statisticMocks()
    {
        return $this->hasMany(FundStatisticMock::class);
    }
}
