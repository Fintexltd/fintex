<?php

namespace App\Entities;

interface ShareInterface
{
    const TYPE_FACEBOOK = 'facebook';
    const TYPE_LINKEDIN = 'linkedin';
    const TYPE_MAIL = 'mail';
    const TYPE_TWITTER = 'twitter';

    const AVALIABLE_TYPES = [
        self::TYPE_FACEBOOK,
        self::TYPE_LINKEDIN,
        self::TYPE_MAIL,
        self::TYPE_TWITTER,
    ];
}