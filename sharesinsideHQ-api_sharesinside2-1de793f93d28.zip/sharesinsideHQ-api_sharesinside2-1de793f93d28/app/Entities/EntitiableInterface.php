<?php

namespace App\Entities;

interface EntitiableInterface
{
    const ENTITIABLE_TYPE_COMPANY = 'company';
    const ENTITIABLE_TYPE_STARTUP = 'startup';
    const ENTITIABLE_TYPE_FUND = 'fund';
    const ENTITIABLE_TYPE_FUNDS_MANAGER = 'funds_manager';

    const ENTITIABLE_TYPE = [
        Company::class => self::ENTITIABLE_TYPE_COMPANY,
        Startup::class => self::ENTITIABLE_TYPE_STARTUP,
        Fund::class => self::ENTITIABLE_TYPE_FUND,
        FundsManager::class => self::ENTITIABLE_TYPE_FUNDS_MANAGER,
    ];

    const ENTITIABLE_TYPE_CLASS = [
        self::ENTITIABLE_TYPE_COMPANY => Company::class,
        self::ENTITIABLE_TYPE_STARTUP => Startup::class,
        self::ENTITIABLE_TYPE_FUND => Fund::class,
        self::ENTITIABLE_TYPE_FUNDS_MANAGER => FundsManager::class,
    ];
}
