<?php

namespace App\Entities;

use App\User;
use Illuminate\Database\Eloquent\Model;

class StartupViewer extends Model
{
    protected $fillable = [
        'startup_id',
        'user_id',
        'profile',
        'news',
        'events',
        'projects',
        'date',
    ];

    public $timestamps = false;

    /**
     * primaryKey
     *
     * @var integer
     * @access protected
     */
    protected $primaryKey = null;

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    protected $table = 'startup_viewer';

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
