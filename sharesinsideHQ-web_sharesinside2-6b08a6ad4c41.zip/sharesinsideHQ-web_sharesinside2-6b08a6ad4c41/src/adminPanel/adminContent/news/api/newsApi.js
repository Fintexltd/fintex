import axios from 'axios';

export const deleteNewsData = newsId =>
  axios.delete(`${process.env.REACT_APP_API_URL}/news/${newsId}`);
