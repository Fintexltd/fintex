import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CompanyNewsContentView from 'adminPanel/adminContent/news/components/newsContentView';
import {
  fetchAdminCompanyNews,
  removeAdminCompanyNews,
} from 'adminPanel/redux/actions/adminCompanyNewsActions';
import { deleteNewsData } from 'adminPanel/adminContent/news/api/newsApi.js';

const mapStateToProps = (state) => ({
  newsList: state.adminCompanyNews.list,
  hasNextPage: state.adminCompanyNews.hasNextPage,
  nextPageIndex: state.adminCompanyNews.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminCompanyNews: bindActionCreators(fetchAdminCompanyNews, dispatch),
  removeAdminCompanyNews: bindActionCreators(removeAdminCompanyNews, dispatch),
});

class NewsContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadMoreClicked: false,
      isRemoveNewsModalVisible: false,
      newsToDelete: null,
    };
  }

  componentDidMount() {
    if (this.props.companyId) {
      this.props.removeAdminCompanyNews();
      this.props.getAdminCompanyNews(0, this.props.companyId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminCompanyNews(
          this.props.nextPageIndex,
          this.props.companyId,
        );
      });
    }
  };

  deleteNews = () => {
    deleteNewsData(this.state.newsToDelete).then(() => {
      this.props.getAdminCompanyNews(0, this.props.companyId);
      this.toggleNewsDeleteModal();
    });
  };

  toggleNewsDeleteModal = (newsId) => {
    this.setState((prevState) => ({
      isRemoveNewsModalVisible: !prevState.isRemoveNewsModalVisible,
      newsToDelete: newsId,
    }));
  };

  render() {
    return (
      <CompanyNewsContentView
        newsList={this.props.newsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        companyId={this.props.companyId}
        isRemoveNewsModalVisible={this.state.isRemoveNewsModalVisible}
        toggleNewsDeleteModal={this.toggleNewsDeleteModal}
        deleteNews={this.deleteNews}
        userData={this.props.userData}
      />
    );
  }
}

NewsContent.defaultProps = {
  companyId: null,
  nextPageIndex: null,
  newsList: [],
};

NewsContent.propTypes = {
  companyId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  newsList: PropTypes.arrayOf(PropTypes.object),
  getAdminCompanyNews: PropTypes.func.isRequired,
  removeAdminCompanyNews: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsContent);
