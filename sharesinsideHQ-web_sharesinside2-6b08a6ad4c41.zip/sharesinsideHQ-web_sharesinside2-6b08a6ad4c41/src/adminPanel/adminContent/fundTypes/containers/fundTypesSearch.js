import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import FundTypesSearchView from 'adminPanel/adminContent/fundTypes/components/fundTypesSearchView';
import fetchFundTypes from 'adminPanel/adminContent/fundTypes/redux/actions/fundTypesActions';
import { saveFundTypesSearch } from 'adminPanel/adminContent/fundTypes/redux/actions/fundTypesFiltersActions';

const mapStateToProps = state => ({
  fundTypes: state.fundTypesAdmin.list,
  fundTypesFilters: state.fundTypesFilters,
  resultsNumber: state.fundTypesAdmin.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getFundTypes: bindActionCreators(fetchFundTypes, dispatch),
  saveFundTypesSearch: bindActionCreators(saveFundTypesSearch, dispatch),
});

class FundTypesSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundTypes = debounce(props.getFundTypes, 500);
  }

  handleSearchInputChange = text => {
    this.props.saveFundTypesSearch(text);
    this.debouncedGetFundTypes();
  };

  render() {
    return (
      <FundTypesSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        fundTypesFilters={this.props.fundTypesFilters}
      />
    );
  }
}

FundTypesSearch.defaultProps = {
  resultsNumber: null,
};

FundTypesSearch.propTypes = {
  getFundTypes: PropTypes.func.isRequired,
  saveFundTypesSearch: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundTypesSearch);
