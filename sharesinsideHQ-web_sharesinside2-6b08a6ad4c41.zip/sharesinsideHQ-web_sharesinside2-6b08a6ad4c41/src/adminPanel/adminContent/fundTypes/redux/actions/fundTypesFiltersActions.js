import * as types from 'adminPanel/adminContent/fundTypes/redux/types';
import { createActionCreator } from 'common/utils/reduxUtils';

const { SAVE_ADMIN_FUND_TYPES_SEARCH } = types;

export const saveFundTypesSearch = createActionCreator(
  SAVE_ADMIN_FUND_TYPES_SEARCH,
  'search',
);
