import axios from 'axios';
import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/fundTypes/redux/types.js';

const {
  FETCH_ADMIN_FUND_TYPES_REQUEST,
  FETCH_ADMIN_FUND_TYPES_SUCCESS,
  FETCH_ADMIN_FUND_TYPES_FAILURE,
} = types;

const fetchFundTypesRequest = createActionCreator(
  FETCH_ADMIN_FUND_TYPES_REQUEST,
);
const fetchFundTypesSuccess = createActionCreator(
  FETCH_ADMIN_FUND_TYPES_SUCCESS,
  'data',
);
const fetchFundTypesFailure = createActionCreator(
  FETCH_ADMIN_FUND_TYPES_FAILURE,
);

const fetchFundTypes = () => (dispatch, getState) => {
  const { search } = getState().fundTypesFilters;

  dispatch(fetchFundTypesRequest());
  return axios
    .get(`${process.env.REACT_APP_API_URL}/fund-types`, {
      params: {
        search,
      },
    })
    .then(response => {
      dispatch(fetchFundTypesSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchFundTypesFailure());
    });
};

export default fetchFundTypes;
