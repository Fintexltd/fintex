import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchFundTypes from 'adminPanel/adminContent/fundTypes/redux/actions/fundTypesActions';
import FundTypesView from 'adminPanel/adminContent/fundTypes/components/fundTypesView';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import { FormGroup } from 'reactstrap';
import FormModal from 'common/components/modals/form';
import validationSchema from 'adminPanel/adminContent/fundTypes/validators/validationSchema';
import Input from 'common/components/input';
import { disableScroll } from 'common/utils/disableScroll';
import RemoveModal from 'common/components/removeModal';
import InfoModal from 'common/components/infoModal';
import {
  addFundType,
  editFundType,
  deleteFundType,
} from 'adminPanel/adminContent/fundTypes/api/fundTypesApi';
import setSubmitErrors from 'adminPanel/adminContent/fundTypes/utils/submitErrors';

const mapStateToProps = (state) => ({
  fundTypes: state.fundTypesAdmin.data,
  fundTypesFilters: state.fundTypesFilters,
  token: state.auth.token,
  userData: state.userData.data,
  resultsNumber: state.fundTypesAdmin.resultsNumber,
});

const mapDispatchToProps = (dispatch) => ({
  getFundTypes: bindActionCreators(fetchFundTypes, dispatch),
});

class AdminFundTypes extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isErrorModalVisible: false,
      errorModalMessage: [],
      isFundTypeModalVisible: false,
      isRemoveFundTypeModalVisible: false,
      values: {
        name: '',
      },
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_FUND_TYPES,
      )
    )
      this.props.history.push('/admin/company/management');

    this.props.getFundTypes();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_FUND_TYPES,
      )
    )
      this.props.history.push('/admin/company/management');
  }

  isFundTypesFiltersActive = () => {
    const { search } = this.props.fundTypesFilters;
    return search !== '';
  };

  toggleFundTypeModal = () => {
    this.setState(
      (prevState) => ({
        isFundTypeModalVisible: !prevState.isFundTypeModalVisible,
      }),
      () => disableScroll(this.state.isFundTypeModalVisible),
    );
  };

  submitFundType = (values, actions) => {
    if (values.isEditing) {
      editFundType(values.id, values.name)
        .then(() => {
          this.toggleFundTypeModal();
          this.props.getFundTypes();
        })
        .catch((error) => {
          actions.setErrors(setSubmitErrors(error));
        });
    } else {
      addFundType(values.name)
        .then(() => {
          this.toggleFundTypeModal();
          this.props.getFundTypes();
        })
        .catch((error) => {
          actions.setErrors(setSubmitErrors(error));
        });
    }
  };

  toggleRemoveFundTypeModal = () => {
    this.setState(
      (prevState) => ({
        isRemoveFundTypeModalVisible: !prevState.isRemoveFundTypeModalVisible,
      }),
      () => disableScroll(this.state.isRemoveFundTypeModalVisible),
    );
  };

  openRemoveFundTypeModal = (id) => {
    this.toggleRemoveFundTypeModal();
    this.setState({
      fundTypeToRemove: id,
    });
  };

  removeFundType = () => {
    deleteFundType(this.state.fundTypeToRemove)
      .then(() => {
        this.props.getFundTypes().then(() => {
          this.toggleRemoveFundTypeModal();
        });
      })
      .catch((error) => {
        this.toggleRemoveFundTypeModal();
        this.toggleErrorModal();
        this.setState({
          errorModalMessage: error.response.data.errors
            ? Object.keys(error.response.data.errors).map(
                (key) => error.response.data.errors[key][0],
              )
            : ['There was an error.'],
        });
      });
  };

  toggleErrorModal = () => {
    this.setState(
      (prevState) => ({
        isErrorModalVisible: !prevState.isErrorModalVisible,
      }),
      () => disableScroll(this.state.isErrorModalVisible),
    );
  };

  addFundType = () => {
    this.toggleFundTypeModal();
    this.setState({
      values: {
        name: '',
        isEditing: false,
      },
    });
  };

  editFundType = (fundType) => {
    this.toggleFundTypeModal();
    this.setState({
      values: {
        name: fundType.name,
        id: fundType.id,
        isEditing: true,
      },
    });
  };

  render() {
    const ModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.name}
            error={formProps.errors.name}
            touched={formProps.touched.name}
            name="name"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Name*"
          />
          <span className="letter-counter">
            {`${formProps.values.name.length}/32`}
          </span>
        </FormGroup>
      </>
    );
    return (
      <>
        <FundTypesView
          fundTypes={this.props.fundTypes}
          isFundTypesFiltersActive={this.isFundTypesFiltersActive}
          getFundTypes={this.props.getFundTypes}
          addNewFundType={this.addNewFundType}
          resultsNumber={this.props.resultsNumber}
          userData={this.props.userData}
          toggleFundTypeModal={this.toggleFundTypeModal}
          openRemoveFundTypeModal={this.openRemoveFundTypeModal}
          removeFundType={this.removeFundType}
          editFundType={this.editFundType}
          addFundType={this.addFundType}
        />
        <FormModal
          isModalVisible={this.state.isFundTypeModalVisible}
          handleClose={this.toggleFundTypeModal}
          header="Add Fund Type"
          validationSchema={validationSchema}
          onSubmit={this.submitFundType}
          initialValues={this.state.values}
          confimButtonText="Confirm"
        >
          <ModalFormView />
        </FormModal>
        {this.state.isRemoveFundTypeModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this fund type?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFundType}
            handleCancelClick={this.toggleRemoveFundTypeModal}
          />
        )}
        {this.state.isErrorModalVisible && (
          <InfoModal
            message={this.state.errorModalMessage.join(' ')}
            handleAcceptClick={this.toggleErrorModal}
          />
        )}
      </>
    );
  }
}

AdminFundTypes.defaultProps = {
  fundTypes: [],
  resultsNumber: null,
};

AdminFundTypes.propTypes = {
  fundTypes: PropTypes.arrayOf(PropTypes.object),
  getFundTypes: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  fundTypesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminFundTypes));
