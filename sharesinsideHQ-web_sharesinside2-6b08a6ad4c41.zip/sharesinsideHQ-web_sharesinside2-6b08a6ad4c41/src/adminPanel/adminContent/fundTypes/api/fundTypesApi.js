import axios from 'axios';

export const addFundType = name =>
  axios({
    method: 'post',
    url: `${process.env.REACT_APP_API_URL}/fund-types`,
    data: {
      name,
    },
  });

export const editFundType = (id, name) =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/fund-types/${id}`,
    data: {
      name,
    },
  });

export const deleteFundType = id =>
  axios({
    method: 'delete',
    url: `${process.env.REACT_APP_API_URL}/fund-types/${id}`,
  });
