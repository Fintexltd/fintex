import React from 'react';
import PropTypes from 'prop-types';
import SearchInput from 'common/components/searchInput';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import './index.scss';

const FundTypesSearchView = ({
  handleSearchInputChange,
  resultsNumber,
  fundTypesFilters,
}) => (
  <div className="fundTypes-search">
    <div className="fundTypes-search__top">
      <div className="fundTypes-search__top-left">
        <div className="fundTypes-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={fundTypesFilters.search}
          />
        </div>
      </div>
    </div>
    <div className="fundTypes-search__results-container">
      <div className="fundTypes-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
    </div>
  </div>
);

FundTypesSearchView.defaultProps = {
  resultsNumber: null,
};

FundTypesSearchView.propTypes = {
  resultsNumber: PropTypes.number,
  handleSearchInputChange: PropTypes.func.isRequired,
};

export default FundTypesSearchView;
