import React from 'react';
import PropTypes from 'prop-types';
import FundTypesSearch from 'adminPanel/adminContent/fundTypes/containers/fundTypesSearch';
import shortid from 'shortid';
import './index.scss';

const FundTypesView = ({
  fundTypes,
  isFundTypesFiltersActive,
  editFundType,
  addFundType,
  openRemoveFundTypeModal,
}) => (
  <div className="fundTypes">
    <h1 className="fundTypes__heading">Manage Fund Types</h1>
    <FundTypesSearch />
    <table className="fundTypes__table">
      <thead className="fundTypes__thead">
        <tr>
          <th>Name</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td
            className="add__fundTypes"
            colSpan={8}
            onClick={addFundType}
            role="presentation"
          >
            <div className="fundTypes-container">
              <h2>+ Add new Fund Type</h2>
            </div>
          </td>
        </tr>
        {fundTypes.map(fundType => (
          <tr key={shortid.generate()} className="fundTypes__fundType-row">
            <td>
              <div className="fundTypes__user-data">
                <div>
                  <p className="fundTypes__name">{fundType.name}</p>
                </div>
              </div>
            </td>
            <td>
              <div className="fundTypes__buttons">
                <button
                  onClick={() => editFundType(fundType)}
                  className="fundTypes__button fundTypes__button--edit"
                >
                  Edit
                </button>
                <button
                  onClick={() => openRemoveFundTypeModal(fundType.id)}
                  className="fundTypes__button fundTypes__button--remove"
                >
                  Remove
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    {isFundTypesFiltersActive() &&
      fundTypes.length === 0 && (
        <div className="fundTypes__empty-list">
          <p className="fundTypes__empty-list-message">
            There are no fundTypes matching these criteria
          </p>
        </div>
      )}
  </div>
);

FundTypesView.propTypes = {
  fundTypes: PropTypes.arrayOf(PropTypes.object).isRequired,
  isFundTypesFiltersActive: PropTypes.func.isRequired,
  editFundType: PropTypes.func.isRequired,
  addFundType: PropTypes.func.isRequired,
  openRemoveFundTypeModal: PropTypes.func.isRequired,
};

export default FundTypesView;
