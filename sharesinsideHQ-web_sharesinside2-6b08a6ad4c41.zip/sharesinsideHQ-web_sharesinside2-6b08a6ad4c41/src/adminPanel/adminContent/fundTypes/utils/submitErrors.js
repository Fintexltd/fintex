export default function setSubmitErrors(error) {
  let submitErrors = {};
  if (error.response.data.errors) {
    submitErrors = {
      ...(error.response.data.errors.name
        ? { name: error.response.data.errors.name }
        : {}),
    };
  }
  return submitErrors;
}
