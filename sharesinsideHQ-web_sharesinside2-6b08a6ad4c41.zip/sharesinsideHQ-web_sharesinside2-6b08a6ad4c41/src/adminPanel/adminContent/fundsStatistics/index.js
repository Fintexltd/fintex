import React, { Component } from 'react';
import fetchAdminFundStatistics from 'adminPanel/redux/actions/funds/admin/adminFundStatisticsActions';
import SelectChart from 'common/components/customSelect/selectChart';
import { saveStatisticsFilters } from 'adminPanel/adminContent/fundsStatistics/redux/actions/statisticsFiltersActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import fetchFundManagersWithFunds from 'common/redux/actions/fundManagersWithFundsActions';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import StatisticsSearch from 'adminPanel/adminContent/fundsStatistics/containers/statisticsSearch';
import StatisticsChart from 'adminPanel/adminContent/fundsStatistics/containers/statisticsChart';
import CircleSpinner from 'common/components/circleSpinner';
import './style.scss';

const mapDispatchToProps = (dispatch) => ({
  saveStatisticsFilters: bindActionCreators(saveStatisticsFilters, dispatch),
  fetchAdminStatistics: bindActionCreators(fetchAdminFundStatistics, dispatch),
  getFundsNames: bindActionCreators(fetchFundManagersWithFunds, dispatch),
});

const mapStateToProps = (state) => ({
  authToken: state.auth.token,
  userData: state.userData.data,
  fundsNames: state.fundManagersWithFunds.list,
  statistics: state.adminFundStatistics.data,
});

class UsersManagement extends Component {
  constructor() {
    super();
    this.state = {
      chartType: 'profile',
      selectedFund: [],
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.VIEW_FUND_STATISTICS,
      )
    )
      this.props.history.push('/admin/panel');

    this.props.getFundsNames();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.fundsNames !== this.props.fundsNames) {
      this.setState(
        {
          selectedFund: [
            {
              category: 'selectedFund',
              label: nextProps.fundsNames[0]
                ? nextProps.fundsNames[0].name
                : '',
              value: nextProps.fundsNames[0] ? nextProps.fundsNames[0] : '',
            },
          ],
        },
        () => {
          if (this.state.selectedFund[0].value) {
            this.props.fetchAdminStatistics(
              this.state.selectedFund[0].value.id,
              this.state.selectedFund[0].value.entitiable_type,
              this.state.chartType,
            );
          }
        },
      );
    }
  }

  handleChangeSelect = (value, category) => {
    this.setState(
      {
        [category]: value,
      },
      () => {
        this.props.fetchAdminStatistics(
          this.state.selectedFund[0].value.id,
          this.state.selectedFund[0].value.entitiable_type,
          this.state.chartType,
        );
      },
    );
  };

  changeChartType = (value) => {
    this.setState(
      {
        chartType: value,
      },
      () => {
        this.props.fetchAdminStatistics(
          this.state.selectedFund[0].value.id,
          this.state.selectedFund[0].value.entitiable_type,
          this.state.chartType,
        );
      },
    );
  };

  render() {
    const selectedFund = this.state.selectedFund[0]
      ? this.state.selectedFund[0].value
      : {};

    return (
      <>
        {this.props.statistics.length > 0 && (
          <div className="statistics">
            <h1 className="statistics__heading">Statistics of </h1>
            <div className="statistics__fundSelect">
              <SelectChart
                onChange={this.handleChangeSelect}
                options={mapObjPropsToSelectFilter({
                  list: this.props.fundsNames
                    ? this.props.fundsNames.map((fund) => ({
                        value: fund,
                        label: fund.name,
                      }))
                    : [],
                  label: 'label',
                  value: 'value',
                  category: 'selectedFund',
                })}
                value={this.state.selectedFund}
                category="selectedFund"
              />
            </div>
            <StatisticsSearch
              id={selectedFund.id}
              entitiableType={selectedFund.entitiable_type}
              chartType={this.state.chartType}
            />
            <StatisticsChart changeChartType={this.changeChartType} />
          </div>
        )}
        {this.props.fundsNames &&
          this.props.fundsNames.length > 0 &&
          this.props.statistics.length === 0 && (
            <div className="statistics__container">
              <CircleSpinner />
            </div>
          )}
        {this.props.fundsNames && this.props.fundsNames.length === 0 && (
          <div className="statistics__container">
            <p className="statistics__message">There are no statistics.</p>
          </div>
        )}
      </>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(UsersManagement);
