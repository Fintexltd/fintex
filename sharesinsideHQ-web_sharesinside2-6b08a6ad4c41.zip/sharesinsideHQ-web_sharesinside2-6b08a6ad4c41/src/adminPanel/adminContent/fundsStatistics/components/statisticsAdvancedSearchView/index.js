import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import DateRangePicker from 'common/components/calendars/dateRangePicker';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import getRelationTypeList from 'adminPanel/adminContent/fundsStatistics/utils/relationTypeUtils';
import 'adminPanel/adminContent/statistics/components/statisticsAdvancedSearchView/style.scss';

const StatisticsAdvancedSearchView = ({
  statisticsFilters,
  clearActiveFilters,
  isRemoveFiltersButtonVisible,
  handleFilterUsage,
  handleDateFilterUsage,
  countriesList,
}) => (
  <div className="statistics-advanced-search">
    <div className="statistics-advanced-search__filters">
      <div className="statistics-advanced-search__filter statistics-advanced-search__filter--region">
        <MultiSelect
          options={countriesList}
          description="Region"
          onChange={handleFilterUsage}
          value={statisticsFilters.country}
          category="country"
        />
      </div>
      <div className="statistics-advanced-search__filter statistics-advanced-search__filter--relation">
        <MultiSelect
          options={getRelationTypeList()}
          description="Relation"
          onChange={handleFilterUsage}
          value={statisticsFilters.relation}
          category="relation"
        />
      </div>
      <div className="statistics-advanced-search__filter statistics-advanced-search__filter--date-range">
        <DateRangePicker
          handleDateFilterUsage={handleDateFilterUsage}
          startDate={statisticsFilters.dateRange.from}
          endDate={statisticsFilters.dateRange.to}
          isOutsideRange
        />
      </div>
    </div>
    <div className="statistics-advanced-search__bottom-container">
      <div>
        {isRemoveFiltersButtonVisible() && (
          <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
        )}
      </div>
    </div>
  </div>
);

StatisticsAdvancedSearchView.propTypes = {
  clearActiveFilters: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
  handleDateFilterUsage: PropTypes.func.isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
  statisticsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.object,
    ]),
  ).isRequired,
};

export default StatisticsAdvancedSearchView;
