import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import { Row, Col, Button } from 'reactstrap';
import 'adminPanel/adminContent/statistics/components/statisticsChartLabels/style.scss';

const StatisticsChartLabel = ({ data, chartType, changeChartType }) => (
  <>
    <Row>
      <Col md={3} sm={12} className="chart__type">
        <div
          className={classnames({
            'chart__type--selected': chartType === 'profile' ? true : null,
            'chart__type--item': chartType !== 'profile' ? true : null,
          })}
        >
          <Button onClick={() => changeChartType('profile')}>
            Fund Profile
          </Button>
        </div>
        <div
          className={classnames({
            'chart__type--selected': chartType === 'news' ? true : null,
            'chart__type--item': chartType !== 'news' ? true : null,
          })}
        >
          <Button onClick={() => changeChartType('news')}>News</Button>
        </div>
        <div
          className={classnames({
            'chart__type--selected': chartType === 'events' ? true : null,
            'chart__type--item': chartType !== 'events' ? true : null,
          })}
        >
          <Button onClick={() => changeChartType('events')}>Events</Button>
        </div>
      </Col>

      <Col md={9} sm={12} className="chart__userInfo">
        <div className="chart__userInfo--item">
          <span className="chart__userInfo--span">Followers: </span>
          {data.followers}
        </div>
        <div className="chart__userInfo--item">
          <span className="chart__userInfo--span">Investors: </span>
          {data.shareholders}
        </div>
        <div className="chart__userInfo--item">
          <span className="chart__userInfo--span">VIPs: </span>
          {data.vips}
        </div>
      </Col>
    </Row>
  </>
);

StatisticsChartLabel.propTypes = {
  chartType: PropTypes.string.isRequired,
  data: PropTypes.objectOf(PropTypes.number).isRequired,
  changeChartType: PropTypes.func.isRequired,
};

export default StatisticsChartLabel;
