import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import StatisticsAdvancedSearch from 'adminPanel/adminContent/fundsStatistics/containers/statisticsAdvancedSearch';
import ActiveFiltersList from 'common/components/activeFiltersList';
import 'adminPanel/adminContent/statistics/components/statisticsSearchView/style.scss';

const StatisticsSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  isRemoveFiltersButtonVisible,
  handleFilterRemoveClick,
  id,
  entitiableType,
  chartType,
}) => (
  <div className="statistics-search">
    <div className="statistics-search__top">
      <StatisticsAdvancedSearch
        clearActiveFilters={clearActiveFilters}
        isRemoveFiltersButtonVisible={isRemoveFiltersButtonVisible}
        id={id}
        entitiableType={entitiableType}
        chartType={chartType}
      />
      {isRemoveFiltersButtonVisible() && (
        <div className="statistics-search__clear-filters-button">
          <div className="statistics-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="statistics-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>

    <div className="statistics-search__results-container">
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

StatisticsSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default StatisticsSearchView;
