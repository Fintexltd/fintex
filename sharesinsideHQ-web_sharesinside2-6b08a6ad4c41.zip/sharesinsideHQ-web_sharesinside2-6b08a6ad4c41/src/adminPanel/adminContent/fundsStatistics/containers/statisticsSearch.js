import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import StatisticsSearchView from 'adminPanel/adminContent/fundsStatistics/components/statisticsSearchView';
import fetchAdminFundStatistics from 'adminPanel/redux/actions/funds/admin/adminFundStatisticsActions';
import {
  removeStatisticsFilters,
  saveStatisticsFilters,
} from 'adminPanel/adminContent/fundsStatistics/redux/actions/statisticsFiltersActions';

const mapStateToProps = (state) => ({
  statisticsFilters: state.fundStatisticsFilters,
});

const mapDispatchToProps = (dispatch) => ({
  fetchAdminStatistics: bindActionCreators(fetchAdminFundStatistics, dispatch),
  removeStatisticsFilters: bindActionCreators(
    removeStatisticsFilters,
    dispatch,
  ),
  saveStatisticsFilters: bindActionCreators(saveStatisticsFilters, dispatch),
});

class StatisticsSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetUser = debounce(
      (id, entitiableType, type) =>
        props.fetchAdminStatistics(id, entitiableType, type),
      500,
    );
  }

  getActiveFiltersWithDateRange = () => {
    const { from, to } = this.props.statisticsFilters.dateRange;
    const filters = this.mapActiveFiltersLists();
    if (from) {
      filters.push(from);
    }
    if (to) {
      filters.push(to);
    }
    return filters;
  };

  clearActiveFilters = () => {
    this.props.removeStatisticsFilters();
    this.debouncedGetUser(
      this.props.id,
      this.props.entitiableType,
      this.props.chartType,
    );
  };

  mapActiveFiltersLists = () =>
    [
      ...this.props.statisticsFilters.relation,
      ...this.props.statisticsFilters.country,
    ].filter((filter) => filter.label);

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.statisticsFilters[category].filter(
      (el) => el.label !== label,
    );
    this.props.saveStatisticsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetUser(
      this.props.id,
      this.props.entitiableType,
      this.props.chartType,
    );
  };

  isRemoveFiltersButtonVisible = () =>
    this.mapActiveFiltersLists().length > 0 ||
    this.props.statisticsFilters.dateRange.from ||
    this.props.statisticsFilters.dateRange.to;

  render() {
    return (
      <StatisticsSearchView
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        statisticsFilters={this.props.statisticsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
        getActiveFiltersWithDateRange={this.getActiveFiltersWithDateRange}
        entitiableType={this.props.entitiableType}
        id={this.props.id}
        chartType={this.props.chartType}
      />
    );
  }
}

StatisticsSearch.propTypes = {
  fetchAdminStatistics: PropTypes.func.isRequired,
  removeStatisticsFilters: PropTypes.func.isRequired,
  saveStatisticsFilters: PropTypes.func.isRequired,
  entitiableType: PropTypes.string.isRequired,
  statisticsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.object,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(StatisticsSearch);
