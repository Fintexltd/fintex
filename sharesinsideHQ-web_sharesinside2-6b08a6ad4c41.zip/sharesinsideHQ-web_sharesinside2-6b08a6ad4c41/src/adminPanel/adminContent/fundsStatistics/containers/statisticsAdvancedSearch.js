import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import StatisticsAdvancedSearchView from 'adminPanel/adminContent/fundsStatistics/components/statisticsAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchFundManagersWithFunds from 'common/redux/actions/fundManagersWithFundsActions';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchAdminFundStatistics from 'adminPanel/redux/actions/funds/admin/adminFundStatisticsActions';
import {
  saveStatisticsFilters,
  saveStatisticsDateRange,
} from 'adminPanel/adminContent/fundsStatistics/redux/actions/statisticsFiltersActions';

const mapStateToProps = (state) => ({
  statisticsFilters: state.fundStatisticsFilters,
  countriesList: state.countries.list,
  fundsNames: state.fundsNames.list,
});

const mapDispatchToProps = (dispatch) => ({
  fetchAdminStatistics: bindActionCreators(fetchAdminFundStatistics, dispatch),
  saveStatisticsFilters: bindActionCreators(saveStatisticsFilters, dispatch),
  saveStatisticsDateRange: bindActionCreators(
    saveStatisticsDateRange,
    dispatch,
  ),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getFundsNames: bindActionCreators(fetchFundManagersWithFunds, dispatch),
});

class StatisticsAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetUser = debounce(
      (id, entitiableType, type) =>
        props.fetchAdminStatistics(id, entitiableType, type),
      500,
    );
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getFundsNames();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveStatisticsFilters(values.length > 0 ? values : { category });
    this.debouncedGetUser(
      this.props.id,
      this.props.entitiableType,
      this.props.chartType,
    );
  };

  handleDateFilterUsage = (start, end) => {
    this.props.saveStatisticsDateRange({
      from: start,
      to: end,
    });
    this.debouncedGetUser(
      this.props.id,
      this.props.entitiableType,
      this.props.chartType,
    );
  };

  render() {
    return (
      <StatisticsAdvancedSearchView
        clearActiveFilters={this.props.clearActiveFilters}
        handleFilterUsage={this.handleFilterUsage}
        statisticsFilters={this.props.statisticsFilters}
        handleDateFilterUsage={this.handleDateFilterUsage}
        isRemoveFiltersButtonVisible={this.props.isRemoveFiltersButtonVisible}
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList ? this.props.countriesList : [],
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
      />
    );
  }
}

StatisticsAdvancedSearch.propTypes = {
  fetchAdminStatistics: PropTypes.func.isRequired,
  saveStatisticsFilters: PropTypes.func.isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
  entitiableType: PropTypes.string.isRequired,
  statisticsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.object,
    ]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(StatisticsAdvancedSearch);
