import React, { Component } from 'react';
import StatisticsChartsLabels from 'adminPanel/adminContent/fundsStatistics/components/statisticsChartLabels';
import { connect } from 'react-redux';
import Chart from 'common/components/chart';
import { Row, Col } from 'reactstrap';

const mapStateToProps = (state) => ({
  statistics: state.adminFundStatistics.data,
  statisticsFilters: state.fundStatisticsFilters,
});

class StatisticsChart extends Component {
  constructor(props) {
    super(props);

    this.charts = React.createRef();
    this.state = {
      sliceFrom: 0,
      sliceTo: 0,
      leftActive: true,
      rightActive: false,
      timeSelected: 30,
      labelData: {},
      chartType: 'profile',
      chartValues: props.statistics || [],
      chartData: {},
    };
  }

  componentDidMount() {
    this.refreshChart();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.statistics !== nextProps.statistics) {
      this.setState(
        () => ({
          chartValues: nextProps.statistics,
          timeSelected:
            nextProps.statisticsFilters.dateRange.from ||
            nextProps.statisticsFilters.dateRange.to
              ? nextProps.statistics.length
              : 30,
          sliceFrom: 0,
          sliceTo: 0,
          leftActive: true,
          rightActive: false,
        }),
        () => this.refreshChart(),
      );
    }
  }

  refreshChart = () => {
    const { chartValues, timeSelected, labelData } = this.state;

    if (chartValues && chartValues.length - 1 > 0) {
      let sliceData = [];
      if (this.state.sliceFrom === 0 && this.state.sliceTo === 0) {
        if (chartValues.length !== timeSelected) {
          sliceData = chartValues
            .slice(
              chartValues.length - 1 - timeSelected,
              chartValues.length - 1,
            )
            .map((element) => {
              let date = element.date.split('-');
              date = [date[2], date[1], date[0]].join('.');
              return { ...element, date };
            });
        } else {
          sliceData = chartValues.map((element) => {
            let date = element.date.split('-');
            date = [date[2], date[1], date[0]].join('.');
            return { ...element, date };
          });
        }
        this.setState({
          sliceFrom: chartValues.length - 1 - timeSelected,
          sliceTo: chartValues.length - 1,
        });
      } else {
        sliceData = chartValues
          .slice(this.state.sliceFrom, this.state.sliceTo)
          .map((element) => {
            let date = element.date.split('-');
            date = [date[2], date[1], date[0]].join('.');
            return { ...element, date };
          });
      }
      if (sliceData.length > 0) {
        this.setState({
          chartData: {
            labels: sliceData.map((element) => element.date),
            views: sliceData.map((element) => element.data.views),
          },
          labelData: {
            followers: sliceData[sliceData.length - 1].data
              ? sliceData[sliceData.length - 1].data.followers
              : labelData.followers,
            shareholders: sliceData[sliceData.length - 1].data
              ? sliceData[sliceData.length - 1].data.shareholders
              : labelData.shareholders,
            vips: sliceData[sliceData.length - 1].data
              ? sliceData[sliceData.length - 1].data.vips
              : labelData.vips,
          },
        });
      }
    } else {
      this.setState({
        chartData: {
          labels: [],
          views: 0,
        },
        labelData: {
          followers: 0,
          shareholders: 0,
          vips: 0,
        },
      });
    }
  };

  changeTimeHandler = (value) => {
    this.setState(
      (prevState) => ({
        timeSelected: value,
        rightActive: false,
        leftActive: prevState.chartValues.length - 1 - value - value > 0,
        sliceFrom: prevState.chartValues.length - 1 - value,
        sliceTo: prevState.chartValues.length - 1,
      }),
      () => this.refreshChart(),
    );
  };

  dotOnClickHandler = (event, array) => {
    if (array[0] && array[0]._index !== undefined) {
      const { chartValues } = this.state;

      const sliceData = chartValues
        .slice(this.state.sliceFrom, this.state.sliceTo)
        .map((element) => {
          let date = element.date.split('-');
          date = [date[2], date[1], date[0]].join('.');
          return { ...element, date };
        });

      if (sliceData[array[0]._index] !== undefined) {
        this.setState((prevState) => ({
          labelData: {
            followers: sliceData[array[0]._index].data
              ? sliceData[array[0]._index].data.followers
              : prevState.labelData.followers,
            shareholders: sliceData[array[0]._index].data
              ? sliceData[array[0]._index].data.shareholders
              : prevState.labelData.shareholders,
            vips: sliceData[array[0]._index].data
              ? sliceData[array[0]._index].data.vips
              : prevState.labelData.vips,
          },
        }));
      }
    }
  };

  changeDateTimeRight = () => {
    if (this.state.rightActive) {
      const { chartValues, timeSelected, sliceFrom, sliceTo } = this.state;

      if (sliceTo + timeSelected >= chartValues.length - 1) {
        this.setState(
          {
            sliceFrom: chartValues.length - 1 - timeSelected,
            rightActive: false,
            leftActive: true,
            sliceTo: chartValues.length - 1,
          },
          () => this.refreshChart(),
        );
      } else {
        this.setState(
          {
            sliceFrom: sliceFrom + timeSelected,
            rightActive: true,
            leftActive: true,
            sliceTo: sliceTo + timeSelected,
          },
          () => this.refreshChart(),
        );
      }
    }
  };

  changeDateTimeLeft = () => {
    if (this.state.leftActive) {
      const { sliceFrom, sliceTo, timeSelected } = this.state;
      if (sliceFrom - timeSelected <= 0) {
        this.setState(
          {
            sliceFrom: 0,
            leftActive: false,
            rightActive: true,
            sliceTo: timeSelected,
          },
          () => this.refreshChart(),
        );
      } else {
        this.setState(
          {
            sliceFrom: sliceFrom - timeSelected,
            leftActive: true,
            rightActive: true,
            sliceTo: sliceTo - timeSelected,
          },
          () => this.refreshChart(),
        );
      }
    }
  };

  changeChartType = (value) => {
    this.setState(
      {
        chartType: value,
      },
      () => {
        this.props.changeChartType(value);
      },
    );
  };

  render() {
    return (
      <div className="chart">
        <StatisticsChartsLabels
          data={this.state.labelData}
          type={this.state.type}
          chartType={this.state.chartType}
          changeChartType={this.changeChartType}
        />
        <Row className="chart__row">
          <Col md={12}>
            <Chart
              dotOnClickHandler={this.dotOnClickHandler}
              labels={this.state.chartData.labels}
              data={this.state.chartData.views}
              timeSelected={this.state.timeSelected}
              changeDateTimeLeft={this.changeDateTimeLeft}
              changeDateTimeRight={this.changeDateTimeRight}
              leftActive={this.state.leftActive}
              rightActive={this.state.rightActive}
              labelName="Views: "
            />
          </Col>
        </Row>
      </div>
    );
  }
}

export default connect(mapStateToProps)(StatisticsChart);
