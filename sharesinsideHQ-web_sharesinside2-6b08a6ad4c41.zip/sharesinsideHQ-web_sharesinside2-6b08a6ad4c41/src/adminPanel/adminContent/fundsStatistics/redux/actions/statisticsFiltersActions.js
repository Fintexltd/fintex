import * as types from 'adminPanel/adminContent/fundsStatistics/redux/types';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_FUNDS_STATISTICS_FILTERS,
  SAVE_FUNDS_STATISTICS_FILTERS,
  SAVE_FUNDS_STATISTICS_DATE_RANGE,
} = types;

export const removeStatisticsFilters = createActionCreator(
  REMOVE_FUNDS_STATISTICS_FILTERS,
);

export const saveStatisticsFilters = createActionCreator(
  SAVE_FUNDS_STATISTICS_FILTERS,
  'filter',
);

export const saveStatisticsDateRange = createActionCreator(
  SAVE_FUNDS_STATISTICS_DATE_RANGE,
  'dateRange',
);
