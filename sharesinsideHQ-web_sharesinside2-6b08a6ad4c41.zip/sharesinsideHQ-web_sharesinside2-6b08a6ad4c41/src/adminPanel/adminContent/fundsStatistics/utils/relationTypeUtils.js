export default function getrelationType() {
  return [
    {
      label: 'VIP',
      value: 'vip',
      category: 'relation',
    },
    {
      label: 'Investor',
      value: 'shareholder',
      category: 'relation',
    },
    {
      label: 'Follower',
      value: 'follower',
      category: 'relation',
    },
    {
      label: 'Other',
      value: 'other',
      category: 'relation',
    },
  ];
}
