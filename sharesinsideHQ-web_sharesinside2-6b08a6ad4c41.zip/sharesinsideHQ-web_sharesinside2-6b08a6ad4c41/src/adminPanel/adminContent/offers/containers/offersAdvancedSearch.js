import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import OffersAdvancedSearchView from 'adminPanel/adminContent/offers/components/offersAdvancedSearchView';
import { fetchOffers } from 'common/redux/actions/offersActions';
import { saveOffersFilters } from 'common/redux/actions/offersFiltersActions';

const mapStateToProps = state => ({
  offersFilters: state.offersFilters,
  countriesList: state.countries.list,
});

const mapDispatchToProps = dispatch => ({
  getOffers: bindActionCreators(fetchOffers, dispatch),
  saveOffersFilters: bindActionCreators(saveOffersFilters, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
});

class OffersAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetOffers = debounce(props.getOffers, 500);
  }

  componentDidMount() {
    this.props.getCountriesList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveOffersFilters(values.length > 0 ? values : { category });
    this.debouncedGetOffers();
  };

  render() {
    return (
      <OffersAdvancedSearchView
        handleFilterUsage={this.handleFilterUsage}
        offersFilters={this.props.offersFilters}
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList ? this.props.countriesList : [],
          label: 'country_name',
          value: 'id',
          category: 'countries',
        })}
      />
    );
  }
}

OffersAdvancedSearch.propTypes = {
  getOffers: PropTypes.func.isRequired,
  saveOffersFilters: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OffersAdvancedSearch);
