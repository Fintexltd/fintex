import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import OffersSearchView from 'adminPanel/adminContent/offers/components/offersSearchView';
import { fetchOffers } from 'common/redux/actions/offersActions';
import {
  removeOffersFilters,
  saveOffersSearch,
  saveOffersFilters,
} from 'common/redux/actions/offersFiltersActions';

const mapStateToProps = state => ({
  offers: state.offers.list,
  offersFilters: state.offersFilters,
  resultsNumber: state.offers.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getOffers: bindActionCreators(fetchOffers, dispatch),
  removeOffersFilters: bindActionCreators(removeOffersFilters, dispatch),
  saveOffersSearch: bindActionCreators(saveOffersSearch, dispatch),
  saveOffersFilters: bindActionCreators(saveOffersFilters, dispatch),
});

class OffersSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetOffers = debounce(props.getOffers, 500);
  }

  clearActiveFilters = () => {
    this.props.removeOffersFilters();
    this.debouncedGetOffers();
  };

  handleSearchInputChange = text => {
    this.props.saveOffersSearch(text);
    this.debouncedGetOffers();
  };

  mapActiveFiltersLists = () => [...this.props.offersFilters.countries];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.offersFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveOffersFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetOffers();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <OffersSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        offersFilters={this.props.offersFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

OffersSearch.defaultProps = {
  resultsNumber: null,
};

OffersSearch.propTypes = {
  getOffers: PropTypes.func.isRequired,
  removeOffersFilters: PropTypes.func.isRequired,
  saveOffersSearch: PropTypes.func.isRequired,
  saveOffersFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(OffersSearch);
