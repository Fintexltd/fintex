import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import OffersAdvancedSearch from 'adminPanel/adminContent/offers/containers/offersAdvancedSearch';
import './style.scss';

const OffersSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  offersFilters,
  handleFilterRemoveClick,
}) => (
  <div className="offers-search">
    <div className="offers-search__top">
      <div className="offers-search__top-left">
        <div className="offers-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={offersFilters.search}
          />
        </div>
        <div className="offers-search__search-input">
          <OffersAdvancedSearch />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="offers-search__clear-filters-button">
          <div className="offers-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="offers-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    <div className="offers-search__results-container">
      <div className="offers-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

OffersSearchView.defaultProps = {
  resultsNumber: null,
};

OffersSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default OffersSearchView;
