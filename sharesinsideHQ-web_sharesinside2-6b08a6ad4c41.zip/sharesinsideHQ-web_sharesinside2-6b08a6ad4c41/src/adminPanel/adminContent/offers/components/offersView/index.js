import React from 'react';
import { Row, Col } from 'reactstrap';
import shortid from 'shortid';
import OffersSearch from 'adminPanel/adminContent/offers/containers/offersSearch';
import OfferItem from 'common/components/offerItem';
import NewOfferButton from 'adminPanel/adminContent/offers/components/newOfferButton';
import './style.scss';

const OffersView = ({
  offersList,
  removeOffer,
  nextPageIndex,
  handleLoadMoreClick,
  isOffersFiltersActive,
}) => (
  <div className="admin-offers">
    <div className="admin-offers__header">
      <h2>Manage job offers</h2>
    </div>
    <OffersSearch />
    <div className="admin-offers__content">
      <Row>
        <Col md={6}>
          <NewOfferButton />
        </Col>
        {offersList.length > 0 &&
          offersList.map(offer => (
            <Col md={6} key={shortid.generate()}>
              <OfferItem inAdminView offer={offer} removeOffer={removeOffer} />
            </Col>
          ))}
      </Row>
    </div>
    {offersList.length === 0 &&
      isOffersFiltersActive() && (
        <div className="admin-offers__empty-container">
          <p className="admin-offers__empty">
            There are no job offers matching this criteria
          </p>
        </div>
      )}
    {nextPageIndex && (
      <div className="admin-offers__load-container">
        <button onClick={handleLoadMoreClick} className="admin-offers__load">
          Load more
        </button>
      </div>
    )}
  </div>
);

export default OffersView;
