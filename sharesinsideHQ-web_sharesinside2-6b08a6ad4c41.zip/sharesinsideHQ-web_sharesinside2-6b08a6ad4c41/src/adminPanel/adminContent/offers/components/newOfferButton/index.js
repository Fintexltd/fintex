import React from 'react';
import { Link } from 'react-router-dom';
import plus from 'assets/icons/add_icon_big_white.svg';
import './style.scss';

const NewOfferButton = () => (
  <Link className="new-offer-button" to="/admin/management/add-offer">
    <div className="new-offer-button__content">
      <img src={plus} height={60} alt="" />
      <span>Add new offer</span>
    </div>
  </Link>
);

export default NewOfferButton;
