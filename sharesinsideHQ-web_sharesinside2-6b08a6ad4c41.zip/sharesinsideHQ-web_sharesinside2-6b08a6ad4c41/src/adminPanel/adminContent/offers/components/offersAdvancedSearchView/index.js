import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import './style.scss';

const OffersAdvancedSearchView = ({
  offersFilters,
  handleFilterUsage,
  countriesList,
}) => (
  <div className="offers-advanced-search">
    <div className="offers-advanced-search__filters">
      <div className="offers-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Region"
          onChange={handleFilterUsage}
          value={offersFilters.countries}
          category="countries"
        />
      </div>
    </div>
  </div>
);

OffersAdvancedSearchView.propTypes = {
  handleFilterUsage: PropTypes.func.isRequired,
};

export default OffersAdvancedSearchView;
