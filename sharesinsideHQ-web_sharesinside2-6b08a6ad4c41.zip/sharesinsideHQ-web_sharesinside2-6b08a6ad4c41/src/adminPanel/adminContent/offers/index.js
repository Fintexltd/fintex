import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import OffersView from 'adminPanel/adminContent/offers/components/offersView';
import { fetchOffers } from 'common/redux/actions/offersActions';
import { saveOffersFilters } from 'common/redux/actions/offersFiltersActions';
import { deleteJobOffer } from 'adminPanel/api/offersApi';

const mapStateToProps = state => ({
  offersList: state.offers.data,
  offersFilters: state.offersFilters,
  token: state.auth.token,
  userData: state.userData.data,
  resultsNumber: state.offers.resultsNumber,
  nextPageIndex: state.offers.nextPageIndex,
  isLoading: state.offers.isLoading,
});

const mapDispatchToProps = dispatch => ({
  getOffersList: bindActionCreators(fetchOffers, dispatch),
  saveOffersFilters: bindActionCreators(saveOffersFilters, dispatch),
});

class AdminOffers extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    this.props.getOffersList();
  }

  isOffersFiltersActive = () => {
    const { countries, search } = this.props.offersFilters;
    return countries.length > 0 || search !== '';
  };

  removeOffer = id => {
    deleteJobOffer(id).then(() => {
      this.props.getOffersList();
    });
  };

  handleLoadMoreClick = () => {
    if (!this.props.isLoading) {
      this.props.getOffersList(this.props.nextPageIndex);
    }
  };

  render() {
    return (
      <OffersView
        offersList={this.props.offersList}
        removeOffer={this.removeOffer}
        nextPageIndex={this.props.nextPageIndex}
        handleLoadMoreClick={this.handleLoadMoreClick}
        isOffersFiltersActive={this.isOffersFiltersActive}
      />
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(AdminOffers);
