import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import InvestorsAdvancedSearch from 'adminPanel/adminContent/investors/containers/investorsAdvancedSearch';
import './index.scss';

const InvestorsSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isAdvancedSearchVisible,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  toggleAdvancedSearch,
  investorsFilters,
  handleFilterRemoveClick,
}) => (
  <div className="investors-requests-search">
    <div className="investors-requests-search__top">
      <div className="investors-requests-search__top-left">
        <div className="investors-requests-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={investorsFilters.search}
          />
        </div>
        <div className="investors-requests-search__filters-button">
          <ToggleMoreFiltersButton
            handleToggleMoreFiltersClick={toggleAdvancedSearch}
            isMoreFiltersVisible={isAdvancedSearchVisible}
          />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="investors-requests-search__clear-filters-button">
          <div className="investors-requests-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="investors-requests-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    {isAdvancedSearchVisible && <InvestorsAdvancedSearch />}
    <div className="investors-requests-search__results-container">
      <div className="investors-requests-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

InvestorsSearchView.defaultProps = {
  resultsNumber: null,
};

InvestorsSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isAdvancedSearchVisible: PropTypes.bool.isRequired,
  toggleAdvancedSearch: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default InvestorsSearchView;
