import React, { Component } from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import './index.scss';

// NOTE: Here I define sizes necessary to calculate
// correct investors navigation width
const barAndMarginsWidth = 420;
const largeBreakpointWidth = 992;
const wideScreen = 1540;

class InvestorsNavigation extends Component {
  constructor() {
    super();
    this.state = {
      width: null,
    };
    this.navRef = React.createRef();
  }

  componentDidMount() {
    this.setScreenWidth();
    window.addEventListener('resize', this.setScreenWidth);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.setScreenWidth);
  }

  setScreenWidth = () => {
    this.setState({ width: window.innerWidth });
  };

  render() {
    if (window.innerWidth < 500) {
      this.navRef.current.scrollLeft = '140';
    }
    return (
      <div
        ref={this.navRef}
        className="investors-navigation"
        style={{
          width:
            this.state.width >= largeBreakpointWidth &&
            this.state.width < wideScreen
              ? this.state.width - barAndMarginsWidth
              : '100%',
        }}
      >
        <LinkContainer
          to="/admin/requests/investors/funds"
          replace
          className="investors-navigation__item"
          activeClassName="investors-navigation__item--active"
        >
          <span>Funds</span>
        </LinkContainer>
        <LinkContainer
          to="/admin/requests/investors/startups"
          replace
          className="investors-navigation__item"
          activeClassName="investors-navigation__item--active"
        >
          <span>Startups</span>
        </LinkContainer>
      </div>
    );
  }
}

export default InvestorsNavigation;
