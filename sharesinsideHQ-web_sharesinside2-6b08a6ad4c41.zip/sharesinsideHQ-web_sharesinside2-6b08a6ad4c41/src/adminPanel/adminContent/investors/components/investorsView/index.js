import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import InvestorsSearch from 'adminPanel/adminContent/investors/containers/investorsSearch';
import Pagination from 'common/components/pagination';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import AcceptButton from 'common/components/acceptButton';
import RejectButton from 'common/components/rejectButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import shortid from 'shortid';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import './index.scss';
import InvestorsNavigation from '../investorsNavigation';

const InvestorsView = ({
  investors,
  acceptInvestor,
  rejectInvestor,
  showBlockInvestorModal,
  handleCheckboxClick,
  checkedInvestors,
  handleCheckAllInvestorsClick,
  handleClearSelectionClick,
  acceptMultipleRequests,
  rejectMultipleRequests,
  isInvestorsFiltersActive,
  getInvestors,
  resultsNumber,
  meta,
  saveInvestorsFilters,
  userData,
}) => (
  <div className="investors-requests">
    <h1 className="investors-requests__heading">Investor requests</h1>

    {userData.is_global_admin ||
    ((userData.is_primary_admin_fund ||
      userData.is_primary_admin_funds_manager ||
      userData.is_secondary_admin_fund ||
      userData.is_secondary_admin_funds_manager) &&
      (userData.is_primary_admin_startup ||
        userData.is_secondary_admin_startup)) ? (
          <InvestorsNavigation />
    ) : (
      <div />
    )}

    <InvestorsSearch />
    <div className="investors-requests__filter-buttons">
      {checkedInvestors.length !== investors.length && (
        <CheckButton
          description="Check all"
          handleClick={handleCheckAllInvestorsClick}
        />
      )}
      {checkedInvestors.length > 0 && (
        <>
          <div className="investors-requests__clear-button">
            <ClearButton
              description="Clear selection"
              handleClick={handleClearSelectionClick}
            />
          </div>
          <div className="investors-requests__accept-button">
            <AcceptButton
              handleClick={acceptMultipleRequests}
              description="Accept checked"
            />
          </div>
          <RejectButton
            handleClick={rejectMultipleRequests}
            description="Reject checked"
          />
        </>
      )}
    </div>
    <table className="investors-requests__table">
      <thead className="investors-requests__thead">
        <tr>
          <th>User Data</th>
          {userData &&
            checkUserPermission(
              userData,
              PERMISSIONS_FUNCTION_TYPES.VIEW_USER_LOGIN_DATA,
            ) && <th />}
          <th>Fund</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {investors.map((investor) => (
          <tr
            key={shortid.generate()}
            className="investors-requests__investor-row"
          >
            <td>
              <div className="investors-requests__user-data">
                <AcceptCheckbox
                  name={`${investor.id}`}
                  id={`${investor.id}`}
                  onChange={handleCheckboxClick}
                  checked={checkedInvestors.includes(investor.id)}
                />
                <div>
                  <p className="investors-requests__name">
                    {investor.first_name} 
                    {' '}
                    {investor.last_name}
                  </p>
                  <p className="investors-requests__name">
                    {investor.user_email}
                  </p>
                  <p className="investors-requests__name">
                    {investor.phone_number}
                  </p>
                  <p className="investors-requests__name">
                    {investor.birth_date}
                  </p>
                </div>
              </div>
            </td>
            {userData &&
              checkUserPermission(
                userData,
                PERMISSIONS_FUNCTION_TYPES.VIEW_USER_LOGIN_DATA,
              ) && (
                <td>
                  <p className="investors-requests__name">{investor.address}</p>
                  <p className="investors-requests__name">
                    {investor.post_code}
                    ,
                    {investor.city}
                  </p>
                  <p className="investors-requests__name">
                    {investor.country.country_name}
                  </p>
                  <p className="investors-requests__name">
                    {investor.login_method[0]
                      ? investor.login_method[0].charAt(0).toUpperCase() +
                        investor.login_method[0].slice(1)
                      : ''}
                    {investor.login_method[1]
                      ? `, ${
                          investor.login_method[1].charAt(0).toUpperCase() +
                          investor.login_method[1].slice(1)
                        }`
                      : ''}
                  </p>
                  <p className="investors-requests__name">
                    Accept terms:
                    {' '}
                    {moment.unix(investor.accept_terms).format('DD.MM.YY')}
                  </p>
                </td>
              )}
            <td>
              <p className="investors-requests__name">
                {investor.fund ? investor.fund.name : investor.startup.name}
              </p>
            </td>
            <td>
              <div className="investors-requests__buttons">
                <button
                  onClick={() => acceptInvestor(investor.id)}
                  className="investors-requests__button investors-requests__button--accept"
                >
                  Accept
                </button>
                <button
                  onClick={() => rejectInvestor(investor.id)}
                  className="investors-requests__button investors-requests__button--reject"
                >
                  Reject
                </button>
                <button
                  onClick={() => showBlockInvestorModal(investor.id)}
                  className="investors-requests__button investors-requests__button--block"
                >
                  Block
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    {isInvestorsFiltersActive() && investors.length === 0 && (
      <div className="investors-requests__empty-list">
        <p className="investors-requests__empty-list-message">
          There are no investors matching these criteria
        </p>
      </div>
    )}
    <Pagination
      meta={meta}
      resultsNumber={resultsNumber}
      saveFilters={saveInvestorsFilters}
      getResults={getInvestors}
    />
  </div>
);

InvestorsView.defaultProps = {
  resultsNumber: null,
};

InvestorsView.propTypes = {
  investors: PropTypes.arrayOf(PropTypes.object).isRequired,
  showBlockInvestorModal: PropTypes.func.isRequired,
  acceptInvestor: PropTypes.func.isRequired,
  checkedInvestors: PropTypes.arrayOf(PropTypes.number).isRequired,
  handleCheckAllInvestorsClick: PropTypes.func.isRequired,
  handleClearSelectionClick: PropTypes.func.isRequired,
  acceptMultipleRequests: PropTypes.func.isRequired,
  getInvestors: PropTypes.func.isRequired,
  saveInvestorsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default InvestorsView;
