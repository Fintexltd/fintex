import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import getLoginMethodList from 'adminPanel/adminContent/shareholders/utils/loginMethodTypeUtils';
import './index.scss';

const InvestorsAdvancedSearchView = ({
  investorsFilters,
  countriesList,
  fundsList,
  handleFilterUsage,
}) => (
  <div className="investors-requests-advanced-search">
    <div className="investors-requests-advanced-search__filters">
      <div className="investors-requests-advanced-search__filter">
        <MultiSelect
          options={fundsList}
          description="Fund"
          onChange={handleFilterUsage}
          value={investorsFilters.fund}
          category="fund"
          isSearchable
        />
      </div>
      <div className="investors-requests-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={investorsFilters.country}
          category="country"
          isSearchable
        />
      </div>
      <div className="investors-requests-advanced-search__filter">
        <MultiSelect
          options={getLoginMethodList()}
          description="Login method"
          onChange={handleFilterUsage}
          value={investorsFilters.loginMethod}
          category="loginMethod"
        />
      </div>
    </div>
  </div>
);

InvestorsAdvancedSearchView.defaultProps = {
  countriesList: [],
  fundsList: [],
};

InvestorsAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  fundsList: PropTypes.arrayOf(PropTypes.object),
  handleFilterUsage: PropTypes.func.isRequired,
};

export default InvestorsAdvancedSearchView;
