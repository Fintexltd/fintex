import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchInvestors from 'adminPanel/adminContent/investors/redux/actions/investorsActions';
import { saveInvestorsFilters } from 'adminPanel/adminContent/investors/redux/actions/investorsFiltersActions';
import InvestorsView from 'adminPanel/adminContent/investors/components/investorsView';
import BlockModal from 'common/components/blockModal';
import { disableScroll } from 'common/utils/disableScroll';
import {
  acceptInvestor,
  rejectInvestor,
  blockInvestor,
  acceptMultipleInvestors,
  rejectMultipleInvestors,
} from 'adminPanel/adminContent/investors/api/investorsApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';

const mapStateToProps = (state) => ({
  investors: state.investors.data,
  investorsFilters: state.investorsFilters,
  token: state.auth.token,
  userData: state.userData.data,
  meta: state.investors.meta,
  resultsNumber: state.investors.resultsNumber,
});

const mapDispatchToProps = (dispatch) => ({
  getInvestors: bindActionCreators(fetchInvestors, dispatch),
  saveInvestorsFilters: bindActionCreators(saveInvestorsFilters, dispatch),
});

class AdminInvestors extends Component {
  constructor() {
    super();
    this.state = {
      checkedInvestors: [],
      isBlockModalVisible: false,
      idToBlock: null,
    };
  }

  UNSAFE_componentWillMount() {
    const locale = this.props.location.pathname.split('/')[4];
    if (locale !== 'funds' && locale !== 'startups') {
      this.props.history.push('/admin/requests/investors/funds');
    } else {
      this.props.saveInvestorsFilters({
        category: 'type',
        value: locale,
      });
    }
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');
    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_INVESTOR_REQUESTS,
      )
    )
      this.props.history.push('/admin/fundsmanager/management');

    if (this.props.investors.length === 0) {
      this.props.getInvestors();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_INVESTOR_REQUESTS,
      )
    )
      this.props.history.push('/admin/fundsmanager/management');

    const nextLocation = nextProps.location.pathname.split('/')[4];
    const location = this.props.location.pathname.split('/')[4];
    const nextType = nextProps.investorsFilters.type;
    const { type } = this.props.investorsFilters;
    if (nextLocation !== location) {
      this.props.saveInvestorsFilters({
        category: 'type',
        value: nextLocation,
      });
    }
    if (nextType && nextType !== type) {
      this.props.getInvestors();
    }
  }

  handleInvestorsCheckboxClick = (value) => {
    let { checkedInvestors } = this.state;
    if (value.target.checked) {
      checkedInvestors.push(Number(value.target.id));
    } else {
      checkedInvestors = this.state.checkedInvestors.filter(
        (id) => id !== Number(value.target.id),
      );
    }
    this.setState({ checkedInvestors });
  };

  acceptInvestor = (id) => {
    acceptInvestor(id).then(() => {
      this.props.getInvestors(this.props.meta.current_page);
    });
  };

  acceptMultipleRequests = () => {
    acceptMultipleInvestors(this.state.checkedInvestors).then(() => {
      this.props.getInvestors(this.props.meta.current_page);
      this.setState({ checkedInvestors: [] });
    });
  };

  rejectInvestor = (id) => {
    rejectInvestor(id).then(() => {
      this.props.getInvestors(this.props.meta.current_page);
    });
  };

  rejectMultipleRequests = () => {
    rejectMultipleInvestors(this.state.checkedInvestors).then(() => {
      this.props.getInvestors(this.props.meta.current_page);
      this.setState({ checkedInvestors: [] });
    });
  };

  showBlockInvestorModal = (id) => {
    this.setState({ idToBlock: id });
    this.toggleBlockModal();
  };

  blockInvestor = () => {
    blockInvestor(this.state.idToBlock).then(() => {
      this.props.getInvestors(this.props.meta.current_page).then(() => {
        this.toggleBlockModal();
      });
    });
  };

  toggleBlockModal = () =>
    this.setState(
      (prevState) => ({ isBlockModalVisible: !prevState.isBlockModalVisible }),
      () => disableScroll(this.state.isBlockModalVisible),
    );

  handleCheckAllInvestorsClick = () => {
    const ids = this.props.investors.map((fund) => fund.id);
    this.setState({ checkedInvestors: ids });
  };

  handleClearSelectionClick = () => {
    this.setState({ checkedInvestors: [] });
  };

  isInvestorsFiltersActive = () => {
    const { fund, country, loginMethod, search } = this.props.investorsFilters;
    return (
      fund.length > 0 ||
      country.length > 0 ||
      loginMethod.length > 0 ||
      search !== ''
    );
  };

  render() {
    return (
      <>
        <InvestorsView
          investors={this.props.investors}
          acceptInvestor={this.acceptInvestor}
          rejectInvestor={this.rejectInvestor}
          showBlockInvestorModal={this.showBlockInvestorModal}
          handleCheckboxClick={this.handleInvestorsCheckboxClick}
          checkedInvestors={this.state.checkedInvestors}
          handleCheckAllInvestorsClick={this.handleCheckAllInvestorsClick}
          handleClearSelectionClick={this.handleClearSelectionClick}
          acceptMultipleRequests={this.acceptMultipleRequests}
          rejectMultipleRequests={this.rejectMultipleRequests}
          isInvestorsFiltersActive={this.isInvestorsFiltersActive}
          getInvestors={this.props.getInvestors}
          saveInvestorsFilters={this.props.saveInvestorsFilters}
          meta={this.props.meta}
          resultsNumber={this.props.resultsNumber}
          userData={this.props.userData}
        />
        {this.state.isBlockModalVisible && (
          <BlockModal
            heading="Are you sure you want to block this user?"
            message="This user will be block immediately. You can't undo this action."
            handleBlockClick={this.blockInvestor}
            handleCancelClick={this.toggleBlockModal}
          />
        )}
      </>
    );
  }
}

AdminInvestors.defaultProps = {
  investors: [],
  resultsNumber: null,
};

AdminInvestors.propTypes = {
  investors: PropTypes.arrayOf(PropTypes.object),
  getInvestors: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  investorsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  saveInvestorsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminInvestors));
