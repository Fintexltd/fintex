import axios from 'axios';

export const acceptInvestor = id =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/shareholders/${id}`,
    data: {
      _method: 'put',
      action: 'accept',
    },
  });

export const rejectInvestor = id =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/shareholders/${id}`,
    data: {
      _method: 'put',
      action: 'reject',
    },
  });

export const blockInvestor = id =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/shareholders/${id}`,
    data: {
      _method: 'put',
      action: 'block',
    },
  });

export const acceptMultipleInvestors = ids =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/shareholders/mass-update`,
    data: {
      _method: 'put',
      action: 'accept',
      shareholders: ids,
    },
  });

export const rejectMultipleInvestors = ids =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/shareholders/mass-update`,
    data: {
      _method: 'put',
      action: 'reject',
      shareholders: ids,
    },
  });
