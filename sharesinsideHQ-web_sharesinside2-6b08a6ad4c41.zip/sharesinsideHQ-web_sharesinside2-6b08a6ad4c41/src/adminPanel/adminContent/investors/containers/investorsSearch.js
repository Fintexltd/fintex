import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import InvestorsSearchView from 'adminPanel/adminContent/investors/components/investorsSearchView';
import fetchInvestors from 'adminPanel/adminContent/investors/redux/actions/investorsActions';
import {
  removeInvestorsFilters,
  saveInvestorsSearch,
  saveInvestorsFilters,
} from 'adminPanel/adminContent/investors/redux/actions/investorsFiltersActions';

const mapStateToProps = state => ({
  investors: state.investors.list,
  investorsFilters: state.investorsFilters,
  resultsNumber: state.investors.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getInvestors: bindActionCreators(fetchInvestors, dispatch),
  removeInvestorsFilters: bindActionCreators(removeInvestorsFilters, dispatch),
  saveInvestorsSearch: bindActionCreators(saveInvestorsSearch, dispatch),
  saveInvestorsFilters: bindActionCreators(saveInvestorsFilters, dispatch),
});

class InvestorsSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetInvestors = debounce(props.getInvestors, 500);
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeInvestorsFilters();
    this.debouncedGetInvestors();
  };

  handleSearchInputChange = text => {
    this.props.saveInvestorsSearch(text);
    this.debouncedGetInvestors();
  };

  mapActiveFiltersLists = () => [
    ...this.props.investorsFilters.loginMethod,
    ...this.props.investorsFilters.fund,
    ...this.props.investorsFilters.country,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.investorsFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveInvestorsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetInvestors();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <InvestorsSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        investorsFilters={this.props.investorsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

InvestorsSearch.defaultProps = {
  resultsNumber: null,
};

InvestorsSearch.propTypes = {
  getInvestors: PropTypes.func.isRequired,
  removeInvestorsFilters: PropTypes.func.isRequired,
  saveInvestorsSearch: PropTypes.func.isRequired,
  saveInvestorsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(InvestorsSearch);
