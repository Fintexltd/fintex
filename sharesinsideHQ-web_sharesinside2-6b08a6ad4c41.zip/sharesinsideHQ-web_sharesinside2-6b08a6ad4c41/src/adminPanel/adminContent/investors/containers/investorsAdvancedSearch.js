import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import InvestorsAdvancedSearchView from 'adminPanel/adminContent/investors/components/investorsAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchInvestors from 'adminPanel/adminContent/investors/redux/actions/investorsActions';
import fetchFundsNames from 'common/redux/actions/fundsNamesActions';
import { saveInvestorsFilters } from 'adminPanel/adminContent/investors/redux/actions/investorsFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  investorsFilters: state.investorsFilters,
  fundsNames: state.fundsNames.list,
});

const mapDispatchToProps = dispatch => ({
  getInvestors: bindActionCreators(fetchInvestors, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  saveInvestorsFilters: bindActionCreators(saveInvestorsFilters, dispatch),
  getFundsNames: bindActionCreators(fetchFundsNames, dispatch),
});

class InvestorsAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetInvestors = debounce(props.getInvestors, 500);
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getFundsNames(null);
  }

  handleFilterUsage = (values, category) => {
    this.props.saveInvestorsFilters(values.length > 0 ? values : { category });
    this.debouncedGetInvestors();
  };

  render() {
    return (
      <InvestorsAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList ? this.props.countriesList : [],
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        fundsList={mapObjPropsToSelectFilter({
          list: this.props.fundsNames ? this.props.fundsNames : [],
          label: 'name',
          value: 'id',
          category: 'fund',
        })}
        handleFilterUsage={this.handleFilterUsage}
        investorsFilters={this.props.investorsFilters}
      />
    );
  }
}

InvestorsAdvancedSearch.propTypes = {
  getCountriesList: PropTypes.func.isRequired,
  getInvestors: PropTypes.func.isRequired,
  saveInvestorsFilters: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(InvestorsAdvancedSearch);
