import { createReducer } from 'common/utils/reduxUtils';
import {
  FETCH_INVESTORS_REQUESTS_SUCCESS,
  UPDATE_INVESTORS_REQUESTS,
} from 'adminPanel/adminContent/investors/redux/types';

const initialState = {
  data: [],
  nextPageIndex: null,
  resultsNumber: null,
  meta: {},
};

const InvestorsReducer = createReducer(
  { ...initialState },
  {
    [FETCH_INVESTORS_REQUESTS_SUCCESS]: (state, action) => {
      const { data, meta } = action.payload.data;
      const hasNextPage = meta.current_page < meta.last_page;

      return {
        ...state,
        data: [...data],
        meta,
        nextPageIndex: hasNextPage ? meta.current_page + 1 : null,
        resultsNumber: meta.total,
      };
    },
    [UPDATE_INVESTORS_REQUESTS]: (state, action) => ({
      ...state,
      list: action.payload.updatedCompaniesRequests,
    }),
  },
);

export default InvestorsReducer;
