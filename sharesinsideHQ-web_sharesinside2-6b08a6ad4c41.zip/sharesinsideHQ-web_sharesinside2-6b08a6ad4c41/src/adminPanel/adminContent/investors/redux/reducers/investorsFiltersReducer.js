import { createReducer } from 'common/utils/reduxUtils';
import {
  REMOVE_INVESTORS_REQUESTS_FILTERS,
  SAVE_INVESTORS_REQUESTS_FILTERS,
  SAVE_INVESTORS_REQUESTS_SEARCH,
} from 'adminPanel/adminContent/investors/redux/types';

const initialState = {
  fund: [],
  startup: [],
  country: [],
  loginMethod: [],
  type: 'funds',
  search: '',

  per_page: 10,
};

const InvestorsFiltersReducer = createReducer(
  { ...initialState },
  {
    [SAVE_INVESTORS_REQUESTS_FILTERS]: (state, action) => {
      if (action.payload.filter.category === 'per_page') {
        return {
          ...state,
          per_page: action.payload.filter.value,
        };
      }
      if (action.payload.filter.category === 'type') {
        return {
          ...state,
          type: action.payload.filter.value,
        };
      }
      if (action.payload.filter && action.payload.filter[0]) {
        const { category } = action.payload.filter[0];
        return {
          ...state,
          [category]: action.payload.filter,
        };
      }
      if (action.payload.filter.category) {
        const { category } = action.payload.filter;
        return {
          ...state,
          [category]: [],
        };
      }
      return {
        ...state,
      };
    },
    [REMOVE_INVESTORS_REQUESTS_FILTERS]: (state) => ({
      ...state,
      fund: [],
      country: [],
      loginMethod: [],
    }),
    [SAVE_INVESTORS_REQUESTS_SEARCH]: (state, action) => ({
      ...state,
      search: action.payload.search,
    }),
  },
);

export default InvestorsFiltersReducer;
