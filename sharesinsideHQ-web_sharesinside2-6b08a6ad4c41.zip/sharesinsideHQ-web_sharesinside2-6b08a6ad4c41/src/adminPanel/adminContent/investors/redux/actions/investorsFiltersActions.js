import * as types from 'adminPanel/adminContent/investors/redux/types';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_INVESTORS_REQUESTS_FILTERS,
  SAVE_INVESTORS_REQUESTS_FILTERS,
  SAVE_INVESTORS_REQUESTS_SEARCH,
} = types;

export const removeInvestorsFilters = createActionCreator(
  REMOVE_INVESTORS_REQUESTS_FILTERS,
);

export const saveInvestorsFilters = createActionCreator(
  SAVE_INVESTORS_REQUESTS_FILTERS,
  'filter',
);

export const saveInvestorsSearch = createActionCreator(
  SAVE_INVESTORS_REQUESTS_SEARCH,
  'search',
);
