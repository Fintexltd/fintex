import axios from 'axios';
import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/investors/redux/types.js';

const {
  FETCH_INVESTORS_REQUESTS_REQUEST,
  FETCH_INVESTORS_REQUESTS_SUCCESS,
  FETCH_INVESTORS_REQUESTS_FAILURE,
} = types;

const fetchInvestorsRequest = createActionCreator(
  FETCH_INVESTORS_REQUESTS_REQUEST,
);
const fetchInvestorsSuccess = createActionCreator(
  FETCH_INVESTORS_REQUESTS_SUCCESS,
  'data',
);
const fetchInvestorsFailure = createActionCreator(
  FETCH_INVESTORS_REQUESTS_FAILURE,
);

const fetchInvestors = (page = 1) => (dispatch, getState) => {
  const {
    fund,
    country,
    search,
    loginMethod,
    type,
  } = getState().investorsFilters;

  const getSelectedFiltersIds = (filters) =>
    filters.map((filter) => filter.value);

  dispatch(fetchInvestorsRequest());

  return axios
    .get(
      `${process.env.REACT_APP_API_URL}/${
        type === 'startups' ? 'startup-' : ''
      }investors/admin/requests`,
      {
        params: {
          page,
          search,
          per_page: getState().investorsFilters.per_page,
          fund: getSelectedFiltersIds(fund),
          login_method: getSelectedFiltersIds(loginMethod),
          country: getSelectedFiltersIds(country),
        },
      },
    )
    .then((response) => {
      dispatch(fetchInvestorsSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchInvestorsFailure());
    });
};

export default fetchInvestors;
