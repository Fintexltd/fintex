import { useSelector } from 'react-redux';
import useDemoStartupsFilters from '../demoStartupsSearch/useDemoStartupsFilters';

const useNoDataInfo = () => {
  const resultsNumber = useSelector(
    (state) => state.demoStartups.resultsNumber,
  );

  const {
    isRemoveFiltersButtonVisible,
    demoStartupsFilters,
  } = useDemoStartupsFilters();

  const isAnyFilterSelected =
    isRemoveFiltersButtonVisible || demoStartupsFilters.search;

  return {
    resultsNumber,
    isAnyFilterSelected,
  };
};

export default useNoDataInfo;
