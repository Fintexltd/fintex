import { useMemo } from 'react';
import { useSelector } from 'react-redux';

const useDemoStartupsFilters = () => {
  const demoStartupsFilters = useSelector((state) => state.demoStartupsFilters);

  const activeFiltersList = useMemo(
    () => [
      ...demoStartupsFilters.country,
      ...demoStartupsFilters.category,
      ...demoStartupsFilters.continent,
      ...demoStartupsFilters.equityFund,
      ...demoStartupsFilters.relations,
    ],
    [
      demoStartupsFilters.country,
      demoStartupsFilters.category,
      demoStartupsFilters.continent,
      demoStartupsFilters.equityFund,
      demoStartupsFilters.relations,
    ],
  );

  const isRemoveFiltersButtonVisible = activeFiltersList.length > 0;

  return {
    demoStartupsFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  };
};

export default useDemoStartupsFilters;
