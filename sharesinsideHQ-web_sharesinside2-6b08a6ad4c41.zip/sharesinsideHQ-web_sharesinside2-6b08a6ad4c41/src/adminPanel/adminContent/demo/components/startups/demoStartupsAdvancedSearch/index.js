import React from 'react';
import 'adminPanel/adminContent/common/styles/advancedSearch.scss';
import CountryFilter from 'adminPanel/adminContent/common/components/filters/CountryFilter';
import ContinentFilter from 'adminPanel/adminContent/common/components/filters/ContinentFilter';
import StartupCategoryFilter from 'adminPanel/adminContent/common/components/filters/StartupCategoryFilter';
import EquityFundFilter from 'adminPanel/adminContent/common/components/filters/EquityFundFilter';
import DataLoader from './dataLoader';

const DemoStartupsAdvancedSearch = ({
  demoStartupsFilters,
  handleFilterUsage,
}) => {
  return (
    <div className="admin-advanced-search">
      <DataLoader />
      <div className="admin-advanced-search__filters">
        <StartupCategoryFilter
          handleFilterUsage={handleFilterUsage}
          value={demoStartupsFilters.category}
        />
        <EquityFundFilter
          handleFilterUsage={handleFilterUsage}
          value={demoStartupsFilters.equityFund}
        />
        <CountryFilter
          handleFilterUsage={handleFilterUsage}
          value={demoStartupsFilters.country}
        />
        <ContinentFilter
          handleFilterUsage={handleFilterUsage}
          value={demoStartupsFilters.continent}
        />
      </div>
    </div>
  );
};

export default DemoStartupsAdvancedSearch;
