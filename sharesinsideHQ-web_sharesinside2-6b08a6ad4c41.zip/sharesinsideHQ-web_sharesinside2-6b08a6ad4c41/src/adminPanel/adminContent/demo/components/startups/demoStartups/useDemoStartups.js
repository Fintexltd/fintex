import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchDemoStartups,
  setDemoStartup,
} from 'adminPanel/adminContent/demo/redux/actions/demoStartupsActions';
import { saveDemoStartupsFilters as saveDemoStartupsFiltersAction } from 'adminPanel/adminContent/demo/redux/actions/demoStartupsFiltersActions';

const useDemoEquities = () => {
  const dispatch = useDispatch();
  const demoStartups = useSelector((state) => state.demoStartups.list);
  const meta = useSelector((state) => state.demoStartups.meta);
  const resultsNumber = useSelector(
    (state) => state.demoStartups.resultsNumber,
  );

  const getDemoStartups = useCallback(
    (page = 1) => {
      dispatch(fetchDemoStartups(page));
    },
    [dispatch],
  );

  const saveDemoStartupsFilters = (filters) => {
    dispatch(saveDemoStartupsFiltersAction(filters));
  };

  const handleCheckboxClick = (e, startupId) => {
    const { checked, value } = e.target;
    dispatch(setDemoStartup(startupId, checked ? 'append' : 'remove', value));
  };

  return {
    getDemoStartups,
    demoStartups,
    meta,
    resultsNumber,
    saveDemoStartupsFilters,
    handleCheckboxClick,
  };
};

export default useDemoEquities;
