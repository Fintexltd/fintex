import React from 'react';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import useDemoStartups from './useDemoStartups';
import DemoStartupsSearch from '../demoStartupsSearch';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import DataLoader from './dataLoader';
import DemoStartupsPagination from './DemoStartupsPagination';

const DemoStartups = () => {
  const {
    demoStartups,
    getDemoStartups,
    resultsNumber,
    meta,
    saveDemoStartupsFilters,
    handleCheckboxClick,
  } = useDemoStartups();

  return (
    <>
      <DataLoader />
      <DemoStartupsSearch />
      <div className="demo__table-container">
        <table className="demo__table">
          <thead className="demo__thead">
            <tr>
              <th>Startup</th>
              <th>Follower</th>
              <th>Shareholder</th>
              <th>VIP</th>
            </tr>
          </thead>
          <tbody>
            {demoStartups.map((startup) => (
              <tr key={startup.id} className="demo__item-row">
                <td>
                  <span className="demo__item-name">{startup.name}</span>
                </td>
                <td>
                  <AcceptCheckbox
                    name={`follower${startup.id}`}
                    id={`follower${startup.id}`}
                    onChange={(e) => handleCheckboxClick(e, startup.id)}
                    value="follower"
                    checked={startup.user_group.includes('follower')}
                  />
                </td>
                <td>
                  <AcceptCheckbox
                    name={`shareholder${startup.id}`}
                    id={`shareholder${startup.id}`}
                    onChange={(e) => handleCheckboxClick(e, startup.id)}
                    value="shareholder"
                    checked={startup.user_group.includes('shareholder')}
                  />
                </td>
                <td>
                  <AcceptCheckbox
                    name={`vip${startup.id}`}
                    id={`vip${startup.id}`}
                    onChange={(e) => handleCheckboxClick(e, startup.id)}
                    value="vip"
                    checked={startup.user_group.includes('vip')}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <LoadingIndicator />
      </div>
      <NoDataInfo />
      <DemoStartupsPagination
        meta={meta}
        resultsNumber={resultsNumber}
        saveFilters={saveDemoStartupsFilters}
        getResults={getDemoStartups}
      />
    </>
  );
};

export default DemoStartups;
