import { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  removeDemoStartupsFilters,
  saveDemoStartupsSearch,
  saveDemoStartupsFilters,
} from 'adminPanel/adminContent/demo/redux/actions/demoStartupsFiltersActions';
import { debounce } from 'lodash';
import useDemoStartupsFilters from './useDemoStartupsFilters';

const useDemoStartupsSearch = () => {
  const dispatch = useDispatch();

  const [isAdvancedSearchVisible, setAdvancedSearchVisible] = useState(false);

  const resultsNumber = useSelector(
    (state) => state.demoStartups.resultsNumber,
  );

  const {
    demoStartupsFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  } = useDemoStartupsFilters();

  const toggleAdvancedSearch = () => {
    setAdvancedSearchVisible(!isAdvancedSearchVisible);
  };

  const clearActiveFilters = () => {
    dispatch(removeDemoStartupsFilters());
  };

  const handleFilterUsage = (values, category) => {
    dispatch(
      saveDemoStartupsFilters(values.length > 0 ? values : { category }),
    );
  };

  const handleFilterRemoveClick = (label, category) => {
    const filteredOut = demoStartupsFilters[category].filter(
      (el) => el.label !== label,
    );
    dispatch(
      saveDemoStartupsFilters(
        filteredOut.length > 0 ? filteredOut : { category },
      ),
    );
  };

  return {
    resultsNumber,
    toggleAdvancedSearch,
    isAdvancedSearchVisible,
    clearActiveFilters,
    activeFiltersList,
    demoStartupsFilters,
    handleFilterRemoveClick,
    isRemoveFiltersButtonVisible,
    handleFilterUsage,
  };
};

const useDemoStartupsSearchTextInput = () => {
  const dispatch = useDispatch();

  const search = useSelector((state) => state.demoStartupsFilters.search);
  const [value, setValue] = useState(search);

  const debouncedSaveDemoStartupsSearch = useCallback(
    debounce((searchText) => dispatch(saveDemoStartupsSearch(searchText)), 500),
    [],
  );

  const handleSearchInputChange = useCallback(
    (newText) => {
      setValue(newText);
      debouncedSaveDemoStartupsSearch(newText);
    },
    [debouncedSaveDemoStartupsSearch],
  );

  return {
    handleSearchInputChange,
    value,
  };
};

export { useDemoStartupsSearch, useDemoStartupsSearchTextInput };
