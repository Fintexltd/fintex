import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchStartupCategoriesList from 'common/redux/actions/startupCategoriesListActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const countries = useSelector((state) => state.countries.list);
  const continents = useSelector((state) => state.continents.list);
  const categories = useSelector((state) => state.startupCategories.list);

  useEffect(() => {
    if (!countries) dispatch(fetchCountriesList());
  }, [dispatch, countries]);

  useEffect(() => {
    if (!continents) dispatch(fetchContinentsList());
  }, [dispatch, continents]);

  useEffect(() => {
    if (!categories) dispatch(fetchStartupCategoriesList());
  }, [dispatch, categories]);

  return null;
};

export default DataLoader;
