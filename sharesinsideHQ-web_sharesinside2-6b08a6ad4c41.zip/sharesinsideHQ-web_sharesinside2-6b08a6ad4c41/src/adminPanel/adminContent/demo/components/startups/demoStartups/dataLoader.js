import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDemoStartups } from 'adminPanel/adminContent/demo/redux/actions/demoStartupsActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const demoStartupsFilters = useSelector((state) => state.demoStartupsFilters);

  useEffect(() => {
    dispatch(fetchDemoStartups(1));
  }, [
    dispatch,
    demoStartupsFilters.country,
    demoStartupsFilters.category,
    demoStartupsFilters.continent,
    demoStartupsFilters.equityFund,
    demoStartupsFilters.relations,
    demoStartupsFilters.search,
  ]);

  return null;
};

export default DataLoader;
