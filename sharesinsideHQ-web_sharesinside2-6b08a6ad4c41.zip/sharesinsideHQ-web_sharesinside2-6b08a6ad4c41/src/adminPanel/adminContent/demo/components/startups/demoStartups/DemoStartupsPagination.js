import React from 'react';
import Pagination from 'common/components/pagination';
import { useSelector } from 'react-redux';

const DemoStartupsPagination = ({
  meta,
  resultsNumber,
  saveFilters,
  getResults,
}) => {
  const perPage = useSelector((state) => state.demoStartupsFilters.per_page);

  return (
    <Pagination
      meta={meta}
      resultsNumber={resultsNumber}
      saveFilters={saveFilters}
      getResults={getResults}
      perPage={perPage}
    />
  );
};

export default DemoStartupsPagination;
