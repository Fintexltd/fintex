import { useState, useEffect, useRef, useCallback } from 'react';

const useDemoNavigation = () => {
  const [width, setWidth] = useState(window.innerWidth);
  const navRef = useRef();

  const setScreenWidth = useCallback(() => {
    setWidth(window.innerWidth);
  }, [setWidth]);

  useEffect(() => {
    setScreenWidth();
    window.addEventListener('resize', setScreenWidth);
    return () => {
      window.removeEventListener('resize', setScreenWidth);
    };
  }, [setScreenWidth]);

  return { navRef, width };
};

export default useDemoNavigation;
