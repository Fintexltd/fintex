import React from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import useDemoNavigation from './useDemoNavigation';
import './index.scss';

// NOTE: Here I define sizes necessary to calculate correct investors navigation
// width
const barAndMarginsWidth = 420;
const largeBreakpointWidth = 992;
const wideScreen = 1540;

const DemoNavigation = () => {
  const { width, navRef } = useDemoNavigation();

  if (window.innerWidth < 500) {
    navRef.current.scrollLeft = '140';
  }
  return (
    <div
      ref={navRef}
      className="demo-navigation"
      style={{
        width:
          width >= largeBreakpointWidth && width < wideScreen
            ? width - barAndMarginsWidth
            : '100%',
      }}
    >
      <LinkContainer
        to="/admin/management/demo/equities"
        replace
        className="demo-navigation__item"
        activeClassName="demo-navigation__item--active"
      >
        <span>Equities</span>
      </LinkContainer>
      <LinkContainer
        to="/admin/management/demo/startups"
        replace
        className="demo-navigation__item"
        activeClassName="demo-navigation__item--active"
      >
        <span>Startups</span>
      </LinkContainer>
    </div>
  );
};

export default DemoNavigation;
