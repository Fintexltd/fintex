import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import Page404Loader from 'common/components/Page404Loader';
import DemoNavigation from '../demoNavigation';
import DemoEquities from '../companies/demoEquities';
import DemoStartups from '../startups/demoStartups';
import './index.scss';

const DemoView = () => (
  <div className="demo">
    <h1 className="demo__heading">Manage Demo Account</h1>
    <DemoNavigation />
    <Switch>
      <Redirect
        exact
        from="/admin/management/demo"
        to="/admin/management/demo/equities"
      />
      <Route
        exact
        path="/admin/management/demo/equities"
        component={DemoEquities}
      />
      <Route
        exact
        path="/admin/management/demo/startups"
        component={DemoStartups}
      />
      <Route component={Page404Loader} />
    </Switch>
  </div>
);

export default DemoView;
