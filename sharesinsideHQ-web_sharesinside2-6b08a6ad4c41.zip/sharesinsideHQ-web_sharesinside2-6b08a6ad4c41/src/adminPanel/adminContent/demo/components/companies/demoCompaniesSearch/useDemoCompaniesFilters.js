import { useMemo } from 'react';
import { useSelector } from 'react-redux';

const useDemoCompaniesFilters = () => {
  const demoCompaniesFilters = useSelector(
    (state) => state.demoCompaniesFilters,
  );

  const activeFiltersList = useMemo(
    () => [
      ...demoCompaniesFilters.sector,
      ...demoCompaniesFilters.industry,
      ...demoCompaniesFilters.continent,
      ...demoCompaniesFilters.country,
      ...demoCompaniesFilters.relations,
    ],
    [
      demoCompaniesFilters.sector,
      demoCompaniesFilters.industry,
      demoCompaniesFilters.continent,
      demoCompaniesFilters.country,
      demoCompaniesFilters.relations,
    ],
  );

  const isRemoveFiltersButtonVisible = activeFiltersList.length > 0;

  return {
    demoCompaniesFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  };
};

export default useDemoCompaniesFilters;
