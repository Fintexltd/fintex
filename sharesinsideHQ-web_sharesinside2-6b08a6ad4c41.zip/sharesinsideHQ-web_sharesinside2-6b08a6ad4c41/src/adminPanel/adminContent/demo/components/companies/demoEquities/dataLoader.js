import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDemoCompanies } from 'adminPanel/adminContent/demo/redux/actions/demoCompaniesActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const demoCompaniesFilters = useSelector(
    (state) => state.demoCompaniesFilters,
  );

  useEffect(() => {
    dispatch(fetchDemoCompanies(1));
  }, [
    dispatch,
    demoCompaniesFilters.sector,
    demoCompaniesFilters.country,
    demoCompaniesFilters.continent,
    demoCompaniesFilters.industry,
    demoCompaniesFilters.relations,
    demoCompaniesFilters.search,
  ]);

  return null;
};

export default DataLoader;
