import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchSectorsList from 'common/redux/actions/sectorsListActions';
import fetchIndustriesList from 'common/redux/actions/industriesListActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const countries = useSelector((state) => state.countries.list);
  const continents = useSelector((state) => state.continents.list);
  const industries = useSelector((state) => state.industries.list);
  const sectors = useSelector((state) => state.sectors.list);

  useEffect(() => {
    if (!countries) dispatch(fetchCountriesList());
  }, [dispatch, countries]);

  useEffect(() => {
    if (!continents) dispatch(fetchContinentsList());
  }, [dispatch, continents]);

  useEffect(() => {
    if (!sectors) dispatch(fetchSectorsList());
  }, [dispatch, sectors]);

  useEffect(() => {
    if (!industries) dispatch(fetchIndustriesList());
  }, [dispatch, industries]);

  return null;
};

export default DataLoader;
