import React from 'react';
import useNoDataInfo from './useNoDataInfo';

const NoDataInfo = () => {
  const { resultsNumber, isAnyFilterSelected } = useNoDataInfo();

  return isAnyFilterSelected && resultsNumber === 0 ? (
    <div className="demo__empty-list">
      <p className="demo__empty-list-message">
        There are no equities matching these criteria
      </p>
    </div>
  ) : null;
};

export default NoDataInfo;
