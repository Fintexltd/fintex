import React from 'react';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import useDemoEquities from './useDemoEquities';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import DemoCompaniesPagination from './DemoCompaniesPagination';
import DataLoader from './dataLoader';
import DemoCompaniesSearch from '../demoCompaniesSearch';

const DemoEquities = () => {
  const {
    demoCompanies,
    getDemoCompanies,
    resultsNumber,
    meta,
    saveDemoCompaniesFilters,
    handleCheckboxClick,
  } = useDemoEquities();

  return (
    <>
      <DataLoader />
      <DemoCompaniesSearch />
      <div className="demo__table-container">
        <table className="demo__table">
          <thead className="demo__thead">
            <tr>
              <th>Company</th>
              <th>Follower</th>
              <th>Shareholder</th>
              <th>VIP</th>
            </tr>
          </thead>
          <tbody>
            {demoCompanies.map((company) => (
              <tr key={company.id} className="demo__item-row">
                <td>
                  <span className="demo__item-name">{company.name}</span>
                </td>
                <td>
                  <AcceptCheckbox
                    name={`follower${company.id}`}
                    id={`follower${company.id}`}
                    onChange={(e) => handleCheckboxClick(e, company.id)}
                    value="follower"
                    checked={company.user_group.includes('follower')}
                  />
                </td>
                <td>
                  <AcceptCheckbox
                    name={`shareholder${company.id}`}
                    id={`shareholder${company.id}`}
                    onChange={(e) => handleCheckboxClick(e, company.id)}
                    value="shareholder"
                    checked={company.user_group.includes('shareholder')}
                  />
                </td>
                <td>
                  <AcceptCheckbox
                    name={`vip${company.id}`}
                    id={`vip${company.id}`}
                    onChange={(e) => handleCheckboxClick(e, company.id)}
                    value="vip"
                    checked={company.user_group.includes('vip')}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <LoadingIndicator />
      </div>
      <NoDataInfo />
      <DemoCompaniesPagination
        meta={meta}
        resultsNumber={resultsNumber}
        saveFilters={saveDemoCompaniesFilters}
        getResults={getDemoCompanies}
      />
    </>
  );
};

export default DemoEquities;
