import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchDemoCompanies,
  setDemoCompany,
} from 'adminPanel/adminContent/demo/redux/actions/demoCompaniesActions';
import { saveDemoCompaniesFilters as saveDemoCompaniesFiltersAction } from 'adminPanel/adminContent/demo/redux/actions/demoCompaniesFiltersActions';

const useDemoEquities = () => {
  const dispatch = useDispatch();
  const demoCompanies = useSelector((state) => state.demoCompanies.list);
  const meta = useSelector((state) => state.demoCompanies.meta);
  const resultsNumber = useSelector(
    (state) => state.demoCompanies.resultsNumber,
  );

  const getDemoCompanies = useCallback(
    (page = 1) => {
      dispatch(fetchDemoCompanies(page));
    },
    [dispatch],
  );

  const saveDemoCompaniesFilters = (filters) => {
    dispatch(saveDemoCompaniesFiltersAction(filters));
  };

  const handleCheckboxClick = (e, companyId) => {
    const { checked, value } = e.target;
    dispatch(setDemoCompany(companyId, checked ? 'append' : 'remove', value));
  };

  return {
    getDemoCompanies,
    demoCompanies,
    meta,
    resultsNumber,
    saveDemoCompaniesFilters,
    handleCheckboxClick,
  };
};

export default useDemoEquities;
