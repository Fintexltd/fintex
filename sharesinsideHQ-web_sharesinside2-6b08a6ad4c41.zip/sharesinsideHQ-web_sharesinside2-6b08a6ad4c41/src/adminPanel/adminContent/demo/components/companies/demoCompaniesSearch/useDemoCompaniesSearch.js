import { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  removeDemoCompaniesFilters,
  saveDemoCompaniesSearch,
  saveDemoCompaniesFilters,
} from 'adminPanel/adminContent/demo/redux/actions/demoCompaniesFiltersActions';
import { debounce } from 'lodash';
import useDemoCompaniesFilters from './useDemoCompaniesFilters';

const useDemoCompaniesSearch = () => {
  const dispatch = useDispatch();

  const [isAdvancedSearchVisible, setAdvancedSearchVisible] = useState(false);

  const resultsNumber = useSelector(
    (state) => state.demoCompanies.resultsNumber,
  );

  const {
    demoCompaniesFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  } = useDemoCompaniesFilters();

  const toggleAdvancedSearch = () => {
    setAdvancedSearchVisible(!isAdvancedSearchVisible);
  };

  const clearActiveFilters = () => {
    dispatch(removeDemoCompaniesFilters());
  };

  const handleFilterUsage = (values, category) => {
    dispatch(
      saveDemoCompaniesFilters(values.length > 0 ? values : { category }),
    );
  };

  const handleFilterRemoveClick = (label, category) => {
    const filteredOut = demoCompaniesFilters[category].filter(
      (el) => el.label !== label,
    );
    dispatch(
      saveDemoCompaniesFilters(
        filteredOut.length > 0 ? filteredOut : { category },
      ),
    );
  };

  return {
    resultsNumber,
    toggleAdvancedSearch,
    isAdvancedSearchVisible,
    clearActiveFilters,
    activeFiltersList,
    demoCompaniesFilters,
    handleFilterRemoveClick,
    isRemoveFiltersButtonVisible,
    handleFilterUsage,
  };
};

const useDemoCompaniesSearchTextInput = () => {
  const dispatch = useDispatch();

  const search = useSelector((state) => state.demoCompaniesFilters.search);
  const [value, setValue] = useState(search);

  const debouncedSaveDemoCompaniesSearch = useCallback(
    debounce(
      (searchText) => dispatch(saveDemoCompaniesSearch(searchText)),
      500,
    ),
    [],
  );

  const handleSearchInputChange = useCallback(
    (newText) => {
      setValue(newText);
      debouncedSaveDemoCompaniesSearch(newText);
    },
    [debouncedSaveDemoCompaniesSearch],
  );

  return {
    handleSearchInputChange,
    value,
  };
};

export { useDemoCompaniesSearch, useDemoCompaniesSearchTextInput };
