import React from 'react';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import ToggleMoreFiltersIconButton from 'common/components/toggleMoreFiltersIconButton';
import SearchInput from 'common/components/searchInput';
import MultiSelect from 'common/components/customSelect/multiSelect';
import DemoCompaniesAdvancedSearch from 'adminPanel/adminContent/demo/components/companies/demoCompaniesAdvancedSearch';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import { getRelationsList } from 'common/utils/relationsListUtils';
import 'adminPanel/adminContent/common/styles/search.scss';
import {
  useDemoCompaniesSearch,
  useDemoCompaniesSearchTextInput,
} from './useDemoCompaniesSearch';

const relationsList = getRelationsList();

const DemoCompaniesSearch = () => {
  const {
    activeFiltersList,
    clearActiveFilters,
    isAdvancedSearchVisible,
    isRemoveFiltersButtonVisible,
    resultsNumber,
    toggleAdvancedSearch,
    demoCompaniesFilters,
    handleFilterRemoveClick,
    handleFilterUsage,
  } = useDemoCompaniesSearch();

  return (
    <div className="admin-search">
      <div className="admin-search__top">
        <div className="admin-search__top-left">
          <DemoCompaniesSearchTextInput />
          <div className="admin-search__relation-filter-container">
            <MultiSelect
              options={relationsList}
              description="Relation"
              onChange={handleFilterUsage}
              value={demoCompaniesFilters.relations}
              category="relations"
            />
          </div>
          <div className="admin-search__filters-button--text">
            <ToggleMoreFiltersButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
          <div className="admin-search__filters-button--icon">
            <ToggleMoreFiltersIconButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
        </div>
        {isRemoveFiltersButtonVisible && (
          <div className="admin-search__clear-filters-button">
            <div className="admin-search__clear-filters-text-button">
              <ClearFiltersButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
            <div className="admin-search__clear-filters-icon-button">
              <ClearFiltersIconButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
          </div>
        )}
      </div>
      {isAdvancedSearchVisible && (
        <DemoCompaniesAdvancedSearch
          demoCompaniesFilters={demoCompaniesFilters}
          handleFilterUsage={handleFilterUsage}
        />
      )}
      <div className="admin-search__results-container">
        <div className="admin-search__results">
          <SearchResultsCounter resultsNumber={resultsNumber} />
        </div>
        {activeFiltersList.length > 0 && (
          <ActiveFiltersList
            activeFiltersList={activeFiltersList}
            handleFilterRemoveClick={handleFilterRemoveClick}
          />
        )}
      </div>
    </div>
  );
};

const DemoCompaniesSearchTextInput = () => {
  const { handleSearchInputChange, value } = useDemoCompaniesSearchTextInput();

  return (
    <div className="admin-search__search-input">
      <SearchInput handleInputChange={handleSearchInputChange} value={value} />
    </div>
  );
};

export default DemoCompaniesSearch;
