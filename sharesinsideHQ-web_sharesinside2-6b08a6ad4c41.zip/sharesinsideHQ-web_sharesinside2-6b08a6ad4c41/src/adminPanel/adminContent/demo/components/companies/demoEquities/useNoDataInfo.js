import { useSelector } from 'react-redux';
import useDemoCompaniesFilters from '../demoCompaniesSearch/useDemoCompaniesFilters';

const useNoDataInfo = () => {
  const resultsNumber = useSelector(
    (state) => state.demoCompanies.resultsNumber,
  );

  const {
    isRemoveFiltersButtonVisible,
    demoCompaniesFilters,
  } = useDemoCompaniesFilters();

  const isAnyFilterSelected =
    isRemoveFiltersButtonVisible || demoCompaniesFilters.search;

  return {
    resultsNumber,
    isAnyFilterSelected,
  };
};

export default useNoDataInfo;
