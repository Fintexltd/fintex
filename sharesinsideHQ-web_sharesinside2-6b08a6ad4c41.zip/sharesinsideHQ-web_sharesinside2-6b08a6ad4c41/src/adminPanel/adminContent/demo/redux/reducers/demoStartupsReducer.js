import { createReducer } from 'common/utils/reduxUtils';
import {
  FETCH_DEMO_STARTUPS_SUCCESS,
  FETCH_DEMO_STARTUPS_REQUEST,
  FETCH_DEMO_STARTUPS_FAILURE,
} from 'adminPanel/adminContent/demo/redux/types.js';

const initialState = {
  isLoading: false,
  list: [],
  nextPageIndex: null,
  meta: {},
};

const demoStartupsReducer = createReducer(
  { ...initialState },
  {
    [FETCH_DEMO_STARTUPS_SUCCESS]: (state, action) => {
      const { data, meta } = action.payload.demoStartups;
      const hasNextPage = meta.current_page < meta.last_page;
      return {
        ...state,
        isLoading: false,
        list: [...data],
        nextPageIndex: hasNextPage ? meta.current_page + 1 : null,
        resultsNumber: meta.total,
        meta,
      };
    },
    [FETCH_DEMO_STARTUPS_REQUEST]: (state) => ({
      ...state,
      isLoading: true,
    }),
    [FETCH_DEMO_STARTUPS_FAILURE]: (state) => ({
      ...state,
      isLoading: false,
    }),
  },
);

export default demoStartupsReducer;
