import * as types from 'adminPanel/adminContent/demo/redux/types.js';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_DEMO_STARTUPS_FILTERS,
  SAVE_DEMO_STARTUPS_FILTERS,
  SAVE_DEMO_STARTUPS_SEARCH,
} = types;

export const removeDemoStartupsFilters = createActionCreator(
  REMOVE_DEMO_STARTUPS_FILTERS,
);

export const saveDemoStartupsFilters = createActionCreator(
  SAVE_DEMO_STARTUPS_FILTERS,
  'filter',
);

export const saveDemoStartupsSearch = createActionCreator(
  SAVE_DEMO_STARTUPS_SEARCH,
  'search',
);
