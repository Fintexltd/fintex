import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/demo/redux/types.js';
import {
  setDemoCompanyRequest,
  getDemoCompaniesRequest,
} from 'adminPanel/adminContent/demo/api/demoCompaniesApi';

const {
  FETCH_DEMO_COMPANIES_REQUEST,
  FETCH_DEMO_COMPANIES_SUCCESS,
  FETCH_DEMO_COMPANIES_FAILURE,
} = types;

const fetchDemoCompaniesRequest = createActionCreator(
  FETCH_DEMO_COMPANIES_REQUEST,
);
const fetchDemoCompaniesSuccess = createActionCreator(
  FETCH_DEMO_COMPANIES_SUCCESS,
  'demoCompanies',
);
const fetchDemoCompaniesFailure = createActionCreator(
  FETCH_DEMO_COMPANIES_FAILURE,
);

export const setDemoCompany = (id, action, relation) => (
  dispatch,
  getState,
) => {
  const {
    sector,
    industry,
    country,
    continent,
    search,
    relations,
    per_page,
  } = getState().demoCompaniesFilters;

  const { meta } = getState().demoCompanies;

  const getSelectedFiltersIds = (filters) =>
    filters.map((filter) => filter.value);

  dispatch(fetchDemoCompaniesRequest());

  const params = {
    page: meta.current_page,
    search,
    per_page,
    sector: getSelectedFiltersIds(sector),
    industry: getSelectedFiltersIds(industry),
    continent: getSelectedFiltersIds(continent),
    country: getSelectedFiltersIds(country),
    relations: getSelectedFiltersIds(relations),
  };

  return setDemoCompanyRequest(id, action, relation)
    .then(() => getDemoCompaniesRequest(params))
    .then((response) => {
      dispatch(fetchDemoCompaniesSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchDemoCompaniesFailure());
    });
};

export const fetchDemoCompanies = (page = 1) => (dispatch, getState) => {
  const {
    sector,
    industry,
    country,
    continent,
    search,
    relations,
    per_page,
  } = getState().demoCompaniesFilters;

  const { list } = getState().demoCompanies;

  const getSelectedFiltersIds = (filters) =>
    filters.map((filter) => filter.value);

  if (list.length === 0) {
    dispatch(fetchDemoCompaniesRequest());
  }

  const params = {
    page,
    search,
    per_page,
    sector: getSelectedFiltersIds(sector),
    industry: getSelectedFiltersIds(industry),
    continent: getSelectedFiltersIds(continent),
    country: getSelectedFiltersIds(country),
    relations: getSelectedFiltersIds(relations),
  };

  return getDemoCompaniesRequest(params)
    .then((response) => {
      dispatch(fetchDemoCompaniesSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchDemoCompaniesFailure());
    });
};
