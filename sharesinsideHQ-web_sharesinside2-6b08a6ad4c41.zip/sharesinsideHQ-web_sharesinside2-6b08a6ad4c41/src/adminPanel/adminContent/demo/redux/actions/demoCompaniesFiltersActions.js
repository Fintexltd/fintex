import * as types from 'adminPanel/adminContent/demo/redux/types.js';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_DEMO_COMPANIES_FILTERS,
  SAVE_DEMO_COMPANIES_FILTERS,
  SAVE_DEMO_COMPANIES_SEARCH,
} = types;

export const removeDemoCompaniesFilters = createActionCreator(
  REMOVE_DEMO_COMPANIES_FILTERS,
);

export const saveDemoCompaniesFilters = createActionCreator(
  SAVE_DEMO_COMPANIES_FILTERS,
  'filter',
);

export const saveDemoCompaniesSearch = createActionCreator(
  SAVE_DEMO_COMPANIES_SEARCH,
  'search',
);
