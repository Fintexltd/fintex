import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/demo/redux/types.js';
import {
  setDemoStartupRequest,
  getDemoStartupsRequest,
} from 'adminPanel/adminContent/demo/api/demoStartupsApi';

const {
  FETCH_DEMO_STARTUPS_REQUEST,
  FETCH_DEMO_STARTUPS_SUCCESS,
  FETCH_DEMO_STARTUPS_FAILURE,
} = types;

const fetchDemoStartupsRequest = createActionCreator(
  FETCH_DEMO_STARTUPS_REQUEST,
);
const fetchDemoStartupsSuccess = createActionCreator(
  FETCH_DEMO_STARTUPS_SUCCESS,
  'demoStartups',
);
const fetchDemoStartupsFailure = createActionCreator(
  FETCH_DEMO_STARTUPS_FAILURE,
);

export const setDemoStartup = (id, action, relation) => (
  dispatch,
  getState,
) => {
  const {
    country,
    continent,
    category,
    equityFund,
    search,
    relations,
    per_page,
  } = getState().demoStartupsFilters;

  const { meta } = getState().demoStartups;

  const getSelectedFiltersIds = (filters) =>
    filters.map((filter) => filter.value);

  dispatch(fetchDemoStartupsRequest());

  const params = {
    page: meta.current_page,
    search,
    per_page,
    startup_category: getSelectedFiltersIds(category),
    continent: getSelectedFiltersIds(continent),
    country: getSelectedFiltersIds(country),
    equity: equityFund.find((item) => item.value === 'equity') ? 1 : null,
    fund: equityFund.find((item) => item.value === 'fund') ? 1 : null,
    relations: getSelectedFiltersIds(relations),
  };

  return setDemoStartupRequest(id, action, relation)
    .then(() => getDemoStartupsRequest(params))
    .then((response) => {
      dispatch(fetchDemoStartupsSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchDemoStartupsFailure());
    });
};

export const fetchDemoStartups = (page = 1) => (dispatch, getState) => {
  const {
    country,
    continent,
    category,
    equityFund,
    search,
    relations,
    per_page,
  } = getState().demoStartupsFilters;

  const { list } = getState().demoStartups;

  const getSelectedFiltersIds = (filters) =>
    filters.map((filter) => filter.value);

  if (list.length === 0) {
    dispatch(fetchDemoStartupsRequest());
  }

  const params = {
    page,
    search,
    per_page,
    startup_category: getSelectedFiltersIds(category),
    continent: getSelectedFiltersIds(continent),
    country: getSelectedFiltersIds(country),
    equity: equityFund.find((item) => item.value === 'equity') ? 1 : null,
    fund: equityFund.find((item) => item.value === 'fund') ? 1 : null,
    relations: getSelectedFiltersIds(relations),
  };

  return getDemoStartupsRequest(params)
    .then((response) => {
      dispatch(fetchDemoStartupsSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchDemoStartupsFailure());
    });
};
