import React from 'react';
import DemoView from 'adminPanel/adminContent/demo/components/demoView';
import UserTypeRequired from 'permissions/components/userTypeRequired';
import { CONTENT_ADMIN, GLOBAL_ADMIN } from 'permissions/constants';

const AdminDemo = () => (
  <UserTypeRequired
    userType={[GLOBAL_ADMIN, CONTENT_ADMIN]}
    redirectFallback="/admin/company/management"
  >
    <DemoView />
  </UserTypeRequired>
);

export default AdminDemo;
