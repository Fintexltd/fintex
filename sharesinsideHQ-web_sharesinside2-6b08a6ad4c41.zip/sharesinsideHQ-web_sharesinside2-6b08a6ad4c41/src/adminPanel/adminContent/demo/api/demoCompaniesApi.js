import axios from 'axios';

const setDemoCompanyRequest = (id, action, relation) =>
  axios.put(`${process.env.REACT_APP_API_URL}/admin/demo`, {
    entitiable_type: 'company',
    entitiable_id: id,
    action,
    relation,
  });

const getDemoCompaniesRequest = (params) =>
  axios.get(`${process.env.REACT_APP_API_URL}/admin/demo/companies`, {
    params,
  });

export { setDemoCompanyRequest, getDemoCompaniesRequest };
