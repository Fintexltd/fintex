import axios from 'axios';

const setDemoStartupRequest = (id, action, relation) =>
  axios.put(`${process.env.REACT_APP_API_URL}/admin/demo`, {
    entitiable_type: 'startup',
    entitiable_id: id,
    action,
    relation,
  });

const getDemoStartupsRequest = (params) =>
  axios.get(`${process.env.REACT_APP_API_URL}/admin/demo/startups`, {
    params,
  });

export { setDemoStartupRequest, getDemoStartupsRequest };
