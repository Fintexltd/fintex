import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button, ButtonGroup, FormGroup } from 'reactstrap';
import PropTypes from 'prop-types';
import TexEditor from 'common/components/textEditor';
import { Formik } from 'formik';
import Input from 'common/components/input';
import UploadAttachments from 'common/components/uploadAttachments';
import AddLinks from 'common/components/addLinks';
import AddLinkOrVideo from 'common/components/addLinkOrVideo';
import CircleSpinner from 'common/components/circleSpinner';
import { updateCompanyData } from 'adminPanel/adminContent/adminCreator/api/adminCreatorApi.js';
import validationSchema from 'adminPanel/validators/aboutValidators';
import { fetchAdminCompany } from 'adminPanel/redux/actions/adminCompanyActions';
import { isEditor } from 'userAuth/utils/permissions';
import './index.scss';

const mapDispatchToProps = dispatch => ({
  getAdminCompany: bindActionCreators(fetchAdminCompany, dispatch),
});

class EditAbout extends Component {
  constructor() {
    super();
    this.state = {
      initFiles: [],
      links: null,
      videoLinks: [],
      videos: [],
      delete_attachments: [],
      delete_links: [],
      isInitialStatePrepared: false,
    };
  }

  componentDidMount() {
    this.setInitialState();

    if (isEditor(this.props.userData, this.props.company.id)) {
      this.props.history.replace(
        `/admin/company/manage/${this.props.company.id}/about`,
      );
    }
  }

  onVideoLinkAdded = (videoLink, previousVideoLink, previousVideo) => {
    this.setState(prevState => ({
      videoLinks: [videoLink],
      videos: [],
      delete_attachments:
        previousVideo && previousVideo.id
          ? [...prevState.delete_attachments, previousVideo.id]
          : prevState.delete_attachments,
      delete_links:
        previousVideoLink && previousVideoLink.id
          ? [...prevState.delete_links, previousVideoLink.id]
          : prevState.delete_links,
    }));
  };

  onVideoLinkRemoved = link => {
    this.setState(prevState => ({
      videoLinks: [],
      delete_links: link.id
        ? [...prevState.delete_links, link.id]
        : prevState.delete_links,
    }));
  };

  onVideoTokenAdded = (videoToken, previousVideoLink, previousVideo) => {
    this.setState(prevState => ({
      videos: [videoToken],
      videoLinks: [],
      delete_attachments:
        previousVideo && previousVideo.id
          ? [...prevState.delete_attachments, previousVideo.id]
          : prevState.delete_attachments,
      delete_links:
        previousVideoLink && previousVideoLink.id
          ? [...prevState.delete_links, previousVideoLink.id]
          : prevState.delete_links,
    }));
  };

  onVideoTokenRemoved = video => {
    this.setState(prevState => ({
      videos: [],
      delete_attachments: video.id
        ? [...prevState.delete_attachments, video.id]
        : prevState.delete_attachments,
    }));
  };

  getNewLinks = () => {
    const links = this.props.company.links
      ? this.props.company.links.map(link => link.id)
      : [];
    const linksToExclude = links.concat(this.state.delete_links);
    return this.state.links.filter(link => !linksToExclude.includes(link.id));
  };

  setInitialState = () => {
    this.setState({
      initFiles: this.props.company.attachments,
      links: this.props.company.links,
      initVideos: this.props.company.videos,
      initVideoLinks: this.props.company.video_links,
      isInitialStatePrepared: true,
    });
  };

  handleCancelClick = () => {
    this.props.history.push(
      `/admin/company/manage/${this.props.company.id}/about`,
    );
  };

  sendCompanyData = values => {
    const data = {
      title: values.title,
      description: values.description || this.props.company.description,
      links: this.getNewLinks(),
      video_links: this.state.videoLinks,
      videos: this.state.videos,
      attachments: values.attachments || [],
      delete_attachments: this.state.delete_attachments,
      delete_links: this.state.delete_links,
    };

    updateCompanyData(this.props.company.id, data).then(() => {
      this.props.getAdminCompany(this.props.company.id);
      this.props.history.push(
        `/admin/company/manage/${this.props.company.id}/about`,
      );
    });
  };

  mergeLinksArray = (objectType, values) => {
    this.setState(prevState => ({
      [objectType]: [...prevState[objectType], values],
    }));
  };

  deleteLinksArray = (objectType, values, linkToDelete) => {
    const filteredArray = this.state[objectType].filter(
      element =>
        element.name !== linkToDelete.name ||
        element.url !== linkToDelete.url ||
        element.type !== linkToDelete.type,
    );

    this.setState({ [objectType]: filteredArray }, () => {
      if (linkToDelete.id) {
        this.initFilesDelete(linkToDelete.id, 'links');
      }
    });
  };

  initFilesDelete = (id, type) => {
    this.setState({
      [`delete_${type}`]: [...this.state[`delete_${type}`], id],
    });
  };

  render() {
    const { description, title } = this.props.company;
    const { initVideos, initVideoLinks } = this.state;
    return (
      <Fragment>
        {this.props.company &&
        this.state.isInitialStatePrepared &&
        this.state.links ? (
          <Formik
            initialValues={{
              title: title || '',
              description: description || '',
            }}
            onSubmit={values => {
              this.sendCompanyData(values);
            }}
            validationSchema={validationSchema}
            render={({
              values,
              errors,
              setValues,
              touched,
              handleSubmit,
              handleChange,
              handleBlur,
              setFieldTouched,
              setFieldError,
              setFieldValue,
            }) => (
              <form onSubmit={handleSubmit} className="edit-about">
                <FormGroup>
                  <Input
                    name="title"
                    placeholder="Title"
                    value={values.title}
                    error={errors.title}
                    onBlur={handleBlur}
                    touched={touched.title}
                    onChange={handleChange}
                  />
                  <span className="description__letter-counter">
                    {`${
                      values.title ? values.title.trimStart().length : 0
                    }/128`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <TexEditor
                    name="description"
                    value={values.description}
                    defaultValue={values.description}
                    errors={errors}
                    setValues={setValues}
                    touched={touched}
                    setFieldTouched={setFieldTouched}
                    setFieldError={setFieldError}
                    setFieldValue={setFieldValue}
                    updateCompanyCreationFormState={
                      this.updateCompanyAboutFormState
                    }
                  />
                </FormGroup>
                <FormGroup>
                  <AddLinkOrVideo
                    initialVideos={initVideos}
                    initLinks={initVideoLinks}
                    onLinkAdded={this.onVideoLinkAdded}
                    onLinkRemoved={this.onVideoLinkRemoved}
                    onVideoTokenAdded={this.onVideoTokenAdded}
                    onVideoTokenRemoved={this.onVideoTokenRemoved}
                  />
                </FormGroup>
                <FormGroup>
                  <UploadAttachments
                    name="attachments"
                    values={values}
                    initFiles={this.state.initFiles}
                    handleInitFilesDelete={this.initFilesDelete}
                    setFieldValue={setFieldValue}
                  />
                </FormGroup>
                <FormGroup>
                  <AddLinks
                    name="links"
                    id="links"
                    placeholder="Add Link"
                    linkType="type_default"
                    objectType="links"
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                    initLinks={this.state.links.filter(
                      link => link.type === 'type_default',
                    )}
                  />
                </FormGroup>
                <ButtonGroup className="edit-about__buttons-container">
                  <Button
                    color="primary"
                    outline
                    className="edit-about__cancel-button"
                    onClick={this.handleCancelClick}
                  >
                    Cancel
                  </Button>
                  <Button color="primary" type="submit">
                    Update
                  </Button>
                </ButtonGroup>
              </form>
            )}
          />
        ) : (
          <div className="edit-about__loader-container">
            <CircleSpinner />
          </div>
        )}
      </Fragment>
    );
  }
}

EditAbout.propTypes = {
  company: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  getAdminCompany: PropTypes.func.isRequired,
};

export default connect(
  null,
  mapDispatchToProps,
)(withRouter(EditAbout));
