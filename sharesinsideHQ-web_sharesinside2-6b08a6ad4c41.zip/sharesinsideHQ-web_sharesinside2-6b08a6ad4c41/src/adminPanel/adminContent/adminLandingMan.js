import React, { Fragment } from 'react';

const AdminLandingManView = () => <Fragment>Landing managemet view</Fragment>;

export default AdminLandingManView;
