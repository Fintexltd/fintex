import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Input from 'common/components/input';
import DocumentsView from 'adminPanel/adminContent/funds/fundDocuments/components/documentsView';
import validationSchema from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/validators';
import RemoveModal from 'common/components/removeModal';
import {
  fetchFundDocuments,
  fetchFundDocumentsMore,
  removeFundDocuments,
  addFundDocumentsSection,
  editFundDocumentsSection,
  removeFundDocumentsSection,
} from 'common/redux/actions/fundDocumentsActions';
import { disableScroll } from 'common/utils/disableScroll';
import FormModal from 'common/components/modals/form';

const mapStateToProps = (state) => ({
  documentsList: state.fundDocuments.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getFundDocuments: bindActionCreators(fetchFundDocuments, dispatch),
  getFundDocumentsMore: bindActionCreators(fetchFundDocumentsMore, dispatch),
  removeFundDocuments: bindActionCreators(removeFundDocuments, dispatch),
  addFundDocumentsSection: bindActionCreators(
    addFundDocumentsSection,
    dispatch,
  ),
  editFundDocumentsSection: bindActionCreators(
    editFundDocumentsSection,
    dispatch,
  ),
  removeFundDocumentsSection: bindActionCreators(
    removeFundDocumentsSection,
    dispatch,
  ),
});

class FundDocuments extends Component {
  constructor() {
    super();
    this.state = {
      sectionId: null,
      isRemoveModalVisible: false,
      isInputModalVisible: false,
      isEdit: false,
      values: {
        name: '',
      },
    };
  }

  componentDidMount() {
    const fundId = Number(this.props.match.params.id);
    if (
      !(
        this.props.userData.relations_fund.secondary_admin &&
        this.props.userData.relations_fund.secondary_admin.includes(fundId)
      ) &&
      !(
        this.props.userData.relations_fund.primary_admin &&
        this.props.userData.relations_fund.primary_admin.includes(fundId)
      ) &&
      !(
        this.props.userData.relations_fund.editor &&
        this.props.userData.relations_fund.editor.includes(fundId)
      ) &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push(`/admin/fund/manage/${fundId}/about`);
    }
    this.props.removeFundDocuments();
    this.props.getFundDocuments(this.props.match.params.id);
  }

  handleSeeMoreClick = (pageIndex, type) => {
    this.props.getFundDocumentsMore(
      pageIndex,
      type,
      this.props.match.params.id,
    );
  };

  closeModal = () => {
    this.setState(
      {
        sectionId: null,
        isRemoveModalVisible: false,
        isInputModalVisible: false,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(false),
    );
  };

  sectionActions = ({ name, id }) => {
    if (this.state.isEdit) {
      this.props.editFundDocumentsSection(id, { name });
      this.closeModal();
    } else {
      this.props.addFundDocumentsSection({
        name,
        entitiable_type: 'fund',
        entitiable_id: this.props.match.params.id,
        type: 'document_section',
      });
      this.closeModal();
    }
  };

  createSection = () => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  editSection = (name, id) => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: true,
        values: {
          name,
          id,
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  removeSection = (sectionId) => {
    if (this.state.sectionId) {
      this.props.removeFundDocumentsSection(this.state.sectionId);
      this.closeModal();
    } else {
      this.setState(
        {
          isRemoveModalVisible: true,
          sectionId,
        },
        () => disableScroll(this.state.isRemoveModalVisible),
      );
    }
  };

  render() {
    const { isRemoveModalVisible, isInputModalVisible } = this.state;

    const ModalFormView = ({ formProps }) => (
      <>
        <Input
          name="name"
          type="text"
          placeholder="Section name"
          error={formProps.errors.name}
          value={formProps.values.name}
          touched={formProps.touched.name}
          onBlur={formProps.handleBlur}
          onChange={formProps.handleChange}
          autoFocus
        />
        {' '}
        <span className="letter-counter">
          {`${formProps.values.name.trimStart().length}/64`}
        </span>
      </>
    );

    return (
      <>
        <DocumentsView
          documentsList={this.props.documentsList}
          createSection={this.createSection}
          editSection={this.editSection}
          removeSection={this.removeSection}
          handleSeeMoreClick={this.handleSeeMoreClick}
          fundId={this.props.match.params.id}
        />
        <FormModal
          isModalVisible={isInputModalVisible}
          handleClose={this.closeModal}
          header={`${this.state.isEdit ? 'Edit' : 'Add new'} section`}
          validationSchema={validationSchema}
          onSubmit={this.sectionActions}
          initialValues={this.state.values}
          confimButtonText={this.state.isEdit ? 'Save' : 'Add'}
        >
          <ModalFormView />
        </FormModal>
        {isRemoveModalVisible && (
          <RemoveModal
            handleRemoveClick={this.removeSection}
            handleCancelClick={this.closeModal}
            heading="Are You sure you want to remove this section?"
            message="This section will be deleted immediately. You can't undo this action."
          />
        )}
      </>
    );
  }
}

FundDocuments.propTypes = {
  getFundDocuments: PropTypes.func.isRequired,
  removeFundDocuments: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(FundDocuments);
