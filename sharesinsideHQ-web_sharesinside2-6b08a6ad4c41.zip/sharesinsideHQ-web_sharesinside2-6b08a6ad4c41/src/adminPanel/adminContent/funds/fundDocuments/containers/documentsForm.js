import React, { Component } from 'react';
import moment from 'moment';
import { connect } from 'react-redux';
import { requestAttachmentToken } from 'common/api/filesApi';
import DocumentsFormView from 'adminPanel/adminContent/funds/fundDocuments/components/documentsFormView';
import { bindActionCreators } from 'redux';
import {
  addDocuments,
  editDocuments,
} from 'common/redux/actions/fundDocumentsActions';

const mapDispatchToProps = dispatch => ({
  addDocuments: bindActionCreators(addDocuments, dispatch),
  editDocuments: bindActionCreators(editDocuments, dispatch),
});

class DocumentsForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLoadingFile: false,
      values: {
        date: this.props.data
          ? moment.unix(this.props.data.timestamp)
          : moment()._d,
        title: this.props.data ? this.props.data.title : '',
        file: '',
        sectionId: this.props.sectionId ? this.props.sectionId : '',
        fileName: this.props.data ? this.props.data.file.oryginal_name : '',
      },
      errors: {
        title: '',
        file: '',
      },
      touched: {
        title: false,
        file: false,
      },
    };
  }

  uploadAttachements = e => {
    this.setState(
      prevState => ({
        touched: {
          ...prevState.touched,
          file: true,
        },
      }),
      () => this.checkErrors(),
    );

    if (e.target.files[0]) {
      e.preventDefault();

      this.setState(prevState => ({
        isLoadingFile: true,
        errors: { ...prevState.errors, file: '' },
        touched: { ...prevState.touched, file: false },
      }));

      const reader = new FileReader();
      const file = e.target.files[0];

      reader.onloadend = () => {
        const fileAsForm = new FormData();
        fileAsForm.append('file', file);

        requestAttachmentToken(fileAsForm, 'type_file')
          .then(res => {
            this.setState({});
            this.setState(prevState => ({
              values: {
                ...prevState.values,
                file: res.data.token,
                fileName: file.name,
              },
              errors: { ...prevState.errors, file: '' },
              touched: { ...prevState.touched, file: false },
              isLoadingFile: false,
            }));
          })
          .catch(error => {
            this.setState(prevState => ({
              errors: {
                ...prevState.errors,
                file:
                  error.response.data && error.response.data.errors.file
                    ? error.response.data.errors.file
                    : 'There was an error uploading a file.',
              },
              touched: { ...prevState.touched, file: true },
              isLoadingFile: false,
            }));
          });
      };

      reader.readAsDataURL(file);
    }
  };

  checkErrors = () => {
    let titleError = '';
    let fileError = '';
    const { touched, values } = this.state;
    if (
      touched.title &&
      (values.title === '' || values.title.trim().length === 0)
    )
      titleError = 'This field is required!';

    if (touched.file && values.fileName === '')
      fileError = 'This field is required!';

    this.setState({
      errors: {
        title: titleError,
        file: fileError,
      },
    });

    if (titleError === '' && fileError === '') return true;

    return false;
  };

  handleChange = e => {
    const { name, value } = e.target;
    this.setState(prevState => ({
      touched: {
        ...prevState.touched,
        [name]: true,
      },
      values: {
        ...prevState.values,
        [name]: value,
      },
    }));
  };

  handleBlur = e => {
    const { name, value } = e.target;
    this.setState(
      prevState => ({
        touched: {
          ...prevState.touched,
          [name]: true,
        },
        values: {
          ...prevState.values,
          [name]: value,
        },
      }),
      () => this.checkErrors(),
    );
  };

  addDocuments = () => {
    const { values } = this.state;
    this.setState(
      {
        touched: {
          title: true,
          file: true,
        },
      },
      () => {
        if (this.checkErrors()) {
          if (this.props.formFunction === 'edit') {
            const data = {
              _method: 'put',
              title: values.title,
              fund_id: this.props.fundId,
              section_id: values.sectionId,
            };

            if (values.file !== '') data.file = values.file;

            this.props.editDocuments(this.props.documentsId, data);
            this.cancelEdit();
          } else {
            const data = {
              title: values.title,
              file: values.file,
              fund_id: this.props.fundId,
              section_id: values.sectionId,
            };

            this.props.addDocuments(data);
            this.setState({
              isLoadingFile: false,
              values: {
                date: moment()._d,
                title: '',
                file: {},
                sectionId: this.props.sectionId ? this.props.sectionId : '',
                fileName: '',
              },
              errors: {
                title: '',
                file: '',
              },
              touched: {
                title: false,
                file: false,
              },
            });
          }
        }
      },
    );
  };

  cancelEdit = () => {
    this.setState({
      isLoadingFile: false,
      values: {
        date: this.props.data
          ? moment.unix(this.props.data.timestamp)
          : moment()._d,
        title: this.props.data ? this.props.data.title : '',
        file: '',
        sectionId: this.props.sectionId ? this.props.sectionId : '',
        fileName: this.props.data ? this.props.data.file.oryginal_name : '',
      },
      errors: {
        title: '',
        file: '',
      },
      touched: {
        title: false,
        file: false,
      },
    });

    this.props.cancelEdit();
  };

  render() {
    const { sectionId, formFunction, isEdit } = this.props;
    const { values, errors, touched } = this.state;
    return (
      <DocumentsFormView
        sectionId={sectionId}
        values={values}
        errors={errors}
        touched={touched}
        handleChange={this.handleChange}
        handleBlur={this.handleBlur}
        addDocuments={this.addDocuments}
        uploadAttachements={this.uploadAttachements}
        isLoadingFile={this.state.isLoadingFile}
        formFunction={formFunction}
        isEdit={isEdit}
        cancelEdit={this.cancelEdit}
        id={this.props.documentsId}
      />
    );
  }
}

export default connect(
  null,
  mapDispatchToProps,
)(DocumentsForm);
