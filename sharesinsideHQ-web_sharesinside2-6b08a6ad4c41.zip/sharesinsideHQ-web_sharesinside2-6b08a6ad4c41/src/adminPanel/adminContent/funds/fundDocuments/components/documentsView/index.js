import React from 'react';
import DocumentsTableView from 'adminPanel/adminContent/funds/fundDocuments/components/documentsTableView';
import shortid from 'shortid';
import './style.scss';

const DocumentsView = ({
  documentsList,
  handleSeeMoreClick,
  removeSection,
  editSection,
  createSection,
  fundId,
}) => (
  <div className="fund-documents">
    {documentsList &&
      documentsList.map(documents => (
        <DocumentsTableView
          key={shortid.generate()}
          header={documents.name}
          sectionId={documents.sectionId}
          data={documents.data}
          nextPageIndex={documents.nextPageIndex}
          handleSeeMoreClick={handleSeeMoreClick}
          removeSection={removeSection}
          editSection={editSection}
          fundId={fundId}
        />
      ))}
    <div
      className="fund-documents__newSection"
      onClick={createSection}
      role="presentation"
    >
      <div className="newSection__icon" />
      <div className="newSection__text">Add new section</div>
    </div>
  </div>
);

export default DocumentsView;
