import React from 'react';
import DocumentsForm from 'adminPanel/adminContent/funds/fundDocuments/containers/documentsForm';
import Documents from 'adminPanel/adminContent/funds/fundDocuments/containers/documents';
import shortid from 'shortid';
import './style.scss';

const DocumentsTableView = ({
  header,
  data,
  sectionId,
  handleSeeMoreClick,
  fundId,
  editSection,
  removeSection,
  nextPageIndex,
}) => (
  <div className="fund-documents__container">
    <div className="fund-documents__header">
      <h1 className="header__content">{header}</h1>
      <div className="header__icons">
        <div
          className="icon__edit"
          onClick={() => editSection(header, sectionId)}
          role="presentation"
        />
        <div
          className="icon__remove"
          onClick={() => removeSection(sectionId)}
          role="presentation"
        />
      </div>
    </div>

    <table className="fund-documents__table">
      <thead className="fund-documents__thead">
        <tr>
          <th className="thPublish align-middle">Publish date</th>
          <th className="thTitle align-middle">Title</th>
          <th className="thAttachments align-middle">Attachments</th>
          <th className="thActions align-middle" />
        </tr>
      </thead>
      <tbody>
        <DocumentsForm fundId={fundId} sectionId={sectionId} />
        {data.map(documents => (
          <Documents
            key={`${shortid.generate()}`}
            fundId={fundId}
            sectionId={sectionId}
            documents={documents}
          />
        ))}
      </tbody>
    </table>
    {nextPageIndex ? (
      <div className="fund-documents__load-container">
        <button
          onClick={() => handleSeeMoreClick(nextPageIndex, sectionId)}
          className="fund-documents__load"
        >
          See more
        </button>
      </div>
    ) : (
      ''
    )}
  </div>
);

export default DocumentsTableView;
