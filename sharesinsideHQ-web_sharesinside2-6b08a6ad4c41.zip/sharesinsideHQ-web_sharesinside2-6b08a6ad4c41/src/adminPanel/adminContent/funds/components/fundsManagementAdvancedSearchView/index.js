import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import './index.scss';

const FundsManagementAdvancedSearchView = ({
  fundsFilters,
  continentsList,
  countriesList,
  currenciesList,
  fundTypesList,
  handleFilterUsage,
  handleCheckboxChange,
}) => (
  <div className="funds-management-advanced-search">
    <div className="funds-management-advanced-search__filters">
      <div className="funds-management-advanced-search__filter">
        <MultiSelect
          options={continentsList}
          description="Continent"
          onChange={handleFilterUsage}
          value={fundsFilters.continent}
          category="continent"
          isSearchable
        />
      </div>
      <div className="funds-management-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={fundsFilters.country}
          category="country"
          isSearchable
        />
      </div>
      <div className="funds-management-advanced-search__filter">
        <MultiSelect
          options={fundTypesList}
          description="Asset Classes"
          onChange={handleFilterUsage}
          value={fundsFilters.fundType}
          category="fundType"
        />
      </div>
      <div className="funds-management-advanced-search__filter">
        <MultiSelect
          options={currenciesList}
          description="Currency"
          onChange={handleFilterUsage}
          value={fundsFilters.currency}
          category="currency"
          isSearchable
        />
      </div>
      <div className="funds-management-advanced-search__filter">
        <AcceptCheckbox
          checked={fundsFilters.active === 1}
          name="active"
          id="active"
          onChange={handleCheckboxChange}
        >
          Active
        </AcceptCheckbox>
        <AcceptCheckbox
          checked={fundsFilters.passive === 1}
          name="passive"
          id="passive"
          onChange={handleCheckboxChange}
        >
          Passive
        </AcceptCheckbox>
      </div>
    </div>
  </div>
);

FundsManagementAdvancedSearchView.defaultProps = {
  countriesList: [],
  continentsList: [],
  currenciesList: [],
  fundTypesList: [],
};

FundsManagementAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  currenciesList: PropTypes.arrayOf(PropTypes.object),
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  fundsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
  handleCheckboxChange: PropTypes.func.isRequired,
};

export default FundsManagementAdvancedSearchView;
