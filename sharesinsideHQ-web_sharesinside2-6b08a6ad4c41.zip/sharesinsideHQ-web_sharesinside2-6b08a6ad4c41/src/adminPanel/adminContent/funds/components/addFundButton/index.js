import React from 'react';
import { NavLink } from 'react-router-dom';
import plus from 'assets/icons/add_icon_big_white.svg';
import PropTypes from 'prop-types';
import './style.scss';

const AddFundButton = ({ fundsManagerId }) => (
  <NavLink
    className="add-fund-button"
    to={`/admin/fundsmanager/${fundsManagerId}/fund/create`}
  >
    <div className="add-fund-button__content">
      <img src={plus} height={60} alt="" />
      <span>add new fund</span>
    </div>
  </NavLink>
);

AddFundButton.propTypes = {
  fundsManagerId: PropTypes.number.isRequired,
};

export default AddFundButton;
