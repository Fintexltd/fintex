import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import TextTruncate from 'react-text-truncate';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import placeholder from 'assets/img/placeholder.png';
import './index.scss';

const FundItem = props => {
  const {
    fund,
    removeFund,
    handleCheckboxClick,
    isChecked,
    isRemoveFundAllowed,
  } = props;
  return (
    <div className="funds-management-item">
      <div className="funds-management-item__content">
        <div className="funds-management-item__top-container">
          {isRemoveFundAllowed() ? (
            <div
              onClick={e => e.stopPropagation()}
              onKeyPress={e => e.stopPropagation()}
              role="button"
              tabIndex="0"
              className="funds-management-item__checkbox-container"
            >
              <AcceptCheckbox
                name={`${fund.id}`}
                id={`${fund.id}`}
                onChange={handleCheckboxClick}
                checked={isChecked}
              />
            </div>
          ) : (
            <div />
          )}
          <div className="funds-management-item__buttons">
            <span
              className="funds-management-item__edit"
              onClick={() => {
                window.location.replace(`/admin/fund/manage/${fund.id}/about`);
              }}
              role="presentation"
            >
              edit
            </span>
            {isRemoveFundAllowed() && (
              <button
                className="funds-management-item__remove"
                onClick={e => {
                  e.stopPropagation();
                  removeFund(fund.id);
                }}
              >
                delete
              </button>
            )}
          </div>
        </div>
        <Link
          to={`/admin/fund/manage/${fund.id}/about`}
          className="company-item__top-container-link"
        >
          <div
            className="funds-management-item__image"
            style={{
              backgroundImage: `url(${fund.logo || placeholder})`,
            }}
          />
          <h2 className="funds-management-item__name">
            <TextTruncate line={1} truncateText="…" text={fund.name} />
          </h2>
        </Link>
      </div>
    </div>
  );
};

FundItem.propTypes = {
  fund: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  removeFund: PropTypes.func.isRequired,
  handleCheckboxClick: PropTypes.func.isRequired,
  isChecked: PropTypes.bool.isRequired,
};

export default withRouter(FundItem);
