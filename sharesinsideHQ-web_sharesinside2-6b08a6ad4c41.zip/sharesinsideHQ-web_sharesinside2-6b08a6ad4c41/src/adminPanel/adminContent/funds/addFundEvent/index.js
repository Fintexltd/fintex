import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { checkIfFundUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import AddEventForm from './containers/addEventForm';

const mapStateToProps = (state) => ({
  fund: state.adminFund.currentFund,
  locationData: state.locationData.results,
  userData: state.userData.data,
});

class AddFundEvent extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      this.props.userData &&
      !checkIfFundUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.fund.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      !checkIfFundUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.fund.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfFundUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.fund.id,
        ) && (
          <AddEventForm
            fund={this.props.fund}
            userData={this.props.userData}
            {...this.props}
          />
        )}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddFundEvent));
