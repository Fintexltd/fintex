import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, ButtonGroup, Button } from 'reactstrap';
import NewsItem from 'common/components/newsItem';
import AddButton from 'common/components/addButton';
import ModalContainer from 'common/components/modalContainer';
import { checkIfFundUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './index.scss';

const NewsContentView = ({
  newsList,
  fundId,
  handleLoadMoreClick,
  nextPageIndex,
  toggleNewsDeleteModal,
  isRemoveNewsModalVisible,
  deleteNews,
  userData,
}) => (
  <div className="fund-news-content">
    <Row>
      {checkIfFundUserCanManageNewsOrEvents(userData, fundId) && (
        <AddButton
          route={`/admin/fund/manage/${fundId}/add-news`}
          content="add news"
        />
      )}
      {newsList.length > 0 &&
        newsList.map((item) => (
          <Col xs="12" md="6" key={item.id}>
            <NewsItem
              news={item}
              handleDelete={toggleNewsDeleteModal}
              inAdminView
              ownerType="fund"
            />
          </Col>
        ))}
      {newsList.length === 0 && (
        <Col xs="12" className="fund-news-content__empty-list">
          <p className="fund-news-content__empty-list-message">
            There are no news for this fund
          </p>
        </Col>
      )}
    </Row>
    {nextPageIndex && (
      <div className="fund-news-content__load-container">
        <button
          onClick={handleLoadMoreClick}
          className="fund-news-content__load"
        >
          Load more
        </button>
      </div>
    )}
    {isRemoveNewsModalVisible && (
      <ModalContainer
        className="fund-news-content__remove-news-modal"
        handleOutsideClick={toggleNewsDeleteModal}
      >
        Warning! All news data will be removed!
        <ButtonGroup>
          <Button
            outline
            color="primary"
            className="mr-5"
            type="button"
            onClick={toggleNewsDeleteModal}
          >
            Cancel
          </Button>

          <Button onClick={deleteNews} color="danger">
            Delete
          </Button>
        </ButtonGroup>
      </ModalContainer>
    )}
  </div>
);

NewsContentView.defaultProps = {
  newsList: [],
  nextPageIndex: null,
};

NewsContentView.propTypes = {
  newsList: PropTypes.arrayOf(PropTypes.object),
  handleLoadMoreClick: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default NewsContentView;
