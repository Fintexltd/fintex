import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundNewsContentView from 'adminPanel/adminContent/funds/fundNews/components/fundNewsContentView';
import {
  fetchAdminFundNews,
  removeAdminFundNews,
} from 'adminPanel/redux/actions/funds/admin/adminFundNewsActions';
import { deleteNewsData } from 'adminPanel/adminContent/news/api/newsApi.js';

const mapStateToProps = (state) => ({
  newsList: state.adminFundNews.list,
  hasNextPage: state.adminFundNews.hasNextPage,
  nextPageIndex: state.adminFundNews.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFundNews: bindActionCreators(fetchAdminFundNews, dispatch),
  removeAdminFundNews: bindActionCreators(removeAdminFundNews, dispatch),
});

class NewsContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadMoreClicked: false,
      isRemoveNewsModalVisible: false,
      newsToDelete: null,
    };
  }

  componentDidMount() {
    if (this.props.fundId) {
      this.props.removeAdminFundNews();
      this.props.getAdminFundNews(0, this.props.fundId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminFundNews(
          this.props.nextPageIndex,
          this.props.fundId,
        );
      });
    }
  };

  deleteNews = () => {
    deleteNewsData(this.state.newsToDelete).then(() => {
      this.props.getAdminFundNews(0, this.props.fundId);
      this.toggleNewsDeleteModal();
    });
  };

  toggleNewsDeleteModal = (newsId) => {
    this.setState((prevState) => ({
      isRemoveNewsModalVisible: !prevState.isRemoveNewsModalVisible,
      newsToDelete: newsId,
    }));
  };

  render() {
    return (
      <FundNewsContentView
        newsList={this.props.newsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        fundId={this.props.fundId}
        isRemoveNewsModalVisible={this.state.isRemoveNewsModalVisible}
        toggleNewsDeleteModal={this.toggleNewsDeleteModal}
        deleteNews={this.deleteNews}
        userData={this.props.userData}
      />
    );
  }
}

NewsContent.defaultProps = {
  fundId: null,
  nextPageIndex: null,
  newsList: [],
};

NewsContent.propTypes = {
  fundId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  newsList: PropTypes.arrayOf(PropTypes.object),
  getAdminFundNews: PropTypes.func.isRequired,
  removeAdminFundNews: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsContent);
