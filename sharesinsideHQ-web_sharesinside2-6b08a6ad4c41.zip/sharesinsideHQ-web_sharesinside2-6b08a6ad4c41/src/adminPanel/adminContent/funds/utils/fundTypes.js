export const kindOfFundList = [
  {
    label: 'Non-regulated',
    value: 'non-regulated',
    category: 'kindOfFund',
  },
  {
    label: 'Professional investment',
    value: 'professional-investment',
    category: 'kindOfFund',
  },
  {
    label: 'Retail',
    value: 'retail',
    category: 'kindOfFund',
  },
  {
    label: 'Listed',
    value: 'listed',
    category: 'kindOfFund',
  },
  {
    label: 'UCTS',
    value: 'ucts',
    category: 'kindOfFund',
  },
  {
    label: 'ETF’s',
    value: 'etf-s',
    category: 'kindOfFund',
  },
];

export const openClosedList = [
  {
    label: 'Open',
    value: 'open',
    category: 'openClosed',
  },
  {
    label: 'Closed',
    value: 'closed',
    category: 'openClosed',
  },
];

export const activePassiveList = [
  {
    label: 'Active',
    value: 'active',
    category: 'activePassive',
  },
  {
    label: 'Passive',
    value: 'passive',
    category: 'activePassive',
  },
];
