import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { checkIfFundUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import 'adminPanel/adminContent/addNews/index.scss';
import AddFundNewsForm from './containers/addNewsForm';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class AddNews extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });
    if (
      this.props.userData &&
      !checkIfFundUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });
    if (
      !checkIfFundUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfFundUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.match.params.id,
        ) && <AddFundNewsForm fund={this.props.fund} />}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddNews));
