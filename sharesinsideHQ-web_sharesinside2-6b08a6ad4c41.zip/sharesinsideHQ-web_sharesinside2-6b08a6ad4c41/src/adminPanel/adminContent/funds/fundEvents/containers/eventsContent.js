import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundEventsContentView from 'adminPanel/adminContent/funds/fundEvents/components/eventsContentView';
import {
  fetchAdminFundEvents,
  removeAdminFundEvents,
} from 'adminPanel/redux/actions/funds/admin/adminFundEventsActions';
import { deletEventDataRequest } from 'adminPanel/adminContent/events/api/eventsApi.js';

const mapStateToProps = (state) => ({
  eventsList: state.adminFundEvents.list,
  hasNextPage: state.adminFundEvents.hasNextPage,
  nextPageIndex: state.adminFundEvents.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFundEvents: bindActionCreators(fetchAdminFundEvents, dispatch),
  removeAdminFundEvents: bindActionCreators(removeAdminFundEvents, dispatch),
});

class EventsContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadMoreClicked: false,
      removeEventModalDisplayed: false,
    };
  }

  componentDidMount() {
    if (this.props.fundId) {
      this.props.removeAdminFundEvents();
      this.props.getAdminFundEvents(0, this.props.fundId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminFundEvents(
          this.props.nextPageIndex,
          this.props.fundId,
        );
      });
    }
  };

  eventDelete = () => {
    deletEventDataRequest(this.state.eventToDelete).then(() => {
      this.props.getAdminFundEvents(0, this.props.fundId);
      this.toggleEventDeleteModal();
    });
  };

  toggleEventDeleteModal = (eventId) => {
    this.setState((prevState) => ({
      removeEventModalDisplayed: !prevState.removeEventModalDisplayed,
      eventToDelete: eventId,
    }));
  };

  render() {
    return (
      <FundEventsContentView
        eventsList={this.props.eventsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        fundId={this.props.fundId}
        toggleEventDeleteModal={this.toggleEventDeleteModal}
        removeEventModalDisplayed={this.state.removeEventModalDisplayed}
        eventDelete={this.eventDelete}
        userData={this.props.userData}
      />
    );
  }
}

EventsContent.defaultProps = {
  fundId: null,
  nextPageIndex: null,
  eventsList: [],
};

EventsContent.propTypes = {
  fundId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  eventsList: PropTypes.arrayOf(PropTypes.object),
  getAdminFundEvents: PropTypes.func.isRequired,
  removeAdminFundEvents: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EventsContent);
