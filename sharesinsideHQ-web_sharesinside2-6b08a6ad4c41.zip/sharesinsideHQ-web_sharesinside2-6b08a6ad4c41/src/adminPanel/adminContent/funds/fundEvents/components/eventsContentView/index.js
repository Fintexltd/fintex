import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, ButtonGroup, Button } from 'reactstrap';
import EventItem from 'common/components/eventItem';
import AddButton from 'common/components/addButton';
import ModalContainer from 'common/components/modalContainer';
import { checkIfFundUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './index.scss';

const EventsContentView = ({
  eventsList,
  fundId,
  handleLoadMoreClick,
  nextPageIndex,
  toggleEventDeleteModal,
  removeEventModalDisplayed,
  eventDelete,
  userData,
}) => (
  <div className="fund-event-content">
    <Row>
      {checkIfFundUserCanManageNewsOrEvents(userData, fundId) && (
        <AddButton
          route={`/admin/fund/manage/${fundId}/add-event`}
          content="add event"
        />
      )}
      {eventsList.length > 0 &&
        eventsList.map((item) => (
          <Col xs="12" md="6" key={item.id}>
            <EventItem
              handleDelete={toggleEventDeleteModal}
              event={item}
              inAdminView
            />
          </Col>
        ))}
      {eventsList.length === 0 && (
        <Col xs="12" className="fund-events-content__empty-list">
          <p className="fund-events-content__empty-list-message">
            There are no events for this fund
          </p>
        </Col>
      )}
    </Row>
    {nextPageIndex && (
      <div className="fund-events-content__load-container">
        <button
          onClick={handleLoadMoreClick}
          className="fund-events-content__load"
        >
          Load more
        </button>
      </div>
    )}
    {removeEventModalDisplayed && (
      <ModalContainer
        className="manage-team__remove-group-modal"
        handleOutsideClick={toggleEventDeleteModal}
      >
        Warning! All event data will be removed!
        <ButtonGroup>
          <Button
            outline
            color="primary"
            className="mr-5"
            type="button"
            onClick={toggleEventDeleteModal}
          >
            Cancel
          </Button>

          <Button onClick={eventDelete} color="danger">
            Delete
          </Button>
        </ButtonGroup>
      </ModalContainer>
    )}
  </div>
);

EventsContentView.defaultProps = {
  eventsList: [],
  nextPageIndex: null,
};

EventsContentView.propTypes = {
  eventsList: PropTypes.arrayOf(PropTypes.object),
  handleLoadMoreClick: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default EventsContentView;
