import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { isFundEditor } from 'userAuth/utils/permissions';
import AttachmentsFile from 'common/components/attachmentsFile';
import AttachmentsLink from 'common/components/attachmentsLink';
import VideoPlayerWrapper from 'common/components/videoPlayerWrapper';
import { disableScroll } from 'common/utils/disableScroll';
import shortid from 'shortid';
import 'news/components/newsDetailsView/index.scss';
import './index.scss';

class FundAbout extends Component {
  constructor() {
    super();
    this.state = {
      isVideoDisplayed: false,
    };
  }

  toggleVideoModal = () => {
    this.setState(
      (prevState) => ({
        isVideoDisplayed: !prevState.isVideoDisplayed,
      }),
      () => disableScroll(this.state.isVideoDisplayed),
    );
  };

  render() {
    const { userData, fund } = this.props;

    let videos = [];

    if (fund.videos && fund.video_links) {
      videos = fund.videos.length > 0 ? fund.videos : fund.video_links;
    }

    return (
      <div className="fund-about">
        <div className="fund-about__title">
          <div className="title__container">
            <p className="title__text">{fund.title}</p>
          </div>
          {!isFundEditor(userData, fund.id) && (
            <div className="title__edit">
              <Link
                className="edit__link"
                to={`/admin/fund/manage/${fund.id}/edit-about`}
              >
                <div className="link__icon" />
                <div className="link__text">Edit</div>
              </Link>
            </div>
          )}
        </div>
        <div
          className="fund-about__text"
          dangerouslySetInnerHTML={{ __html: fund.description }}
        />
        {videos && videos.length > 0 && (
          <div className="news-details__videos fund-about__videos">
            <p className="fund-about__media-label">Video:</p>
            <div
              className="placeholder"
              onClick={this.toggleVideoModal}
              role="presentation"
            >
              <img
                src={videos[0].video_img}
                className="video__placeholder"
                alt="placeholder"
              />
              <div className="placeholder__play" />
            </div>
            <VideoPlayerWrapper
              isVideoDisplayed={this.state.isVideoDisplayed}
              toggleVideoModal={this.toggleVideoModal}
              videos={videos}
              indexVideo={0}
            />
          </div>
        )}
        {fund.attachments && fund.attachments.length > 0 && (
          <>
            <p className="fund-about__media-label">Attachments:</p>
            <ul>
              {fund.attachments.map((file) => (
                <AttachmentsFile key={shortid.generate()} file={file} />
              ))}
            </ul>
          </>
        )}
        {fund.links && fund.links.length > 0 && (
          <>
            <p className="fund-about__media-label">Links:</p>
            <ul>
              {fund.links.map((link) => (
                <AttachmentsLink key={shortid.generate()} link={link} />
              ))}
            </ul>
          </>
        )}
      </div>
    );
  }
}

FundAbout.propTypes = {
  fund: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default FundAbout;
