import * as Yup from 'yup';

const fundEditValidationSchema = Yup.object().shape({
  name: Yup.string()
    .required('This field is required.')
    .max(64, 'Name must be shorter than 64 characters'),

  management_fee: Yup.number()
    .min(0)
    .required('This field is required.'),

  performance_fee: Yup.number()
    .min(0)
    .required('This field is required.'),

  duration: Yup.number()
    .min(0)
    .required('This field is required.'),

  // distribution-hide
  // distribution: Yup.number()
  //  .min(0)
  //  .required('This field is required.'),

  currency: Yup.string().required('This field is required.'),

  kind_of_fund: Yup.string()
    .nullable()
    .required('This field is required.'),

  country: Yup.string().required('This field is required.'),

  fund_types: Yup.array().required('At least 1 asset class is required.'),

  is_active: Yup.boolean().required('This field is required.'),

  open_closed: Yup.string()
    .nullable()
    .required('This field is required.'),

  is_passive: Yup.boolean().required('This field is required.'),
});

export default fundEditValidationSchema;
