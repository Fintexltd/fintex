import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundTitleEdit from 'common/components/funds/fundTitleEdit';
import FundHeaderEdit from 'common/components/funds/fundHeaderEdit';
import {
  fetchAdminFund,
  removeAdminFund,
} from 'adminPanel/redux/actions/funds/admin/adminFundActions';
import fetchFundTypesList from 'common/redux/actions/fundTypesListActions';
import fetchCurrenciesList from 'common/redux/actions/currenciesListActions';
import { updateFundData } from 'adminPanel/adminContent/funds/fundCreator/api/fundCreatorApi';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import { disableScroll } from 'common/utils/disableScroll';
import { deleteFunds } from 'adminPanel/api/fundsApi';
import RemoveModal from 'common/components/removeModal';
import FundNavigation from 'common/components/funds/fundNavigation';
import {
  isFundEditor,
  isFundsSecondaryOrPrimaryAdmin,
} from 'userAuth/utils/permissions';
import { Route, Switch } from 'react-router-dom';
import FundBaseInfoEditModal from 'common/components/funds/fundBaseInfoEditModal';
import Documents from 'adminPanel/adminContent/funds/fundDocuments';
import Charts from 'common/containers/charts';
import { getFundChartData } from 'common/api/chartsApi';
import Page404Loader from 'common/components/Page404Loader';
import FundAbout from './components/fundAbout';
import FundEditAbout from './components/fundEditAbout';
import FundNewsContent from '../fundNews/containers/fundNewsContent';
import AddFundNews from '../addFundNews';
import AddFundEvent from '../addFundEvent';
import EventsContent from '../fundEvents/containers/eventsContent';
import EditFundEvent from '../editFundEvent';

const mapStateToProps = (state) => ({
  fund: state.adminFund.currentFund,
  countriesList: state.countries.list,
  currenciesList: state.currencies.list,
  fundTypesList: state.fundTypes.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFund: bindActionCreators(fetchAdminFund, dispatch),
  removeAdminFund: bindActionCreators(removeAdminFund, dispatch),
  getCountriesList: () => dispatch(fetchCountriesList()),
  fetchFundTypesList: () => dispatch(fetchFundTypesList()),
  fetchCurrenciesList: () => dispatch(fetchCurrenciesList()),
});

class FundManagement extends Component {
  constructor() {
    super();
    this.state = {
      isBaseInfoEditModalVisible: false,
      isRemoveFundModalVisible: false,
      symbols: null,
      excludedCountries: [],
      selectedFundTypes: [],
    };
  }

  componentDidMount() {
    this.props.removeAdminFund();
    this.props.getAdminFund(this.props.match.params.id);
    this.props.getCountriesList();
    this.props.fetchFundTypesList();
    this.props.fetchCurrenciesList();
  }

  getBaseInfoFormInitialValues = () => {
    const {
      name,
      management_fee,
      performance_fee,
      duration,
      distribution,
      country,
      currency,
      kind_of_fund,
      is_passive,
      is_active,
      open_closed,
      excluded,
      trading_frequency,
      fund_types,
    } = this.props.fund;

    return {
      name,
      management_fee,
      performance_fee,
      duration,
      distribution,
      is_passive,
      is_active,
      open_closed,
      country: country && country.id,
      currency: currency && currency.id,
      kind_of_fund,
      excluded,
      trading_frequency: trading_frequency || null,
      fund_types,
    };
  };

  setCountryToExclude = (values) => {
    this.setState({ excludedCountries: values });
  };

  setFundTypeSelected = (values) => {
    this.setState({
      selectedFundTypes: values,
    });
  };

  handleExcludedCountryRemoveClick = (label) => {
    this.setState((prevState) => ({
      excludedCountries: prevState.excludedCountries.filter(
        (el) => el.label !== label,
      ),
    }));
  };

  handleFundTypeRemoveClick = (label) => {
    this.setState((prevState) => ({
      selectedFundTypes: prevState.selectedFundTypes.filter(
        (el) => el.label !== label,
      ),
    }));
  };

  submitBaseInfoForm = (values, actions) => {
    const {
      name,
      title,
      description,
      management_fee,
      performance_fee,
      duration,
      distribution,
      country,
      currency,
      kind_of_fund,
      trading_frequency,
      is_passive,
      is_active,
      open_closed,
    } = values;
    updateFundData(this.props.fund.id, {
      name,
      title,
      description,
      management_fee,
      performance_fee,
      duration,
      distribution,
      country_id: country,
      currency_id: currency,
      kind_of_fund,
      trading_frequency,
      is_passive,
      is_active,
      open_closed,
      se_symbols: this.state.symbols,
      excluded: this.state.excludedCountries.map((item) => item.value),
      fund_types: this.state.selectedFundTypes.map((item) => item.value),
    })
      .then(() => {
        this.props.getAdminFund(this.props.fund.id);
        this.toggleBaseInfoEditModal();
      })
      .catch(() => {
        actions.setErrors({
          submit: 'There was an error submitting the form.',
        });
        actions.setSubmitting(false);
      });
  };

  toggleBaseInfoEditModal = () => {
    this.setState(
      (prevState) => ({
        isBaseInfoEditModalVisible: !prevState.isBaseInfoEditModalVisible,
        excludedCountries: mapObjPropsToSelectFilter({
          list: this.props.fund.excluded,
          label: 'country_name',
          value: 'id',
          category: 'country',
        }),
        selectedFundTypes: mapObjPropsToSelectFilter({
          list: this.props.fund.fund_types,
          label: 'name',
          value: 'id',
          category: 'fund_types',
        }),
      }),
      () => disableScroll(this.state.isBaseInfoEditModalVisible),
    );
  };

  updateFundHeaderData = (data) => {
    updateFundData(this.props.fund.id, data).then(() => {
      this.props.getAdminFund(this.props.fund.id);
    });
  };

  updateStockData = (symbols) => {
    this.setState({ symbols });
  };

  toggleRemoveModalOpenClick = () => {
    this.setState(
      (prevState) => ({
        isRemoveFundModalVisible: !prevState.isRemoveFundModalVisible,
      }),
      () => disableScroll(this.state.isRemoveFundModalVisible),
    );
  };

  removeFund = () => {
    deleteFunds([this.props.fund.id]).then(() => {
      this.toggleRemoveModalOpenClick();
      this.props.history.push(
        `/admin/fundsmanager/manage/${this.props.fund.funds_manager_id}/funds`,
      );
    });
  };

  handleActivePassiveChange = (e, setFieldValue) => {
    const { value } = e.target;
    const is_active = value === 'is_active';
    setFieldValue('is_active', is_active);
    setFieldValue('is_passive', !is_active);
  };

  render() {
    const AboutWithProps = (props) => (
      <FundAbout
        userData={this.props.userData}
        fund={this.props.fund}
        {...props}
      />
    );

    const EditAboutWithProps = (props) => (
      <FundEditAbout
        userData={this.props.userData}
        fund={this.props.fund}
        {...props}
      />
    );

    const NewsContentWithProps = (props) => (
      <FundNewsContent fundId={this.props.fund.id} {...props} />
    );

    const AddNewsWithProps = (props) => (
      <AddFundNews fund={this.props.fund} {...props} />
    );

    const EventsWithProps = (props) => (
      <EventsContent fundId={this.props.fund.id} {...props} />
    );

    return (
      <>
        <FundTitleEdit
          openEditModal={this.toggleBaseInfoEditModal}
          openRemoveModal={this.toggleRemoveModalOpenClick}
          userData={this.props.userData}
          fundId={this.props.fund.id}
        />
        <FundHeaderEdit
          fund={this.props.fund}
          userData={this.props.userData}
          updateFundHeaderData={this.updateFundHeaderData}
        />
        {this.state.isRemoveFundModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this fund?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFund}
            handleCancelClick={this.toggleRemoveModalOpenClick}
          />
        )}
        <FundNavigation
          fund={this.props.fund}
          path={`/admin/fund/manage/${this.props.fund.id}`}
          isAdminPanel
          isEditor={isFundEditor(this.props.userData, this.props.fund.id)}
          isSecondaryOrPrimaryAdmin={isFundsSecondaryOrPrimaryAdmin(
            this.props.userData,
            this.props.fund.id,
          )}
          isGlobalAdmin={this.props.userData.is_global_admin}
          isContentAdmin={this.props.userData.is_content_admin}
        />
        {this.state.isBaseInfoEditModalVisible && this.props.fund && (
          <FundBaseInfoEditModal
            closeModal={this.toggleBaseInfoEditModal}
            getBaseInfoFormInitialValues={this.getBaseInfoFormInitialValues}
            submitBaseInfoForm={this.submitBaseInfoForm}
            setCountryToExclude={this.setCountryToExclude}
            updateStockData={this.updateStockData}
            symbols={this.props.fund.se_symbols}
            handleExcludedCountryRemoveClick={
              this.handleExcludedCountryRemoveClick
            }
            setFundTypeSelected={this.setFundTypeSelected}
            handleFundTypeRemoveClick={this.handleFundTypeRemoveClick}
            excludedCountries={this.state.excludedCountries}
            selectedFundTypes={this.state.selectedFundTypes}
            countriesList={this.props.countriesList}
            currenciesList={this.props.currenciesList}
            fundTypesList={this.props.fundTypesList}
            handleActivePassiveChange={this.handleActivePassiveChange}
          />
        )}
        <Switch>
          <Route
            path="/admin/fund/manage/:id/about"
            component={AboutWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/edit-about"
            component={EditAboutWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/news"
            component={NewsContentWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/add-news"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/edit-news/:newsId"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/events"
            component={EventsWithProps}
          />
          <Route
            path="/admin/fund/manage/:id/add-event"
            component={AddFundEvent}
          />
          <Route
            path="/admin/fund/manage/:id/edit-event/:eventId"
            component={EditFundEvent}
          />
          <Route
            path="/admin/fund/manage/:id/documents"
            component={Documents}
          />
          <Route
            path="/admin/fund/manage/:id/charts"
            render={(props) => (
              <Charts {...props} getChartData={getFundChartData} />
            )}
          />
          <Route component={Page404Loader} />
        </Switch>
      </>
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(FundManagement));
