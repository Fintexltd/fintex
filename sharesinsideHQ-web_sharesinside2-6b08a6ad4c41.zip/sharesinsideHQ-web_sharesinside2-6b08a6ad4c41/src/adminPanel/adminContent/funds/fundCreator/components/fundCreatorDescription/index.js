import React, { Fragment } from 'react';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import TextEditor from 'common/components/textEditor';
import './style.scss';

const fundCreatorDescription = ({
  values,
  errors,
  touched,
  handleChange,
  handleBlur,
  updateFundCreationFormState,
  setFieldValue,
  setFieldTouched,
  setFieldError,
}) => (
  <Fragment>
    <FormGroup className="description__form-group">
      <Input
        className="description__input"
        name="title"
        placeholder="Title"
        value={values.title}
        error={errors.title}
        touched={touched.title}
        onChange={handleChange}
        onBlur={e => {
          handleBlur(e);
          updateFundCreationFormState(values);
        }}
      />
      <span className="description__letter-counter">
        {`${values.title ? values.title.trimStart().length : 0}/128`}
      </span>
    </FormGroup>

    <TextEditor
      className="description__text-editor"
      name="description"
      placeholder="Description*"
      values={values}
      errors={errors}
      touched={touched}
      setFieldError={setFieldError}
      setFieldValue={setFieldValue}
      setFieldTouched={setFieldTouched}
      handleStateUpdate={updateFundCreationFormState}
    />
  </Fragment>
);

export default fundCreatorDescription;
