import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { FormGroup } from 'reactstrap';
import classnames from 'classnames';
import Input from 'common/components/input';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import SelectFundTypes from 'adminPanel/adminContent/fundsManagers/fundsManagerCreator/components/fundTypes';
import SingleSelect from 'common/components/customSelect/singleSelect';
import { tradingFrequenciesList } from '../utils/tradingFrequenciesListUtils';

class FundCreatorForm extends Component {
  constructor(props) {
    super(props);
    this.timer = null;
  }
  render() {
    const {
      errorsFromApi,
      fundTypesList,
      values,
      errors,
      touched,
      handleChange,
      handleBlur,
      selectedFundTypes,
      handleFundTypeRemoveClick,
      setFundTypeSelected,
      setFieldValue,
      fundTypesError,
    } = this.props;

    return (
      <section className="panel-section info">
        <FormGroup>
          <Input
            type="text"
            name="name"
            placeholder="Fund name*"
            value={values.name}
            error={errors.name}
            touched={touched.name}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateFundCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="number"
            name="management_fee"
            placeholder="Management fee*"
            value={values.management_fee}
            error={errors.management_fee}
            touched={touched.management_fee}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateFundCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="number"
            name="performance_fee"
            placeholder="Performance fee*"
            value={values.performance_fee}
            error={errors.performance_fee}
            touched={touched.performance_fee}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateFundCreationFormState(values);
            }}
          />
        </FormGroup>

        <FormGroup>
          <div
            className={classnames({
              'admin-fund-creator__select-container': errors.trading_frequency,
            })}
          >
            <SingleSelect
              description="Trading"
              onChange={value => {
                setFieldValue('trading_frequency', value[0].value || null);
              }}
              options={tradingFrequenciesList}
              value={tradingFrequenciesList.filter(
                frequency => frequency.value === values.trading_frequency,
              )}
              category="trading_frequency"
            />{' '}
            {errors.trading_frequency && (
              <div className="api-errors-container">
                {errors.trading_frequency}
              </div>
            )}
            {errorsFromApi.trading_frequency && (
              <div className="api-errors-container">
                {errorsFromApi.trading_frequency}
              </div>
            )}
          </div>
        </FormGroup>

        <FormGroup>
          <div
            className={classnames({
              'admin-fund-creator__select-container': fundTypesError,
            })}
          >
            <SelectFundTypes
              selectedFundTypes={selectedFundTypes}
              fundTypesList={mapObjPropsToSelectFilter({
                list: fundTypesList,
                label: 'name',
                value: 'id',
                category: 'fund_types',
              })}
              handleSelectedFundTypeRemoveClick={handleFundTypeRemoveClick}
              setFundTypeToSelect={setFundTypeSelected}
              setFieldValue={setFieldValue}
            />{' '}
            {fundTypesError && (
              <div className="api-errors-container">{fundTypesError}</div>
            )}
            {errorsFromApi.fund_types && (
              <div className="api-errors-container">
                {errorsFromApi.fund_types}
              </div>
            )}
          </div>
        </FormGroup>

        <FormGroup>
          <Input
            type="number"
            name="duration"
            placeholder="Duration* (number of years)"
            value={values.duration}
            error={errors.duration}
            touched={touched.duration}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateFundCreationFormState(values);
            }}
          />
        </FormGroup>
        {/* distribution-hide
        <FormGroup>
          <Input
            name="distribution"
            placeholder="Distribution*"
            value={values.distribution}
            error={errors.distribution}
            touched={touched.distribution}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateFundCreationFormState(values);
            }}
          />
        </FormGroup>
        */}
      </section>
    );
  }
}

const mapStateToProps = state => ({ fundTypesList: state.fundTypes.list });

FundCreatorForm.defaultProps = {
  fundTypesList: [],
  errorsFromApi: {},
  errors: {},
};

FundCreatorForm.propTypes = {
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  errorsFromApi: PropTypes.objectOf(PropTypes.string),
  errors: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ),
  handleChange: PropTypes.func.isRequired,
  handleBlur: PropTypes.func.isRequired,
  updateFundCreationFormState: PropTypes.func.isRequired,
  fundTypesError: PropTypes.string.isRequired,
};
export default connect(mapStateToProps)(FundCreatorForm);
