import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

Yup.addMethod(Yup.string, 'maxContext', function(max, msg) {
  return this.test({
    name: 'maxContext',
    exclusive: true,
    message: msg || `Description must be shorter than ${max} characters`,
    test: value =>
      !value ||
      value.replace(/<br>/g, ' ').replace(/<[^>]+>/g, '').length <= max,
  });
});

export const fundCreatorFormSchema = Yup.object().shape({
  name: Yup.string()
    .required('This field is required.')
    .max(64, 'Name must be shorter than 64 characters'),

  management_fee: Yup.number()
    .min(0)
    .required('This field is required.'),

  performance_fee: Yup.number()
    .min(0)
    .required('This field is required.'),

  duration: Yup.number()
    .min(0)
    .required('This field is required.'),

  // distribution-hide
  // distribution: Yup.number()
  //  .min(0)
  //  .required('This field is required.'),

  currency_id: Yup.string().required('This field is required.'),

  fund_types: Yup.array().required('At least 1 asset class is required.'),

  kind_of_fund: Yup.string().required('This field is required.'),

  is_active: Yup.boolean().required('This field is required.'),

  is_passive: Yup.boolean().required('This field is required.'),

  open_closed: Yup.string().required('This field is required.'),

  country_id: Yup.string().required('This field is required.'),

  facebook: Yup.string()
    .matches(/facebook.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  twitter: Yup.string()
    .matches(/twitter.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  linkedin: Yup.string()
    .matches(/linkedin.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  title: Yup.string().max(128, 'Title must be shorter than 128 symbols'),

  description: Yup.string()
    .maxContext(8000)
    .required('This field is required'),
});
