export default function setSubmitErrors(error) {
  let submitErrors = {};
  if (error.response.data.errors) {
    submitErrors = {
      ...(error.response.data.errors.name
        ? { name: error.response.data.errors.name }
        : {}),
      ...(error.response.data.errors.phone
        ? { phone: error.response.data.errors.phone }
        : {}),
      ...(error.response.data.errors.email
        ? { email: error.response.data.errors.email }
        : {}),
      ...(error.response.data.errors.country_id
        ? { country_id: error.response.data.errors.country_id }
        : {}),
      ...(error.response.data.errors.website
        ? { website: error.response.data.errors.website }
        : {}),
      ...(error.response.data.errors.address
        ? { address: error.response.data.errors.address }
        : {}),
    };
  }
  return submitErrors;
}
