export const tradingFrequenciesList = [
  {
    label: 'none',
    value: '',
    category: 'trading',
  },
  {
    label: 'Daily',
    value: 'daily',
    category: 'trading',
  },
  {
    label: 'Weekly',
    value: 'weekly',
    category: 'trading',
  },
  {
    label: 'Monthly',
    value: 'monthly',
    category: 'trading',
  },
  {
    label: 'Quarterly',
    value: 'quarterly',
    category: 'trading',
  },
  {
    label: 'Half Yearly',
    value: 'halfyearly',
    category: 'trading',
  },
  {
    label: 'Yearly',
    value: 'yearly',
    category: 'trading',
  },
];

export const tradingFrequenciesFiltersList = [
  {
    label: 'Daily',
    value: 'daily',
    category: 'trading',
  },
  {
    label: 'Weekly',
    value: 'weekly',
    category: 'trading',
  },
  {
    label: 'Monthly',
    value: 'monthly',
    category: 'trading',
  },
  {
    label: 'Quarterly',
    value: 'quarterly',
    category: 'trading',
  },
  {
    label: 'Half Yearly',
    value: 'halfyearly',
    category: 'trading',
  },
  {
    label: 'Yearly',
    value: 'yearly',
    category: 'trading',
  },
];
