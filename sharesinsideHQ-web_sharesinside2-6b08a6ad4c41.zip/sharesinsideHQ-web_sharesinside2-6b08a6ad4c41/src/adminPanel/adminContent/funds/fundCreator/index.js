import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Row, Col, Button, ButtonGroup, FormGroup } from 'reactstrap';
import { Link } from 'react-router-dom';
import { Formik } from 'formik';
import { bindActionCreators } from 'redux';
import { fundCreatorFormSchema as validationSchema } from 'adminPanel/adminContent/funds/fundCreator/validators/fundsCreatorFormSchema';
import {
  requestImageToken,
  sendFundDataRequest,
} from 'adminPanel/adminContent/funds/fundCreator/api/fundCreatorApi';
import CreatorHeader from 'adminPanel/adminContent/common/components/creatorHeader';
import CreatorSocialMedia from 'adminPanel/adminContent/common/components/creatorSocialMedia';
import UploadAttachments from 'common/components/uploadAttachments/index.js';
import AddLinks from 'common/components/addLinks/index.js';
import AddLinkOrVideo from 'common/components/addLinkOrVideo';
import CreatorStock from 'adminPanel/adminContent/common/containers/creatorStock';
import ModalContainer from 'common/components/modalContainer';
import ExcludeCountries from 'common/components/excludeCountries';
import { disableScroll } from 'common/utils/disableScroll';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { fetchAdminFundsManager } from 'adminPanel/redux/actions/funds/admin/adminFundsManagersActions';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchFundTypesList from 'common/redux/actions/fundTypesListActions';
import fetchCurrenciesList from 'common/redux/actions/currenciesListActions';
import { fetchUserData } from 'common/redux/actions/userDataActions';
import setSubmitErrors from 'adminPanel/adminContent/adminCreator/utils/submitErrors';
import SingleSelect from 'common/components/customSelect/singleSelect';
import classnames from 'classnames';
import RadioInput from 'common/components/radioInput';
import FundsCreatorForm from './containers/fundCreatorForm';
import FundCreatorDescription from './components/fundCreatorDescription';
import './index.scss';
import { kindOfFundList } from '../utils/fundTypes';

const mapStateToProps = (state) => ({
  fundsManager: state.adminFundsManager.currentFundsManager,
  countriesList: state.countries.list,
  currenciesList: state.currencies.list,
});

const mapDispatchToProps = (dispatch) => ({
  fetchFundsManager: bindActionCreators(fetchAdminFundsManager, dispatch),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
  fetchFundTypesList: () => dispatch(fetchFundTypesList()),
  fetchCurrenciesList: () => dispatch(fetchCurrenciesList()),
  fetchUserData: bindActionCreators(fetchUserData, dispatch),
});

class FundCreatorView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiErrors: {},
      backgroundUrl: '',
      logoUrl: '',
      imagesErrors: '',
      sendSuccessMsg: '',
      displaySocialMediaForm: false,
      excludedFilters: [],
      selectedFundTypes: [],
      countryError: '',
      currencyError: '',
      fundTypesError: '',
      activePassiveError: '',
      formData: {
        funds_manager_id: this.props.fundsManager.id,
        logo: '',
        background: '',
        name: '',
        trading_frequency: '',
        management_fee: '',
        performance_fee: '',
        duration: '',
        kind_of_fund: '',
        distribution: '',
        links: [],
        video_links: [],
        videos: [],
        country_id: '',
        currency_id: '',
        social_media: [],
        excluded: [],
        se_symbols: [],
      },
    };
  }

  componentDidMount() {
    this.props.fetchFundsManager(this.props.match.params.id);
    this.props.fetchCountriesList();
    this.props.fetchFundTypesList();
    this.props.fetchCurrenciesList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.fundsManager !== this.props.fundsManager) {
      const excludedCountries = mapObjPropsToSelectFilter({
        list: nextProps.fundsManager.excluded,
        label: 'country_name',
        value: 'id',
        category: 'country',
      });
      this.setState((prevState) => ({
        excludedFilters: excludedCountries,
        formData: {
          ...prevState.formData,
          funds_manager_id: nextProps.fundsManager.id,
          excluded: excludedCountries.map((item) => item.value),
        },
      }));
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      prevState.displaySocialMediaForm !== this.state.displaySocialMediaForm
    ) {
      disableScroll(this.state.displaySocialMediaForm);
    }
  }

  onVideoLinkAdded = (videoLink) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [videoLink],
        videos: [],
      },
    }));
  };

  onVideoLinkRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [],
      },
    }));
  };

  onVideoTokenAdded = (videoToken) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [videoToken],
        video_links: [],
      },
    }));
  };

  onVideoTokenRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [],
      },
    }));
  };

  updateStockData = (se_symbols, setValues, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...{ se_symbols },
      },
    }));

    setValues({
      ...values,
      se_symbols,
    });
  };

  setHeaderImages = (e, type, setFieldValue) => {
    const imagesValidSize = {
      logo: 200,
      background: 940,
    };
    const imageFile = e.target.files[0];
    const reader = new FileReader();
    const image = new Image();
    if (imageFile) {
      reader.readAsDataURL(imageFile);
      reader.addEventListener('load', () => {
        image.src = reader.result;
        image.addEventListener('load', () => {
          if (
            (type === 'logo' &&
              image.width >= imagesValidSize.logo &&
              image.height >= imagesValidSize.logo) ||
            (type === 'background' && image.width >= imagesValidSize.background)
          ) {
            this.setState({
              [`${type}Url`]: image.src,
              imagesErrors: '',
            });

            this.setImageToken(imageFile, type, setFieldValue);
          } else {
            this.setState({
              imagesErrors: `${
                type.charAt(0).toUpperCase() + type.slice(1)
              } image should be at least ${imagesValidSize[type]}px wide ${
                type === 'logo' ? `and ${imagesValidSize[type]} px height` : ``
              }`,
            });
          }
        });
      });
    }
  };

  setImageToken = (imageFile, type, setFieldValue) => {
    const imgAsForm = new FormData();
    imgAsForm.append('file', imageFile);

    requestImageToken(imgAsForm, type)
      .catch((err) => {
        if (err.response.data) {
          this.setState({ imagesErrors: err.response.data.message });
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState((prevState) => ({
            formData: {
              ...prevState.formData,
              [`${type}`]: res.data.token,
            },
          }));

          setFieldValue(type, res.data.token);
        }
      });
  };

  setCountryToExclude = (values) => {
    this.setState((prevState) => ({
      excludedFilters: values,
      formData: {
        ...prevState.formData,
        excluded: values.map((item) => item.value),
      },
    }));
  };

  setFundTypeSelected = (values, setFieldValue) => {
    this.setState({
      selectedFundTypes: values,
    });
    setFieldValue(
      'fund_types',
      values.map((item) => item.value),
    );
    this.removeFundTypesError();
  };

  handleFundTypeRemoveClick = (label, setFieldValue) => {
    this.setState(
      (prevState) => ({
        selectedFundTypes: prevState.selectedFundTypes.filter(
          (el) => el.label !== label,
        ),
      }),
      () => {
        setFieldValue(
          'fund_types',
          this.state.selectedFundTypes.map((item) => item.value),
        );
      },
    );
  };

  handleExcludedFilterRemoveClick = (label) => {
    this.setState((prevState) => {
      const filteredOut = prevState.excludedFilters.filter(
        (el) => el.label !== label,
      );
      return {
        excludedFilters: filteredOut,
        formData: {
          ...prevState.formData,
          excluded: filteredOut.map((item) => item.value),
        },
      };
    });
  };

  displaySocialMediaForm = (shouldDisplay) => {
    this.setState({ displaySocialMediaForm: shouldDisplay });
  };

  updateSocialMediaLinks = (socialLinks) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        social_media: socialLinks,
      },
    }));
  };

  removeSocialLink = (linkTypeToRemove) => {
    this.updateSocialMediaLinks(
      this.state.formData.social_media.filter(
        (link) => link.type !== linkTypeToRemove,
      ),
    );
  };

  toggleDisplayDescriptionForm = () => {
    this.setState((prevState) => ({
      displayDescriptionForm: !prevState.displayDescriptionForm,
    }));
  };

  updateFundCreationFormState = (values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...values,
      },
    }));
  };

  mergeLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: values,
      },
    }));
  };

  sendFundData = (setErrors) => {
    const data = JSON.stringify(this.state.formData);
    sendFundDataRequest(data)
      .catch((error) => {
        if (error.response.data) {
          setErrors(setSubmitErrors(error));
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState({ sendSuccessMsg: res.data.message });
          this.props.fetchUserData();
        }
      });
  };

  handleActivePassiveChange = (e, setFieldTouched, setFieldValue) => {
    const { value } = e.target;
    setFieldTouched(value);
    const is_active = value === 'is_active';
    setFieldValue('is_active', is_active);
    setFieldValue('is_passive', !is_active);
    this.removeActivePassiveError();
  };

  removeCountryError = () => this.setState({ countryError: '' });

  removeCurrencyError = () => this.setState({ currencyError: '' });

  removeFundTypesError = () => this.setState({ fundTypesError: '' });

  removeActivePassiveError = () => this.setState({ activePassiveError: '' });

  render() {
    const {
      apiErrors,
      logoUrl,
      backgroundUrl,
      imagesErrors,
      displaySocialMediaForm,
      sendSuccessMsg,
      countryError,
      currencyError,
      fundTypesError,
      activePassiveError,
      selectedFundTypes,
    } = this.state;
    const { fundsManager, countriesList, currenciesList } = this.props;

    return (
      <div className="admin-fund-creator">
        <header className="admin-creator-header">
          <h2 className="section-header">
            {' '}
            Create Fund for 
            {' '}
            {fundsManager.name}
          </h2>
        </header>
        <Formik
          ref={this.form}
          validationSchema={validationSchema}
          initialValues={{}}
          onSubmit={(values, { setErrors }) => {
            this.sendFundData(setErrors);
          }}
          render={({
            values,
            errors,
            setValues,
            touched,
            isValid,
            handleSubmit,
            handleChange,
            handleBlur,
            setFieldTouched,
            setFieldError,
            setFieldValue,
          }) => (
            <form onSubmit={handleSubmit} noValidate>
              <CreatorHeader
                setHeaderImages={this.setHeaderImages}
                logoUrl={logoUrl}
                backgroundUrl={backgroundUrl}
                imagesErrors={imagesErrors}
                socialLinks={this.state.formData.social_media}
                displaySocialMediaForm={(shouldDisplay) =>
                  this.displaySocialMediaForm(shouldDisplay)}
                removeSocialLink={this.removeSocialLink}
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue}
              />
              <Row>
                <Col>
                  <header className="admin-creator-header basic">
                    <h2 className="section-header">Basic Information</h2>
                  </header>
                </Col>
              </Row>
              <Row>
                <Col md={6}>
                  <FundsCreatorForm
                    errorsFromApi={apiErrors}
                    updateFundCreationFormState={(values1) =>
                      this.updateFundCreationFormState(values1)}
                    setFieldValue={setFieldValue}
                    checkBoxisChecked={this.setAllowShareHolders}
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    handleFundTypeRemoveClick={this.handleFundTypeRemoveClick}
                    setFundTypeSelected={this.setFundTypeSelected}
                    selectedFundTypes={selectedFundTypes}
                    fundTypesError={fundTypesError}
                  />
                  <FundCreatorDescription
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    updateFundCreationFormState={
                      this.updateFundCreationFormState
                    }
                  />
                  <AddLinkOrVideo
                    onLinkAdded={this.onVideoLinkAdded}
                    onLinkRemoved={this.onVideoLinkRemoved}
                    onVideoTokenAdded={this.onVideoTokenAdded}
                    onVideoTokenRemoved={this.onVideoTokenRemoved}
                  />
                  <UploadAttachments name="attachments" values={values} />
                  <AddLinks
                    name="links"
                    placeholder="Add Link"
                    linkType="type_default"
                    objectType="links"
                    values={values}
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                  />
                </Col>
                <Col md={6}>
                  <FormGroup>
                    <div
                      className={classnames({
                        'admin-fund-creator__select-container': countryError,
                      })}
                    >
                      <SingleSelect
                        description="Country/Jurisdiction*"
                        onChange={(value) => {
                          setFieldTouched('country_id', true);
                          setFieldValue('country_id', value[0].value);
                          if (countryError) {
                            this.removeCountryError();
                          }
                        }}
                        options={mapObjPropsToSelectFilter({
                          list: countriesList
                            ? countriesList.map(
                                ({ country_name: countryName, id }) => ({
                                  value: id,
                                  label: countryName,
                                }),
                              )
                            : [],
                          label: 'label',
                          value: 'value',
                          category: 'country',
                        })}
                        value={[
                          {
                            category: 'country',
                            label: countriesList.filter(
                              (element) => element.id === values.country_id,
                            )[0]
                              ? countriesList.filter(
                                  (element) => element.id === values.country_id,
                                )[0].country_name
                              : '',
                            value: values.country_id,
                          },
                        ]}
                        category="country"
                        isSearchable
                      />
                      {' '}
                      {countryError && (
                        <div className="api-errors-container">
                          {countryError}
                        </div>
                      )}
                      {apiErrors.country_id && (
                        <div className="api-errors-container">
                          {apiErrors.country_id}
                        </div>
                      )}
                    </div>
                  </FormGroup>
                  <FormGroup>
                    <div
                      className={classnames({
                        'admin-fund-creator__select-container': currencyError,
                      })}
                    >
                      <SingleSelect
                        description="Currency*"
                        onChange={(value) => {
                          setFieldTouched('currency_id', true);
                          setFieldValue('currency_id', value[0].value);
                          if (currencyError) {
                            this.removeCurrencyError();
                          }
                        }}
                        options={mapObjPropsToSelectFilter({
                          list: currenciesList
                            ? currenciesList.map(
                                ({ currency_name, currency_symbol, id }) => ({
                                  value: id,
                                  label: `${currency_symbol} - ${currency_name}`,
                                }),
                              )
                            : [],
                          label: 'label',
                          value: 'value',
                          category: 'currency_id',
                        })}
                        value={[
                          {
                            category: 'currency_id',
                            label: currenciesList.filter(
                              (element) => element.id === values.currency_id,
                            )[0]
                              ? currenciesList.filter(
                                  (element) =>
                                    element.id === values.currency_id,
                                )[0].currency_name
                              : '',
                            value: values.currency_id,
                          },
                        ]}
                        category="currency_id"
                        isSearchable
                      />
                      {' '}
                      {currencyError && (
                        <div className="api-errors-container">
                          {currencyError}
                        </div>
                      )}
                      {apiErrors.currency_id && (
                        <div className="api-errors-container">
                          {apiErrors.currency_id}
                        </div>
                      )}
                    </div>
                  </FormGroup>
                  <FormGroup>
                    <div
                      className={classnames({
                        'admin-fund-creator__select-container':
                          touched.kind_of_fund && errors.kind_of_fund,
                      })}
                    >
                      <SingleSelect
                        description="Fund type*"
                        onChange={(value) => {
                          setFieldTouched('kind_of_fund', true);
                          setFieldValue('kind_of_fund', value[0].value);
                        }}
                        options={kindOfFundList}
                        value={kindOfFundList.filter(
                          (fundType) => fundType.value === values.kind_of_fund,
                        )}
                        category="kind_of_fund"
                        isSearchable
                      />
                      {' '}
                      {touched.kind_of_fund && errors.kind_of_fund && (
                        <div className="api-errors-container">
                          {errors.kind_of_fund}
                        </div>
                      )}
                      {apiErrors.kind_of_fund && (
                        <div className="api-errors-container">
                          {apiErrors.kind_of_fund}
                        </div>
                      )}
                    </div>
                  </FormGroup>
                  <div className="admin-fund-creator__stock">
                    <CreatorStock
                      type="fund"
                      updateStockData={(stock) =>
                        this.updateStockData(stock, setValues, values)}
                      errors={errors}
                      touched={touched}
                      setValues={setValues}
                    />
                  </div>
                  <p className="admin-fund-creator__section-title">
                    Active/Passive*:
                  </p>
                  <div className="admin-fund-creator__input-row">
                    <RadioInput
                      name="activePassive"
                      value="is_active"
                      checked={values.is_active}
                      onChange={(e) =>
                        this.handleActivePassiveChange(
                          e,
                          setFieldTouched,
                          setFieldValue,
                        )}
                    >
                      Active
                    </RadioInput>
                    <RadioInput
                      name="activePassive"
                      value="is_passive"
                      checked={values.is_passive}
                      onChange={(e) =>
                        this.handleActivePassiveChange(
                          e,
                          setFieldTouched,
                          setFieldValue,
                        )}
                    >
                      Passive
                    </RadioInput>
                  </div>
                  <div className="api-errors-container">
                    {activePassiveError}
                  </div>
                  <p className="admin-fund-creator__section-title">
                    Open/Closed*:
                  </p>
                  <div className="admin-fund-creator__input-row">
                    <RadioInput
                      name="openClosed"
                      value="open"
                      checked={values.open_closed === 'open'}
                      onChange={(e) => {
                        setFieldTouched('open_closed', true);
                        const { value } = e.target;
                        setFieldValue('open_closed', value);
                      }}
                    >
                      Open
                    </RadioInput>
                    <RadioInput
                      name="openClosed"
                      value="closed"
                      checked={values.open_closed === 'closed'}
                      onChange={(e) => {
                        setFieldTouched('open_closed', true);
                        const { value } = e.target;
                        setFieldValue('open_closed', value);
                      }}
                    >
                      Closed
                    </RadioInput>
                  </div>
                  {touched.open_closed && errors.open_closed && (
                    <div className="api-errors-container">
                      {errors.open_closed}
                    </div>
                  )}
                  <Row className="mt-4">
                    <Col>
                      <div className="admin-fund-creator__exclude">
                        <ExcludeCountries
                          excludedCountries={this.state.excludedFilters}
                          countriesList={mapObjPropsToSelectFilter({
                            list: this.props.countriesList,
                            label: 'country_name',
                            value: 'id',
                            category: 'country',
                          })}
                          handleExcludedCountryRemoveClick={
                            this.handleExcludedFilterRemoveClick
                          }
                          setCountryToExclude={this.setCountryToExclude}
                          title="Exclude news from:"
                        />
                      </div>
                    </Col>
                  </Row>
                </Col>
              </Row>
              {displaySocialMediaForm && (
                <CreatorSocialMedia
                  displaySocialMediaForm={(shouldDisplay) =>
                    this.displaySocialMediaForm(shouldDisplay)}
                  updateSocialMediaLinks={(links) =>
                    this.updateSocialMediaLinks(links)}
                  socialLinks={this.state.formData.social_media}
                />
              )}
              <ButtonGroup className="float-right">
                <Button outline color="primary mr-4">
                  CANCEL
                </Button>
                <Button
                  color="primary"
                  type="submit"
                  onClick={() => {
                    this.updateFundCreationFormState(values);
                    this.setState({ imagesErrors: '' });
                    if (!values.country_id) {
                      this.setState({ countryError: 'This field is required' });
                    }
                    if (!values.fund_types || !values.fund_types.length) {
                      this.setState({
                        fundTypesError: 'This field is required',
                      });
                    }
                    if (!values.is_active && !values.is_passive) {
                      this.setState({
                        activePassiveError: 'This field is required',
                      });
                    }
                    if (!values.currency_id) {
                      this.setState({
                        currencyError: 'This field is required',
                      });
                    }
                    if (!isValid) {
                      setValues({
                        name: values.name,
                        management_fee: values.management_fee,
                        performance_fee: values.performance_fee,
                        fund_types: values.fund_types,
                        duration: values.duration,
                        distribution: values.distribution,
                        title: values.title,
                        description: values.description,
                        kind_of_fund: values.kind_of_fund,
                        country_id: values.country_id,
                        currency_id: values.currency_id,
                        is_active: values.is_active,
                        is_passive: values.is_passive,
                        open_closed: values.open_closed,
                        website: values.website,
                        trading_frequency: values.trading_frequency,
                        logo: values.logo,
                        se_symbols: this.state.formData.se_symbols,
                      });
                    }
                  }}
                >
                  save
                </Button>
              </ButtonGroup>
              <div>{this.state.sendSuccessMsg}</div>
            </form>
          )}
        />
        {' '}
        {sendSuccessMsg && (
          <ModalContainer className="admin-fund-creator__modal">
            <h2 className="admin-fund-creator__modal__header">
              The fund has been created.
            </h2>
            <ButtonGroup>
              <Link
                to={`/admin/fundsmanager/manage/${fundsManager.id}/funds`}
                rel="noopener noreferrer"
              >
                <Button color="primary">Ok</Button>
              </Link>
            </ButtonGroup>
          </ModalContainer>
        )}
      </div>
    );
  }
}

FundCreatorView.defaultProps = {
  countriesList: [],
  currenciesList: [],
};

FundCreatorView.propTypes = {
  fundsManager: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
  countriesList: PropTypes.arrayOf(PropTypes.object),
  currenciesList: PropTypes.arrayOf(PropTypes.object),
  fetchFundsManager: PropTypes.func.isRequired,
  fetchCountriesList: PropTypes.func.isRequired,
  fetchFundTypesList: PropTypes.func.isRequired,
  fetchCurrenciesList: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(FundCreatorView);
