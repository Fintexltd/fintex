import axios from 'axios';

export const requestImageToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=type_fund_${type}`,
    data,
  );

export const sendFundDataRequest = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/funds`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });

export const updateFundData = (id, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/funds/${id}`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
