import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  fetchFundsList,
  updateFundsList,
  removeFunds,
} from 'adminPanel/redux/actions/funds/admin/adminFundsListActions';
import { deleteFunds } from 'adminPanel/api/fundsApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import RemoveModal from 'common/components/removeModal';
import RemoveButton from 'common/components/removeButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import AddFundButton from '../components/addFundButton';
import FundItem from '../components/fundItem';
import FundsManagementSearch from './fundsManagementSearch';

const mapStateToProps = (state) => ({
  adminFundsList: state.adminFunds.list,
  nextPageIndex: state.adminFunds.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsList: bindActionCreators(fetchFundsList, dispatch),
  removeFundsList: bindActionCreators(removeFunds, dispatch),
  updateFundsList: bindActionCreators(updateFundsList, dispatch),
});

class FundsContent extends Component {
  constructor() {
    super();
    this.state = {
      fundsToRemove: [],
      fundToRemoveId: null,
      isRemoveFundModalVisible: false,
      isRemoveMultipleFundsModalVisible: false,
      isLoadMoreClicked: false,
    };
  }

  componentDidMount() {
    if (this.props.fundsManagerId) {
      this.props.getFundsList(this.props.fundsManagerId);
    } else {
      this.props.removeFundsList();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  getFundsIfNecessary = () => {
    if (this.props.nextPageIndex) {
      this.handleLoadMoreClick(this.props.nextPageIndex);
    }
  };

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () =>
        this.props.getFundsList(
          this.props.fundsManagerId,
          this.props.nextPageIndex,
        ),
      );
    }
  };

  handleCheckAllFundsClick = () => {
    const ids = this.isRemoveFundAllowed()
      ? this.props.adminFundsList.map((fund) => fund.id)
      : [];
    this.setState({ fundsToRemove: ids });
  };

  handleFundCheckboxClick = (value) => {
    const { checked, id } = value.target;
    this.setState((prevState) => {
      let checkedFunds = prevState.fundsToRemove;
      if (checked) {
        checkedFunds.push(Number(id));
      } else {
        checkedFunds = prevState.fundsToRemove.filter(
          (fundId) => fundId !== Number(id),
        );
      }
      return { fundsToRemove: checkedFunds };
    });
  };

  handleClearSelectionClick = () => {
    this.setState({ fundsToRemove: [] });
  };

  toggleRemoveFundModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveFundModalVisible: !prevState.isRemoveFundModalVisible,
    }));
  };

  toggleRemoveMultipleFundsModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveMultipleFundsModalVisible: !prevState.isRemoveMultipleFundsModalVisible,
    }));
  };

  handleRemoveFundsClick = () => {
    this.toggleRemoveMultipleFundsModalOpen();
  };

  handleRemoveFundClick = (id) => {
    this.setState({ fundToRemoveId: id });
    this.toggleRemoveFundModalOpen();
  };

  removeFund = () => {
    deleteFunds([this.state.fundToRemoveId]).then(() => {
      this.props.updateFundsList(
        this.props.adminFundsList.filter(
          (item) => item.id !== this.state.fundToRemoveId,
        ),
      );
      this.setState({ fundToRemoveId: null });
      this.toggleRemoveFundModalOpen();
    });
  };

  removeFunds = () => {
    const removeAllVisible =
      this.state.fundsToRemove.length === this.props.adminFundsList.length;
    deleteFunds(this.state.fundsToRemove).then(() => {
      this.props.updateFundsList(
        this.props.adminFundsList.filter(
          (item) => !this.state.fundsToRemove.includes(item.id),
        ),
      );
      this.setState({ fundsToRemove: [] });
      this.toggleRemoveMultipleFundsModalOpen();
      if (removeAllVisible) {
        this.getFundsIfNecessary();
      }
    });
  };

  isRemovePermissionExists = () =>
    this.props.userData &&
    checkUserPermission(
      this.props.userData,
      PERMISSIONS_FUNCTION_TYPES.REMOVE_FUNDS_MANAGER,
    );

  isRemoveFundAllowed = () =>
    this.props.userData.is_global_admin || this.props.userData.is_content_admin;

  render() {
    return (
      <div className="admin-management-container">
        <FundsManagementSearch fundsManagerId={this.props.fundsManagerId} />
        {this.isRemovePermissionExists() && (
          <div className="admin-management__buttons">
            {this.state.fundsToRemove.length !==
              this.props.adminFundsList.length && (
              <CheckButton
                description="Check all"
                handleClick={this.handleCheckAllFundsClick}
              />
            )}
            {this.state.fundsToRemove.length > 0 && (
              <div className="admin-management__clear-button">
                <ClearButton
                  description="Clear selection"
                  handleClick={this.handleClearSelectionClick}
                />
              </div>
            )}
            {this.state.fundsToRemove.length > 0 && (
              <RemoveButton
                description="Remove checked"
                handleRemoveClick={this.handleRemoveFundsClick}
              />
            )}
          </div>
        )}
        <div className="row">
          <div className="admin-management-item admin-management__add-item">
            <AddFundButton fundsManagerId={this.props.fundsManagerId} />
          </div>
          {this.props.adminFundsList.length > 0 &&
            this.props.adminFundsList.map((item) => (
              <div className="admin-management__company-item" key={item.id}>
                <FundItem
                  fund={item}
                  removeFund={this.handleRemoveFundClick}
                  handleCheckboxClick={this.handleFundCheckboxClick}
                  isChecked={this.state.fundsToRemove.indexOf(item.id) > -1}
                  isRemoveFundAllowed={this.isRemoveFundAllowed}
                />
              </div>
            ))}
        </div>
        <div className="row">
          {this.props.nextPageIndex && (
            <div className="admin-management__load-container">
              <button
                onClick={this.handleLoadMoreClick}
                className="admin-management__load"
              >
                Load more
              </button>
            </div>
          )}
        </div>
        {this.state.isRemoveFundModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this Fund?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFund}
            handleCancelClick={this.toggleRemoveFundModalOpen}
          />
        )}
        {this.state.isRemoveMultipleFundsModalVisible && (
          <RemoveModal
            heading={`Are You sure you want to remove these funds (${
              this.state.fundsToRemove.length
            } ${
              this.state.fundsToRemove.length > 1 ? 'elements' : 'element'
            })?`}
            message="This items will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFunds}
            handleCancelClick={this.toggleRemoveMultipleFundsModalOpen}
          />
        )}
      </div>
    );
  }
}

FundsContent.defaultProps = {
  adminFundsList: [],
  nextPageIndex: null,
};

FundsContent.propTypes = {
  adminFundsList: PropTypes.arrayOf(PropTypes.object),
  removeFundsList: PropTypes.func.isRequired,
  getFundsList: PropTypes.func.isRequired,
  updateFundsList: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  fundsManagerId: PropTypes.number.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(FundsContent);
