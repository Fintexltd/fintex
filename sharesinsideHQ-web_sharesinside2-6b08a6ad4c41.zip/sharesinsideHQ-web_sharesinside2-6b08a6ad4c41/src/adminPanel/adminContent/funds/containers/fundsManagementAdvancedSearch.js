import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchFundTypesList from 'common/redux/actions/fundTypesListActions';
import fetchCurrenciesList from 'common/redux/actions/currenciesListActions';
import { fetchFundsList } from 'adminPanel/redux/actions/funds/admin/adminFundsListActions';
import {
  saveAdminFundsFilters,
  saveAdminFundsActiveCheckbox,
  saveAdminFundsPassiveCheckbox,
} from 'adminPanel/redux/actions/funds/admin/adminFundsFiltersActions';
import FundsManagementAdvancedSearchView from '../components/fundsManagementAdvancedSearchView';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  continentsList: state.continents.list,
  fundTypesList: state.fundTypes.list,
  currenciesList: state.currencies.list,
  fundsFilters: state.adminFundsFilters,
});

const mapDispatchToProps = dispatch => ({
  getFundsList: bindActionCreators(fetchFundsList, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getContinentsList: bindActionCreators(fetchContinentsList, dispatch),
  getCurrenciesList: bindActionCreators(fetchCurrenciesList, dispatch),
  getFundTypesList: bindActionCreators(fetchFundTypesList, dispatch),
  saveFundsFilters: bindActionCreators(saveAdminFundsFilters, dispatch),
  saveFundsActiveCheckbox: bindActionCreators(
    saveAdminFundsActiveCheckbox,
    dispatch,
  ),
  saveFundsPassiveCheckbox: bindActionCreators(
    saveAdminFundsPassiveCheckbox,
    dispatch,
  ),
});

class FundsManagementAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsList = debounce(() => {
      props.getFundsList(props.fundsManagerId);
    }, 500);
  }

  componentDidMount() {
    this.props.getContinentsList();
    this.props.getCurrenciesList();
    this.props.getFundTypesList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveFundsFilters(values.length > 0 ? values : { category });
    this.debouncedGetFundsList();
  };

  handleCheckboxChange = value => {
    switch (value.target.name) {
      case 'active':
        this.props.saveFundsActiveCheckbox(value.target.checked);
        break;
      case 'passive':
        this.props.saveFundsPassiveCheckbox(value.target.checked);
        break;
      default:
        break;
    }
    this.debouncedGetFundsList();
  };

  render() {
    return (
      <FundsManagementAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        continentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'continent',
        })}
        currenciesList={mapObjPropsToSelectFilter({
          list: this.props.currenciesList,
          label: 'currency_symbol',
          value: 'id',
          category: 'currency',
        })}
        fundTypesList={mapObjPropsToSelectFilter({
          list: this.props.fundTypesList,
          label: 'name',
          value: 'id',
          category: 'fundType',
        })}
        handleFilterUsage={this.handleFilterUsage}
        fundsFilters={this.props.fundsFilters}
        handleCheckboxChange={this.handleCheckboxChange}
      />
    );
  }
}

FundsManagementAdvancedSearch.defaultProps = {
  countriesList: [],
  continentsList: [],
  currenciesList: [],
  fundTypesList: [],
};

FundsManagementAdvancedSearch.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  currenciesList: PropTypes.arrayOf(PropTypes.object),
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  getContinentsList: PropTypes.func.isRequired,
  getCurrenciesList: PropTypes.func.isRequired,
  getFundTypesList: PropTypes.func.isRequired,
  fundsManagerId: PropTypes.number.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagementAdvancedSearch);
