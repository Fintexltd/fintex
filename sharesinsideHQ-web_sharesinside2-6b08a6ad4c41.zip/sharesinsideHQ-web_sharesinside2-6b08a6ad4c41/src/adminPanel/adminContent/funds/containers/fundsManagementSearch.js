import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import { fetchFundsList } from 'adminPanel/redux/actions/funds/admin/adminFundsListActions';
import {
  removeAdminFundsFilters,
  saveAdminFundsSearch,
  saveAdminFundsFilters,
} from 'adminPanel/redux/actions/funds/admin/adminFundsFiltersActions';
import FundsManagementSearchView from '../components/fundsManagementSearchView';

const mapStateToProps = state => ({
  resultsNumber: state.adminFunds.resultsNumber,
  fundsFilters: state.adminFundsFilters,
});

const mapDispatchToProps = dispatch => ({
  getFundsList: bindActionCreators(fetchFundsList, dispatch),
  removeFundsFilters: bindActionCreators(removeAdminFundsFilters, dispatch),
  saveFundsSearch: bindActionCreators(saveAdminFundsSearch, dispatch),
  saveFundsFilters: bindActionCreators(saveAdminFundsFilters, dispatch),
});

class FundsManagementSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsList = debounce(() => {
      props.getFundsList(props.fundsManagerId);
    }, 500);
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeFundsFilters();
    this.debouncedGetFundsList();
  };

  handleSearchInputChange = text => {
    this.props.saveFundsSearch(text);
    this.debouncedGetFundsList();
  };

  mapActiveFiltersLists = () => [
    ...this.props.fundsFilters.country,
    ...this.props.fundsFilters.fundType,
    ...this.props.fundsFilters.currency,
    ...this.props.fundsFilters.continent,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.fundsFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveFundsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetFundsList();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <FundsManagementSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        fundsFilters={this.props.fundsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
        fundsManagerId={this.props.fundsManagerId}
      />
    );
  }
}

FundsManagementSearch.defaultProps = {
  resultsNumber: null,
};

FundsManagementSearch.propTypes = {
  getFundsList: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  fundsManagerId: PropTypes.number.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagementSearch);
