import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { FormGroup, Col } from 'reactstrap';
import TextEditor from 'common/components/textEditor';
import fetchLocationData from 'common/redux/actions/locationDataActions.js';
import fetchCountriesList from 'common/redux/actions/countriesListActions.js';
import Input from 'common/components/input';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import EditEventMap from 'adminPanel/adminContent/editEvent/containers/editEventMap';
import { SingleDatePicker } from 'react-dates';
import { TimePicker } from 'antd';
import RadioInput from 'common/components/radioInput';
import SingleSelect from 'common/components/customSelect/singleSelect';
import moment from 'moment';
import UploadAttachments from 'common/components/uploadAttachments';
import AddLinks from 'common/components/addLinks';
import { isFundsSecondaryOrPrimaryAdmin } from 'userAuth/utils/permissions.js';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { googleMapURL } from 'common/api/googleMapsApi';
import 'react-dates/lib/css/_datepicker.css';

class EditEventsFormView extends Component {
  constructor(props) {
    super(props);
    this.timer = null;
    this.state = {
      date: moment(this.props.initDate) || moment({}),
      time: moment(this.props.initDate) || moment(),
    };
  }

  componentDidMount() {
    this.props.fetchCountriesList();
    this.props.fetchLocationData(
      `${this.props.values.city} ${this.props.values.adress}`,
    );
  }

  handleLocationData = (city, adress) => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.props.fetchLocationData(`${city} ${adress}`);
    }, 1000);
  };

  handleChangeData = (setFieldValue) => {
    const { date } = this.state;
    date.set('hour', this.state.time.hour());
    date.set('minute', this.state.time.minute());
    const month =
      date.month() + 1 < 10 ? `0${date.month() + 1}` : date.month() + 1;
    const day = date.date() < 10 ? `0${date.date()}` : date.date();
    const hour = date.hour() < 10 ? `0${date.hour()}` : date.hour();
    const minute = date.minute() < 10 ? `0${date.minute()}` : date.minute();
    const stringDate = `${date.year()}-${month}-${day} ${hour}:${minute}:00`;

    setFieldValue('event_date', stringDate);

    this.props.updateFundEventsFormState({
      ...this.props.values,
      event_date: stringDate,
    });
  };

  render() {
    const {
      initFiles,
      initWebcastLinks,
      initVideoLinks,
      values,
      errors,
      touched,
      handleChange,
      handleBlur,
      setFieldValue,
      setFieldTouched,
      setFieldError,
      countriesList,
      updateFundEventsFormState,
      mergeLinksArray,
      deleteLinksArray,
      handleInitFilesDelete,
      handlePublishRadioChange,
      publishDate,
      publishTime,
      publishRadioValue,
      handlePublishDataChange,
      isPublished,
      handlePublicityRadioChange,
      isBusiness,
      isInternal,
      userData,
      fundId,
      isLocal,
      handleNotificationRangeRadioChange,
      publishAt,
      receivers,
      handleNotificationReceiverCheckboxClick,
      updateLocation,
      links,
    } = this.props;
    return (
      <>
        <Col md={6}>
          <section className="edit-event-form">
            <FormGroup>
              <Input
                type="text"
                name="title"
                placeholder="Title*"
                focused
                value={values.title}
                error={errors.title}
                touched={touched.title}
                onChange={handleChange}
                onBlur={(e) => {
                  handleBlur(e);
                  this.props.updateFundEventsFormState(values);
                }}
              />
              <span className="edit-event-form__letter-counter">
                {`${(values.title || '').trimStart().length}/200`}
              </span>
            </FormGroup>
            <FormGroup>
              <TextEditor
                className="description__text-editor"
                name="description"
                placeholder="Content"
                values={values}
                defaultValue={values.description}
                errors={errors}
                touched={touched}
                setFieldError={setFieldError}
                setFieldValue={setFieldValue}
                setFieldTouched={setFieldTouched}
                handleStateUpdate={updateFundEventsFormState}
              />
            </FormGroup>
            <FormGroup>
              <SingleSelect
                description="Country*"
                onChange={(value) => {
                  setFieldTouched('country_id', true);
                  setFieldValue('country_id', value[0].value);
                  values.country_id = value[0].value;
                }}
                options={mapObjPropsToSelectFilter({
                  list: countriesList
                    ? countriesList.map(
                        ({ country_name: countryName, id }) => ({
                          value: id,
                          label: countryName,
                        }),
                      )
                    : [],
                  label: 'label',
                  value: 'value',
                  category: 'country',
                })}
                value={[
                  {
                    category: 'country',
                    label: countriesList.filter(
                      (element) => element.id === values.country_id,
                    )[0]
                      ? countriesList.filter(
                          (element) => element.id === values.country_id,
                        )[0].country_name
                      : '',
                    value: values.country_id,
                  },
                ]}
                category="country"
              />
            </FormGroup>
            <FormGroup>
              <Input
                name="city"
                placeholder="City*"
                value={values.city}
                error={errors.city}
                touched={touched.city}
                onChange={(e) => {
                  handleChange(e);
                  updateLocation(e.target.value, values.adress);
                  this.handleLocationData(e.target.value, values.adress);
                }}
                onBlur={(e) => {
                  handleBlur(e);
                  this.handleLocationData(e.target.value, values.adress);
                  this.props.updateFundEventsFormState(values);
                }}
              />
            </FormGroup>
            <FormGroup>
              <Input
                name="adress"
                placeholder="Location"
                value={values.adress}
                error={errors.adress}
                touched={touched.adress}
                onChange={(e) => {
                  handleChange(e);
                  updateLocation(values.city, e.target.value);
                  this.handleLocationData(values.city, e.target.value);
                }}
                onBlur={(e) => {
                  handleBlur(e);
                  this.handleLocationData(values.city, e.target.value);
                  this.props.updateFundEventsFormState(values);
                }}
              />
            </FormGroup>
            <FormGroup>
              <SingleDatePicker
                showDefaultInputIcon
                date={this.state.date}
                onDateChange={(date) => {
                  if (date)
                    this.setState({ date }, () => {
                      this.handleChangeData(setFieldValue);
                    });
                }}
                focused
                keepOpenOnDateSelect
                onFocusChange={() => {}}
                placeholder="Event Time"
                small
                required
                displayFormat="DD/MM/YYYY"
                numberOfMonths={1}
                id="event_time"
              />

              <TimePicker
                defaultValue={moment(this.state.time, 'h:mm A')}
                format="h:mm A"
                onChange={(time) => {
                  if (time)
                    this.setState({ time }, () => {
                      this.handleChangeData(setFieldValue);
                    });
                }}
                placeholder="Time"
                size="large"
              />
            </FormGroup>
            <FormGroup className="edit-event-form__attachments">
              <UploadAttachments
                name="files"
                values={values}
                initFiles={initFiles}
                handleInitFilesDelete={handleInitFilesDelete}
                setFieldValue={setFieldValue}
              />
            </FormGroup>
            <FormGroup>
              <AddLinks
                name="type_webcast"
                id="type_webcast"
                placeholder="Add Webcast Link"
                linkType="type_webcast"
                objectType="links"
                initLinks={initWebcastLinks}
                mergeLinksArray={mergeLinksArray}
                deleteLinksArray={deleteLinksArray}
                isVideoLink
              />
              {links.filter((link) => link.type === 'type_webcast').length >
                1 && (
                <p className="edit-event-form__error">
                  Only one webcast link is allowed.
                </p>
              )}
            </FormGroup>
            <FormGroup>
              <AddLinks
                name="type_archived_video"
                id="type_archived_video"
                placeholder="Add Archived Video Link"
                linkType="type_archived_video"
                objectType="links"
                mergeLinksArray={mergeLinksArray}
                deleteLinksArray={deleteLinksArray}
                initLinks={initVideoLinks}
                isVideoLink
              />
              {links.filter((link) => link.type === 'type_archived_video')
                .length > 1 && (
                <p className="edit-event-form__error">
                  Only one archived video link is allowed.
                </p>
              )}
            </FormGroup>
          </section>
        </Col>
        <Col md={6}>
          <section className="edit-event-form">
            <div className="google-map">
              <EditEventMap
                googleMapURL={googleMapURL}
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ height: `350px` }} />}
                errors={errors}
                mapElement={
                  <div className="mapElement" style={{ height: `100%` }} />
                }
              />
            </div>
            <div className="add-event-form__section">
              <p className="add-event-form__section-title">Publicity:</p>
              <div className="add-event-form__input-row">
                <RadioInput
                  name="publicity"
                  value="public"
                  checked={!isBusiness && !isInternal}
                  onChange={handlePublicityRadioChange}
                  disabled={isPublished}
                >
                  Public
                </RadioInput>
                <RadioInput
                  name="publicity"
                  value="business"
                  checked={isBusiness}
                  onChange={handlePublicityRadioChange}
                  disabled={isPublished}
                >
                  Investor
                </RadioInput>
                {isFundsSecondaryOrPrimaryAdmin(userData, Number(fundId)) && (
                  <RadioInput
                    name="publicity"
                    value="internal"
                    checked={isInternal}
                    onChange={handlePublicityRadioChange}
                    disabled={isPublished}
                  >
                    VIP
                  </RadioInput>
                )}
              </div>
              {(isPublished ||
                (!isPublished && !publishAt) ||
                (!isPublished &&
                  publishAt &&
                  moment().unix() - publishAt <= 0)) && (
                  <>
                    <p className="add-event-form__section-title">
                      Notification range:
                    </p>
                    <div className="add-event-form__input-row">
                      <RadioInput
                        name="notificationRange"
                        value="global"
                        checked={!isLocal}
                        onChange={handleNotificationRangeRadioChange}
                        disabled={isPublished}
                      >
                        Global
                      </RadioInput>
                      <RadioInput
                        name="notificationRange"
                        value="local"
                        checked={isLocal}
                        onChange={handleNotificationRangeRadioChange}
                        disabled={isPublished}
                      >
                        Local
                      </RadioInput>
                    </div>
                  </>
              )}
              {(isPublished ||
                (!isPublished && !publishAt) ||
                (!isPublished &&
                  publishAt &&
                  moment().unix() - publishAt <= 0)) && (
                  <>
                    <p className="add-news-form__section-title">
                      Notification receiver:
                    </p>
                    <div className="add-event-form__input-row add-event-form__input-row--checkboxes">
                      {!isInternal && (
                      <>
                        <AcceptCheckbox
                          name="followers"
                          id="followers"
                          onChange={handleNotificationReceiverCheckboxClick}
                          checked={receivers.includes('followers')}
                          disabled={isPublished}
                        >
                          <span>Followers</span>
                        </AcceptCheckbox>
                        <AcceptCheckbox
                          name="shareholders"
                          id="shareholders"
                          onChange={handleNotificationReceiverCheckboxClick}
                          checked={receivers.includes('shareholders')}
                          disabled={isPublished}
                        >
                          <span>Investors</span>
                        </AcceptCheckbox>
                      </>
                    )}
                      <AcceptCheckbox
                        name="vips"
                        id="vips"
                        onChange={handleNotificationReceiverCheckboxClick}
                        checked={receivers.includes('vips')}
                        disabled={isPublished}
                      >
                        <span>VIPs</span>
                      </AcceptCheckbox>
                    </div>
                  </>
              )}
            </div>
            <div className="add-event-form__section">
              <p className="add-event-form__section-heading">Schedule time:</p>
              <div className="add-event-form__input-row">
                <RadioInput
                  name="publish"
                  value="true"
                  checked={publishRadioValue}
                  onChange={handlePublishRadioChange}
                  disabled={isPublished}
                >
                  Publish now
                </RadioInput>
                <RadioInput
                  name="publish"
                  value="false"
                  checked={!publishRadioValue}
                  onChange={handlePublishRadioChange}
                  disabled={isPublished}
                >
                  Set a date
                </RadioInput>
              </div>
              {!publishRadioValue && (
                <FormGroup>
                  <SingleDatePicker
                    showDefaultInputIcon
                    date={publishDate}
                    isOutsideRange={(day) =>
                      day.unix() <= moment().subtract(1, 'day').unix() ||
                      isPublished}
                    onDateChange={(date) =>
                      handlePublishDataChange(date, publishTime)}
                    focused
                    keepOpenOnDateSelect
                    onFocusChange={() => {}}
                    placeholder="Publish Date"
                    small
                    required
                    displayFormat="DD/MM/YYYY"
                    numberOfMonths={1}
                    disabled={isPublished}
                  />
                  <TimePicker
                    defaultValue={moment(publishTime, 'h:mm A')}
                    format="h:mm A"
                    disabled={isPublished}
                    allowEmpty={false}
                    onChange={(time) =>
                      handlePublishDataChange(publishDate, time)}
                    placeholder="Publish Time"
                    size="large"
                  />
                </FormGroup>
              )}
            </div>
          </section>
        </Col>
      </>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchLocationData: (adress) => dispatch(fetchLocationData(adress)),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
});

const mapStateToProps = (state) => ({
  countriesList: state.countries.list,
  industriesList: state.industries.list,
});

EditEventsFormView.defaultProps = {
  countriesList: [],
  errors: {},
  values: {},
};

EditEventsFormView.propTypes = {
  fetchLocationData: PropTypes.func.isRequired,
  fetchCountriesList: PropTypes.func.isRequired,
  countriesList: PropTypes.arrayOf(PropTypes.object),
  values: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ),
  errors: PropTypes.objectOf(PropTypes.string),
  handleChange: PropTypes.func.isRequired,
  handleBlur: PropTypes.func.isRequired,
  setFieldTouched: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EditEventsFormView);
