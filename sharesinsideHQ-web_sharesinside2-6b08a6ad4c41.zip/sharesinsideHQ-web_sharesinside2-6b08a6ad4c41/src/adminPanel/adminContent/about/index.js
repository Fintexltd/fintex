import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { isEditor } from 'userAuth/utils/permissions';
import AttachmentsFile from 'common/components/attachmentsFile';
import AttachmentsLink from 'common/components/attachmentsLink';
import VideoPlayerWrapper from 'common/components/videoPlayerWrapper';
import { disableScroll } from 'common/utils/disableScroll';
import shortid from 'shortid';
import 'news/components/newsDetailsView/index.scss';
import './index.scss';

class About extends Component {
  constructor() {
    super();
    this.state = {
      isVideoDisplayed: false,
    };
  }

  toggleVideoModal = () => {
    this.setState(
      (prevState) => ({
        isVideoDisplayed: !prevState.isVideoDisplayed,
      }),
      () => disableScroll(this.state.isVideoDisplayed),
    );
  };

  render() {
    const { userData, company } = this.props;

    let videos = [];

    if (company.videos && company.video_links) {
      videos = company.videos.length > 0 ? company.videos : company.video_links;
    }

    return (
      <div className="company-about">
        <div className="company-about__title">
          <div className="title__container">
            <p className="title__text">{company.title}</p>
          </div>
          {!isEditor(userData, company.id) && (
            <div className="title__edit">
              <Link
                className="edit__link"
                to={`/admin/company/manage/${company.id}/edit-about`}
              >
                <div className="link__icon" />
                <div className="link__text">Edit</div>
              </Link>
            </div>
          )}
        </div>
        <div
          className="company-about__text"
          dangerouslySetInnerHTML={{ __html: company.description }}
        />
        {videos && videos.length > 0 && (
          <div className="news-details__videos company-about__videos">
            <p className="company-about__media-label">Video:</p>
            <div
              className="placeholder"
              onClick={this.toggleVideoModal}
              role="presentation"
            >
              <img
                src={videos[0].video_img}
                className="video__placeholder"
                alt="placeholder"
              />
              <div className="placeholder__play" />
            </div>
            <VideoPlayerWrapper
              isVideoDisplayed={this.state.isVideoDisplayed}
              toggleVideoModal={this.toggleVideoModal}
              videos={videos}
              indexVideo={0}
            />
          </div>
        )}
        {company.attachments && company.attachments.length > 0 && (
          <>
            <p className="company-about__media-label">Attachments:</p>
            <ul>
              {company.attachments.map((file) => (
                <AttachmentsFile key={shortid.generate()} file={file} />
              ))}
            </ul>
          </>
        )}
        {company.links && company.links.length > 0 && (
          <>
            <p className="company-about__media-label">Links:</p>
            <ul>
              {company.links.map((link) => (
                <AttachmentsLink key={shortid.generate()} link={link} />
              ))}
            </ul>
          </>
        )}
      </div>
    );
  }
}

About.propTypes = {
  company: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
};

export default About;
