import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Row, Col, Button, ButtonGroup } from 'reactstrap';
import { Link } from 'react-router-dom';
import { Formik } from 'formik';
import { bindActionCreators } from 'redux';
import { adminCreatorFormSchema as validationSchema } from 'adminPanel/adminContent/adminCreator/validators/adminCreatorFormSchema.js';
import {
  requestImageToken,
  sendCompanyDataRequest,
} from 'adminPanel/adminContent/adminCreator/api/adminCreatorApi';
import CreatorHeader from 'adminPanel/adminContent/common/components/creatorHeader';
import AdminCreatorForm from 'adminPanel/adminContent/adminCreator/containers/adminCreatorForm';
import CreatorMap from 'adminPanel/adminContent/common/containers/creatorMap';
import CreatorStock from 'adminPanel/adminContent/common/containers/creatorStock';
import CreatorSocialMedia from 'adminPanel/adminContent/common/components/creatorSocialMedia';
import AdminCreatorDescription from 'adminPanel/adminContent/adminCreator/components/adminCreatorDescription';
import UploadAttachments from 'common/components/uploadAttachments/index.js';
import AddLinks from 'common/components/addLinks/index.js';
import AddLinkOrVideo from 'common/components/addLinkOrVideo';
import ModalContainer from 'common/components/modalContainer';
import ExcludeCountries from 'common/components/excludeCountries';
import AddEmails from 'common/components/addEmails';
import { disableScroll } from 'common/utils/disableScroll';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import { fetchUserData } from 'common/redux/actions/userDataActions';
import setSubmitErrors from 'adminPanel/adminContent/adminCreator/utils/submitErrors';
import { googleMapURL } from 'common/api/googleMapsApi';
import './index.scss';

const mapStateToProps = (state) => ({
  countriesList: state.countries.list,
  locationData: state.locationData.results,
});

const mapDispatchToProps = (dispatch) => ({
  fetchCountriesList: () => dispatch(fetchCountriesList()),
  fetchUserData: bindActionCreators(fetchUserData, dispatch),
});

class AdminCreatorView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiErrors: {},
      backgroundUrl: '',
      logoUrl: '',
      imagesErrors: '',
      sendSuccessMsg: '',
      displaySocialMediaForm: false,
      excludedFilters: [],
      countryError: '',
      industryError: '',
      formData: {
        logo: '',
        background: '',
        name: '',
        phone: '',
        links: [],
        video_links: [],
        videos: [],
        email: '',
        location: '',
        website: '',
        industry_id: '',
        country_id: '',
        dont_allow_shareholders: false,
        se_symbols: [],
        social_media: [],
        longitude: 74.011222,
        latitude: 40.706893,
        excluded: [],
        stock_exchange_emails: [],
      },
    };
  }

  componentDidMount() {
    this.props.fetchCountriesList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.locationData !== this.props.locationData) {
      const gpsData = {
        longitude: nextProps.locationData.lng,
        latitude: nextProps.locationData.lat,
      };
      this.updateCompanyCreationFormState(gpsData);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      prevState.displaySocialMediaForm !== this.state.displaySocialMediaForm
    ) {
      disableScroll(this.state.displaySocialMediaForm);
    }
  }

  onVideoLinkAdded = (videoLink) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [videoLink],
        videos: [],
      },
    }));
  };

  onVideoLinkRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [],
      },
    }));
  };

  onVideoTokenAdded = (videoToken) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [videoToken],
        video_links: [],
      },
    }));
  };

  onVideoTokenRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [],
      },
    }));
  };

  setHeaderImages = (e, type, setFieldValue) => {
    const imagesValidSize = { logo: 200, background: 940 };
    const imageFile = e.target.files[0];
    const reader = new FileReader();
    const image = new Image();
    if (imageFile) {
      reader.readAsDataURL(imageFile);
      reader.addEventListener('load', () => {
        image.src = reader.result;
        image.addEventListener('load', () => {
          if (
            (type === 'logo' &&
              image.width >= imagesValidSize.logo &&
              image.height >= imagesValidSize.logo) ||
            (type === 'background' && image.width >= imagesValidSize.background)
          ) {
            this.setState({
              [`${type}Url`]: image.src,
              imagesErrors: '',
            });

            this.setImageToken(imageFile, type, setFieldValue);
          } else {
            this.setState({
              imagesErrors: `${
                type.charAt(0).toUpperCase() + type.slice(1)
              } image should be at least ${imagesValidSize[type]}px wide ${
                type === 'logo' ? `and ${imagesValidSize[type]} px height` : ``
              }`,
            });
          }
        });
      });
    }
  };

  setImageToken = (imageFile, type, setFieldValue) => {
    const imgAsForm = new FormData();
    imgAsForm.append('file', imageFile);

    requestImageToken(imgAsForm, type)
      .catch((err) => {
        if (err.response.data) {
          this.setState({
            imagesErrors: err.response.data.message,
          });
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState((prevState) => ({
            formData: {
              ...prevState.formData,
              [`${type}`]: res.data.token,
            },
          }));

          setFieldValue(type, res.data.token);
        }
      });
  };

  setCountryToExclude = (values) => {
    this.setState((prevState) => ({
      excludedFilters: values,
      formData: {
        ...prevState.formData,
        excluded: values.map((item) => item.value),
      },
    }));
  };

  handleExcludedFilterRemoveClick = (label) => {
    const filteredOut = this.state.excludedFilters.filter(
      (el) => el.label !== label,
    );
    this.setState((prevState) => ({
      excludedFilters: filteredOut,
      formData: {
        ...prevState.formData,
        excluded: filteredOut.map((item) => item.value),
      },
    }));
  };

  displaySocialMediaForm = (shouldDisplay) => {
    this.setState({ displaySocialMediaForm: shouldDisplay });
  };

  updateSocialMediaLinks = (socialLinks) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        social_media: socialLinks,
      },
    }));
  };

  removeSocialLink = (linkTypeToRemove) => {
    this.updateSocialMediaLinks(
      this.state.formData.social_media.filter(
        (link) => link.type !== linkTypeToRemove,
      ),
    );
  };

  toggleDisplayDescriptionForm = () => {
    this.setState((prevState) => ({
      displayDescriptionForm: !prevState.displayDescriptionForm,
    }));
  };

  updateCompanyCreationFormState = (values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...values,
      },
    }));
  };

  updateStockData = (se_symbols, setValues, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...{ se_symbols },
      },
    }));

    setValues({
      ...values,
      se_symbols,
    });
  };

  mergeLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: values,
      },
    }));
  };

  addStockExchangeEmail = (email) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stock_exchange_emails: [
          ...prevState.formData.stock_exchange_emails,
          email,
        ],
      },
    }));
  };

  removeStockExchangeEmail = (emailToRemove) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stock_exchange_emails: prevState.formData.stock_exchange_emails.filter(
          (email) => email !== emailToRemove,
        ),
      },
    }));
  };

  sendCompanyData = (setErrors) => {
    const data = JSON.stringify(this.state.formData);
    sendCompanyDataRequest(data)
      .catch((error) => {
        if (error.response.data) {
          setErrors(setSubmitErrors(error));
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState({ sendSuccessMsg: res.data.message });
          this.props.fetchUserData();
        }
      });
  };

  removeCountryError = () => this.setState({ countryError: '' });

  removeIndustryError = () => this.setState({ industryError: '' });

  render() {
    const {
      apiErrors,
      logoUrl,
      backgroundUrl,
      imagesErrors,
      displaySocialMediaForm,
      sendSuccessMsg,
      countryError,
      industryError,
    } = this.state;

    return (
      <div className="admin-company-creator">
        <header className="admin-creator-header">
          <h2 className="section-header"> Create New Company</h2>
        </header>
        <Formik
          ref={this.form}
          validationSchema={validationSchema}
          onSubmit={(values, { setErrors }) => {
            this.sendCompanyData(setErrors);
          }}
          initialValues={{}}
          render={({
            values,
            errors,
            setValues,
            touched,
            isValid,
            handleSubmit,
            handleChange,
            handleBlur,
            setFieldTouched,
            setFieldError,
            setFieldValue,
          }) => (
            <form onSubmit={handleSubmit} noValidate>
              <CreatorHeader
                setHeaderImages={this.setHeaderImages}
                logoUrl={logoUrl}
                backgroundUrl={backgroundUrl}
                imagesErrors={imagesErrors}
                socialLinks={this.state.formData.social_media}
                displaySocialMediaForm={(shouldDisplay) =>
                  this.displaySocialMediaForm(shouldDisplay)}
                removeSocialLink={this.removeSocialLink}
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue}
              />
              <Row>
                <Col>
                  <header className="admin-creator-header basic">
                    <h2 className="section-header"> Basic Information </h2>
                  </header>
                </Col>
              </Row>
              <Row>
                <Col md={6}>
                  <AdminCreatorForm
                    errorsFromApi={apiErrors}
                    updateCompanyCreationFormState={(values1) =>
                      this.updateCompanyCreationFormState(values1)}
                    setFieldValue={setFieldValue}
                    checkBoxisChecked={this.setAllowShareHolders}
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    countryError={countryError}
                    industryError={industryError}
                    removeCountryError={this.removeCountryError}
                    removeIndustryError={this.removeIndustryError}
                  />

                  <AdminCreatorDescription
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    updateCompanyCreationFormState={
                      this.updateCompanyCreationFormState
                    }
                  />

                  <AddLinkOrVideo
                    onLinkAdded={this.onVideoLinkAdded}
                    onLinkRemoved={this.onVideoLinkRemoved}
                    onVideoTokenAdded={this.onVideoTokenAdded}
                    onVideoTokenRemoved={this.onVideoTokenRemoved}
                  />

                  <UploadAttachments name="attachments" values={values} />

                  <AddLinks
                    name="links"
                    placeholder="Add Link"
                    linkType="type_default"
                    objectType="links"
                    values={values}
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                  />
                </Col>

                <Col md={6}>
                  <div className="google-map">
                    <CreatorMap
                      googleMapURL={googleMapURL}
                      loadingElement={<div style={{ height: `100%` }} />}
                      containerElement={<div style={{ height: `350px` }} />}
                      errors={errors}
                      mapElement={(
                        <div
                          className="mapElement"
                          style={{ height: `100%` }}
                        />
                      )}
                    />
                  </div>

                  <Row className="mt-4">
                    <Col>
                      <div className="admin-company-creator__stock">
                        <CreatorStock
                          type="equity"
                          updateStockData={(stock) =>
                            this.updateStockData(stock, setValues, values)}
                          errors={errors}
                          touched={touched}
                          setValues={setValues}
                        />
                      </div>
                      <div className="admin-company-creator__exclude">
                        <ExcludeCountries
                          excludedCountries={this.state.excludedFilters}
                          countriesList={mapObjPropsToSelectFilter({
                            list: this.props.countriesList,
                            label: 'country_name',
                            value: 'id',
                            category: 'country',
                          })}
                          handleExcludedCountryRemoveClick={
                            this.handleExcludedFilterRemoveClick
                          }
                          setCountryToExclude={this.setCountryToExclude}
                          title="Exclude news from:"
                        />
                      </div>
                      <AddEmails
                        addEmail={this.addStockExchangeEmail}
                        emails={this.state.formData.stock_exchange_emails}
                        removeEmail={this.removeStockExchangeEmail}
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>

              {displaySocialMediaForm && (
                <CreatorSocialMedia
                  displaySocialMediaForm={(shouldDisplay) =>
                    this.displaySocialMediaForm(shouldDisplay)}
                  updateSocialMediaLinks={(links) =>
                    this.updateSocialMediaLinks(links)}
                  socialLinks={this.state.formData.social_media}
                />
              )}
              <ButtonGroup className="float-right">
                <Button outline color="primary  mr-4">
                  CANCEL
                </Button>

                <Button
                  color="primary"
                  type="submit"
                  onClick={() => {
                    this.updateCompanyCreationFormState(values);
                    this.setState({ imagesErrors: '' });
                    if (!values.country_id) {
                      this.setState({ countryError: 'This field is required' });
                    }
                    if (!values.industry_id) {
                      this.setState({
                        industryError: 'This field is required',
                      });
                    }
                    if (!isValid) {
                      setValues({
                        name: values.name,
                        email: values.email,
                        industry_id: values.industry_id,
                        country_id: values.country_id,
                        adress: values.adress,
                        website: values.website,
                        logo: values.logo,
                        se_symbols: this.state.formData.se_symbols,
                        description: values.description,
                        title: values.title,
                      });
                    }
                  }}
                >
                  send request
                </Button>
              </ButtonGroup>

              <div>{this.state.sendSuccessMsg}</div>
            </form>
          )}
        />
        {sendSuccessMsg && (
          <ModalContainer className="admin-company-creator__modal">
            <h2 className="admin-company-creator__modal__header">
              The company has been created.
            </h2>
            <p className="admin-company-creator__modal__message">
              It will be visible in the system after its acceptance.
            </p>

            <ButtonGroup>
              <Link to="/admin/company/management" rel="noopener noreferrer">
                <Button color="primary">Ok</Button>
              </Link>
            </ButtonGroup>
          </ModalContainer>
        )}
      </div>
    );
  }
}

AdminCreatorView.defaultProps = {
  countriesList: [],
};

AdminCreatorView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  fetchCountriesList: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AdminCreatorView);
