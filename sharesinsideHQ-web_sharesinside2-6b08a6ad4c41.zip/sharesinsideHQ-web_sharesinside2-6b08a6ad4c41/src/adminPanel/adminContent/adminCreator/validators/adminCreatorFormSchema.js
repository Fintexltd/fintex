import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

Yup.addMethod(Yup.string, 'maxContext', function(max, msg) {
  return this.test({
    name: 'maxContext',
    exclusive: true,
    message: msg || `Description must be shorter than ${max} characters`,
    test: value =>
      !value ||
      value.replace(/<br>/g, ' ').replace(/<[^>]+>/g, '').length <= max,
  });
});

export const adminCreatorFormSchema = Yup.object().shape({
  name: Yup.string()
    .required('This field is required.')
    .max(64, 'Description must be shorter than 64 characters'),
  phone: Yup.string()
    .matches(
      /^\+\d*$/,
      'Phone number must be at least 8 digits long and start with a +.',
    )
    .min(9, 'Phone number must be at least 8 digits long and start with a +.')
    .max(16, 'Phone number must be at most 15 digits long and start with a +.'),
  email: Yup.string().email('This field must be a valid email'),

  adress: Yup.string().required('This field is required.'),

  website: Yup.string()
    .required('This field is required.')
    .matches(validUrl, 'This field must be a valid URL'),

  industry_id: Yup.string().required('This field is required.'),
  country_id: Yup.string().required('This field is required.'),

  logo: Yup.string().required('Logo image is required.'),

  facebook: Yup.string()
    .matches(/facebook.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  twitter: Yup.string()
    .matches(/twitter.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  linkedin: Yup.string()
    .matches(/linkedin.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  title: Yup.string().max(128, 'Title must be shorter than 128 symbols'),
  description: Yup.string()
    .maxContext(8000)
    .required('This field is required'),
});
