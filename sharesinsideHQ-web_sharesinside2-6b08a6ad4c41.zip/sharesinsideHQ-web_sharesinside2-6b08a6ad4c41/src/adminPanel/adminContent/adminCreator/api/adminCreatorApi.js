import axios from 'axios';

export const requestImageToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=type_company_${type}`,
    data,
  );

export const sendCompanyDataRequest = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/companies?`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });

export const updateCompanyData = (id, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/companies/${id}`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
