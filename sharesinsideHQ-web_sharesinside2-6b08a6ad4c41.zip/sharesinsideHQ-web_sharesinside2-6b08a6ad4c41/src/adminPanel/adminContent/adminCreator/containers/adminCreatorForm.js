import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { FormGroup } from 'reactstrap';
import classnames from 'classnames';
import fetchLocationData from 'common/redux/actions/locationDataActions';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import Input from 'common/components/input';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import fetchIndustriesList from 'common/redux/actions/inustriesListActions';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import SingleSelect from 'common/components/customSelect/singleSelect';

class AdminCreatorForm extends Component {
  constructor(props) {
    super(props);
    this.timer = null;
  }

  componentDidMount() {
    this.props.fetchCountriesList();
    this.props.fetchIndustriesList();
  }

  handleLocationData = e => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      const adress = e.target.value;
      this.props.fetchLocationData(adress);
    }, 1000);
  };

  render() {
    const {
      errorsFromApi,
      industriesList,
      countriesList,
      values,
      errors,
      touched,
      handleChange,
      handleBlur,
      setFieldTouched,
      setFieldValue,
      countryError,
      industryError,
      removeCountryError,
      removeIndustryError,
    } = this.props;

    return (
      <section className="panel-section info">
        <FormGroup>
          <Input
            type="text"
            name="name"
            placeholder="Company name*"
            value={values.name}
            error={errors.name}
            touched={touched.name}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            name="phone"
            placeholder="Contact number"
            value={values.phone}
            error={errors.phone}
            touched={touched.phone}
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="email"
            name="email"
            placeholder="E-mail address"
            value={values.email}
            error={errors.email}
            touched={touched.email}
            onChange={e => {
              handleChange(e);

              setFieldTouched('email', false);
            }}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            name="adress"
            placeholder="Location*"
            value={values.adress}
            error={errors.adress}
            touched={touched.adress}
            onChange={e => {
              handleChange(e);
              this.handleLocationData(e);
            }}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <div
            className={classnames({
              'admin-company-creator__select-container': countryError,
            })}
          >
            <SingleSelect
              description="Country*"
              onChange={value => {
                setFieldTouched('country_id', true);
                setFieldValue('country_id', value[0].value);
                if (countryError) {
                  removeCountryError();
                }
              }}
              options={mapObjPropsToSelectFilter({
                list: countriesList
                  ? countriesList.map(({ country_name: countryName, id }) => ({
                      value: id,
                      label: countryName,
                    }))
                  : [],
                label: 'label',
                value: 'value',
                category: 'country',
              })}
              value={[
                {
                  category: 'country',
                  label: countriesList.filter(
                    element => element.id === values.country_id,
                  )[0]
                    ? countriesList.filter(
                        element => element.id === values.country_id,
                      )[0].country_name
                    : '',
                  value: values.country_id,
                },
              ]}
              category="country"
            />
            {countryError && (
              <div className="api-errors-container">{countryError}</div>
            )}
            {errorsFromApi.country_id && (
              <div className="api-errors-container">
                {errorsFromApi.country_id}
              </div>
            )}
          </div>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            name="website"
            placeholder="Website*"
            value={values.website}
            error={errors.website}
            touched={touched.website}
            onChange={e => {
              handleChange(e);

              setFieldTouched('website', false);
            }}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <div
            className={classnames({
              'admin-company-creator__select-container': industryError,
            })}
          >
            <SingleSelect
              description="Industry*"
              onChange={value => {
                setFieldTouched('industry_id', true);
                setFieldValue('industry_id', value[0].value);
                if (industryError) {
                  removeIndustryError();
                }
              }}
              options={mapObjPropsToSelectFilter({
                list: industriesList
                  ? industriesList.map(({ name, id }) => ({
                      value: id,
                      label: name,
                    }))
                  : [],
                label: 'label',
                value: 'value',
                category: 'industry',
              })}
              value={[
                {
                  category: 'industry',
                  label: industriesList.filter(
                    element => element.id === values.industry_id,
                  )[0]
                    ? industriesList.filter(
                        element => element.id === values.industry_id,
                      )[0].name
                    : '',
                  value: values.industry_id,
                },
              ]}
              category="industry"
            />
            {industryError && (
              <div className="api-errors-container">{industryError}</div>
            )}
          </div>
        </FormGroup>
        <FormGroup>
          <AcceptCheckbox
            name="dont_allow_shareholders"
            id="dont_allow_shareholders"
            onChange={handleChange}
            onBlur={e => {
              handleBlur(e);
              this.props.updateCompanyCreationFormState(values);
            }}
            value={values.dont_allow_shareholders}
          >
            Don&apos;t allow shareholders
          </AcceptCheckbox>
        </FormGroup>
      </section>
    );
  }
}

const mapDispatchToProps = dispatch => ({
  fetchLocationData: adress => dispatch(fetchLocationData(adress)),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
  fetchIndustriesList: () => dispatch(fetchIndustriesList()),
});

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  industriesList: state.industries.list,
});

AdminCreatorForm.defaultProps = {
  countriesList: [],
  industriesList: [],
  errorsFromApi: {},
  errors: {},
};

AdminCreatorForm.propTypes = {
  fetchLocationData: PropTypes.func.isRequired,
  fetchCountriesList: PropTypes.func.isRequired,
  fetchIndustriesList: PropTypes.func.isRequired,
  countriesList: PropTypes.arrayOf(PropTypes.object),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  errorsFromApi: PropTypes.objectOf(PropTypes.string),
  errors: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ),
  handleChange: PropTypes.func.isRequired,
  handleBlur: PropTypes.func.isRequired,
  setFieldTouched: PropTypes.func.isRequired,
  updateCompanyCreationFormState: PropTypes.func.isRequired,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(AdminCreatorForm);
