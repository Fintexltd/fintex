import React, { Component } from 'react';
import { connect } from 'react-redux';
import EditEventForm from 'adminPanel/adminContent/editEvent/containers/editEventForm';
import { fetchEventsEditDataRequest } from 'adminPanel/adminContent/editEvent/api/editEventApi.js';
import './style.scss';

const mapStateToProps = state => ({
  userData: state.userData.data,
  locationData: state.locationData.results,
});

class EditEvent extends Component {
  state = {
    event: {},
  };

  componentDidMount() {
    fetchEventsEditDataRequest(this.props.match.params.eventId).then(res => {
      this.setState({ event: res.data });
    });
  }

  render() {
    return (
      <div>
        <EditEventForm
          companyId={this.props.match.params.id}
          eventId={this.props.match.params.eventId}
          initEventData={this.state.event}
          userData={this.props.userData}
          locationData={this.props.locationData}
        />
      </div>
    );
  }
}
export default connect(mapStateToProps)(EditEvent);
