import * as yup from 'yup';

yup.addMethod(yup.string, 'maxContext', function(max, msg) {
  return this.test({
    name: 'maxContext',
    exclusive: true,
    message: msg || `Description must be shorter than ${max} characters`,
    test: value =>
      !value ||
      value.replace(/<br>/g, ' ').replace(/<[^>]+>/g, '').length <= max,
  });
});

yup.addMethod(yup.string, 'minTitle', function(min, msg) {
  return this.test({
    name: 'minTitle',
    exclusive: true,
    message: msg || `Title must be at least ${min} character`,
    test: value => !value || value.trimStart().length >= min,
  });
});

yup.addMethod(yup.string, 'maxTitle', function(max, msg) {
  return this.test({
    name: 'maxTitle',
    exclusive: true,
    message: msg || `Title must be at most ${max} character`,
    test: value => !value || value.trimStart().length <= max,
  });
});

export const addEventSchema = yup.object().shape({
  title: yup
    .string()
    .minTitle(1)
    .maxTitle(200)
    .required('This field is required.'),
  description: yup
    .string()
    .maxContext(8000)
    .min(1),
  city: yup.string().required('This field is required.'),
  country_id: yup.string().required('This field is required.'),
});
