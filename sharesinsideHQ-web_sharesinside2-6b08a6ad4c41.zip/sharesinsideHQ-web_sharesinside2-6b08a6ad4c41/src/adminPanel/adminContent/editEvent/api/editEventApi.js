import axios from 'axios';

export const requestImageToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=type_company_${type}`,
    data,
  );

export const requestAttachmentToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=${type}&file=${data}`,
    data,
    {
      headers: {
        Accept: 'application/json',
      },
    },
  );

export const fetchEventsEditDataRequest = (eventId) =>
  axios.get(`${process.env.REACT_APP_API_URL}/events/${eventId}/edit`);

export const updateEventsDataRequest = (eventId, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/events/${eventId}`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
