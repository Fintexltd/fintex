import React, { Fragment, Component } from 'react';
import classNames from 'classnames';
import moment from 'moment';
import { connect } from 'react-redux';
import HistoricalDataForm from 'adminPanel/adminContent/historical/containers/historicalDataForm';
import { bindActionCreators } from 'redux';
import { removeHistoricalData } from 'common/redux/actions/companyHistoricalDataActions';

const mapDispatchToProps = dispatch => ({
  removeHistoricalData: bindActionCreators(removeHistoricalData, dispatch),
});

class HistoricalData extends Component {
  state = {
    isEdit: false,
  };

  editHistorical = () => {
    this.setState({
      isEdit: true,
    });
  };

  cancelEdit = () => {
    this.setState({
      isEdit: false,
    });
  };

  removeHistorical = id => {
    this.props.removeHistoricalData(id, this.props.sectionId);
  };

  render() {
    const { sectionId, historical, companyId } = this.props;
    return (
      <Fragment>
        <HistoricalDataForm
          companyId={companyId}
          sectionId={sectionId}
          data={historical}
          isEdit={this.state.isEdit}
          formFunction="edit"
          historicalId={historical.id}
          cancelEdit={this.cancelEdit}
        />
        <tr
          className="company-historical-data__company-row"
          style={{
            display: this.state.isEdit ? 'none' : 'table-row',
          }}
        >
          <th scope="row" className="align-middle">
            {moment.unix(historical.timestamp).format('DD.MM.YYYY')}
          </th>
          <td className="align-middle">{historical.fiscal_year}</td>
          <td className="align-middle">{historical.title}</td>
          <td className="align-middle">
            <a
              href={historical.file.url}
              rel="noopener noreferrer"
              target="_blank"
              className="link__container"
            >
              <div className="link_icon">
                <div
                  className={classNames({
                    'historical-link__image': true,
                    pdf:
                      historical.file.mime_type.split('/')[0] === 'application',
                    image: historical.file.mime_type.split('/')[0] === 'image',
                    video: historical.file.mime_type.split('/')[0] === 'video',
                  })}
                />
              </div>
              <div className="link__text">
                {' '}
                {historical.file.oryginal_name}{' '}
              </div>
            </a>
          </td>

          <td className="align-middle">
            <div
              className="link__container"
              onClick={this.editHistorical}
              role="presentation"
            >
              <div className="link_icon">
                <div className="historical-link__image edit" />
              </div>
              <div className="link__text edit">Edit</div>
            </div>
            <div
              className="link__container"
              onClick={() => this.removeHistorical(historical.id)}
              role="presentation"
            >
              <div className="link_icon">
                <div className="historical-link__image remove" />
              </div>
              <div className="link__text remove">Remove</div>
            </div>
          </td>
        </tr>
      </Fragment>
    );
  }
}

export default connect(
  null,
  mapDispatchToProps,
)(HistoricalData);
