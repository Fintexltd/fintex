import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Input from 'common/components/input';
import HistoricalDataView from 'adminPanel/adminContent/historical/components/historicalDataView';
import validationSchema from 'adminPanel/adminContent/historical/validators';
import RemoveModal from 'common/components/removeModal';
import {
  fetchCompanyHistoricalData,
  fetchCompanyHistoricalDataMore,
  removeCompanyHistoricalData,
  addCompanyHistoricalSection,
  editCompanyHistoricalSection,
  removeCompanyHistoricalSection,
} from 'common/redux/actions/companyHistoricalDataActions';
import { disableScroll } from 'common/utils/disableScroll';
import FormModal from 'common/components/modals/form';

const mapStateToProps = (state) => ({
  historicalDataList: state.companyHistoricalData.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getCompanyHistoricalData: bindActionCreators(
    fetchCompanyHistoricalData,
    dispatch,
  ),
  getCompanyHistoricalDataMore: bindActionCreators(
    fetchCompanyHistoricalDataMore,
    dispatch,
  ),
  removeCompanyHistoricalData: bindActionCreators(
    removeCompanyHistoricalData,
    dispatch,
  ),
  addCompanyHistoricalSection: bindActionCreators(
    addCompanyHistoricalSection,
    dispatch,
  ),
  editCompanyHistoricalSection: bindActionCreators(
    editCompanyHistoricalSection,
    dispatch,
  ),
  removeCompanyHistoricalSection: bindActionCreators(
    removeCompanyHistoricalSection,
    dispatch,
  ),
});

class CompanyHistoricalData extends Component {
  constructor() {
    super();
    this.state = {
      sectionId: null,
      isRemoveModalVisible: false,
      isInputModalVisible: false,
      isEdit: false,
      values: {
        name: '',
      },
    };
  }

  componentDidMount() {
    const companyId = Number(this.props.match.params.id);
    if (
      !(
        this.props.userData.relations.secondary_admin &&
        this.props.userData.relations.secondary_admin.includes(companyId)
      ) &&
      !(
        this.props.userData.relations.primary_admin &&
        this.props.userData.relations.primary_admin.includes(companyId)
      ) &&
      !(
        this.props.userData.relations.domestic_admin &&
        this.props.userData.relations.domestic_admin.includes(companyId)
      ) &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push(`/admin/company/manage/${companyId}/about`);
    }
    this.props.removeCompanyHistoricalData();
    this.props.getCompanyHistoricalData(this.props.match.params.id);
  }

  handleSeeMoreClick = (pageIndex, type) => {
    this.props.getCompanyHistoricalDataMore(
      pageIndex,
      type,
      this.props.match.params.id,
    );
  };

  closeModal = () => {
    this.setState(
      {
        sectionId: null,
        isRemoveModalVisible: false,
        isInputModalVisible: false,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(false),
    );
  };

  sectionActions = ({ name, id }) => {
    if (this.state.isEdit) {
      this.props.editCompanyHistoricalSection(id, { name });
      this.closeModal();
    } else {
      this.props.addCompanyHistoricalSection({
        name,
        entitiable_type: 'company',
        entitiable_id: this.props.match.params.id,
        type: 'historical_data_section',
      });
      this.closeModal();
    }
  };

  createSection = () => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  editSection = (name, id) => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: true,
        values: {
          name,
          id,
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  removeSection = (sectionId) => {
    if (this.state.sectionId) {
      this.props.removeCompanyHistoricalSection(this.state.sectionId);
      this.closeModal();
    } else {
      this.setState(
        {
          isRemoveModalVisible: true,
          sectionId,
        },
        () => disableScroll(this.state.isRemoveModalVisible),
      );
    }
  };

  render() {
    const { isRemoveModalVisible, isInputModalVisible } = this.state;

    const ModalFormView = ({ formProps }) => (
      <>
        <Input
          name="name"
          type="text"
          placeholder="Section name"
          error={formProps.errors.name}
          value={formProps.values.name}
          touched={formProps.touched.name}
          onBlur={formProps.handleBlur}
          onChange={formProps.handleChange}
          autoFocus
        />
        {' '}
        <span className="letter-counter">
          {`${formProps.values.name.trimStart().length}/64`}
        </span>
      </>
    );

    return (
      <>
        <HistoricalDataView
          historicalDataList={this.props.historicalDataList}
          createSection={this.createSection}
          editSection={this.editSection}
          removeSection={this.removeSection}
          handleSeeMoreClick={this.handleSeeMoreClick}
          companyId={this.props.match.params.id}
        />
        <FormModal
          isModalVisible={isInputModalVisible}
          handleClose={this.closeModal}
          header={`${this.state.isEdit ? 'Edit' : 'Add new'} section`}
          validationSchema={validationSchema}
          onSubmit={this.sectionActions}
          initialValues={this.state.values}
          confimButtonText={this.state.isEdit ? 'Save' : 'Add'}
        >
          <ModalFormView />
        </FormModal>
        {isRemoveModalVisible && (
          <RemoveModal
            handleRemoveClick={this.removeSection}
            handleCancelClick={this.closeModal}
            heading="Are You sure you want to remove this section?"
            message="This section will be deleted immediately. You can't undo this action."
          />
        )}
      </>
    );
  }
}

CompanyHistoricalData.propTypes = {
  getCompanyHistoricalData: PropTypes.func.isRequired,
  removeCompanyHistoricalData: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CompanyHistoricalData);
