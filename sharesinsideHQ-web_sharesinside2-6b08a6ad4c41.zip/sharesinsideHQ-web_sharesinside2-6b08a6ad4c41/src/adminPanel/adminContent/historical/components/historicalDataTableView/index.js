import React from 'react';
import HistoricalDataForm from 'adminPanel/adminContent/historical/containers/historicalDataForm';
import HistoricalData from 'adminPanel/adminContent/historical/containers/historicalData';
import shortid from 'shortid';
import './style.scss';

const HistoricalDataTableView = ({
  header,
  data,
  sectionId,
  handleSeeMoreClick,
  companyId,
  editSection,
  removeSection,
  nextPageIndex,
}) => (
  <div className="company-historical-data__container">
    <div className="company-historical-data__header">
      <h1 className="header__content">{header}</h1>
      <div className="header__icons">
        <div
          className="icon__edit"
          onClick={() => editSection(header, sectionId)}
          role="presentation"
        />
        <div
          className="icon__remove"
          onClick={() => removeSection(sectionId)}
          role="presentation"
        />
      </div>
    </div>

    <table className="company-historical-data__table">
      <thead className="company-historical-data__thead">
        <tr>
          <th className="thPublish align-middle">Publish date</th>
          <th className="thFiscal align-middle">Fiscal Year</th>
          <th className="thTitle align-middle">Title</th>
          <th className="thAttachments align-middle">Attachments</th>
          <th className="thActions align-middle" />
        </tr>
      </thead>
      <tbody>
        <HistoricalDataForm companyId={companyId} sectionId={sectionId} />
        {data.map(historical => (
          <HistoricalData
            key={`${shortid.generate()}`}
            companyId={companyId}
            sectionId={sectionId}
            historical={historical}
          />
        ))}
      </tbody>
    </table>
    {nextPageIndex ? (
      <div className="company-historical-data__load-container">
        <button
          onClick={() => handleSeeMoreClick(nextPageIndex, sectionId)}
          className="company-historical-data__load"
        >
          See more
        </button>
      </div>
    ) : (
      ''
    )}
  </div>
);

export default HistoricalDataTableView;
