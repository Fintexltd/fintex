import React from 'react';
import HistoricalDataTableView from 'adminPanel/adminContent/historical/components/historicalDataTableView';
import shortid from 'shortid';
import './style.scss';

const HistoricalDataView = ({
  historicalDataList,
  handleSeeMoreClick,
  removeSection,
  editSection,
  createSection,
  companyId,
}) => (
  <div className="company-historical-data">
    {historicalDataList &&
      historicalDataList.map(historical => (
        <HistoricalDataTableView
          key={shortid.generate()}
          header={historical.name}
          sectionId={historical.sectionId}
          data={historical.data}
          nextPageIndex={historical.nextPageIndex}
          handleSeeMoreClick={handleSeeMoreClick}
          removeSection={removeSection}
          editSection={editSection}
          companyId={companyId}
        />
      ))}
    <div
      className="company-historical-data__newSection"
      onClick={createSection}
      role="presentation"
    >
      <div className="newSection__icon" />
      <div className="newSection__text">Add new section</div>
    </div>
  </div>
);

export default HistoricalDataView;
