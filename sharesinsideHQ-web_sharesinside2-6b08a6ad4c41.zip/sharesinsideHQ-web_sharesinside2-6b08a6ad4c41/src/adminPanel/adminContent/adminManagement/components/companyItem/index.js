import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import TextTruncate from 'react-text-truncate';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import placeholder from 'assets/img/placeholder.png';
import './index.scss';

const CompanyItem = props => {
  const {
    company,
    removeCompany,
    handleCheckboxClick,
    isChecked,
    isRemoveCompanyAllowed,
  } = props;
  return (
    <div className="admin-management-item">
      <div className="admin-management-item__content">
        <div className="admin-management-item__top-container">
          {isRemoveCompanyAllowed(company.id) ? (
            <div
              onClick={e => e.stopPropagation()}
              onKeyPress={e => e.stopPropagation()}
              role="button"
              tabIndex="0"
              className="admin-management-item__checkbox-container"
            >
              <AcceptCheckbox
                name={`${company.id}`}
                id={`${company.id}`}
                onChange={handleCheckboxClick}
                checked={isChecked}
              />
            </div>
          ) : (
            <div />
          )}
          <div className="admin-management-item__buttons">
            <span
              className="admin-management-item__edit"
              onClick={() => {
                window.location.replace(
                  `/admin/company/manage/${company.id}/about`,
                );
              }}
              role="presentation"
            >
              edit
            </span>
            {isRemoveCompanyAllowed(company.id) && (
              <button
                className="admin-management-item__remove"
                onClick={e => {
                  e.stopPropagation();
                  removeCompany(company.id);
                }}
              >
                delete
              </button>
            )}
          </div>
        </div>
        <Link
          to={`/admin/company/manage/${company.id}/about`}
          className="company-item__top-container-link"
        >
          <div
            className="admin-management-item__image"
            style={{ backgroundImage: `url(${company.logo || placeholder})` }}
          />
          <h2 className="admin-management-item__name">
            <TextTruncate line={1} truncateText="…" text={company.name} />
          </h2>
          <p className="admin-management-item__country">{company.industry}</p>
        </Link>
      </div>
    </div>
  );
};

CompanyItem.propTypes = {
  company: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  removeCompany: PropTypes.func.isRequired,
  handleCheckboxClick: PropTypes.func.isRequired,
  isChecked: PropTypes.bool.isRequired,
};

export default withRouter(CompanyItem);
