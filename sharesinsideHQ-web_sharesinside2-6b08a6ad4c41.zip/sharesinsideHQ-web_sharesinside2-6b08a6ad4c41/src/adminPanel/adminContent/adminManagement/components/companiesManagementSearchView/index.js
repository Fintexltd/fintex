import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import CompaniesManagementAdvancedSearch from 'adminPanel/adminContent/adminManagement/containers/companiesManagementAdvancedSearch';
import './index.scss';

const CompaniesManagementSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isAdvancedSearchVisible,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  toggleAdvancedSearch,
  companiesFilters,
  handleFilterRemoveClick,
}) => (
  <div className="companies-management-search">
    <div className="companies-management-search__top">
      <div className="companies-management-search__top-left">
        <div className="companies-management-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={companiesFilters.search}
          />
        </div>
        <div className="companies-management-search__filters-button">
          <ToggleMoreFiltersButton
            handleToggleMoreFiltersClick={toggleAdvancedSearch}
            isMoreFiltersVisible={isAdvancedSearchVisible}
          />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="companies-management-search__clear-filters-button">
          <div className="companies-management-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="companies-management-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    {isAdvancedSearchVisible && <CompaniesManagementAdvancedSearch />}
    <div className="companies-management-search__results-container">
      <div className="companies-management-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

CompaniesManagementSearchView.defaultProps = {
  resultsNumber: null,
};

CompaniesManagementSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  companiesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isAdvancedSearchVisible: PropTypes.bool.isRequired,
  toggleAdvancedSearch: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default CompaniesManagementSearchView;
