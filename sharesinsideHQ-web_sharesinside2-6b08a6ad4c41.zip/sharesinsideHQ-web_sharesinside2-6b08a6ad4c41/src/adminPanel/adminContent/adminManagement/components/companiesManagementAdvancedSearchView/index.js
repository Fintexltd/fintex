import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import './index.scss';

const CompaniesManagementAdvancedSearchView = ({
  companiesFilters,
  continentsList,
  countriesList,
  industriesList,
  sectorsList,
  handleFilterUsage,
}) => (
  <div className="companies-management-advanced-search">
    <div className="companies-management-advanced-search__filters">
      <div className="companies-management-advanced-search__filter">
        <MultiSelect
          options={sectorsList}
          description="Sector"
          onChange={handleFilterUsage}
          value={companiesFilters.sector}
          category="sector"
        />
      </div>
      <div className="companies-management-advanced-search__filter">
        <MultiSelect
          options={industriesList}
          description="Industry"
          onChange={handleFilterUsage}
          value={companiesFilters.industry}
          category="industry"
        />
      </div>
      <div className="companies-management-advanced-search__filter">
        <MultiSelect
          options={continentsList}
          description="Continent"
          onChange={handleFilterUsage}
          value={companiesFilters.continent}
          category="continent"
        />
      </div>
      <div className="companies-management-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={companiesFilters.country}
          category="country"
        />
      </div>
    </div>
  </div>
);

CompaniesManagementAdvancedSearchView.defaultProps = {
  countriesList: [],
  continentsList: [],
  industriesList: [],
  sectorsList: [],
};

CompaniesManagementAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  sectorsList: PropTypes.arrayOf(PropTypes.object),
  companiesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
};

export default CompaniesManagementAdvancedSearchView;
