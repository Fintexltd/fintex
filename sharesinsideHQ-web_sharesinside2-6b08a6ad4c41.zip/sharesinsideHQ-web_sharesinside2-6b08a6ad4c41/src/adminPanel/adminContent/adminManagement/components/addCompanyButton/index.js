import React from 'react';
import { NavLink } from 'react-router-dom';
import plus from 'assets/icons/add_icon_big_white.svg';
import './style.scss';

const AddCompanyButton = () => (
  <NavLink className="add-company-button" to="/admin/company/create">
    <div className="add-company-button__content">
      <img src={plus} height={60} alt="" />
      <span>add new company</span>
    </div>
  </NavLink>
);
export default AddCompanyButton;
