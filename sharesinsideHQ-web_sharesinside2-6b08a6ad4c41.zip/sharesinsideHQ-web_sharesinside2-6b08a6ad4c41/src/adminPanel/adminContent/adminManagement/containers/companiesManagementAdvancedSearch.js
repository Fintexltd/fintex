import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import CompaniesManagementAdvancedSearchView from 'adminPanel/adminContent/adminManagement/components/companiesManagementAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchSectorsList from 'common/redux/actions/sectorsListActions';
import fetchIndustriesList from 'common/redux/actions/industriesListActions';
import { fetchAdminCompaniesList } from 'adminPanel/redux/actions/adminCompaniesListActions';
import { saveAdminCompaniesFilters } from 'adminPanel/redux/actions/adminCompaniesFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  continentsList: state.continents.list,
  industriesList: state.industries.list,
  sectorsList: state.sectors.list,
  companiesFilters: state.adminCompaniesFilters,
});

const mapDispatchToProps = dispatch => ({
  getCompaniesList: bindActionCreators(fetchAdminCompaniesList, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getContinentsList: bindActionCreators(fetchContinentsList, dispatch),
  getIndustriesList: bindActionCreators(fetchIndustriesList, dispatch),
  getSectorsList: bindActionCreators(fetchSectorsList, dispatch),
  saveCompaniesFilters: bindActionCreators(saveAdminCompaniesFilters, dispatch),
});

class CompaniesManagementAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetCompaniesList = debounce(props.getCompaniesList, 500);
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getContinentsList();
    this.props.getIndustriesList();
    this.props.getSectorsList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveCompaniesFilters(values.length > 0 ? values : { category });
    this.debouncedGetCompaniesList();
  };

  render() {
    return (
      <CompaniesManagementAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        continentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'continent',
        })}
        industriesList={mapObjPropsToSelectFilter({
          list: this.props.industriesList,
          label: 'name',
          value: 'id',
          category: 'industry',
        })}
        sectorsList={mapObjPropsToSelectFilter({
          list: this.props.sectorsList,
          label: 'name',
          value: 'id',
          category: 'sector',
        })}
        handleFilterUsage={this.handleFilterUsage}
        companiesFilters={this.props.companiesFilters}
      />
    );
  }
}

CompaniesManagementAdvancedSearch.defaultProps = {
  countriesList: [],
  continentsList: [],
  industriesList: [],
  sectorsList: [],
};

CompaniesManagementAdvancedSearch.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  sectorsList: PropTypes.arrayOf(PropTypes.object),
  getCountriesList: PropTypes.func.isRequired,
  getContinentsList: PropTypes.func.isRequired,
  getIndustriesList: PropTypes.func.isRequired,
  getSectorsList: PropTypes.func.isRequired,
  getCompaniesList: PropTypes.func.isRequired,
  saveCompaniesFilters: PropTypes.func.isRequired,
  companiesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CompaniesManagementAdvancedSearch);
