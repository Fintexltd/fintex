import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Route, Switch } from 'react-router-dom';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CompanyHeaderEdit from 'common/components/companyHeaderEdit';
import CompanyTitleEdit from 'common/components/companyTitleEdit';
import CompanyNavigation from 'common/components/companyNavigation';
import BaseInfoEditModal from 'common/components/baseInfoEditModal';
import AddNews from 'adminPanel/adminContent/addNews';
import NewsContent from 'adminPanel/adminContent/news/containers/newsContent';
import About from 'adminPanel/adminContent/about';
import EditAbout from 'adminPanel/adminContent/editAbout';
import RemoveModal from 'common/components/removeModal';
import Team from 'adminPanel/adminContent/team';
import fetchIndustriesList from 'common/redux/actions/inustriesListActions';
import {
  fetchAdminCompany,
  removeAdminCompany,
} from 'adminPanel/redux/actions/adminCompanyActions';
import fetchLocationData from 'common/redux/actions/locationDataActions.js';
import { deleteCompanies } from 'adminPanel/api/companiesApi';
import { updateCompanyData } from 'adminPanel/adminContent/adminCreator/api/adminCreatorApi.js';
import EventsContent from 'adminPanel/adminContent/events/containers/eventsContent';
import AddEvents from 'adminPanel/adminContent/addEvent';
import EditEvent from 'adminPanel/adminContent/editEvent';
import HistoricalData from 'adminPanel/adminContent/historical';
import Page404Loader from 'common/components/Page404Loader';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import Charts from 'common/containers/charts';
import { getCompanyChartData } from 'common/api/chartsApi';
import Gallery from 'adminPanel/adminContent/gallery';
import { disableScroll } from 'common/utils/disableScroll';
import { isEditor } from 'userAuth/utils/permissions';

const mapStateToProps = (state) => ({
  company: state.adminCompany.currentCompany,
  adminCompaniesList: state.adminCompanies.list,
  industriesList: state.industries.list,
  locationData: state.locationData.results,
  countriesList: state.countries.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminCompany: bindActionCreators(fetchAdminCompany, dispatch),
  removeAdminCompany: bindActionCreators(removeAdminCompany, dispatch),
  getIndustriesList: bindActionCreators(fetchIndustriesList, dispatch),
  fetchLocationData: (adress) => dispatch(fetchLocationData(adress)),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
});

class AdminManagement extends Component {
  constructor() {
    super();
    this.state = {
      isBaseInfoEditModalVisible: false,
      isRemoveCompanyModalVisible: false,
      symbols: null,
      excludedCountries: [],
      stockExchangeEmails: [],
    };
  }

  componentDidMount() {
    this.props.getAdminCompany(this.props.match.params.id);
    this.props.getIndustriesList();
    this.props.fetchCountriesList();
  }

  getBaseInfoFormInitialValues = () => {
    const {
      name,
      phone,
      email,
      adress,
      website,
      industry,
      excluded,
      country,
      dont_allow_shareholders: dontAllowShareholders,
    } = this.props.company;

    return {
      name,
      // NOTE: Phone and email are not mandatory and might be null
      phone: phone || '',
      email: email || '',
      adress,
      website,
      industryId: industry && industry.id,
      excluded,
      dontAllowShareholders,
      countryId: country && country.id,
    };
  };

  setCountryToExclude = (values) => {
    this.setState({
      excludedCountries: values,
    });
  };

  handleExcludedCountryRemoveClick = (label) => {
    this.setState((prevState) => ({
      excludedCountries: prevState.excludedCountries.filter(
        (el) => el.label !== label,
      ),
    }));
  };

  submitBaseInfoForm = (values, actions) => {
    const {
      name,
      phone,
      title,
      description,
      email,
      adress,
      website,
      industryId,
      countryId,
      dontAllowShareholders,
    } = values;

    updateCompanyData(this.props.company.id, {
      name,
      phone,
      email,
      adress,
      website,
      description,
      title,
      dont_allow_shareholders: dontAllowShareholders,
      industry_id: industryId,
      country_id: countryId,
      se_symbols: this.state.symbols,
      latitude: this.props.locationData
        ? this.props.locationData.lat
        : this.props.company.latitude,
      longitude: this.props.locationData
        ? this.props.locationData.lng
        : this.props.company.longitude,
      excluded: this.state.excludedCountries.map((item) => item.value),
      stock_exchange_emails: this.state.stockExchangeEmails,
    })
      .then(() => {
        this.props.getAdminCompany(this.props.company.id);
        this.toggleBaseInfoEditModal();
      })
      .catch(() => {
        actions.setErrors({
          submit: 'There was an error submitting the form.',
        });
        actions.setSubmitting(false);
      });
  };

  toggleBaseInfoEditModal = () => {
    this.setState(
      (prevState) => ({
        isBaseInfoEditModalVisible: !prevState.isBaseInfoEditModalVisible,
        excludedCountries: mapObjPropsToSelectFilter({
          list: this.props.company.excluded,
          label: 'country_name',
          value: 'id',
          category: 'country',
        }),
        stockExchangeEmails: this.props.company.stock_exchange_emails,
      }),
      () => disableScroll(this.state.isBaseInfoEditModalVisible),
    );
  };

  updateCompanyHeaderData = (data) => {
    updateCompanyData(this.props.company.id, data).then(() => {
      this.props.getAdminCompany(this.props.company.id);
    });
  };

  updateStockData = (symbols) => {
    this.setState({ symbols });
  };

  toggleRemoveModalOpenClick = () => {
    this.setState(
      (prevState) => ({
        isRemoveCompanyModalVisible: !prevState.isRemoveCompanyModalVisible,
      }),
      () => disableScroll(this.state.isRemoveCompanyModalVisible),
    );
  };

  removeCompany = () => {
    deleteCompanies([this.props.company.id]).then(() => {
      this.toggleRemoveModalOpenClick();
      this.props.history.push('/admin/company/management');
    });
  };

  handleLocationData = (e) => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      const adress = e.target.value;
      this.props.fetchLocationData(adress);
    }, 1000);
  };

  addStockExchangeEmail = (email) => {
    this.setState((prevState) => ({
      stockExchangeEmails: [...prevState.stockExchangeEmails, email],
    }));
  };

  removeStockExchangeEmail = (emailToRemove) => {
    this.setState((prevState) => ({
      stockExchangeEmails: prevState.stockExchangeEmails.filter(
        (email) => email !== emailToRemove,
      ),
    }));
  };

  render() {
    const AboutWithProps = (props) => (
      <About
        userData={this.props.userData}
        company={this.props.company}
        {...props}
      />
    );

    const EditAboutWithProps = (props) => (
      <EditAbout
        userData={this.props.userData}
        company={this.props.company}
        {...props}
      />
    );

    const TeamWithProps = (props) => (
      <Team
        userData={this.props.userData}
        companyId={this.props.company.id}
        {...props}
      />
    );

    const GalleryWithProps = (props) => (
      <Gallery
        userData={this.props.userData}
        companyId={this.props.company.id}
        {...props}
      />
    );

    const NewsContentWithProps = (props) => (
      <NewsContent companyId={this.props.company.id} {...props} />
    );

    const AddNewsWithProps = (props) => (
      <AddNews company={this.props.company} {...props} />
    );

    const EventsWithProps = (props) => (
      <EventsContent companyId={this.props.company.id} {...props} />
    );

    return (
      <>
        <CompanyTitleEdit
          openEditModal={this.toggleBaseInfoEditModal}
          openRemoveModal={this.toggleRemoveModalOpenClick}
          userData={this.props.userData}
          companyId={this.props.company.id}
        />
        <CompanyHeaderEdit
          company={this.props.company}
          userData={this.props.userData}
          updateCompanyHeaderData={this.updateCompanyHeaderData}
        />
        {this.state.isRemoveCompanyModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this company?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeCompany}
            handleCancelClick={this.toggleRemoveModalOpenClick}
          />
        )}
        <CompanyNavigation
          company={this.props.company}
          path={`/admin/company/manage/${this.props.company.id}`}
          isAdminPanel
          isEditor={isEditor(this.props.userData, this.props.company.id)}
        />
        {this.state.isBaseInfoEditModalVisible && (
          <BaseInfoEditModal
            company={this.props.company}
            closeModal={this.toggleBaseInfoEditModal}
            getBaseInfoFormInitialValues={this.getBaseInfoFormInitialValues}
            submitBaseInfoForm={this.submitBaseInfoForm}
            industriesList={this.props.industriesList}
            updateStockData={this.updateStockData}
            symbols={this.props.company.se_symbols}
            handleLocationData={this.handleLocationData}
            setCountryToExclude={this.setCountryToExclude}
            handleExcludedCountryRemoveClick={
              this.handleExcludedCountryRemoveClick
            }
            excludedCountries={this.state.excludedCountries}
            countriesList={this.props.countriesList}
            addStockExchangeEmail={this.addStockExchangeEmail}
            removeStockExchangeEmail={this.removeStockExchangeEmail}
            stockExchangeEmails={this.state.stockExchangeEmails}
          />
        )}
        <Switch>
          <Route
            path="/admin/company/manage/:id/about"
            component={AboutWithProps}
          />
          <Route
            path="/admin/company/manage/:id/edit-about"
            component={EditAboutWithProps}
          />
          <Route
            path="/admin/company/manage/:id/team"
            component={TeamWithProps}
          />
          <Route
            path="/admin/company/manage/:id/gallery"
            component={GalleryWithProps}
          />
          <Route
            path="/admin/company/manage/:id/news"
            component={NewsContentWithProps}
          />
          <Route
            path="/admin/company/manage/:id/add-news"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/company/manage/:id/edit-news/:newsId"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/company/manage/:id/events"
            component={EventsWithProps}
          />
          <Route
            path="/admin/company/manage/:id/add-event"
            component={AddEvents}
          />
          <Route
            path="/admin/company/manage/:id/edit-event/:eventId"
            component={EditEvent}
          />
          <Route
            path="/admin/company/manage/:id/historical-data"
            component={HistoricalData}
          />
          <Route
            path="/admin/company/manage/:id/charts"
            render={(props) => (
              <Charts {...props} getChartData={getCompanyChartData} />
            )}
          />
          <Route component={Page404Loader} />
        </Switch>
      </>
    );
  }
}

AdminManagement.defaultProps = {
  adminCompaniesList: [],
  company: {},
  industriesList: [],
};

AdminManagement.propTypes = {
  getAdminCompany: PropTypes.func.isRequired,
  getIndustriesList: PropTypes.func.isRequired,
  adminCompaniesList: PropTypes.arrayOf(PropTypes.object),
  removeAdminCompany: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  match: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.objectOf(PropTypes.string),
      PropTypes.string,
      PropTypes.bool,
    ]),
  ).isRequired,
  company: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  fetchLocationData: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminManagement));
