import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import CompaniesManagementSearchView from 'adminPanel/adminContent/adminManagement/components/companiesManagementSearchView';
import { fetchAdminCompaniesList } from 'adminPanel/redux/actions/adminCompaniesListActions';
import {
  removeAdminCompaniesFilters,
  saveAdminCompaniesSearch,
  saveAdminCompaniesFilters,
} from 'adminPanel/redux/actions/adminCompaniesFiltersActions';

const mapStateToProps = state => ({
  resultsNumber: state.adminCompanies.resultsNumber,
  companiesFilters: state.adminCompaniesFilters,
});

const mapDispatchToProps = dispatch => ({
  getCompaniesList: bindActionCreators(fetchAdminCompaniesList, dispatch),
  removeCompaniesFilters: bindActionCreators(
    removeAdminCompaniesFilters,
    dispatch,
  ),
  saveCompaniesSearch: bindActionCreators(saveAdminCompaniesSearch, dispatch),
  saveCompaniesFilters: bindActionCreators(saveAdminCompaniesFilters, dispatch),
});

class CompaniesManagementSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetCompaniesList = debounce(props.getCompaniesList, 500);
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeCompaniesFilters();
    this.debouncedGetCompaniesList();
  };

  handleSearchInputChange = text => {
    this.props.saveCompaniesSearch(text);
    this.debouncedGetCompaniesList();
  };

  mapActiveFiltersLists = () => [
    ...this.props.companiesFilters.sector,
    ...this.props.companiesFilters.industry,
    ...this.props.companiesFilters.continent,
    ...this.props.companiesFilters.country,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.companiesFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveCompaniesFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetCompaniesList();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <CompaniesManagementSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        companiesFilters={this.props.companiesFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

CompaniesManagementSearch.defaultProps = {
  resultsNumber: null,
};

CompaniesManagementSearch.propTypes = {
  getCompaniesList: PropTypes.func.isRequired,
  removeCompaniesFilters: PropTypes.func.isRequired,
  saveCompaniesSearch: PropTypes.func.isRequired,
  saveCompaniesFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  companiesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CompaniesManagementSearch);
