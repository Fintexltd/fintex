import React, { Component } from 'react';
import PropTypes from 'prop-types';
import AddCompanyButton from 'adminPanel/adminContent/adminManagement/components/addCompanyButton';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CompaniesManagementSearch from 'adminPanel/adminContent/adminManagement/containers/companiesManagementSearch';
import {
  fetchAdminCompaniesList,
  updateAdminCompaniesList,
} from 'adminPanel/redux/actions/adminCompaniesListActions';
import CompanyItem from 'adminPanel/adminContent/adminManagement/components/companyItem';
import RemoveModal from 'common/components/removeModal';
import RemoveButton from 'common/components/removeButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import { deleteCompanies } from 'adminPanel/api/companiesApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import './index.scss';

const mapStateToProps = (state) => ({
  adminCompaniesList: state.adminCompanies.list,
  companiesFilters: state.adminCompaniesFilters,
  nextPageIndex: state.adminCompanies.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminCompaniesList: bindActionCreators(fetchAdminCompaniesList, dispatch),
  updateAdminCompaniesList: bindActionCreators(
    updateAdminCompaniesList,
    dispatch,
  ),
});

class AdminManagement extends Component {
  constructor(props) {
    super(props);
    this.state = {
      companiesToRemove: [],
      companyToRemoveId: null,
      isRemoveCompanyModalVisible: false,
      isRemoveMultipleCompaniesModalVisible: false,
      isLoadMoreClicked: false,
    };
  }

  componentDidMount() {
    this.props.getAdminCompaniesList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  getCompaniesIfNecessary = () => {
    if (this.props.nextPageIndex) {
      this.handleLoadMoreClick(this.props.nextPageIndex);
    }
  };

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () =>
        this.props.getAdminCompaniesList(this.props.nextPageIndex),
      );
    }
  };

  isAdminCompaniesFiltersActive = () => {
    const {
      sector,
      country,
      continent,
      industry,
      search,
    } = this.props.companiesFilters;
    return (
      sector.length > 0 ||
      country.length > 0 ||
      continent.length > 0 ||
      industry.length > 0 ||
      search !== ''
    );
  };

  handleCheckAllCompaniesClick = () => {
    const ids = this.props.adminCompaniesList
      .map((company) => company.id)
      .filter((id) => this.isRemoveCompanyAllowed(id));
    this.setState({ companiesToRemove: ids });
  };

  handleCompanyCheckboxClick = (value) => {
    const { checked, id } = value.target;
    this.setState((prevState) => {
      let checkedCompanies = prevState.companiesToRemove;
      if (checked) {
        checkedCompanies.push(Number(id));
      } else {
        checkedCompanies = prevState.companiesToRemove.filter(
          (companyId) => companyId !== Number(id),
        );
      }
      return { companiesToRemove: checkedCompanies };
    });
  };

  handleClearSelectionClick = () => {
    this.setState({ companiesToRemove: [] });
  };

  toggleRemoveCompanyModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveCompanyModalVisible: !prevState.isRemoveCompanyModalVisible,
    }));
  };

  toggleRemoveMultipleCompaniesModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveMultipleCompaniesModalVisible: !prevState.isRemoveMultipleCompaniesModalVisible,
    }));
  };

  handleRemoveCompaniesClick = () => {
    this.toggleRemoveMultipleCompaniesModalOpen();
  };

  handleRemoveCompanyClick = (id) => {
    this.setState({ companyToRemoveId: id });
    this.toggleRemoveCompanyModalOpen();
  };

  removeCompany = () => {
    deleteCompanies([this.state.companyToRemoveId]).then(() => {
      this.props.updateAdminCompaniesList(
        this.props.adminCompaniesList.filter(
          (item) => item.id !== this.state.companyToRemoveId,
        ),
      );
      this.setState({ companyToRemoveId: null });
      this.toggleRemoveCompanyModalOpen();
    });
  };

  removeCompanies = () => {
    const removeAllVisible =
      this.state.companiesToRemove.length ===
      this.props.adminCompaniesList.length;
    deleteCompanies(this.state.companiesToRemove).then(() => {
      this.props.updateAdminCompaniesList(
        this.props.adminCompaniesList.filter(
          (item) => !this.state.companiesToRemove.includes(item.id),
        ),
      );
      this.setState({ companiesToRemove: [] });
      this.toggleRemoveMultipleCompaniesModalOpen();
      if (removeAllVisible) {
        this.getCompaniesIfNecessary();
      }
    });
  };

  isRemovePermissionExists = () =>
    this.props.userData &&
    checkUserPermission(
      this.props.userData,
      PERMISSIONS_FUNCTION_TYPES.REMOVE_COMPANY,
    );

  isRemoveCompanyAllowed = (id) =>
    (this.props.userData.relations.domestic_admin &&
      this.props.userData.relations.domestic_admin.includes(id)) ||
    this.props.userData.is_content_admin ||
    this.props.userData.is_global_admin;

  render() {
    return (
      <div className="admin-management-container">
        <h2 className="admin-management-container__heading">
          Company Management
        </h2>
        <CompaniesManagementSearch />
        {this.isRemovePermissionExists() && (
          <div className="admin-management__buttons">
            {this.state.companiesToRemove.length !==
              this.props.adminCompaniesList.length && (
              <CheckButton
                description="Check all"
                handleClick={this.handleCheckAllCompaniesClick}
              />
            )}
            {this.state.companiesToRemove.length > 0 && (
              <div className="admin-management__clear-button">
                <ClearButton
                  description="Clear selection"
                  handleClick={this.handleClearSelectionClick}
                />
              </div>
            )}
            {this.state.companiesToRemove.length > 0 && (
              <RemoveButton
                description="Remove checked"
                handleRemoveClick={this.handleRemoveCompaniesClick}
              />
            )}
          </div>
        )}
        <div className="row">
          <div className="admin-management-item admin-management__add-item">
            <AddCompanyButton />
          </div>
          {this.props.adminCompaniesList.length > 0 &&
            this.props.adminCompaniesList.map((item) => (
              <div className="admin-management__company-item" key={item.id}>
                <CompanyItem
                  company={item}
                  removeCompany={this.handleRemoveCompanyClick}
                  handleCheckboxClick={this.handleCompanyCheckboxClick}
                  isChecked={this.state.companiesToRemove.indexOf(item.id) > -1}
                  isRemoveCompanyAllowed={this.isRemoveCompanyAllowed}
                />
              </div>
            ))}
          {this.isAdminCompaniesFiltersActive() &&
            this.props.adminCompaniesList.length === 0 && (
              <div className="admin-management__empty-list">
                <p className="admin-management__empty-list-message">
                  There are no companies matching these criteria
                </p>
              </div>
            )}
        </div>
        <div className="row">
          {this.props.nextPageIndex && (
            <div className="admin-management__load-container">
              <button
                onClick={this.handleLoadMoreClick}
                className="admin-management__load"
              >
                Load more
              </button>
            </div>
          )}
        </div>
        {this.state.isRemoveCompanyModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this company?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeCompany}
            handleCancelClick={this.toggleRemoveCompanyModalOpen}
          />
        )}
        {this.state.isRemoveMultipleCompaniesModalVisible && (
          <RemoveModal
            heading={`Are You sure you want to remove these companies (${
              this.state.companiesToRemove.length
            } ${
              this.state.companiesToRemove.length > 1 ? 'elements' : 'element'
            })?`}
            message="This items will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeCompanies}
            handleCancelClick={this.toggleRemoveMultipleCompaniesModalOpen}
          />
        )}
      </div>
    );
  }
}

AdminManagement.defaultProps = {
  adminCompaniesList: [],
  nextPageIndex: null,
};

AdminManagement.propTypes = {
  adminCompaniesList: PropTypes.arrayOf(PropTypes.object),
  companiesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
  getAdminCompaniesList: PropTypes.func.isRequired,
  updateAdminCompaniesList: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
};

export default connect(mapStateToProps, mapDispatchToProps)(AdminManagement);
