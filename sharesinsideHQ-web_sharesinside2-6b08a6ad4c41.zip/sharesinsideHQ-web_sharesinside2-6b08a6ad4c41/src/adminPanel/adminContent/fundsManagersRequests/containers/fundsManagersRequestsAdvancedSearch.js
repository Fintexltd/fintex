import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import FundsManagersRequestsAdvancedSearchView from 'adminPanel/adminContent/fundsManagersRequests/components/fundsManagersRequestsAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchFundsManagersRequests from 'adminPanel/redux/actions/funds/admin/adminFundsManagersRequestsActions';
import { saveFundsManagersRequestsFilters } from 'adminPanel/redux/actions/funds/fundsManagersRequestsFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  continentsList: state.continents.list,
  fundsManagersRequestsFilters: state.fundsManagersRequestsFilters,
});

const mapDispatchToProps = dispatch => ({
  getFundsManagersRequests: bindActionCreators(
    fetchFundsManagersRequests,
    dispatch,
  ),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getContinentsList: bindActionCreators(fetchContinentsList, dispatch),
  saveFundsManagersRequestsFilters: bindActionCreators(
    saveFundsManagersRequestsFilters,
    dispatch,
  ),
});

class FundsManagersRequestsAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsManagersRequests = debounce(
      props.getFundsManagersRequests,
      500,
    );
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getContinentsList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveFundsManagersRequestsFilters(
      values.length > 0 ? values : { category },
    );
    this.debouncedGetFundsManagersRequests();
  };

  render() {
    return (
      <FundsManagersRequestsAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        continentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'continent',
        })}
        handleFilterUsage={this.handleFilterUsage}
        fundsManagersRequestsFilters={this.props.fundsManagersRequestsFilters}
      />
    );
  }
}

FundsManagersRequestsAdvancedSearch.defaultProps = {
  countriesList: [],
  continentsList: [],
};

FundsManagersRequestsAdvancedSearch.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  getCountriesList: PropTypes.func.isRequired,
  getContinentsList: PropTypes.func.isRequired,
  getFundsManagersRequests: PropTypes.func.isRequired,
  saveFundsManagersRequestsFilters: PropTypes.func.isRequired,
  fundsManagersRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagersRequestsAdvancedSearch);
