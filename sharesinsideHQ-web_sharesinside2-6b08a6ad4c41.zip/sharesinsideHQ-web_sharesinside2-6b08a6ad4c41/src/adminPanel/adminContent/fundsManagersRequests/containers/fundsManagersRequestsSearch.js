import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import FundsManagersRequestsSearchView from 'adminPanel/adminContent/fundsManagersRequests/components/fundsManagersRequestsSearchView';
import fetchFundsManagersRequests from 'adminPanel/redux/actions/funds/admin/adminFundsManagersRequestsActions';
import {
  removeFundsManagersRequestsFilters,
  saveFundsManagersRequestsSearch,
  saveFundsManagersRequestsFilters,
} from 'adminPanel/redux/actions/funds/fundsManagersRequestsFiltersActions';

const mapStateToProps = state => ({
  fundsManagersRequests: state.fundsManagersRequests.list,
  fundsManagersRequestsFilters: state.fundsManagersRequestsFilters,
  resultsNumber: state.fundsManagersRequests.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getFundsManagersRequests: bindActionCreators(
    fetchFundsManagersRequests,
    dispatch,
  ),
  removeFundsManagersRequestsFilters: bindActionCreators(
    removeFundsManagersRequestsFilters,
    dispatch,
  ),
  saveFundsManagersRequestsSearch: bindActionCreators(
    saveFundsManagersRequestsSearch,
    dispatch,
  ),
  saveFundsManagersRequestsFilters: bindActionCreators(
    saveFundsManagersRequestsFilters,
    dispatch,
  ),
});

class FundsManagersRequestsSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsManagersRequests = debounce(
      props.getFundsManagersRequests,
      500,
    );
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeFundsManagersRequestsFilters();
    this.debouncedGetFundsManagersRequests();
  };

  handleSearchInputChange = text => {
    this.props.saveFundsManagersRequestsSearch(text);
    this.debouncedGetFundsManagersRequests();
  };

  mapActiveFiltersLists = () => [
    ...this.props.fundsManagersRequestsFilters.continent,
    ...this.props.fundsManagersRequestsFilters.country,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.fundsManagersRequestsFilters[
      category
    ].filter(el => el.label !== label);
    this.props.saveFundsManagersRequestsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetFundsManagersRequests();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <FundsManagersRequestsSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        fundsManagersFilters={this.props.fundsManagersRequestsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

FundsManagersRequestsSearch.defaultProps = {
  resultsNumber: null,
};

FundsManagersRequestsSearch.propTypes = {
  getFundsManagersRequests: PropTypes.func.isRequired,
  removeFundsManagersRequestsFilters: PropTypes.func.isRequired,
  saveFundsManagersRequestsSearch: PropTypes.func.isRequired,
  saveFundsManagersRequestsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  fundsManagersRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagersRequestsSearch);
