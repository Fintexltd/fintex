import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundsManagersRequestsView from 'adminPanel/adminContent/fundsManagersRequests/components/fundsManagersRequestsView';
import {
  acceptFundsManagers,
  deleteFundsManagers,
} from 'adminPanel/api/fundsManagersApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import fetchFundsManagersRequests from 'adminPanel/redux/actions/funds/admin/adminFundsManagersRequestsActions';
import { saveFundsManagersRequestsFilters } from 'adminPanel/redux/actions/funds/fundsManagersRequestsFiltersActions';

const mapStateToProps = (state) => ({
  fundsManagersRequests: state.fundsManagersRequests.data,
  fundsManagersRequestsFilters: state.fundsManagersRequestsFilters,
  token: state.auth.token,
  userData: state.userData.data,
  meta: state.fundsManagersRequests.meta,
  resultsNumber: state.fundsManagersRequests.resultsNumber,
  isLoading: state.fundsManagersRequests.isLoading,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsManagersRequests: bindActionCreators(
    fetchFundsManagersRequests,
    dispatch,
  ),
  saveFundsManagersRequestsFilters: bindActionCreators(
    saveFundsManagersRequestsFilters,
    dispatch,
  ),
});

class AdminFundsManagers extends Component {
  constructor() {
    super();
    this.state = {
      checkedFundsManagers: [],
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_FUNDS_MANAGER_REQUESTS,
      )
    )
      this.props.history.push('/admin/fundsManager/management');

    if (this.props.fundsManagersRequests.length === 0) {
      this.props.getFundsManagersRequests();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_FUNDS_MANAGER_REQUESTS,
      )
    )
      this.props.history.push('/admin/fundsManager/management');
  }

  previewFundsManager = (id) => {
    this.props.history.push(`/fundsmanager/${id}`);
  };

  handleFundsManagerRequestCheckboxClick = (value) => {
    let { checkedFundsManagers } = this.state;
    if (value.target.checked) {
      checkedFundsManagers.push(Number(value.target.id));
    } else {
      checkedFundsManagers = this.state.checkedFundsManagers.filter(
        (id) => id !== Number(value.target.id),
      );
    }
    this.setState({ checkedFundsManagers });
  };

  acceptFundsManager = (id) => {
    acceptFundsManagers([id]).then(() => {
      this.props.getFundsManagersRequests(this.props.meta.current_page);
    });
  };

  deleteFundsManager = (id) => {
    deleteFundsManagers([id]).then(() => {
      this.props.getFundsManagersRequests(this.props.meta.current_page);
    });
  };

  acceptMultipleRequests = () => {
    acceptFundsManagers(this.state.checkedFundsManagers).then(() => {
      this.props.getFundsManagersRequests(this.props.meta.current_page);
      this.setState({ checkedFundsManagers: [] });
    });
  };

  deleteMultipleRequests = () => {
    deleteFundsManagers(this.state.checkedFundsManagers).then(() => {
      this.props.getFundsManagersRequests(this.props.meta.current_page);
      this.setState({ checkedFundsManagers: [] });
    });
  };

  handleCheckAllFundsManagersClick = () => {
    const ids = this.props.fundsManagersRequests.map(
      (fundsManager) => fundsManager.id,
    );
    this.setState({ checkedFundsManagers: ids });
  };

  handleClearSelectionClick = () => {
    this.setState({ checkedFundsManagers: [] });
  };

  render() {
    return (
      <FundsManagersRequestsView
        fundsManagers={this.props.fundsManagersRequests}
        previewFundsManager={this.previewFundsManager}
        acceptFundsManager={this.acceptFundsManager}
        deleteFundsManager={this.deleteFundsManager}
        handleCheckboxClick={this.handleFundsManagerRequestCheckboxClick}
        checkedFundsManagers={this.state.checkedFundsManagers}
        handleCheckAllFundsManagersClick={this.handleCheckAllFundsManagersClick}
        handleClearSelectionClick={this.handleClearSelectionClick}
        acceptMultipleRequests={this.acceptMultipleRequests}
        deleteMultipleRequests={this.deleteMultipleRequests}
        getFundsManagersRequests={this.props.getFundsManagersRequests}
        meta={this.props.meta}
        saveFundsManagersRequestsFilters={
          this.props.saveFundsManagersRequestsFilters
        }
        resultsNumber={this.props.resultsNumber}
        isLoading={this.props.isLoading}
      />
    );
  }
}

AdminFundsManagers.defaultProps = {
  fundsManagersRequests: [],
  resultsNumber: null,
};

AdminFundsManagers.propTypes = {
  fundsManagersRequests: PropTypes.arrayOf(PropTypes.object),
  getFundsManagersRequests: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminFundsManagers));
