import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import './index.scss';

const FundsManagersRequestsAdvancedSearchView = ({
  fundsManagersRequestsFilters,
  continentsList,
  countriesList,
  handleFilterUsage,
}) => (
  <div className="fundsManagers-requests-advanced-search">
    <div className="fundsManagers-requests-advanced-search__filters">
      <div className="fundsManagers-requests-advanced-search__filter">
        <MultiSelect
          options={continentsList}
          description="Continent"
          onChange={handleFilterUsage}
          value={fundsManagersRequestsFilters.continent}
          category="continent"
        />
      </div>
      <div className="fundsManagers-requests-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={fundsManagersRequestsFilters.country}
          category="country"
        />
      </div>
    </div>
  </div>
);

FundsManagersRequestsAdvancedSearchView.defaultProps = {
  countriesList: [],
  continentsList: [],
};

FundsManagersRequestsAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  fundsManagersRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
};

export default FundsManagersRequestsAdvancedSearchView;
