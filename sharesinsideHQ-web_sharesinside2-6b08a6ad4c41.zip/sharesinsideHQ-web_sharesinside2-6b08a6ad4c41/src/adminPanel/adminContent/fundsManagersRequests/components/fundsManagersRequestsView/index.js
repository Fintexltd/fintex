import React from 'react';
import PropTypes from 'prop-types';
import FundsManagersRequestsSearch from 'adminPanel/adminContent/fundsManagersRequests/containers/fundsManagersRequestsSearch';
import Pagination from 'common/components/pagination';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import AcceptButton from 'common/components/acceptButton';
import RejectButton from 'common/components/rejectButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import shortid from 'shortid';
import './index.scss';

const FundsManagersRequestsView = ({
  fundsManagers,
  previewFundsManager,
  acceptFundsManager,
  deleteFundsManager,
  handleCheckboxClick,
  checkedFundsManagers,
  handleCheckAllFundsManagersClick,
  handleClearSelectionClick,
  acceptMultipleRequests,
  deleteMultipleRequests,
  getFundsManagersRequests,
  resultsNumber,
  meta,
  saveFundsManagersRequestsFilters,
  isLoading,
}) => (
  <div className="fundsManagers-requests">
    <h1 className="fundsManagers-requests__heading">Fund-Manager Management</h1>
    <FundsManagersRequestsSearch />
    <div className="fundsManagers-requests__filter-buttons">
      {checkedFundsManagers.length !== fundsManagers.length && (
        <CheckButton
          description="Check all"
          handleClick={handleCheckAllFundsManagersClick}
        />
      )}
      {checkedFundsManagers.length > 0 && (
        <>
          <div className="fundsManagers-requests__clear-button">
            <ClearButton
              description="Clear selection"
              handleClick={handleClearSelectionClick}
            />
          </div>
          <div className="fundsManagers-requests__accept-button">
            <AcceptButton
              handleClick={acceptMultipleRequests}
              description="Accept checked"
            />
          </div>
          <RejectButton
            handleClick={deleteMultipleRequests}
            description="Reject checked"
          />
        </>
      )}
    </div>
    <table className="fundsManagers-requests__table">
      <thead className="fundsManagers-requests__thead">
        <tr>
          <th>Fund-Manager</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {fundsManagers.map((fundsManager) => (
          <tr
            key={shortid.generate()}
            className="fundsManagers-requests__fundsManager-row"
          >
            <td>
              <div className="fundsManagers-requests__user-data">
                <AcceptCheckbox
                  name={`${fundsManager.id}`}
                  id={`${fundsManager.id}`}
                  onChange={handleCheckboxClick}
                  checked={checkedFundsManagers.includes(fundsManager.id)}
                />
                <div>
                  <p className="fundsManagers-requests__name">
                    {fundsManager.name}
                  </p>
                  <p className="fundsManagers-requests__data">
                    {`${fundsManager.country_calling_code.name} (${fundsManager.country_calling_code.code})`}
                  </p>
                </div>
              </div>
            </td>
            <td>
              <div className="fundsManagers-requests__buttons">
                <button
                  onClick={() => previewFundsManager(fundsManager.id)}
                  className="fundsManagers-requests__button fundsManagers-requests__button--preview"
                >
                  Preview
                </button>
                <button
                  onClick={() => acceptFundsManager(fundsManager.id)}
                  className="fundsManagers-requests__button fundsManagers-requests__button--accept"
                >
                  Accept
                </button>
                <button
                  onClick={() => deleteFundsManager(fundsManager.id)}
                  className="fundsManagers-requests__button fundsManagers-requests__button--delete"
                >
                  Reject
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    {!isLoading && fundsManagers.length === 0 && (
      <div className="fundsManagers-requests__empty-list">
        <p className="fundsManagers-requests__empty-list-message">
          There are no fund-Managers requests
        </p>
      </div>
    )}
    <Pagination
      meta={meta}
      resultsNumber={resultsNumber}
      saveFilters={saveFundsManagersRequestsFilters}
      getResults={getFundsManagersRequests}
    />
  </div>
);

FundsManagersRequestsView.defaultProps = {
  resultsNumber: null,
};

FundsManagersRequestsView.propTypes = {
  fundsManagers: PropTypes.arrayOf(PropTypes.object).isRequired,
  previewFundsManager: PropTypes.func.isRequired,
  acceptFundsManager: PropTypes.func.isRequired,
  deleteFundsManager: PropTypes.func.isRequired,
  checkedFundsManagers: PropTypes.arrayOf(PropTypes.number).isRequired,
  handleCheckAllFundsManagersClick: PropTypes.func.isRequired,
  handleClearSelectionClick: PropTypes.func.isRequired,
  acceptMultipleRequests: PropTypes.func.isRequired,
  deleteMultipleRequests: PropTypes.func.isRequired,
  getFundsManagersRequests: PropTypes.func.isRequired,
  saveFundsManagersRequestsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default FundsManagersRequestsView;
