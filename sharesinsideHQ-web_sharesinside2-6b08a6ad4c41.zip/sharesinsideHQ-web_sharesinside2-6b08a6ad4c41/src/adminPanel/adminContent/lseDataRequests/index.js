import React from 'react';
import PermissionRequired from 'permissions/components/permissionRequired';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import LseData from './components/lseData';
import DataLoader from './dataLoader';

const Index = () => (
  <PermissionRequired
    permission={PERMISSIONS_FUNCTION_TYPES.MANAGE_LSE_DATA_REQUESTS}
    redirectFallback="/admin/company/management"
  >
    <DataLoader />
    <LseData />
  </PermissionRequired>
);

export default Index;
