import * as types from 'adminPanel/adminContent/lseDataRequests/redux/types.js';
import { createActionCreator } from 'common/utils/reduxUtils';

const { SAVE_LSE_DATA_FILTERS } = types;

export const saveLseDataFilters = createActionCreator(
  SAVE_LSE_DATA_FILTERS,
  'filter',
);
