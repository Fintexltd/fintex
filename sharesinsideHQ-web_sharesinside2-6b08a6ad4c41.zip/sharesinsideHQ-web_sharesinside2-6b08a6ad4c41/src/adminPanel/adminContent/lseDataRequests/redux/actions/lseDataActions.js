import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/lseDataRequests/redux/types.js';

import {
  getLseDataRequest,
  rejectLseRequest,
} from 'adminPanel/adminContent/lseDataRequests/api/lseDataApi';

const {
  FETCH_LSE_DATA_REQUEST,
  FETCH_LSE_DATA_SUCCESS,
  FETCH_LSE_DATA_FAILURE,
} = types;

const fetchLseDataRequest = createActionCreator(FETCH_LSE_DATA_REQUEST);
const fetchLseDataSuccess = createActionCreator(
  FETCH_LSE_DATA_SUCCESS,
  'lseData',
);
const fetchLseDataFailure = createActionCreator(FETCH_LSE_DATA_FAILURE);

export const rejectLse = (lseId) => (dispatch, getState) => {
  const { per_page, showRejected } = getState().lseDataFilters;
  const { meta } = getState().lseData;

  dispatch(fetchLseDataRequest());

  const params = {
    page: meta.current_page,
    per_page,
  };

  return rejectLseRequest(lseId)
    .then(() => getLseDataRequest(params))
    .then((response) => {
      response.data.isRejected = showRejected;
      dispatch(fetchLseDataSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchLseDataFailure());
    });
};

export const fetchLseData = (page = 1) => (dispatch, getState) => {
  const { per_page, showRejected } = getState().lseDataFilters;
  const { list, meta } = getState().lseData;

  if (list.length === 0) {
    dispatch(fetchLseDataRequest());
  }

  const params = {
    page: page || meta.current_page,
    per_page,
    rejected: showRejected ? 1 : 0,
  };

  return getLseDataRequest(params)
    .then((response) => {
      response.data.isRejected = showRejected;
      dispatch(fetchLseDataSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchLseDataFailure());
    });
};
