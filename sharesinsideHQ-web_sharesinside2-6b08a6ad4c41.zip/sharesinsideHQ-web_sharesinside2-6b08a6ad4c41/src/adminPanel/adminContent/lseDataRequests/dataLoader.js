import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchLseData } from './redux/actions/lseDataActions';

const DataLoader = () => {
  const dispatch = useDispatch();
  const showRejected = useSelector(
    (state) => state.lseDataFilters.showRejected,
  );

  useEffect(() => {
    dispatch(fetchLseData(1));
  }, [dispatch, showRejected]);

  return null;
};

export default DataLoader;
