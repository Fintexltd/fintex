import AsyncSingleSelect from 'common/components/customSelect/asyncSingleSelect';
import React from 'react';
import useCompanySearchInput from './useCompanySearchInput';
import './index.scss';

const CompanySearchInput = ({ initialOptions, value, onChange }) => {
  const { onSearchTextChange, options, loading } = useCompanySearchInput(
    initialOptions,
  );

  return (
    <div className="company-search-input">
      <AsyncSingleSelect
        options={options}
        onChange={onChange}
        value={value}
        onSearchTextChange={onSearchTextChange}
        isLoading={loading}
        description={value ? 'Equity' : 'Select...'}
        category="company"
      />
    </div>
  );
};

export default CompanySearchInput;
