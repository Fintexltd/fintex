import { useCallback, useEffect, useState } from 'react';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { debounce } from 'lodash';
import { searchCompanyNamesRequest } from '../../api/lseDataApi';

const mapCompaniesToOptions = (companies) =>
  mapObjPropsToSelectFilter({
    list: companies || [],
    label: 'name',
    value: 'id',
    category: 'company',
  });

const useCompanySearchInput = (initialOptions) => {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setOptions(mapCompaniesToOptions(initialOptions));
  }, [initialOptions]);

  const onSearchTextChange = useCallback(
    debounce((text) => {
      if (text) {
        setLoading(true);
        searchCompanyNamesRequest(text)
          .then((response) => {
            setOptions(mapCompaniesToOptions(response.data));
            setLoading(false);
          })
          .catch(() => {
            setLoading(false);
          });
      } else {
        setOptions(mapCompaniesToOptions(initialOptions));
      }
    }, 500),
    [initialOptions],
  );

  return {
    onSearchTextChange,
    options,
    loading,
  };
};

export default useCompanySearchInput;
