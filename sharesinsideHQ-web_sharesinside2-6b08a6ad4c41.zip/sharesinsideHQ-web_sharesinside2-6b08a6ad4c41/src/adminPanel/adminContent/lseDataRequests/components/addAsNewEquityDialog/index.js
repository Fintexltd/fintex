import React from 'react';
import { Modal, ModalHeader, Button } from 'reactstrap';
import closeIcon from 'assets/icons/close.svg';
import useAddAsNewEquityDialog from './useAddAsNewEquityDialog';
import '../../styles/newModal.scss';
import AddAsNewEquityForm from '../addAsNewEquityForm';

const AddAsNewEquityDialog = ({ lseAsset, setLseAsset }) => {
  const { asset, close, reset } = useAddAsNewEquityDialog(
    lseAsset,
    setLseAsset,
  );

  return (
    <Modal
      contentClassName="modal-new__content"
      centered
      isOpen={!!lseAsset}
      onClosed={reset}
    >
      <ModalHeader className="modal-new__header">
        ADD AS NEW EQUITY
        <Button className="modal-new__close-button" onClick={close}>
          <img src={closeIcon} alt="close icon" />
        </Button>
      </ModalHeader>
      <AddAsNewEquityForm asset={asset} close={close} />
    </Modal>
  );
};

export default AddAsNewEquityDialog;
