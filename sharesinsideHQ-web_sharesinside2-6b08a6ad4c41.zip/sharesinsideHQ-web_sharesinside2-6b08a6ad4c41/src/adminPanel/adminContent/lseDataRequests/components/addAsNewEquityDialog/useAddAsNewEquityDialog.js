import { useEffect, useState } from 'react';

const useAddAsNewEquityDialog = (lseAsset, setLseAsset) => {
  const close = () => setLseAsset(null);
  const [asset, setAsset] = useState({});
  const reset = () => setAsset({});

  useEffect(() => {
    if (lseAsset) setAsset(lseAsset);
  }, [lseAsset]);

  return {
    asset,
    close,
    reset,
  };
};

export default useAddAsNewEquityDialog;
