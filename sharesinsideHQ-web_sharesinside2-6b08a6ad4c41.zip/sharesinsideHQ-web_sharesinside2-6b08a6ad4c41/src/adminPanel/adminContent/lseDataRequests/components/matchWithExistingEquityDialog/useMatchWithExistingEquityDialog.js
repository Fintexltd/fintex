import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { attachToCompanyRequest } from '../../api/lseDataApi';
import { fetchLseData } from '../../redux/actions/lseDataActions';

const MatchWithExistingEquityDialog = (lseAsset, setLseAsset) => {
  const dispatch = useDispatch();

  const [equity, selectEquity] = useState(null);
  const [asset, setAsset] = useState({});
  const [loading, setLoading] = useState(false);

  const close = () => setLseAsset(null);
  const reset = () => {
    setAsset({});
    selectEquity(null);
    setLoading(false);
  };

  useEffect(() => {
    if (lseAsset) {
      setAsset(lseAsset);
      if (lseAsset.search_results.length) {
        const { id, name } = lseAsset.search_results[0];
        selectEquity([
          {
            label: name,
            value: id,
          },
        ]);
      }
    }
  }, [lseAsset]);

  const match = () => {
    setLoading(true);
    attachToCompanyRequest(asset.id, equity[0].value)
      .then(() => {
        dispatch(fetchLseData(null));
        close();
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  };

  return {
    asset,
    close,
    reset,
    equity,
    selectEquity,
    match,
    loading,
  };
};

export default MatchWithExistingEquityDialog;
