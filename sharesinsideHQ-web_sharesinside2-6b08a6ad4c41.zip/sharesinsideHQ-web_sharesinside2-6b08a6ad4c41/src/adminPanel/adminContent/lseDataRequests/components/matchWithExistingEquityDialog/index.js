import React from 'react';
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ButtonGroup,
  Button,
} from 'reactstrap';
import CircleSpinner from 'common/components/circleSpinner';
import closeIcon from 'assets/icons/close.svg';
import useMatchWithExistingEquityDialog from './useMatchWithExistingEquityDialog';
import '../../styles/newModal.scss';
import CompanySearchInput from '../companySearchInput';

const MatchWithExistingEquityDialog = ({ lseAsset, setLseAsset }) => {
  const {
    asset,
    close,
    reset,
    equity,
    selectEquity,
    match,
    loading,
  } = useMatchWithExistingEquityDialog(lseAsset, setLseAsset);

  return (
    <Modal
      contentClassName="modal-new__content"
      centered
      isOpen={!!lseAsset}
      onClosed={reset}
    >
      <ModalHeader className="modal-new__header">
        MATCH WITH EXISTING EQUITY
        <Button className="modal-new__close-button" onClick={close}>
          <img src={closeIcon} alt="close icon" />
        </Button>
      </ModalHeader>
      <ModalBody>
        <p>
          This action will match 
          {' '}
          <b>{asset.name}</b>
          {' '}
          with:
        </p>
        <CompanySearchInput
          initialOptions={asset.search_results}
          onChange={selectEquity}
          value={equity}
        />
        <p>
          In future, all data from the LSE API will be automatically linked to
          this equity.
        </p>
      </ModalBody>
      <ModalFooter className="modal-new__footer">
        {loading && <CircleSpinner />}
        <ButtonGroup>
          <Button onClick={close} disabled={loading} outline color="primary">
            Cancel
          </Button>
          <Button color="primary" onClick={match} disabled={!equity || loading}>
            Confirm
          </Button>
        </ButtonGroup>
      </ModalFooter>
    </Modal>
  );
};

export default MatchWithExistingEquityDialog;
