import { useDispatch, useSelector } from 'react-redux';
import { saveLseDataFilters } from '../../redux/actions/lseDataFiltersActions';

const useLseDataFilters = () => {
  const dispatch = useDispatch();

  const showRejected = useSelector(
    (state) => state.lseDataFilters.showRejected,
  );

  const handleShowRejectedClick = (event) => {
    const { checked } = event.target;
    dispatch(
      saveLseDataFilters({
        category: 'showRejected',
        value: checked,
      }),
    );
  };

  return { showRejected, handleShowRejectedClick };
};

export default useLseDataFilters;
