import React from 'react';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import useLseDataFilters from './useLseDataFilters';

const LseDataFilters = () => {
  const { showRejected, handleShowRejectedClick } = useLseDataFilters();

  return (
    <AcceptCheckbox
      name="showRejected"
      id="showRejected"
      onChange={handleShowRejectedClick}
      checked={showRejected}
    >
      <span>Show rejected</span>
    </AcceptCheckbox>
  );
};

export default LseDataFilters;
