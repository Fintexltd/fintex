import { useDispatch, useSelector } from 'react-redux';
import { fetchLseData } from '../../redux/actions/lseDataActions';
import { saveLseDataFilters } from '../../redux/actions/lseDataFiltersActions';

const useLseDataPagination = () => {
  const dispatch = useDispatch();

  const perPage = useSelector((state) => state.lseDataFilters.per_page);
  const resultsNumber = useSelector((state) => state.lseData.resultsNumber);
  const meta = useSelector((state) => state.lseData.meta);

  const getResults = (page) => dispatch(fetchLseData(page));
  const saveFilters = (filters) => dispatch(saveLseDataFilters(filters));

  return {
    perPage,
    resultsNumber,
    meta,
    getResults,
    saveFilters,
  };
};

export default useLseDataPagination;
