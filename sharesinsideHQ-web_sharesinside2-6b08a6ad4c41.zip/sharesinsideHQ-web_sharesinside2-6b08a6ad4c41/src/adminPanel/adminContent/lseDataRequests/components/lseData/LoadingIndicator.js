import React from 'react';
import { useSelector } from 'react-redux';
import CircleSpinner from 'common/components/circleSpinner';

const LoadingIndicator = () => {
  const isLoading = useSelector((state) => state.lseData.isLoading);

  return isLoading ? (
    <div className="lseData-requests__table-loader">
      <CircleSpinner />
    </div>
  ) : null;
};

export default LoadingIndicator;
