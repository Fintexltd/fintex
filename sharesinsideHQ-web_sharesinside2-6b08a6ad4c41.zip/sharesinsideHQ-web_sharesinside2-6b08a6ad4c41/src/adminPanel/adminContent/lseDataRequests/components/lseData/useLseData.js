import { useCallback, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { rejectLse } from '../../redux/actions/lseDataActions';

const useLseData = () => {
  const dispatch = useDispatch();

  const lseAssets = useSelector((state) => state.lseData.list);
  const isRejected = useSelector((state) => state.lseData.isRejected);

  const [lseAssetForMatching, setLseAssetForMatching] = useState(null);
  const [lseAssetForAdding, setLseAssetForAdding] = useState(null);

  const rejectLseAsset = useCallback(
    (lseId) => {
      dispatch(rejectLse(lseId));
    },
    [dispatch],
  );

  return {
    lseAssets,
    rejectLseAsset,
    lseAssetForMatching,
    setLseAssetForMatching,
    lseAssetForAdding,
    setLseAssetForAdding,
    isRejected,
  };
};

export default useLseData;
