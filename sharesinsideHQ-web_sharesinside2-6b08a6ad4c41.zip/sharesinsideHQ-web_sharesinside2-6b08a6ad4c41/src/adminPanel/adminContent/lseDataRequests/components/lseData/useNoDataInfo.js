import { useSelector } from 'react-redux';

const useNoDataInfo = () => {
  const resultsNumber = useSelector((state) => state.lseData.resultsNumber);

  return { resultsNumber };
};

export default useNoDataInfo;
