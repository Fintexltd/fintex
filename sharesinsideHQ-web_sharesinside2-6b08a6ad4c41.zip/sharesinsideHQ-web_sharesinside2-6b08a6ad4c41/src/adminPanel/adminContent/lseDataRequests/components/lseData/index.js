import React from 'react';
import './index.scss';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import useLseData from './useLseData';
import LseAssetItem from '../lseAssetItem';
import LseDataPagination from './LseDataPagination';
import MatchWithExistingEquityDialog from '../matchWithExistingEquityDialog';
import AddAsNewEquityDialog from '../addAsNewEquityDialog';
import LseDataFilters from '../lseDataFilters';

const LseData = () => {
  const {
    lseAssets,
    isRejected,
    rejectLseAsset,
    lseAssetForMatching,
    setLseAssetForMatching,
    lseAssetForAdding,
    setLseAssetForAdding,
  } = useLseData();

  return (
    <div className="lseData-requests">
      <h1 className="lseData-requests__heading">LSE Data</h1>
      <LseDataFilters />
      <table className="lseData-requests__table">
        <thead className="lseData-requests__thead">
          <tr>
            <th>User data</th>
            <th>News / Events to import</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {lseAssets.map((lseAsset) => (
            <LseAssetItem
              key={lseAsset.id}
              lseAsset={lseAsset}
              isRejected={isRejected}
              rejectLseAsset={rejectLseAsset}
              setLseAssetForMatching={setLseAssetForMatching}
              setLseAssetForAdding={setLseAssetForAdding}
            />
          ))}
        </tbody>
      </table>
      <LoadingIndicator />
      <NoDataInfo />
      <LseDataPagination />
      <MatchWithExistingEquityDialog
        lseAsset={lseAssetForMatching}
        setLseAsset={setLseAssetForMatching}
      />
      <AddAsNewEquityDialog
        lseAsset={lseAssetForAdding}
        setLseAsset={setLseAssetForAdding}
      />
    </div>
  );
};

export default LseData;
