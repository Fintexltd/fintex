import React from 'react';
import useNoDataInfo from './useNoDataInfo';

const NoDataInfo = () => {
  const { resultsNumber } = useNoDataInfo();

  return resultsNumber === 0 ? (
    <div className="lseData-requests__empty-list">
      <p className="lseData-requests__empty-list-message">
        There are no LSE Data
      </p>
    </div>
  ) : null;
};

export default NoDataInfo;
