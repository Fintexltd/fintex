import React from 'react';
import Pagination from 'common/components/pagination';
import useLseDataPagination from './useLseDataPagination';

const LseDataPagination = () => {
  const {
    perPage,
    resultsNumber,
    meta,
    getResults,
    saveFilters,
  } = useLseDataPagination();

  return (
    <Pagination
      meta={meta}
      resultsNumber={resultsNumber}
      saveFilters={saveFilters}
      getResults={getResults}
      perPage={perPage}
      showRowsPerPage={false}
    />
  );
};

export default LseDataPagination;
