import * as yup from 'yup';

const requiredError = 'This field is required.';
const locationError = 'No location found for this address.';

export const addAsNewEquitySchema = yup.object().shape({
  address: yup.string().required(requiredError),
  country: yup.array().required(requiredError).min(1),
  industry: yup.array().required(requiredError).min(1),
  longitude: yup.number().typeError(locationError).required(locationError),
  latitude: yup.number().typeError(locationError).required(locationError),
});
