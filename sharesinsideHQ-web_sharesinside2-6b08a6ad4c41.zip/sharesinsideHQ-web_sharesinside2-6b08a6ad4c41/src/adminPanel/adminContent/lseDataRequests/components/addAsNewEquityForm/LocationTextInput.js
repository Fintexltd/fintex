import React from 'react';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import { useLocationTextInput } from './useInputs';

const parseErrorMessage = (errors) => {
  if (errors.address) {
    return errors.address.message;
  }
  if (errors.longitude) {
    return errors.longitude.message;
  }
  if (errors.latitude) {
    return errors.latitude.message;
  }
  return null;
};

const LocationTextInput = ({ innerRef, setValue, errors, clearErrors }) => {
  const { onChange } = useLocationTextInput(setValue, errors, clearErrors);

  return (
    <FormGroup>
      <Input
        name="address"
        innerRef={innerRef}
        placeholder="Location*"
        error={parseErrorMessage(errors)}
        onChange={onChange}
        touched
      />
    </FormGroup>
  );
};

export default LocationTextInput;
