import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchIndustriesList from 'common/redux/actions/industriesListActions';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const DataLoader = () => {
  const dispatch = useDispatch();

  const countries = useSelector((state) => state.countries.list);
  const industries = useSelector((state) => state.industries.list);

  useEffect(() => {
    if (!countries) dispatch(fetchCountriesList());
  }, [dispatch, countries]);

  useEffect(() => {
    if (!industries) dispatch(fetchIndustriesList());
  }, [dispatch, industries]);

  return null;
};

export default DataLoader;
