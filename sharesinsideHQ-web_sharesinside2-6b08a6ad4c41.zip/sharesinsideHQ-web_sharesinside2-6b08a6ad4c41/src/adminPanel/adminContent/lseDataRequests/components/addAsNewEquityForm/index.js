import React from 'react';
import { ModalBody, ModalFooter, ButtonGroup, Button } from 'reactstrap';
import CircleSpinner from 'common/components/circleSpinner';
import CountrySelectInput from './CountrySelectInput';
import IndustrySelectInput from './IndustrySelectInput';
import DataLoader from './dataLoader';
import LocationSelectInput from './LocationTextInput';
import useAddAsNewEquityForm from './useAddAsNewEquityForm';

const AddAsNewEquityForm = ({ asset, close }) => {
  const {
    register,
    errors,
    clearErrors,
    control,
    setValue,
    handleSubmit,
    onSubmit,
    loading,
  } = useAddAsNewEquityForm(asset, close);

  return (
    <form className="lseData-form" onSubmit={handleSubmit(onSubmit)}>
      <ModalBody>
        <p>
          This action will ad new equity: 
          {' '}
          <b>{asset.name}</b>
        </p>
        <DataLoader />
        <LocationSelectInput
          innerRef={register}
          setValue={setValue}
          errors={errors}
          clearErrors={clearErrors}
        />
        <CountrySelectInput control={control} errors={errors} />
        <IndustrySelectInput control={control} errors={errors} />
        <input name="longitude" type="hidden" ref={register} />
        <input name="latitude" type="hidden" ref={register} />
        <p>
          In future, all data from the LSE API will be automatically linked to
          this equity.
        </p>
      </ModalBody>
      <ModalFooter className="modal-new__footer">
        {loading && <CircleSpinner />}
        <ButtonGroup>
          <Button onClick={close} disabled={loading} outline color="primary">
            Cancel
          </Button>
          <Button type="submit" disabled={loading} color="primary">
            Confirm
          </Button>
        </ButtonGroup>
      </ModalFooter>
    </form>
  );
};

export default AddAsNewEquityForm;
