import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch } from 'react-redux';
import { addAsNewEquitySchema } from './formValidation';
import { acceptAsCompanyRequest } from '../../api/lseDataApi';
import { fetchLseData } from '../../redux/actions/lseDataActions';

const useAddAsNewEquityForm = ({ additional_data, ...asset }, closeForm) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);

  const {
    register,
    errors,
    clearErrors,
    control,
    setValue,
    handleSubmit,
  } = useForm({
    defaultValues: {
      address: additional_data.address,
      longitude: additional_data.longitude,
      latitude: additional_data.latitude,
      industry: [],
      country: asset.country
        ? [
            {
              label: asset.country.country_name,
              value: asset.country.id,
            },
          ]
        : [],
    },
    resolver: yupResolver(addAsNewEquitySchema),
  });

  const onSubmit = (data) => {
    setLoading(true);
    acceptAsCompanyRequest(asset.id, {
      industry_id: data.industry[0].value,
      country_id: data.country[0].value,
      address: data.address,
      longitude: data.longitude,
      latitude: data.latitude,
    })
      .then(() => {
        dispatch(fetchLseData(null));
        closeForm();
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  };

  return {
    register,
    errors,
    clearErrors,
    control,
    setValue,
    handleSubmit,
    onSubmit,
    loading,
  };
};

export default useAddAsNewEquityForm;
