import { useMemo, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { debounce } from 'lodash';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { getLocationData } from 'common/api/googleMapsApi';
import { EMPTY_LOCATION_PROMISE } from 'common/redux/actions/locationDataActions';

const useCountrySelectInput = () => {
  const countries = useSelector((state) => state.countries.list);

  const countriesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: countries || [],
        label: 'country_name',
        value: 'id',
        category: 'country',
      }),
    [countries],
  );

  return { countriesList };
};

const useIndustrySelectInput = () => {
  const industries = useSelector((state) => state.industries.list);

  const industriesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: industries || [],
        label: 'name',
        value: 'id',
        category: 'industry',
      }),
    [industries],
  );
  return { industriesList };
};

const useLocationTextInput = (setValue, errors, clearErrors) => {
  const handleLocationChange = useCallback(
    debounce((location) => {
      (location.trim() ? getLocationData(location) : EMPTY_LOCATION_PROMISE)
        .then((res) => {
          setValue('longitude', res.location.lng || undefined, {
            shouldValidate: true,
          });
          setValue('latitude', res.location.lat || undefined, {
            shouldValidate: true,
          });
        })
        .catch(() => {
          setValue('longitude', undefined, { shouldValidate: true });
          setValue('latitude', undefined, { shouldValidate: true });
        });
    }, 1000),
    [],
  );

  const onChange = (event) => {
    if (errors.latitude || errors.longitude) {
      clearErrors('longitude');
      clearErrors('latitude');
    }
    const location = event.target.value;
    handleLocationChange(location);
  };

  return { onChange };
};

export { useCountrySelectInput, useIndustrySelectInput, useLocationTextInput };
