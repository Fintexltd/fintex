import React from 'react';
import SingleSelectFormInput from 'adminPanel/adminContent/common/components/formInput/singleSelectFormInput';
import { useCountrySelectInput } from './useInputs';

const CountrySelectInput = ({ control, errors }) => {
  const { countriesList } = useCountrySelectInput();

  return (
    <SingleSelectFormInput
      options={countriesList}
      isSearchable
      placeholder="Country*"
      name="country"
      errors={errors}
      control={control}
    />
  );
};

export default CountrySelectInput;
