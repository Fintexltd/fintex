import React from 'react';
import SingleSelectFormInput from 'adminPanel/adminContent/common/components/formInput/singleSelectFormInput';
import { useIndustrySelectInput } from './useInputs';

const IndustrySelectInput = ({ control, errors }) => {
  const { industriesList } = useIndustrySelectInput();

  return (
    <SingleSelectFormInput
      options={industriesList}
      isSearchable
      placeholder="Industry*"
      name="industry"
      errors={errors}
      control={control}
    />
  );
};

export default IndustrySelectInput;
