import React from 'react';
import { Link } from 'react-router-dom';
import './index.scss';

const status = (lseAsset) =>
  lseAsset.search_results.length ? (
    <p className="lseData-item__status lseData-item__status-matched">MATCHED</p>
  ) : (
    <p className="lseData-item__status lseData-item__status-new">NEW</p>
  );

const LseAssetItem = ({
  lseAsset,
  isRejected,
  rejectLseAsset,
  setLseAssetForMatching,
  setLseAssetForAdding,
}) => {
  const onRejectClick = () => rejectLseAsset(lseAsset.id);
  const onMatchClick = () => setLseAssetForMatching(lseAsset);
  const onAddClick = () => setLseAssetForAdding(lseAsset);

  return (
    <tr className="lseData-item">
      <td>
        <p className="lseData-item__name">{lseAsset.name}</p>
        {status(lseAsset)}
      </td>
      <td>
        {lseAsset.to_import.events}
        {' '}
        Event
        {lseAsset.to_import.events === 1 ? '' : 's'}
      </td>
      <td>
        <div className="lseData-item__buttons">
          <Link
            to={`/company/lse/${lseAsset.id}/about`}
            rel="noopener noreferrer"
          >
            <button className="lseData-item__button lseData-item__button--preview">
              Preview
            </button>
          </Link>
          <button
            onClick={onAddClick}
            className="lseData-item__button lseData-item__button--accept"
          >
            Add as new
          </button>
          <button
            onClick={onMatchClick}
            className="lseData-item__button lseData-item__button--match"
          >
            Match with existing
          </button>
          {!isRejected && (
            <button
              onClick={onRejectClick}
              className="lseData-item__button lseData-item__button--reject"
            >
              Reject
            </button>
          )}
        </div>
      </td>
    </tr>
  );
};

export default LseAssetItem;
