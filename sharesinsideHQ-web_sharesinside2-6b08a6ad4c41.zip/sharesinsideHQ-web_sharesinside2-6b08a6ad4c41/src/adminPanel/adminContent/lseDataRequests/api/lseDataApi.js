import axios from 'axios';

const getLseDataRequest = (params) =>
  axios.get(`${process.env.REACT_APP_API_URL}/admin/lse-assets`, {
    params,
  });

const searchCompanyNamesRequest = (search) =>
  axios.get(`${process.env.REACT_APP_API_URL}/admin/lse-entity-search`, {
    params: {
      search,
      entitiable_type: 'company',
    },
  });

const acceptAsCompanyRequest = (lseId, params) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/admin/lse-accept-as-company/${lseId}`,
    params,
  );

const rejectLseRequest = (lseId) =>
  axios.post(`${process.env.REACT_APP_API_URL}/admin/lse-reject/${lseId}`);

const attachToCompanyRequest = (lseId, companyId) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/admin/lse-attach-to-company/${lseId}`,
    {
      entitiable_id: companyId,
    },
  );

export {
  getLseDataRequest,
  searchCompanyNamesRequest,
  acceptAsCompanyRequest,
  rejectLseRequest,
  attachToCompanyRequest,
};
