import axios from 'axios';

export const requestImageToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=type_company_${type}`,
    data,
  );

export const requestAttachmentToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=${type}&file=${data}`,
    data,
    {
      headers: {
        Accept: 'application/json',
      },
    },
  );

export const sendEventsDataRequest = (data) =>
  axios.post(`${process.env.REACT_APP_API_URL}/events?`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
