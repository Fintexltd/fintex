import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import AddEventForm from 'adminPanel/adminContent/addEvent/containers/addEventForm';
import { checkIfUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './style.scss';

const mapStateToProps = (state) => ({
  company: state.adminCompany.currentCompany,
  locationData: state.locationData.results,
  userData: state.userData.data,
});

class AddEvent extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      this.props.userData &&
      !checkIfUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.company.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      !checkIfUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.company.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.company.id,
        ) && (
          <AddEventForm
            company={this.props.company}
            userData={this.props.userData}
            {...this.props}
          />
        )}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddEvent));
