import React from 'react';
import PropTypes from 'prop-types';
import IndustriesSearch from 'adminPanel/adminContent/industries/containers/industriesSearch';
import shortid from 'shortid';
import './index.scss';

const IndustriesView = ({
  industries,
  isIndustriesFiltersActive,
  editIndustry,
  addIndustry,
  openRemoveIndustryModal,
}) => (
  <div className="industries">
    <h1 className="industries__heading">Manage Industries</h1>
    <IndustriesSearch />
    <table className="industries__table">
      <thead className="industries__thead">
        <tr>
          <th>Name</th>
          <th>Sector</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td
            className="add__industries"
            colSpan={8}
            onClick={addIndustry}
            role="presentation"
          >
            <div className="industries-container">
              <h2>+ Add new industry</h2>
            </div>
          </td>
        </tr>
        {industries.map(industry => (
          <tr key={shortid.generate()} className="industries__industry-row">
            <td>
              <div className="industries__user-data">
                <div>
                  <p className="industries__name">{industry.name}</p>
                </div>
              </div>
            </td>
            <td>
              <p className="industries__name">
                {industry.economic_sector.name}
              </p>
            </td>
            <td>
              <div className="industries__buttons">
                <button
                  onClick={() => editIndustry(industry)}
                  className="industries__button industries__button--edit"
                >
                  Edit
                </button>
                <button
                  onClick={() => openRemoveIndustryModal(industry.id)}
                  className="industries__button industries__button--remove"
                >
                  Remove
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    {isIndustriesFiltersActive() &&
      industries.length === 0 && (
        <div className="industries__empty-list">
          <p className="industries__empty-list-message">
            There are no industries matching these criteria
          </p>
        </div>
      )}
  </div>
);

IndustriesView.propTypes = {
  industries: PropTypes.arrayOf(PropTypes.object).isRequired,
  isIndustriesFiltersActive: PropTypes.func.isRequired,
  editIndustry: PropTypes.func.isRequired,
  addIndustry: PropTypes.func.isRequired,
  openRemoveIndustryModal: PropTypes.func.isRequired,
};

export default IndustriesView;
