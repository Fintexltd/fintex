import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import './index.scss';

const IndustriesAdvancedSearchView = ({
  industriesFilters,
  sectorsList,
  handleFilterUsage,
}) => (
  <div className="industries-advanced-search">
    <div className="industries-advanced-search__filters">
      <div className="industries-advanced-search__filter">
        <MultiSelect
          options={sectorsList}
          description="Sector"
          onChange={handleFilterUsage}
          value={industriesFilters.sector}
          category="sector"
        />
      </div>
    </div>
  </div>
);

IndustriesAdvancedSearchView.propTypes = {
  handleFilterUsage: PropTypes.func.isRequired,
};

export default IndustriesAdvancedSearchView;
