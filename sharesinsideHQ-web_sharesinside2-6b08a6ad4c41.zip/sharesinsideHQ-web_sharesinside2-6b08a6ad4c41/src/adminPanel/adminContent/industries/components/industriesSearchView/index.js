import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import IndustriesAdvancedSearch from 'adminPanel/adminContent/industries/containers/industriesAdvancedSearch';
import './index.scss';

const IndustriesSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isAdvancedSearchVisible,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  toggleAdvancedSearch,
  industriesFilters,
  handleFilterRemoveClick,
}) => (
  <div className="industries-search">
    <div className="industries-search__top">
      <div className="industries-search__top-left">
        <div className="industries-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={industriesFilters.search}
          />
        </div>
        <div className="industries-search__filters-button">
          <ToggleMoreFiltersButton
            handleToggleMoreFiltersClick={toggleAdvancedSearch}
            isMoreFiltersVisible={isAdvancedSearchVisible}
          />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="industries-search__clear-filters-button">
          <div className="industries-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="industries-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    {isAdvancedSearchVisible && <IndustriesAdvancedSearch />}
    <div className="industries-search__results-container">
      <div className="industries-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

IndustriesSearchView.defaultProps = {
  resultsNumber: null,
};

IndustriesSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isAdvancedSearchVisible: PropTypes.bool.isRequired,
  toggleAdvancedSearch: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default IndustriesSearchView;
