import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchIndustries from 'adminPanel/adminContent/industries/redux/actions/industriesActions';
import { saveIndustriesFilters } from 'adminPanel/adminContent/industries/redux/actions/industriesFiltersActions';
import IndustriesView from 'adminPanel/adminContent/industries/components/industriesView';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import { FormGroup } from 'reactstrap';
import FormModal from 'common/components/modals/form';
import validationSchema from 'adminPanel/adminContent/industries/validators/validationSchema';
import Input from 'common/components/input';
import { disableScroll } from 'common/utils/disableScroll';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import SingleSelect from 'common/components/customSelect/singleSelect';
import RemoveModal from 'common/components/removeModal';
import InfoModal from 'common/components/infoModal';
import fetchSectorsList from 'common/redux/actions/sectorsListActions';
import {
  addIndustry,
  editIndustry,
  deleteIndustry,
} from 'adminPanel/adminContent/industries/api/industriesApi';
import setSubmitErrors from 'adminPanel/adminContent/industries/utils/submitErrors';

const mapStateToProps = (state) => ({
  industries: state.industriesAdmin.data,
  industriesFilters: state.industriesFilters,
  token: state.auth.token,
  userData: state.userData.data,
  resultsNumber: state.industriesAdmin.resultsNumber,
  sectorsList: state.sectors.list,
});

const mapDispatchToProps = (dispatch) => ({
  getIndustries: bindActionCreators(fetchIndustries, dispatch),
  saveIndustriesFilters: bindActionCreators(saveIndustriesFilters, dispatch),
  getSectorsList: bindActionCreators(fetchSectorsList, dispatch),
});

class AdminIndustries extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isErrorModalVisible: false,
      errorModalMessage: [],
      isIndustryModalVisible: false,
      isRemoveIndustryModalVisible: false,
      values: {
        name: '',
        sector_id: '',
      },
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_INDUSTRIES,
      )
    )
      this.props.history.push('/admin/company/management');

    this.props.getIndustries();
    this.props.getSectorsList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_INDUSTRIES,
      )
    )
      this.props.history.push('/admin/company/management');
  }

  isIndustriesFiltersActive = () => {
    const { sector, search } = this.props.industriesFilters;
    return sector.length > 0 || search !== '';
  };

  toggleIndustryModal = () => {
    this.setState(
      (prevState) => ({
        isIndustryModalVisible: !prevState.isIndustryModalVisible,
      }),
      () => disableScroll(this.state.isIndustryModalVisible),
    );
  };

  submitIndustry = (values, actions) => {
    if (values.isEditing) {
      editIndustry(values.id, values.name, values.sector_id)
        .then(() => {
          this.toggleIndustryModal();
          this.props.getIndustries();
        })
        .catch((error) => {
          actions.setErrors(setSubmitErrors(error));
        });
    } else {
      addIndustry(values.name, values.sector_id)
        .then(() => {
          this.toggleIndustryModal();
          this.props.getIndustries();
        })
        .catch((error) => {
          actions.setErrors(setSubmitErrors(error));
        });
    }
  };

  toggleRemoveIndustryModal = () => {
    this.setState(
      (prevState) => ({
        isRemoveIndustryModalVisible: !prevState.isRemoveIndustryModalVisible,
      }),
      () => disableScroll(this.state.isRemoveIndustryModalVisible),
    );
  };

  openRemoveIndustryModal = (id) => {
    this.toggleRemoveIndustryModal();
    this.setState({
      industryToRemove: id,
    });
  };

  removeIndustry = () => {
    deleteIndustry(this.state.industryToRemove)
      .then(() => {
        this.props.getIndustries().then(() => {
          this.toggleRemoveIndustryModal();
        });
      })
      .catch((error) => {
        this.toggleRemoveIndustryModal();
        this.toggleErrorModal();
        this.setState({
          errorModalMessage: error.response.data.errors
            ? Object.keys(error.response.data.errors).map(
                (key) => error.response.data.errors[key][0],
              )
            : ['There was an error.'],
        });
      });
  };

  toggleErrorModal = () => {
    this.setState(
      (prevState) => ({
        isErrorModalVisible: !prevState.isErrorModalVisible,
      }),
      () => disableScroll(this.state.isErrorModalVisible),
    );
  };

  addIndustry = () => {
    this.toggleIndustryModal();
    this.setState({
      values: {
        name: '',
        sector_id: 11,
        isEditing: false,
      },
    });
  };

  editIndustry = (industry) => {
    this.toggleIndustryModal();
    this.setState({
      values: {
        name: industry.name,
        id: industry.id,
        sector_id: industry.economic_sector.id,
        isEditing: true,
      },
    });
  };

  render() {
    const ModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.name}
            error={formProps.errors.name}
            touched={formProps.touched.name}
            name="name"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Name*"
          />
          <span className="letter-counter">
            {`${formProps.values.name.length}/32`}
          </span>
        </FormGroup>
        <FormGroup>
          <SingleSelect
            description="Sector*"
            onChange={(value) => {
              formProps.setFieldTouched('sector_id', true);
              formProps.setFieldValue('sector_id', value[0].value);
            }}
            options={mapObjPropsToSelectFilter({
              list: this.props.sectorsList
                ? this.props.sectorsList.map(({ name: sectorName, id }) => ({
                    value: id,
                    label: sectorName,
                  }))
                : [],
              label: 'label',
              value: 'value',
              category: 'sector',
            })}
            value={[
              {
                category: 'sector',
                label: this.props.sectorsList.filter(
                  (element) => element.id === formProps.values.sector_id,
                )[0]
                  ? this.props.sectorsList.filter(
                      (element) => element.id === formProps.values.sector_id,
                    )[0].name
                  : '',
                value: formProps.values.sector_id,
              },
            ]}
            category="sector"
          />
          <div className="sectorSelect--error">
            {formProps.errors.sector_id}
          </div>
        </FormGroup>
      </>
    );
    return (
      <>
        <IndustriesView
          industries={this.props.industries}
          isIndustriesFiltersActive={this.isIndustriesFiltersActive}
          getIndustries={this.props.getIndustries}
          saveIndustriesFilters={this.props.saveIndustriesFilters}
          addNewIndustry={this.addNewIndustry}
          resultsNumber={this.props.resultsNumber}
          userData={this.props.userData}
          toggleIndustryModal={this.toggleIndustryModal}
          openRemoveIndustryModal={this.openRemoveIndustryModal}
          removeIndustry={this.removeIndustry}
          editIndustry={this.editIndustry}
          addIndustry={this.addIndustry}
        />
        <FormModal
          isModalVisible={this.state.isIndustryModalVisible}
          handleClose={this.toggleIndustryModal}
          header="Add Industry"
          validationSchema={validationSchema}
          onSubmit={this.submitIndustry}
          initialValues={this.state.values}
          confimButtonText="Confirm"
        >
          <ModalFormView />
        </FormModal>
        {this.state.isRemoveIndustryModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this industry?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeIndustry}
            handleCancelClick={this.toggleRemoveIndustryModal}
          />
        )}
        {this.state.isErrorModalVisible && (
          <InfoModal
            message={this.state.errorModalMessage.join(' ')}
            handleAcceptClick={this.toggleErrorModal}
          />
        )}
      </>
    );
  }
}

AdminIndustries.defaultProps = {
  industries: [],
  resultsNumber: null,
};

AdminIndustries.propTypes = {
  industries: PropTypes.arrayOf(PropTypes.object),
  getIndustries: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  industriesFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  saveIndustriesFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminIndustries));
