export default function setSubmitErrors(error) {
  let submitErrors = {};
  if (error.response.data.errors) {
    submitErrors = {
      ...(error.response.data.errors.name
        ? { name: error.response.data.errors.name }
        : {}),
      ...(error.response.data.errors.economic_sector
        ? { economic_sector: error.response.data.errors.economic_sector }
        : {}),
    };
  }
  return submitErrors;
}
