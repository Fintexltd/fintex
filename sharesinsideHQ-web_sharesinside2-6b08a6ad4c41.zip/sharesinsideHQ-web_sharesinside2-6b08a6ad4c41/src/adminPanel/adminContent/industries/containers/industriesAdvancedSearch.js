import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import IndustriesAdvancedSearchView from 'adminPanel/adminContent/industries/components/industriesAdvancedSearchView';
import fetchIndustries from 'adminPanel/adminContent/industries/redux/actions/industriesActions';
import fetchSectorsList from 'common/redux/actions/sectorsListActions';
import { saveIndustriesFilters } from 'adminPanel/adminContent/industries/redux/actions/industriesFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  industriesFilters: state.industriesFilters,
  companiesNames: state.companiesNames.list,
  sectorsList: state.sectors.list,
});

const mapDispatchToProps = dispatch => ({
  getIndustries: bindActionCreators(fetchIndustries, dispatch),
  getSectorsList: bindActionCreators(fetchSectorsList, dispatch),
  saveIndustriesFilters: bindActionCreators(saveIndustriesFilters, dispatch),
});

class IndustriesAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetIndustries = debounce(props.getIndustries, 500);
  }

  componentDidMount() {
    this.props.getSectorsList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveIndustriesFilters(values.length > 0 ? values : { category });
    this.debouncedGetIndustries();
  };

  render() {
    return (
      <IndustriesAdvancedSearchView
        sectorsList={mapObjPropsToSelectFilter({
          list: this.props.sectorsList || [],
          label: 'name',
          value: 'id',
          category: 'sector',
        })}
        handleFilterUsage={this.handleFilterUsage}
        industriesFilters={this.props.industriesFilters}
      />
    );
  }
}

IndustriesAdvancedSearch.propTypes = {
  getIndustries: PropTypes.func.isRequired,
  saveIndustriesFilters: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(IndustriesAdvancedSearch);
