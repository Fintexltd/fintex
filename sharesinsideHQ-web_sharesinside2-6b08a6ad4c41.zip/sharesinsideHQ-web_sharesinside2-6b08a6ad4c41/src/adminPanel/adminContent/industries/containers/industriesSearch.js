import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import IndustriesSearchView from 'adminPanel/adminContent/industries/components/industriesSearchView';
import fetchIndustries from 'adminPanel/adminContent/industries/redux/actions/industriesActions';
import {
  removeIndustriesFilters,
  saveIndustriesSearch,
  saveIndustriesFilters,
} from 'adminPanel/adminContent/industries/redux/actions/industriesFiltersActions';

const mapStateToProps = state => ({
  industries: state.industriesAdmin.list,
  industriesFilters: state.industriesFilters,
  resultsNumber: state.industriesAdmin.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getIndustries: bindActionCreators(fetchIndustries, dispatch),
  removeIndustriesFilters: bindActionCreators(
    removeIndustriesFilters,
    dispatch,
  ),
  saveIndustriesSearch: bindActionCreators(saveIndustriesSearch, dispatch),
  saveIndustriesFilters: bindActionCreators(saveIndustriesFilters, dispatch),
});

class IndustriesSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetIndustries = debounce(props.getIndustries, 500);
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeIndustriesFilters();
    this.debouncedGetIndustries();
  };

  handleSearchInputChange = text => {
    this.props.saveIndustriesSearch(text);
    this.debouncedGetIndustries();
  };

  mapActiveFiltersLists = () => [...this.props.industriesFilters.sector];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.industriesFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveIndustriesFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetIndustries();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <IndustriesSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        industriesFilters={this.props.industriesFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

IndustriesSearch.defaultProps = {
  resultsNumber: null,
};

IndustriesSearch.propTypes = {
  getIndustries: PropTypes.func.isRequired,
  removeIndustriesFilters: PropTypes.func.isRequired,
  saveIndustriesSearch: PropTypes.func.isRequired,
  saveIndustriesFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(IndustriesSearch);
