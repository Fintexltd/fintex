import axios from 'axios';

export const addIndustry = (name, sectorId) =>
  axios({
    method: 'post',
    url: `${process.env.REACT_APP_API_URL}/industries`,
    data: {
      name,
      economic_sector_id: sectorId,
    },
  });

export const editIndustry = (id, name, sectorId) =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/industries/${id}`,
    data: {
      name,
      economic_sector_id: sectorId,
    },
  });

export const deleteIndustry = id =>
  axios({
    method: 'delete',
    url: `${process.env.REACT_APP_API_URL}/industries/${id}`,
  });
