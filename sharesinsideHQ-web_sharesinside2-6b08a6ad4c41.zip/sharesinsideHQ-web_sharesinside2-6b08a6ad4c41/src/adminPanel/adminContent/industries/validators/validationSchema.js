import * as Yup from 'yup';

const userEditSchema = Yup.object().shape({
  name: Yup.string()
    .max(32, 'Name must be at most 32 characters')
    .required('This field is required.'),
  sector_id: Yup.number().required('This field is required.'),
});

export default userEditSchema;
