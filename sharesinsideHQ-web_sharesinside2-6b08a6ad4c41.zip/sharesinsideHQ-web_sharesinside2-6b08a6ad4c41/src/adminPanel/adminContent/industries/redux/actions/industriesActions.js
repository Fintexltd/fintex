import axios from 'axios';
import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/industries/redux/types.js';

const {
  FETCH_ADMIN_INDUSTRIES_REQUEST,
  FETCH_ADMIN_INDUSTRIES_SUCCESS,
  FETCH_ADMIN_INDUSTRIES_FAILURE,
} = types;

const fetchIndustriesRequest = createActionCreator(
  FETCH_ADMIN_INDUSTRIES_REQUEST,
);
const fetchIndustriesSuccess = createActionCreator(
  FETCH_ADMIN_INDUSTRIES_SUCCESS,
  'data',
);
const fetchIndustriesFailure = createActionCreator(
  FETCH_ADMIN_INDUSTRIES_FAILURE,
);

const fetchIndustries = () => (dispatch, getState) => {
  const { sector, search } = getState().industriesFilters;

  const getSelectedFiltersIds = filters => filters.map(filter => filter.value);

  dispatch(fetchIndustriesRequest());
  return axios
    .get(`${process.env.REACT_APP_API_URL}/industries`, {
      params: {
        search,
        economic_sectors: getSelectedFiltersIds(sector),
        with_sector: 1,
      },
    })
    .then(response => {
      dispatch(fetchIndustriesSuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchIndustriesFailure());
    });
};

export default fetchIndustries;
