import * as types from 'adminPanel/adminContent/industries/redux/types';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_ADMIN_INDUSTRIES_FILTERS,
  SAVE_ADMIN_INDUSTRIES_FILTERS,
  SAVE_ADMIN_INDUSTRIES_SEARCH,
} = types;

export const removeIndustriesFilters = createActionCreator(
  REMOVE_ADMIN_INDUSTRIES_FILTERS,
);

export const saveIndustriesFilters = createActionCreator(
  SAVE_ADMIN_INDUSTRIES_FILTERS,
  'filter',
);

export const saveIndustriesSearch = createActionCreator(
  SAVE_ADMIN_INDUSTRIES_SEARCH,
  'search',
);
