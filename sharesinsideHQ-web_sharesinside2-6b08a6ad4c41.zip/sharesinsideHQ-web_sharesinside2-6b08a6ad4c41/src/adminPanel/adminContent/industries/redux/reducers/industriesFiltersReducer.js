import { createReducer } from 'common/utils/reduxUtils';
import {
  REMOVE_ADMIN_INDUSTRIES_FILTERS,
  SAVE_ADMIN_INDUSTRIES_FILTERS,
  SAVE_ADMIN_INDUSTRIES_SEARCH,
} from 'adminPanel/adminContent/industries/redux/types';

const initialState = {
  sector: [],
  search: '',
  per_page: 10,
};

const IndustriesFiltersReducer = createReducer(
  { ...initialState },
  {
    [SAVE_ADMIN_INDUSTRIES_FILTERS]: (state, action) => {
      if (action.payload.filter && action.payload.filter[0]) {
        const { category } = action.payload.filter[0];
        return {
          ...state,
          [category]: action.payload.filter,
        };
      }
      if (action.payload.filter.category) {
        const { category } = action.payload.filter;
        return {
          ...state,
          [category]: [],
        };
      }
      return {
        ...state,
      };
    },
    [REMOVE_ADMIN_INDUSTRIES_FILTERS]: state => ({
      ...state,
      sector: [],
    }),
    [SAVE_ADMIN_INDUSTRIES_SEARCH]: (state, action) => ({
      ...state,
      search: action.payload.search,
    }),
  },
);

export default IndustriesFiltersReducer;
