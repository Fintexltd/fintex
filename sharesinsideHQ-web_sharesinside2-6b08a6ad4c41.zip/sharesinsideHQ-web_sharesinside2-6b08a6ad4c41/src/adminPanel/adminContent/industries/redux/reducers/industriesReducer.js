import { createReducer } from 'common/utils/reduxUtils';
import {
  FETCH_ADMIN_INDUSTRIES_SUCCESS,
  UPDATE_ADMIN_INDUSTRIES_REQUESTS,
} from 'adminPanel/adminContent/industries/redux/types';

const initialState = {
  data: [],
  resultsNumber: null,
};

const IndustriesReducer = createReducer(
  { ...initialState },
  {
    [FETCH_ADMIN_INDUSTRIES_SUCCESS]: (state, action) => {
      const { data } = action.payload;
      return {
        ...state,
        data: [...data],
        resultsNumber: data.length,
      };
    },
    [UPDATE_ADMIN_INDUSTRIES_REQUESTS]: (state, action) => ({
      ...state,
      list: action.payload.updatedCompaniesRequests,
    }),
  },
);

export default IndustriesReducer;
