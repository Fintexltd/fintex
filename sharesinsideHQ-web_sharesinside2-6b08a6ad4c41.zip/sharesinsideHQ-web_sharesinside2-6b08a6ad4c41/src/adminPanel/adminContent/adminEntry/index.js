import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import addGrey from 'assets/icons/add_icon_big_grey.svg';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import './index.scss';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class AdminEntry extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.OPEN_ADMIN_PANEL,
      )
    )
      this.props.history.push('/');
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.OPEN_ADMIN_PANEL,
      )
    )
      this.props.history.push('/');
  }

  render() {
    return (
      <div className="admin-entry">
        <Link to="/admin/company/create" className="admin-entry__link">
          <img className="admin-entry__image" src={addGrey} alt="" />
          <p className="admin-entry__text">Add new company</p>
        </Link>
      </div>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AdminEntry));
