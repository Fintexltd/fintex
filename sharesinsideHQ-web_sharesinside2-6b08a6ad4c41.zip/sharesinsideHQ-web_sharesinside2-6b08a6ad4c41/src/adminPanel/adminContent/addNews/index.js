import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import AddNewsForm from 'adminPanel/adminContent/addNews/containers/addNewsForm';
import { checkIfUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './index.scss';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class AddNews extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      this.props.userData &&
      !checkIfUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      !checkIfUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.match.params.id,
        ) && <AddNewsForm company={this.props.company} />}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddNews));
