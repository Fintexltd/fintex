import axios from 'axios';

export const sendNewsData = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/news?`, data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const editNewsData = (newsId, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/news/${newsId}`, data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });
