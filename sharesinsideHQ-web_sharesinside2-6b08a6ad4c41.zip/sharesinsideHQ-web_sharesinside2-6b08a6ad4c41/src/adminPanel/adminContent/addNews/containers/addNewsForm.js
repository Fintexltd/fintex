import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { Button } from 'reactstrap';
import { Formik } from 'formik';
import { withRouter } from 'react-router';
import moment from 'moment';
import { isNil, omitBy } from 'lodash';
import {
  sendNewsData,
  editNewsData,
} from 'adminPanel/adminContent/addNews/api/addNewsApi';
import { addNewsSchema as validationSchema } from 'adminPanel/adminContent/addNews/validators/addNewsSchema';
import AddNewsFormView from 'adminPanel/adminContent/addNews/components/addNewsFormView';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { fetchAdminNews } from 'adminPanel/redux/actions/adminNewsActions';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import shortid from 'shortid';

const mapStateToProps = (state) => ({
  countriesList: state.countries.list,
  news: state.adminNews.currentNews,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  fetchAdminNews: bindActionCreators(fetchAdminNews, dispatch),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
});

class AddNewsForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiMessage: {},
      formData: {
        title: '',
        adhoc: false,
        description: '',
        images: [],
        files: [],
        videos: [],
        links: [],
        videoLinks: [],
        companyId: this.props.company.id,
        publishNow: true,
        publishAt: null,
        excluded: [],
        isExcluded: false,
        notifyStock: false,
        stockExchangeEmails: props.company.stock_exchange_emails || [],
        notifyStockNow: true,
        notifyStockAt: null,
        delete_attachments: [],
        delete_links: [],
        initFiles: [],
        initVideos: [],
        initImages: [],
        stockInformedInPast: false,
        isBusiness: 0,
        isInternal: 0,
        isLocal: 0,
        receivers: ['followers', 'shareholders', 'vips'],
        remind: false,
        remindAt: null,
      },
      publishDate: moment(),
      publishTime: moment(),
      notifyDate: moment(),
      notifyTime: moment(),
      remindDate: moment(),
      remindTime: moment(),
      excludedCountries: [],
      notifyError: '',
      publishError: '',
      isLoaded: false,
      isEditMode: false,
      remindError: '',
    };
    this.isClicked = false;
    this.isClickedDraft = false;
  }

  componentDidMount() {
    if (!this.props.countriesList) {
      this.props.fetchCountriesList();
    }

    if (!this.props.match.params.id) {
      this.props.history.replace(`/admin/company/management/`);
    }

    if (this.props.match.params.id && !this.props.match.params.newsId) {
      this.setStockExchangeEmails(() =>
        this.setExcludedCountries(this.props.company.excluded),
      );
    }

    if (this.props.match.params.newsId) {
      this.props.fetchAdminNews(this.props.match.params.newsId).then(() => {
        this.setExcludedCountries(this.props.news.excluded);
        const { news } = this.props;
        this.setState((prevState) => ({
          isLoaded: true,
          isEditMode: true,
          isPublished: this.props.news.is_published,
          formData: {
            ...prevState.formData,
            title: news.title,
            description: news.description,
            adhoc: news.is_ad_hoc,
            links: news.links,
            videoLinks: news.video_links,
            publishNow: news.publish_now,
            publishAt: news.publish_at,
            initFiles: news.files,
            initVideos: news.videos,
            initImages: news.images,
            notifyStock: news.notify_stock,
            stockExchangeEmails: news.stock_exchange_emails,
            isExcluded: news.is_excluded,
            notifyStockNow: !news.notify_stock_at,
            notifyStockAt: news.notify_stock_at,
            stockInformedInPast: news.stock_informed_in_past,
            isBusiness: news.is_business,
            isInternal: news.is_internal,
            isLocal: news.is_local,
            receivers: news.receivers,
            remind: news.remind,
            remindAt: news.remind_at,
            remindConcernsUser: news.remind_concerns_user,
            isDraft: news.is_draft,
          },
          publishDate: moment.unix(this.props.news.publish_at),
          publishTime: moment.unix(this.props.news.publish_at),
          notifyDate: this.props.news.notify_stock_at
            ? moment.unix(this.props.news.notify_stock_at)
            : moment(),
          notifyTime: this.props.news.notify_stock_at
            ? moment.unix(this.props.news.notify_stock_at)
            : moment(),
          remindDate: this.props.news.remind_at
            ? moment.unix(this.props.news.remind_at)
            : moment(),
          remindTime: this.props.news.remind_at
            ? moment.unix(this.props.news.remind_at)
            : moment(),
        }));
      });
    }
  }

  getNewLinks = () => {
    const links = this.props.news.links
      ? this.props.news.links.map((link) => link.id)
      : [];
    const linksToExclude = links.concat(this.state.formData.delete_links);
    return this.state.formData.links.filter(
      (link) => !linksToExclude.includes(link.id),
    );
  };

  getNewVideoLinks = () => {
    const videoLinks = this.props.news.video_links
      ? this.props.news.video_links.map((file) => file.id)
      : [];
    const videoLinksToExclude = videoLinks.concat(
      this.state.formData.delete_links,
    );
    return this.state.formData.videoLinks.filter(
      (link) => !videoLinksToExclude.includes(link.id),
    );
  };

  setExcludedCountries = (excluded = []) => {
    const excludedCountries = mapObjPropsToSelectFilter({
      list: excluded,
      label: 'country_name',
      value: 'id',
      category: 'country',
    });
    this.setState((prevState) => ({
      excludedCountries,
      formData: {
        ...prevState.formData,
        excluded: excludedCountries.map((item) => item.value),
      },
    }));
  };

  setStockExchangeEmails = (callback) => {
    this.setState(
      (prevState) => ({
        formData: {
          ...prevState.formData,
          stockExchangeEmails: this.props.company.stock_exchange_emails,
        },
      }),
      callback,
    );
  };

  setCountryToExclude = (values) => {
    this.setState((prevState) => ({
      excludedCountries: values,
      formData: {
        ...prevState.formData,
        excluded: values.map((item) => item.value),
      },
    }));
  };

  handleExcludedCountryRemoveClick = (label) => {
    const filteredOut = this.state.excludedCountries.filter(
      (el) => el.label !== label,
    );
    this.setState((prevState) => ({
      excludedCountries: filteredOut,
      formData: {
        ...prevState.formData,
        excluded: filteredOut.map((item) => item.value),
      },
    }));
  };

  removeNotifyAndPublishErrors = () => {
    this.setState({
      notifyError: '',
      publishError: '',
    });
  };

  handleSubmit = (values, type) => {
    const data = omitBy(
      {
        entitiable_type: 'company',
        entitiable_id: this.props.company.id,
        title: values.title.trimStart(),
        description: values.description,
        is_ad_hoc: values.adhoc ? 1 : 0,
        is_draft: type === 'preview' || type === 'draft' ? 1 : 0,
        publish_now: this.state.formData.publishNow,
        publish_at: this.state.formData.publishAt,
        files: values.files,
        videos: values.videos,
        images: values.images,
        links: this.getNewLinks(),
        video_links: this.getNewVideoLinks(),
        excluded: this.state.formData.excluded,
        is_excluded: this.state.formData.isExcluded,
        stock_exchange_emails: this.state.formData.stockExchangeEmails,
        notify_stock: values.notifyStock,
        notify_stock_now: values.notifyStock
          ? this.state.formData.notifyStockNow
          : null,
        notify_stock_at:
          values.notifyStock && !this.state.formData.notifyStockNow
            ? this.state.formData.notifyStockAt
            : null,
        delete_attachments: this.state.formData.delete_attachments,
        delete_links: this.state.formData.delete_links,
        is_business: this.state.formData.isBusiness,
        is_internal: this.state.formData.isInternal,
        is_local:
          // NOTE: check if publication date is not in the past
          !this.state.formData.publishAt ||
          (this.state.formData.publishAt &&
            moment().unix() - this.state.formData.publishAt <= 0)
            ? this.state.formData.isLocal
            : null,
        receivers:
          // NOTE: check if publication date is not in the past
          !this.state.formData.publishAt ||
          (this.state.formData.publishAt &&
            moment().unix() - this.state.formData.publishAt <= 0)
            ? this.state.formData.receivers
            : [],
      },
      isNil,
    );

    let dataWithRemind;

    if (
      (!this.props.match.params.newsId && values.remind) ||
      (this.props.match.params.newsId && this.state.formData.remindConcernsUser)
    ) {
      dataWithRemind = omitBy(
        {
          ...data,
          remind: values.remind,
          remind_at: values.remind ? this.state.formData.remindAt : null,
        },
        isNil,
      );
    }

    if (
      values.remind &&
      ((this.state.formData.publishAt &&
        this.state.formData.remindAt <= this.state.formData.publishAt) ||
        (!this.state.formData.publishAt &&
          this.state.formData.remindAt <= moment().unix()) ||
        this.state.formData.remindAt <= moment().unix())
    ) {
      this.setState({
        remindError:
          'The time of reminder should be later than current time and publication time.',
      });
      return;
    }

    if (values.notifyStock) {
      if (this.state.formData.notifyStockNow) {
        if (
          this.state.formData.publishAt > moment().add(30, 'minutes').unix()
        ) {
          this.submitNewsData(dataWithRemind || data, type);
        } else {
          this.setState({
            notifyError:
              'The time of publication should be at least 30 minutes later from now.',
          });
        }
      } else if (
        !this.state.formData.notifyStockNow &&
        this.state.formData.publishAt >
          moment
            .unix(this.state.formData.notifyStockAt)
            .add(30, 'minutes')
            .unix()
      ) {
        this.submitNewsData(dataWithRemind || data, type);
      } else {
        this.setState({
          publishError:
            'The time between notification and publication should be at least 30 minutes.',
        });
      }
    } else {
      this.submitNewsData(dataWithRemind || data, type);
    }
  };

  submitNewsData = (data, type) => {
    if (this.props.match.params.newsId) {
      editNewsData(this.props.match.params.newsId, data)
        .then((response) => {
          if (response.status === 200) {
            if (type === 'preview') {
              this.props.history.replace(
                `/news/${this.props.match.params.newsId}`,
              );
            } else {
              this.props.history.replace(
                `/admin/company/manage/${this.props.company.id}/news`,
              );
            }
          }
        })
        .catch((err) => {
          if (err.response.data) {
            this.isClicked = false;
            this.setState({
              apiMessage: {
                ...err.response.data.errors,
              },
            });
          }
        });
    } else {
      sendNewsData(data)
        .then((response) => {
          if (response.status === 200) {
            if (type === 'preview') {
              this.props.history.replace(`/news/${response.data.id}`);
            } else {
              this.props.history.replace(
                `/admin/company/manage/${this.props.company.id}/news`,
              );
            }
          }
        })
        .catch((err) => {
          if (err.response.data) {
            this.isClicked = false;
            this.setState({
              apiMessage: {
                ...err.response.data.errors,
              },
            });
          }
        });
    }
  };

  updateCompanyNewsFormState = (values) => {
    this.isClicked = false;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...values,
        links: prevState.formData.links,
        videoLinks: prevState.formData.videoLinks,
        publishNow: prevState.formData.publishNow,
        publishAt: prevState.formData.publishAt,
        excluded: prevState.formData.excluded,
        stockExchangeEmails: prevState.formData.stockExchangeEmails,
        notifyStockNow: prevState.formData.notifyStockNow,
        notifyStockAt: prevState.formData.notifyStockAt,
        remindAt: prevState.formData.remindAt,
      },
      notifyError: '',
      publishError: '',
    }));
  };

  handleCancelButton = () => {
    this.props.history.replace(
      `/admin/company/manage/${this.props.company.id}/news`,
    );
  };

  mergeLinksArray = (objectType, values) => {
    this.isClicked = false;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values, linkToDelete) => {
    this.isClicked = false;
    const { formData } = this.state;
    const filteredArray = formData[objectType].filter(
      (element) =>
        element.name !== linkToDelete.name ||
        element.url !== linkToDelete.url ||
        element.type !== linkToDelete.type,
    );

    this.setState(
      (prevState) => ({
        formData: {
          ...prevState.formData,
          [objectType]: filteredArray,
        },
      }),
      () => {
        if (linkToDelete.id) {
          this.initFilesDelete(linkToDelete.id, 'links');
        }
      },
    );
  };

  handlePublishRadioChange = (e) => {
    const value = e.target.value === 'true';
    this.setState((prevState) => ({
      publishDate: moment(),
      publishTime: moment(),
      formData: {
        ...prevState.formData,
        publishNow: value,
        publishAt: value ? null : moment().unix(),
      },
    }));
    this.removeNotifyAndPublishErrors();
  };

  handlePublishDataChange = (date, time) => {
    if (date) {
      const publishDate = date;
      publishDate.set('hour', time.hour());
      publishDate.set('minute', time.minute());
      this.setState((prevState) => ({
        publishDate: date,
        publishTime: time,
        formData: {
          ...prevState.formData,
          publishNow: false,
          publishAt: publishDate.unix(),
        },
      }));
    }
    this.removeNotifyAndPublishErrors();
  };

  handleNotifyRadioChange = (e) => {
    const value = e.target.value === 'true';
    this.setState((prevState) => ({
      notifyDate: moment(),
      notifyTime: moment(),
      formData: {
        ...prevState.formData,
        notifyStockNow: value,
        notifyStockAt: value ? null : moment().unix(),
      },
    }));
    this.removeNotifyAndPublishErrors();
  };

  handleNotifyDataChange = (date, time) => {
    if (date) {
      const notifyDate = date;
      notifyDate.set('hour', time.hour());
      notifyDate.set('minute', time.minute());
      this.setState((prevState) => ({
        notifyDate: date,
        notifyTime: time,
        formData: {
          ...prevState.formData,
          notifyStockNow: false,
          notifyStockAt: notifyDate.unix(),
        },
      }));
    }
    this.removeNotifyAndPublishErrors();
  };

  handlePublicityRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        isBusiness: inputValue === 'business' ? 1 : 0,
        isInternal: inputValue === 'internal' ? 1 : 0,
        receivers:
          inputValue === 'internal'
            ? prevState.formData.receivers.filter(
                (i) => i !== 'shareholders' && i !== 'followers',
              )
            : prevState.formData.receivers,
      },
    }));
  };

  handleNotificationRangeRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        isLocal: inputValue === 'local' ? 1 : 0,
      },
    }));
  };

  handleNotificationReceiverCheckboxClick = (e) => {
    const { target } = e;
    if (target.checked) {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: [...prevState.formData.receivers, target.name],
        },
      }));
    } else {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: prevState.formData.receivers.filter(
            (i) => i !== target.name,
          ),
        },
      }));
    }
  };

  addStockExchangeEmail = (email) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stockExchangeEmails: [...prevState.formData.stockExchangeEmails, email],
      },
    }));
  };

  removeStockExchangeEmail = (emailToRemove) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stockExchangeEmails: prevState.formData.stockExchangeEmails.filter(
          (email) => email !== emailToRemove,
        ),
      },
    }));
  };

  initFilesDelete = (id, type) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [`delete_${type}`]: [...prevState.formData[`delete_${type}`], id],
      },
    }));
  };

  removeRemindError = () => {
    this.setState({
      remindError: '',
    });
  };

  handleRemindDataChange = (date, time) => {
    if (date) {
      const remindDate = date;
      remindDate.set('hour', time.hour());
      remindDate.set('minute', time.minute());
      this.setState((prevState) => ({
        remindDate: date,
        remindTime: time,
        formData: {
          ...prevState.formData,
          remindAt: remindDate.unix(),
        },
      }));
    }
    this.removeRemindError();
  };

  isRemindDisabled = (values) =>
    this.props.match.params.newsId &&
    !values.isDraft &&
    !this.state.formData.remindConcernsUser;

  handleRemindSwitch = (values) => {
    if (values.remind) {
      this.setState((prevState) => ({
        remindDate: moment(),
        remindTime: moment(),
        formData: {
          ...prevState.formData,
          remindAt: prevState.formData.remindAt
            ? prevState.formData.remindAt
            : moment().unix(),
        },
      }));
    }
    this.removeRemindError();
  };

  render() {
    return (
      <div>
        {((this.props.match.params.newsId && this.state.isLoaded) ||
          !this.props.match.params.newsId) && (
          <Formik
            ref={this.form}
            validationSchema={validationSchema}
            onSubmit={(values, { setErrors }) => {
              this.handleSubmit(values, setErrors);
              this.isClicked = true;
            }}
            initialValues={this.state.formData}
            render={({
              values,
              errors,
              touched,
              handleSubmit,
              handleChange,
              handleBlur,
              setFieldTouched,
              setFieldError,
              setFieldValue,
            }) => (
              <form onSubmit={handleSubmit} className="add-news-form">
                <AddNewsFormView
                  values={values}
                  errors={errors}
                  touched={touched}
                  handleChange={handleChange}
                  handleBlur={handleBlur}
                  setFieldTouched={setFieldTouched}
                  setFieldValue={setFieldValue}
                  setFieldError={setFieldError}
                  updateCompanyNewsFormState={this.updateCompanyNewsFormState}
                  mergeLinksArray={this.mergeLinksArray}
                  deleteLinksArray={this.deleteLinksArray}
                  handlePublishRadioChange={this.handlePublishRadioChange}
                  publishRadioValue={this.state.formData.publishNow}
                  publishTime={this.state.publishTime}
                  publishDate={this.state.publishDate}
                  handlePublishDataChange={this.handlePublishDataChange}
                  countriesList={
                    this.props.countriesList ? this.props.countriesList : []
                  }
                  excludedCountries={this.state.excludedCountries}
                  handleExcludedCountryRemoveClick={
                    this.handleExcludedCountryRemoveClick
                  }
                  setCountryToExclude={this.setCountryToExclude}
                  addStockExchangeEmail={this.addStockExchangeEmail}
                  emails={this.state.formData.stockExchangeEmails}
                  removeStockExchangeEmail={this.removeStockExchangeEmail}
                  handleNotifyRadioChange={this.handleNotifyRadioChange}
                  notifyRadioValue={this.state.formData.notifyStockNow}
                  notifyTime={this.state.notifyTime}
                  notifyDate={this.state.notifyDate}
                  handleNotifyDataChange={this.handleNotifyDataChange}
                  handleInitFilesDelete={this.initFilesDelete}
                  isPublished={this.state.isPublished}
                  stockInformedInPast={this.state.formData.stockInformedInPast}
                  isEditMode={this.state.isEditMode}
                  isBusiness={this.state.formData.isBusiness}
                  isInternal={this.state.formData.isInternal}
                  handlePublicityRadioChange={this.handlePublicityRadioChange}
                  userData={this.props.userData}
                  companyId={this.props.company.id}
                  isLocal={this.state.formData.isLocal}
                  handleNotificationRangeRadioChange={
                    this.handleNotificationRangeRadioChange
                  }
                  publishAt={this.state.formData.publishAt}
                  receivers={this.state.formData.receivers}
                  handleNotificationReceiverCheckboxClick={
                    this.handleNotificationReceiverCheckboxClick
                  }
                  handleRemindDataChange={this.handleRemindDataChange}
                  remindDate={this.state.remindDate}
                  remindTime={this.state.remindTime}
                  handleRemindSwitch={this.handleRemindSwitch}
                  remindError={this.state.remindError}
                  isRemindDisabled={this.isRemindDisabled}
                />

                <div className="buttons__container">
                  <div className="draft__buttons">
                    <div
                      onClick={() => {
                        this.isClickedDraft = true;
                        this.handleSubmit(values, 'preview');
                      }}
                      role="presentation"
                      className="draft__preview"
                    >
                      <div className="preview__icon" />
                      <div className="preview__text">Preview</div>
                    </div>

                    <div
                      role="presentation"
                      className="draft__save"
                      onClick={() => {
                        this.isClickedDraft = true;
                        this.handleSubmit(values, 'draft');
                      }}
                    >
                      Save as draft
                    </div>
                  </div>

                  <div className="add-news-form__buttons">
                    <Button
                      onClick={this.handleCancelButton}
                      outline
                      color="primary  mr-4"
                    >
                      CANCEL
                    </Button>

                    <Button
                      color="primary"
                      type="submit"
                      onClick={() => {
                        this.isClicked = true;
                      }}
                    >
                      Publish
                    </Button>
                    {Object.keys(this.state.apiMessage).map((element) =>
                      this.state.apiMessage[element].map((error) => (
                        <span
                          key={shortid.generate()}
                          className="add-news-form__api-errors"
                        >
                          {error}
                        </span>
                      )),
                    )}
                    {(this.state.notifyError || this.state.publishError) && (
                      <p className="add-news-form__date-error">
                        {this.state.notifyError}
                        {this.state.publishError}
                      </p>
                    )}
                  </div>
                </div>
              </form>
            )}
          />
        )}
      </div>
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AddNewsForm));
