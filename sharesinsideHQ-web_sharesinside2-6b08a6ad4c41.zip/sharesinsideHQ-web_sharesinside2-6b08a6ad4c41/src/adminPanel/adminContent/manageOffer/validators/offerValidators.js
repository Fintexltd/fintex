import * as Yup from 'yup';

const offerSchema = Yup.object().shape({
  title: Yup.string()
    .max(64, "Offer title shouldn't be longer than 64 characters.")
    .required('This field is required.'),
  description: Yup.string()
    .max(512, "Offer description shouldn't be longer than 512 characters.")
    .required('This field is required.'),
  address: Yup.string()
    .max(64, "Address shouldn't be longer than 64 characters.")
    .required('This field is required.'),
  country_id: Yup.number().required('This field is required.'),
});

export default offerSchema;
