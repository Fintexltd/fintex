import * as Yup from 'yup';

const responsibilitySchema = Yup.object().shape({
  description: Yup.string()
    .max(128, "Responsibility shouldn't be longer than 128 characters.")
    .required('This field is required.'),
});

export default responsibilitySchema;
