import * as Yup from 'yup';

const singleOfferSchema = Yup.object().shape({
  description: Yup.string()
    .max(64, "Offer shouldn't be longer than 64 characters.")
    .required('This field is required.'),
});

export default singleOfferSchema;
