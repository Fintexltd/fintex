import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Form, FormGroup, Button, Row, Col } from 'reactstrap';
import { Formik } from 'formik';
import shortid from 'shortid';
import classNames from 'classnames';
import Input from 'common/components/input';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import SingleSelect from 'common/components/customSelect/singleSelect';
import offerValidationSchema from 'adminPanel/adminContent/manageOffer/validators/offerValidators';
import './index.scss';

class ManageOfferView extends Component {
  state = {
    isSubmitClicked: false,
  };

  render() {
    const {
      countriesList,
      isEditView,
      offerData,
      submitOfferForm,
      addNewResponsibility,
      setResponsibilityToEdit,
      removeResponsibility,
      addNewOffer,
      setOfferToEdit,
      removeOffer,
    } = this.props;
    const { isSubmitClicked } = this.state;
    return (
      <div className="manage-offer">
        <h1 className="manage-offer__heading">
          {isEditView ? 'Edit job offer' : 'Add new job offer'}
        </h1>
        <Formik
          initialValues={offerData}
          onSubmit={(values, { setErrors, setSubmitting }) =>
            submitOfferForm(values, { setErrors, setSubmitting })
          }
          validationSchema={offerValidationSchema}
          render={({
            values,
            errors,
            touched,
            handleChange,
            handleBlur,
            handleSubmit,
            setFieldTouched,
            setFieldValue,
          }) => (
            <Form onSubmit={handleSubmit} noValidate>
              <Row>
                <Col>
                  <FormGroup>
                    <Input
                      type="text"
                      value={values.title}
                      error={errors.title}
                      touched={touched.title}
                      name="title"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Add title*"
                    />
                    <span className="manage-offer__character-counter">
                      {`${
                        values.title ? values.title.trimStart().length : 0
                      }/64`}
                    </span>
                  </FormGroup>
                  <FormGroup>
                    <Input
                      type="textarea"
                      value={values.description}
                      error={errors.description}
                      touched={touched.description}
                      name="description"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Add description*"
                    />
                    <span className="manage-offer__character-counter">
                      {`${
                        values.description
                          ? values.description.trimStart().length
                          : 0
                      }/512`}
                    </span>
                  </FormGroup>
                  <FormGroup>
                    <Input
                      type="text"
                      value={values.address}
                      error={errors.address}
                      touched={touched.address}
                      name="address"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Add address*"
                    />
                    <span className="manage-offer__character-counter">
                      {`${
                        values.address ? values.address.trimStart().length : 0
                      }/64`}
                    </span>
                  </FormGroup>
                  <FormGroup>
                    <div
                      className={classNames({
                        'manage-offer__country-container--error':
                          errors.country_id && isSubmitClicked,
                      })}
                    >
                      <SingleSelect
                        description="Country*"
                        onChange={value => {
                          setFieldTouched('country_id', true);
                          setFieldValue('country_id', value[0].value);
                        }}
                        options={mapObjPropsToSelectFilter({
                          list: countriesList
                            ? countriesList.map(
                                ({ country_name: countryName, id }) => ({
                                  value: id,
                                  label: countryName,
                                }),
                              )
                            : [],
                          label: 'label',
                          value: 'value',
                          category: 'country',
                        })}
                        value={[
                          {
                            category: 'country',
                            label: countriesList.filter(
                              element => element.id === values.country_id,
                            )[0]
                              ? countriesList.filter(
                                  element => element.id === values.country_id,
                                )[0].country_name
                              : '',
                            value: values.country_id,
                          },
                        ]}
                        category="country"
                      />
                      {isSubmitClicked &&
                        errors.country_id && (
                          <span className="manage-offer__country-error">
                            {errors.country_id}
                          </span>
                        )}
                    </div>
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col>
                  <p className="manage-offer__section-title">
                    Your responsibilities
                  </p>
                </Col>
              </Row>
              <Row>
                <Col>
                  {offerData.responsibilities.map((item, index) => (
                    <div
                      className="manage-offer__responsibility"
                      key={shortid.generate()}
                    >
                      <p className="manage-offer__responsibility-text">
                        {item}
                      </p>
                      <div>
                        <div
                          className="manage-offer__edit-button"
                          onClick={() => setResponsibilityToEdit(item, index)}
                          onKeyPress={() =>
                            setResponsibilityToEdit(item, index)
                          }
                          role="button"
                          tabIndex="0"
                        >
                          Edit
                        </div>
                        <div
                          className="manage-offer__remove-button"
                          onClick={() => removeResponsibility(item, index)}
                          onKeyPress={() => removeResponsibility(item, index)}
                          role="button"
                          tabIndex="0"
                        >
                          Remove
                        </div>
                      </div>
                    </div>
                  ))}
                  <div
                    className="manage-offer__add-button"
                    onClick={addNewResponsibility}
                    onKeyPress={addNewResponsibility}
                    role="button"
                    tabIndex="0"
                  >
                    Add new responsibility
                    {isSubmitClicked &&
                      offerData.responsibilities.length === 0 && (
                        <p className="manage-offer__list-error">
                          At least one responsibility is required.
                        </p>
                      )}
                  </div>
                </Col>
              </Row>
              <Row>
                <Col>
                  <p className="manage-offer__section-title">What we offer</p>
                </Col>
              </Row>
              <Row>
                <Col>
                  {offerData.offers.map((item, index) => (
                    <div
                      className="manage-offer__offer"
                      key={shortid.generate()}
                    >
                      <p className="manage-offer__offer-text">{item}</p>
                      <div>
                        <div
                          className="manage-offer__edit-button"
                          onClick={() => setOfferToEdit(item, index)}
                          onKeyPress={() => setOfferToEdit(item, index)}
                          role="button"
                          tabIndex="0"
                        >
                          Edit
                        </div>
                        <div
                          className="manage-offer__remove-button"
                          onClick={() => removeOffer(item, index)}
                          onKeyPress={() => removeOffer(item, index)}
                          role="button"
                          tabIndex="0"
                        >
                          Remove
                        </div>
                      </div>
                    </div>
                  ))}
                  <div
                    className="manage-offer__add-button"
                    onClick={addNewOffer}
                    onKeyPress={addNewOffer}
                    role="button"
                    tabIndex="0"
                  >
                    Add new offer
                    {isSubmitClicked &&
                      offerData.offers.length === 0 && (
                        <p className="manage-offer__list-error">
                          At least one offer is required.
                        </p>
                      )}
                  </div>
                </Col>
              </Row>
              <div className="manage-offer__save-container">
                <Button
                  type="submit"
                  color="primary"
                  onClick={() => {
                    this.setState({ isSubmitClicked: true });
                  }}
                >
                  Save
                </Button>
              </div>
            </Form>
          )}
        />
      </div>
    );
  }
}

ManageOfferView.defaultProps = {
  countriesList: [],
  isEditView: false,
};

ManageOfferView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  isEditView: PropTypes.bool,
  offerData: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  submitOfferForm: PropTypes.func.isRequired,
  addNewResponsibility: PropTypes.func.isRequired,
  setResponsibilityToEdit: PropTypes.func.isRequired,
  removeResponsibility: PropTypes.func.isRequired,
  addNewOffer: PropTypes.func.isRequired,
  setOfferToEdit: PropTypes.func.isRequired,
  removeOffer: PropTypes.func.isRequired,
};

export default ManageOfferView;
