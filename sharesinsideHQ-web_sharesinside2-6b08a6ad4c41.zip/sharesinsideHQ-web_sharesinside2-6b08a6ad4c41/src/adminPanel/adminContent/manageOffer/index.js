import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import FormModal from 'common/components/modals/form';
import ManageOfferView from 'adminPanel/adminContent/manageOffer/components/manageOfferView';
import CircleSpinner from 'common/components/circleSpinner';
import fetchCountriesList from 'common/redux/actions/countriesListActions.js';
import responsibilityValidationSchema from 'adminPanel/adminContent/manageOffer/validators/responsibilityValidators';
import offerValidationSchema from 'adminPanel/adminContent/manageOffer/validators/singleOfferValidators';
import { disableScroll } from 'common/utils/disableScroll';
import { fetchSingleOffer } from 'common/redux/actions/offersActions.js';
import { removeOffersFilters } from 'common/redux/actions/offersFiltersActions';
import { addJobOffer, editJobOffer } from 'adminPanel/api/offersApi';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
  countriesList: state.countries.list,
  offers: state.offers,
});

const mapDispatchToProps = (dispatch) => ({
  fetchCountriesList: () => dispatch(fetchCountriesList()),
  fetchSingleOffer: (id) => dispatch(fetchSingleOffer(id)),
  removeOffersFilters: () => dispatch(removeOffersFilters()),
});

class ManageOffer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isResponsibilityModalVisible: false,
      isOfferModalVisible: false,
    };
  }

  UNSAFE_componentWillMount() {
    const data = {
      title: '',
      description: '',
      address: '',
      responsibilities: [],
      offers: [],
    };
    this.setState({ offerData: data });
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      this.props.userData &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push('/');
    }

    if (!this.props.countriesList) {
      this.props.fetchCountriesList();
    }

    if (this.props.match.params.id) {
      this.props.fetchSingleOffer(this.props.match.params.id).then(() => {
        const { offer } = this.props.offers;
        this.setState({
          offerData: {
            title: offer.title,
            description: offer.description,
            address: offer.address,
            responsibilities: offer.responsibilities,
            offers: offer.offers,
            country_id: offer.country.id,
          },
        });
      });
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push('/');
    }
  }

  componentWillUnmount() {
    this.props.removeOffersFilters();
  }

  setOfferToEdit = (item, index) => {
    this.toggleOfferModal();
    this.setState({
      offerValues: {
        description: item,
        index,
        new: false,
      },
    });
  };

  setResponsibilityToEdit = (item, index) => {
    this.toggleResponsibilityModal();
    this.setState({
      responsibilityValues: {
        description: item,
        index,
        new: false,
      },
    });
  };

  submitOfferForm = (values) => {
    if (
      this.state.offerData.responsibilities.length > 0 &&
      this.state.offerData.offers.length > 0
    ) {
      const data = {
        title: values.title,
        description: values.description,
        address: values.address,
        country_id: values.country_id,
        offers: this.state.offerData.offers,
        responsibilities: this.state.offerData.responsibilities,
      };

      if (this.props.match.params.id) {
        editJobOffer(this.props.match.params.id, data).then(() => {
          this.props.history.push('/admin/management/offers');
        });
      } else {
        addJobOffer(data).then(() => {
          this.props.history.push('/admin/management/offers');
        });
      }
    }
  };

  addNewResponsibility = () => {
    this.toggleResponsibilityModal();
    this.setState({
      responsibilityValues: {
        description: '',
        new: true,
      },
    });
  };

  removeResponsibility = (item, index) => {
    const newResponsibilities = [...this.state.offerData.responsibilities];
    newResponsibilities.splice(index, 1);
    this.setState((prevState) => ({
      offerData: {
        ...prevState.offerData,
        responsibilities: newResponsibilities,
      },
    }));
  };

  addNewOffer = () => {
    this.toggleOfferModal();
    this.setState({
      offerValues: {
        description: '',
        new: true,
      },
    });
  };

  removeOffer = (item, index) => {
    this.setState((prevState) => {
      const newOffers = [...prevState.offerData.offers];
      newOffers.splice(index, 1);
      return {
        offerData: {
          ...prevState.offerData,
          offers: newOffers,
        },
      };
    });
  };

  submitOffer = (value) => {
    if (!value.new) {
      this.setState((prevState) => {
        const newOffers = [...prevState.offerData.offers];
        newOffers[value.index] = value.description;
        return {
          offerData: {
            ...prevState.offerData,
            offers: newOffers,
          },
        };
      });
      this.toggleOfferModal();
    } else {
      this.setState((prevState) => ({
        offerData: {
          ...prevState.offerData,
          offers: [...prevState.offerData.offers, value.description],
        },
      }));
      this.toggleOfferModal();
    }
  };

  submitResponsibility = (value) => {
    if (!value.new) {
      this.setState((prevState) => {
        const newResponsibilities = [...prevState.offerData.responsibilities];
        newResponsibilities[value.index] = value.description;
        return {
          offerData: {
            ...prevState.offerData,
            responsibilities: newResponsibilities,
          },
        };
      });
      this.toggleResponsibilityModal();
    } else {
      this.setState((prevState) => ({
        offerData: {
          ...prevState.offerData,
          responsibilities: [
            ...prevState.offerData.responsibilities,
            value.description,
          ],
        },
      }));
      this.toggleResponsibilityModal();
    }
  };

  toggleResponsibilityModal = () => {
    this.setState(
      (prevState) => ({
        isResponsibilityModalVisible: !prevState.isResponsibilityModalVisible,
      }),
      () => disableScroll(this.state.isResponsibilityModalVisible),
    );
  };

  toggleOfferModal = () => {
    this.setState(
      (prevState) => ({
        isOfferModalVisible: !prevState.isOfferModalVisible,
      }),
      () => disableScroll(this.state.isOfferModalVisible),
    );
  };

  render() {
    const ResponsibilityModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="textarea"
            value={formProps.values.description}
            error={formProps.errors.description}
            touched={formProps.touched.description}
            name="description"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Responsibility"
          />
          <span className="manage-offer__character-counter">
            {`${
              formProps.values.description
                ? formProps.values.description.trimStart().length
                : 0
            }/128`}
          </span>
        </FormGroup>
      </>
    );

    const OfferModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="textarea"
            value={formProps.values.description}
            error={formProps.errors.description}
            touched={formProps.touched.description}
            name="description"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Offer"
          />
          <span className="manage-offer__character-counter">
            {`${
              formProps.values.description
                ? formProps.values.description.trimStart().length
                : 0
            }/64`}
          </span>
        </FormGroup>
      </>
    );

    return (
      <>
        {this.props.userData && this.props.userData.is_global_admin && (
          <div>
            {(!this.props.match.params.id ||
              (this.props.match.params.id && this.state.offerData.title)) && (
              <ManageOfferView
                offerData={this.state.offerData}
                submitOfferForm={this.submitOfferForm}
                isEditView={!!this.props.match.params.id}
                countriesList={this.props.countriesList}
                addNewResponsibility={this.addNewResponsibility}
                setResponsibilityToEdit={this.setResponsibilityToEdit}
                removeResponsibility={this.removeResponsibility}
                addNewOffer={this.addNewOffer}
                setOfferToEdit={this.setOfferToEdit}
                removeOffer={this.removeOffer}
              />
            )}
            {this.props.match.params.id && !this.state.offerData.title && (
              <div className="manage-offer__load-container">
                <CircleSpinner />
              </div>
            )}
          </div>
        )}
        <FormModal
          isModalVisible={this.state.isResponsibilityModalVisible}
          handleClose={this.toggleResponsibilityModal}
          header={
            this.state.responsibilityValues &&
            this.state.responsibilityValues.new
              ? 'Add new responsibility'
              : 'Edit responsibility'
          }
          onSubmit={this.submitResponsibility}
          initialValues={this.state.responsibilityValues}
          validationSchema={responsibilityValidationSchema}
          confimButtonText="Confirm"
        >
          <ResponsibilityModalFormView />
        </FormModal>
        <FormModal
          isModalVisible={this.state.isOfferModalVisible}
          handleClose={this.toggleOfferModal}
          header={
            this.state.offerValues && this.state.offerValues.new
              ? 'Add new offer'
              : 'Edit offer'
          }
          onSubmit={this.submitOffer}
          initialValues={this.state.offerValues}
          validationSchema={offerValidationSchema}
          confimButtonText="Confirm"
        >
          <OfferModalFormView />
        </FormModal>
      </>
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(ManageOffer));
