import React, { Component } from 'react';
import { Button } from 'reactstrap';
import { requestAttachmentToken } from 'common/api/filesApi';
import {
  addPhoto,
  editPhoto,
  removePhoto,
} from 'adminPanel/adminContent/gallery/api/galleryApi';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  fetchGallery,
  fetchAllPhotos,
} from 'common/redux/actions/galleryActions';
import GalleryAllPhotosView from 'adminPanel/adminContent/gallery/components/galleryAllPhotosView';
import PhotoModalView from 'common/components/gallery/photoModalView';
import CircleSpinner from 'common/components/circleSpinner';
import TextEditor from 'common/components/textEditor';
import closeIcon from 'assets/icons/close.svg';
import Select from 'common/components/select';
import shortid from 'shortid';
import placeholder from 'assets/img/placeholder.png';
import { disableScroll } from 'common/utils/disableScroll';

const mapDispatchToProps = (dispatch) => ({
  getGallery: bindActionCreators(fetchGallery, dispatch),
  getAllPhotos: bindActionCreators(fetchAllPhotos, dispatch),
});

class GalleryAllPhotos extends Component {
  constructor(props) {
    super(props);
    this.state = {
      photosModalVisible: false,
      isEdit: false,
      previewId: null,
      editId: null,
      isPhotoViewModalVisible: false,
      values: {
        description: '',
        image: '',
        file: '',
        pureText: '',
        album: '',
      },
      errors: {
        description: '',
        file: '',
      },
      touched: {
        description: false,
        file: false,
      },
      images: [],
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.editPhotoModal) {
      this.setState(
        (prevState) => ({
          values: {
            ...prevState.values,
            album: nextProps.albumId,
          },
        }),
        () => this.editPhoto(nextProps.photoId),
      );
    } else if (nextProps.uploadPhotoModal) {
      this.setState(
        (prevState) => ({
          values: {
            ...prevState.values,
            album: nextProps.albumId,
          },
        }),
        () => this.handleOpenPhotoModal(),
      );
    }
  }

  setFieldValue = (element, value, pureText) => {
    this.setState(
      (prevState) => ({
        values: {
          ...prevState.values,
          description: value || '',
          pureText: pureText || '',
        },
      }),
      () => {
        this.checkErrors();
      },
    );
  };

  setFieldTouched = () => {
    this.setState((prevState) => ({
      touched: {
        ...prevState.touched,
        description: true,
      },
    }));
  };

  clearState = () => {
    this.setState(
      {
        photosModalVisible: false,
        isEdit: false,
        previewId: null,
        editId: null,
        isPhotoViewModalVisible: false,
        values: {
          description: '',
          image: '',
          file: '',
          pureText: '',
          album: '',
        },
        errors: {
          description: '',
          file: '',
        },
        touched: {
          description: false,
          file: false,
        },
        images: [],
      },
      () => disableScroll(this.state.photosModalVisible),
    );

    if (this.props.editId !== null) this.props.editPhoto();

    if (this.props.uploadPhotoModal) this.props.uploadPhoto();
  };

  handleOpenPhotoModal = () => {
    this.setState(
      {
        photosModalVisible: true,
      },
      () => disableScroll(this.state.photosModalVisible),
    );
  };

  handleClose = () => {
    this.clearState();
  };

  handlePhotoAction = () => {
    this.setState(
      {
        touched: {
          description: true,
          file: true,
        },
      },
      () => {
        if (this.checkErrors()) {
          if (this.state.isEdit) {
            editPhoto(
              this.state.editId,
              this.state.values.description,
              this.state.values.album,
              this.state.values.file,
            ).then((response) => {
              if (response.status === 200) {
                this.props.getGallery(this.props.companyId);
                this.props.getAllPhotos(this.props.companyId);
                this.clearState();
              }
            });
          } else {
            addPhoto(
              this.props.companyId,
              this.state.values.album === 'null'
                ? null
                : this.state.values.album,
              this.state.values.description,
              this.state.values.file,
            ).then((response) => {
              if (response.status === 200) {
                this.props.getGallery(this.props.companyId);
                this.props.getAllPhotos(this.props.companyId);
                this.clearState();
              }
            });
          }
        }
      },
    );
  };

  editPhoto = (ids) => {
    if (typeof ids === 'object') {
      const { id, galleryId } = ids;
      const editedAlbum = this.props.gallery.filter(
        (element) => element.id === galleryId,
      );
      this.setState(
        (prevState) => ({
          values: {
            ...prevState.values,
            description: editedAlbum[0].items.filter(
              (element) => element.id === id,
            )[0].description,
            album: editedAlbum[0].items.filter(
              (element) => element.id === id,
            )[0].section_id,
          },
          errors: {
            description: '',
            album: '',
            file: '',
          },
          touched: {
            description: false,
            album: false,
            file: false,
          },
          isEdit: true,
          editId: id,
          isLoadingFile: false,
          photosModalVisible: true,
          images: [
            editedAlbum[0].items.filter((element) => element.id === id)[0].url,
          ],
        }),
        () => disableScroll(this.state.photosModalVisible),
      );
    } else if (typeof ids === 'number') {
      const id = ids;
      this.setState(
        (prevState) => ({
          values: {
            ...prevState.values,
            description: this.props.photos.filter(
              (element) => element.id === id,
            )[0].description,
            album: this.props.photos.filter((element) => element.id === id)[0]
              .section_id,
          },
          errors: {
            description: '',
            album: '',
            file: '',
          },
          touched: {
            description: false,
            album: false,
            file: false,
          },
          isEdit: true,
          editId: id,
          isLoadingFile: false,
          photosModalVisible: true,
          images: [
            this.props.photos.filter((element) => element.id === id)[0].url,
          ],
        }),
        () => disableScroll(this.state.photosModalVisible),
      );
    }
  };

  removePhoto = (id) => {
    removePhoto(id).then((response) => {
      if (response.status === 200) {
        this.props.getGallery(this.props.companyId);
        this.props.getAllPhotos(this.props.companyId);
        this.clearState();
      }
    });
  };

  uploadAttachements = (e) => {
    this.setState(
      (prevState) => ({
        touched: {
          ...prevState.touched,
          file: true,
        },
      }),
      () => this.checkErrors(),
    );

    if (e.target.files[0]) {
      e.preventDefault();

      this.setState((prevState) => ({
        isLoadingFile: true,
        errors: { ...prevState.errors, file: '' },
        touched: { ...prevState.touched, file: true },
      }));

      const reader = new FileReader();
      const file = e.target.files[0];

      reader.onloadend = (event) => {
        const fileAsForm = new FormData();
        fileAsForm.append('file', file);

        requestAttachmentToken(fileAsForm, 'type_image')
          .then((res) => {
            this.setState({});
            this.setState((prevState) => ({
              values: {
                ...prevState.values,
                file: res.data.token,
                image: file.name,
              },
              images: [event.srcElement.result],
              errors: { ...prevState.errors, file: '' },
              touched: { ...prevState.touched, file: true },
              isLoadingFile: false,
            }));
          })
          .catch(() => {
            this.setState((prevState) => ({
              errors: {
                ...prevState.errors,
                file: 'Executable files are not allowed',
              },
              touched: { ...prevState.touched, file: true },
              isLoadingFile: false,
            }));
          });
      };

      reader.readAsDataURL(file);
    }
  };

  checkErrors = () => {
    const { touched, values, isEdit } = this.state;

    let fileError = '';
    let descriptionError = '';

    if (!isEdit && touched.file && values.image === '')
      fileError = 'This field is required!';

    if (touched.description && values.pureText.trimStart().length > 512)
      descriptionError = 'Description must be at most 512 characters';

    this.setState({
      errors: {
        file: fileError,
        description: descriptionError,
      },
    });

    if (fileError === '' && descriptionError === '') return true;

    return false;
  };

  openPhoto = (id) => {
    this.setState(
      {
        previewId: id,
        isPhotoViewModalVisible: true,
      },
      () => disableScroll(this.state.isPhotoViewModalVisible),
    );
  };

  handleChangeSelect = (event) => {
    const album = event.target.value;
    if (album !== '') {
      this.setState((prevState) => ({
        values: {
          ...prevState.values,
          album,
        },
      }));
    }
  };

  changePhoto = (index) => {
    let clickedIndex = 0;
    this.props.photos.forEach((element, key) => {
      if (element.id === this.state.previewId) clickedIndex = key;
    });
    clickedIndex += index;
    if (clickedIndex >= this.props.photos.length) clickedIndex = 0;
    if (clickedIndex < 0) clickedIndex = this.props.photos.length - 1;

    this.setState({
      previewId: this.props.photos[clickedIndex].id,
    });
  };

  loadMorePhotos = () => {
    this.props.getAllPhotos(this.props.companyId, this.props.allPhotosNextPage);
  };

  render() {
    const {
      touched,
      errors,
      values,
      photosModalVisible,
      isEdit,
      isLoadingFile,
      isPhotoViewModalVisible,
      images,
      previewId,
    } = this.state;

    return (
      <>
        <GalleryAllPhotosView
          handleOpenPhotoModal={this.handleOpenPhotoModal}
          loadMorePhotos={this.loadMorePhotos}
          photos={this.props.photos}
          editPhoto={this.editPhoto}
          removePhoto={this.removePhoto}
          openPhoto={this.openPhoto}
          userData={this.props.userData}
          companyId={this.props.companyId}
          allPhotosNextPage={this.props.allPhotosNextPage}
        />
        {photosModalVisible && (
          <div
            className="addPhoto__form-wraper"
            role="presentation"
            onClick={this.handleClose}
          >
            <div
              className="form__container"
              role="presentation"
              onClick={(e) => {
                e.stopPropagation();
              }}
            >
              <header className="form__header">
                <h2>
                  {isEdit ? 'Edit' : 'Add new'}
                  {' '}
                  photo
                </h2>
                <button className="close-button" onClick={this.handleClose}>
                  <img src={closeIcon} alt="close add description" />
                </button>
              </header>
              {isLoadingFile ? (
                <div className="loading__container">
                  <CircleSpinner />
                </div>
              ) : (
                <label htmlFor="photoInput" className="custom-file-upload">
                  {images.length === 0 ? (
                    <div className="link__container">
                      <div className="link__icon" />
                      <div className="link__text">
                        <p>Upload Photo</p>
                      </div>
                    </div>
                  ) : (
                    <div className="preview__container">
                      {images.map((image) => (
                        <div
                          key={shortid.generate()}
                          className="preview__item"
                          style={{
                            background: `url(${image || placeholder})`,
                            backgroundSize: 'contain',
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'center',
                            width: '100%',
                            height: '180px',
                          }}
                        />
                      ))}
                    </div>
                  )}
                  <input
                    id="photoInput"
                    name="file"
                    type="file"
                    className="attachements__input-hidden"
                    accept=".jpeg, .jpg, .png, .gif"
                    onChange={this.uploadAttachements}
                  />
                  {errors.file && (
                    <p className="input-error-message">{errors.file}</p>
                  )}
                </label>
              )}
              <div className="selectAlbum__label">Album: </div>
              <Select
                name="album"
                value={values.album}
                error={errors.album}
                touched={touched.album}
                onChange={this.handleChangeSelect}
                onBlur={(e) => {
                  this.handleChangeSelect(e);
                }}
              >
                <>
                  <option key={shortid.generate()} value="null">
                    All photos
                  </option>
                  {this.props.gallery.map((gallery) => (
                    <option key={shortid.generate()} value={gallery.id}>
                      {gallery.name}
                    </option>
                  ))}
                </>
              </Select>
              <TextEditor
                className="description__text-editor"
                name="description"
                placeholder="Description"
                values={values}
                defaultValue={values.description}
                errors={errors}
                touched={touched}
                setFieldValue={this.setFieldValue}
                setFieldTouched={this.setFieldTouched}
                characterLimit="512"
              />
              <div className="buttons">
                <Button
                  outline
                  tabIndex={-1}
                  color="primary"
                  onClick={this.handleClose}
                >
                  Cancel
                </Button>
                <Button
                  color="primary"
                  tabIndex={0}
                  onClick={this.handlePhotoAction}
                >
                  {isEdit ? 'Save' : 'Add'}
                </Button>
              </div>
            </div>
          </div>
        )}
        {isPhotoViewModalVisible && (
          <PhotoModalView
            photo={
              this.props.photos.filter((photo) => photo.id === previewId)[0]
            }
            size={this.props.photos.length}
            changePhoto={this.changePhoto}
            handleClose={this.handleClose}
          />
        )}
      </>
    );
  }
}

export default connect(null, mapDispatchToProps)(GalleryAllPhotos);
