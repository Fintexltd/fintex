import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  fetchGallery,
  fetchAllPhotos,
} from 'common/redux/actions/galleryActions';
import {
  addAlbum,
  editAlbum,
  removeAlbum,
  removePhoto,
  removePhotos,
} from 'adminPanel/adminContent/gallery/api/galleryApi';
import Input from 'common/components/input';
import { validationSchemaAlbum } from 'adminPanel/adminContent/gallery/validators/validationSchema';
import GalleryAlbumsView from 'adminPanel/adminContent/gallery/components/galleryAlbumsView';
import AlbumModalView from 'common/components/gallery/albumModalView';
import FormModal from 'common/components/modals/form';
import { disableScroll } from 'common/utils/disableScroll';

const mapDispatchToProps = dispatch => ({
  getGallery: bindActionCreators(fetchGallery, dispatch),
  getAllPhotos: bindActionCreators(fetchAllPhotos, dispatch),
});

class GalleryAlbums extends Component {
  constructor(props) {
    super(props);
    this.state = {
      albumModalVisible: false,
      isAlbumViewModalVisible: false,
      previewId: null,
      isEdit: false,
      checkedArray: [],
      values: {
        name: '',
      },
    };
  }

  clearState = () => {
    this.setState({
      albumModalVisible: false,
      isAlbumViewModalVisible: false,
      previewId: null,
      checkedArray: [],
      isEdit: false,
      values: {
        name: '',
      },
    });
  };

  handleOpenAlbumModal = () => {
    this.setState({
      albumModalVisible: true,
    });
  };

  handleClose = () => {
    this.clearState();
  };

  handleAlbumAction = values => {
    if (this.state.isEdit) {
      editAlbum(this.state.editId, values.name).then(response => {
        if (response.status === 200) {
          this.props.getGallery(this.props.companyId);
          this.props.getAllPhotos(this.props.companyId);
          this.clearState();
        }
      });
    } else {
      addAlbum(this.props.companyId, values.name).then(response => {
        if (response.status === 200) {
          this.props.getGallery(this.props.companyId);
          this.props.getAllPhotos(this.props.companyId);
          this.clearState();
        }
      });
    }
  };

  editAlbum = id => {
    this.setState({
      values: {
        name: this.props.gallery.filter(element => element.id === id)[0].name,
      },
      isEdit: true,
      editId: id,
      albumModalVisible: true,
    });
  };

  removeAlbum = id => {
    removeAlbum(id).then(response => {
      if (response.status === 200) {
        this.props.getGallery(this.props.companyId);
        this.props.getAllPhotos(this.props.companyId);
        this.clearState();
      }
    });
  };

  openAlbum = id => {
    this.setState(
      {
        previewId: id,
        isAlbumViewModalVisible: true,
      },
      () => disableScroll(this.state.isAlbumViewModalVisible),
    );
  };

  checkPhoto = id => {
    if (this.state.checkedArray.indexOf(id) === -1) {
      this.setState(prevState => ({
        checkedArray: [...prevState.checkedArray, id],
      }));
    } else {
      this.setState(prevState => ({
        checkedArray: [
          ...prevState.checkedArray.filter(element => element !== id),
        ],
      }));
    }
  };

  removePhoto = id => {
    removePhoto(id).then(response => {
      if (response.status === 200) {
        this.props.getGallery(this.props.companyId);
        this.props.getAllPhotos(this.props.companyId);
        this.setState(prevState => ({
          checkedArray: [
            ...prevState.checkedArray.filter(element => element !== id),
          ],
        }));
      }
    });
  };

  removeMassPhotos = () => {
    removePhotos(this.state.previewId, {
      delete_ids: this.state.checkedArray,
    }).then(response => {
      if (response.status === 200) {
        this.props.getGallery(this.props.companyId);
        this.props.getAllPhotos(this.props.companyId);
        this.setState({
          checkedArray: [],
        });
      }
    });
  };

  render() {
    const ModalFormView = ({ formProps }) => (
      <Fragment>
        <Input
          name="name"
          type="text"
          placeholder="Album name"
          error={formProps.errors.name}
          value={formProps.values.name}
          touched={formProps.touched.name}
          onBlur={formProps.handleBlur}
          onChange={formProps.handleChange}
          autoFocus
        />{' '}
        <span className="letter-counter">
          {`${formProps.values.name.trimStart().length}/64`}
        </span>
      </Fragment>
    );

    return (
      <Fragment>
        <GalleryAlbumsView
          handleOpenAlbumModal={this.handleOpenAlbumModal}
          gallery={this.props.gallery}
          editAlbum={this.editAlbum}
          removeAlbum={this.removeAlbum}
          openAlbum={this.openAlbum}
          userData={this.props.userData}
          companyId={this.props.companyId}
        />
        <FormModal
          isModalVisible={this.state.albumModalVisible}
          handleClose={this.handleClose}
          header={`${this.state.isEdit ? 'Edit' : 'Add new'} album`}
          validationSchema={validationSchemaAlbum}
          onSubmit={this.handleAlbumAction}
          initialValues={this.state.values}
          confimButtonText={this.state.isEdit ? 'Save' : 'Add'}
        >
          <ModalFormView />
        </FormModal>

        {this.state.isAlbumViewModalVisible && (
          <AlbumModalView
            gallery={
              this.props.gallery.filter(
                element => element.id === this.state.previewId,
              )[0]
            }
            handleClose={this.handleClose}
            removePhoto={this.removePhoto}
            checkPhoto={this.checkPhoto}
            checkedArray={this.state.checkedArray}
            removeMassPhotos={this.removeMassPhotos}
            uploadPhoto={galleryId => {
              this.props.uploadPhoto(galleryId);
            }}
            editPhoto={(photoId, galleryId) => {
              this.props.editPhoto(photoId, galleryId);
            }}
          />
        )}
      </Fragment>
    );
  }
}

export default connect(
  null,
  mapDispatchToProps,
)(GalleryAlbums);
