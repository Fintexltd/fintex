import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  fetchGallery,
  fetchAllPhotos,
} from 'common/redux/actions/galleryActions';
import GalleryAlbums from 'adminPanel/adminContent/gallery/containers/galleryAlbums';
import GalleryAllPhotos from 'adminPanel/adminContent/gallery/containers/galleryAllPhotos';

const mapStateToProps = (state) => ({
  gallery: state.gallery.data,
  allPhotos: state.allPhotos.data,
  allPhotosNextPage: state.allPhotos.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getGallery: bindActionCreators(fetchGallery, dispatch),
  getAllPhotos: bindActionCreators(fetchAllPhotos, dispatch),
});

class Gallery extends Component {
  constructor() {
    super();
    this.state = {
      photoId: null,
      albumId: null,
      editPhotoModal: false,
      uploadPhotoModal: false,
    };
  }

  componentDidMount() {
    const companyId = Number(this.props.match.params.id);
    if (
      !(
        this.props.userData.relations.secondary_admin &&
        this.props.userData.relations.secondary_admin.includes(companyId)
      ) &&
      !(
        this.props.userData.relations.primary_admin &&
        this.props.userData.relations.primary_admin.includes(companyId)
      ) &&
      !(
        this.props.userData.relations.domestic_admin &&
        this.props.userData.relations.domestic_admin.includes(companyId)
      ) &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push(`/admin/company/manage/${companyId}/about`);
    }
    if (this.props.companyId) {
      this.props.getGallery(this.props.companyId);
      this.props.getAllPhotos(this.props.companyId);
    } else if (this.props.match.params.id) {
      this.props.getGallery(this.props.match.params.id);
      this.props.getAllPhotos(this.props.match.params.id);
    }
  }

  uploadPhoto = (albumId) => {
    this.setState({
      uploadPhotoModal: true,
      photoId: null,
      albumId,
    });
  };

  editPhoto = (photoId, albumId) => {
    this.setState({
      editPhotoModal: true,
      photoId,
      albumId,
    });
  };

  handleClose = () => {
    this.setState({
      uploadPhotoModal: false,
      editPhotoModal: false,
      albumId: null,
      photoId: null,
    });
  };

  render() {
    return (
      <>
        <GalleryAlbums
          gallery={this.props.gallery.filter((element) => element.name)}
          companyId={this.props.companyId || this.props.match.params.id}
          uploadPhoto={this.uploadPhoto}
          editPhoto={this.editPhoto}
          userData={this.props.userData}
        />
        <GalleryAllPhotos
          companyId={this.props.companyId || this.props.match.params.id}
          photos={this.props.allPhotos}
          gallery={this.props.gallery.filter((element) => element.name)}
          photoId={this.state.photoId}
          albumId={this.state.albumId}
          uploadPhotoModal={this.state.uploadPhotoModal}
          editPhotoModal={this.state.editPhotoModal}
          uploadPhoto={this.handleClose}
          editPhoto={this.handleClose}
          userData={this.props.userData}
          allPhotosNextPage={this.props.allPhotosNextPage}
        />
      </>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Gallery);
