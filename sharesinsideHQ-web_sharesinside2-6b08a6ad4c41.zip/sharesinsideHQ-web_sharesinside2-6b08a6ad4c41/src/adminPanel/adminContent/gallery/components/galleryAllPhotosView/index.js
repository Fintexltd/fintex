import React from 'react';
import { Row, Col } from 'reactstrap';
import AddNewButton from 'common/components/gallery/newButton';
import PhotoItem from 'common/components/gallery/photoItem';
import shortid from 'shortid';
import { isEditor } from 'userAuth/utils/permissions';
import './style.scss';

const GalleryAllPhotos = ({
  editPhoto,
  removePhoto,
  handleOpenPhotoModal,
  loadMorePhotos,
  allPhotosNextPage,
  userData,
  companyId,
  photos,
  openPhoto,
}) => (
  <div className="allPhotos__container">
    <div className="allPhotos__header">
      <h2 className="header__element">All Photos</h2>
    </div>

    <Row>
      {!isEditor(userData, companyId) && (
        <Col md={3}>
          <AddNewButton addNew={handleOpenPhotoModal} />
        </Col>
      )}
      {photos.map(photo => (
        <Col key={shortid.generate()} md={3}>
          <PhotoItem
            isAdminPanel
            photo={photo}
            editPhoto={editPhoto}
            removePhoto={removePhoto}
            openPhoto={openPhoto}
          />
        </Col>
      ))}
      {allPhotosNextPage ? (
        <div
          className="photos__seeMore"
          onClick={loadMorePhotos}
          role="presentation"
        >
          See More
        </div>
      ) : (
        ''
      )}
    </Row>
  </div>
);

export default GalleryAllPhotos;
