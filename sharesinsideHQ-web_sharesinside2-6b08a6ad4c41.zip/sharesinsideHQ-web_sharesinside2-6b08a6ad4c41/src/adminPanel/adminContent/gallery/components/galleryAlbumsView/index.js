import React, { Fragment } from 'react';
import { Row, Col } from 'reactstrap';
import AlbumItem from 'common/components/gallery/albumItem';
import AddNewButton from 'common/components/gallery/newButton';
import shortid from 'shortid';
import { isEditor } from 'userAuth/utils/permissions';
import './style.scss';

const GalleryAlbumsView = ({
  handleOpenAlbumModal,
  editAlbum,
  removeAlbum,
  gallery,
  openAlbum,
  userData,
  companyId,
}) => (
  <Fragment>
    {isEditor(userData, companyId)
      ? gallery.length > 0
      : true && (
      <div className="albums__container">
        <div className="albums__header">
          <h2 className="header__element">Albums</h2>
        </div>

        <Row>
          {!isEditor(userData, companyId) && (
          <Col md={3}>
            <AddNewButton addNew={handleOpenAlbumModal} />
          </Col>
              )}
          {gallery.map(element => (
            <Col md={3} key={shortid.generate()}>
              <AlbumItem
                id={element.id}
                removeAlbum={removeAlbum}
                editAlbum={editAlbum}
                name={element.name}
                size={element.items.length}
                placeholder={element.items[0]}
                openAlbum={openAlbum}
                isAdminPanel
              />
            </Col>
              ))}
        </Row>
      </div>
        )}
  </Fragment>
);

export default GalleryAlbumsView;
