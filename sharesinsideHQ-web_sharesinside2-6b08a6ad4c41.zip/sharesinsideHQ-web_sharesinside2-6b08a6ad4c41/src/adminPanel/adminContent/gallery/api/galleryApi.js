import axios from 'axios';

export const addAlbum = (id, name) =>
  axios({
    method: 'post',
    url: `${process.env.REACT_APP_API_URL}/galleries`,
    data: {
      entitiable_type: 'company',
      entitiable_id: id,
      name,
    },
  });

export const editAlbum = (id, name) =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/galleries/${id}`,
    data: {
      _method: 'put',
      name,
    },
  });

export const removeAlbum = (id) =>
  axios({
    method: 'delete',
    url: `${process.env.REACT_APP_API_URL}/galleries/${id}`,
  });

export const addPhoto = (companyId, sectionId, description, file) => {
  let data = {};
  if (sectionId) {
    data = {
      section_id: sectionId,
      description,
      file,
    };
  } else {
    data = {
      entitiable_type: 'company',
      entitiable_id: companyId,
      description,
      file,
    };
  }
  return axios({
    method: 'post',
    url: `${process.env.REACT_APP_API_URL}/galleries/item`,
    data,
  });
};

export const editPhoto = (id, description, album, file) => {
  let data = {};
  if (file !== '') {
    data = {
      _method: 'put',
      file,
      section_id: album,
      description,
    };
  } else {
    data = {
      _method: 'put',
      section_id: album,
      description,
    };
  }

  return axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/galleries/item/${id}`,
    data,
  });
};

export const removePhoto = (id) =>
  axios({
    method: 'delete',
    url: `${process.env.REACT_APP_API_URL}/galleries/item/${id}`,
  });

export const removePhotos = (id, data) =>
  axios({
    method: 'delete',
    url: `${process.env.REACT_APP_API_URL}/galleries/${id}/items`,
    data,
  });
