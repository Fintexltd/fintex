import * as yup from 'yup';

yup.addMethod(yup.string, 'minLength', function(min, msg) {
  return this.test({
    name: 'minLength',
    exclusive: true,
    message: msg || `Name must be at least ${min} characters`,
    test: value => !value || value.trimStart().length >= min,
  });
});

yup.addMethod(yup.string, 'maxLength', function(max, msg) {
  return this.test({
    name: 'maxLength',
    exclusive: true,
    message: msg || `Name must be at most ${max} characters`,
    test: value => !value || value.trimStart().length <= max,
  });
});

export const validationSchemaAlbum = yup.object().shape({
  name: yup
    .string()
    .minLength(1)
    .maxLength(64)
    .required('This field is required.'),
});
