import axios from 'axios';

export const editLanding = data =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/landing-page`,
    data,
  });
