import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { compact, isNil, omitBy } from 'lodash';
import AdminLandingView from 'adminPanel/adminContent/landing/components/adminLandingView';
import FormModal from 'common/components/modals/form';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import partnerValidationSchema from 'adminPanel/adminContent/landing/validators/partnerValidators';
import officeValidationSchema from 'adminPanel/adminContent/landing/validators/officeValidators';
import videoValidationSchema from 'adminPanel/adminContent/landing/validators/videoValidators';
import { requestAttachmentToken } from 'common/api/filesApi';
import fetchLandingData from 'common/redux/actions/landingActions';
import { editLanding } from 'adminPanel/adminContent/landing/api/landingApi';
import { disableScroll } from 'common/utils/disableScroll';

const mapStateToProps = (state) => ({
  landingData: state.landing.data,
  token: state.auth.token,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getLandingData: bindActionCreators(fetchLandingData, dispatch),
});

class AdminLanding extends Component {
  constructor(props) {
    super(props);
    this.state = {
      landingData: {},
      isOfficeModalVisible: false,
      isPartnerModalVisible: false,
      isVideoLinkModalVisible: false,
      soon: null,
      aboutImage: '',
      platformImage: '',
      aboutVideo: '',
      platformVideo: '',
      partnerValues: {
        partner: '',
        website: '',
      },
      isUpdating: false,
      officesError: '',
      partnersError: '',
      bannerImage: '',
      isSaved: false,
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push('/admin/company/management');
    }

    this.props.getLandingData().then(() => {
      const { benefitsList1, benefitsList2 } = this.props.landingData;

      this.setState({
        landingData: {
          ...this.props.landingData,
          benefitsList1Item1: benefitsList1[0],
          benefitsList1Item2: benefitsList1[1],
          benefitsList1Item3: benefitsList1[2],
          benefitsList1Item4: benefitsList1[3],
          benefitsList1Item5: benefitsList1[4],
          benefitsList2Item1: benefitsList2[0],
          benefitsList2Item2: benefitsList2[1],
          benefitsList2Item3: benefitsList2[2],
          benefitsList2Item4: benefitsList2[3],
          benefitsList2Item5: benefitsList2[4],
        },
      });
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push('/admin/company/management');
    }
  }

  setPartnerToEdit = (item, index) => {
    const { partner, website } = item;
    this.togglePartnerModal();
    this.setState({
      partnerValues: {
        partner,
        website,
        index,
      },
    });
  };

  setOfficeToEdit = (office, index) => {
    const { country, name, email, phone, address, soon } = office;
    this.toggleOfficeModal();
    this.setState({
      soon,
      values: {
        country,
        name,
        email,
        phone,
        address,
        index,
      },
    });
  };

  setImageToken = (imageFile, type) => {
    const imgAsForm = new FormData();
    imgAsForm.append('file', imageFile);
    requestAttachmentToken(imgAsForm, 'type_image')
      .catch((err) => {
        if (err.response.data) {
          this.setState({
            [`${type}ImageError`]: err.response.data.message,
          });
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState({
            [`${type}ImageToken`]: res.data.token,
          });
        }
      });
  };

  addPhoto = (e, type) => {
    let validSize = {
      width: 540,
      height: 200,
    };
    if (type === 'banner') {
      validSize = { width: 1110, height: 200 };
    } else {
      validSize = { width: 540, height: 200 };
    }
    const imageFile = e.target.files[0];
    const reader = new FileReader();
    const image = new Image();
    if (imageFile) {
      reader.readAsDataURL(imageFile);
      reader.addEventListener('load', () => {
        image.src = reader.result;
        image.addEventListener('load', () => {
          if (
            image.width >= validSize.width &&
            image.height >= validSize.height
          ) {
            this.setState({
              [`${type}Image`]: image.src,
              [`${type}Video`]: null,
              [`${type}ImageError`]: null,
            });
            this.setImageToken(imageFile, type);
          } else {
            this.setState({
              [`${type}ImageError`]: `Uploaded image should be at least ${validSize.width}px
              wide and ${validSize.height}px height.`,
            });
          }
        });
      });
    }
  };

  toggleOfficeModal = () => {
    this.setState(
      (prevState) => ({
        isOfficeModalVisible: !prevState.isOfficeModalVisible,
      }),
      () => disableScroll(this.state.isOfficeModalVisible),
    );
  };

  submitOffice = (value) => {
    if (!value.new) {
      this.setState((prevState) => {
        const newOffices = prevState.landingData.offices;
        newOffices[value.index] = {
          country: value.country,
          name: value.name,
          email: value.email,
          phone: value.phone,
          address: value.address,
          soon: prevState.soon,
        };
        return {
          landingData: {
            ...prevState.landingData,
            offices: newOffices,
          },
        };
      });
      this.toggleOfficeModal();
    } else {
      this.setState((prevState) => ({
        landingData: {
          ...prevState.landingData,
          offices: [
            ...prevState.landingData.offices,
            {
              country: value.country,
              name: value.name,
              email: value.email,
              phone: value.phone,
              address: value.address,
              soon: prevState.soon,
            },
          ],
        },
      }));
      this.toggleOfficeModal();
    }
  };

  addNewOffice = () => {
    this.toggleOfficeModal();
    this.setState({
      soon: false,
      values: {
        country: '',
        name: '',
        email: '',
        phone: '',
        address: '',
        new: true,
      },
      officesError: '',
    });
  };

  addNewPartner = () => {
    this.togglePartnerModal();
    this.setState({
      partnerValues: {
        partner: '',
        website: '',
        new: true,
      },
      partnersError: '',
    });
  };

  submitPartner = (value) => {
    if (!value.new) {
      const newPartners = this.state.landingData.partners;
      newPartners[value.index] = {
        partner: value.partner,
        website: value.website,
      };
      this.setState((prevState) => ({
        landingData: {
          ...prevState.landingData,
          partners: newPartners,
        },
      }));
      this.togglePartnerModal();
    } else {
      this.setState((prevState) => ({
        landingData: {
          ...prevState.landingData,
          partners: [
            ...prevState.landingData.partners,
            {
              partner: value.partner,
              website: value.website,
            },
          ],
        },
      }));
      this.togglePartnerModal();
    }
  };

  submitLandingForm = (values) => {
    const {
      aboutImage,
      aboutVideo,
      platformImage,
      platformVideo,
      benefitsList1Item1,
      benefitsList1Item2,
      benefitsList1Item3,
      benefitsList1Item4,
      benefitsList1Item5,
      benefitsList2Item1,
      benefitsList2Item2,
      benefitsList2Item3,
      benefitsList2Item4,
      benefitsList2Item5,
      supportImage,
      bannerImage,
    } = values;

    const setAboutVideo = () => {
      if (!this.state.aboutImageToken && this.state.aboutVideo) {
        return this.state.aboutVideo;
      }
      if (!aboutImage && !this.state.aboutImageToken && aboutVideo) {
        return aboutVideo;
      }
      return null;
    };

    const setPlatformVideo = () => {
      if (!this.state.platformImageToken && this.state.platformVideo) {
        return this.state.platformVideo;
      }
      if (!platformImage && !this.state.platformImageToken && platformVideo) {
        return platformVideo;
      }
      return null;
    };

    const setBannerImage = () => {
      if (this.state.bannerImageToken) {
        return null;
      }
      return bannerImage || '';
    };

    const data = {
      ...values,
      benefitsList1: compact([
        benefitsList1Item1,
        benefitsList1Item2,
        benefitsList1Item3,
        benefitsList1Item4,
        benefitsList1Item5,
      ]),
      benefitsList2: compact([
        benefitsList2Item1,
        benefitsList2Item2,
        benefitsList2Item3,
        benefitsList2Item4,
        benefitsList2Item5,
      ]),
      aboutImage:
        !this.state.aboutImageToken && !this.state.aboutVideo
          ? aboutImage
          : null,
      aboutVideo: setAboutVideo(),
      aboutImageToken: this.state.aboutImageToken,
      platformImage:
        !this.state.platformImageToken && !this.state.platformVideo
          ? platformImage
          : null,
      platformVideo: setPlatformVideo(),
      platformImageToken: this.state.platformImageToken,
      supportImage: this.state.supportImageToken ? null : supportImage,
      supportImageToken: this.state.supportImageToken,
      bannerImage: setBannerImage(),
      bannerImageToken: this.state.bannerImageToken,
      offices: this.state.landingData.offices,
      partners: this.state.landingData.partners,
    };

    this.setState({
      isUpdating: true,
    });

    if (data.offices.length > 0 && data.partners.length > 0) {
      editLanding(omitBy(data, isNil))
        .then(() => {
          this.props.getLandingData().then(() => {
            this.setState({
              isSaved: true,
              aboutImageToken: null,
              platformImageToken: null,
              supportImageToken: null,
              bannerImageToken: null,
            });
            setTimeout(() => {
              this.setState({
                isSaved: false,
                isUpdating: false,
              });
            }, 1000);
          });
        })
        .catch(() => {
          this.setState({
            isUpdating: false,
          });
        });
    } else {
      this.setState({
        isUpdating: false,
      });
      if (data.offices.length === 0) {
        this.setState({
          officesError: 'At least one office is required.',
        });
      }
      if (data.partners.length === 0) {
        this.setState({
          partnersError: 'At least one partner is required.',
        });
      }
    }
  };

  updateComingSoonCheckbox = (values) => {
    this.setState({
      soon: values.target.checked,
    });
  };

  removePartner = (item, index) => {
    const newPartners = this.state.landingData.partners;
    newPartners.splice(index, 1);
    this.setState((prevState) => ({
      landingData: {
        ...prevState.landingData,
        partners: newPartners,
      },
    }));
  };

  removeOffice = (item, index) => {
    const newOffices = this.state.landingData.offices;
    newOffices.splice(index, 1);
    this.setState((prevState) => ({
      landingData: {
        ...prevState.landingData,
        offices: newOffices,
      },
    }));
  };

  togglePartnerModal = () => {
    this.setState(
      (prevState) => ({
        isPartnerModalVisible: !prevState.isPartnerModalVisible,
      }),
      () => disableScroll(this.state.isPartnerModalVisible),
    );
  };

  addVideoLink = (type) => {
    this.setState({
      videoSection: type,
    });
    this.toggleVideoLinkModal();
  };

  submitVideoLink = (values) => {
    if (this.state.videoSection === 'about') {
      this.setState({
        aboutVideo: values.url,
        aboutImage: null,
        aboutImageToken: null,
      });
    } else {
      this.setState({
        platformVideo: values.url,
        platformImage: null,
        platformImageToken: null,
      });
    }
    this.toggleVideoLinkModal();
  };

  toggleVideoLinkModal = () => {
    this.setState((prevState) => ({
      isVideoLinkModalVisible: !prevState.isVideoLinkModalVisible,
    }));
  };

  removeBannerImage = () => {
    this.setState((prevState) => ({
      bannerImage: null,
      bannerImageToken: null,
      landingData: {
        ...prevState.landingData,
        bannerImage: null,
      },
    }));
  };

  render() {
    const OfficeModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.country}
            error={formProps.errors.country}
            touched={formProps.touched.country}
            name="country"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Country"
          />
          <span className="admin-landing__character-counter">
            {`${
              formProps.values.country
                ? formProps.values.country.trimStart().length
                : 0
            }/64`}
          </span>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.name}
            error={formProps.errors.name}
            touched={formProps.touched.name}
            name="name"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Contact name"
          />
          <span className="admin-landing__character-counter">
            {`${
              formProps.values.name
                ? formProps.values.name.trimStart().length
                : 0
            }/64`}
          </span>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.email}
            error={formProps.errors.email}
            touched={formProps.touched.email}
            name="email"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Email"
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.phone}
            error={formProps.errors.phone}
            touched={formProps.touched.phone}
            name="phone"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Phone"
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.address}
            error={formProps.errors.address}
            touched={formProps.touched.address}
            name="address"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Address"
          />
          <span className="admin-landing__character-counter">
            {`${
              formProps.values.address
                ? formProps.values.address.trimStart().length
                : 0
            }/64`}
          </span>
        </FormGroup>
        <AcceptCheckbox
          name="comingSoon"
          id="comingSoon"
          onChange={this.updateComingSoonCheckbox}
          checked={this.state.soon}
        >
          Coming soon
        </AcceptCheckbox>
      </>
    );

    const PartnerModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.partner}
            error={formProps.errors.partner}
            touched={formProps.touched.partner}
            name="partner"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Partner"
          />
          <span className="admin-landing__character-counter">
            {`${
              formProps.values.partner
                ? formProps.values.partner.trimStart().length
                : 0
            }/100`}
          </span>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.website}
            error={formProps.errors.website}
            touched={formProps.touched.website}
            name="website"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Website"
          />
        </FormGroup>
      </>
    );

    const VideoLinkModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.url}
            error={formProps.errors.url}
            touched={formProps.touched.url}
            name="url"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Video link"
          />
        </FormGroup>
      </>
    );

    return (
      <>
        <AdminLandingView
          landingData={this.state.landingData}
          submitLandingForm={this.submitLandingForm}
          setOfficeToEdit={this.setOfficeToEdit}
          addNewOffice={this.addNewOffice}
          setPartnerToEdit={this.setPartnerToEdit}
          addNewPartner={this.addNewPartner}
          removePartner={this.removePartner}
          removeOffice={this.removeOffice}
          supportImage={this.state.supportImage}
          platformImage={this.state.platformImage}
          aboutImage={this.state.aboutImage}
          addPhoto={this.addPhoto}
          supportImageError={this.state.supportImageError}
          aboutImageError={this.state.aboutImageError}
          platformImageError={this.state.platformImageError}
          addVideoLink={this.addVideoLink}
          aboutVideo={this.state.aboutVideo}
          platformVideo={this.state.platformVideo}
          isUpdating={this.state.isUpdating}
          officesError={this.state.officesError}
          partnersError={this.state.partnersError}
          bannerImage={this.state.bannerImage}
          bannerImageError={this.state.bannerImageError}
          removeBannerImage={this.removeBannerImage}
          isSaved={this.state.isSaved}
        />
        <FormModal
          isModalVisible={this.state.isOfficeModalVisible}
          handleClose={this.toggleOfficeModal}
          header="Office"
          onSubmit={this.submitOffice}
          initialValues={this.state.values}
          validationSchema={officeValidationSchema}
          confimButtonText="Confirm"
        >
          <OfficeModalFormView />
        </FormModal>
        <FormModal
          isModalVisible={this.state.isPartnerModalVisible}
          handleClose={this.togglePartnerModal}
          header="Partner"
          onSubmit={this.submitPartner}
          initialValues={this.state.partnerValues}
          validationSchema={partnerValidationSchema}
          confimButtonText="Confirm"
        >
          <PartnerModalFormView />
        </FormModal>
        <FormModal
          isModalVisible={this.state.isVideoLinkModalVisible}
          handleClose={this.toggleVideoLinkModal}
          header="Video link"
          onSubmit={this.submitVideoLink}
          validationSchema={videoValidationSchema}
          confimButtonText="Confirm"
        >
          <VideoLinkModalFormView />
        </FormModal>
      </>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(AdminLanding);
