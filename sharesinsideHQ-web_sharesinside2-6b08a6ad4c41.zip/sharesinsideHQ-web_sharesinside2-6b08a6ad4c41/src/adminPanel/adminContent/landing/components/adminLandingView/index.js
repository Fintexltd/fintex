import React from 'react';
import { Form, FormGroup, Row, Col } from 'reactstrap';
import { Formik } from 'formik';
import shortid from 'shortid';
import ReactPlayer from 'react-player';
import landingValidationSchema from 'adminPanel/adminContent/landing/validators/landingValidators';
import SaveButton from 'common/components/saveButton';
import Input from 'common/components/input';
import CircleSpinner from 'common/components/circleSpinner';
import './index.scss';
import DescriptionFormInput from './DescriptionFormInput';

const AdminLandingView = ({
  landingData,
  submitLandingForm,
  setOfficeToEdit,
  addNewOffice,
  addNewPartner,
  setPartnerToEdit,
  removePartner,
  removeOffice,
  supportImage,
  aboutImage,
  platformImage,
  addPhoto,
  supportImageError,
  aboutImageError,
  platformImageError,
  addVideoLink,
  aboutVideo,
  platformVideo,
  isUpdating,
  officesError,
  partnersError,
  bannerImage,
  bannerImageError,
  removeBannerImage,
  isSaved,
}) => (
  <div className="admin-landing">
    <h1 className="admin-landing__heading">Manage landing page</h1>
    {landingData && landingData.heroTitle ? (
      <Formik
        initialValues={landingData}
        onSubmit={(values, { setErrors, setSubmitting }) =>
          submitLandingForm(values, { setErrors, setSubmitting })}
        validationSchema={landingValidationSchema}
        render={({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          setValues,
        }) => (
          <Form onSubmit={handleSubmit} noValidate>
            <Row>
              <Col>
                <p className="admin-landing__section">Main section</p>
              </Col>
            </Row>
            <Row>
              <Col>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.heroTitle}
                    error={errors.heroTitle}
                    touched={touched.heroTitle}
                    name="heroTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.heroTitle ? values.heroTitle.trimStart().length : 0
                    }/24`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.heroSubTitle}
                    error={errors.heroSubTitle}
                    touched={touched.heroSubTitle}
                    name="heroSubTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.heroSubTitle
                        ? values.heroSubTitle.trimStart().length
                        : 0
                    }/64`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <DescriptionFormInput />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">Banner</p>
              </Col>
            </Row>
            <Row>
              <Col>
                <FormGroup>
                  <label htmlFor="bannerPhotoInput">
                    <div className="admin-landing__image">
                      {(bannerImage || landingData.bannerImage) && (
                        <img
                          src={bannerImage || landingData.bannerImage}
                          alt=""
                        />
                      )}
                    </div>
                    <input
                      id="bannerPhotoInput"
                      name="file"
                      type="file"
                      className="admin-landing__input-hidden"
                      accept=".jpeg, .jpg, .png, .gif"
                      onChange={(e) => addPhoto(e, 'banner')}
                    />
                    <div className="admin-landing__add-button">
                      Upload banner image
                    </div>
                    {bannerImageError && (
                      <p className="admin-landing__error">{bannerImageError}</p>
                    )}
                  </label>
                  {(bannerImage || landingData.bannerImage) && (
                    <div
                      className="admin-landing__remove-button"
                      onClick={() => {
                        removeBannerImage();
                        setValues({
                          ...values,
                          bannerImage: null,
                        });
                      }}
                      onKeyPress={() => {
                        removeBannerImage();
                        setValues({
                          ...values,
                          bannerImage: null,
                        });
                      }}
                      role="button"
                      tabIndex="0"
                    >
                      Remove banner image
                    </div>
                  )}
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.bannerUrl}
                    error={errors.bannerUrl}
                    touched={touched.bannerUrl}
                    name="bannerUrl"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add url"
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">Benefits section</p>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.benefitsTitle}
                    error={errors.benefitsTitle}
                    touched={touched.benefitsTitle}
                    name="benefitsTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsTitle
                        ? values.benefitsTitle.trimStart().length
                        : 0
                    }/64`}
                  </span>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.benefitsSubTitle1}
                    error={errors.benefitsSubTitle1}
                    touched={touched.benefitsSubTitle1}
                    name="benefitsSubTitle1"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsSubTitle1
                        ? values.benefitsSubTitle1.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList1Item1}
                    error={errors.benefitsList1Item1}
                    touched={touched.benefitsList1Item1}
                    name="benefitsList1Item1"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList1Item1
                        ? values.benefitsList1Item1.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList1Item2}
                    error={errors.benefitsList1Item2}
                    touched={touched.benefitsList1Item2}
                    name="benefitsList1Item2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList1Item2
                        ? values.benefitsList1Item2.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList1Item3}
                    error={errors.benefitsList1Item3}
                    touched={touched.benefitsList1Item3}
                    name="benefitsList1Item3"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList1Item3
                        ? values.benefitsList1Item3.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList1Item4}
                    error={errors.benefitsList1Item4}
                    touched={touched.benefitsList1Item4}
                    name="benefitsList1Item4"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList1Item4
                        ? values.benefitsList1Item4.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList1Item5}
                    error={errors.benefitsList1Item5}
                    touched={touched.benefitsList1Item5}
                    name="benefitsList1Item5"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList1Item5
                        ? values.benefitsList1Item5.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.benefitsSubTitle2}
                    error={errors.benefitsSubTitle2}
                    touched={touched.benefitsSubTitle2}
                    name="benefitsSubTitle2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsSubTitle2
                        ? values.benefitsSubTitle2.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList2Item1}
                    error={errors.benefitsList2Item1}
                    touched={touched.benefitsList2Item1}
                    name="benefitsList2Item1"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList2Item1
                        ? values.benefitsList2Item1.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList2Item2}
                    error={errors.benefitsList2Item2}
                    touched={touched.benefitsList2Item2}
                    name="benefitsList2Item2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList2Item2
                        ? values.benefitsList2Item2.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList2Item3}
                    error={errors.benefitsList2Item3}
                    touched={touched.benefitsList2Item3}
                    name="benefitsList2Item3"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList2Item3
                        ? values.benefitsList2Item3.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList2Item4}
                    error={errors.benefitsList2Item4}
                    touched={touched.benefitsList2Item4}
                    name="benefitsList2Item4"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList2Item4
                        ? values.benefitsList2Item4.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.benefitsList2Item5}
                    error={errors.benefitsList2Item5}
                    touched={touched.benefitsList2Item5}
                    name="benefitsList2Item5"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.benefitsList2Item5
                        ? values.benefitsList2Item5.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">About/Platform section</p>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.aboutTitle}
                    error={errors.aboutTitle}
                    touched={touched.aboutTitle}
                    name="aboutTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.aboutTitle
                        ? values.aboutTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--large"
                    value={values.aboutText}
                    error={errors.aboutText}
                    touched={touched.aboutText}
                    name="aboutText"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.aboutText ? values.aboutText.trimStart().length : 0
                    }/1000`}
                  </span>
                </FormGroup>
                <FormGroup>
                  {(aboutVideo || (landingData.aboutVideo && !aboutImage)) && (
                    <div className="admin-landing__player-container">
                      <ReactPlayer
                        url={aboutVideo || landingData.aboutVideo}
                        height="100%"
                        width="100%"
                        config={{
                          youtube: {
                            playerVars: {
                              showinfo: 1,
                              controls: 2,
                            },
                          },
                          file: {
                            attributes: {
                              controls: true,
                              controlsList: 'nodownload',
                            },
                          },
                        }}
                      />
                    </div>
                  )}
                  <label htmlFor="aboutPhotoInput">
                    {(aboutImage ||
                      (landingData.aboutImage && !aboutVideo)) && (
                      <div className="admin-landing__image">
                        {(aboutImage || landingData.aboutImage) && (
                          <img
                            src={aboutImage || landingData.aboutImage}
                            alt=""
                          />
                        )}
                      </div>
                    )}
                    <input
                      id="aboutPhotoInput"
                      name="file"
                      type="file"
                      className="admin-landing__input-hidden"
                      accept=".jpeg, .jpg, .png, .gif"
                      onChange={(e) => addPhoto(e, 'about')}
                    />
                    <div className="admin-landing__add-button">
                      Upload photo
                    </div>
                    {aboutImageError && (
                      <p className="admin-landing__error">{aboutImageError}</p>
                    )}
                  </label>
                  <div>
                    <div
                      className="admin-landing__add-button"
                      onClick={() => addVideoLink('about')}
                      onKeyPress={() => addVideoLink('about')}
                      role="button"
                      tabIndex="0"
                    >
                      Add video link
                    </div>
                  </div>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.platformTitle}
                    error={errors.platformTitle}
                    touched={touched.platformTitle}
                    name="platformTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.platformTitle
                        ? values.platformTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--large"
                    value={values.platformText}
                    error={errors.platformText}
                    touched={touched.platformText}
                    name="platformText"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.platformText
                        ? values.platformText.trimStart().length
                        : 0
                    }/1000`}
                  </span>
                </FormGroup>
                <FormGroup>
                  {(platformVideo ||
                    (landingData.platformVideo && !platformImage)) && (
                    <div className="admin-landing__player-container">
                      <ReactPlayer
                        url={platformVideo || landingData.platformVideo}
                        height="100%"
                        width="100%"
                        config={{
                          youtube: {
                            playerVars: {
                              showinfo: 1,
                              controls: 2,
                            },
                          },
                          file: {
                            attributes: {
                              controls: true,
                              controlsList: 'nodownload',
                            },
                          },
                        }}
                      />
                    </div>
                  )}
                  <label htmlFor="platformPhotoInput">
                    {(platformImage ||
                      (landingData.platformImage && !platformVideo)) && (
                      <div className="admin-landing__image">
                        {(platformImage || landingData.platformImage) && (
                          <img
                            src={platformImage || landingData.platformImage}
                            alt=""
                          />
                        )}
                      </div>
                    )}
                    <input
                      id="platformPhotoInput"
                      name="file"
                      type="file"
                      className="admin-landing__input-hidden"
                      accept=".jpeg, .jpg, .png, .gif"
                      onChange={(e) => addPhoto(e, 'platform')}
                    />
                    <div className="admin-landing__add-button">
                      Upload photo
                    </div>
                    {platformImageError && (
                      <p className="admin-landing__error">
                        {platformImageError}
                      </p>
                    )}
                  </label>
                  <div>
                    <div
                      className="admin-landing__add-button"
                      onClick={() => addVideoLink('platform')}
                      onKeyPress={() => addVideoLink('platform')}
                      role="button"
                      tabIndex="0"
                    >
                      Add video link
                    </div>
                  </div>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">
                  Contact/Support section
                </p>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.contactTitle}
                    error={errors.contactTitle}
                    touched={touched.contactTitle}
                    name="contactTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.contactTitle
                        ? values.contactTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.contactText}
                    error={errors.contactText}
                    touched={touched.contactText}
                    name="contactText"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.contactText
                        ? values.contactText.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.supportTitle}
                    error={errors.supportTitle}
                    touched={touched.supportTitle}
                    name="supportTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.supportTitle
                        ? values.supportTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.supportText}
                    error={errors.supportText}
                    touched={touched.supportText}
                    name="supportText"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.supportText
                        ? values.supportText.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <label htmlFor="supportPhotoInput">
                    <div className="admin-landing__image">
                      {(supportImage || landingData.supportImage) && (
                        <img
                          src={supportImage || landingData.supportImage}
                          alt=""
                        />
                      )}
                    </div>
                    <input
                      id="supportPhotoInput"
                      name="file"
                      type="file"
                      className="admin-landing__input-hidden"
                      accept=".jpeg, .jpg, .png, .gif"
                      onChange={(e) => addPhoto(e, 'support')}
                    />
                    <div className="admin-landing__add-button">
                      Upload new photo
                    </div>
                    {supportImageError && (
                      <p className="admin-landing__error">
                        {supportImageError}
                      </p>
                    )}
                  </label>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.supportName}
                    error={errors.supportName}
                    touched={touched.supportName}
                    name="supportName"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Name"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.supportName
                        ? values.supportName.trimStart().length
                        : 0
                    }/64`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.supportPosition}
                    error={errors.supportPosition}
                    touched={touched.supportPosition}
                    name="supportPosition"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Role"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.supportPosition
                        ? values.supportPosition.trimStart().length
                        : 0
                    }/64`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.supportEmail}
                    error={errors.supportEmail}
                    touched={touched.supportEmail}
                    name="supportEmail"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Contact email"
                  />
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.supportPhone}
                    error={errors.supportPhone}
                    touched={touched.supportPhone}
                    name="supportPhone"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Phone number"
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">Offices section</p>
              </Col>
            </Row>
            <Row>
              <Col>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.officesTitle}
                    error={errors.officesTitle}
                    touched={touched.officesTitle}
                    name="officesTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.officesTitle
                        ? values.officesTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                {landingData.offices.map((office, index) => (
                  <div
                    className="admin-landing__office"
                    key={shortid.generate()}
                  >
                    <div className="admin-landing__office-data">
                      <p>{office.country}</p>
                      <p>{office.name}</p>
                      <p>{office.email}</p>
                      <p>{office.phone}</p>
                      <p>{office.address}</p>
                      <p className="admin-landing__coming-soon">
                        {office.soon ? 'Coming soon' : ''}
                      </p>
                    </div>
                    <div>
                      <div
                        className="admin-landing__edit-button"
                        onClick={() => setOfficeToEdit(office, index)}
                        onKeyPress={() => setOfficeToEdit(office, index)}
                        role="button"
                        tabIndex="0"
                      >
                        Edit
                      </div>
                      <div
                        className="admin-landing__remove-button"
                        onClick={() => removeOffice(office, index)}
                        onKeyPress={() => removeOffice(office, index)}
                        role="button"
                        tabIndex="0"
                      >
                        Remove
                      </div>
                    </div>
                  </div>
                ))}
                <div className="admin-landing__add-button-container">
                  <div
                    className="admin-landing__add-button admin-landing__add-button--office"
                    onClick={addNewOffice}
                    onKeyPress={addNewOffice}
                    role="button"
                    tabIndex="0"
                  >
                    Add new office
                  </div>
                  {officesError && (
                    <p className="admin-landing__list-error">{officesError}</p>
                  )}
                </div>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">Corporate section</p>
              </Col>
            </Row>
            <Row>
              <Col>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.corporateTitle}
                    error={errors.corporateTitle}
                    touched={touched.corporateTitle}
                    name="corporateTitle"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateTitle
                        ? values.corporateTitle.trimStart().length
                        : 0
                    }/32`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--medium"
                    value={values.corporateText1}
                    error={errors.corporateText1}
                    touched={touched.corporateText1}
                    name="corporateText1"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateText1
                        ? values.corporateText1.trimStart().length
                        : 0
                    }/800`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--medium"
                    value={values.corporateText2}
                    error={errors.corporateText2}
                    touched={touched.corporateText2}
                    name="corporateText2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateText2
                        ? values.corporateText2.trimStart().length
                        : 0
                    }/800`}
                  </span>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--medium"
                    value={values.corporateText3}
                    error={errors.corporateText3}
                    touched={touched.corporateText3}
                    name="corporateText3"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateText3
                        ? values.corporateText3.trimStart().length
                        : 0
                    }/400`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.corporateQuote1}
                    error={errors.corporateQuote1}
                    touched={touched.corporateQuote1}
                    name="corporateQuote1"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add quote"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateQuote1
                        ? values.corporateQuote1.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Input
                    type="textarea"
                    className="admin-landing__textarea--medium"
                    value={values.corporateText4}
                    error={errors.corporateText4}
                    touched={touched.corporateText4}
                    name="corporateText4"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add text"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateText4
                        ? values.corporateText4.trimStart().length
                        : 0
                    }/400`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <Input
                    type="textarea"
                    value={values.corporateQuote2}
                    error={errors.corporateQuote2}
                    touched={touched.corporateQuote2}
                    name="corporateQuote2"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Add quote"
                  />
                  <span className="admin-landing__character-counter">
                    {`${
                      values.corporateQuote2
                        ? values.corporateQuote2.trimStart().length
                        : 0
                    }/200`}
                  </span>
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col>
                <p className="admin-landing__section">Partners</p>
              </Col>
            </Row>
            <Row>
              <Col>
                {landingData.partners.map((item, index) => (
                  <div
                    className="admin-landing__partner"
                    key={shortid.generate()}
                  >
                    <div className="admin-landing__partner-data">
                      <p>{item.partner}</p>
                      <p>{item.website}</p>
                    </div>
                    <div>
                      <div
                        className="admin-landing__edit-button"
                        onClick={() => setPartnerToEdit(item, index)}
                        onKeyPress={() => setPartnerToEdit(item, index)}
                        role="button"
                        tabIndex="0"
                      >
                        Edit
                      </div>
                      <div
                        className="admin-landing__remove-button"
                        onClick={() => removePartner(item, index)}
                        onKeyPress={() => removePartner(item, index)}
                        role="button"
                        tabIndex="0"
                      >
                        Remove
                      </div>
                    </div>
                  </div>
                ))}
                <div className="admin-landing__add-button-container">
                  <div
                    className="admin-landing__add-button admin-landing__add-button--partner"
                    onClick={addNewPartner}
                    onKeyPress={addNewPartner}
                    role="button"
                    tabIndex="0"
                  >
                    Add new partner
                  </div>
                  {partnersError && (
                    <p className="admin-landing__list-error">{partnersError}</p>
                  )}
                </div>
              </Col>
            </Row>
            <div className="admin-landing__save-container">
              <SaveButton
                type="submit"
                disabled={isUpdating}
                isSaved={isSaved}
              />
              {errors.submit && <p>{errors.submit}</p>}
            </div>
          </Form>
        )}
      />
    ) : (
      <div className="admin-landing__load-container">
        <CircleSpinner />
      </div>
    )}
  </div>
);

export default AdminLandingView;
