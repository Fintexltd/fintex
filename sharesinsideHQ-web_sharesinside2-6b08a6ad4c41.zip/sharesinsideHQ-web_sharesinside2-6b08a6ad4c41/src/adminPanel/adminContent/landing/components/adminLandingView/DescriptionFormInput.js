import TextEditor from 'common/components/textEditor';
import { Field } from 'formik';
import React from 'react';

const DescriptionFormInput = () => {
  return (
    <Field name="heroText">
      {({ form }) => (
        <TextEditor
          className="description__text-editor"
          name="heroText"
          placeholder="Add text*"
          characterLimit={2000}
          defaultValue={form.values.heroText}
          values={form.values}
          errors={form.errors}
          touched={form.touched}
          setFieldError={form.setError}
          setFieldValue={(name, formattedText) => {
            form.setFieldValue(name, formattedText, false);
          }}
          setFieldTouched={form.setTouched}
        />
      )}
    </Field>
  );
};

export default DescriptionFormInput;
