import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

const videoLinkSchema = Yup.object().shape({
  url: Yup.string()
    .required('This field is required.')
    .matches(validUrl, 'Video link must be valid url.'),
});

export default videoLinkSchema;
