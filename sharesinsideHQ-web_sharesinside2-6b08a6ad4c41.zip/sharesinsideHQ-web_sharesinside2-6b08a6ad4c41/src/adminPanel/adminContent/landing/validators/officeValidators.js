import * as Yup from 'yup';

const officeSchema = Yup.object().shape({
  country: Yup.string()
    .max(64, "Office name shouldn't be longer than 64 characters.")
    .required('This field is required.'),
  name: Yup.string().max(
    64,
    "Contact name shouldn't be longer than 64 characters.",
  ),
  email: Yup.string().matches(
    /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
    'E-mail address is invalid.',
  ),
  phone: Yup.string()
    .matches(
      /^\+\d*$/,
      'Phone number must be at least 8 digits long and start with a +.',
    )
    .min(9, 'Phone number must be at least 8 digits long and start with a +.')
    .max(16, 'Phone number must be at most 15 digits long and start with a +.'),
  address: Yup.string().max(
    64,
    "Address shouldn't be longer than 64 characters.",
  ),
});

export default officeSchema;
