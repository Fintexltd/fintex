import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

const partnerSchema = Yup.object().shape({
  partner: Yup.string()
    .max(100, "Partner name shouldn't be longer than 100 characters.")
    .required('This field is required.'),
  website: Yup.string()
    .required('This field is required.')
    .matches(validUrl, 'Website must be valid url.'),
});

export default partnerSchema;
