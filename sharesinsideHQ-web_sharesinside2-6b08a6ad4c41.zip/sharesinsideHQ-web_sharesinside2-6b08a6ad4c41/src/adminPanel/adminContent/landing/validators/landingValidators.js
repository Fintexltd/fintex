import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

const landingSchema = Yup.object().shape({
  heroTitle: Yup.string()
    .max(24, 'This text must be at most 24 characters')
    .required('This field is required.'),
  heroSubTitle: Yup.string()
    .max(64, 'This text must be at most 64 characters')
    .required('This field is required.'),
  heroText: Yup.string()
    .max(2000, 'This text must be at most 2000 characters')
    .required('This field is required.'),
  benefitsTitle: Yup.string()
    .max(64, 'This text must be at most 64 characters')
    .required('This field is required.'),
  bannerUrl: Yup.string().matches(validUrl, 'Url is not valid.'),
  benefitsSubTitle1: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  benefitsList1Item1: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  benefitsList1Item2: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  benefitsList1Item3: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  benefitsList1Item4: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  benefitsList1Item5: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  benefitsSubTitle2: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  benefitsList2Item1: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  benefitsList2Item2: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  benefitsList2Item3: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  benefitsList2Item4: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  benefitsList2Item5: Yup.string().max(
    200,
    'This text must be at most 200 characters',
  ),
  aboutTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  aboutText: Yup.string()
    .max(1000, 'This text must be at most 1000 characters')
    .required('This field is required.'),
  platformTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  platformText: Yup.string()
    .max(1000, 'This text must be at most 1000 characters')
    .required('This field is required.'),
  contactTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  contactText: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  supportTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  supportText: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  supportName: Yup.string()
    .max(64, 'This text must be at most 64 characters')
    .required('This field is required.'),
  supportPosition: Yup.string()
    .max(64, 'This text must be at most 64 characters')
    .required('This field is required.'),
  supportEmail: Yup.string()
    .matches(
      /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
      'E-mail address is invalid.',
    )
    .required('This field is required.'),
  supportPhone: Yup.string()
    .matches(
      /^\+\d*$/,
      'Phone number must be at least 8 digits long and start with a +.',
    )
    .min(9, 'Phone number must be at least 8 digits long and start with a +.')
    .max(16, 'Phone number must be at most 15 digits long and start with a +.')
    .required('This field is required.'),
  officesTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  corporateTitle: Yup.string()
    .max(32, 'This text must be at most 32 characters')
    .required('This field is required.'),
  corporateText1: Yup.string()
    .max(800, 'This text must be at most 800 characters')
    .required('This field is required.'),
  corporateText2: Yup.string().max(
    800,
    'This text must be at most 800 characters',
  ),
  corporateText3: Yup.string()
    .max(400, 'This text must be at most 400 characters')
    .required('This field is required.'),
  corporateText4: Yup.string()
    .max(400, 'This text must be at most 400 characters')
    .required('This field is required.'),
  corporateQuote1: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
  corporateQuote2: Yup.string()
    .max(200, 'This text must be at most 200 characters')
    .required('This field is required.'),
});

export default landingSchema;
