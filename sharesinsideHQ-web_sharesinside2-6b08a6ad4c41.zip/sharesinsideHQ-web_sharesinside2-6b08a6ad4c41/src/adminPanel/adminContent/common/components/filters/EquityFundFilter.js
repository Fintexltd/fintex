import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { equityFundList } from 'adminPanel/adminContent/startups/startupCreator/utils/startupTypes';

const EquityFundFilter = ({ handleFilterUsage, value }) => (
  <div className="admin-advanced-search__filter">
    <MultiSelect
      options={equityFundList}
      description="As Equity / Fund"
      onChange={handleFilterUsage}
      value={value}
      category="equityFund"
    />
  </div>
);

export default EquityFundFilter;
