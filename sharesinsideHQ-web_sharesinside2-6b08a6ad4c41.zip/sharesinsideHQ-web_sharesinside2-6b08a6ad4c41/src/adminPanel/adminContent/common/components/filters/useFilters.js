import { useMemo } from 'react';
import { useSelector } from 'react-redux';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';

const useContinentFilter = (category = 'continent') => {
  const continents = useSelector((state) => state.continents.list);

  const continentsList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: continents || [],
        label: 'continent_name',
        value: 'id',
        category,
      }),
    [continents, category],
  );

  return { continentsList };
};

const useCountryFilter = (category = 'country') => {
  const countries = useSelector((state) => state.countries.list);

  const countriesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: countries || [],
        label: 'country_name',
        value: 'id',
        category,
      }),
    [countries, category],
  );

  return { countriesList };
};

const useIndustryFilter = () => {
  const industries = useSelector((state) => state.industries.list);

  const industriesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: industries || [],
        label: 'name',
        value: 'id',
        category: 'industry',
      }),
    [industries],
  );

  return { industriesList };
};

const useSectorFilter = () => {
  const sectors = useSelector((state) => state.sectors.list);

  const sectorsList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: sectors || [],
        label: 'name',
        value: 'id',
        category: 'sector',
      }),
    [sectors],
  );

  return { sectorsList };
};

const useStartupCategoryFilter = () => {
  const startupCategories = useSelector(
    (state) => state.startupCategories.list,
  );

  const startupCategoriesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: startupCategories || [],
        label: 'name',
        value: 'id',
        category: 'category',
      }),
    [startupCategories],
  );

  return { startupCategoriesList };
};

const useCurrencyFilter = () => {
  const currencies = useSelector((state) => state.currencies.list);

  const currenciesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: currencies || [],
        label: 'currency_symbol',
        value: 'id',
        category: 'currency',
      }),
    [currencies],
  );

  return { currenciesList };
};

const useFundTypeFilter = () => {
  const fundTypes = useSelector((state) => state.fundTypes.list);

  const fundTypesList = useMemo(
    () =>
      mapObjPropsToSelectFilter({
        list: fundTypes || [],
        label: 'name',
        value: 'id',
        category: 'fundType',
      }),
    [fundTypes],
  );

  return { fundTypesList };
};

export {
  useContinentFilter,
  useCountryFilter,
  useIndustryFilter,
  useSectorFilter,
  useStartupCategoryFilter,
  useCurrencyFilter,
  useFundTypeFilter,
};
