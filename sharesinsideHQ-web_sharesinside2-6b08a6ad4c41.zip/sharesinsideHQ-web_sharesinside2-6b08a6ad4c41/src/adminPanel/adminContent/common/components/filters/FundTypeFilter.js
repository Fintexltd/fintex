import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useFundTypeFilter } from './useFilters';

const FundTypeFilter = ({ handleFilterUsage, value }) => {
  const { fundTypesList } = useFundTypeFilter();

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={fundTypesList}
        description="Asset Classes"
        onChange={handleFilterUsage}
        value={value}
        category="fundType"
      />
    </div>
  );
};

export default FundTypeFilter;
