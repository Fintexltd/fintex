import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useSectorFilter } from './useFilters';

const SectorFilter = ({ handleFilterUsage, value }) => {
  const { sectorsList } = useSectorFilter();

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={sectorsList}
        description="Sector"
        onChange={handleFilterUsage}
        value={value}
        category="sector"
      />
    </div>
  );
};

export default SectorFilter;
