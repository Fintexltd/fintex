import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useContinentFilter } from './useFilters';

const ContinentFilter = ({
  handleFilterUsage,
  value,
  category = 'continent',
  description = 'Continent',
}) => {
  const { continentsList } = useContinentFilter(category);

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={continentsList}
        description={description}
        onChange={handleFilterUsage}
        value={value}
        category={category}
        isSearchable
      />
    </div>
  );
};

export default ContinentFilter;
