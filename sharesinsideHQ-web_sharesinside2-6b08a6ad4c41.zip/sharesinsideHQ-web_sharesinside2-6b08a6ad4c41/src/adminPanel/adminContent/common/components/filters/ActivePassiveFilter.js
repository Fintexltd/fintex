import React from 'react';
import { activePassiveList } from 'adminPanel/adminContent/funds/utils/fundTypes';
import MultiSelect from 'common/components/customSelect/multiSelect';

const ActivePassiveFilter = ({ handleFilterUsage, value }) => (
  <div className="admin-advanced-search__filter">
    <MultiSelect
      options={activePassiveList}
      description="Active / Passive"
      onChange={handleFilterUsage}
      value={value}
      category="activePassive"
    />
  </div>
);

export default ActivePassiveFilter;
