import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useCurrencyFilter } from './useFilters';

const CurrencyFilter = ({ handleFilterUsage, value }) => {
  const { currenciesList } = useCurrencyFilter();

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={currenciesList}
        description="Currency"
        onChange={handleFilterUsage}
        value={value}
        category="currency"
        isSearchable
      />
    </div>
  );
};

export default CurrencyFilter;
