import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useStartupCategoryFilter } from './useFilters';

const StartupCategoryFilter = ({ handleFilterUsage, value }) => {
  const { startupCategoriesList } = useStartupCategoryFilter();

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={startupCategoriesList}
        description="Category"
        onChange={handleFilterUsage}
        value={value}
        category="category"
      />
    </div>
  );
};

export default StartupCategoryFilter;
