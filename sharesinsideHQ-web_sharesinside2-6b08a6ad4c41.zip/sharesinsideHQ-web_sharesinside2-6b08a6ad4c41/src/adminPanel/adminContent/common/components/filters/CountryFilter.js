import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useCountryFilter } from './useFilters';

const CountryFilter = ({
  handleFilterUsage,
  value,
  category = 'country',
  description = 'Country',
}) => {
  const { countriesList } = useCountryFilter(category);

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={countriesList}
        description={description}
        onChange={handleFilterUsage}
        value={value}
        category={category}
        isSearchable
      />
    </div>
  );
};

export default CountryFilter;
