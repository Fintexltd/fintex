import React from 'react';
import MultiSelect from 'common/components/customSelect/multiSelect';
import { useIndustryFilter } from './useFilters';

const IndustryFilter = ({ handleFilterUsage, value }) => {
  const { industriesList } = useIndustryFilter();

  return (
    <div className="admin-advanced-search__filter">
      <MultiSelect
        options={industriesList}
        description="Industry"
        onChange={handleFilterUsage}
        value={value}
        category="industry"
        isSearchable
      />
    </div>
  );
};

export default IndustryFilter;
