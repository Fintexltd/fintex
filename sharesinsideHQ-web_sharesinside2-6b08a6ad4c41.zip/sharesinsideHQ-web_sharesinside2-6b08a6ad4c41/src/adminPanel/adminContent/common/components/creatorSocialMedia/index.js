import React, { Fragment } from 'react';
import fbIcon from 'assets/icons/facebook_blue.svg';
import twitterIcon from 'assets/icons/twitter_blue.svg';
import linkedinIcon from 'assets/icons/linkedin_blue.svg';
import { FormGroup } from 'reactstrap';
import FormModal from 'common/components/modals/form';
import Input from 'common/components/input/index.js';
import { socialMediaLinksFormSchema } from '../validators/socialMediaLinksFormSchema';
import './style.scss';

const CreatorSocialMedia = ({
  displaySocialMediaForm,
  updateSocialMediaLinks,
  socialLinks,
}) => {
  const confirmSocialMediaLinks = values => {
    const validSocialLinks = Object.keys(values)
      .filter(link => values[link] !== '')
      .map(name => ({
        type: name,
        url: values[name],
      }));
    updateSocialMediaLinks(validSocialLinks);
    displaySocialMediaForm(false);
  };

  const getValues = () => {
    const initObject = {
      facebook: '',
      twitter: '',
      linkedin: '',
    };

    socialLinks.forEach(link => {
      initObject[link.type] = link.url;
    });

    return initObject;
  };

  const ModalFormView = ({ formProps }) => (
    <Fragment>
      <FormGroup>
        <img className="input-icon" src={fbIcon} alt="facebook input" />
        <Input
          name="facebook"
          placeholder="Facebook"
          error={formProps.errors.facebook}
          value={formProps.values.facebook}
          touched={formProps.touched.facebook}
          onChange={formProps.handleChange}
          onBlur={formProps.handleBlur}
          autoFocus
        />
      </FormGroup>
      <FormGroup>
        <img className="input-icon" src={twitterIcon} alt="facebook input" />
        <Input
          name="twitter"
          placeholder="Twitter"
          error={formProps.errors.twitter}
          value={formProps.values.twitter}
          touched={formProps.touched.twitter}
          onChange={formProps.handleChange}
          onBlur={formProps.handleBlur}
        />
      </FormGroup>
      <FormGroup>
        <img className="input-icon" src={linkedinIcon} alt="facebook input" />
        <Input
          name="linkedin"
          placeholder="Linkedin"
          error={formProps.errors.linkedin}
          value={formProps.values.linkedin}
          touched={formProps.touched.linkedin}
          onChange={formProps.handleChange}
          onBlur={formProps.handleBlur}
        />
      </FormGroup>
    </Fragment>
  );

  return (
    <FormModal
      isModalVisible
      handleClose={() => displaySocialMediaForm(false)}
      header="Add social media"
      validationSchema={socialMediaLinksFormSchema}
      onSubmit={confirmSocialMediaLinks}
      initialValues={getValues()}
      confimButtonText="Save"
      className="socialMediaForm"
    >
      <ModalFormView />
    </FormModal>
  );
};

export default CreatorSocialMedia;
