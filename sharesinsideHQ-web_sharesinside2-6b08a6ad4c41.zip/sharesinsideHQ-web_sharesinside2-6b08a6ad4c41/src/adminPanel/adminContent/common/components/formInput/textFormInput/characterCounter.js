import React from 'react';
import { useWatch } from 'react-hook-form';
import '../style.scss';

const CharacterCounter = ({ textLimit, control, name }) => {
  const textValue = useWatch({
    control,
    name,
    defaultValue: '',
  });

  return (
    <span className="formInput__character-counter">
      {`${textValue.length}/${textLimit}`}
    </span>
  );
};

export default CharacterCounter;
