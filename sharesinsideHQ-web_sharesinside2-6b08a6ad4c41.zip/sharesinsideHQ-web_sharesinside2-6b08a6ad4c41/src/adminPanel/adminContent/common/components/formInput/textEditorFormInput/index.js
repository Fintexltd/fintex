import React from 'react';
import ReactQuill from 'react-quill';

import '../style.scss'

const TextEditorFormInput = ({
    placeholder,
    name,
    showCounter = false,
    control,
    errors
}) => {

    return (

    <>
    <Controller
        control={control}
        name="description"
        rules={{
            validate: value => wordCounter(value) >= 10 || "Enter at least 10 words in the description"
        }}
        error={errors.description}
        render={({ onChange, onBlur, value },  { isTouched }) => (
            <>
            <div
            className={isTouched && errors[name]
            ? 'input-error'
            : null}/>

            <ReactQuill
                name={name}
                placeholder={placeholder}
                theme="snow"
                onChange={(description, delta, source, editor) => onChange(description)}
                value={value || ''}
                onBlur={onBlur}
                touched={isTouched}
            />
            </>
        )}
    />
        { showCounter && <span className="formInput__character-counter">
        {`${this.state.contentLength}/${characterLimit || '8000'}`}
        </span> }
        </>
    )
}

export default TextEditorFormInput;