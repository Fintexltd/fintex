import React from 'react';
import { FormGroup } from 'reactstrap';
import { Controller } from 'react-hook-form';
import classNames from 'classnames';
import MultiSelect from 'common/components/customSelect/multiSelect';
import '../style.scss';

const MultiSelectFormInput = ({
  options,
  isSearchable = false,
  isClearable = false,
  placeholder,
  name,
  errors,
  control,
}) => {
  const error = errors[name] && errors[name].message;

  return (
    <FormGroup>
      <div
        className={classNames({
          'formInput__select-container': error,
        })}
      >
        <Controller
          control={control}
          name={name}
          render={({ onChange, onBlur, value }) => (
            <MultiSelect
              description={placeholder}
              options={options}
              category={name}
              value={value}
              onChange={onChange}
              onBlur={onBlur}
              isSearchable={isSearchable}
              isClearable={isClearable}
            />
          )}
        />
        {' '}
        {error && <div className="formInput__errors-container">{error}</div>}
      </div>
    </FormGroup>
  );
};

export default MultiSelectFormInput;
