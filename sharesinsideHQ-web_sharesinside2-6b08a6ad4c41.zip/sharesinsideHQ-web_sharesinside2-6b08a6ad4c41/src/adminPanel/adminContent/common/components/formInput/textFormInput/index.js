import React from 'react';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import CharacterCounter from './characterCounter';

const TextFormInput = ({
  placeholder,
  name,
  errors,
  innerRef,
  control,
  textLimit,
  onChange,
}) => {
  return (
    <FormGroup>
      <Input
        name={name}
        innerRef={innerRef}
        placeholder={placeholder}
        error={errors[name] && errors[name].message}
        onChange={onChange}
        maxLength={textLimit}
        touched
      />
      {textLimit ? (
        <CharacterCounter textLimit={textLimit} control={control} name={name} />
      ) : null}
    </FormGroup>
  );
};

export default TextFormInput;
