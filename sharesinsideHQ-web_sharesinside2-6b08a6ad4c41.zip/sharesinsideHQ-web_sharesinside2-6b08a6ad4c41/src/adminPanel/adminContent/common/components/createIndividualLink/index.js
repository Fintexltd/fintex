import React from 'react';
import plus from 'assets/icons/add_icon_big_blue.svg';
import PropTypes from 'prop-types';
import CircleSpinner from 'common/components/circleSpinner';
import useCreateIndividualLink from './useCreateIndividualLink';
import './index.scss';

const handleFocus = (event) => event.target.select();

const CreateIndividualLink = ({ type, id, demoIndividualKey }) => {
  const {
    loading,
    individualKey,
    generateIndividualKey,
  } = useCreateIndividualLink(type, id, demoIndividualKey);

  return (
    <div className="create-individual-link">
      <p className="create-individual-link__header">Individual link:</p>
      {loading ? (
        <div className="create-individual-link__spinner">
          <CircleSpinner />
        </div>
      ) : (
        <>
          {' '}
          {individualKey ? (
            <input
              className="create-individual-link__link"
              type="text"
              value={`${process.env.REACT_APP_URL}/demo/key/${individualKey}`}
              onFocus={handleFocus}
            />
          ) : (
            <div
              className="create-individual-link__generate"
              role="presentation"
              onClick={generateIndividualKey}
            >
              <img src={plus} alt="" height={30} width={30} />
              <span>CREATE INDIVIDUAL LINK</span>
            </div>
          )}
          {' '}
        </>
      )}
    </div>
  );
};

CreateIndividualLink.propTypes = {
  type: PropTypes.string.isRequired,
  id: PropTypes.number.isRequired,
  demoIndividualKey: PropTypes.string.isRequired,
};

export default CreateIndividualLink;
