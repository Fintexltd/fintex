import { useState, useEffect } from 'react';
import { getIndividualKey } from './api';

const useCreateIndividualLink = (type, id, key) => {
  const [loading, setLoading] = useState(false);
  const [individualKey, setIndividualKey] = useState(key);

  useEffect(() => {
    setIndividualKey(key);
  }, [key, setIndividualKey]);

  const generateIndividualKey = () => {
    setLoading(true);
    getIndividualKey(id, type)
      .then((response) => {
        setLoading(false);
        setIndividualKey(response.data.key);
      })
      .catch(() => {
        setLoading(false);
      });
  };

  return { loading, individualKey, generateIndividualKey };
};

export default useCreateIndividualLink;
