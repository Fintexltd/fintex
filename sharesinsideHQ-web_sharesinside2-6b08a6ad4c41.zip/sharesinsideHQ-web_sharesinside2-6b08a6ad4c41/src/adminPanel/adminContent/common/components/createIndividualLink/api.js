import axios from 'axios';

const getIndividualKey = (id, type) =>
  axios.post(`${process.env.REACT_APP_API_URL}/admin/demo/individual-key`, {
    entitiable_type: type,
    entitiable_id: id,
  });

export { getIndividualKey };
