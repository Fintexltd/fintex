import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

export const socialMediaLinksFormSchema = Yup.object().shape({
  facebook: Yup.string()
    .matches(/facebook.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  twitter: Yup.string()
    .matches(/twitter.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
  linkedin: Yup.string()
    .matches(/linkedin.com/, 'Social media link should mach social media type.')
    .matches(validUrl, 'This field must be a valid URL'),
});
