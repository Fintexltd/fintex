import React from 'react';
import './style.scss';

const ImageInput = ({
  id,
  setFieldValue,
  name,
  imageType,
  setHeaderImages,
  children,
  accept,
}) => (
  <label htmlFor={id} className="image-input add-wraper">
    {children}
    <input
      name={name}
      id={id}
      className={`add-${imageType}-input`}
      type="file"
      accept={accept || '.jpeg, .jpg, .png, .gif'}
      onChange={e => setHeaderImages(e, imageType, setFieldValue)}
    />
  </label>
);

export default ImageInput;
