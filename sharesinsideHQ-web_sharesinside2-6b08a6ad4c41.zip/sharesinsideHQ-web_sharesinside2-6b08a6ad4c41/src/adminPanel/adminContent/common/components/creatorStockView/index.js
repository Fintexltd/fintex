import React from 'react';
import { Table, Row, Col } from 'reactstrap';
import PropTypes from 'prop-types';
import mapMarker from 'assets/icons/map_marker.svg';
import removeIcon from 'assets/icons/remove_icon_red.svg';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import AsyncMultiSelect from 'common/components/customSelect/asyncMultiSelect';
import shortid from 'shortid';
import './index.scss';

const CreatorStockView = ({
  selectedSymbols,
  symbolsList,
  selectedFeaturedSymbol,
  isLoading,
  errors,
  handleFeaturedInputChange,
  handleRemoveButtonClick,
  onSearchTextChange,
  handleSymbolsChanged,
}) => (
  <section className="stock-form">
    <Table borderless>
      <thead>
        {selectedSymbols.length > 0 && (
          <tr>
            <th className="featured__header">Featured</th>
            <th>Symbol</th>
            <th>Name</th>
            <th />
          </tr>
        )}
      </thead>
      <tbody>
        {selectedSymbols.length > 0 &&
          selectedSymbols.map((item, index) => (
            <tr key={shortid.generate()}>
              <td className="featured__content">
                <div className="featured-chooser__label">
                  <label className="featured-chooser-label" htmlFor="featured">
                    <input
                      name="featured"
                      className="featured-chooser-input"
                      type="radio"
                      defaultChecked={
                        (!selectedFeaturedSymbol && index === 0) ||
                        selectedFeaturedSymbol === item.symbol
                      }
                      onClick={() => handleFeaturedInputChange(item.symbol)}
                    />
                    <img src={mapMarker} alt="stock checked as featured" />
                  </label>
                </div>
              </td>

              <td className="table-stock-column">{item.symbol}</td>
              <td className="table-stock-column">{item.name}</td>
              <td className="table-remove-column">
                <button
                  className="table-remove-row-button"
                  onClick={() => handleRemoveButtonClick(item.symbol)}
                >
                  <img src={removeIcon} alt="remove stock" />
                  remove
                </button>
              </td>
            </tr>
          ))}
      </tbody>
    </Table>
    <Row>
      <Col>
        <AsyncMultiSelect
          description="Stock & Symbol"
          onSearchTextChange={onSearchTextChange}
          onChange={handleSymbolsChanged}
          isLoading={isLoading}
          options={mapObjPropsToSelectFilter({
            list: symbolsList
              ? symbolsList.map(({ symbol, name, region, provider }) => ({
                  value: {
                    symbol,
                    name,
                    provider,
                  },
                  label: `${symbol} ${name} Stock - ${region}`,
                }))
              : [],
            label: 'label',
            value: 'value',
            category: 'symbol',
          })}
          getOptionValue={(option) => option.value.symbol}
          value={selectedSymbols.map((item) => ({
            category: 'symbol',
            label: item.symbol,
            value: item,
          }))}
          category="symbol"
        />
      </Col>
    </Row>
    <Row>
      <Col>
        <div className="api-errors-container">{errors.symbols}</div>
      </Col>
    </Row>
  </section>
);

CreatorStockView.defaultProps = {
  selectedSymbols: [],
  symbolsList: [],
  selectedFeaturedSymbol: null,
  isLoading: false,
  errors: {},
};

CreatorStockView.propTypes = {
  selectedSymbols: PropTypes.arrayOf(PropTypes.object),
  symbolsList: PropTypes.arrayOf(PropTypes.object),
  selectedFeaturedSymbol: PropTypes.string,
  isLoading: PropTypes.bool,
  errors: PropTypes.objectOf(PropTypes.string),
  handleFeaturedInputChange: PropTypes.func.isRequired,
  handleRemoveButtonClick: PropTypes.func.isRequired,
  onSearchTextChange: PropTypes.func.isRequired,
  handleSymbolsChanged: PropTypes.func.isRequired,
};

export default CreatorStockView;
