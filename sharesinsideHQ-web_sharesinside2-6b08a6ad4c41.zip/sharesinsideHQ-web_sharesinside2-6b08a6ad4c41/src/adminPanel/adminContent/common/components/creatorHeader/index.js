import React, { Fragment } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import ImageInput from 'adminPanel/adminContent/common/components/imageInput';
import addWhite from 'assets/icons/add_icon_big_white.svg';
import addBlue from 'assets/icons/add_icon_big_blue.svg';
import camera from 'assets/icons/photo_icon_dark.svg';
import fbIcon from 'assets/icons/facebook_blue.svg';
import twitterIcon from 'assets/icons/twitter_blue.svg';
import linkedinIcon from 'assets/icons/linkedin_blue.svg';
import removeIcon from 'assets/icons/clear_icon_grey.svg';
import shortid from 'shortid';
import './style.scss';

const CreatorHeaderView = ({
  logoUrl,
  backgroundUrl,
  setHeaderImages,
  imagesErrors,
  displaySocialMediaForm,
  socialLinks,
  removeSocialLink,
  errors,
  touched,
  setFieldValue,
}) => {
  const cameraIconLogoClass = classNames({
    'camera-icon': true,
    hide: !logoUrl,
  });
  const cameraIconBackgroundClass = classNames({
    'camera-icon': true,
    hide: !backgroundUrl,
  });

  const logoClass = classNames({
    'add-sign-wraper': true,
    logo: true,
    hide: logoUrl,
  });
  const backgroundClass = classNames({
    'add-sign-wraper': true,
    background: true,
    hide: backgroundUrl,
  });

  const linkIcons = {
    facebook: fbIcon,
    twitter: twitterIcon,
    linkedin: linkedinIcon,
  };
  return (
    <Fragment>
      <section className="creator-images-header wraper">
        <section className="sub-images-header">
          <div
            className="viewer viewer-logo"
            id="viewer-logo"
            style={{ backgroundImage: `url(${logoUrl})` }}
          >
            <ImageInput
              id="add-logo-input"
              imageType="logo"
              setHeaderImages={setHeaderImages}
              setFieldValue={setFieldValue}
            >
              <div className={logoClass} id="add-sign-wraper-logo">
                <img src={addWhite} alt="add logo" className="add-icon" />
                <p className="add-sign-paragraph"> add logo</p>
              </div>
            </ImageInput>

            <ImageInput
              id="add-logo-input-2"
              imageType="logo"
              setHeaderImages={setHeaderImages}
              setFieldValue={setFieldValue}
            >
              <img
                className={cameraIconLogoClass}
                src={camera}
                alt="change logo"
              />
            </ImageInput>
          </div>

          <div
            className="viewer viewer-background"
            id="viewer-background"
            style={{ backgroundImage: `url(${backgroundUrl})` }}
          >
            <ImageInput
              id="add-background-input"
              imageType="background"
              setHeaderImages={setHeaderImages}
              setFieldValue={setFieldValue}
            >
              <div className={backgroundClass} id="add-sign-wraper-background ">
                <img src={addBlue} alt="add background" className="add-icon" />
                <p className="add-sign-paragraph"> add photo</p>
              </div>
            </ImageInput>

            <ImageInput
              id="add-background-input-2"
              imageType="background"
              setHeaderImages={setHeaderImages}
              setFieldValue={setFieldValue}
            >
              <img
                className={cameraIconBackgroundClass}
                src={camera}
                alt="change background"
              />
            </ImageInput>
          </div>
        </section>

        <section className="sub-social-header">
          {socialLinks.map(link => (
            <li key={shortid.generate()}>
              <button
                className="social-links-remove-button"
                onClick={() => removeSocialLink(link.type)}
              >
                <img src={removeIcon} alt="remove social media link" />
              </button>
              <img
                className="social-links-icon"
                src={linkIcons[link.type]}
                alt={`${link.type} is added to links`}
              />
            </li>
          ))}

          <button type="button" onClick={() => displaySocialMediaForm(true)}>
            <img src={addBlue} alt="add social media" className="add-icon" />

            {socialLinks.length === 0 && 'add social media'}
          </button>
        </section>
      </section>
      <div className="error-container">
        <span>{imagesErrors || (touched.logo && errors.logo)}</span>
        <span>{errors['social_media.0'] && errors['social_media.0'][0]}</span>
      </div>
    </Fragment>
  );
};

CreatorHeaderView.defaultProps = {
  logoUrl: '',
  backgroundUrl: '',
  imagesErrors: '',
  socialLinks: [{}],
};

CreatorHeaderView.propTypes = {
  logoUrl: PropTypes.string,
  backgroundUrl: PropTypes.string,
  setHeaderImages: PropTypes.func.isRequired,
  imagesErrors: PropTypes.string,
  displaySocialMediaForm: PropTypes.func.isRequired,
  socialLinks: PropTypes.arrayOf(PropTypes.object),
  removeSocialLink: PropTypes.func.isRequired,
};

export default CreatorHeaderView;
