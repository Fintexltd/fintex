import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import mapStyles from 'styles/googleMaps/mapStyles.js';
import {
  GoogleMap,
  Marker,
  withGoogleMap,
  withScriptjs,
} from 'react-google-maps';
import mapMarker from 'assets/icons/map_marker.svg';

const CreatorMap = withScriptjs(
  withGoogleMap(props => {
    const wallStreetGps = { lat: 40.706893, lng: -74.011222 };
    const locationData = props.locationData || wallStreetGps;

    return (
      <GoogleMap
        defaultZoom={9}
        defaultCenter={locationData}
        center={locationData}
        defaultOptions={{
          styles: mapStyles,
          mapTypeControl: false,
          streetViewControl: false,
        }}
      >
        <Marker defaultIcon={mapMarker} position={locationData} />
        <div className="api-errors-container">
          {' '}
          {props.errors.latitude &&
            'Google could not find Your adress. Please check the location field'}
        </div>
      </GoogleMap>
    );
  }),
);

const mapStateToProps = state => ({
  locationData: state.locationData.results,
});

CreatorMap.propTypes = {
  locationData: PropTypes.objectOf(PropTypes.number),
};

export default connect(mapStateToProps)(CreatorMap);
