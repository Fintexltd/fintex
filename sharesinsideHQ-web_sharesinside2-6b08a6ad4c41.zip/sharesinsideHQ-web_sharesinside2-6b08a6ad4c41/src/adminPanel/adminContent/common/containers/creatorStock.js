import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import debounce from 'lodash/debounce';
import {
  fetchSymbolsList,
  clearSymbolsList,
} from 'common/redux/actions/symbolsListActions';
import CreatorStockView from 'adminPanel/adminContent/common/components/creatorStockView';

class CreatorStock extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedFeaturedSymbol: null,
      symbols: [],
    };
    this.debouncedGetSymbols = debounce((search) => {
      if (search && search.length > 1) {
        props.fetchSymbols(props.type, search);
      } else {
        props.clearSymbols();
      }
    }, 500);
  }

  componentDidMount() {
    this.mapSymbolsToLocalState();
  }

  handleFeaturedInputChange = (symbolOfDefault) => {
    this.setState(
      {
        selectedFeaturedSymbol: symbolOfDefault,
      },
      () => {
        this.notifySymbolsUpdated();
      },
    );
  };

  onSearchTextChange = (text) => {
    this.debouncedGetSymbols(text);
  };

  notifySymbolsUpdated = () => {
    const { symbols, selectedFeaturedSymbol } = this.state;
    this.props.updateStockData(
      symbols.map((item) => ({
        symbol: item.symbol,
        provider: item.provider,
        default:
          selectedFeaturedSymbol === item.symbol || symbols.length === 1
            ? 1
            : 0,
      })),
    );
  };

  handleRemoveButtonClick = (removedSymbol) => {
    this.setState(
      (prevState) => {
        const symbolsCopy = [...prevState.symbols];
        const removedIndex = symbolsCopy.findIndex(
          (item) => item.symbol === removedSymbol,
        );
        symbolsCopy.splice(removedIndex, 1);
        let newFeaturedSymbol = null;
        if (removedSymbol !== prevState.selectedFeaturedSymbol) {
          newFeaturedSymbol = prevState.selectedFeaturedSymbol;
        } else if (symbolsCopy.length) {
          newFeaturedSymbol = symbolsCopy[0].symbol;
        }
        return {
          symbols: symbolsCopy,
          selectedFeaturedSymbol: newFeaturedSymbol,
        };
      },
      () => {
        this.notifySymbolsUpdated();
      },
    );
  };

  handleSymbolsChanged = (updatedSymbols) => {
    if (updatedSymbols !== null) {
      this.setState(
        (prevState) => {
          const symbols = updatedSymbols.map((data) => data.value);
          const { selectedFeaturedSymbol } = prevState;
          let newFeaturedSymbol = null;
          if (symbols.find((item) => item.symbol === selectedFeaturedSymbol)) {
            newFeaturedSymbol = selectedFeaturedSymbol;
          } else if (symbols.length) {
            newFeaturedSymbol = symbols[0].symbol;
          }
          return {
            symbols,
            selectedFeaturedSymbol: newFeaturedSymbol,
          };
        },
        () => {
          this.notifySymbolsUpdated();
        },
      );
    }
  };

  mapSymbolsToLocalState = () => {
    if (this.props.symbols.length) {
      this.setState({
        selectedFeaturedSymbol: this.props.symbols.find(
          (item) => item.is_default,
        ).symbol,
        symbols: this.props.symbols,
      });
    }
  };

  render() {
    const { symbols, selectedFeaturedSymbol } = this.state;
    const { symbolsList, isLoading, errors } = this.props;
    return (
      <CreatorStockView
        selectedSymbols={symbols}
        symbolsList={symbolsList}
        selectedFeaturedSymbol={selectedFeaturedSymbol}
        isLoading={isLoading}
        errors={errors}
        handleFeaturedInputChange={this.handleFeaturedInputChange}
        handleRemoveButtonClick={this.handleRemoveButtonClick}
        onSearchTextChange={this.onSearchTextChange}
        handleSymbolsChanged={this.handleSymbolsChanged}
      />
    );
  }
}

const mapStateToProps = (state) => ({
  symbolsList: state.symbols.list,
  isLoading: state.symbols.isLoading,
});
const mapDispatchToProps = (dispatch) => ({
  fetchSymbols: (type, search) => dispatch(fetchSymbolsList(type, search)),
  clearSymbols: () => dispatch(clearSymbolsList()),
});

CreatorStock.defaultProps = {
  symbolsList: {},
  symbols: [],
  isLoading: false,
};

CreatorStock.propTypes = {
  type: PropTypes.func.isRequired,
  fetchSymbols: PropTypes.func.isRequired,
  clearSymbols: PropTypes.func.isRequired,
  symbolsList: PropTypes.arrayOf(PropTypes.object),
  symbols: PropTypes.arrayOf(PropTypes.object),
  updateStockData: PropTypes.func.isRequired,
  isLoading: PropTypes.bool,
};

export default connect(mapStateToProps, mapDispatchToProps)(CreatorStock);
