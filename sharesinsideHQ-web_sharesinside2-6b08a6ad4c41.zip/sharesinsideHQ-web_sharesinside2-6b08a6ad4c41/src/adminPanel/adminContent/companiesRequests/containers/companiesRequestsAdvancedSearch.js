import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import CompaniesRequestsAdvancedSearchView from 'adminPanel/adminContent/companiesRequests/components/companiesRequestsAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchSectorsList from 'common/redux/actions/sectorsListActions';
import fetchIndustriesList from 'common/redux/actions/industriesListActions';
import fetchCompaniesRequests from 'adminPanel/redux/actions/companiesRequestsActions';
import { saveCompaniesRequestsFilters } from 'adminPanel/redux/actions/companiesRequestsFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  continentsList: state.continents.list,
  industriesList: state.industries.list,
  sectorsList: state.sectors.list,
  companiesRequestsFilters: state.companiesRequestsFilters,
});

const mapDispatchToProps = dispatch => ({
  getCompaniesRequests: bindActionCreators(fetchCompaniesRequests, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getContinentsList: bindActionCreators(fetchContinentsList, dispatch),
  getIndustriesList: bindActionCreators(fetchIndustriesList, dispatch),
  getSectorsList: bindActionCreators(fetchSectorsList, dispatch),
  saveCompaniesRequestsFilters: bindActionCreators(
    saveCompaniesRequestsFilters,
    dispatch,
  ),
});

class CompaniesRequestsAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetCompaniesRequests = debounce(
      props.getCompaniesRequests,
      500,
    );
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getContinentsList();
    this.props.getIndustriesList();
    this.props.getSectorsList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveCompaniesRequestsFilters(
      values.length > 0 ? values : { category },
    );
    this.debouncedGetCompaniesRequests();
  };

  render() {
    return (
      <CompaniesRequestsAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        continentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'continent',
        })}
        industriesList={mapObjPropsToSelectFilter({
          list: this.props.industriesList,
          label: 'name',
          value: 'id',
          category: 'industry',
        })}
        sectorsList={mapObjPropsToSelectFilter({
          list: this.props.sectorsList,
          label: 'name',
          value: 'id',
          category: 'sector',
        })}
        handleFilterUsage={this.handleFilterUsage}
        companiesRequestsFilters={this.props.companiesRequestsFilters}
      />
    );
  }
}

CompaniesRequestsAdvancedSearch.defaultProps = {
  countriesList: [],
  continentsList: [],
  industriesList: [],
  sectorsList: [],
};

CompaniesRequestsAdvancedSearch.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  sectorsList: PropTypes.arrayOf(PropTypes.object),
  getCountriesList: PropTypes.func.isRequired,
  getContinentsList: PropTypes.func.isRequired,
  getIndustriesList: PropTypes.func.isRequired,
  getSectorsList: PropTypes.func.isRequired,
  getCompaniesRequests: PropTypes.func.isRequired,
  saveCompaniesRequestsFilters: PropTypes.func.isRequired,
  companiesRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CompaniesRequestsAdvancedSearch);
