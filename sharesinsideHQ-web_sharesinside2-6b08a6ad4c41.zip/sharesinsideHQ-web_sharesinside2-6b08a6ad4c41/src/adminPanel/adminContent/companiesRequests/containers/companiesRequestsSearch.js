import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import CompaniesRequestsSearchView from 'adminPanel/adminContent/companiesRequests/components/companiesRequestsSearchView';
import fetchCompaniesRequests from 'adminPanel/redux/actions/companiesRequestsActions';
import {
  removeCompaniesRequestsFilters,
  saveCompaniesRequestsSearch,
  saveCompaniesRequestsFilters,
} from 'adminPanel/redux/actions/companiesRequestsFiltersActions';

const mapStateToProps = state => ({
  companiesRequests: state.companiesRequests.list,
  companiesRequestsFilters: state.companiesRequestsFilters,
  resultsNumber: state.companiesRequests.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getCompaniesRequests: bindActionCreators(fetchCompaniesRequests, dispatch),
  removeCompaniesRequestsFilters: bindActionCreators(
    removeCompaniesRequestsFilters,
    dispatch,
  ),
  saveCompaniesRequestsSearch: bindActionCreators(
    saveCompaniesRequestsSearch,
    dispatch,
  ),
  saveCompaniesRequestsFilters: bindActionCreators(
    saveCompaniesRequestsFilters,
    dispatch,
  ),
});

class CompaniesRequestsSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetCompaniesRequests = debounce(
      props.getCompaniesRequests,
      500,
    );
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeCompaniesRequestsFilters();
    this.debouncedGetCompaniesRequests();
  };

  handleSearchInputChange = text => {
    this.props.saveCompaniesRequestsSearch(text);
    this.debouncedGetCompaniesRequests();
  };

  mapActiveFiltersLists = () => [
    ...this.props.companiesRequestsFilters.sector,
    ...this.props.companiesRequestsFilters.industry,
    ...this.props.companiesRequestsFilters.continent,
    ...this.props.companiesRequestsFilters.country,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.companiesRequestsFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveCompaniesRequestsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetCompaniesRequests();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <CompaniesRequestsSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        companiesFilters={this.props.companiesRequestsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

CompaniesRequestsSearch.defaultProps = {
  resultsNumber: null,
};

CompaniesRequestsSearch.propTypes = {
  getCompaniesRequests: PropTypes.func.isRequired,
  removeCompaniesRequestsFilters: PropTypes.func.isRequired,
  saveCompaniesRequestsSearch: PropTypes.func.isRequired,
  saveCompaniesRequestsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  companiesRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CompaniesRequestsSearch);
