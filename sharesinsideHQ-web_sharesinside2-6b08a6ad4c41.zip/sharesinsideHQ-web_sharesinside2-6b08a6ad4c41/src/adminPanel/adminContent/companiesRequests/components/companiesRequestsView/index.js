import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import CompaniesRequestsSearch from 'adminPanel/adminContent/companiesRequests/containers/companiesRequestsSearch';
import Pagination from 'common/components/pagination';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import AcceptButton from 'common/components/acceptButton';
import RejectButton from 'common/components/rejectButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import shortid from 'shortid';
import './index.scss';

const CompaniesRequestsView = ({
  companies,
  previewCompany,
  acceptCompany,
  deleteCompany,
  handleCheckboxClick,
  checkedCompanies,
  handleCheckAllCompaniesClick,
  handleClearSelectionClick,
  acceptMultipleRequests,
  deleteMultipleRequests,
  isCompaniesRequestsFiltersActive,
  getCompaniesRequests,
  resultsNumber,
  meta,
  saveCompaniesRequestsFilters,
  isLoading,
}) => (
  <div className="companies-requests">
    <h1 className="companies-requests__heading">Company Management</h1>
    <CompaniesRequestsSearch />
    <div className="companies-requests__filter-buttons">
      {checkedCompanies.length !== companies.length && (
        <CheckButton
          description="Check all"
          handleClick={handleCheckAllCompaniesClick}
        />
      )}
      {checkedCompanies.length > 0 && (
        <Fragment>
          <div className="companies-requests__clear-button">
            <ClearButton
              description="Clear selection"
              handleClick={handleClearSelectionClick}
            />
          </div>
          <div className="companies-requests__accept-button">
            <AcceptButton
              handleClick={acceptMultipleRequests}
              description="Accept checked"
            />
          </div>
          <RejectButton
            handleClick={deleteMultipleRequests}
            description="Reject checked"
          />
        </Fragment>
      )}
    </div>
    <table className="companies-requests__table">
      <thead className="companies-requests__thead">
        <tr>
          <th>User data</th>
          <th>Sector</th>
          <th>Industry</th>
          <th>Continent</th>
          <th>Country</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {companies.map(company => (
          <tr
            key={shortid.generate()}
            className="companies-requests__company-row"
          >
            <td>
              <div className="companies-requests__user-data">
                <AcceptCheckbox
                  name={`${company.id}`}
                  id={`${company.id}`}
                  onChange={handleCheckboxClick}
                  checked={checkedCompanies.includes(company.id)}
                />
                <div>
                  <p className="companies-requests__name">{company.name}</p>
                  <p className="companies-requests__data">
                    {company.industry.trim()}, {company.country}
                  </p>
                </div>
              </div>
            </td>
            <td>{company.sector}</td>
            <td>{company.industry}</td>
            <td>{company.continent}</td>
            <td>{company.country}</td>
            <td>
              <div className="companies-requests__buttons">
                <button
                  onClick={() => previewCompany(company.id)}
                  className="companies-requests__button companies-requests__button--preview"
                >
                  Preview
                </button>
                <button
                  onClick={() => acceptCompany(company.id)}
                  className="companies-requests__button companies-requests__button--accept"
                >
                  Accept
                </button>
                <button
                  onClick={() => deleteCompany(company.id)}
                  className="companies-requests__button companies-requests__button--delete"
                >
                  Reject
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
    {!isLoading &&
      companies.length === 0 && (
        <div className="companies-requests__empty-list">
          <p className="companies-requests__empty-list-message">
            There are no companies requests
          </p>
        </div>
      )}
    {isCompaniesRequestsFiltersActive() &&
      companies.length === 0 && (
        <div className="companies-requests__empty-list">
          <p className="companies-requests__empty-list-message">
            There are no companies matching these criteria
          </p>
        </div>
      )}
    <Pagination
      meta={meta}
      resultsNumber={resultsNumber}
      saveFilters={saveCompaniesRequestsFilters}
      getResults={getCompaniesRequests}
    />
  </div>
);

CompaniesRequestsView.defaultProps = {
  resultsNumber: null,
};

CompaniesRequestsView.propTypes = {
  companies: PropTypes.arrayOf(PropTypes.object).isRequired,
  previewCompany: PropTypes.func.isRequired,
  acceptCompany: PropTypes.func.isRequired,
  deleteCompany: PropTypes.func.isRequired,
  checkedCompanies: PropTypes.arrayOf(PropTypes.number).isRequired,
  handleCheckAllCompaniesClick: PropTypes.func.isRequired,
  handleClearSelectionClick: PropTypes.func.isRequired,
  acceptMultipleRequests: PropTypes.func.isRequired,
  deleteMultipleRequests: PropTypes.func.isRequired,
  getCompaniesRequests: PropTypes.func.isRequired,
  saveCompaniesRequestsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default CompaniesRequestsView;
