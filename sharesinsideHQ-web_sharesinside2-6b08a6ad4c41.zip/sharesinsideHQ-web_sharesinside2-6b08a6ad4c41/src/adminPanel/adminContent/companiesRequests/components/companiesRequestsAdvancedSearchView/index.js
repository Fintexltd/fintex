import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import './index.scss';

const CompaniesRequestsAdvancedSearchView = ({
  companiesRequestsFilters,
  continentsList,
  countriesList,
  industriesList,
  sectorsList,
  handleFilterUsage,
}) => (
  <div className="companies-requests-advanced-search">
    <div className="companies-requests-advanced-search__filters">
      <div className="companies-requests-advanced-search__filter">
        <MultiSelect
          options={sectorsList}
          description="Sector"
          onChange={handleFilterUsage}
          value={companiesRequestsFilters.sector}
          category="sector"
        />
      </div>
      <div className="companies-requests-advanced-search__filter">
        <MultiSelect
          options={industriesList}
          description="Industry"
          onChange={handleFilterUsage}
          value={companiesRequestsFilters.industry}
          category="industry"
        />
      </div>
      <div className="companies-requests-advanced-search__filter">
        <MultiSelect
          options={continentsList}
          description="Continent"
          onChange={handleFilterUsage}
          value={companiesRequestsFilters.continent}
          category="continent"
        />
      </div>
      <div className="companies-requests-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={companiesRequestsFilters.country}
          category="country"
        />
      </div>
    </div>
  </div>
);

CompaniesRequestsAdvancedSearchView.defaultProps = {
  countriesList: [],
  continentsList: [],
  industriesList: [],
  sectorsList: [],
};

CompaniesRequestsAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  industriesList: PropTypes.arrayOf(PropTypes.object),
  sectorsList: PropTypes.arrayOf(PropTypes.object),
  companiesRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
};

export default CompaniesRequestsAdvancedSearchView;
