import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchCompaniesRequests from 'adminPanel/redux/actions/companiesRequestsActions';
import { saveCompaniesRequestsFilters } from 'adminPanel/redux/actions/companiesRequestsFiltersActions';
import CompaniesRequestsView from 'adminPanel/adminContent/companiesRequests/components/companiesRequestsView';
import { acceptCompanies, deleteCompanies } from 'adminPanel/api/companiesApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';

const mapStateToProps = (state) => ({
  companiesRequests: state.companiesRequests.data,
  companiesRequestsFilters: state.companiesRequestsFilters,
  token: state.auth.token,
  userData: state.userData.data,
  meta: state.companiesRequests.meta,
  resultsNumber: state.companiesRequests.resultsNumber,
  isLoading: state.companiesRequests.isLoading,
});

const mapDispatchToProps = (dispatch) => ({
  getCompaniesRequests: bindActionCreators(fetchCompaniesRequests, dispatch),
  saveCompaniesRequestsFilters: bindActionCreators(
    saveCompaniesRequestsFilters,
    dispatch,
  ),
});

class AdminCompanies extends Component {
  constructor() {
    super();
    this.state = {
      checkedCompanies: [],
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_COMPANY_REQUESTS,
      )
    )
      this.props.history.push('/admin/company/management');

    if (this.props.companiesRequests.length === 0) {
      this.props.getCompaniesRequests();
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      !checkUserPermission(
        nextProps.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_COMPANY_REQUESTS,
      )
    )
      this.props.history.push('/admin/company/management');
  }

  previewCompany = (id) => {
    this.props.history.push(`/company/${id}`);
  };

  handleCompanyRequestCheckboxClick = (value) => {
    let { checkedCompanies } = this.state;
    if (value.target.checked) {
      checkedCompanies.push(Number(value.target.id));
    } else {
      checkedCompanies = this.state.checkedCompanies.filter(
        (id) => id !== Number(value.target.id),
      );
    }
    this.setState({ checkedCompanies });
  };

  acceptCompany = (id) => {
    acceptCompanies([id]).then(() => {
      this.props.getCompaniesRequests(this.props.meta.current_page);
    });
  };

  deleteCompany = (id) => {
    deleteCompanies([id]).then(() => {
      this.props.getCompaniesRequests(this.props.meta.current_page);
    });
  };

  acceptMultipleRequests = () => {
    acceptCompanies(this.state.checkedCompanies).then(() => {
      this.props.getCompaniesRequests(this.props.meta.current_page);
      this.setState({ checkedCompanies: [] });
    });
  };

  deleteMultipleRequests = () => {
    deleteCompanies(this.state.checkedCompanies).then(() => {
      this.props.getCompaniesRequests(this.props.meta.current_page);
      this.setState({ checkedCompanies: [] });
    });
  };

  handleCheckAllCompaniesClick = () => {
    const ids = this.props.companiesRequests.map((company) => company.id);
    this.setState({ checkedCompanies: ids });
  };

  handleClearSelectionClick = () => {
    this.setState({ checkedCompanies: [] });
  };

  isCompaniesRequestsFiltersActive = () => {
    const {
      sector,
      country,
      continent,
      industry,
      search,
    } = this.props.companiesRequestsFilters;
    return (
      sector.length > 0 ||
      country.length > 0 ||
      continent.length > 0 ||
      industry.length > 0 ||
      search !== ''
    );
  };

  render() {
    return (
      <CompaniesRequestsView
        companies={this.props.companiesRequests}
        previewCompany={this.previewCompany}
        acceptCompany={this.acceptCompany}
        deleteCompany={this.deleteCompany}
        handleCheckboxClick={this.handleCompanyRequestCheckboxClick}
        checkedCompanies={this.state.checkedCompanies}
        handleCheckAllCompaniesClick={this.handleCheckAllCompaniesClick}
        handleClearSelectionClick={this.handleClearSelectionClick}
        acceptMultipleRequests={this.acceptMultipleRequests}
        deleteMultipleRequests={this.deleteMultipleRequests}
        isCompaniesRequestsFiltersActive={this.isCompaniesRequestsFiltersActive}
        getCompaniesRequests={this.props.getCompaniesRequests}
        saveCompaniesRequestsFilters={this.props.saveCompaniesRequestsFilters}
        meta={this.props.meta}
        resultsNumber={this.props.resultsNumber}
        isLoading={this.props.isLoading}
      />
    );
  }
}

AdminCompanies.defaultProps = {
  companiesRequests: [],
  resultsNumber: null,
};

AdminCompanies.propTypes = {
  companiesRequests: PropTypes.arrayOf(PropTypes.object),
  getCompaniesRequests: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  companiesRequestsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  saveCompaniesRequestsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminCompanies));
