import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { disableScroll } from 'common/utils/disableScroll';
import RemoveModal from 'common/components/removeModal';
import './index.scss';
import {
  getApiClientData,
  sendApiClientData,
  editApiClientData,
  deleteApiClientData,
  getApiScopesData,
  createBearer,
  revokeTokenData,
} from './api/apiClientApi';
import Clients from './containers/clients';
import ClientFormModal from './components/clientFormModal';
import AddBearerModal from './components/addBearerModal';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class ApiClients extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clients: [],
      scopes: [],
      isClientFormModalVisible: false,
      editedClient: null,
      isDeleteClientModalVisible: false,
      deleteClientId: null,
      isBearerModalVisibe: false,
      bearerClientId: null,
      isRevokeTokenModalVisible: false,
      revokeTokenId: null,
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    this.fetchApiAclients();
    this.fetchApiScopes();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });
  }

  openClientFormModal = (editedClient) => {
    this.setState(
      {
        isClientFormModalVisible: true,
        editedClient,
      },
      () => disableScroll(this.state.isClientFormModalVisible),
    );
  };

  openDeleteClientModal = (clientId) => {
    this.setState(
      {
        isDeleteClientModalVisible: true,
        deleteClientId: clientId,
      },
      () => disableScroll(this.state.isDeleteClientModalVisible),
    );
  };

  openBearerModal = (clientId) => {
    this.setState(
      {
        isBearerModalVisibe: true,
        bearerClientId: clientId,
      },
      () => disableScroll(this.state.isBearerModalVisibe),
    );
  };

  openRevokeTokenModal = (tokenId) => {
    this.setState(
      {
        isRevokeTokenModalVisible: true,
        revokeTokenId: tokenId,
      },
      () => disableScroll(this.state.isRevokeTokenModalVisible),
    );
  };

  revokeToken = () => {
    revokeTokenData(this.state.revokeTokenId).then(() => {
      this.closeAllModals();
      this.fetchApiAclients();
    });
  };

  closeAllModals = () => {
    this.setState(
      {
        isClientFormModalVisible: false,
        editedClient: null,
        isDeleteClientModalVisible: false,
        deleteClientId: null,
        isBearerModalVisibe: false,
        bearerClientId: null,
        isRevokeTokenModalVisible: false,
        revokeTokenId: null,
      },
      () => disableScroll(false),
    );
  };

  submitClientForm = (client, actions) => {
    actions.setSubmitting(true);
    const requestForm = client.id ? editApiClientData : sendApiClientData;
    requestForm(client)
      .then(() => {
        this.closeAllModals();
        actions.setSubmitting(false);
        this.fetchApiAclients();
      })
      .catch(() => {
        actions.setErrors({
          submit: 'There was an error submitting the form.',
        });
        actions.setSubmitting(false);
      });
  };

  submitTokenForm = (scopes) => {
    const request = {
      client_id: this.state.bearerClientId,
      scopes,
    };
    createBearer(request).then(() => {
      this.closeAllModals();
      this.fetchApiAclients();
    });
  };

  deleteClient = () => {
    deleteApiClientData(this.state.deleteClientId).then(() => {
      this.closeAllModals();
      this.fetchApiAclients();
    });
  };

  fetchApiAclients = () => {
    getApiClientData().then((response) => {
      this.setState({
        clients: response.data && response.data.length ? response.data : [],
      });
    });
  };

  fetchApiScopes = () => {
    getApiScopesData().then((response) => {
      this.setState({ scopes: response.data });
    });
  };

  render() {
    const {
      scopes,
      isClientFormModalVisible,
      editedClient,
      isDeleteClientModalVisible,
      isBearerModalVisibe,
      isRevokeTokenModalVisible,
    } = this.state;
    return (
      <>
        <Clients
          clients={this.state.clients}
          openClientFormModal={this.openClientFormModal}
          openDeleteClientModal={this.openDeleteClientModal}
          openBearerModal={this.openBearerModal}
          openRevokeTokenModal={this.openRevokeTokenModal}
        />
        {isClientFormModalVisible && (
          <ClientFormModal
            editedClient={editedClient}
            closeModal={this.closeAllModals}
            submitClientForm={this.submitClientForm}
          />
        )}
        {isDeleteClientModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this API client?"
            message="This item will be deleted along with tokens. You can't undo this action."
            handleRemoveClick={this.deleteClient}
            handleCancelClick={this.closeAllModals}
          />
        )}
        {isBearerModalVisibe && (
          <AddBearerModal
            scopes={scopes}
            submitTokenForm={this.submitTokenForm}
            closeModal={this.closeAllModals}
          />
        )}
        {isRevokeTokenModalVisible && (
          <RemoveModal
            heading="Are You sure you want to revoke this token?"
            message="This item will be deleted. You can't undo this action."
            handleRemoveClick={this.revokeToken}
            handleCancelClick={this.closeAllModals}
          />
        )}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(ApiClients));
