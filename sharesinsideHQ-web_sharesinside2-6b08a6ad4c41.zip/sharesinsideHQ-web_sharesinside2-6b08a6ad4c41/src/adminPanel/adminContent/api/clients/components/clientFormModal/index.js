import React from 'react';
import PropTypes from 'prop-types';
import { Formik } from 'formik';
import Input from 'common/components/input';
import { Row, Col, Form, FormGroup, Button } from 'reactstrap';
import closeIcon from 'assets/icons/close.svg';
import './style.scss';
import { addApiClientSchema } from '../../validators/addApiClientSchema';

const ClientFormModal = ({ closeModal, editedClient, submitClientForm }) => (
  <div className="api-client-edit-modal">
    <div className="api-client-edit-modal__content">
      <p className="api-client-edit-modal__heading">
        {editedClient ? 'Edit' : 'Add'} api client
      </p>
      <button
        className="api-client-edit-modal__close-button"
        onClick={closeModal}
      >
        <img src={closeIcon} alt="close add social links" />
      </button>
      <Formik
        validationSchema={addApiClientSchema}
        initialValues={{
          id: editedClient ? editedClient.id : null,
          name: editedClient ? editedClient.name : '',
          redirect: editedClient
            ? editedClient.redirect
            : 'http://example.com/callback',
        }}
        onSubmit={(values, { setErrors, setSubmitting }) =>
          submitClientForm(values, { setErrors, setSubmitting })
        }
        render={({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isSubmitting,
        }) => (
          <Form onSubmit={handleSubmit} noValidate>
            <Row className="api-client-edit-modal__form-row">
              <Col className="col">
                <FormGroup>
                  <Input
                    type="text"
                    value={values.name}
                    error={errors.name}
                    touched={touched.name}
                    name="name"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Name*"
                    autoFocus
                  />
                </FormGroup>
                <FormGroup>
                  <Input
                    type="text"
                    value={values.redirect}
                    error={errors.redirect}
                    touched={touched.redirect}
                    name="redirect"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    placeholder="Redirect callbacks (url's separated by comma without spaces)"
                  />
                </FormGroup>
              </Col>
            </Row>
            <div className="api-client-edit-modal__buttons">
              <Button color="primary" outline onClick={closeModal}>
                Cancel
              </Button>
              <div className="api-client-edit-modal__save-button">
                <Button type="submit" disabled={isSubmitting} color="primary">
                  Save
                </Button>
                {errors.submit && (
                  <p className="api-client-edit-modal__submit-error-message">
                    {errors.submit}
                  </p>
                )}
              </div>
            </div>
          </Form>
        )}
      />
    </div>
  </div>
);

ClientFormModal.defaultProps = {};

ClientFormModal.propTypes = {
  closeModal: PropTypes.func.isRequired,
};

export default ClientFormModal;
