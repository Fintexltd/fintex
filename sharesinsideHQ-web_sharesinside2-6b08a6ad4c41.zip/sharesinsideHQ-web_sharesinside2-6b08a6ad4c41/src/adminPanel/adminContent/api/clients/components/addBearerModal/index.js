import React, { Component } from 'react';
import { Row, Col, Form, Button } from 'reactstrap';
import MultiSelect from 'common/components/customSelect/multiSelect';
import closeIcon from 'assets/icons/close.svg';
import './style.scss';

class AddBearerModal extends Component {
  state = {
    selectedScopeOptions: [],
  };

  handleScopeChange = data => {
    this.setState({
      selectedScopeOptions: data,
    });
  };

  handleSubmit = () => {
    this.props.submitTokenForm(
      this.state.selectedScopeOptions.map(option => option.value),
    );
  };

  render() {
    const { selectedScopeOptions } = this.state;
    const { closeModal, scopes } = this.props;

    const options = scopes.map(scope => ({
      value: scope.id,
      label: scope.description,
    }));

    return (
      <div className="api-token-edit-modal">
        <div className="api-token-edit-modal__content">
          <p className="api-token-edit-modal__heading">Add new token</p>
          <button
            className="api-token-edit-modal__close-button"
            onClick={closeModal}
          >
            <img src={closeIcon} alt="close add social links" />
          </button>
          <Form noValidate>
            <Row className="api-token-edit-modal__form-row">
              <Col className="col">
                <MultiSelect
                  value={selectedScopeOptions}
                  options={options}
                  onChange={this.handleScopeChange}
                />
              </Col>
            </Row>
            <div className="api-token-edit-modal__buttons">
              <Button color="primary" outline onClick={closeModal}>
                Cancel
              </Button>
              <div className="api-token-edit-modal__save-button">
                <Button
                  disabled={!selectedScopeOptions}
                  color="primary"
                  onClick={this.handleSubmit}
                >
                  Save
                </Button>
              </div>
            </div>
          </Form>
        </div>
      </div>
    );
  }
}

export default AddBearerModal;
