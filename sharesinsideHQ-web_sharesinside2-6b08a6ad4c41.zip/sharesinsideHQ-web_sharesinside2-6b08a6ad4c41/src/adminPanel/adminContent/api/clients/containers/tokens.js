import React from 'react';
import Token from './token';

function Tokens({ openRevokeTokenModal, openBearerModal, client }) {
  const tokenItems = client.tokens.map(token => (
    <Token token={token} openRevokeTokenModal={openRevokeTokenModal} />
  ));

  return (
    <tr>
      <td colSpan={6} className="apitokens">
        <table className="apitokens__table">
          <thead className="apitokens__thead">
            <tr>
              <th>Token</th>
              <th>Refresh token</th>
              <th>Bearer token</th>
              <th>Bearer refresh token</th>
              <th>Info</th>
              <th className="narrow">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td
                className="add__apitokens"
                colSpan={6}
                onClick={() => openBearerModal(client.id)}
                role="presentation"
              >
                <div className="apitokens-container">
                  <h2>+ Add new token</h2>
                </div>
              </td>
            </tr>
            {tokenItems}
          </tbody>
        </table>
      </td>
    </tr>
  );
}

export default Tokens;
