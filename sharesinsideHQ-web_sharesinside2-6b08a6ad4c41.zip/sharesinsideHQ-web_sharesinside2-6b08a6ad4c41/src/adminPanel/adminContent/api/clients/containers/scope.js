import React from 'react';

function Scope({ scope }) {
  return <li>{scope.description}</li>;
}

export default Scope;
