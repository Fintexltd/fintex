import React from 'react';
import Client from './client';

function Clients({
  clients,
  openClientFormModal,
  openDeleteClientModal,
  openBearerModal,
  openRevokeTokenModal,
}) {
  const clientItems = clients.map(client => (
    <Client
      client={client}
      openClientFormModal={openClientFormModal}
      openDeleteClientModal={openDeleteClientModal}
      openBearerModal={openBearerModal}
      openRevokeTokenModal={openRevokeTokenModal}
    />
  ));

  return (
    <div className="apiclients">
      <h1 className="apiclients__heading">Manage api clients and tokens</h1>
      <table className="apiclients__table">
        <thead className="apiclients__thead">
          <tr>
            <th>Name</th>
            <th className="narrow">Identifier</th>
            <th>Secret</th>
            <th>Redirect callbacks</th>
            <th className="narrow">Tokens</th>
            <th className="narrow">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td
              className="add__apiclients"
              colSpan={6}
              onClick={() => openClientFormModal(null)}
              role="presentation"
            >
              <div className="apiclients-container">
                <h2>+ Add new api client</h2>
              </div>
            </td>
          </tr>
          {clientItems}
        </tbody>
      </table>
    </div>
  );
}

export default Clients;
