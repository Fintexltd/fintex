import React from 'react';
import Scope from './scope';

function Scopes({ scopes }) {
  const scopeItems = scopes.map(scope => <Scope scope={scope} />);

  return <ul>{scopeItems}</ul>;
}

export default Scopes;
