import React from 'react';
import moment from 'moment';
import ReactMomentCountDown from 'react-moment-countdown';
import { Input } from 'reactstrap';
import Scopes from './scopes';

function Token({ token, openRevokeTokenModal }) {
  return (
    <tr
      key={token.oauth.access_token.identifier}
      className="apitokens__token-row"
    >
      <td>
        <p className="apitokens__name">
          <Input value={token.oauth.access_token.identifier} type="textarea" />
        </p>
      </td>
      <td>
        <p className="apitokens__name">
          <Input value={token.oauth.refresh_token.identifier} type="textarea" />
        </p>
      </td>
      <td>
        <p className="apitokens__name">
          <Input value={token.bearer.access_token} type="textarea" />
        </p>
      </td>
      <td>
        <p className="apitokens__name">
          <Input value={token.bearer.refresh_token} type="textarea" />
        </p>
      </td>
      <td className="small">
        <ul>
          <li>
            Created at:{' '}
            {moment
              .unix(token.oauth.access_token.created_at)
              .format('YYYY-MM-DD H:m:s')}
          </li>
          <li>
            Expires at:{' '}
            {moment
              .unix(token.oauth.access_token.expires_at)
              .format('YYYY-MM-DD H:m:s')}
          </li>
          <li>
            Expires in:&nbsp;
            <ReactMomentCountDown
              toDate={moment().add(token.bearer.expires_in, 'seconds')}
              targetFormatMask="DD:HH:mm:ss"
            />
          </li>
          <li>
            Scopes:
            <Scopes scopes={token.oauth.access_token.scopes} />
          </li>
        </ul>
      </td>
      <td>
        <div className="apitokens__buttons">
          <button
            onClick={() =>
              openRevokeTokenModal(token.oauth.access_token.identifier)
            }
            className="apitokens__button apitokens__button--remove"
          >
            Revoke
          </button>
        </div>
      </td>
    </tr>
  );
}

export default Token;
