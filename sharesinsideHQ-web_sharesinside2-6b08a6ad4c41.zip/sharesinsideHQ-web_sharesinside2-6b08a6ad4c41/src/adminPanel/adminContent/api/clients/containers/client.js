import React, { Component, Fragment } from 'react';
import { Input, Button } from 'reactstrap';
import Tokens from './tokens';

class Client extends Component {
  state = {
    showTokensSection: false,
  };

  toggleTokensSection = () => {
    this.setState({
      showTokensSection: !this.state.showTokensSection,
    });
  };

  render() {
    const {
      client,
      openClientFormModal,
      openDeleteClientModal,
      openBearerModal,
      openRevokeTokenModal,
    } = this.props;

    const { showTokensSection } = this.state;

    return (
      <Fragment>
        <tr key={client.id} className="apiclients__client-row">
          <td>
            <div className="apiclients__user-data">
              <p className="apiclients__name">{client.name}</p>
            </div>
          </td>
          <td>
            <p className="apiclients__name">
              <Input value={client.id} />
            </p>
          </td>
          <td>
            <p className="apiclients__name">
              <Input value={client.secret} />
            </p>
          </td>
          <td>
            <p className="apiclients__name">
              <Input value={client.redirect} />
            </p>
          </td>
          <td>
            <p className="apiclients__name">
              <Button active onClick={this.toggleTokensSection}>
                Tokens ({client.tokens.length})
              </Button>
            </p>
          </td>
          <td>
            <div className="apiclients__buttons">
              <button
                onClick={() => openClientFormModal(client)}
                className="apiclients__button apiclients__button--edit"
              >
                Edit
              </button>
              <button
                onClick={() => openDeleteClientModal(client.id)}
                className="apiclients__button apiclients__button--remove"
              >
                Remove
              </button>
            </div>
          </td>
        </tr>
        {showTokensSection && (
          <Tokens
            client={client}
            openRevokeTokenModal={openRevokeTokenModal}
            openBearerModal={openBearerModal}
          />
        )}
      </Fragment>
    );
  }
}

export default Client;
