import axios from 'axios';

export const sendApiClientData = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/oauth/clients`, data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const editApiClientData = data =>
  axios.put(`${process.env.REACT_APP_API_URL}/oauth/clients/${data.id}`, data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const getApiClientData = () =>
  axios.get(`${process.env.REACT_APP_API_URL}/oauth/clients`, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const deleteApiClientData = clientId =>
  axios.delete(`${process.env.REACT_APP_API_URL}/oauth/clients/${clientId}`, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const getApiScopesData = () =>
  axios.get(`${process.env.REACT_APP_API_URL}/oauth/scopes`, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const createBearer = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/oauth/bearer`, data, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });

export const revokeTokenData = tokenId =>
  axios.delete(`${process.env.REACT_APP_API_URL}/oauth/bearer/${tokenId}`, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
  });
