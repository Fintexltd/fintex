import * as yup from 'yup';

export const addApiClientSchema = yup.object().shape({
  name: yup
    .string()
    .min(1)
    .max(255)
    .required('This field is required.'),
  redirect: yup
    .string()
    .url()
    .min(1)
    .required('This field is required.'),
});
