import React from 'react';
import SwaggerUI from 'swagger-ui-react';
import 'swagger-ui-react/swagger-ui.css';

const swagger = {
  swagger: '2.0',
  info: {
    version: '0.2.0',
    title: 'Sharesinside API',
    description: 'Web API for SharesInside',
  },
  host: 'api2.sharesinside.com',
  basePath: '/',
  schemes: ['https'],
  securityDefinitions: {
    Bearer: {
      type: 'apiKey',
      name: 'Authorization',
      in: 'header',
    },
    OAuth2: {
      type: 'oauth2',
      flow: 'accessCode',
      authorizationUrl: 'https://api2.sharesinside.com/oauth/authorize',
      tokenUrl: 'https://api2.sharesinside.com/oauth/token',
      scopes: {
        'manage-news': 'Manage news',
      },
    },
  },
  paths: {
    '/api/external/companies': {
      get: {
        tags: ['avaliable options'],
        summary: 'Returns array of availiable companies of authenticated user',
        produces: ['application/json'],
        parameters: [
          {
            name: 'Accept',
            in: 'header',
            type: 'string',
            default: 'application/json',
          },
        ],
        security: [
          {
            Bearer: [],
          },
          {
            OAuth2: ['manage-news'],
          },
        ],
        responses: {
          '200': {
            $ref: '#/definitions/CompanyCollection',
          },
          '401': {
            description: 'User not authenticated.',
          },
          '422': {
            description: 'Validation error',
          },
        },
      },
    },
    '/api/external/countries': {
      get: {
        tags: ['avaliable options'],
        summary: 'Returns array of availiable countries',
        produces: ['application/json'],
        parameters: [
          {
            name: 'Accept',
            in: 'header',
            type: 'string',
            default: 'application/json',
          },
        ],
        security: [
          {
            Bearer: [],
          },
          {
            OAuth2: ['manage-news'],
          },
        ],
        responses: {
          '200': {
            $ref: '#/definitions/CountryCollection',
          },
          '401': {
            description: 'User not authenticated.',
          },
          '422': {
            description: 'Validation error',
          },
        },
      },
    },
    '/api/external/news': {
      post: {
        tags: ['news'],
        summary: 'Create news for company',
        consumes: ['application/json'],
        produces: ['application/json'],
        parameters: [
          {
            name: 'Accept',
            in: 'header',
            type: 'string',
            default: 'application/json',
          },
          {
            in: 'body',
            name: 'body',
            description: 'Json object with news data',
            required: true,
            schema: {
              $ref: '#/definitions/NewsStore',
            },
          },
        ],
        security: [
          {
            Bearer: [],
          },
          {
            OAuth2: ['manage-news'],
          },
        ],
        responses: {
          '200': {
            $ref: '#/definitions/ApiResponse',
          },
          '401': {
            description: 'User not authenticated.',
          },
          '422': {
            description: 'Validation error',
          },
        },
      },
    },
    '/api/external/attachment': {
      post: {
        tags: ['attachment'],
        summary: 'Send attachment',
        produces: ['application/json'],
        consumes: ['multipart/form-data'],
        parameters: [
          {
            name: 'file',
            in: 'formData',
            type: 'file',
            required: true,
            description: 'Required. File to upload',
          },
          {
            name: 'type',
            in: 'query',
            type: 'string',
            required: true,
            description:
              'Required. One of predefined types: type_file for news attachements (files), type_image for news images, type_video for news videos',
            enum: ['type_file', 'type_image', 'type_video'],
          },
        ],
        security: [
          {
            Bearer: [],
          },
          {
            OAuth2: ['manage-news'],
          },
        ],
        responses: {
          '200': {
            $ref: '#/definitions/FileChunkUploadSuccess',
          },
          '201': {
            $ref: '#/definitions/FileUploadSuccess',
          },
        },
      },
    },
  },
  definitions: {
    CompanyCollection: {
      type: 'array',
      description: 'Array of companies',
      items: {
        $ref: '#/definitions/CompanyResource',
      },
    },
    CompanyResource: {
      type: 'object',
      properties: {
        id: {
          type: 'integer',
          description: 'Company ID',
        },
        name: {
          type: 'string',
          description: 'Company name',
        },
      },
    },
    CountryCollection: {
      type: 'array',
      description: 'Array of countries',
      items: {
        $ref: '#/definitions/CountryResource',
      },
    },
    CountryResource: {
      type: 'object',
      properties: {
        id: {
          type: 'integer',
          description: 'Country ID',
        },
        country_name: {
          type: 'string',
          description: 'Country name',
        },
        continent_id: {
          type: 'integer',
          description: 'Continent id',
        },
        linkedin_code: {
          type: 'string',
          description: 'LinkedIn country code ID',
        },
      },
    },
    NewsStore: {
      type: 'object',
      required: ['company_id', 'title', 'description'],
      properties: {
        company_id: {
          type: 'integer',
          description:
            'ID of existing company. Get availiable companies of authenticated user at endpoint /api/external/companies',
          example: '2',
        },
        title: {
          type: 'string',
          description: 'Max. 200 characters.',
          example: 'News title example',
        },
        description: {
          type: 'string',
          description:
            'Max. 20000 characters. Allows basic formating (html tags not counted to max chars limit). This parameter is treated as html text, allowed html tags are p, b, and a, unallowed tags are removed when savind this parameter (so < and > should be encoded as &lt; and &gt;)',
          example: 'News description example',
        },
        is_ad_hoc: {
          type: 'boolean',
          description:
            'Ad-Hoc is a term used by the companies. This is the news that companies MUST publish. E.g. when someone buy more than 3% of the shares available (this is considered a large chunk) all the shareholders/public must be told. This would be an Ad-hoc release. Includes some financial statements, annual reports, etc.',
          example: false,
        },
        files: {
          type: 'array',
          items: {
            $ref: '#/definitions/AttachmentToken',
          },
        },
        videos: {
          description:
            'Only video files are allowed (flv, mp4, mov, avi, wmv, qt)',
          type: 'array',
          items: {
            $ref: '#/definitions/AttachmentToken',
          },
        },
        images: {
          description: 'Only image files are allowed (jpeg, png)',
          type: 'array',
          items: {
            $ref: '#/definitions/AttachmentToken',
          },
        },
        links: {
          type: 'array',
          items: {
            $ref: '#/definitions/Link',
          },
          example: [
            {
              name: 'Link name',
              url: 'https://example.com/example-page.html',
              type: 'type_default',
            },
          ],
        },
        video_links: {
          description: 'Only youtube and vimeo links are allowed',
          type: 'array',
          items: {
            $ref: '#/definitions/Link',
          },
          example: [
            {
              name: 'Video link name',
              url: 'https://www.youtube.com/example-video',
              type: 'type_video',
            },
          ],
        },
        is_business: {
          description:
            'Cannot be true if is_internal is true. Business news can be seen by shareholders and members (VIPs).',
          type: 'boolean',
          example: false,
        },
        is_internal: {
          description:
            'Cannot be true if is_business is true. Internal news can be seen only by members (VIPs).',
          type: 'boolean',
          example: false,
        },
        is_local: {
          description:
            'If true, only users within the same country as the company are notified',
          type: 'boolean',
          example: false,
        },
        receivers: {
          description:
            'If is_internal is true, only vips are allowed. If publish_at is set in the past, this fied is not allowed. Allows to choose receivers, the notifications will be sent to.',
          type: 'array',
          items: {
            type: 'string',
            enum: ['followers', 'shareholders', 'vips'],
          },
          example: ['followers', 'shareholders', 'vips'],
        },
        notify_stock_now: {
          type: 'boolean',
          description:
            'Cannot be true if notify_stock_at is set. Notify stock exchange now',
          example: false,
        },
        notify_stock_at: {
          type: 'integer',
          description:
            'Cannot be set if notify_stock_now is true. Timestamp when stock exchange should be notified',
          example: 16749630671,
        },
        stock_exchange_emails: {
          type: 'array',
          items: {
            type: 'string',
          },
          description:
            'Array of stock exchange emails which should be notified',
          example: ['stock@example.com'],
        },
        publish_at: {
          type: 'integer',
          description:
            'Required if notify_stock_now is true or notify_stock_at is set. Should be at least 1800 seconds later from now if notify_stock_now is true or notify_stock_at is set. Timestamp when news should be published',
          example: 16749720732,
        },
        excluded: {
          type: 'array',
          items: {
            type: 'integer',
          },
          description:
            'Array of country IDs for excluding news. List of countries with IDs is available at /api/external/countries endpoint. You cannot exclude country assigned to your account.',
          example: ['8'],
        },
      },
    },
    ApiResponse: {
      type: 'object',
      properties: {
        message: {
          type: 'string',
          description: 'Response message from API',
        },
      },
    },
    AttachmentToken: {
      type: 'string',
      description:
        'Attachment token received after adding the attachment at endpoint /api/external/attachment',
      example: 'attachement-token',
    },
    Link: {
      type: 'object',
      required: ['name', 'url'],
      properties: {
        name: {
          type: 'string',
          description: 'Displayed name',
        },
        url: {
          type: 'string',
          description: 'Link url',
        },
        type: {
          type: 'string',
          description:
            'Link type: type_default for news links, type_video for news video links',
          enum: ['type_default', 'type_video'],
        },
      },
    },
    FileChunkUploadSuccess: {
      type: 'object',
      properties: {
        done: {
          type: 'integer',
        },
        status: {
          type: 'boolean',
        },
      },
    },
    FileUploadSuccess: {
      type: 'object',
      properties: {
        message: {
          type: 'string',
        },
        token: {
          type: 'string',
        },
      },
    },
  },
};

function ApiDocumentation() {
  return <SwaggerUI spec={swagger} />;
}

export default ApiDocumentation;
