import React, { Fragment } from 'react';

const AdminDemoManView = () => <Fragment>Demo Manview</Fragment>;

export default AdminDemoManView;
