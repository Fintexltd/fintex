import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundsManagerEventsContentView from 'adminPanel/adminContent/fundsManagers/fundsManagerEvents/components/eventsContentView';
import {
  fetchAdminFundsManagerEvents,
  removeAdminFundsManagerEvents,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagerEventsActions';
import { deletEventDataRequest } from 'adminPanel/adminContent/events/api/eventsApi.js';

const mapStateToProps = (state) => ({
  eventsList: state.adminFundsManagerEvents.list,
  hasNextPage: state.adminFundsManagerEvents.hasNextPage,
  nextPageIndex: state.adminFundsManagerEvents.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFundsManagerEvents: bindActionCreators(
    fetchAdminFundsManagerEvents,
    dispatch,
  ),
  removeAdminFundsManagerEvents: bindActionCreators(
    removeAdminFundsManagerEvents,
    dispatch,
  ),
});

class EventsContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadMoreClicked: false,
      removeEventModalDisplayed: false,
    };
  }

  componentDidMount() {
    if (this.props.fundsManagerId) {
      this.props.removeAdminFundsManagerEvents();
      this.props.getAdminFundsManagerEvents(0, this.props.fundsManagerId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminFundsManagerEvents(
          this.props.nextPageIndex,
          this.props.fundsManagerId,
        );
      });
    }
  };

  eventDelete = () => {
    deletEventDataRequest(this.state.eventToDelete).then(() => {
      this.props.getAdminFundsManagerEvents(0, this.props.fundsManagerId);
      this.toggleEventDeleteModal();
    });
  };

  toggleEventDeleteModal = (eventId) => {
    this.setState((prevState) => ({
      removeEventModalDisplayed: !prevState.removeEventModalDisplayed,
      eventToDelete: eventId,
    }));
  };

  render() {
    return (
      <FundsManagerEventsContentView
        eventsList={this.props.eventsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        fundsManagerId={this.props.fundsManagerId}
        toggleEventDeleteModal={this.toggleEventDeleteModal}
        removeEventModalDisplayed={this.state.removeEventModalDisplayed}
        eventDelete={this.eventDelete}
        userData={this.props.userData}
      />
    );
  }
}

EventsContent.defaultProps = {
  fundsManagerId: null,
  nextPageIndex: null,
  eventsList: [],
};

EventsContent.propTypes = {
  fundsManagerId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  eventsList: PropTypes.arrayOf(PropTypes.object),
  getAdminFundsManagerEvents: PropTypes.func.isRequired,
  removeAdminFundsManagerEvents: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EventsContent);
