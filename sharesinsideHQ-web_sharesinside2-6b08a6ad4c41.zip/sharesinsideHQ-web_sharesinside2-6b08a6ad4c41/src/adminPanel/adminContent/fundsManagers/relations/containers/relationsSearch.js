import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import RelationsSearchView from 'adminPanel/adminContent/fundsManagers/relations/components/relationsSearchView';
import fetchRelations from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsActions';
import {
  removeRelationsFilters,
  saveRelationsSearch,
  saveRelationsFilters,
} from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsFiltersActions';

const mapStateToProps = state => ({
  relationsFilters: state.adminFundsManagersRelationsFilters,
  resultsNumber: state.adminFundsManagersRelations.resultsNumber,
});

const mapDispatchToProps = dispatch => ({
  getRelations: bindActionCreators(fetchRelations, dispatch),
  removeRelationsFilters: bindActionCreators(removeRelationsFilters, dispatch),
  saveRelationsSearch: bindActionCreators(saveRelationsSearch, dispatch),
  saveRelationsFilters: bindActionCreators(saveRelationsFilters, dispatch),
});

class RelationsSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetRelations = debounce((fundsManager, role) => {
      props.getRelations(fundsManager, role);
    }, 500);
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState({
      isAdvancedSearchVisible: !this.state.isAdvancedSearchVisible,
    });
  };

  clearActiveFilters = () => {
    this.props.removeRelationsFilters();
    this.debouncedGetRelations();
  };

  handleSearchInputChange = text => {
    this.props.saveRelationsSearch(text);
    this.debouncedGetRelations();
  };

  mapActiveFiltersLists = () => [
    ...this.props.relationsFilters.loginMethod,
    ...this.props.relationsFilters.country,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.relationsFilters[category].filter(
      el => el.label !== label,
    );
    this.props.saveRelationsFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetRelations();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <RelationsSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        relationsFilters={this.props.relationsFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
        selectedRole={this.props.selectedRole}
        selectedFundsManager={this.props.selectedFundsManager}
      />
    );
  }
}

RelationsSearch.defaultProps = {
  resultsNumber: null,
};

RelationsSearch.propTypes = {
  getRelations: PropTypes.func.isRequired,
  removeRelationsFilters: PropTypes.func.isRequired,
  saveRelationsSearch: PropTypes.func.isRequired,
  saveRelationsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(RelationsSearch);
