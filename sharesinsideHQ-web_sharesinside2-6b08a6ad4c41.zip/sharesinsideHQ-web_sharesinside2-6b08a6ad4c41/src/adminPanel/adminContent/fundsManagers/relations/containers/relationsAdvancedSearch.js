import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import RelationsAdvancedSearchView from 'adminPanel/adminContent/fundsManagers/relations/components/relationsAdvancedSearchView';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchRelations from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsActions';
import { saveRelationsFilters } from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsFiltersActions';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  relationsFilters: state.adminFundsManagersRelationsFilters,
});

const mapDispatchToProps = dispatch => ({
  getRelations: bindActionCreators(fetchRelations, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  saveRelationsFilters: bindActionCreators(saveRelationsFilters, dispatch),
});

class RelationsAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetRelations = debounce((company, role) => {
      props.getRelations(company, role);
    }, 500);
  }

  componentDidMount() {
    this.props.getCountriesList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveRelationsFilters(values.length > 0 ? values : { category });
    this.debouncedGetRelations(
      this.props.selectedFundsManager,
      this.props.selectedRole,
    );
  };

  render() {
    return (
      <RelationsAdvancedSearchView
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList ? this.props.countriesList : [],
          label: 'country_name',
          value: 'id',
          category: 'country',
        })}
        handleFilterUsage={this.handleFilterUsage}
        relationsFilters={this.props.relationsFilters}
      />
    );
  }
}

RelationsAdvancedSearch.propTypes = {
  getCountriesList: PropTypes.func.isRequired,
  getRelations: PropTypes.func.isRequired,
  saveRelationsFilters: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(RelationsAdvancedSearch);
