import axios from 'axios';
import { createActionCreator } from 'common/utils/reduxUtils';
import * as types from 'adminPanel/adminContent/fundsManagers/relations/redux/types.js';

const {
  FETCH_FUNDS_MANAGERS_RELATIONS_REQUEST,
  FETCH_FUNDS_MANAGERS_RELATIONS_SUCCESS,
  FETCH_FUNDS_MANAGERS_RELATIONS_FAILURE,
} = types;

const fetchRelationsRequest = createActionCreator(
  FETCH_FUNDS_MANAGERS_RELATIONS_REQUEST,
);
const fetchRelationsSuccess = createActionCreator(
  FETCH_FUNDS_MANAGERS_RELATIONS_SUCCESS,
  'data',
);
const fetchRelationsFailure = createActionCreator(
  FETCH_FUNDS_MANAGERS_RELATIONS_FAILURE,
);

const fetchRelations = (page = 1) => (dispatch, getState) => {
  const {
    country,
    search,
    loginMethod,
    per_page,
    relation,
  } = getState().adminFundsManagersRelationsFilters;

  const fixedRelation = relation === 'investor' ? 'shareholder' : relation;

  const getSelectedFiltersValues = filters =>
    filters.map(filter => filter.value);

  dispatch(fetchRelationsRequest());
  if (getState().adminFundsManagersRelationsFilters.fundsManager) {
    return axios
      .get(
        `${process.env.REACT_APP_API_URL}/admin/funds-managers/${
          getState().adminFundsManagersRelationsFilters.fundsManager
        }/relations`,
        {
          params: {
            page,
            search,
            per_page,
            relation: fixedRelation,
            countries: getSelectedFiltersValues(country),
            login_methods: getSelectedFiltersValues(loginMethod),
          },
        },
      )
      .then(response => {
        dispatch(fetchRelationsSuccess(response.data));
      })
      .catch(() => {
        dispatch(fetchRelationsFailure());
      });
  }

  return null;
};

export default fetchRelations;
