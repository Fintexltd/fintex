import * as types from 'adminPanel/adminContent/fundsManagers/relations/redux/types';
import { createActionCreator } from 'common/utils/reduxUtils';

const {
  REMOVE_FUNDS_MANAGERS_RELATIONS_FILTERS,
  SAVE_FUNDS_MANAGERS_RELATIONS_FILTERS,
  SAVE_FUNDS_MANAGERS_RELATIONS_SEARCH,
} = types;

export const removeRelationsFilters = createActionCreator(
  REMOVE_FUNDS_MANAGERS_RELATIONS_FILTERS,
);

export const saveRelationsFilters = createActionCreator(
  SAVE_FUNDS_MANAGERS_RELATIONS_FILTERS,
  'filter',
);

export const saveRelationsSearch = createActionCreator(
  SAVE_FUNDS_MANAGERS_RELATIONS_SEARCH,
  'search',
);
