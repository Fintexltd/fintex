export default function setErrorMessages(message) {
  if (message === 'Cannot change primary admin role.') {
    return "Each company have to has one Primary Admin. If you want to change this user's role to Editor, first set someone else as Primary Admin.";
  }
  return message;
}
