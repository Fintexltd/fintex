export default function getLoginMethodType() {
  return [
    {
      label: 'Manual',
      value: 'manual',
      category: 'loginMethod',
    },
    {
      label: 'Linkedin',
      value: 'linkedin',
      category: 'loginMethod',
    },
  ];
}
