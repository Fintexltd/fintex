export default function getAdminRolesList() {
  return [
    {
      label: 'Primary Admin',
      value: 'set_primary_admin',
      category: 'administryLevel',
    },
    {
      label: 'Secondary Admin',
      value: 'set_secondary_admin',
      category: 'administryLevel',
    },
  ];
}
