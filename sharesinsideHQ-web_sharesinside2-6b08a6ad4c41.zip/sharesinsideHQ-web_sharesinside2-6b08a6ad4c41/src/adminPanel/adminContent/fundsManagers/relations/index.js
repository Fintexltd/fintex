import React, { Component } from 'react';
import PropTypes from 'prop-types';
import validationSchema from 'adminPanel/adminContent/relations/validators/emailSchema';
import Input from 'common/components/input';
import { Route, Switch, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button } from 'reactstrap';
import shortid from 'shortid';
import fetchRelations from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsActions';
import {
  saveRelationsFilters,
  removeRelationsFilters,
} from 'adminPanel/adminContent/fundsManagers/relations/redux/actions/relationsFiltersActions';
import RelationsView from 'adminPanel/adminContent/fundsManagers/relations/components/relationsView';
import {
  removeRelation,
  removeAdminRelation,
  addNewAdminRole,
  addNewFundsManagerRole,
} from 'adminPanel/adminContent/fundsManagers/relations/api/relationsApi';
import fetchFundsManagersNames from 'common/redux/actions/fundsManagersNamesActions';
import fetchFundsNames from 'common/redux/actions/fundsNamesActions';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import RemoveButton from 'common/components/removeButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import SelectChart from 'common/components/customSelect/selectChart';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import RelationsSearch from 'adminPanel/adminContent/fundsManagers/relations/containers/relationsSearch';
import Page404Loader from 'common/components/Page404Loader';
import RelationsNavigation from 'adminPanel/adminContent/fundsManagers/relations/components/relationsNavigation';
import { disableScroll } from 'common/utils/disableScroll';
import ModalContainer from 'common/components/modalContainer';
import SingleSelect from 'common/components/customSelect/singleSelect';
import FormModal from 'common/components/modals/form';
import Pagination from 'common/components/pagination';
import getAdminRolesList from 'adminPanel/adminContent/fundsManagers/relations/utils/adminRolesListUtils';
import setErrorMessages from 'adminPanel/adminContent/fundsManagers/relations/utils/setErrorMessagesUtils';
import CircleSpinner from 'common/components/circleSpinner';
import ActiveFiltersList from 'common/components/activeFiltersList';
import MultiSelect from 'common/components/customSelect/multiSelect';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import './index.scss';

const mapStateToProps = (state) => ({
  relations: state.adminFundsManagersRelations.data,
  roles: state.adminFundsManagersRelations.roles,
  userGroup: state.adminFundsManagersRelations.userGroup,
  relationsFilters: state.adminFundsManagersRelationsFilters,
  token: state.auth.token,
  userData: state.userData.data,
  meta: state.relations.meta,
  resultsNumber: state.relations.resultsNumber,
  fundsManagersNames: state.fundsManagersNames.list,
  fundsNames: state.fundsNames.list,
  isfundsManagersNamesLoading: state.fundsManagersNames.isLoading,
});

const mapDispatchToProps = (dispatch) => ({
  getRelations: bindActionCreators(fetchRelations, dispatch),
  saveRelationsFilters: bindActionCreators(saveRelationsFilters, dispatch),
  getFundsManagersNames: bindActionCreators(fetchFundsManagersNames, dispatch),
  getFundsNames: bindActionCreators(fetchFundsNames, dispatch),
  removeRelationsFilters: bindActionCreators(removeRelationsFilters, dispatch),
});

class AdminFundsManagersRelations extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checkedRelations: [],
      selectedFundsManager: 0,
      selectedRole: props.location.pathname.split('/')[4],
      errorModalMessage: '',
      isErrorModalVisible: false,
      isNewRoleModalVisible: false,
      isNewAdminRoleModalVisible: false,
      selectedAdminRole: [getAdminRolesList()[0]],
      selectedEditorFunds: [],
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !checkUserPermission(
        this.props.userData,
        PERMISSIONS_FUNCTION_TYPES.MANAGE_FUNDS_MANAGER_PRIMARY_ADMINISTRATOR,
      )
    )
      this.props.history.push('/admin/fundsmanager/management');

    this.props.removeRelationsFilters();
    this.props.history.replace('/admin/fundsmanager/relations/admins');
    this.props.getFundsManagersNames().then(() => {
      if (
        (this.props.userData.relations_funds_manager.primary_admin &&
          this.props.userData.relations_funds_manager.primary_admin.includes(
            this.state.selectedFundsManager[0].value,
          )) ||
        this.props.userData.is_global_admin ||
        this.props.userData.is_content_admin
      ) {
        this.props.history.replace('/admin/fundsmanager/relations/admins');
      } else {
        this.props.history.replace('/admin/fundsmanager/relations/editor');
      }
      this.props.saveRelationsFilters({
        category: 'relation',
        value: this.props.location.pathname.split('/')[4],
      });
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.fundsManagersNames !== this.props.fundsManagersNames) {
      this.props.removeRelationsFilters();
      this.setState(
        {
          selectedFundsManager: [
            {
              category: 'selectedFundsManager',
              label: nextProps.fundsManagersNames[0]
                ? nextProps.fundsManagersNames[0].name
                : '',
              value: nextProps.fundsManagersNames[0]
                ? nextProps.fundsManagersNames[0].id
                : '',
            },
          ],
        },
        () => {
          this.setState({
            checkedRelations: [],
            selectedEditorFunds: [],
          });
          this.props.removeRelationsFilters();
          this.props.saveRelationsFilters({
            category: 'fundsManager',
            value: this.state.selectedFundsManager[0].value,
          });
          this.props.saveRelationsFilters({
            category: 'relation',
            value: this.props.location.pathname.split('/')[4],
          });
          this.props.getRelations();
          const fundsManagerId = this.state.selectedFundsManager[0].value;
          if (fundsManagerId) {
            this.props.getFundsNames(fundsManagerId);
          }
        },
      );
    }

    if (
      nextProps.location.pathname.split('/')[4] !==
      this.props.location.pathname.split('/')[4]
    ) {
      this.setState(
        {
          selectedRole: nextProps.location.pathname.split('/')[4],
          checkedRelations: [],
        },
        () => {
          this.props.removeRelationsFilters();
          if (this.state.selectedFundsManager[0]) {
            this.props.saveRelationsFilters({
              category: 'relation',
              value: nextProps.location.pathname.split('/')[4],
            });
            this.props.saveRelationsFilters({
              category: 'fundsManager',
              value: this.state.selectedFundsManager[0].value,
            });
            this.props.getRelations();
            const fundsManagerId = this.state.selectedFundsManager[0].value;
            if (fundsManagerId) {
              this.props.getFundsNames(fundsManagerId);
            }
          }
        },
      );
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      prevState.selectedFundsManager[0] &&
      this.state.selectedFundsManager[0] &&
      prevState.selectedFundsManager[0].value &&
      this.state.selectedFundsManager[0].value &&
      prevState.selectedFundsManager[0].value !==
        this.state.selectedFundsManager[0].value
    ) {
      if (
        (this.props.userData.relations_funds_manager.primary_admin &&
          this.props.userData.relations_funds_manager.primary_admin.includes(
            this.state.selectedFundsManager[0].value,
          )) ||
        this.props.userData.is_global_admin ||
        this.props.userData.is_content_admin
      ) {
        this.props.history.replace('/admin/fundsmanager/relations/admins');
      } else {
        this.props.history.replace('/admin/fundsmanager/relations/editor');
      }
      this.props.saveRelationsFilters({
        category: 'relation',
        value: this.props.location.pathname.split('/')[4],
      });
      this.props.saveRelationsFilters({
        category: 'fundsManager',
        value: this.state.selectedFundsManager[0].value,
      });
      setTimeout(() => {
        this.props.getRelations();
        this.props.getFundsNames(this.state.selectedFundsManager[0].value);
      });
    }
  }

  handleChangeSelect = (value, category) => {
    this.setState(
      {
        [category]: value,
        checkedRelations: [],
        selectedEditorFunds: [],
      },
      () => {
        this.props.removeRelationsFilters();
        this.props.saveRelationsFilters({
          category: 'fundsManager',
          value: this.state.selectedFundsManager[0].value,
        });
        this.props.saveRelationsFilters({
          category: 'relation',
          value: this.props.location.pathname.split('/')[4],
        });
      },
    );
  };

  handleRelationsCheckboxClick = (value, relation) => {
    if (relation !== 'primary_admin') {
      let { checkedRelations } = this.state;
      if (value.target.checked) {
        checkedRelations.push(Number(value.target.id));
      } else {
        checkedRelations = this.state.checkedRelations.filter(
          (id) => id !== Number(value.target.id),
        );
      }
      this.setState({ checkedRelations });
    }
  };

  removeRelation = (id) => {
    (this.state.selectedRole !== 'admins'
      ? removeRelation(
          this.state.selectedFundsManager[0].value,
          parseInt(id, 10) ? [id] : this.state.checkedRelations,
        )
      : removeAdminRelation(
          this.state.selectedFundsManager[0].value,
          parseInt(id, 10) ? [id] : this.state.checkedRelations,
        )
    ).then(() => {
      this.setState((prevState) => ({
        checkedRelations: parseInt(id, 10)
          ? prevState.checkedRelations.filter((checkedId) => checkedId !== id)
          : [],
      }));
      this.props.getRelations();
    });
  };

  handleCheckAllRelationsClick = () => {
    if (this.state.selectedRole === 'admins') {
      const ids = this.props.relations.map((relation) =>
        relation.type !== 'primary_admin' ? relation.id : null,
      );
      this.setState({
        checkedRelations: ids.filter((id) => id !== null),
      });
    } else {
      const arrays = this.props.relations.map((relation) => relation.relations);
      this.setState({
        checkedRelations: []
          .concat(...arrays)
          .map((fundRelation) => fundRelation.id),
      });
    }
  };

  handleClearSelectionClick = () => {
    this.setState({ checkedRelations: [] });
  };

  isRelationsFiltersActive = () => {
    const { country, loginMethod, search } = this.props.relationsFilters;
    return country.length > 0 || loginMethod.length > 0 || search !== '';
  };

  handleClickNewRole = (roleType) => {
    if (roleType === 'admins') {
      this.setState(
        (prevState) => ({
          isNewAdminRoleModalVisible: !prevState.isNewAdminRoleModalVisible,
        }),
        () => disableScroll(this.state.isNewAdminRoleModalVisible),
      );
    } else {
      this.setState(
        (prevState) => ({
          isNewRoleModalVisible: !prevState.isNewRoleModalVisible,
          selectedEditorFunds: [],
        }),
        () => disableScroll(this.state.isNewRoleModalVisible),
      );
    }
  };

  handleAddRoleSubmit = (values, adminAction) => {
    (this.state.selectedRole === 'admins'
      ? addNewAdminRole(
          this.state.selectedFundsManager[0].value,
          adminAction,
          values.email,
        )
      : addNewFundsManagerRole(
          this.state.selectedFundsManager[0].value,
          values.email,
          values.assignToFundsManager,
          this.state.selectedRole === 'editor' ? 'set_editor' : 'add_vip',
          this.state.selectedEditorFunds.map((option) => option.value),
        )
    )
      .then((response) => {
        if (response.status === 200) {
          this.props.getRelations();
          if (adminAction) {
            this.handleClickNewRole('admins');
          } else {
            this.handleClickNewRole(this.state.selectedRole);
          }
        }
      })
      .catch((error) => {
        this.setState(
          {
            isNewRoleModalVisible: false,
            isNewAdminRoleModalVisible: false,
            isErrorModalVisible: true,
            errorModalMessage: error.response.data.errors
              ? Object.keys(error.response.data.errors).map(
                  (key) => error.response.data.errors[key][0],
                )
              : ['There was an error submitting the form.'],
          },
          () => disableScroll(this.state.isErrorModalVisible),
        );
      });
  };

  handleSelectedFundRemoveClick = (label) => {
    this.setState((prevState) => ({
      selectedEditorFunds: prevState.selectedEditorFunds.filter(
        (el) => el.label !== label,
      ),
    }));
  };

  errorModalClose = () => {
    this.setState({ isErrorModalVisible: false, errorModalMessage: '' });
  };

  render() {
    const RelationTableView = () => (
      <RelationsView
        relations={this.props.relations}
        removeRelation={this.removeRelation}
        handleCheckboxClick={this.handleRelationsCheckboxClick}
        checkedRelations={this.state.checkedRelations}
        isRelationsFiltersActive={this.isRelationsFiltersActive}
        getRelations={this.props.getRelations}
        saveRelationsFilters={this.props.saveRelationsFilters}
        meta={this.props.meta}
        resultsNumber={this.props.resultsNumber}
        handleClickNewRole={this.handleClickNewRole}
        roleType={this.props.location.pathname.split('/')[4]}
        userData={this.props.userData}
        roles={this.props.roles}
        userGroup={this.props.userGroup}
      />
    );

    const EditorModalFormView = ({ formProps }) => (
      <div>
        <div className="set-admin-modal">
          <div className="set-admin-modal__email">
            <Input
              name="email"
              type="text"
              placeholder="E-mail"
              error={formProps.errors.email}
              value={formProps.values.email}
              touched={formProps.touched.email}
              onBlur={formProps.handleBlur}
              onChange={formProps.handleChange}
              autoFocus
            />
            {' '}
          </div>
          <div className="set-admin-modal__select">
            <MultiSelect
              description="Funds"
              onChange={(value) =>
                this.setState({ selectedEditorFunds: value })}
              isSearchable
              options={mapObjPropsToSelectFilter({
                list: this.props.fundsNames,
                label: 'name',
                value: 'id',
                category: 'fund',
              })}
              value={this.state.selectedEditorFunds}
              category="fund"
            />
          </div>
        </div>
        <div className="set-admin-modal__checkbox">
          <AcceptCheckbox
            id="assignToFundsManager"
            name="assignToFundsManager"
            touched={formProps.touched.assignToFundsManager}
            onBlur={formProps.handleBlur}
            onChange={formProps.handleChange}
            value={formProps.values.assignToFundsManager}
          >
            Assign as
            {' '}
            {`${
              this.state.selectedFundsManager
                ? this.state.selectedFundsManager[0].label
                : this.props.fundsManagersNames[0].label
            } ${this.state.selectedRole}`}
          </AcceptCheckbox>
        </div>
      </div>
    );

    const AdminModalFormView = ({ formProps }) => (
      <div className="set-admin-modal">
        <div className="set-admin-modal__email">
          <Input
            name="email"
            type="text"
            placeholder="E-mail"
            error={formProps.errors.email}
            value={formProps.values.email}
            touched={formProps.touched.email}
            onBlur={formProps.handleBlur}
            onChange={formProps.handleChange}
            autoFocus
          />
          {' '}
        </div>
        <div className="set-admin-modal__select">
          <SingleSelect
            description="Administry level"
            onChange={(value) => this.setState({ selectedAdminRole: value })}
            options={getAdminRolesList()}
            value={this.state.selectedAdminRole}
            category="administryLevel"
          />
        </div>
      </div>
    );

    return (
      <div className="adminRelations__container">
        {this.props.fundsManagersNames &&
          this.props.fundsManagersNames.length > 0 && (
            <div className="adminRelations">
              <h1 className="adminRelations__heading">Relations of</h1>
              <div className="adminRelations__companySelect">
                {this.props.fundsManagersNames &&
                this.props.fundsManagersNames.length > 1 ? (
                  <SelectChart
                    onChange={this.handleChangeSelect}
                    options={mapObjPropsToSelectFilter({
                      list: this.props.fundsManagersNames
                        ? this.props.fundsManagersNames.map((fundsManager) => ({
                            value: fundsManager.id,
                            label: fundsManager.name,
                          }))
                        : [],
                      label: 'label',
                      value: 'value',
                      category: 'selectedFundsManager',
                    })}
                    value={this.state.selectedFundsManager}
                    category="selectedFundsManager"
                  />
                ) : (
                  <h1 className="adminRelations__heading--company">
                    {this.props.fundsManagersNames &&
                    this.props.fundsManagersNames[0]
                      ? this.props.fundsManagersNames[0].name
                      : ''}
                  </h1>
                )}
              </div>
              <RelationsNavigation
                roles={this.props.roles}
                userData={this.props.userData}
                selectedFundsManagerId={
                  this.state.selectedFundsManager[0] &&
                  this.state.selectedFundsManager[0].value
                }
              />
              <RelationsSearch />
              <div className="adminRelations__filter-buttons">
                {this.state.checkedRelations.length !==
                  this.props.relations.length && (
                  <CheckButton
                    description="Check all"
                    handleClick={this.handleCheckAllRelationsClick}
                  />
                )}
                {this.state.checkedRelations.length > 0 && (
                  <>
                    <div className="adminRelations__clear-button">
                      <ClearButton
                        description="Clear selection"
                        handleClick={this.handleClearSelectionClick}
                      />
                    </div>
                    <RemoveButton
                      handleRemoveClick={this.removeRelation}
                      description="Remove checked"
                    />
                  </>
                )}
              </div>
              <div className="adminRelation__navigation">
                <Switch>
                  <Route
                    path="/admin/fundsmanager/relations/admins"
                    component={RelationTableView}
                  />
                  <Route
                    path="/admin/fundsmanager/relations/editor"
                    component={RelationTableView}
                  />
                  <Route
                    path="/admin/fundsmanager/relations/vip"
                    component={RelationTableView}
                  />
                  <Route
                    path="/admin/fundsmanager/relations/investor"
                    component={RelationTableView}
                  />
                  <Route component={Page404Loader} />
                </Switch>
              </div>
              <Pagination
                meta={this.props.meta}
                resultsNumber={this.props.resultsNumber}
                saveFilters={this.props.saveRelationsFilters}
                getResults={this.props.getRelations}
              />
              <FormModal
                isModalVisible={this.state.isNewRoleModalVisible}
                handleClose={() =>
                  this.handleClickNewRole(this.state.selectedRole)}
                header={`Add new ${this.state.selectedRole}`}
                validationSchema={validationSchema}
                onSubmit={(values) => this.handleAddRoleSubmit(values)}
                initialValues={{
                  email: '',
                  assignToFundsManager: false,
                }}
                confimButtonText="ADD"
              >
                <EditorModalFormView />
                <div className="adminRelations__selected-editors">
                  <ActiveFiltersList
                    activeFiltersList={this.state.selectedEditorFunds}
                    handleFilterRemoveClick={this.handleSelectedFundRemoveClick}
                    title={null}
                  />
                </div>
              </FormModal>

              <FormModal
                isModalVisible={this.state.isNewAdminRoleModalVisible}
                handleClose={() => this.handleClickNewRole('admins')}
                header="Add new fund-Manager admin"
                validationSchema={validationSchema}
                onSubmit={(values) =>
                  this.handleAddRoleSubmit(
                    values,
                    this.state.selectedAdminRole[0].value,
                  )}
                initialValues={{
                  email: '',
                }}
                confimButtonText="ADD"
              >
                <AdminModalFormView />
              </FormModal>

              {this.state.isErrorModalVisible && (
                <ModalContainer className="relationError__modal">
                  <div className="relationError__container">
                    {this.state.errorModalMessage &&
                      this.state.errorModalMessage.map((message) => (
                        <p
                          key={shortid.generate()}
                          className="relationError__message"
                        >
                          {setErrorMessages(message)}
                        </p>
                      ))}
                    <Button
                      className="mr-4 relationError__button"
                      outline
                      color="primary"
                      onClick={() => {
                        this.setState(
                          {
                            isErrorModalVisible: false,
                            errorModalMessage: '',
                          },
                          () => disableScroll(this.state.isErrorModalVisible),
                        );
                      }}
                    >
                      return
                    </Button>
                  </div>
                </ModalContainer>
              )}
            </div>
          )}
        {!this.props.isfundsManagersNamesLoading &&
          (!this.props.fundsManagersNames ||
            (this.props.fundsManagersNames &&
              this.props.fundsManagersNames.length === 0)) && (
              <div className="adminRelations__empty-container">
                <p className="adminRelations__empty-message">
                  There are no relations.
                </p>
              </div>
          )}
        {this.props.isfundsManagersNamesLoading && (
          <div className="adminRelations__load-container">
            <CircleSpinner />
          </div>
        )}
      </div>
    );
  }
}

AdminFundsManagersRelations.defaultProps = {
  relations: [],
  resultsNumber: null,
};

AdminFundsManagersRelations.propTypes = {
  relations: PropTypes.arrayOf(PropTypes.object),
  getRelations: PropTypes.func.isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.object,
      PropTypes.func,
      PropTypes.number,
      PropTypes.string,
    ]),
  ).isRequired,
  relationsFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array, PropTypes.number]),
  ).isRequired,
  saveRelationsFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  meta: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(AdminFundsManagersRelations));
