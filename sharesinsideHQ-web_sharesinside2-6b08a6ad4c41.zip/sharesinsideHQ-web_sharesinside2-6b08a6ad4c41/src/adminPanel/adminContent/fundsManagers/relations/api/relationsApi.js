import axios from 'axios';

export const removeAdminRelation = (id, relations) =>
  axios({
    method: 'delete',
    url: `${
      process.env.REACT_APP_API_URL
    }/admin/funds-managers/${id}/relations`,
    data: {
      relations,
    },
  });

export const removeRelation = (id, relations) =>
  axios({
    method: 'delete',
    url: `${
      process.env.REACT_APP_API_URL
    }/admin/funds-managers/${id}/funds-relations`,
    data: {
      relations,
    },
  });

export const addNewAdminRole = (id, action, email) =>
  axios({
    method: 'post',
    url: `${
      process.env.REACT_APP_API_URL
    }/funds-managers/${id}/admin/manage-roles`,
    data: {
      action,
      user_email: email,
    },
  });

export const addNewFundsManagerRole = (
  id,
  email,
  assignToFundsManager,
  action,
  fundIds,
) =>
  axios({
    method: 'post',
    url: `${
      process.env.REACT_APP_API_URL
    }/funds-managers/${id}/admin/manage-funds-roles `,
    data: {
      user_email: email,
      assign_to_funds_manager: assignToFundsManager,
      fund_ids: fundIds,
      action,
    },
  });
