import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import getLoginMethodList from 'adminPanel/adminContent/relations/utils/loginMethodTypeUtils';
import 'adminPanel/adminContent/relations/components/relationsAdvancedSearchView/index.scss';

const RelationsAdvancedSearchView = ({
  relationsFilters,
  countriesList,
  handleFilterUsage,
}) => (
  <div className="adminRelations-advanced-search">
    <div className="adminRelations-advanced-search__filters">
      <div className="adminRelations-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Country"
          onChange={handleFilterUsage}
          value={relationsFilters.country}
          category="country"
        />
      </div>
      <div className="adminRelations-advanced-search__filter">
        <MultiSelect
          options={getLoginMethodList()}
          description="Login method"
          onChange={handleFilterUsage}
          value={relationsFilters.loginMethod}
          category="loginMethod"
        />
      </div>
    </div>
  </div>
);

RelationsAdvancedSearchView.defaultProps = {
  countriesList: [],
};

RelationsAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  handleFilterUsage: PropTypes.func.isRequired,
};

export default RelationsAdvancedSearchView;
