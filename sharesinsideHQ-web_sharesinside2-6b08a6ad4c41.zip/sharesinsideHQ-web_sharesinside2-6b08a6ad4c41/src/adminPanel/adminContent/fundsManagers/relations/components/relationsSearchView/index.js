import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import RelationsAdvancedSearch from 'adminPanel/adminContent/fundsManagers/relations/containers/relationsAdvancedSearch';
import 'adminPanel/adminContent/relations/components/relationsSearchView/index.scss';

const RelationsSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isAdvancedSearchVisible,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  toggleAdvancedSearch,
  relationsFilters,
  handleFilterRemoveClick,
  selectedRole,
  selectedCompany,
}) => (
  <div className="adminRelations-search">
    <div className="adminRelations-search__top">
      <div className="adminRelations-search__top-left">
        <div className="adminRelations-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={relationsFilters.search}
          />
        </div>
        <div className="adminRelations-search__filters-button">
          <ToggleMoreFiltersButton
            handleToggleMoreFiltersClick={toggleAdvancedSearch}
            isMoreFiltersVisible={isAdvancedSearchVisible}
          />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="adminRelations-search__clear-filters-button">
          <div className="adminRelations-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="adminRelations-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    {isAdvancedSearchVisible && (
      <RelationsAdvancedSearch
        selectedRole={selectedRole}
        selectedCompany={selectedCompany}
      />
    )}
    <div className="adminRelations-search__results-container">
      <div className="adminRelations-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

RelationsSearchView.defaultProps = {
  resultsNumber: null,
};

RelationsSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isAdvancedSearchVisible: PropTypes.bool.isRequired,
  toggleAdvancedSearch: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default RelationsSearchView;
