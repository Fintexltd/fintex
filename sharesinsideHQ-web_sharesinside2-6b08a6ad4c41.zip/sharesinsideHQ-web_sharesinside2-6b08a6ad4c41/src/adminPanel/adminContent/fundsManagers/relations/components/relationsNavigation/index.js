import React, { Component } from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import 'adminPanel/adminContent/relations/components/relationsNavigation/style.scss';

// NOTE: Here I define sizes necessary to calculate correct adminRelations
// navigation width
const barAndMarginsWidth = 420;
const largeBreakpointWidth = 992;
const wideScreen = 1540;

class RelationsNavigation extends Component {
  constructor() {
    super();
    this.state = {
      width: null,
    };
    this.navRef = React.createRef();
  }

  componentDidMount() {
    this.setScreenWidth();
    window.addEventListener('resize', this.setScreenWidth);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.setScreenWidth);
  }

  setScreenWidth = () => {
    this.setState({ width: window.innerWidth });
  };

  render() {
    if (window.innerWidth < 500) {
      this.navRef.current.scrollLeft = '140';
    }
    return (
      <div
        ref={this.navRef}
        className="adminRelations-navigation"
        style={{
          width:
            this.state.width >= largeBreakpointWidth &&
            this.state.width < wideScreen
              ? this.state.width - barAndMarginsWidth
              : '100%',
        }}
      >
        {this.props.userData &&
          this.props.userData.relations_funds_manager &&
          ((this.props.userData.relations_funds_manager.primary_admin &&
            this.props.userData.relations_funds_manager.primary_admin.includes(
              this.props.selectedFundsManagerId,
            )) ||
            this.props.userData.is_global_admin) && (
            <LinkContainer
              to="/admin/fundsmanager/relations/admins"
              replace
              className="adminRelations-navigation__item"
              activeClassName="adminRelations-navigation__item--active"
            >
              <span>
                Admins( 
                {' '}
                {this.props.roles ? this.props.roles.admins : 0}
                )
              </span>
            </LinkContainer>
          )}
        {this.props.userData &&
          this.props.userData.relations_funds_manager &&
          ((this.props.userData.relations_funds_manager.primary_admin &&
            this.props.userData.relations_funds_manager.primary_admin.includes(
              this.props.selectedFundsManagerId,
            )) ||
            (this.props.userData.relations_funds_manager.secondary_admin &&
              this.props.userData.relations_funds_manager.secondary_admin.includes(
                this.props.selectedFundsManagerId,
              )) ||
            this.props.userData.is_global_admin) && (
            <>
              <LinkContainer
                to="/admin/fundsmanager/relations/editor"
                replace
                className="adminRelations-navigation__item"
                activeClassName="adminRelations-navigation__item--active"
              >
                <span>
                  Editors( 
                  {' '}
                  {this.props.roles ? this.props.roles.editors : 0}
                  )
                </span>
              </LinkContainer>
              <LinkContainer
                to="/admin/fundsmanager/relations/vip"
                replace
                className="adminRelations-navigation__item"
                activeClassName="adminRelations-navigation__item--active"
              >
                <span>
                  Vips( 
                  {' '}
                  {this.props.roles ? this.props.roles.vips : 0}
                  )
                </span>
              </LinkContainer>
              <LinkContainer
                to="/admin/fundsmanager/relations/investor"
                replace
                className="adminRelations-navigation__item"
                activeClassName="adminRelations-navigation__item--active"
              >
                <span>
                  Investors(
                  {' '}
                  {this.props.roles ? this.props.roles.shareholders : 0}
                  )
                </span>
              </LinkContainer>
            </>
          )}
      </div>
    );
  }
}

export default RelationsNavigation;
