import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import shortid from 'shortid';
import { checkUserPermission } from 'userAuth/utils/permissions';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import 'adminPanel/adminContent/relations/components/relationsView/index.scss';
import './styles.scss';

const isAnyAdmin = userGroup =>
  userGroup &&
  (userGroup.includes('secondary_admin') ||
    userGroup.includes('primary_admin') ||
    userGroup.includes('global_admin'));

const isPrimaryOrGlobalAdmin = userGroup =>
  userGroup &&
  (userGroup.includes('primary_admin') || userGroup.includes('global_admin'));

const RelationAdminView = ({
  removeRelation,
  handleCheckboxClick,
  checkedRelations,
  userData,
  relation,
}) => (
  <tr key={shortid.generate()} className="adminRelations__relation-row">
    <td>
      <div className="adminRelations__user-data">
        <AcceptCheckbox
          name={`${relation.id}`}
          id={`${relation.id}`}
          onChange={e => handleCheckboxClick(e, relation.type)}
          disabled={relation.type === 'primary_admin'}
          checked={
            relation.type === 'primary_admin'
              ? false
              : checkedRelations.includes(relation.id)
          }
        />
        <div>
          <p className="adminRelations__name">{relation.name}</p>
          <p className="adminRelations__name">{relation.email}</p>
        </div>
      </div>
    </td>
    {userData &&
      checkUserPermission(
        userData,
        PERMISSIONS_FUNCTION_TYPES.VIEW_USER_LOGIN_DATA,
      ) && (
        <td>
          <p className="adminRelations__name">
            {relation.type === 'primary_admin' ||
            relation.type === 'secondary_admin'
              ? relation.type
                  .split('_')
                  .join(' ')
                  .charAt(0)
                  .toUpperCase() +
                relation.type
                  .split('_')
                  .join(' ')
                  .slice(1)
              : ''}
          </p>
          <p className="adminRelations__name">{relation.country_name}</p>
          <p className="adminRelations__name">
            {relation.login_method && relation.login_method[0]
              ? relation.login_method[0].charAt(0).toUpperCase() +
                relation.login_method[0].slice(1)
              : ''}
            {relation.login_method && relation.login_method[1]
              ? `, ${relation.login_method[1].charAt(0).toUpperCase() +
                  relation.login_method[1].slice(1)}`
              : ''}
          </p>
          <p className="adminRelations__name">
            Accept terms:{' '}
            {moment.unix(relation.accepted_terms).format('DD.MM.YY')}
          </p>
        </td>
      )}
    <td>
      {relation.type !== 'primary_admin' && (
        <div className="adminRelations__buttons">
          <button
            onClick={() => removeRelation(relation.id)}
            className="adminRelations__button adminRelations__button--remove"
          >
            Remove
          </button>
        </div>
      )}
    </td>
  </tr>
);

const RelationEditorView = ({
  removeRelation,
  handleCheckboxClick,
  checkedRelations,
  userData,
  relation,
}) => (
  <tr key={shortid.generate()} className="adminRelations__relation-row">
    <td>
      <div className="adminRelations__user-data">
        <p className="adminRelations__name">{relation.name}</p>
      </div>
      <div className="adminRelations__user-data">
        <p className="adminRelations__name">{relation.email}</p>
      </div>
    </td>
    {userData &&
      checkUserPermission(
        userData,
        PERMISSIONS_FUNCTION_TYPES.VIEW_USER_LOGIN_DATA,
      ) && (
        <td>
          <p className="adminRelations__name">{relation.country_name}</p>
          <p className="adminRelations__name">
            {relation.login_method && relation.login_method[0]
              ? relation.login_method[0].charAt(0).toUpperCase() +
                relation.login_method[0].slice(1)
              : ''}
            {relation.login_method && relation.login_method[1]
              ? `, ${relation.login_method[1].charAt(0).toUpperCase() +
                  relation.login_method[1].slice(1)}`
              : ''}
          </p>
          <p className="adminRelations__name">
            Accept terms:{' '}
            {moment.unix(relation.accepted_terms).format('DD.MM.YY')}
          </p>
        </td>
      )}
    <td>
      {relation.relations.map(fundRelation => (
        <div className="adminRelations__fund-data">
          <AcceptCheckbox
            name={`${fundRelation.id}`}
            id={`${fundRelation.id}`}
            onChange={e => handleCheckboxClick(e, fundRelation.type)}
            checked={checkedRelations.includes(fundRelation.id)}
          >
            <p
              style={{
                fontWeight:
                  fundRelation.entitiable_type === 'fund' ? 'normal' : 'bold',
              }}
            >
              {fundRelation.name}
            </p>
          </AcceptCheckbox>
          <div className="adminRelations__buttons">
            <button
              onClick={() => removeRelation(fundRelation.id)}
              className="adminRelations__button adminRelations__button--remove"
            >
              Remove
            </button>
          </div>
        </div>
      ))}
    </td>
  </tr>
);

const RelationsView = ({
  relations,
  removeRelation,
  handleCheckboxClick,
  checkedRelations,
  isRelationsFiltersActive,
  handleClickNewRole,
  roleType,
  userData,
  userGroup,
}) => (
  <Fragment>
    <table className="adminRelations__table">
      <thead className="adminRelations__thead">
        <tr>
          <th>User data</th>
          {userData &&
            checkUserPermission(
              userData,
              PERMISSIONS_FUNCTION_TYPES.VIEW_USER_LOGIN_DATA,
            ) && <th />}
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {(((roleType === 'vip' || roleType === 'editor') &&
          isAnyAdmin(userGroup)) ||
          (roleType === 'admins' && isPrimaryOrGlobalAdmin(userGroup))) && (
          <tr>
            <td className="adminRelations__add" colSpan={8}>
              <div
                className="adminRelations__add-container"
                onClick={() => handleClickNewRole(roleType)}
                role="presentation"
              >
                <h2>
                  + ADD NEW {roleType === 'vip' ? 'VIP' : null}
                  {roleType === 'admins' ? 'FUNDS MANAGER ADMIN' : null}
                  {roleType === 'editor' ? 'EDITOR' : null}
                </h2>
              </div>
            </td>
          </tr>
        )}

        {relations.map(
          relation =>
            relation.id ? (
              <RelationAdminView
                key={relation.id}
                removeRelation={removeRelation}
                handleCheckboxClick={handleCheckboxClick}
                checkedRelations={checkedRelations}
                userData={userData}
                relation={relation}
              />
            ) : (
              <RelationEditorView
                key={relation.email}
                removeRelation={removeRelation}
                handleCheckboxClick={handleCheckboxClick}
                checkedRelations={checkedRelations}
                userData={userData}
                relation={relation}
              />
            ),
        )}
      </tbody>
    </table>
    {isRelationsFiltersActive() &&
      relations.length === 0 && (
        <div className="adminRelations__empty-list">
          <p className="adminRelations__empty-list-message">
            There are no relations matching these criteria
          </p>
        </div>
      )}
  </Fragment>
);

RelationsView.propTypes = {
  relations: PropTypes.arrayOf(PropTypes.object).isRequired,
  checkedRelations: PropTypes.arrayOf(PropTypes.number).isRequired,
};

export default RelationsView;
