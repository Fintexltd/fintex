import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {
  fetchFundsManagersList,
  updateFundsManagersList,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagersListActions';
import { deleteFundsManagers } from 'adminPanel/api/fundsManagersApi';
import { checkUserPermission } from 'userAuth/utils/permissions';
import RemoveModal from 'common/components/removeModal';
import RemoveButton from 'common/components/removeButton';
import CheckButton from 'common/components/checkButton';
import ClearButton from 'common/components/clearButton';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import FundsManagerItem from 'adminPanel/adminContent/fundsManagers/fundsManagersManagement/components/fundsManagerItem';
import AddFundsManagerButton from './components/addFundsManagerButton';
import FundsManagersManagementSearch from './containers/fundsManagersManagementSearch';

const mapStateToProps = (state) => ({
  adminFundsManagersList: state.adminFundsManagers.list,
  fundsManagersFilters: state.adminFundsManagersFilters,
  nextPageIndex: state.adminFundsManagers.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsManagersList: bindActionCreators(fetchFundsManagersList, dispatch),
  updateFundsManagersList: bindActionCreators(
    updateFundsManagersList,
    dispatch,
  ),
});

class FundsManagersManagement extends Component {
  constructor() {
    super();
    this.state = {
      fundsManagersToRemove: [],
      fundsManagerToRemoveId: null,
      isRemoveFundsManagerModalVisible: false,
      isRemoveMultipleFundsManagersModalVisible: false,
      isLoadMoreClicked: false,
    };
  }

  componentDidMount() {
    this.props.getFundsManagersList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  getFundsManagersIfNecessary = () => {
    if (this.props.nextPageIndex) {
      this.handleLoadMoreClick(this.props.nextPageIndex);
    }
  };

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () =>
        this.props.getFundsManagersList(this.props.nextPageIndex),
      );
    }
  };

  handleCheckAllFundsManagersClick = () => {
    const ids = this.isRemoveFundsManagerAllowed()
      ? this.props.adminFundsManagersList.map((fundsManager) => fundsManager.id)
      : [];
    this.setState({ fundsManagersToRemove: ids });
  };

  handleFundsManagerCheckboxClick = (value) => {
    const { checked, id } = value.target;
    this.setState((prevState) => {
      let checkedFundsManagers = prevState.fundsManagersToRemove;
      if (checked) {
        checkedFundsManagers.push(Number(id));
      } else {
        checkedFundsManagers = prevState.fundsManagersToRemove.filter(
          (fundsManagerId) => fundsManagerId !== Number(id),
        );
      }
      return { fundsManagersToRemove: checkedFundsManagers };
    });
  };

  handleClearSelectionClick = () => {
    this.setState({ fundsManagersToRemove: [] });
  };

  toggleRemoveFundsManagerModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveFundsManagerModalVisible: !prevState.isRemoveFundsManagerModalVisible,
    }));
  };

  toggleRemoveMultipleFundsManagersModalOpen = () => {
    this.setState((prevState) => ({
      isRemoveMultipleFundsManagersModalVisible: !prevState.isRemoveMultipleFundsManagersModalVisible,
    }));
  };

  handleRemoveFundsManagersClick = () => {
    this.toggleRemoveMultipleFundsManagersModalOpen();
  };

  handleRemoveFundsManagerClick = (id) => {
    this.setState({ fundsManagerToRemoveId: id });
    this.toggleRemoveFundsManagerModalOpen();
  };

  removeFundsManager = () => {
    deleteFundsManagers([this.state.fundsManagerToRemoveId]).then(() => {
      this.props.updateFundsManagersList(
        this.props.adminFundsManagersList.filter(
          (item) => item.id !== this.state.fundsManagerToRemoveId,
        ),
      );
      this.setState({ fundsManagerToRemoveId: null });
      this.toggleRemoveFundsManagerModalOpen();
    });
  };

  removeFundsManagers = () => {
    const removeAllVisible =
      this.state.fundsManagersToRemove.length ===
      this.props.adminFundsManagersList.length;
    deleteFundsManagers(this.state.fundsManagersToRemove).then(() => {
      this.props.updateFundsManagersList(
        this.props.adminFundsManagersList.filter(
          (item) => !this.state.fundsManagersToRemove.includes(item.id),
        ),
      );
      this.setState({ fundsManagersToRemove: [] });
      this.toggleRemoveMultipleFundsManagersModalOpen();
      if (removeAllVisible) {
        this.getFundsManagersIfNecessary();
      }
    });
  };

  isRemovePermissionExists = () =>
    this.props.userData &&
    checkUserPermission(
      this.props.userData,
      PERMISSIONS_FUNCTION_TYPES.REMOVE_FUNDS_MANAGER,
    );

  isRemoveFundsManagerAllowed = () =>
    this.props.userData.is_global_admin || this.props.userData.is_content_admin;

  render() {
    return (
      <div className="admin-management-container">
        <h2 className="admin-management-container__heading">
          Fund-Manager Management
        </h2>
        <FundsManagersManagementSearch />
        {this.isRemovePermissionExists() && (
          <div className="admin-management__buttons">
            {this.state.fundsManagersToRemove.length !==
              this.props.adminFundsManagersList.length && (
              <CheckButton
                description="Check all"
                handleClick={this.handleCheckAllFundsManagersClick}
              />
            )}
            {this.state.fundsManagersToRemove.length > 0 && (
              <div className="admin-management__clear-button">
                <ClearButton
                  description="Clear selection"
                  handleClick={this.handleClearSelectionClick}
                />
              </div>
            )}
            {this.state.fundsManagersToRemove.length > 0 && (
              <RemoveButton
                description="Remove checked"
                handleRemoveClick={this.handleRemoveFundsManagersClick}
              />
            )}
          </div>
        )}
        <div className="row">
          <div className="admin-management-item admin-management__add-item">
            <AddFundsManagerButton />
          </div>
          {this.props.adminFundsManagersList.length > 0 &&
            this.props.adminFundsManagersList.map((item) => (
              <div className="admin-management__company-item" key={item.id}>
                <FundsManagerItem
                  fundsManager={item}
                  removeFundsManager={this.handleRemoveFundsManagerClick}
                  handleCheckboxClick={this.handleFundsManagerCheckboxClick}
                  isChecked={
                    this.state.fundsManagersToRemove.indexOf(item.id) > -1
                  }
                  isRemoveFundsManagerAllowed={this.isRemoveFundsManagerAllowed}
                />
              </div>
            ))}
        </div>
        <div className="row">
          {this.props.nextPageIndex && (
            <div className="admin-management__load-container">
              <button
                onClick={this.handleLoadMoreClick}
                className="admin-management__load"
              >
                Load more
              </button>
            </div>
          )}
        </div>
        {this.state.isRemoveFundsManagerModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this Fund-Manager?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFundsManager}
            handleCancelClick={this.toggleRemoveFundsManagerModalOpen}
          />
        )}
        {this.state.isRemoveMultipleFundsManagersModalVisible && (
          <RemoveModal
            heading={`Are You sure you want to remove these fundsManagers (${
              this.state.fundsManagersToRemove.length
            } ${
              this.state.fundsManagersToRemove.length > 1
                ? 'elements'
                : 'element'
            })?`}
            message="This items will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFundsManagers}
            handleCancelClick={this.toggleRemoveMultipleFundsManagersModalOpen}
          />
        )}
      </div>
    );
  }
}

FundsManagersManagement.defaultProps = {
  adminFundsManagersList: [],
  nextPageIndex: null,
};

FundsManagersManagement.propTypes = {
  adminFundsManagersList: PropTypes.arrayOf(PropTypes.object),
  /*
  fundsManagersFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ).isRequired,
  */
  getFundsManagersList: PropTypes.func.isRequired,
  updateFundsManagersList: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagersManagement);
