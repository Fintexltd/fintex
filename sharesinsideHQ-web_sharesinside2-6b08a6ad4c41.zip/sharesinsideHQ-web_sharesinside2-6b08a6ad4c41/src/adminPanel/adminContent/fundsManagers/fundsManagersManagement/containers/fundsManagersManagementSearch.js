import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import { fetchFundsManagersList } from 'adminPanel/redux/actions/funds/admin/adminFundsManagersListActions';
import {
  removeAdminFundsManagersFilters,
  saveAdminFundsManagersSearch,
  saveAdminFundsManagersFilters,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagersFiltersActions';
import FundsManagersManagementSearchView from '../components/fundsManagersManagementSearchView';

const mapStateToProps = (state) => ({
  resultsNumber: state.adminFundsManagers.resultsNumber,
  fundsManagersFilters: state.adminFundsManagersFilters,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsManagersList: bindActionCreators(fetchFundsManagersList, dispatch),
  removeFundsManagersFilters: bindActionCreators(
    removeAdminFundsManagersFilters,
    dispatch,
  ),
  saveFundsManagersSearch: bindActionCreators(
    saveAdminFundsManagersSearch,
    dispatch,
  ),
  saveFundsManagersFilters: bindActionCreators(
    saveAdminFundsManagersFilters,
    dispatch,
  ),
});

class FundsManagersManagementSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsManagersList = debounce(
      props.getFundsManagersList,
      500,
    );
    this.state = {
      isAdvancedSearchVisible: false,
    };
  }

  toggleAdvancedSearch = () => {
    this.setState((prevState) => ({
      isAdvancedSearchVisible: !prevState.isAdvancedSearchVisible,
    }));
  };

  clearActiveFilters = () => {
    this.props.removeFundsManagersFilters();
    this.debouncedGetFundsManagersList();
  };

  handleSearchInputChange = (text) => {
    this.props.saveFundsManagersSearch(text);
    this.debouncedGetFundsManagersList();
  };

  mapActiveFiltersLists = () => [
    ...this.props.fundsManagersFilters.fundCountry,
    ...this.props.fundsManagersFilters.fundType,
    ...this.props.fundsManagersFilters.currency,
    ...this.props.fundsManagersFilters.fundContinent,
    ...this.props.fundsManagersFilters.fundsManagerCountry,
    ...this.props.fundsManagersFilters.fundsManagerContinent,
  ];

  handleFilterRemoveClick = (label, category) => {
    const filteredOut = this.props.fundsManagersFilters[category].filter(
      (el) => el.label !== label,
    );
    this.props.saveFundsManagersFilters(
      filteredOut.length > 0 ? filteredOut : { category },
    );
    this.debouncedGetFundsManagersList();
  };

  isRemoveFiltersButtonVisible = () => this.mapActiveFiltersLists().length > 0;

  render() {
    return (
      <FundsManagersManagementSearchView
        resultsNumber={this.props.resultsNumber}
        handleSearchInputChange={this.handleSearchInputChange}
        toggleAdvancedSearch={this.toggleAdvancedSearch}
        isAdvancedSearchVisible={this.state.isAdvancedSearchVisible}
        clearActiveFilters={this.clearActiveFilters}
        activeFiltersList={this.mapActiveFiltersLists()}
        fundsManagersFilters={this.props.fundsManagersFilters}
        handleFilterRemoveClick={this.handleFilterRemoveClick}
        isRemoveFiltersButtonVisible={this.isRemoveFiltersButtonVisible}
      />
    );
  }
}

FundsManagersManagementSearch.defaultProps = {
  resultsNumber: null,
};

FundsManagersManagementSearch.propTypes = {
  getFundsManagersList: PropTypes.func.isRequired,
  resultsNumber: PropTypes.number,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagersManagementSearch);
