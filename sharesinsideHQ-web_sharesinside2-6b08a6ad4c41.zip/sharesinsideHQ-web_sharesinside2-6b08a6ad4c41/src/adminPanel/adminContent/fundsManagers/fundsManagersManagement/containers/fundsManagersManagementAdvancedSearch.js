import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import debounce from 'lodash/debounce';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchFundTypesList from 'common/redux/actions/fundTypesListActions';
import fetchCurrenciesList from 'common/redux/actions/currenciesListActions';
import { fetchFundsManagersList } from 'adminPanel/redux/actions/funds/admin/adminFundsManagersListActions';
import {
  saveAdminFundsManagersFilters,
  saveAdminFundsManagersActiveCheckbox,
  saveAdminFundsManagersPassiveCheckbox,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagersFiltersActions';
import FundsManagersManagementAdvancedSearchView from '../components/fundsManagersManagementAdvancedSearchView';

const mapStateToProps = state => ({
  countriesList: state.countries.list,
  continentsList: state.continents.list,
  fundTypesList: state.fundTypes.list,
  currenciesList: state.currencies.list,
  fundsManagersFilters: state.adminFundsManagersFilters,
});

const mapDispatchToProps = dispatch => ({
  getFundsManagersList: bindActionCreators(fetchFundsManagersList, dispatch),
  getCountriesList: bindActionCreators(fetchCountriesList, dispatch),
  getContinentsList: bindActionCreators(fetchContinentsList, dispatch),
  getCurrenciesList: bindActionCreators(fetchCurrenciesList, dispatch),
  getFundTypesList: bindActionCreators(fetchFundTypesList, dispatch),
  saveFundsManagersFilters: bindActionCreators(
    saveAdminFundsManagersFilters,
    dispatch,
  ),
  saveFundsManagersActiveCheckbox: bindActionCreators(
    saveAdminFundsManagersActiveCheckbox,
    dispatch,
  ),
  saveFundsManagersPassiveCheckbox: bindActionCreators(
    saveAdminFundsManagersPassiveCheckbox,
    dispatch,
  ),
});

class FundsManagersManagementAdvancedSearch extends Component {
  constructor(props) {
    super(props);
    this.debouncedGetFundsManagersList = debounce(
      props.getFundsManagersList,
      500,
    );
  }

  componentDidMount() {
    this.props.getCountriesList();
    this.props.getContinentsList();
    this.props.getCurrenciesList();
    this.props.getFundTypesList();
  }

  handleFilterUsage = (values, category) => {
    this.props.saveFundsManagersFilters(
      values.length > 0 ? values : { category },
    );
    this.debouncedGetFundsManagersList();
  };

  handleCheckboxChange = value => {
    switch (value.target.name) {
      case 'active':
        this.props.saveFundsManagersActiveCheckbox(value.target.checked);
        break;
      case 'passive':
        this.props.saveFundsManagersPassiveCheckbox(value.target.checked);
        break;
      default:
        break;
    }
    this.debouncedGetFundsManagersList();
  };

  render() {
    return (
      <FundsManagersManagementAdvancedSearchView
        fundsManagerCountriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'fundsManagerCountry',
        })}
        fundsManagerContinentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'fundsManagerContinent',
        })}
        countriesList={mapObjPropsToSelectFilter({
          list: this.props.countriesList,
          label: 'country_name',
          value: 'id',
          category: 'fundCountry',
        })}
        continentsList={mapObjPropsToSelectFilter({
          list: this.props.continentsList,
          label: 'continent_name',
          value: 'id',
          category: 'fundContinent',
        })}
        currenciesList={mapObjPropsToSelectFilter({
          list: this.props.currenciesList,
          label: 'currency_symbol',
          value: 'id',
          category: 'currency',
        })}
        fundTypesList={mapObjPropsToSelectFilter({
          list: this.props.fundTypesList,
          label: 'name',
          value: 'id',
          category: 'fundType',
        })}
        handleFilterUsage={this.handleFilterUsage}
        fundsManagersFilters={this.props.fundsManagersFilters}
        handleCheckboxChange={this.handleCheckboxChange}
      />
    );
  }
}

FundsManagersManagementAdvancedSearch.defaultProps = {
  countriesList: [],
  continentsList: [],
  currenciesList: [],
  fundTypesList: [],
};

FundsManagersManagementAdvancedSearch.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  currenciesList: PropTypes.arrayOf(PropTypes.object),
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  getCountriesList: PropTypes.func.isRequired,
  getContinentsList: PropTypes.func.isRequired,
  getCurrenciesList: PropTypes.func.isRequired,
  getFundTypesList: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagersManagementAdvancedSearch);
