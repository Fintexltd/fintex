import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import RemoveModal from 'common/components/removeModal';
import {
  fetchAdminFundsManager,
  removeAdminFundsManager,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagersActions';
import { updateFundsManagerData } from 'adminPanel/adminContent/fundsManagers/fundsManagerCreator/api/fundsManagerCreatorApi';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchLocationData from 'common/redux/actions/locationDataActions.js';
import fetchCountryCallingCodesList from 'common/redux/actions/countryCallingCodesListActions';
import { disableScroll } from 'common/utils/disableScroll';
import { deleteFundsManagers } from 'adminPanel/api/fundsManagersApi';
import FundsManagerBaseInfoEditModal from 'common/components/fundsManager/fundsManagerBaseInfoEditModal';
import FundsManagerTitleEdit from 'common/components/fundsManager/fundsManagerTitleEdit';
import FundsManagerHeaderEdit from 'common/components/fundsManager/fundsManagerHeaderEdit';
import FundsManagerNavigation from 'common/components/fundsManager/fundsManagerNavigation';
import {
  isFundsManagerEditor,
  isFundsManagersSecondaryOrPrimaryAdmin,
} from 'userAuth/utils/permissions';
import Team from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam';
import AddFundEvent from 'adminPanel/adminContent/fundsManagers/addFundsManagerEvent';
import EditFundEvent from 'adminPanel/adminContent/fundsManagers/editFundsManagerEvent';
import Documents from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments';
import FundsContent from 'adminPanel/adminContent/funds/containers/fundsContent';
import FundsManagerAbout from '../components/fundsManagerAbout';
import FundsManagerEditAbout from '../components/fundsManagerEditAbout';
import FundsManagerNewsContent from '../../fundsManagerNews/containers/fundsManagerNewsContent';
import AddFundsManagerNews from '../../addFundsManagerNews';
import EventsContent from '../../fundsManagerEvents/containers/eventsContent';

const mapStateToProps = (state) => ({
  fundsManager: state.adminFundsManager.currentFundsManager,
  locationData: state.locationData.results,
  countriesList: state.countries.list,
  countryCallingCodesList: state.countryCallingCodes.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFundsManager: bindActionCreators(fetchAdminFundsManager, dispatch),
  removeAdminFundsManager: bindActionCreators(
    removeAdminFundsManager,
    dispatch,
  ),
  fetchLocationData: (adress) => dispatch(fetchLocationData(adress)),
  getCountriesList: () => dispatch(fetchCountriesList()),
  getCountryCallingCodesList: () => dispatch(fetchCountryCallingCodesList()),
});

class FundsManagerManagement extends Component {
  constructor() {
    super();
    this.state = {
      isBaseInfoEditModalVisible: false,
      isRemoveFundsManagerModalVisible: false,
      excludedCountries: [],
      termsAndConditions: [],
      termsAndConditionsLinks: [],
      deleteAttachments: [],
      deleteLinks: [],
      termsAndConditionsError: '',
    };
  }

  componentDidMount() {
    this.props.removeAdminFundsManager();
    this.props.getAdminFundsManager(this.props.match.params.id);
    this.props.getCountriesList();
    this.props.getCountryCallingCodesList();
  }

  onTermLinkAdded = (addedLink, previousLink, previousFile) => {
    this.setState((prevState) => ({
      termsAndConditionsLinks: [addedLink],
      termsAndConditions: [],
      deleteAttachments:
        previousFile && previousFile.id
          ? [...prevState.deleteAttachments, previousFile.id]
          : prevState.deleteAttachments,
      deleteLinks:
        previousLink && previousLink.id
          ? [...prevState.deleteLinks, previousLink.id]
          : prevState.deleteLinks,
    }));
  };

  onTermTokenAdded = (newToken, previousLink, previousFile) => {
    this.setState((prevState) => ({
      termsAndConditions: [newToken],
      termsAndConditionsLinks: [],
      deleteAttachments:
        previousFile && previousFile.id
          ? [...prevState.deleteAttachments, previousFile.id]
          : prevState.deleteAttachments,
      deleteLinks:
        previousLink && previousLink.id
          ? [...prevState.deleteLinks, previousLink.id]
          : prevState.deleteLinks,
    }));
  };

  onTermLinkRemoved = (link) => {
    this.setState((prevState) => ({
      termsAndConditionsLinks: [],
      deleteLinks: link.id
        ? [...prevState.deleteLinks, link.id]
        : prevState.deleteLinks,
    }));
  };

  onTermTokenRemoved = (token) => {
    this.setState((prevState) => ({
      termsAndConditions: [],
      deleteAttachments: token.id
        ? [...prevState.deleteAttachments, token.id]
        : prevState.deleteAttachments,
    }));
  };

  getBaseInfoFormInitialValues = () => {
    const {
      name,
      phone,
      email,
      address,
      website,
      excluded,
      country_calling_code,
    } = this.props.fundsManager;

    return {
      name,
      phone: phone || '',
      email: email || '',
      address,
      website,
      excluded,
      country_calling_code: country_calling_code && country_calling_code.id,
    };
  };

  setCountryToExclude = (values) => {
    this.setState({
      excludedCountries: values,
    });
  };

  handleExcludedCountryRemoveClick = (label) => {
    this.setState((prevState) => ({
      excludedCountries: prevState.excludedCountries.filter(
        (el) => el.label !== label,
      ),
    }));
  };

  removeTermsAndConditionsError = () =>
    this.setState({ termsAndConditionsError: '' });

  submitBaseInfoForm = (values, actions) => {
    const {
      name,
      phone,
      title,
      description,
      email,
      address,
      website,
      country_calling_code,
    } = values;

    const {
      termsAndConditions,
      termsAndConditionsLinks,
      deleteAttachments,
      deleteLinks,
    } = this.state;

    if (
      !(
        deleteAttachments.length ||
        deleteLinks.length ||
        termsAndConditions.length ||
        termsAndConditionsLinks.length
      ) ||
      // eslint-disable-next-line
      ((deleteAttachments.length || deleteLinks.length) &&
        // eslint-disable-next-line
        (termsAndConditions.length || termsAndConditionsLinks.length))
    ) {
      updateFundsManagerData(this.props.fundsManager.id, {
        name,
        phone,
        email,
        address,
        website,
        description,
        title,
        country_calling_code_id: country_calling_code,
        latitude: this.props.locationData
          ? this.props.locationData.lat
          : this.props.fundsManager.latitude,
        longitude: this.props.locationData
          ? this.props.locationData.lng
          : this.props.fundsManager.longitude,
        excluded: this.state.excludedCountries.map((item) => item.value),
        terms_and_conditions: termsAndConditions,
        terms_and_conditions_links: termsAndConditionsLinks,
        delete_attachments: deleteAttachments,
        delete_links: deleteLinks,
      })
        .then(() => {
          this.props.getAdminFundsManager(this.props.fundsManager.id);
          this.toggleBaseInfoEditModal();
        })
        .catch(() => {
          actions.setErrors({
            submit: 'There was an error submitting the form.',
          });
          actions.setSubmitting(false);
        });
    } else {
      actions.setSubmitting(false);
      this.setState({
        termsAndConditionsError: 'This field cannot be empty',
      });
    }
  };

  toggleBaseInfoEditModal = () => {
    this.setState(
      (prevState) => ({
        isBaseInfoEditModalVisible: !prevState.isBaseInfoEditModalVisible,
        excludedCountries: mapObjPropsToSelectFilter({
          list: this.props.fundsManager.excluded,
          label: 'country_name',
          value: 'id',
          category: 'country',
        }),
        termsAndConditions: [],
        termsAndConditionsLinks: [],
        deleteAttachments: [],
        deleteLinks: [],
      }),
      () => disableScroll(this.state.isBaseInfoEditModalVisible),
    );
  };

  updateFundsManagerHeaderData = (data) => {
    updateFundsManagerData(this.props.fundsManager.id, data).then(() => {
      this.props.getAdminFundsManager(this.props.fundsManager.id);
    });
  };

  toggleRemoveModalOpenClick = () => {
    this.setState(
      (prevState) => ({
        isRemoveFundsManagerModalVisible: !prevState.isRemoveFundsManagerModalVisible,
      }),
      () => disableScroll(this.state.isRemoveFundsManagerModalVisible),
    );
  };

  removeFundsManager = () => {
    deleteFundsManagers([this.props.fundsManager.id]).then(() => {
      this.toggleRemoveModalOpenClick();
      this.props.history.push('/admin/fundsmanager/management');
    });
  };

  handleLocationData = (e) => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      const adress = e.target.value;
      this.props.fetchLocationData(adress);
    }, 1000);
  };

  render() {
    const AboutWithProps = (props) => (
      <FundsManagerAbout
        userData={this.props.userData}
        fundsManager={this.props.fundsManager}
        {...props}
      />
    );

    const EditAboutWithProps = (props) => (
      <FundsManagerEditAbout
        userData={this.props.userData}
        fundsManager={this.props.fundsManager}
        {...props}
      />
    );

    const TeamWithProps = (props) => (
      <Team
        userData={this.props.userData}
        fundsManagerId={this.props.fundsManager.id}
        {...props}
      />
    );

    const FundsContentWithProps = (props) => (
      <FundsContent fundsManagerId={this.props.fundsManager.id} {...props} />
    );

    const NewsContentWithProps = (props) => (
      <FundsManagerNewsContent
        fundsManagerId={this.props.fundsManager.id}
        {...props}
      />
    );

    const AddNewsWithProps = (props) => (
      <AddFundsManagerNews fundsManager={this.props.fundsManager} {...props} />
    );

    const EventsWithProps = (props) => (
      <EventsContent fundsManagerId={this.props.fundsManager.id} {...props} />
    );

    return (
      <>
        <FundsManagerTitleEdit
          openEditModal={this.toggleBaseInfoEditModal}
          openRemoveModal={this.toggleRemoveModalOpenClick}
          userData={this.props.userData}
          fundsManagerId={this.props.fundsManager.id}
        />
        <FundsManagerHeaderEdit
          fundsManager={this.props.fundsManager}
          userData={this.props.userData}
          updateFundsManagerHeaderData={this.updateFundsManagerHeaderData}
        />
        {this.state.isRemoveFundsManagerModalVisible && (
          <RemoveModal
            heading="Are You sure you want to remove this fund-Manager?"
            message="This item will be deleted immediately. You can't undo this action."
            handleRemoveClick={this.removeFundsManager}
            handleCancelClick={this.toggleRemoveModalOpenClick}
          />
        )}
        <FundsManagerNavigation
          fundsManager={this.props.fundsManager}
          path={`/admin/fundsmanager/manage/${this.props.fundsManager.id}`}
          isAdminPanel
          isEditor={isFundsManagerEditor(
            this.props.userData,
            this.props.fundsManager.id,
          )}
          isSecondaryOrPrimaryAdmin={isFundsManagersSecondaryOrPrimaryAdmin(
            this.props.userData,
            this.props.fundsManager.id,
          )}
          isGlobalAdmin={this.props.userData.is_global_admin}
          isContentAdmin={this.props.userData.is_content_admin}
        />
        {this.state.isBaseInfoEditModalVisible && this.props.fundsManager && (
          <FundsManagerBaseInfoEditModal
            closeModal={this.toggleBaseInfoEditModal}
            getBaseInfoFormInitialValues={this.getBaseInfoFormInitialValues}
            submitBaseInfoForm={this.submitBaseInfoForm}
            handleLocationData={this.handleLocationData}
            setCountryToExclude={this.setCountryToExclude}
            handleExcludedCountryRemoveClick={
              this.handleExcludedCountryRemoveClick
            }
            excludedCountries={this.state.excludedCountries}
            countriesList={this.props.countriesList}
            countryCallingCodesList={this.props.countryCallingCodesList}
            onTermLinkAdded={this.onTermLinkAdded}
            onTermLinkRemoved={this.onTermLinkRemoved}
            onTermTokenAdded={this.onTermTokenAdded}
            onTermTokenRemoved={this.onTermTokenRemoved}
            removeTermsAndConditionsError={this.removeTermsAndConditionsError}
            termsAndConditionsError={this.state.termsAndConditionsError}
            initialTermFiles={this.props.fundsManager.terms_and_conditions}
            initialTermLinks={
              this.props.fundsManager.terms_and_conditions_links
            }
          />
        )}
        <Switch>
          <Route
            path="/admin/fundsmanager/manage/:id/about"
            component={AboutWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/edit-about"
            component={EditAboutWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/team"
            component={TeamWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/funds"
            component={FundsContentWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/news"
            component={NewsContentWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/add-news"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/edit-news/:newsId"
            component={AddNewsWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/events"
            component={EventsWithProps}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/add-event"
            component={AddFundEvent}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/edit-event/:eventId"
            component={EditFundEvent}
          />
          <Route
            path="/admin/fundsmanager/manage/:id/documents"
            component={Documents}
          />
        </Switch>
      </>
    );
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withRouter(FundsManagerManagement));
