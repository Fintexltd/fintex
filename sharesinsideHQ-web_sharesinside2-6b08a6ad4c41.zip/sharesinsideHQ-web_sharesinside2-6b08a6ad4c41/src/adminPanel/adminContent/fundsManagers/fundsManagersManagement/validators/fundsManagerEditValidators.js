import * as Yup from 'yup';
import { validUrl } from 'common/utils/validationUtils';

const fundsManagerEditValidationSchema = Yup.object().shape({
  name: Yup.string()
    .required('This field is required.')
    .max(64, 'Description must be shorter than 64 characters'),
  phone: Yup.string()
    .matches(
      /^\+\d*$/,
      'Phone number must be at least 8 digits long and start with a +.',
    )
    .min(9, 'Phone number must be at least 8 digits long and start with a +.')
    .max(16, 'Phone number must be at most 15 digits long and start with a +.'),

  email: Yup.string().email('This field must be a valid email'),

  address: Yup.string().required('This field is required.'),

  website: Yup.string()
    .required('This field is required.')
    .matches(validUrl, 'This field must be a valid URL'),

  country_calling_code: Yup.string().required('This field is required.'),
});

export default fundsManagerEditValidationSchema;
