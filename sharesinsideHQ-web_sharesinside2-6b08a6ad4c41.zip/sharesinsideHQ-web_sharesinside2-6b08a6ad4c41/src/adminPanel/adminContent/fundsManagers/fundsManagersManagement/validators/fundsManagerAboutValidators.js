import * as yup from 'yup';

yup.addMethod(yup.string, 'maxContext', function(max, msg) {
  return this.test({
    name: 'maxContext',
    exclusive: true,
    message: msg || `Description must be shorter than ${max} characters.`,
    test: value => !value || value.replace(/<[^>]+>/g, '').length <= max,
  });
});

yup.addMethod(yup.string, 'minContext', function(min, msg) {
  return this.test({
    name: 'minContext',
    exclusive: true,
    message: msg || `Description must have more than ${min} characters.`,
    test: value => !value || value.replace(/<[^>]+>/g, '').length >= min,
  });
});

const fundsManagerAboutFormSchema = yup.object().shape({
  title: yup.string().max(500, 'Title must be shorter than 500 symbols'),
  description: yup
    .string()
    .maxContext(20000)
    .required('This field is required.'),
});

export default fundsManagerAboutFormSchema;
