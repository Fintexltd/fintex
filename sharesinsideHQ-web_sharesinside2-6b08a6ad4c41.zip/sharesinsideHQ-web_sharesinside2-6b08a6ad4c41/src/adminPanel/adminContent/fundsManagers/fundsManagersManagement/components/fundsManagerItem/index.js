import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import TextTruncate from 'react-text-truncate';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import placeholder from 'assets/img/placeholder.png';
import './index.scss';

const FundsManagerItem = props => {
  const {
    fundsManager,
    removeFundsManager,
    handleCheckboxClick,
    isChecked,
    isRemoveFundsManagerAllowed,
  } = props;
  return (
    <div className="fundsManagers-management-item">
      <div className="fundsManagers-management-item__content">
        <div className="fundsManagers-management-item__top-container">
          {isRemoveFundsManagerAllowed() ? (
            <div
              onClick={e => e.stopPropagation()}
              onKeyPress={e => e.stopPropagation()}
              role="button"
              tabIndex="0"
              className="fundsManagers-management-item__checkbox-container"
            >
              <AcceptCheckbox
                name={`${fundsManager.id}`}
                id={`${fundsManager.id}`}
                onChange={handleCheckboxClick}
                checked={isChecked}
              />
            </div>
          ) : (
            <div />
          )}
          <div className="fundsManagers-management-item__buttons">
            <span
              className="fundsManagers-management-item__edit"
              onClick={() => {
                window.location.replace(
                  `/admin/fundsmanager/manage/${fundsManager.id}/about`,
                );
              }}
              role="presentation"
            >
              edit
            </span>
            {isRemoveFundsManagerAllowed() && (
              <button
                className="fundsManagers-management-item__remove"
                onClick={e => {
                  e.stopPropagation();
                  removeFundsManager(fundsManager.id);
                }}
              >
                delete
              </button>
            )}
          </div>
        </div>
        <Link
          to={`/admin/fundsmanager/manage/${fundsManager.id}/about`}
          className="company-item__top-container-link"
        >
          <div
            className="fundsManagers-management-item__image"
            style={{
              backgroundImage: `url(${fundsManager.logo || placeholder})`,
            }}
          />
          <h2 className="fundsManagers-management-item__name">
            <TextTruncate line={1} truncateText="…" text={fundsManager.name} />
          </h2>
          <p className="fundsManagers-management-item__country" />
        </Link>
      </div>
    </div>
  );
};

FundsManagerItem.propTypes = {
  fundsManager: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  removeFundsManager: PropTypes.func.isRequired,
  handleCheckboxClick: PropTypes.func.isRequired,
  isChecked: PropTypes.bool.isRequired,
  isRemoveFundsManagerAllowed: PropTypes.bool.isRequired,
};

export default withRouter(FundsManagerItem);
