import React, { Component, Fragment } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Button, ButtonGroup, FormGroup } from 'reactstrap';
import PropTypes from 'prop-types';
import TexEditor from 'common/components/textEditor';
import { Formik } from 'formik';
import Input from 'common/components/input';
import UploadAttachments from 'common/components/uploadAttachments';
import AddLinks from 'common/components/addLinks';
import AddLinkOrVideo from 'common/components/addLinkOrVideo';
import CircleSpinner from 'common/components/circleSpinner';
import { fetchAdminFundsManager } from 'adminPanel/redux/actions/funds/admin/adminFundsManagersActions';
import { isFundsManagerEditor } from 'userAuth/utils/permissions';
import 'adminPanel/adminContent/editAbout/index.scss';
import { updateFundsManagerData } from 'adminPanel/adminContent/fundsManagers/fundsManagerCreator/api/fundsManagerCreatorApi';
import fundsManagerAboutFormSchema from '../../validators/fundsManagerAboutValidators';

const mapDispatchToProps = dispatch => ({
  getAdminFundsManager: bindActionCreators(fetchAdminFundsManager, dispatch),
});

class FundsManagerEditAbout extends Component {
  constructor() {
    super();
    this.state = {
      initFiles: [],
      links: null,
      videoLinks: [],
      videos: [],
      delete_attachments: [],
      delete_links: [],
      isInitialStatePrepared: false,
    };
  }

  componentDidMount() {
    this.setInitialState();
    if (isFundsManagerEditor(this.props.userData, this.props.fundsManager.id)) {
      this.props.history.replace(
        `/admin/fundsmanager/manage/${this.props.fundsManager.id}/about`,
      );
    }
  }

  onVideoLinkAdded = (videoLink, previousVideoLink, previousVideo) => {
    this.setState(prevState => ({
      videoLinks: [videoLink],
      videos: [],
      delete_attachments:
        previousVideo && previousVideo.id
          ? [...prevState.delete_attachments, previousVideo.id]
          : prevState.delete_attachments,
      delete_links:
        previousVideoLink && previousVideoLink.id
          ? [...prevState.delete_links, previousVideoLink.id]
          : prevState.delete_links,
    }));
  };

  onVideoLinkRemoved = link => {
    this.setState(prevState => ({
      videoLinks: [],
      delete_links: link.id
        ? [...prevState.delete_links, link.id]
        : prevState.delete_links,
    }));
  };

  onVideoTokenAdded = (videoToken, previousVideoLink, previousVideo) => {
    this.setState(prevState => ({
      videos: [videoToken],
      videoLinks: [],
      delete_attachments:
        previousVideo && previousVideo.id
          ? [...prevState.delete_attachments, previousVideo.id]
          : prevState.delete_attachments,
      delete_links:
        previousVideoLink && previousVideoLink.id
          ? [...prevState.delete_links, previousVideoLink.id]
          : prevState.delete_links,
    }));
  };

  onVideoTokenRemoved = video => {
    this.setState(prevState => ({
      videos: [],
      delete_attachments: video.id
        ? [...prevState.delete_attachments, video.id]
        : prevState.delete_attachments,
    }));
  };

  getNewLinks = () => {
    const links = this.props.fundsManager.links
      ? this.props.fundsManager.links.map(link => link.id)
      : [];
    const linksToExclude = links.concat(this.state.delete_links);
    return this.state.links.filter(link => !linksToExclude.includes(link.id));
  };

  setInitialState = () => {
    this.setState({
      initFiles: this.props.fundsManager.attachments,
      links: this.props.fundsManager.links,
      initVideos: this.props.fundsManager.videos,
      initVideoLinks: this.props.fundsManager.video_links,
      isInitialStatePrepared: true,
    });
  };

  handleCancelClick = () => {
    this.props.history.push(
      `/admin/fundsmanager/manage/${this.props.fundsManager.id}/about`,
    );
  };

  sendFundsManagerData = values => {
    const data = {
      title: values.title,
      description: values.description || this.props.fundsManager.description,
      links: this.getNewLinks(),
      video_links: this.state.videoLinks,
      videos: this.state.videos,
      attachments: values.attachments || [],
      delete_attachments: this.state.delete_attachments,
      delete_links: this.state.delete_links,
    };

    updateFundsManagerData(this.props.fundsManager.id, data).then(() => {
      this.props.getAdminFundsManager(this.props.fundsManager.id);
      this.props.history.push(
        `/admin/fundsmanager/manage/${this.props.fundsManager.id}/about`,
      );
    });
  };

  mergeLinksArray = (objectType, values) => {
    this.setState(prevState => ({
      [objectType]: [...prevState[objectType], values],
    }));
  };

  deleteLinksArray = (objectType, values, linkToDelete) => {
    const filteredArray = this.state[objectType].filter(
      element =>
        element.name !== linkToDelete.name ||
        element.url !== linkToDelete.url ||
        element.type !== linkToDelete.type,
    );

    this.setState({ [objectType]: filteredArray }, () => {
      if (linkToDelete.id) {
        this.initFilesDelete(linkToDelete.id, 'links');
      }
    });
  };

  initFilesDelete = (id, type) => {
    this.setState({
      [`delete_${type}`]: [...this.state[`delete_${type}`], id],
    });
  };

  render() {
    const { description, title } = this.props.fundsManager;
    const { initVideos, initVideoLinks } = this.state;
    return (
      <Fragment>
        {this.props.fundsManager &&
        this.state.isInitialStatePrepared &&
        this.state.links ? (
          <Formik
            initialValues={{
              title: title || '',
              description: description || '',
            }}
            onSubmit={values => {
              this.sendFundsManagerData(values);
            }}
            validationSchema={fundsManagerAboutFormSchema}
            render={({
              values,
              errors,
              setValues,
              touched,
              handleSubmit,
              handleChange,
              handleBlur,
              setFieldTouched,
              setFieldError,
              setFieldValue,
            }) => (
              <form onSubmit={handleSubmit} className="edit-about">
                <FormGroup>
                  <Input
                    name="title"
                    placeholder="Title"
                    value={values.title}
                    error={errors.title}
                    onBlur={handleBlur}
                    touched={touched.title}
                    onChange={handleChange}
                  />
                  <span className="description__letter-counter">
                    {`${
                      values.title ? values.title.trimStart().length : 0
                    }/128`}
                  </span>
                </FormGroup>
                <FormGroup>
                  <TexEditor
                    name="description"
                    value={values.description}
                    defaultValue={values.description}
                    errors={errors}
                    setValues={setValues}
                    touched={touched}
                    setFieldTouched={setFieldTouched}
                    setFieldError={setFieldError}
                    setFieldValue={setFieldValue}
                    characterLimit={20000}
                    updateFundsManagerCreationFormState={
                      this.updateFundsManagerAboutFormState
                    }
                  />
                </FormGroup>
                <FormGroup>
                  <AddLinkOrVideo
                    initialVideos={initVideos}
                    initLinks={initVideoLinks}
                    onLinkAdded={this.onVideoLinkAdded}
                    onLinkRemoved={this.onVideoLinkRemoved}
                    onVideoTokenAdded={this.onVideoTokenAdded}
                    onVideoTokenRemoved={this.onVideoTokenRemoved}
                  />
                </FormGroup>
                <FormGroup>
                  <UploadAttachments
                    name="attachments"
                    values={values}
                    initFiles={this.state.initFiles}
                    handleInitFilesDelete={this.initFilesDelete}
                    setFieldValue={setFieldValue}
                  />
                </FormGroup>
                <FormGroup>
                  <AddLinks
                    name="links"
                    id="links"
                    placeholder="Add Link"
                    linkType="type_default"
                    objectType="links"
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                    initLinks={this.state.links.filter(
                      link => link.type === 'type_default',
                    )}
                  />
                </FormGroup>
                <ButtonGroup className="edit-about__buttons-container">
                  <Button
                    color="primary"
                    outline
                    className="edit-about__cancel-button"
                    onClick={this.handleCancelClick}
                  >
                    Cancel
                  </Button>
                  <Button color="primary" type="submit">
                    Update
                  </Button>
                </ButtonGroup>
              </form>
            )}
          />
        ) : (
          <div className="edit-about__loader-container">
            <CircleSpinner />
          </div>
        )}
      </Fragment>
    );
  }
}

FundsManagerEditAbout.propTypes = {
  fundsManager: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  getAdminFundsManager: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
  history: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default connect(
  null,
  mapDispatchToProps,
)(withRouter(FundsManagerEditAbout));
