import React from 'react';
import { NavLink } from 'react-router-dom';
import plus from 'assets/icons/add_icon_big_white.svg';
import './style.scss';

const AddFundsManagerButton = () => (
  <NavLink className="add-fundsmanager-button" to="/admin/fundsmanager/create">
    <div className="add-fundsmanager-button__content">
      <img src={plus} height={60} alt="" />
      <span>add new fund-Manager</span>
    </div>
  </NavLink>
);
export default AddFundsManagerButton;
