import React from 'react';
import PropTypes from 'prop-types';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import SearchInput from 'common/components/searchInput';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import FundsManagersManagementAdvancedSearch from 'adminPanel/adminContent/fundsManagers/fundsManagersManagement/containers/fundsManagersManagementAdvancedSearch';
import './index.scss';

const FundsManagersManagementSearchView = ({
  activeFiltersList,
  clearActiveFilters,
  handleSearchInputChange,
  isAdvancedSearchVisible,
  isRemoveFiltersButtonVisible,
  resultsNumber,
  toggleAdvancedSearch,
  fundsManagersFilters,
  handleFilterRemoveClick,
}) => (
  <div className="fundsManagers-management-search">
    <div className="fundsManagers-management-search__top">
      <div className="fundsManagers-management-search__top-left">
        <div className="fundsManagers-management-search__search-input">
          <SearchInput
            handleInputChange={handleSearchInputChange}
            value={fundsManagersFilters.search}
          />
        </div>
        <div className="fundsManagers-management-search__filters-button">
          <ToggleMoreFiltersButton
            handleToggleMoreFiltersClick={toggleAdvancedSearch}
            isMoreFiltersVisible={isAdvancedSearchVisible}
          />
        </div>
      </div>
      {isRemoveFiltersButtonVisible() && (
        <div className="fundsManagers-management-search__clear-filters-button">
          <div className="fundsManagers-management-search__clear-filters-text-button">
            <ClearFiltersButton handleClearFiltersClick={clearActiveFilters} />
          </div>
          <div className="fundsManagers-management-search__clear-filters-icon-button">
            <ClearFiltersIconButton
              handleClearFiltersClick={clearActiveFilters}
            />
          </div>
        </div>
      )}
    </div>
    {isAdvancedSearchVisible && <FundsManagersManagementAdvancedSearch />}
    <div className="fundsManagers-management-search__results-container">
      <div className="fundsManagers-management-search__results">
        <SearchResultsCounter resultsNumber={resultsNumber} />
      </div>
      {activeFiltersList.length > 0 && (
        <ActiveFiltersList
          activeFiltersList={activeFiltersList}
          handleFilterRemoveClick={handleFilterRemoveClick}
        />
      )}
    </div>
  </div>
);

FundsManagersManagementSearchView.defaultProps = {
  resultsNumber: null,
};

FundsManagersManagementSearchView.propTypes = {
  activeFiltersList: PropTypes.arrayOf(PropTypes.object).isRequired,
  clearActiveFilters: PropTypes.func.isRequired,
  fundsManagersFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  resultsNumber: PropTypes.number,
  handleFilterRemoveClick: PropTypes.func.isRequired,
  handleSearchInputChange: PropTypes.func.isRequired,
  isAdvancedSearchVisible: PropTypes.bool.isRequired,
  toggleAdvancedSearch: PropTypes.func.isRequired,
  isRemoveFiltersButtonVisible: PropTypes.func.isRequired,
};

export default FundsManagersManagementSearchView;
