import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import './index.scss';

const FundsManagersManagementAdvancedSearchView = ({
  fundsManagersFilters,
  continentsList,
  countriesList,
  currenciesList,
  fundsManagerContinentsList,
  fundsManagerCountriesList,
  fundTypesList,
  handleFilterUsage,
  handleCheckboxChange,
}) => (
  <div className="fundsManagers-management-advanced-search">
    <div className="fundsManagers-management-advanced-search__filters">
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={fundsManagerContinentsList}
          description="Fund-Manager Continent"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.fundsManagerContinent}
          category="fundsManagerContinent"
          isSearchable
        />
      </div>
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={fundsManagerCountriesList}
          description="Fund-Manager Country"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.fundsManagerCountry}
          category="fundsManagerCountry"
          isSearchable
        />
      </div>
      <div />
    </div>
    <div className="fundsManagers-management-advanced-search__filters">
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={continentsList}
          description="Fund Continent"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.fundContinent}
          category="fundContinent"
          isSearchable
        />
      </div>
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={countriesList}
          description="Fund Country"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.fundCountry}
          category="fundCountry"
          isSearchable
        />
      </div>
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={fundTypesList}
          description="Asset Classes"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.fundType}
          category="fundType"
        />
      </div>
      <div className="fundsManagers-management-advanced-search__filter">
        <MultiSelect
          options={currenciesList}
          description="Currency"
          onChange={handleFilterUsage}
          value={fundsManagersFilters.currency}
          category="currency"
          isSearchable
        />
      </div>
      <div className="fundsManagers-management-advanced-search__filter">
        <AcceptCheckbox
          checked={fundsManagersFilters.active === 1}
          name="active"
          id="active"
          onChange={handleCheckboxChange}
        >
          Active
        </AcceptCheckbox>
        <AcceptCheckbox
          checked={fundsManagersFilters.passive === 1}
          name="passive"
          id="passive"
          onChange={handleCheckboxChange}
        >
          Passive
        </AcceptCheckbox>
      </div>
    </div>
  </div>
);

FundsManagersManagementAdvancedSearchView.defaultProps = {
  countriesList: [],
  continentsList: [],
  currenciesList: [],
  fundTypesList: [],
  fundsManagerContinentsList: [],
  fundsManagerCountriesList: [],
};

FundsManagersManagementAdvancedSearchView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  continentsList: PropTypes.arrayOf(PropTypes.object),
  currenciesList: PropTypes.arrayOf(PropTypes.object),
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  fundsManagerContinentsList: PropTypes.arrayOf(PropTypes.object),
  fundsManagerCountriesList: PropTypes.arrayOf(PropTypes.object),
  fundsManagersFilters: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.number, PropTypes.string, PropTypes.array]),
  ).isRequired,
  handleFilterUsage: PropTypes.func.isRequired,
  handleCheckboxChange: PropTypes.func.isRequired,
};

export default FundsManagersManagementAdvancedSearchView;
