import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { isFundsManagersSecondaryOrPrimaryAdmin } from 'userAuth/utils/permissions';
import AttachmentsFile from 'common/components/attachmentsFile';
import AttachmentsLink from 'common/components/attachmentsLink';
import VideoPlayerWrapper from 'common/components/videoPlayerWrapper';
import { disableScroll } from 'common/utils/disableScroll';
import shortid from 'shortid';
import 'news/components/newsDetailsView/index.scss';
import './index.scss';

class FundsManagerAbout extends Component {
  constructor() {
    super();
    this.state = {
      isVideoDisplayed: false,
    };
  }

  toggleVideoModal = () => {
    this.setState(
      (prevState) => ({
        isVideoDisplayed: !prevState.isVideoDisplayed,
      }),
      () => disableScroll(this.state.isVideoDisplayed),
    );
  };

  render() {
    const { userData, fundsManager } = this.props;

    let videos = [];

    if (fundsManager.videos && fundsManager.video_links) {
      videos =
        fundsManager.videos.length > 0
          ? fundsManager.videos
          : fundsManager.video_links;
    }

    return (
      <div className="fundsManager-about">
        <div className="fundsManager-about__title">
          <div className="title__container">
            <p className="title__text">{fundsManager.title}</p>
          </div>
          {(userData.is_global_admin ||
            isFundsManagersSecondaryOrPrimaryAdmin(
              userData,
              fundsManager.id,
            )) && (
            <div className="title__edit">
              <Link
                className="edit__link"
                to={`/admin/fundsmanager/manage/${fundsManager.id}/edit-about`}
              >
                <div className="link__icon" />
                <div className="link__text">Edit</div>
              </Link>
            </div>
          )}
        </div>
        <div
          className="fundsManager-about__text"
          dangerouslySetInnerHTML={{ __html: fundsManager.description }}
        />
        {videos && videos.length > 0 && (
          <div className="news-details__videos fundsManager-about__videos">
            <p className="fundsManager-about__media-label">Video:</p>
            <div
              className="placeholder"
              onClick={this.toggleVideoModal}
              role="presentation"
            >
              <img
                src={videos[0].video_img}
                className="video__placeholder"
                alt="placeholder"
              />
              <div className="placeholder__play" />
            </div>
            <VideoPlayerWrapper
              isVideoDisplayed={this.state.isVideoDisplayed}
              toggleVideoModal={this.toggleVideoModal}
              videos={videos}
              indexVideo={0}
            />
          </div>
        )}
        {fundsManager.attachments && fundsManager.attachments.length > 0 && (
          <>
            <p className="fundsManager-about__media-label">Attachments:</p>
            <ul>
              {fundsManager.attachments.map((file) => (
                <AttachmentsFile key={shortid.generate()} file={file} />
              ))}
            </ul>
          </>
        )}
        {fundsManager.links && fundsManager.links.length > 0 && (
          <>
            <p className="fundsManager-about__media-label">Links:</p>
            <ul>
              {fundsManager.links.map((link) => (
                <AttachmentsLink key={shortid.generate()} link={link} />
              ))}
            </ul>
          </>
        )}
      </div>
    );
  }
}

FundsManagerAbout.propTypes = {
  fundsManager: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default FundsManagerAbout;
