import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { checkIfFundsManagerUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import 'adminPanel/adminContent/addNews/index.scss';
import AddFundsManagerNewsForm from './containers/addNewsForm';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class AddNews extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });
    if (
      this.props.userData &&
      !checkIfFundsManagerUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });
    if (
      !checkIfFundsManagerUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.match.params.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfFundsManagerUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.match.params.id,
        ) && <AddFundsManagerNewsForm fundsManager={this.props.fundsManager} />}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddNews));
