import React from 'react';
import { FormGroup, Row, Col } from 'reactstrap';
import { SingleDatePicker } from 'react-dates';
import { TimePicker } from 'antd';
import moment from 'moment';
import Input from 'common/components/input';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import RadioInput from 'common/components/radioInput';
import SwitchComponent from 'common/components/switchComponent';
import TextEditor from 'common/components/textEditor';
import UploadPhotosComponent from 'common/components/uploadPhotos';
import AddVideo from 'common/components/addVideo';
import UploadAttachments from 'common/components/uploadAttachments';
import AddLinks from 'common/components/addLinks';
import ExcludeCountries from 'common/components/excludeCountries';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { isFundsManagersSecondaryOrPrimaryAdmin } from 'userAuth/utils/permissions.js';
import { NEWS_DESCRIPTION_MAX_LENGTH } from 'adminPanel/adminContent/addNews/config';
import 'react-quill/dist/quill.snow.css';
import 'react-dates/lib/css/_datepicker.css';
import 'adminPanel/adminContent/addNews/components/addNewsFormView/style.scss';

const AddFundsManagerNewsFormView = ({
  values,
  errors,
  touched,
  handleChange,
  handleBlur,
  setFieldValue,
  setFieldTouched,
  setFieldError,
  updateFundsManagerNewsFormState,
  mergeLinksArray,
  deleteLinksArray,
  handlePublishRadioChange,
  publishRadioValue,
  publishDate,
  publishTime,
  handlePublishDataChange,
  excludedCountries,
  countriesList,
  handleExcludedCountryRemoveClick,
  setCountryToExclude,
  handleInitFilesDelete,
  isPublished,
  isEditMode,
  isInternal,
  handlePublicityRadioChange,
  isLocal,
  handleNotificationRangeRadioChange,
  publishAt,
  receivers,
  handleNotificationReceiverCheckboxClick,
  handleRemindDataChange,
  remindDate,
  remindTime,
  handleRemindSwitch,
  remindError,
  isRemindDisabled,
  userData,
  fundsManagerId,
}) => (
  <>
    <Row className="add-news-form">
      <Col md={6}>
        <header className="add-news-form__header">
          <h2 className="add-news-form__heading">
            {isEditMode ? 'Edit News' : 'Add News'}
          </h2>
        </header>
        <FormGroup>
          <Input
            type="text"
            name="title"
            placeholder="Title*"
            focused
            value={values.title}
            error={errors.title}
            touched={touched.title}
            onChange={handleChange}
            onBlur={(e) => {
              handleBlur(e);
              updateFundsManagerNewsFormState(values);
            }}
          />
          <span className="letter-counter">
            {`${values.title.trimStart().length}/200`}
          </span>
        </FormGroup>
        <FormGroup>
          <TextEditor
            className="description__text-editor"
            name="description"
            placeholder="Content"
            values={values}
            defaultValue={values.description}
            errors={errors}
            touched={touched}
            setFieldError={setFieldError}
            setFieldValue={setFieldValue}
            setFieldTouched={setFieldTouched}
            characterLimit={NEWS_DESCRIPTION_MAX_LENGTH}
          />
        </FormGroup>
        <FormGroup>
          <UploadPhotosComponent
            name="images"
            values={values}
            initImages={values.initImages}
            handleInitFilesDelete={handleInitFilesDelete}
          />
        </FormGroup>
        <FormGroup>
          <AddLinks
            name="videoLinks"
            id="videoLinks"
            placeholder="Add Video Link"
            linkType="type_default"
            objectType="videoLinks"
            mergeLinksArray={mergeLinksArray}
            deleteLinksArray={deleteLinksArray}
            isVideoLink
            initLinks={values.videoLinks.filter(
              (link) => link.type === 'type_video',
            )}
          />
        </FormGroup>
        <FormGroup>
          <AddVideo
            values={values}
            initVideos={values.initVideos}
            handleInitFilesDelete={handleInitFilesDelete}
          />
        </FormGroup>
        <FormGroup>
          <UploadAttachments
            name="files"
            values={values}
            initFiles={values.initFiles}
            handleInitFilesDelete={handleInitFilesDelete}
            setFieldValue={setFieldValue}
          />
        </FormGroup>
        <FormGroup>
          <AddLinks
            name="links"
            id="links"
            placeholder="Add Link"
            linkType="type_default"
            objectType="links"
            mergeLinksArray={mergeLinksArray}
            deleteLinksArray={deleteLinksArray}
            initLinks={values.links.filter(
              (link) => link.type === 'type_default',
            )}
          />
        </FormGroup>
      </Col>
      <Col md={6}>
        <div className="add-news-form__section">
          <p className="add-news-form__section-heading">
            Publicity and notifications
          </p>
          <p className="add-news-form__section-title">Publicity:</p>
          <div className="add-news-form__input-row">
            <RadioInput
              name="publicity"
              value="public"
              checked={!isInternal}
              onChange={handlePublicityRadioChange}
              disabled={isPublished}
            >
              Public
            </RadioInput>
            {isFundsManagersSecondaryOrPrimaryAdmin(
              userData,
              fundsManagerId,
            ) && (
              <RadioInput
                name="publicity"
                value="internal"
                checked={isInternal}
                onChange={handlePublicityRadioChange}
                disabled={isPublished}
              >
                VIP
              </RadioInput>
            )}
          </div>
          {(isPublished ||
            (!isPublished && !publishAt) ||
            (!isPublished &&
              publishAt &&
              moment().unix() - publishAt <= 0)) && (
              <>
                <p className="add-news-form__section-title">
                  Notification range:
                </p>
                <div className="add-news-form__input-row">
                  <RadioInput
                    name="notificationRange"
                    value="global"
                    checked={!isLocal}
                    onChange={handleNotificationRangeRadioChange}
                    disabled={isPublished}
                  >
                    Global
                  </RadioInput>
                  <RadioInput
                    name="notificationRange"
                    value="local"
                    checked={isLocal}
                    onChange={handleNotificationRangeRadioChange}
                    disabled={isPublished}
                  >
                    Local
                  </RadioInput>
                </div>
              </>
          )}
          {(isPublished ||
            (!isPublished && !publishAt) ||
            (!isPublished &&
              publishAt &&
              moment().unix() - publishAt <= 0)) && (
              <>
                <p className="add-news-form__section-title">
                  Notification receiver:
                </p>
                <div className="add-news-form__input-row add-news-form__input-row--checkboxes">
                  {!isInternal && (
                  <AcceptCheckbox
                    name="followers"
                    id="followers"
                    onChange={handleNotificationReceiverCheckboxClick}
                    checked={receivers.includes('followers')}
                    disabled={isPublished}
                  >
                    <span>Followers</span>
                  </AcceptCheckbox>
                )}
                  <AcceptCheckbox
                    name="vips"
                    id="vips"
                    onChange={handleNotificationReceiverCheckboxClick}
                    checked={receivers.includes('vips')}
                    disabled={isPublished}
                  >
                    <span>VIPs</span>
                  </AcceptCheckbox>
                </div>
              </>
          )}
          <p className="add-news-form__section-title">Social media reminder:</p>
          <SwitchComponent
            switchName="Remind me to share this news"
            name="remind"
            id="remind"
            onChange={(e) => {
              handleChange(e);
              updateFundsManagerNewsFormState(values);
              handleRemindSwitch(values);
            }}
            value={values.remind}
            touched={touched}
            onBlur={(e) => {
              handleBlur(e);
              updateFundsManagerNewsFormState(values);
              handleRemindSwitch(values);
            }}
            disabled={isPublished || isRemindDisabled(values)}
          />
          {remindError && (
            <p className="add-news-form__remind-error">{remindError}</p>
          )}
          {!!values.remind && (
            <div className="add-news-form__remind-date-container">
              <SingleDatePicker
                showDefaultInputIcon
                date={remindDate}
                onDateChange={(date) =>
                  handleRemindDataChange(date, remindTime)}
                focused
                keepOpenOnDateSelect
                onFocusChange={() => {}}
                placeholder="Remind date"
                small
                required
                displayFormat="DD/MM/YYYY"
                numberOfMonths={1}
                disabled={isPublished || isRemindDisabled(values)}
                isOutsideRange={(day) =>
                  day.unix() <= moment().subtract(1, 'day').unix() ||
                  isPublished ||
                  isRemindDisabled(values)}
              />
              <TimePicker
                defaultValue={moment(remindTime, 'h:mm A')}
                format="h:mm A"
                allowEmpty={false}
                onChange={(time) => handleRemindDataChange(remindDate, time)}
                placeholder="Remind time"
                size="large"
                disabled={isPublished || isRemindDisabled(values)}
              />
            </div>
          )}
        </div>
        <div className="add-news-form__section">
          <p className="add-news-form__section-heading">
            Publishing date and excluded countries
          </p>
          <div className="add-news-form__input-row">
            <RadioInput
              name="publish"
              value="true"
              checked={publishRadioValue}
              onChange={handlePublishRadioChange}
              disabled={isPublished}
            >
              Publish now
            </RadioInput>
            <RadioInput
              name="publish"
              value="false"
              checked={!publishRadioValue}
              onChange={handlePublishRadioChange}
              disabled={isPublished}
            >
              Set a date
            </RadioInput>
          </div>
          {!publishRadioValue && (
            <FormGroup>
              <SingleDatePicker
                showDefaultInputIcon
                date={publishDate}
                onDateChange={(date) =>
                  handlePublishDataChange(date, publishTime)}
                focused
                keepOpenOnDateSelect
                onFocusChange={() => {}}
                placeholder="Publish Date"
                small
                required
                displayFormat="DD/MM/YYYY"
                numberOfMonths={1}
                disabled={isPublished}
                isOutsideRange={() => !!isPublished}
              />
              <TimePicker
                defaultValue={moment(publishTime, 'h:mm A')}
                format="h:mm A"
                allowEmpty={false}
                onChange={(time) => handlePublishDataChange(publishDate, time)}
                placeholder="Publish Time"
                size="large"
                disabled={isPublished}
              />
            </FormGroup>
          )}
          <div className="add-news-form__excluded-switch">
            <SwitchComponent
              switchName="Exclude countries"
              name="isExcluded"
              id="isExcluded"
              onChange={handleChange}
              value={values.isExcluded}
              touched={touched}
              onBlur={(e) => {
                handleBlur(e);
                updateFundsManagerNewsFormState(values);
              }}
            />
          </div>
          <ExcludeCountries
            excludedCountries={excludedCountries}
            countriesList={mapObjPropsToSelectFilter({
              list: countriesList,
              label: 'country_name',
              value: 'id',
              category: 'country',
            })}
            handleExcludedCountryRemoveClick={handleExcludedCountryRemoveClick}
            setCountryToExclude={setCountryToExclude}
            disabled={!values.isExcluded}
          />
        </div>
      </Col>
    </Row>
  </>
);

export default AddFundsManagerNewsFormView;
