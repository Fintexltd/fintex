import React from 'react';
import DocumentsTableView from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/components/documentsTableView';
import shortid from 'shortid';
import './style.scss';

const DocumentsView = ({
  documentsList,
  handleSeeMoreClick,
  removeSection,
  editSection,
  createSection,
  fundsManagerId,
}) => (
  <div className="fundsManager-documents">
    {documentsList &&
      documentsList.map(documents => (
        <DocumentsTableView
          key={shortid.generate()}
          header={documents.name}
          sectionId={documents.sectionId}
          data={documents.data}
          nextPageIndex={documents.nextPageIndex}
          handleSeeMoreClick={handleSeeMoreClick}
          removeSection={removeSection}
          editSection={editSection}
          fundsManagerId={fundsManagerId}
        />
      ))}
    <div
      className="fundsManager-documents__newSection"
      onClick={createSection}
      role="presentation"
    >
      <div className="newSection__icon" />
      <div className="newSection__text">Add new section</div>
    </div>
  </div>
);

export default DocumentsView;
