import React from 'react';
import DocumentsForm from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/containers/documentsForm';
import Documents from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/containers/documents';
import shortid from 'shortid';
import './style.scss';

const DocumentsTableView = ({
  header,
  data,
  sectionId,
  handleSeeMoreClick,
  fundsManagerId,
  editSection,
  removeSection,
  nextPageIndex,
}) => (
  <div className="fundsManager-documents__container">
    <div className="fundsManager-documents__header">
      <h1 className="header__content">{header}</h1>
      <div className="header__icons">
        <div
          className="icon__edit"
          onClick={() => editSection(header, sectionId)}
          role="presentation"
        />
        <div
          className="icon__remove"
          onClick={() => removeSection(sectionId)}
          role="presentation"
        />
      </div>
    </div>

    <table className="fundsManager-documents__table">
      <thead className="fundsManager-documents__thead">
        <tr>
          <th className="thPublish align-middle">Publish date</th>
          <th className="thTitle align-middle">Title</th>
          <th className="thAttachments align-middle">Attachments</th>
          <th className="thActions align-middle" />
        </tr>
      </thead>
      <tbody>
        <DocumentsForm fundsManagerId={fundsManagerId} sectionId={sectionId} />
        {data.map(documents => (
          <Documents
            key={`${shortid.generate()}`}
            fundsManagerId={fundsManagerId}
            sectionId={sectionId}
            documents={documents}
          />
        ))}
      </tbody>
    </table>
    {nextPageIndex ? (
      <div className="fundsManager-documents__load-container">
        <button
          onClick={() => handleSeeMoreClick(nextPageIndex, sectionId)}
          className="fundsManager-documents__load"
        >
          See more
        </button>
      </div>
    ) : (
      ''
    )}
  </div>
);

export default DocumentsTableView;
