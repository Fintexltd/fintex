import React, { Fragment } from 'react';
import moment from 'moment';
import Input from 'common/components/input';
import CircleSpinner from 'common/components/circleSpinner';
import './style.scss';

const DocumentsTableView = ({
  sectionId,
  values,
  errors,
  touched,
  handleChange,
  handleBlur,
  addDocuments,
  cancelEdit,
  uploadAttachements,
  isLoadingFile,
  isEdit,
  formFunction,
  id,
}) => (
  <tr
    className="fundsManager-documents__fundsManager-row"
    style={{
      display: !isEdit && formFunction === 'edit' ? 'none' : 'table-row',
    }}
  >
    <th className="align-middle new-documents" scope="row">
      {moment(values.date).format('DD.MM.YYYY')}
    </th>
    <td className="align-middle new-documents-input">
      <Input
        type="text"
        name="title"
        placeholder="Title"
        focused
        maxLength={64}
        value={values.title}
        error={errors.title}
        touched={touched.title}
        onChange={handleChange}
        onBlur={handleBlur}
      />
    </td>
    <td className="align-middle">
      {isLoadingFile ? (
        <div className="loading__container">
          <CircleSpinner />
        </div>
      ) : (
        <label htmlFor={`${sectionId}_${id}`} className="custom-file-upload">
          <div className="link__container">
            <div className="link__icon">
              <div className="documents-link__image pdf" />
            </div>
            <div className="link__text">
              {values.fileName === '' ? 'Upload File' : values.fileName}
            </div>
          </div>
          <input
            id={`${sectionId}_${id}`}
            name="file"
            type="file"
            className="attachements__input-hidden"
            accept=".txt, .rtf, .pages, .numbers, .key, .pdf, .zip, .jpg, .jpeg, .png, .gif, .pot, .potm, .potx, .ppam, .pps, .ppsx, .ppt, .pptm, .pptx, .doc, .docb, .docm, .docx, .dot, .dotm, .dotx, .xla, .xlam, .xll, .xlm, .xls, .xlsb, .xslm, .xlsx, .xlt, .xltm, .xltx, .xlw, .flv, .mp4, .mov, .wmv, .qt"
            onChange={uploadAttachements}
          />
        </label>
      )}
      <span className="input-error-message-file">{errors.file}</span>
    </td>
    <td className="align-middle">
      {formFunction !== 'edit' ? (
        <Fragment>
          <div
            className="link__container"
            onClick={addDocuments}
            role="presentation"
          >
            <div className="link_icon">
              <div className="documents-link__image add" />
            </div>
            <div className="link__text add">Add</div>
          </div>
        </Fragment>
      ) : (
        <Fragment>
          <div
            className="link__container"
            role="presentation"
            onClick={addDocuments}
          >
            <div className="link_icon">
              <div className="documents-link__image confirm" />
            </div>
            <div className="link__text confirm">Confirm</div>
          </div>
          <div
            className="link__container"
            onClick={cancelEdit}
            role="presentation"
          >
            <div className="link_icon">
              <div className="documents-link__image cancel" />
            </div>
            <div className="link__text cancel">Cancel</div>
          </div>
        </Fragment>
      )}
    </td>
  </tr>
);

export default DocumentsTableView;
