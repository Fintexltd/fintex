import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Input from 'common/components/input';
import DocumentsView from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/components/documentsView';
import validationSchema from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/validators';
import RemoveModal from 'common/components/removeModal';
import {
  fetchFundsManagerDocuments,
  fetchFundsManagerDocumentsMore,
  removeFundsManagerDocuments,
  addFundsManagerDocumentsSection,
  editFundsManagerDocumentsSection,
  removeFundsManagerDocumentsSection,
} from 'common/redux/actions/fundsManagerDocumentsActions';
import { disableScroll } from 'common/utils/disableScroll';
import FormModal from 'common/components/modals/form';

const mapStateToProps = (state) => ({
  documentsList: state.fundsManagerDocuments.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsManagerDocuments: bindActionCreators(
    fetchFundsManagerDocuments,
    dispatch,
  ),
  getFundsManagerDocumentsMore: bindActionCreators(
    fetchFundsManagerDocumentsMore,
    dispatch,
  ),
  removeFundsManagerDocuments: bindActionCreators(
    removeFundsManagerDocuments,
    dispatch,
  ),
  addFundsManagerDocumentsSection: bindActionCreators(
    addFundsManagerDocumentsSection,
    dispatch,
  ),
  editFundsManagerDocumentsSection: bindActionCreators(
    editFundsManagerDocumentsSection,
    dispatch,
  ),
  removeFundsManagerDocumentsSection: bindActionCreators(
    removeFundsManagerDocumentsSection,
    dispatch,
  ),
});

class FundsManagerDocuments extends Component {
  constructor() {
    super();
    this.state = {
      sectionId: null,
      isRemoveModalVisible: false,
      isInputModalVisible: false,
      isEdit: false,
      values: {
        name: '',
      },
    };
  }

  componentDidMount() {
    const fundsManagerId = Number(this.props.match.params.id);
    if (
      !(
        this.props.userData.relations_funds_manager.secondary_admin &&
        this.props.userData.relations_funds_manager.secondary_admin.includes(
          fundsManagerId,
        )
      ) &&
      !(
        this.props.userData.relations_funds_manager.primary_admin &&
        this.props.userData.relations_funds_manager.primary_admin.includes(
          fundsManagerId,
        )
      ) &&
      !(
        this.props.userData.relations_funds_manager.domestic_admin &&
        this.props.userData.relations_funds_manager.domestic_admin.includes(
          fundsManagerId,
        )
      ) &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push(
        `/admin/fundsManager/manage/${fundsManagerId}/about`,
      );
    }
    this.props.removeFundsManagerDocuments();
    this.props.getFundsManagerDocuments(this.props.match.params.id);
  }

  handleSeeMoreClick = (pageIndex, type) => {
    this.props.getFundsManagerDocumentsMore(
      pageIndex,
      type,
      this.props.match.params.id,
    );
  };

  closeModal = () => {
    this.setState(
      {
        sectionId: null,
        isRemoveModalVisible: false,
        isInputModalVisible: false,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(false),
    );
  };

  sectionActions = ({ name, id }) => {
    if (this.state.isEdit) {
      this.props.editFundsManagerDocumentsSection(id, { name });
      this.closeModal();
    } else {
      this.props.addFundsManagerDocumentsSection({
        name,
        entitiable_type: 'funds_manager',
        entitiable_id: this.props.match.params.id,
        type: 'document_section',
      });
      this.closeModal();
    }
  };

  createSection = () => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: false,
        values: {
          name: '',
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  editSection = (name, id) => {
    this.setState(
      {
        isInputModalVisible: true,
        isEdit: true,
        values: {
          name,
          id,
        },
      },
      () => disableScroll(this.state.isInputModalVisible),
    );
  };

  removeSection = (sectionId) => {
    if (this.state.sectionId) {
      this.props.removeFundsManagerDocumentsSection(this.state.sectionId);
      this.closeModal();
    } else {
      this.setState(
        {
          isRemoveModalVisible: true,
          sectionId,
        },
        () => disableScroll(this.state.isRemoveModalVisible),
      );
    }
  };

  render() {
    const { isRemoveModalVisible, isInputModalVisible } = this.state;

    const ModalFormView = ({ formProps }) => (
      <>
        <Input
          name="name"
          type="text"
          placeholder="Section name"
          error={formProps.errors.name}
          value={formProps.values.name}
          touched={formProps.touched.name}
          onBlur={formProps.handleBlur}
          onChange={formProps.handleChange}
          autoFocus
        />
        {' '}
        <span className="letter-counter">
          {`${formProps.values.name.trimStart().length}/64`}
        </span>
      </>
    );

    return (
      <>
        <DocumentsView
          documentsList={this.props.documentsList}
          createSection={this.createSection}
          editSection={this.editSection}
          removeSection={this.removeSection}
          handleSeeMoreClick={this.handleSeeMoreClick}
          fundsManagerId={this.props.match.params.id}
        />
        <FormModal
          isModalVisible={isInputModalVisible}
          handleClose={this.closeModal}
          header={`${this.state.isEdit ? 'Edit' : 'Add new'} section`}
          validationSchema={validationSchema}
          onSubmit={this.sectionActions}
          initialValues={this.state.values}
          confimButtonText={this.state.isEdit ? 'Save' : 'Add'}
        >
          <ModalFormView />
        </FormModal>
        {isRemoveModalVisible && (
          <RemoveModal
            handleRemoveClick={this.removeSection}
            handleCancelClick={this.closeModal}
            heading="Are You sure you want to remove this section?"
            message="This section will be deleted immediately. You can't undo this action."
          />
        )}
      </>
    );
  }
}

FundsManagerDocuments.propTypes = {
  getFundsManagerDocuments: PropTypes.func.isRequired,
  removeFundsManagerDocuments: PropTypes.func.isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagerDocuments);
