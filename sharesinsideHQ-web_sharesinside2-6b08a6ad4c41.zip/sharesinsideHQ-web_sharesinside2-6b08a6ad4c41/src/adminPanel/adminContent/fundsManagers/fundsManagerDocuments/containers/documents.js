import React, { Fragment, Component } from 'react';
import classNames from 'classnames';
import moment from 'moment';
import { connect } from 'react-redux';
import DocumentsForm from 'adminPanel/adminContent/fundsManagers/fundsManagerDocuments/containers/documentsForm';
import { bindActionCreators } from 'redux';
import { removeDocuments } from 'common/redux/actions/fundsManagerDocumentsActions';

const mapDispatchToProps = dispatch => ({
  removeDocuments: bindActionCreators(removeDocuments, dispatch),
});

class Documents extends Component {
  state = {
    isEdit: false,
  };

  editHistorical = () => {
    this.setState({
      isEdit: true,
    });
  };

  cancelEdit = () => {
    this.setState({
      isEdit: false,
    });
  };

  removeHistorical = id => {
    this.props.removeDocuments(id, this.props.sectionId);
  };

  render() {
    const { sectionId, documents, fundsManagerId } = this.props;
    return (
      <Fragment>
        <DocumentsForm
          fundsManagerId={fundsManagerId}
          sectionId={sectionId}
          data={documents}
          isEdit={this.state.isEdit}
          formFunction="edit"
          documentsId={documents.id}
          cancelEdit={this.cancelEdit}
        />
        <tr
          className="fundsManager-documents__fundsManager-row"
          style={{
            display: this.state.isEdit ? 'none' : 'table-row',
          }}
        >
          <th scope="row" className="align-middle">
            {moment.unix(documents.timestamp).format('DD.MM.YYYY')}
          </th>
          <td className="align-middle">{documents.title}</td>
          <td className="align-middle">
            <a
              href={documents.file.url}
              rel="noopener noreferrer"
              target="_blank"
              className="link__container"
            >
              <div className="link_icon">
                <div
                  className={classNames({
                    'documents-link__image': true,
                    pdf:
                      documents.file.mime_type.split('/')[0] === 'application',
                    image: documents.file.mime_type.split('/')[0] === 'image',
                    video: documents.file.mime_type.split('/')[0] === 'video',
                  })}
                />
              </div>
              <div className="link__text"> {documents.file.oryginal_name} </div>
            </a>
          </td>

          <td className="align-middle">
            <div
              className="link__container"
              onClick={this.editHistorical}
              role="presentation"
            >
              <div className="link_icon">
                <div className="documents-link__image edit" />
              </div>
              <div className="link__text edit">Edit</div>
            </div>
            <div
              className="link__container"
              onClick={() => this.removeHistorical(documents.id)}
              role="presentation"
            >
              <div className="link_icon">
                <div className="documents-link__image remove" />
              </div>
              <div className="link__text remove">Remove</div>
            </div>
          </td>
        </tr>
      </Fragment>
    );
  }
}

export default connect(
  null,
  mapDispatchToProps,
)(Documents);
