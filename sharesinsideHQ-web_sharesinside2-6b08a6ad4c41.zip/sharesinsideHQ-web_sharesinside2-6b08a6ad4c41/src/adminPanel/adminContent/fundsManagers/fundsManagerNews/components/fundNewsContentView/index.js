import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, ButtonGroup, Button } from 'reactstrap';
import NewsItem from 'common/components/newsItem';
import AddButton from 'common/components/addButton';
import ModalContainer from 'common/components/modalContainer';
import { checkIfFundsManagerUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './index.scss';

const NewsContentView = ({
  newsList,
  fundsManagerId,
  handleLoadMoreClick,
  nextPageIndex,
  toggleNewsDeleteModal,
  isRemoveNewsModalVisible,
  deleteNews,
  userData,
}) => (
  <div className="fundsManager-news-content">
    <Row>
      {checkIfFundsManagerUserCanManageNewsOrEvents(
        userData,
        fundsManagerId,
      ) && (
        <AddButton
          route={`/admin/fundsmanager/manage/${fundsManagerId}/add-news`}
          content="add news"
        />
      )}
      {newsList.length > 0 &&
        newsList.map((item) => (
          <Col xs="12" md="6" key={item.id}>
            <NewsItem
              news={item}
              handleDelete={toggleNewsDeleteModal}
              inAdminView
              ownerType="fundsManager"
            />
          </Col>
        ))}
      {newsList.length === 0 && (
        <Col xs="12" className="fundsManager-news-content__empty-list">
          <p className="fundsManager-news-content__empty-list-message">
            There are no news for this fundsManager
          </p>
        </Col>
      )}
    </Row>
    {nextPageIndex && (
      <div className="fundsManager-news-content__load-container">
        <button
          onClick={handleLoadMoreClick}
          className="fundsManager-news-content__load"
        >
          Load more
        </button>
      </div>
    )}
    {isRemoveNewsModalVisible && (
      <ModalContainer
        className="fundsManager-news-content__remove-news-modal"
        handleOutsideClick={toggleNewsDeleteModal}
      >
        Warning! All news data will be removed!
        <ButtonGroup>
          <Button
            outline
            color="primary"
            className="mr-5"
            type="button"
            onClick={toggleNewsDeleteModal}
          >
            Cancel
          </Button>

          <Button onClick={deleteNews} color="danger">
            Delete
          </Button>
        </ButtonGroup>
      </ModalContainer>
    )}
  </div>
);

NewsContentView.defaultProps = {
  newsList: [],
  nextPageIndex: null,
};

NewsContentView.propTypes = {
  newsList: PropTypes.arrayOf(PropTypes.object),
  handleLoadMoreClick: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default NewsContentView;
