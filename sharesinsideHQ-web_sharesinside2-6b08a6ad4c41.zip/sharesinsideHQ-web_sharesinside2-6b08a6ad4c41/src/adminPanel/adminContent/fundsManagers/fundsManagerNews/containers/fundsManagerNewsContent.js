import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import FundsManagerNewsContentView from 'adminPanel/adminContent/fundsManagers/fundsManagerNews/components/fundNewsContentView';
import {
  fetchAdminFundsManagerNews,
  removeAdminFundsManagerNews,
} from 'adminPanel/redux/actions/funds/admin/adminFundsManagerNewsActions';
import { deleteNewsData } from 'adminPanel/adminContent/news/api/newsApi.js';

const mapStateToProps = (state) => ({
  newsList: state.adminFundsManagerNews.list,
  hasNextPage: state.adminFundsManagerNews.hasNextPage,
  nextPageIndex: state.adminFundsManagerNews.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminFundsManagerNews: bindActionCreators(
    fetchAdminFundsManagerNews,
    dispatch,
  ),
  removeAdminFundsManagerNews: bindActionCreators(
    removeAdminFundsManagerNews,
    dispatch,
  ),
});

class NewsContent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isLoadMoreClicked: false,
      isRemoveNewsModalVisible: false,
      newsToDelete: null,
    };
  }

  componentDidMount() {
    if (this.props.fundsManagerId) {
      this.props.removeAdminFundsManagerNews();
      this.props.getAdminFundsManagerNews(0, this.props.fundsManagerId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminFundsManagerNews(
          this.props.nextPageIndex,
          this.props.fundsManagerId,
        );
      });
    }
  };

  deleteNews = () => {
    deleteNewsData(this.state.newsToDelete).then(() => {
      this.props.getAdminFundsManagerNews(0, this.props.fundsManagerId);
      this.toggleNewsDeleteModal();
    });
  };

  toggleNewsDeleteModal = (newsId) => {
    this.setState((prevState) => ({
      isRemoveNewsModalVisible: !prevState.isRemoveNewsModalVisible,
      newsToDelete: newsId,
    }));
  };

  render() {
    return (
      <FundsManagerNewsContentView
        newsList={this.props.newsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        fundsManagerId={this.props.fundsManagerId}
        isRemoveNewsModalVisible={this.state.isRemoveNewsModalVisible}
        toggleNewsDeleteModal={this.toggleNewsDeleteModal}
        deleteNews={this.deleteNews}
        userData={this.props.userData}
      />
    );
  }
}

NewsContent.defaultProps = {
  fundsManagerId: null,
  nextPageIndex: null,
  newsList: [],
};

NewsContent.propTypes = {
  fundsManagerId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  newsList: PropTypes.arrayOf(PropTypes.object),
  getAdminFundsManagerNews: PropTypes.func.isRequired,
  removeAdminFundsManagerNews: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(NewsContent);
