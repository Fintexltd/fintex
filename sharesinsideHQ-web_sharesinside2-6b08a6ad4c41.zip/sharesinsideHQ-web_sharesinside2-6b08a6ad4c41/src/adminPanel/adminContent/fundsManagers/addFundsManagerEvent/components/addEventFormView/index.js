import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Row, Col, FormGroup } from 'reactstrap';
import TextEditor from 'common/components/textEditor';
import fetchLocationData from 'common/redux/actions/locationDataActions.js';
import fetchCountriesList from 'common/redux/actions/countriesListActions.js';
import Input from 'common/components/input';
import AcceptCheckbox from 'common/components/acceptCheckbox';
import RadioInput from 'common/components/radioInput';
import { SingleDatePicker } from 'react-dates';
import { TimePicker } from 'antd';
import SingleSelect from 'common/components/customSelect/singleSelect';
import moment from 'moment';
import classnames from 'classnames';
import UploadAttachments from 'common/components/uploadAttachments';
import AddLinks from 'common/components/addLinks';
import AddEventMap from 'adminPanel/adminContent/addEvent/containers/addEventMap';
import { isFundsManagersSecondaryOrPrimaryAdmin } from 'userAuth/utils/permissions.js';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import { formatDateTime } from 'common/utils/dateUtils';
import { googleMapURL } from 'common/api/googleMapsApi';
import 'react-dates/lib/css/_datepicker.css';
import 'adminPanel/adminContent/addEvent/components/addEventFormView/style.scss';

class AdminEventsForm extends Component {
  constructor(props) {
    super(props);
    this.timer = null;
    this.state = {
      date: moment({}),
      time: moment(),
    };
  }

  componentDidMount() {
    this.props.fetchCountriesList();
  }

  handleLocationData = (city, adress) => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.props.fetchLocationData(`${city} ${adress}`);
    }, 1000);
  };

  handleChangeData = () => {
    const { date, time } = this.state;
    this.props.updateFundsManagerEventsFormState({
      ...this.props.values,
      event_date: formatDateTime(date, time),
    });
  };

  render() {
    const {
      values,
      errors,
      touched,
      handleChange,
      handleBlur,
      setFieldValue,
      setFieldTouched,
      setFieldError,
      countriesList,
      updateFundsManagerEventsFormState,
      mergeLinksArray,
      deleteLinksArray,
      handlePublishRadioChange,
      publishDate,
      publishTime,
      publishRadioValue,
      handlePublishDataChange,
      isInternal,
      handlePublicityRadioChange,
      userData,
      fundsManagerId,
      isLocal,
      handleNotificationRangeRadioChange,
      publishAt,
      receivers,
      handleNotificationReceiverCheckboxClick,
      countryError,
      removeCountryError,
      links,
      cityRef,
      addressRef,
    } = this.props;
    return (
      <Row className="add-event-form">
        <Col md={6}>
          <FormGroup>
            <Input
              type="text"
              name="title"
              placeholder="Title*"
              focused
              value={values.title}
              error={errors.title}
              touched={touched.title}
              onChange={handleChange}
              onBlur={(e) => {
                handleBlur(e);
                this.props.updateFundsManagerEventsFormState(values);
              }}
            />
            <span className="add-event-form__letter-counter">
              {`${values.title.trimStart().length}/200`}
            </span>
          </FormGroup>
          <FormGroup>
            <TextEditor
              className="description__text-editor"
              name="description"
              placeholder="Content"
              values={values}
              errors={errors}
              touched={touched}
              setFieldError={setFieldError}
              setFieldValue={setFieldValue}
              setFieldTouched={setFieldTouched}
              updateFundsManagerCreationFormState={
                updateFundsManagerEventsFormState
              }
            />
          </FormGroup>
          <FormGroup>
            <div
              className={classnames({
                'add-event-form__select-container': countryError,
              })}
            >
              <SingleSelect
                description="Country*"
                onChange={(value) => {
                  setFieldTouched('country_id', true);
                  setFieldValue('country_id', value[0].value);
                  if (countryError) {
                    removeCountryError();
                  }
                }}
                options={mapObjPropsToSelectFilter({
                  list: countriesList
                    ? countriesList.map(
                        ({ country_name: countryName, id }) => ({
                          value: id,
                          label: countryName,
                        }),
                      )
                    : [],
                  label: 'label',
                  value: 'value',
                  category: 'country',
                })}
                value={[
                  {
                    category: 'country',
                    label: countriesList.filter(
                      (element) => element.id === values.country_id,
                    )[0]
                      ? countriesList.filter(
                          (element) => element.id === values.country_id,
                        )[0].country_name
                      : '',
                    value: values.country_id,
                  },
                ]}
                category="country"
              />
              {countryError && (
                <div className="add-event-form__error">{countryError}</div>
              )}
            </div>
          </FormGroup>
          <FormGroup>
            <Input
              name="city"
              placeholder="City*"
              value={values.city}
              error={errors.city}
              touched={touched.city}
              innerRef={cityRef}
              onChange={(e) => {
                handleChange(e);
                this.handleLocationData(e.target.value, values.adress);
              }}
              onBlur={(e) => {
                handleBlur(e);
                this.handleLocationData(e.target.value, values.adress);
              }}
            />
          </FormGroup>
          <FormGroup>
            <Input
              name="adress"
              placeholder="Address"
              value={values.adress}
              error={errors.adress}
              touched={touched.adress}
              innerRef={addressRef}
              onChange={(e) => {
                handleChange(e);
                this.handleLocationData(values.city, e.target.value);
              }}
              onBlur={(e) => {
                handleBlur(e);
                this.handleLocationData(values.city, e.target.value);
              }}
            />
          </FormGroup>
          <FormGroup>
            <SingleDatePicker
              showDefaultInputIcon
              date={this.state.date}
              onDateChange={(date) => {
                if (date)
                  this.setState({ date }, () => {
                    this.handleChangeData();
                  });
              }}
              focused
              keepOpenOnDateSelect
              onFocusChange={() => {}}
              placeholder="Event Time"
              small
              required
              displayFormat="DD/MM/YYYY"
              numberOfMonths={1}
              id="event_time"
            />

            <TimePicker
              defaultValue={moment(this.state.time, 'h:mm A')}
              format="h:mm A"
              allowEmpty={false}
              onChange={(time) => {
                if (time)
                  this.setState({ time }, () => {
                    this.handleChangeData();
                  });
              }}
              placeholder="Time"
              size="large"
            />
          </FormGroup>
          <FormGroup className="add-event-form__upload-group">
            <UploadAttachments values={values} name="files" />
          </FormGroup>
          <FormGroup>
            <AddLinks
              name="type_webcast"
              id="type_webcast"
              placeholder="Add Webcast Link"
              linkType="type_webcast"
              objectType="links"
              mergeLinksArray={mergeLinksArray}
              deleteLinksArray={deleteLinksArray}
              isVideoLink
            />
            {links.filter((link) => link.type === 'type_webcast').length >
              1 && (
              <p className="add-event-form__error">
                Only one webcast link is allowed.
              </p>
            )}
          </FormGroup>
          <FormGroup>
            <AddLinks
              name="type_archived_video"
              id="type_archived_video"
              placeholder="Add Archived Video Link"
              linkType="type_archived_video"
              objectType="links"
              mergeLinksArray={mergeLinksArray}
              deleteLinksArray={deleteLinksArray}
              isVideoLink
            />
            {links.filter((link) => link.type === 'type_archived_video')
              .length > 1 && (
              <p className="add-event-form__error">
                Only one archived video link is allowed.
              </p>
            )}
          </FormGroup>
        </Col>
        <Col md={6}>
          <div className="add-event-form__map-container google-map">
            <AddEventMap
              googleMapURL={googleMapURL}
              loadingElement={<div style={{ height: `100%` }} />}
              containerElement={<div style={{ height: `350px` }} />}
              errors={errors}
              touched={touched}
              mapElement={
                <div className="mapElement" style={{ height: `100%` }} />
              }
            />
          </div>
          <div className="add-event-form__section">
            <p className="add-event-form__section-title">Publicity:</p>
            <div className="add-event-form__input-row">
              <RadioInput
                name="publicity"
                value="public"
                checked={!isInternal}
                onChange={handlePublicityRadioChange}
              >
                Public
              </RadioInput>
              {isFundsManagersSecondaryOrPrimaryAdmin(
                userData,
                fundsManagerId,
              ) && (
                <RadioInput
                  name="publicity"
                  value="internal"
                  checked={isInternal}
                  onChange={handlePublicityRadioChange}
                >
                  VIP
                </RadioInput>
              )}
            </div>
          </div>
          {(!publishAt || (publishAt && moment().unix() - publishAt <= 0)) && (
            <>
              <p className="add-event-form__section-title">
                Notification range:
              </p>
              <div className="add-event-form__input-row">
                <RadioInput
                  name="notificationRange"
                  value="global"
                  checked={!isLocal}
                  onChange={handleNotificationRangeRadioChange}
                >
                  Global
                </RadioInput>
                <RadioInput
                  name="notificationRange"
                  value="local"
                  checked={isLocal}
                  onChange={handleNotificationRangeRadioChange}
                >
                  Local
                </RadioInput>
              </div>
            </>
          )}
          {(!publishAt || (publishAt && moment().unix() - publishAt <= 0)) && (
            <>
              <p className="add-news-form__section-title">
                Notification receiver:
              </p>
              <div className="add-event-form__input-row add-event-form__input-row--checkboxes">
                {!isInternal && (
                  <AcceptCheckbox
                    name="followers"
                    id="followers"
                    onChange={handleNotificationReceiverCheckboxClick}
                    checked={receivers.includes('followers')}
                  >
                    <span>Followers</span>
                  </AcceptCheckbox>
                )}
                <AcceptCheckbox
                  name="vips"
                  id="vips"
                  onChange={handleNotificationReceiverCheckboxClick}
                  checked={receivers.includes('vips')}
                >
                  <span>VIPs</span>
                </AcceptCheckbox>
              </div>
            </>
          )}
          <div className="add-event-form__section">
            <p className="add-event-form__section-title">Schedule time:</p>
            <div className="add-event-form__input-row">
              <RadioInput
                name="publish"
                value="true"
                checked={publishRadioValue}
                onChange={handlePublishRadioChange}
              >
                Publish now
              </RadioInput>
              <RadioInput
                name="publish"
                value="false"
                checked={!publishRadioValue}
                onChange={handlePublishRadioChange}
              >
                Set a date
              </RadioInput>
            </div>
            {!publishRadioValue && (
              <FormGroup>
                <SingleDatePicker
                  showDefaultInputIcon
                  date={publishDate}
                  onDateChange={(date) =>
                    handlePublishDataChange(date, publishTime)}
                  focused
                  keepOpenOnDateSelect
                  onFocusChange={() => {}}
                  placeholder="Publish Date"
                  small
                  required
                  displayFormat="DD/MM/YYYY"
                  numberOfMonths={1}
                />
                <TimePicker
                  defaultValue={moment(publishTime, 'h:mm A')}
                  format="h:mm A"
                  allowEmpty={false}
                  onChange={(time) =>
                    handlePublishDataChange(publishDate, time)}
                  placeholder="Publish Time"
                  size="large"
                />
              </FormGroup>
            )}
          </div>
        </Col>
      </Row>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchLocationData: (adress) => dispatch(fetchLocationData(adress)),
  fetchCountriesList: () => dispatch(fetchCountriesList()),
});

const mapStateToProps = (state) => ({
  countriesList: state.countries.list,
  industriesList: state.industries.list,
});

AdminEventsForm.defaultProps = {
  countriesList: [],
  errors: {},
  values: {},
};

AdminEventsForm.propTypes = {
  fetchLocationData: PropTypes.func.isRequired,
  fetchCountriesList: PropTypes.func.isRequired,
  countriesList: PropTypes.arrayOf(PropTypes.object),
  values: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.string,
      PropTypes.number,
      PropTypes.array,
      PropTypes.bool,
    ]),
  ),
  errors: PropTypes.objectOf(PropTypes.string),
  handleChange: PropTypes.func.isRequired,
  handleBlur: PropTypes.func.isRequired,
  setFieldTouched: PropTypes.func.isRequired,
  handlePublishRadioChange: PropTypes.func.isRequired,
  publishDate: PropTypes.instanceOf(moment).isRequired,
  publishTime: PropTypes.instanceOf(moment).isRequired,
  publishRadioValue: PropTypes.bool.isRequired,
  handlePublishDataChange: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(AdminEventsForm);
