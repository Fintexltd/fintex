import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { checkIfFundsManagerUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import AddEventForm from './containers/addEventForm';

const mapStateToProps = (state) => ({
  fundsManager: state.adminFundsManager.currentFundsManager,
  locationData: state.locationData.results,
  userData: state.userData.data,
});

class AddFundsManagerEvent extends Component {
  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      this.props.userData &&
      !checkIfFundsManagerUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.fundsManager.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData)
      this.props.history.push({
        pathname: '/auth',
        state: { location: this.props.location.pathname },
      });

    if (
      !checkIfFundsManagerUserCanManageNewsOrEvents(
        this.props.userData,
        this.props.fundsManager.id,
      )
    ) {
      this.props.history.push('/');
    }
  }

  render() {
    return (
      <>
        {checkIfFundsManagerUserCanManageNewsOrEvents(
          this.props.userData,
          this.props.fundsManager.id,
        ) && (
          <AddEventForm
            fundsManager={this.props.fundsManager}
            userData={this.props.userData}
            {...this.props}
          />
        )}
      </>
    );
  }
}

export default connect(mapStateToProps)(withRouter(AddFundsManagerEvent));
