import React, { Component } from 'react';
import { Button } from 'reactstrap';
import { Formik } from 'formik';
import { withRouter } from 'react-router';
import moment from 'moment';
import { isNil, omitBy } from 'lodash';
import { addEventSchema as validationSchema } from 'adminPanel/adminContent/addEvent/validators/addEventSchema';
import { sendEventsDataRequest } from 'adminPanel/adminContent/addEvent/api/addEventApi';
import shortid from 'shortid';
import { formatDateTime } from 'common/utils/dateUtils';
import AddEventFormView from '../components/addEventFormView';

class AddEventForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      apiErrors: '',
      apiMessage: {},
      isClicked: false,
      sendSuccessMsg: '',
      countryError: '',
      formData: {
        city: '',
        adress: '',
        title: '',
        country_id: '',
        funds_manager_id: this.props.fundsManager.id,
        description: '',
        event_date: formatDateTime(moment({}), moment()),
        files: [],
        links: [],
        longitude: null,
        latitude: null,
        is_preview: 0,
        is_draft: 0,
        publish_now: true,
        publish_at: null,
        is_internal: 0,
        is_local: 0,
        receivers: ['followers', 'vips'],
      },
      publishDate: moment(),
      publishTime: moment(),
    };
    this.cityRef = React.createRef();
    this.addressRef = React.createRef();
  }

  componentDidMount() {
    if (!this.props.fundsManager.id || !this.props.fundsManager)
      this.props.history.replace(`/admin/fundsmanager/management`);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        funds_manager_id: nextProps.fundsManager.id,
      },
    }));

    if (nextProps.locationData !== this.props.locationData) {
      const gpsData = {
        longitude: nextProps.locationData.lng,
        latitude: nextProps.locationData.lat,
      };
      this.updateFundsManagerEventsFormState(gpsData);
    }
  }

  updateFundsManagerEventsFormState = (values) => {
    this.setState((prevState) => ({
      isClicked: false,
      formData: {
        ...prevState.formData,
        ...values,
        longitude: values.longitude
          ? values.longitude
          : prevState.formData.longitude,
        latitude: values.latitude
          ? values.latitude
          : prevState.formData.latitude,
        links: prevState.formData.links,
        files: prevState.formData.files,
        event_date:
          values.event_date && values.event_date !== ''
            ? values.event_date
            : prevState.formData.event_date,
        publish_now: prevState.formData.publish_now,
        publish_at: prevState.formData.publish_at,
        is_internal: prevState.formData.is_internal,
        is_local:
          // NOTE: check if publication date is not in the past
          !prevState.formData.publish_at ||
          (prevState.formData.publish_at &&
            moment().unix() - prevState.formData.publish_at <= 0)
            ? prevState.formData.is_local
            : null,
        receivers:
          // NOTE: check if publication date is not in the past
          !prevState.formData.publish_at ||
          (prevState.formData.publish_at &&
            moment().unix() - prevState.formData.publish_at <= 0)
            ? prevState.formData.receivers
            : [],
      },
    }));
  };

  mergeLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      isClicked: false,
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values, linkToDelete) => {
    const { formData } = this.state;
    const filteredArray = formData[objectType].filter(
      (element) =>
        element.name !== linkToDelete.name ||
        element.url !== linkToDelete.url ||
        element.type !== linkToDelete.type,
    );

    this.setState((prevState) => ({
      isClicked: false,
      formData: {
        ...prevState.formData,
        [objectType]: filteredArray,
      },
    }));
  };

  sendFundsManagerData = (values) => {
    if (
      this.state.formData.links.filter((link) => link.type === 'type_webcast')
        .length > 1 ||
      this.state.formData.links.filter(
        (link) => link.type === 'type_archived_video',
      ).length > 1
    ) {
      return;
    }
    if (this.state.formData.longitude && this.state.formData.latitude) {
      this.setState(
        (prevState) => ({
          isClicked: true,
          formData: {
            ...prevState.formData,
            entitiable_type: 'funds_manager',
            entitiable_id: values.funds_manager_id,
            is_draft: values.is_draft,
            is_preview: values.is_preview,
            country_id: values.country_id,
            description: values.description,
            city: this.cityRef.current.value,
            adress: this.addressRef.current.value
              .toLowerCase()
              .split(' ')
              .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
              .join(' '),
            title: prevState.formData.title.trimStart(),
            files: values.files && values.files.length > 0 ? values.files : [],
          },
        }),
        () => {
          sendEventsDataRequest(omitBy(this.state.formData, isNil))
            .then((response) => {
              if (response.status === 200) {
                if (this.state.formData.is_preview) {
                  this.props.history.replace(`/events/${response.data.id}`);
                } else {
                  this.props.history.replace(
                    `/admin/fundsmanager/manage/${this.props.fundsManager.id}/events`,
                  );
                }
              }
            })
            .catch((err) => {
              if (err.response.data) {
                this.setState({
                  isClicked: false,
                  apiMessage: {
                    ...err.response.data.errors,
                  },
                });
              }
            });
        },
      );
    }
  };

  handleCancelButton = () => {
    this.props.history.replace(
      `/admin/fundsmanager/manage/${this.props.fundsManager.id}/events`,
    );
  };

  handlePublishRadioChange = (e) => {
    const value = e.target.value === 'true';
    this.setState((prevState) => ({
      publishDate: moment(),
      publishTime: moment(),
      formData: {
        ...prevState.formData,
        publish_now: value,
        publish_at: value ? null : moment().unix(),
      },
    }));
  };

  handlePublishDataChange = (date, time) => {
    if (date) {
      const publishDate = date;
      publishDate.set('hour', time.hour());
      publishDate.set('minute', time.minute());
      this.setState((prevState) => ({
        publishDate: date,
        publishTime: time,
        formData: {
          ...prevState.formData,
          publish_now: false,
          publish_at: publishDate.unix(),
        },
      }));
    }
  };

  handlePublicityRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        is_internal: inputValue === 'internal' ? 1 : 0,
        receivers:
          inputValue === 'internal'
            ? prevState.formData.receivers.filter((i) => i !== 'followers')
            : prevState.formData.receivers,
      },
    }));
  };

  handleNotificationRangeRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        is_local: inputValue === 'local' ? 1 : 0,
      },
    }));
  };

  handleNotificationReceiverCheckboxClick = (e) => {
    const { target } = e;
    if (target.checked) {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: [...prevState.formData.receivers, target.name],
        },
      }));
    } else {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: prevState.formData.receivers.filter(
            (i) => i !== target.name,
          ),
        },
      }));
    }
  };

  removeCountryError = () => this.setState({ countryError: '' });

  render() {
    const { apiErrors, countryError } = this.state;

    return (
      <div className="add-event">
        <Formik
          ref={this.form}
          validationSchema={validationSchema}
          onSubmit={(values) => {
            this.setState(
              {
                isClicked: true,
              },
              () => this.sendFundsManagerData(values),
            );
          }}
          initialValues={this.state.formData}
          render={({
            values,
            errors,
            setValues,
            touched,
            isValid,
            handleSubmit,
            handleChange,
            handleBlur,
            setFieldTouched,
            setFieldError,
            setFieldValue,
          }) => (
            <form onSubmit={handleSubmit}>
              <header className="add-event-header">
                <h2>Add Event</h2>
              </header>
              <AddEventFormView
                errorsFromApi={apiErrors}
                checkBoxisChecked={this.setAllowShareHolders}
                values={values}
                errors={errors}
                touched={touched}
                handleChange={handleChange}
                handleBlur={handleBlur}
                setFieldTouched={setFieldTouched}
                setFieldValue={setFieldValue}
                setFieldError={setFieldError}
                updateFundsManagerEventsFormState={
                  this.updateFundsManagerEventsFormState
                }
                mergeLinksArray={this.mergeLinksArray}
                deleteLinksArray={this.deleteLinksArray}
                publishRadioValue={this.state.formData.publish_now}
                publishTime={this.state.publishTime}
                publishDate={this.state.publishDate}
                handlePublishRadioChange={this.handlePublishRadioChange}
                handlePublishDataChange={this.handlePublishDataChange}
                handlePublicityRadioChange={this.handlePublicityRadioChange}
                isInternal={this.state.formData.is_internal}
                userData={this.props.userData}
                fundsManagerId={this.props.fundsManager.id}
                publishAt={this.state.formData.publish_at}
                isLocal={this.state.formData.is_local}
                handleNotificationRangeRadioChange={
                  this.handleNotificationRangeRadioChange
                }
                handleNotificationReceiverCheckboxClick={
                  this.handleNotificationReceiverCheckboxClick
                }
                receivers={this.state.formData.receivers}
                countryError={countryError}
                removeCountryError={this.removeCountryError}
                links={this.state.formData.links}
                cityRef={this.cityRef}
                addressRef={this.addressRef}
              />

              {Object.keys(this.state.apiMessage).map((element) =>
                this.state.apiMessage[element].map((error) => (
                  <span key={shortid.generate()} className="apisErrors">
                    {error}
                  </span>
                )),
              )}

              <div className="buttons__container">
                <div className="draft__buttons">
                  <div
                    onClick={(e) => {
                      if (!values.country_id) {
                        this.setState({
                          countryError: 'This field is required.',
                        });
                      }
                      setValues({
                        adress: values.adress,
                        title: values.title,
                        city: values.city,
                        is_draft: 1,
                        is_preview: 1,
                        description: values.description,
                        country_id: values.country_id,
                        funds_manager_id: values.funds_manager_id,
                      });
                      handleSubmit(e);
                    }}
                    disabled={this.state.isClicked}
                    role="presentation"
                    className="draft__preview"
                  >
                    <div className="preview__icon" />
                    <div className="preview__text">Preview</div>
                  </div>

                  <div
                    role="presentation"
                    className="draft__save"
                    disabled={this.state.isClicked}
                    onClick={(e) => {
                      if (!values.country_id) {
                        this.setState({
                          countryError: 'This field is required.',
                        });
                      }
                      setValues({
                        is_draft: 1,
                        is_preview: 0,
                        adress: values.adress,
                        title: values.title,
                        city: values.city,
                        description: values.description,
                        country_id: values.country_id,
                        funds_manager_id: values.funds_manager_id,
                      });
                      handleSubmit(e);
                    }}
                  >
                    Save as draft
                  </div>
                </div>

                <div className="add-event-form__buttons">
                  <Button
                    onClick={this.handleCancelButton}
                    outline
                    color="primary  mr-4"
                  >
                    CANCEL
                  </Button>

                  <Button
                    color="primary"
                    type="submit"
                    disabled={this.state.isClicked}
                    onClick={() => {
                      if (!values.country_id) {
                        this.setState({
                          countryError: 'This field is required.',
                        });
                      }
                      if (!isValid) {
                        setValues({
                          adress: values.adress,
                          title: values.title,
                          city: values.city,
                          is_draft: 0,
                          is_preview: 0,
                          description: values.description,
                          country_id: values.country_id,
                          funds_manager_id: values.funds_manager_id,
                        });
                      }
                    }}
                  >
                    Publish
                  </Button>
                </div>
              </div>
              <div>{this.state.sendSuccessMsg}</div>
            </form>
          )}
        />
      </div>
    );
  }
}

export default withRouter(AddEventForm);
