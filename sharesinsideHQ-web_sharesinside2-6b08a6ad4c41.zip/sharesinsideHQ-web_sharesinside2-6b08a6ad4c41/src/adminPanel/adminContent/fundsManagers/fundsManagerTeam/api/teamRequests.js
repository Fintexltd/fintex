import axios from 'axios';

export const requestToken = (data, type) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/attachment?type=type_${type}`,
    data,
  );

export const createFundsManagerEmployee = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/employees`, data);

export const updateFundsManagerEmployee = (id, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/employees/${id}`, data);
