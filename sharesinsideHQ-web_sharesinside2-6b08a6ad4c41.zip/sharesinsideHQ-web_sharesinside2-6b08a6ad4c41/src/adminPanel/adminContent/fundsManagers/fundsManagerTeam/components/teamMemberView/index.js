import React from 'react';
import TextTruncate from 'react-text-truncate';
import EditMember from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam/containers/editMember';
import emailIcon from 'assets/icons/contact.svg';
import defaultPhoto from 'assets/icons/member_placeholder.svg';
import binIcon from 'assets/icons/remove_icon_red.svg';
import pencilIcon from 'assets/icons/edit_icon_blue.svg';
import attachmentIcon from 'assets/icons/attachement_icon_small_blue.svg';
import { isEditor } from 'userAuth/utils/permissions';
import 'adminPanel/adminContent/team/components/teamMemberView/index.scss';

const TeamMemberView = ({
  employeeId,
  groupId,
  name,
  photoUrl,
  position,
  fundsManagerId,
  email,
  phone,
  attachment,
  description,
  diaplayedMemberIndexes,
  groupIndex,
  memberIndex,
  toggleDetails,
  toggleEdited,
  editedMemberIndexes,
  getFundsManagerTeam,
  removeEmployee,
  userData,
}) => (
  <li className="manage-team__employees-item">
    {!isEditor(userData, fundsManagerId) && (
      <div className="manage-team__edit-options">
        <div
          role="presentation"
          className="manage-team__group__icon-wrapper"
          onClick={() => {
            toggleEdited(groupIndex, memberIndex);
          }}
        >
          <img alt="" className="manage-team__group__icon" src={pencilIcon} />
          <span className="manage-team__edit-options__edit">edit</span>
        </div>

        <div
          className="manage-team__group__icon-wrapper"
          role="presentation"
          onClick={() => {
            removeEmployee(employeeId, groupIndex, memberIndex);
          }}
        >
          <img alt="" className="manage-team__group__icon" src={binIcon} />
          <span className="manage-team__edit-options__remove">remove</span>
        </div>
      </div>
    )}
    <div
      className="manage-team__employees-item__photo"
      alt="employee"
      style={{
        backgroundImage: `url(${photoUrl || defaultPhoto})`,
      }}
    />
    <div className="manage-team__data">
      <div className="manage-team__sub-data">
        <h3 className="manage-team__data__name">
          <TextTruncate line={2} truncateText="…" text={name} />
        </h3>
        <div className="manage-team__data__position">
          <TextTruncate line={3} truncateText="…" text={position} />
        </div>
        <button
          onClick={() => toggleDetails(groupIndex, memberIndex)}
          className="manage-team__button manage-team__data__button"
        >
          {' '}
          See More
        </button>
      </div>
      <div className="manage-team__sub-data">
        {email && (
          <div className="manage-team__data__email">
            <img
              alt="e-mail"
              className="manage-team__data__icon"
              src={emailIcon}
            />
            <a className="manage-team__data__link" href={`mailto:${email}`}>
              {email}
            </a>
          </div>
        )}
        {attachment && (
          <div className="manage-team__data__email">
            <img
              alt="attachment"
              className="manage-team__data__icon"
              src={attachmentIcon}
            />
            <a
              className="manage-team__data__link"
              href={attachment.url}
              target="_blank"
              rel="noopener noreferrer"
            >
              {attachment.oryginal_name}
            </a>
          </div>
        )}
      </div>
    </div>{' '}
    {editedMemberIndexes[0] === groupIndex &&
      editedMemberIndexes[1] === memberIndex && (
        <EditMember
          initialValues={{
            employeeName: name,
            position,
            email,
            contact: phone,
            description,
          }}
          initAttachment={attachment}
          photoUrl={photoUrl}
          employeeId={employeeId}
          groupId={groupId}
          diaplayedMemberIndexes={diaplayedMemberIndexes}
          memberIndex={memberIndex}
          groupIndex={groupIndex}
          toggleDetails={toggleDetails}
          handleOutsideClick={() => {
            toggleEdited();
          }}
          editedMemberIndexes={editedMemberIndexes}
          getFundsManagerTeam={getFundsManagerTeam}
          fundsManagerId={fundsManagerId}
        />
      )}
  </li>
);

export default TeamMemberView;
