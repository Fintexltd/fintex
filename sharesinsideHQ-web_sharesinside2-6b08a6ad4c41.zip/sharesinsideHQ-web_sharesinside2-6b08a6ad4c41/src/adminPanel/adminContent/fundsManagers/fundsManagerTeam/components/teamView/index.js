import React from 'react';
import PropTypes from 'prop-types';
import binIcon from 'assets/icons/remove_icon_red.svg';
import pencilIcon from 'assets/icons/edit_icon_blue.svg';
import plus from 'assets/icons/add_icon_big_white.svg';
import plusBlue from 'assets/icons/add_icon_big_blue.svg';
import { ButtonGroup, Button } from 'reactstrap';
import ModalContainer from 'common/components/modalContainer';
import EditMember from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam/containers/editMember';
import EditGroupName from 'adminPanel/adminContent/team/components/editGroupsView/index.js';
import TeamMemberView from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam/components/teamMemberView';
import shortid from 'shortid';
import { isEditor } from 'userAuth/utils/permissions';
import 'adminPanel/adminContent/team/components/teamView/index.scss';

const TeamView = ({
  team,
  fundsManagerId,
  toggleAllTeam,
  fullTeamViewIndex,
  diaplayedMemberIndexes,
  toggleDetails,
  teamMembersToShow,
  toggleEdited,
  editedMemberIndexes,
  addNewMember,
  toggleAddNewMember,
  removeEmployee,
  getFundsManagerTeam,
  toggleEditGroupName,
  editedGroupNameIndex,
  sendGroupName,
  toggleAddNewGroup,
  addNewGroup,
  sendNewGroup,
  toggleRemoveGroupModal,
  removeGroupIndex,
  removeGroup,
  userData,
}) => (
  <div className="manage-team">
    <ul className="manage-team__group">
      {team.map((group, groupIndex) => (
        <li key={shortid.generate()}>
          <div className="manage-team__group">
            <header className="manage-team__group__header">
              <h2 className="manage-team__group__headline">
                {group.name}
                {!isEditor(userData, fundsManagerId) && (
                  <span className="manage-team__group__header__edit-options">
                    <div
                      role="presentation"
                      className="manage-team__group__icon-wrapper"
                      onClick={() => toggleEditGroupName(groupIndex)}
                    >
                      <img
                        alt=""
                        className="manage-team__group__icon"
                        src={pencilIcon}
                      />
                    </div>
                    <div
                      className="manage-team__group__icon-wrapper"
                      role="presentation"
                      onClick={() => toggleRemoveGroupModal(groupIndex)}
                    >
                      <img
                        alt=""
                        className="manage-team__group__icon"
                        src={binIcon}
                      />
                    </div>
                  </span>
                )}
              </h2>
            </header>
            <ul className="manage-team__employees-list">
              {!isEditor(userData, fundsManagerId) && (
                <li className="manage-team__employees-item addButton">
                  <div className="manage-team__add-button">
                    <div
                      role="presentation"
                      onClick={() => {
                        toggleAddNewMember(group.id);
                      }}
                    >
                      <img src={plus} height={60} alt="" />
                      <div className="manage-team__add-button__text">
                        Add New
                      </div>
                    </div>
                  </div>
                </li>
              )}
              {group.data.map(
                (member, memberIndex) =>
                  (memberIndex < teamMembersToShow ||
                    fullTeamViewIndex[groupIndex]) && (
                    <TeamMemberView
                      key={shortid.generate()}
                      employeeId={member.id}
                      groupId={group.id}
                      name={member.name}
                      photoUrl={member.photo_url}
                      position={member.position}
                      email={member.email}
                      phone={member.phone_number}
                      attachment={member.attachment}
                      description={member.description}
                      diaplayedMemberIndexes={diaplayedMemberIndexes}
                      memberIndex={memberIndex}
                      groupIndex={groupIndex}
                      toggleDetails={toggleDetails}
                      fundsManagerId={fundsManagerId}
                      toggleEdited={toggleEdited}
                      toggleAddNewMember={toggleAddNewMember}
                      editedMemberIndexes={editedMemberIndexes}
                      addNewMember={addNewMember}
                      getFundsManagerTeam={getFundsManagerTeam}
                      removeEmployee={removeEmployee}
                      userData={userData}
                    />
                  ),
              )}

              {addNewMember === group.id && (
                <EditMember
                  addNewMember
                  groupId={group.id}
                  diaplayedMemberIndexes={diaplayedMemberIndexes}
                  groupIndex={groupIndex}
                  toggleDetails={toggleDetails}
                  editedMemberIndexes={editedMemberIndexes}
                  handleOutsideClick={() => {
                    toggleAddNewMember();
                  }}
                  getFundsManagerTeam={getFundsManagerTeam}
                  fundsManagerId={fundsManagerId}
                />
              )}
            </ul>
            {editedGroupNameIndex === groupIndex && (
              <EditGroupName
                handleToggle={toggleEditGroupName}
                sendGroupName={sendGroupName}
                initName={group.name}
                id={group.id}
              />
            )}{' '}
            {removeGroupIndex === groupIndex &&
              group.data.length > 0 && (
                <ModalContainer
                  className="manage-team__remove-group-modal"
                  handleOutsideClick={() => {
                    toggleRemoveGroupModal();
                  }}
                >
                  Warning! All employee data in this group will be removed!
                  <ButtonGroup>
                    <Button
                      outline
                      color="primary"
                      className="mr-5"
                      type="button"
                      onClick={() => {
                        toggleRemoveGroupModal();
                      }}
                    >
                      Cancel
                    </Button>

                    <Button
                      onClick={() => {
                        removeGroup(group.id);
                      }}
                      color="danger"
                    >
                      Delete
                    </Button>
                  </ButtonGroup>
                </ModalContainer>
              )}{' '}
            {removeGroupIndex === groupIndex &&
              group.data.length === 0 &&
              removeGroup(group.id)}
            <div className="fundsManager-team__see-all">
              <button
                className="manage-team__button fundsManager-team__see-all__button"
                onClick={() => toggleAllTeam(groupIndex)}
              >
                {(fullTeamViewIndex[groupIndex] && 'Hide') ||
                  (group.data.length > teamMembersToShow && 'See All') ||
                  ''}
              </button>
            </div>
          </div>
        </li>
      ))}
    </ul>
    {!isEditor(userData, fundsManagerId) && (
      <div
        className="add-link mt-3"
        role="presentation"
        onClick={toggleAddNewGroup}
      >
        <img src={plusBlue} alt="" height={30} width={30} />
        <span>Add new section</span>
      </div>
    )}
    {addNewGroup && (
      <EditGroupName
        handleToggle={toggleAddNewGroup}
        sendGroupName={sendGroupName}
        sendNewGroup={sendNewGroup}
        addNewGroup
      />
    )}
  </div>
);

export default TeamView;

TeamView.defaultProps = {
  team: [],
  fundsManagerId: null,
  teamMembersToShow: null,
  editedGroupNameIndex: null,
  fullTeamViewIndex: [],
  editedMemberIndexes: [],
  diaplayedMemberIndexes: [],
  removeGroupIndex: null,
  toggleDetails: null,
};

TeamView.propTypes = {
  fundsManagerId: PropTypes.number,
  toggleAllTeam: PropTypes.func.isRequired,
  fullTeamViewIndex: PropTypes.arrayOf(PropTypes.number),
  diaplayedMemberIndexes: PropTypes.arrayOf(PropTypes.number),
  toggleDetails: PropTypes.func,
  teamMembersToShow: PropTypes.number,
  toggleEdited: PropTypes.func.isRequired,
  editedMemberIndexes: PropTypes.arrayOf(PropTypes.number),
  toggleAddNewMember: PropTypes.func.isRequired,
  removeEmployee: PropTypes.func.isRequired,
  getFundsManagerTeam: PropTypes.func.isRequired,
  toggleEditGroupName: PropTypes.func.isRequired,
  editedGroupNameIndex: PropTypes.number,
  sendGroupName: PropTypes.func.isRequired,
  toggleAddNewGroup: PropTypes.func.isRequired,
  addNewGroup: PropTypes.bool.isRequired,
  sendNewGroup: PropTypes.func.isRequired,
  toggleRemoveGroupModal: PropTypes.func.isRequired,
  removeGroupIndex: PropTypes.number,
  removeGroup: PropTypes.func.isRequired,
  team: PropTypes.arrayOf(PropTypes.object),
};
