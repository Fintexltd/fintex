import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Formik } from 'formik';
import { memberFormSchema } from 'adminPanel/adminContent/team/validators/memberFormSchema.js';
import EditMemberView from 'adminPanel/adminContent/team/components/editMemberView/index.js';
import {
  requestToken,
  createFundsManagerEmployee,
  updateFundsManagerEmployee,
} from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam/api/teamRequests';
import { fetchFundsManagerTeam } from 'common/redux/actions/fundsManagerTeamActions.js';
import setSubmitErrors from 'adminPanel/adminContent/team/utils/submitErrors';

const mapDispatchToProps = (dispatch) => ({
  reloadFundsManagerTeam: bindActionCreators(fetchFundsManagerTeam, dispatch),
});

class EditMember extends Component {
  constructor(props) {
    super(props);
    this.state = {
      photoUrl: this.props.photoUrl,
      formData: {
        sectionId: this.props.groupId,
        photoToken: '',
        attachmentToken: [''],
        deleteAttachment: false,
        description: '',
      },
    };
  }

  setImageToken = (imageFile) => {
    const imgAsForm = new FormData();
    imgAsForm.append('file', imageFile);
    requestToken(imgAsForm, 'image')
      .catch((err) => {
        if (err.response.data) {
          this.setState({
            imageErrors: err.response.data.message,
          });
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState((prevState) => ({
            imageErrors: '',
            formData: {
              ...prevState.formData,
              photoToken: res.data.token,
            },
          }));
        }
      });
  };

  setHeaderImages = (e) => {
    const imagesValidSize = 200;
    const imageFile = e.target.files[0];
    const reader = new FileReader();
    const image = new Image();
    if (imageFile) {
      reader.readAsDataURL(imageFile);
      reader.addEventListener('load', () => {
        image.src = reader.result;
        image.addEventListener('load', () => {
          if (
            image.width >= imagesValidSize &&
            image.height >= imagesValidSize
          ) {
            this.setImageToken(imageFile);
            this.setState({
              photoUrl: image.src,
            });
          } else {
            this.setState({
              imageErrors: `Photo should be at least ${imagesValidSize}px x ${imagesValidSize}px`,
            });
          }
        });
      });
    }
  };

  handleInitFilesDelete = () => {
    this.setState((prevState) => ({
      formData: { ...prevState.formData, deleteAttachment: true },
    }));
  };

  formDataToSend = (values) => {
    const { photoToken, sectionId, deleteAttachment } = this.state.formData;
    let data = {
      section_id: sectionId,
      name: values.employeeName,
      position: values.position,
      phone_number: values.contact,
      email: values.email,
      description: this.state.formData.description
        ? this.state.formData.description
        : values.description,
      attachment: values.attachment,
    };

    if (this.props.addNewMember) {
      data.photo = photoToken;
      data.attachment = values.attachment;
    } else {
      if (!values.attachment && deleteAttachment === true) {
        data.delete_attachment = deleteAttachment;
      }

      data = photoToken ? { ...data, photo: photoToken } : data;
      data = values.attachment
        ? { ...data, attachment: values.attachment }
        : data;
    }

    return data;
  };

  createFundsManagerEmployee = (values, actions) => {
    createFundsManagerEmployee(this.formDataToSend(values))
      .then(() => {
        this.props.handleOutsideClick();
        this.props.reloadFundsManagerTeam(this.props.fundsManagerId);
      })
      .catch((error) => {
        actions.setErrors(setSubmitErrors(error));
      });
  };

  updateFundsManagerEmployee = (values, actions) => {
    updateFundsManagerEmployee(
      this.props.employeeId,
      this.formDataToSend(values),
    )
      .then(() => {
        this.props.handleOutsideClick();
        this.props.reloadFundsManagerTeam(this.props.fundsManagerId);
      })
      .catch((error) => {
        actions.setErrors(setSubmitErrors(error));
      });
  };

  updateEditMemberFormState = (values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        description: values.description,
      },
    }));
  };

  render() {
    return (
      <Formik
        validationSchema={memberFormSchema}
        initialValues={this.props.initialValues || {}}
        onSubmit={(values, { setErrors }) => {
          if (this.props.addNewMember) {
            this.createFundsManagerEmployee(values, { setErrors });
          } else {
            this.updateFundsManagerEmployee(values, { setErrors });
          }
        }}
        render={({
          values,
          errors,
          touched,
          isValid,
          handleChange,
          handleBlur,
          handleSubmit,
          setFieldValue,
          setFieldTouched,
          setValues,
        }) => (
          <EditMemberView
            photoUrl={this.state.photoUrl}
            imageErrors={this.state.imageErrors}
            values={values}
            errors={errors}
            touched={touched}
            isValid={isValid}
            handleSubmit={handleSubmit}
            handleChange={handleChange}
            handleBlur={handleBlur}
            setFieldValue={setFieldValue}
            setFieldTouched={setFieldTouched}
            setHeaderImages={this.setHeaderImages}
            initAttachment={this.props.initAttachment}
            handleOutsideClick={this.props.handleOutsideClick}
            setValues={setValues}
            handleInitFilesDelete={this.handleInitFilesDelete}
            addNewMember={this.props.addNewMember}
            updateEditMemberFormState={this.updateEditMemberFormState}
          />
        )}
      />
    );
  }
}
export default connect(null, mapDispatchToProps)(EditMember);
