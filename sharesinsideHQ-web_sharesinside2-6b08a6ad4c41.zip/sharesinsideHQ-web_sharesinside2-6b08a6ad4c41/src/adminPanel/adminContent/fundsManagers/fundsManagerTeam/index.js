import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import TeamView from 'adminPanel/adminContent/fundsManagers/fundsManagerTeam/components/teamView';
import { isNotebookViewActive } from 'common/utils/viewUtils.js';
import { disableScroll } from 'common/utils/disableScroll.js';
import { isEditor } from 'userAuth/utils/permissions';
import {
  fetchFundsManagerTeam,
  removeEmployee,
  updateFundsManagerSection,
  createFundsManagerSection,
  removeFundsManagerSection,
} from 'common/redux/actions/fundsManagerTeamActions';

const mapStateToProps = (state) => ({
  team: state.fundsManagerTeam.list,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getFundsManagerGroups: bindActionCreators(fetchFundsManagerTeam, dispatch),
  removeThisEmployee: bindActionCreators(removeEmployee, dispatch),
  sendEditedFundsManagerSection: bindActionCreators(
    updateFundsManagerSection,
    dispatch,
  ),
  sendNewFundsManagerSection: bindActionCreators(
    createFundsManagerSection,
    dispatch,
  ),
  removeFundsManagerSection: bindActionCreators(
    removeFundsManagerSection,
    dispatch,
  ),
});

class Team extends Component {
  constructor() {
    super();
    this.state = {
      fullTeamViewIndex: [],
      diaplayedMemberIndexes: [],
      editedMemberIndexes: [],
      editedGroupNameIndex: null,
      addNewMember: false,
      addNewGroup: false,
      removeGroupIndex: null,
    };
  }

  componentDidMount() {
    const fundsManagerId = Number(this.props.match.params.id);
    if (
      !(
        this.props.userData.relations_funds_manager.secondary_admin &&
        this.props.userData.relations_funds_manager.secondary_admin.includes(
          fundsManagerId,
        )
      ) &&
      !(
        this.props.userData.relations_funds_manager.primary_admin &&
        this.props.userData.relations_funds_manager.primary_admin.includes(
          fundsManagerId,
        )
      ) &&
      !(
        this.props.userData.relations_funds_manager.domestic_admin &&
        this.props.userData.relations_funds_manager.domestic_admin.includes(
          fundsManagerId,
        )
      ) &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    ) {
      this.props.history.push(
        `/admin/fundsManager/manage/${fundsManagerId}/about`,
      );
    }
    this.getFundsManagerTeam();
    this.checkNotebookViewActive();
    window.addEventListener('resize', this.checkNotebookViewActive);
  }

  getFundsManagerTeam() {
    this.props.getFundsManagerGroups(this.props.match.params.id);
  }

  toggleAllTeam = (index) => {
    this.setState((prevState) => {
      const fullTeamViewIndexCopy = prevState.fullTeamViewIndex;
      fullTeamViewIndexCopy[index] = !fullTeamViewIndexCopy[index];
      return { fullTeamViewIndex: fullTeamViewIndexCopy };
    });
  };

  checkNotebookViewActive = () => {
    if (isNotebookViewActive()) {
      this.setState({
        teamMembersToShow: isEditor(
          this.props.userData,
          this.props.fundsManagerId,
        )
          ? 2
          : 1,
      });
    } else {
      this.setState({
        teamMembersToShow: isEditor(
          this.props.userData,
          this.props.fundsManagerId,
        )
          ? 3
          : 2,
      });
    }
  };

  sendGroupName = (groupId, name) => {
    this.props.sendEditedFundsManagerSection(groupId, { name }).then(() => {
      this.getFundsManagerTeam(this.props.fundsManagerId);
    });
    this.toggleEditGroupName();
  };

  removeGroup = (groupId) => {
    this.props.removeFundsManagerSection(groupId).then(() => {
      this.getFundsManagerTeam(this.props.fundsManagerId);
    });
    this.toggleRemoveGroupModal();
  };

  sendNewGroup = (name) => {
    this.props
      .sendNewFundsManagerSection({
        name,
        entitiable_type: 'funds_manager',
        entitiable_id: this.props.fundsManagerId,
        type: 'employee_section',
      })
      .then(() => {
        this.getFundsManagerTeam(this.props.fundsManagerId);
      });
    this.toggleAddNewGroup();
  };

  toggleEditGroupName = (groupIndex = null) => {
    this.setState({ editedGroupNameIndex: groupIndex });
    this.disableScrolloModal(groupIndex);
  };

  toggleRemoveGroupModal = (groupIndex = null) => {
    this.setState({ removeGroupIndex: groupIndex });
    this.disableScrolloModal(groupIndex);
  };

  toggleAddNewGroup = () => {
    const disableScrollValue = !this.state.addNewGroup ? true : null;
    this.disableScrolloModal(disableScrollValue);

    this.setState((prevState) => ({ addNewGroup: !prevState.addNewGroup }));
  };

  toggleEdited = (groupIndex = null, memberIndex = null) => {
    this.setState({ editedMemberIndexes: [groupIndex, memberIndex] });
    this.disableScrolloModal(groupIndex);
  };

  toggleAddNewMember = (groupId = null) => {
    this.setState({ addNewMember: groupId });
    this.disableScrolloModal(groupId);
  };

  disableScrolloModal = (disable) => {
    disableScroll(disable !== null);
  };

  removeEmployee = (employeeId, groupIndex, memberIndex) => {
    this.props.removeThisEmployee(employeeId, groupIndex, memberIndex);
  };

  toggleDetails = () => {
    // TO DO
  };

  render() {
    return (
      <>
        <TeamView
          team={this.props.team}
          fundsManagerId={this.props.fundsManagerId}
          toggleAllTeam={this.toggleAllTeam}
          fullTeamViewIndex={this.state.fullTeamViewIndex}
          diaplayedMemberIndexes={this.state.diaplayedMemberIndexes}
          toggleDetails={this.toggleDetails}
          teamMembersToShow={this.state.teamMembersToShow}
          toggleEdited={this.toggleEdited}
          editedMemberIndexes={this.state.editedMemberIndexes}
          addNewMember={this.state.addNewMember}
          toggleAddNewMember={this.toggleAddNewMember}
          getFundsManagerTeam={this.getFundsManagerTeam}
          removeEmployee={this.removeEmployee}
          editedGroupNameIndex={this.state.editedGroupNameIndex}
          toggleEditGroupName={this.toggleEditGroupName}
          sendGroupName={this.sendGroupName}
          addNewGroup={this.state.addNewGroup}
          toggleAddNewGroup={this.toggleAddNewGroup}
          sendNewGroup={this.sendNewGroup}
          isRemoveGroupModalVisible={this.state.isRemoveGroupModalVisible}
          toggleRemoveGroupModal={this.toggleRemoveGroupModal}
          removeGroupIndex={this.state.removeGroupIndex}
          removeGroup={this.removeGroup}
          userData={this.props.userData}
        />
      </>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(Team);

Team.defaultProps = {
  team: [],
};

Team.propTypes = {
  getFundsManagerGroups: PropTypes.func.isRequired,
  removeThisEmployee: PropTypes.func.isRequired,
  sendEditedFundsManagerSection: PropTypes.func.isRequired,
  sendNewFundsManagerSection: PropTypes.func.isRequired,
  removeFundsManagerSection: PropTypes.func.isRequired,
  team: PropTypes.arrayOf(PropTypes.object),
};
