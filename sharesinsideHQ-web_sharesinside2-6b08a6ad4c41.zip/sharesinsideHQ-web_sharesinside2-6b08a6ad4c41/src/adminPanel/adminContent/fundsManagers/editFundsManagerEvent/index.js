import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchEventsEditDataRequest } from 'adminPanel/adminContent/editEvent/api/editEventApi.js';
import EditEventForm from './containers/editEventForm';

const mapStateToProps = state => ({
  userData: state.userData.data,
  locationData: state.locationData.results,
});

class EditFundsManagerEvent extends Component {
  state = {
    event: {},
  };

  componentDidMount() {
    fetchEventsEditDataRequest(this.props.match.params.eventId).then(res => {
      this.setState({ event: res.data });
    });
  }

  render() {
    return (
      <div>
        <EditEventForm
          fundsManagerId={this.props.match.params.id}
          eventId={this.props.match.params.eventId}
          initEventData={this.state.event}
          userData={this.props.userData}
          locationData={this.props.locationData}
        />
      </div>
    );
  }
}
export default connect(mapStateToProps)(EditFundsManagerEvent);
