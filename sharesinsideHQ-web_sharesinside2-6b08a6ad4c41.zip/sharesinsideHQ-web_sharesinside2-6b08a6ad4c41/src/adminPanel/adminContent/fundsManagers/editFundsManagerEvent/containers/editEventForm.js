import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Row, Col, Button } from 'reactstrap';
import { Formik } from 'formik';
import { withRouter } from 'react-router';
import moment from 'moment';
import { isNil, omitBy } from 'lodash';
import { addEventSchema as validationSchema } from 'adminPanel/adminContent/editEvent/validators/editEventSchema';
import { updateEventsDataRequest } from 'adminPanel/adminContent/editEvent/api/editEventApi';
import CircleSpinner from 'common/components/circleSpinner';
import shortid from 'shortid';
import EditEventFormView from '../components/editEventFormView';

class EditEventForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      initDataLoaded: false,
      apiErrors: '',
      apiMessage: {},
      sendSuccessMsg: '',
      isClicked: false,
      formData: {
        city: '',
        adress: '',
        title: '',
        country_id: null,
        delete_attachments: [],
        delete_links: [],
        description: '',
        event_date: '',
        longitude: null,
        latitude: null,
        is_draft: 0,
        is_preview: 0,
        publish_now: true,
        files: [],
        links: [],
        is_internal: 0,
      },
      editedCity: null,
      editedAdress: null,
    };
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.initEventData !== this.props.initEventData) {
      const initEvent = nextProps.initEventData;

      const initFiles = initEvent.files.map((file) => ({
        name: file.oryginal_name,
        id: file.id,
      }));
      const initWebcastLinks = initEvent.links.filter(
        (link) => link.type === 'type_webcast',
      );
      const initVideoLinks = initEvent.links.filter(
        (link) => link.type === 'type_archived_video',
      );

      this.setState((prevState) => ({
        initFiles,
        initWebcastLinks,
        initVideoLinks,
        initDataLoaded: true,
        publishDate: moment.unix(initEvent.publish_at),
        publishTime: moment.unix(initEvent.publish_at),
        isPublished: initEvent.is_published,
        formData: {
          ...prevState.formData,
          publish_now: initEvent.publish_now,
          publish_at: initEvent.publish_at,
          country_id: initEvent.event_country.id,
          is_internal: initEvent.is_internal,
          is_local: initEvent.is_local,
          receivers: initEvent.receivers,
        },
      }));

      delete initEvent.files;
      this.updateFundsManagerEventsFormState(nextProps.initEventData);
    }

    if (nextProps.locationData !== this.props.locationData) {
      const gpsData = {
        longitude: nextProps.locationData.lng,
        latitude: nextProps.locationData.lat,
        city:
          this.state.editedCity !== null
            ? this.state.editedCity
            : this.state.formData.city,
        adress:
          this.state.editedAdress !== null
            ? this.state.editedAdress
            : this.state.formData.adress,
      };
      this.updateFundsManagerEventsFormState(gpsData);
    }
  }

  updateFundsManagerEventsFormState = (values) => {
    this.setState((prevState) => ({
      isClicked: false,
      formData: {
        ...prevState.formData,
        ...values,
        longitude: values.longitude
          ? values.longitude
          : prevState.formData.longitude,
        latitude: values.latitude
          ? values.latitude
          : prevState.formData.latitude,
        event_date:
          values.event_date && values.event_date !== ''
            ? values.event_date
            : prevState.formData.event_date,
        publish_now: prevState.formData.publish_now,
        publish_at: prevState.formData.publish_at,
        is_internal: prevState.formData.is_internal,
        is_local: prevState.formData.is_local,
        receivers: prevState.formData.receivers,
      },
    }));
  };

  mergeLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      isClicked: false,
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values, linkToDelete) => {
    this.setState({
      isClicked: false,
    });
    const { formData } = this.state;
    const filteredArray = formData[objectType].filter(
      (element) =>
        element.name !== linkToDelete.name ||
        element.url !== linkToDelete.url ||
        element.type !== linkToDelete.type,
    );

    this.setState(
      (prevState) => ({
        formData: {
          ...prevState.formData,
          [objectType]: filteredArray,
        },
      }),
      () => {
        if (linkToDelete.id) {
          this.initFilesDelete(linkToDelete.id, 'links');
        }
      },
    );
  };

  initFilesDelete = (id, type) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [`delete_${type}`]: [...prevState.formData[`delete_${type}`], id],
      },
    }));
  };

  handlePublishRadioChange = (e) => {
    const value = e.target.value === 'true';
    this.setState((prevState) => ({
      publishDate: moment(),
      publishTime: moment(),
      formData: {
        ...prevState.formData,
        publish_now: value,
        publish_at: value ? null : moment().unix(),
      },
    }));
  };

  handlePublishDataChange = (date, time) => {
    if (date) {
      const publishDate = date;
      publishDate.set('hour', time.hour());
      publishDate.set('minute', time.minute());
      this.setState((prevState) => ({
        publishDate: date,
        publishTime: time,
        formData: {
          ...prevState.formData,
          publish_now: false,
          publish_at: publishDate.unix(),
        },
      }));
    }
  };

  handlePublicityRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        is_internal: inputValue === 'internal' ? 1 : 0,
        receivers:
          inputValue === 'internal'
            ? prevState.formData.receivers.filter((i) => i !== 'followers')
            : prevState.formData.receivers,
      },
    }));
  };

  sendFundsManagerData = (values) => {
    if (
      this.state.formData.links.filter((link) => link.type === 'type_webcast')
        .length > 1 ||
      this.state.formData.links.filter(
        (link) => link.type === 'type_archived_video',
      ).length > 1
    ) {
      return;
    }
    this.setState(
      (prevState) => ({
        isClicked: false,
        formData: {
          ...prevState.formData,
          is_draft: values.is_draft,
          is_preview: values.is_preview,
          adress: values.adress
            .toLowerCase()
            .split(' ')
            .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
            .join(' '),
          title: prevState.formData.title.trimStart(),
          files: values.files && values.files.length > 0 ? values.files : [],
          is_local:
            // NOTE: check if publication date is not in the past
            !prevState.formData.publish_at ||
            (prevState.formData.publish_at &&
              moment().unix() - prevState.formData.publish_at <= 0)
              ? prevState.formData.is_local
              : null,
          receivers:
            // NOTE: check if publication date is not in the past
            !prevState.formData.publish_at ||
            (prevState.formData.publish_at &&
              moment().unix() - prevState.formData.publish_at <= 0)
              ? prevState.formData.receivers
              : [],
        },
      }),
      () => {
        updateEventsDataRequest(
          this.props.eventId,
          omitBy(this.state.formData, isNil),
        )
          .then((response) => {
            if (response.status === 200) {
              if (this.state.formData.is_preview) {
                this.props.history.replace(`/events/${this.props.eventId}`);
              } else {
                this.props.history.replace(
                  `/admin/fundsmanager/manage/${this.props.fundsManagerId}/events`,
                );
              }
            }

            this.setState({
              isClicked: false,
            });
          })
          .catch((err) => {
            if (err.response) {
              this.setState({
                isClicked: false,
                apiMessage: {
                  ...err.response.data.errors,
                },
              });
            }
          });
      },
    );
  };

  handleNotificationRangeRadioChange = (e) => {
    const inputValue = e.target.value;
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        is_local: inputValue === 'local' ? 1 : 0,
      },
    }));
  };

  handleNotificationReceiverCheckboxClick = (e) => {
    const { target } = e;
    if (target.checked) {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: [...prevState.formData.receivers, target.name],
        },
      }));
    } else {
      this.setState((prevState) => ({
        formData: {
          ...prevState.formData,
          receivers: prevState.formData.receivers.filter(
            (i) => i !== target.name,
          ),
        },
      }));
    }
  };

  handleCancelButton = () => {
    this.props.history.replace(
      `/admin/fundsmanager/manage/${this.props.fundsManagerId}/events`,
    );
  };

  updateLocation = (city, adress) => {
    this.setState({
      editedCity: city,
      editedAdress: adress,
    });
  };

  render() {
    const { apiErrors } = this.state;
    return (
      (this.state.initDataLoaded && (
        <div className="edit-event">
          <Formik
            ref={this.form}
            enableReinitialize
            initialValues={this.state.formData}
            validationSchema={validationSchema}
            onSubmit={(values, { setErrors }) => {
              this.sendFundsManagerData(values, setErrors);
              this.setState({
                isClicked: true,
              });
            }}
            render={({
              values,
              errors,
              setValues,
              touched,
              isValid,
              handleSubmit,
              handleChange,
              handleBlur,
              setFieldTouched,
              setFieldError,
              setFieldValue,
            }) => (
              <form onSubmit={handleSubmit}>
                <Row>
                  <Col>
                    <header className="edit-event-header">
                      <h2>Edit Event</h2>
                    </header>
                  </Col>
                </Row>
                <Row>
                  <EditEventFormView
                    initDate={this.state.formData.event_date}
                    initFiles={this.state.initFiles}
                    initWebcastLinks={this.state.initWebcastLinks}
                    initVideoLinks={this.state.initVideoLinks}
                    initCountryCode={this.state.initCountryCode}
                    errorsFromApi={apiErrors}
                    checkBoxisChecked={this.setAllowShareHolders}
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    updateFundsManagerEventsFormState={
                      this.updateFundsManagerEventsFormState
                    }
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                    handleInitFilesDelete={this.initFilesDelete}
                    publishRadioValue={this.state.formData.publish_now}
                    publishTime={this.state.publishTime}
                    publishDate={this.state.publishDate}
                    handlePublishRadioChange={this.handlePublishRadioChange}
                    handlePublishDataChange={this.handlePublishDataChange}
                    isPublished={this.state.isPublished}
                    handlePublicityRadioChange={this.handlePublicityRadioChange}
                    isInternal={this.state.formData.is_internal}
                    userData={this.props.userData}
                    fundsManagerId={this.props.fundsManagerId}
                    isLocal={this.state.formData.is_local}
                    handleNotificationRangeRadioChange={
                      this.handleNotificationRangeRadioChange
                    }
                    publishAt={this.state.formData.publish_at}
                    receivers={this.state.formData.receivers}
                    handleNotificationReceiverCheckboxClick={
                      this.handleNotificationReceiverCheckboxClick
                    }
                    updateLocation={this.updateLocation}
                    links={this.state.formData.links}
                  />
                </Row>

                <div className="buttons__container">
                  <div className="draft__buttons">
                    <div
                      onClick={(e) => {
                        setValues({
                          ...values,
                          is_draft: 1,
                          is_preview: 1,
                          country_id: values.country_id,
                        });
                        handleSubmit(e);
                      }}
                      disabled={this.state.isClicked}
                      role="presentation"
                      className="draft__preview"
                    >
                      <div className="preview__icon" />
                      <div className="preview__text">Preview</div>
                    </div>

                    <div
                      role="presentation"
                      className="draft__save"
                      disabled={this.state.isClicked}
                      onClick={(e) => {
                        setValues({
                          ...values,
                          is_draft: 1,
                          is_preview: 0,
                          country_id: values.country_id,
                        });
                        handleSubmit(e);
                      }}
                    >
                      Save as draft
                    </div>
                  </div>

                  <div className="add-event-form__buttons">
                    <Button
                      onClick={this.handleCancelButton}
                      outline
                      color="primary pull mr-4"
                    >
                      CANCEL
                    </Button>

                    <Button
                      color="primary"
                      type="submit"
                      disabled={this.state.isClicked}
                      onClick={() => {
                        if (!isValid) {
                          setValues({
                            ...values,
                            is_draft: 0,
                            is_preview: 0,
                            country_id: values.country_id,
                          });
                        }
                      }}
                    >
                      Publish
                    </Button>
                  </div>
                </div>
                {Object.keys(this.state.apiMessage).map((element) =>
                  this.state.apiMessage[element].map((error) => (
                    <span key={shortid.generate()} className="apisErrors">
                      {error}
                    </span>
                  )),
                )}
                <div>{this.state.sendSuccessMsg}</div>
              </form>
            )}
          />
        </div>
      )) || <CircleSpinner />
    );
  }
}

export default withRouter(EditEventForm);

EditEventForm.propTypes = {
  fundsManagerId: PropTypes.string.isRequired,
  eventId: PropTypes.string.isRequired,
  initEventData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.array,
      PropTypes.bool,
      PropTypes.object,
    ]),
  ).isRequired,
};
