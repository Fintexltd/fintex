import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Row, Col, Button, ButtonGroup } from 'reactstrap';
import { Link } from 'react-router-dom';
import { Formik } from 'formik';
import { bindActionCreators } from 'redux';
import { fundsManagerCreatorFormSchema as validationSchema } from 'adminPanel/adminContent/fundsManagers/fundsManagerCreator/validators/fundsManagerCreatorFormSchema';
import {
  requestImageToken,
  sendFundsManagerDataRequest,
} from 'adminPanel/adminContent/fundsManagers/fundsManagerCreator/api/fundsManagerCreatorApi';
import CreatorMap from 'adminPanel/adminContent/common/containers/creatorMap';
import CreatorHeader from 'adminPanel/adminContent/common/components/creatorHeader';
import CreatorSocialMedia from 'adminPanel/adminContent/common/components/creatorSocialMedia';
import UploadAttachments from 'common/components/uploadAttachments/index.js';
import AddLinks from 'common/components/addLinks/index.js';
import AddLinkOrVideo from 'common/components/addLinkOrVideo';
import ModalContainer from 'common/components/modalContainer';
import ExcludeCountries from 'common/components/excludeCountries';
import { disableScroll } from 'common/utils/disableScroll';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchCountryCallingCodesList from 'common/redux/actions/countryCallingCodesListActions';
import { fetchUserData } from 'common/redux/actions/userDataActions';
import setSubmitErrors from 'adminPanel/adminContent/adminCreator/utils/submitErrors';
import { googleMapURL } from 'common/api/googleMapsApi';
import FundsManagerCreatorForm from './containers/fundsManagerCreatorForm';
import FundsManagerCreatorDescription from './components/fundsManagerCreatorDescription';
import AddTermsAndConditions from './components/addTermsAndConditions';

import './index.scss';

const mapStateToProps = (state) => ({
  countriesList: state.countries.list,
  countryCallingCodesList: state.countryCallingCodes.list,
  locationData: state.locationData.results,
});

const mapDispatchToProps = (dispatch) => ({
  fetchCountriesList: () => dispatch(fetchCountriesList()),
  fetchCountryCallingCodesList: () => dispatch(fetchCountryCallingCodesList()),
  fetchUserData: bindActionCreators(fetchUserData, dispatch),
});

class FundsManagerCreatorView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      apiErrors: {},
      backgroundUrl: '',
      logoUrl: '',
      imagesErrors: '',
      sendSuccessMsg: '',
      displaySocialMediaForm: false,
      excludedFilters: [],
      countryCallingCodeError: '',
      termsAndConditionsError: '',
      formData: {
        logo: '',
        background: '',
        name: '',
        phone: '',
        links: [],
        video_links: [],
        videos: [],
        terms_and_conditions: [],
        terms_and_conditions_links: [],
        email: '',
        location: '',
        website: '',
        country_calling_code_id: '',
        dont_allow_shareholders: false,
        symbols: [],
        social_media: [],
        longitude: 74.011222,
        latitude: 40.706893,
        excluded: [],
        stock_exchange_emails: [],
      },
    };
  }

  componentDidMount() {
    this.props.fetchCountriesList();
    this.props.fetchCountryCallingCodesList();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.locationData !== this.props.locationData) {
      const gpsData = {
        longitude: nextProps.locationData.lng,
        latitude: nextProps.locationData.lat,
      };
      this.updateFundsManagerCreationFormState(gpsData);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      prevState.displaySocialMediaForm !== this.state.displaySocialMediaForm
    ) {
      disableScroll(this.state.displaySocialMediaForm);
    }
  }

  onVideoLinkAdded = (videoLink) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [videoLink],
        videos: [],
      },
    }));
  };

  onVideoLinkRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        video_links: [],
      },
    }));
  };

  onVideoTokenAdded = (videoToken) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [videoToken],
        video_links: [],
      },
    }));
  };

  onVideoTokenRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        videos: [],
      },
    }));
  };

  onTermLinkAdded = (termLink) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        terms_and_conditions_links: [termLink],
        terms_and_conditions: [],
      },
    }));
  };

  onTermLinkRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        terms_and_conditions_links: [],
      },
    }));
  };

  onTermTokenAdded = (termToken) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        terms_and_conditions: [termToken],
        terms_and_conditions_links: [],
      },
    }));
  };

  onTermTokenRemoved = () => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        terms_and_conditions: [],
      },
    }));
  };

  setHeaderImages = (e, type, setFieldValue) => {
    const imagesValidSize = { logo: 200, background: 940 };
    const imageFile = e.target.files[0];
    const reader = new FileReader();
    const image = new Image();
    if (imageFile) {
      reader.readAsDataURL(imageFile);
      reader.addEventListener('load', () => {
        image.src = reader.result;
        image.addEventListener('load', () => {
          if (
            (type === 'logo' &&
              image.width >= imagesValidSize.logo &&
              image.height >= imagesValidSize.logo) ||
            (type === 'background' && image.width >= imagesValidSize.background)
          ) {
            this.setState({
              [`${type}Url`]: image.src,
              imagesErrors: '',
            });

            this.setImageToken(imageFile, type, setFieldValue);
          } else {
            this.setState({
              imagesErrors: `${
                type.charAt(0).toUpperCase() + type.slice(1)
              } image should be at least ${imagesValidSize[type]}px wide ${
                type === 'logo' ? `and ${imagesValidSize[type]} px height` : ``
              }`,
            });
          }
        });
      });
    }
  };

  setImageToken = (imageFile, type, setFieldValue) => {
    const imgAsForm = new FormData();
    imgAsForm.append('file', imageFile);

    requestImageToken(imgAsForm, type)
      .catch((err) => {
        if (err.response.data) {
          this.setState({
            imagesErrors: err.response.data.message,
          });
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState((prevState) => ({
            formData: {
              ...prevState.formData,
              [`${type}`]: res.data.token,
            },
          }));

          setFieldValue(type, res.data.token);
        }
      });
  };

  setCountryToExclude = (values) => {
    this.setState((prevState) => ({
      excludedFilters: values,
      formData: {
        ...prevState.formData,
        excluded: values.map((item) => item.value),
      },
    }));
  };

  handleExcludedFilterRemoveClick = (label) => {
    const filteredOut = this.state.excludedFilters.filter(
      (el) => el.label !== label,
    );
    this.setState((prevState) => ({
      excludedFilters: filteredOut,
      formData: {
        ...prevState.formData,
        excluded: filteredOut.map((item) => item.value),
      },
    }));
  };

  displaySocialMediaForm = (shouldDisplay) => {
    this.setState({ displaySocialMediaForm: shouldDisplay });
  };

  updateSocialMediaLinks = (socialLinks) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        social_media: socialLinks,
      },
    }));
  };

  removeSocialLink = (linkTypeToRemove) => {
    this.updateSocialMediaLinks(
      this.state.formData.social_media.filter(
        (link) => link.type !== linkTypeToRemove,
      ),
    );
  };

  toggleDisplayDescriptionForm = () => {
    this.setState((prevState) => ({
      displayDescriptionForm: !prevState.displayDescriptionForm,
    }));
  };

  updateFundsManagerCreationFormState = (values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...values,
      },
    }));
  };

  updateStockData = (symbols, setValues, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        ...{ symbols },
      },
    }));

    setValues({
      ...values,
      symbols,
    });
  };

  mergeLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: [...prevState.formData[objectType], values],
      },
    }));
  };

  deleteLinksArray = (objectType, values) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        [objectType]: values,
      },
    }));
  };

  addStockExchangeEmail = (email) => {
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stock_exchange_emails: [
          ...prevState.formData.stock_exchange_emails,
          email,
        ],
      },
    }));
  };

  removeStockExchangeEmail = (emailToRemove) => {
    const filteredOut = this.state.formData.stock_exchange_emails.filter(
      (email) => email !== emailToRemove,
    );
    this.setState((prevState) => ({
      formData: {
        ...prevState.formData,
        stock_exchange_emails: filteredOut,
      },
    }));
  };

  sendFundsManagerData = (setErrors) => {
    const data = JSON.stringify(this.state.formData);
    sendFundsManagerDataRequest(data)
      .catch((error) => {
        if (error.response.data) {
          setErrors(setSubmitErrors(error));
        }
      })
      .then((res) => {
        if (res && res.data) {
          this.setState({ sendSuccessMsg: res.data.message });
          this.props.fetchUserData();
        }
      });
  };

  removeCountryCallingCodeError = () =>
    this.setState({ countryCallingCodeError: '' });

  removeTermsAndConditionsError = () =>
    this.setState({ termsAndConditionsError: '' });

  render() {
    const {
      apiErrors,
      logoUrl,
      backgroundUrl,
      imagesErrors,
      displaySocialMediaForm,
      sendSuccessMsg,
      countryCallingCodeError,
      termsAndConditionsError,
    } = this.state;

    return (
      <div className="admin-fundsmanager-creator">
        <header className="admin-creator-header">
          <h2 className="section-header"> Create New Fund-Manager</h2>
        </header>
        <Formik
          ref={this.form}
          validationSchema={validationSchema}
          initialValues={{}}
          onSubmit={(values, { setErrors }) => {
            this.sendFundsManagerData(setErrors);
          }}
          render={({
            values,
            errors,
            setValues,
            touched,
            isValid,
            handleSubmit,
            handleChange,
            handleBlur,
            setFieldTouched,
            setFieldError,
            setFieldValue,
          }) => (
            <form onSubmit={handleSubmit} noValidate>
              <CreatorHeader
                setHeaderImages={this.setHeaderImages}
                logoUrl={logoUrl}
                backgroundUrl={backgroundUrl}
                imagesErrors={imagesErrors}
                socialLinks={this.state.formData.social_media}
                displaySocialMediaForm={(shouldDisplay) =>
                  this.displaySocialMediaForm(shouldDisplay)}
                removeSocialLink={this.removeSocialLink}
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue}
              />
              <Row>
                <Col>
                  <header className="admin-creator-header basic">
                    <h2 className="section-header"> Basic Information </h2>
                  </header>
                </Col>
              </Row>
              <Row>
                <Col md={6}>
                  <FundsManagerCreatorForm
                    errorsFromApi={apiErrors}
                    updateFundsManagerCreationFormState={(values1) =>
                      this.updateFundsManagerCreationFormState(values1)}
                    setFieldValue={setFieldValue}
                    checkBoxisChecked={this.setAllowShareHolders}
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    countryCallingCodeError={countryCallingCodeError}
                    removeCountryCallingCodeError={
                      this.removeCountryCallingCodeError
                    }
                    countryCallingCodesList={this.props.countryCallingCodesList}
                  />

                  <FundsManagerCreatorDescription
                    values={values}
                    errors={errors}
                    touched={touched}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    updateFundsManagerCreationFormState={
                      this.updateFundsManagerCreationFormState
                    }
                  />

                  <AddLinkOrVideo
                    onLinkAdded={this.onVideoLinkAdded}
                    onLinkRemoved={this.onVideoLinkRemoved}
                    onVideoTokenAdded={this.onVideoTokenAdded}
                    onVideoTokenRemoved={this.onVideoTokenRemoved}
                  />

                  <UploadAttachments name="attachments" values={values} />

                  <AddLinks
                    name="links"
                    placeholder="Add Link"
                    linkType="type_default"
                    objectType="links"
                    values={values}
                    mergeLinksArray={this.mergeLinksArray}
                    deleteLinksArray={this.deleteLinksArray}
                  />
                </Col>

                <Col md={6}>
                  <div className="google-map">
                    <CreatorMap
                      googleMapURL={googleMapURL}
                      loadingElement={<div style={{ height: `100%` }} />}
                      containerElement={<div style={{ height: `350px` }} />}
                      errors={errors}
                      mapElement={(
                        <div
                          className="mapElement"
                          style={{ height: `100%` }}
                        />
                      )}
                    />
                  </div>

                  <Row className="mt-4">
                    <Col>
                      <div className="admin-fundsmanager-creator__exclude">
                        <ExcludeCountries
                          excludedCountries={this.state.excludedFilters}
                          countriesList={mapObjPropsToSelectFilter({
                            list: this.props.countriesList,
                            label: 'country_name',
                            value: 'id',
                            category: 'country',
                          })}
                          handleExcludedCountryRemoveClick={
                            this.handleExcludedFilterRemoveClick
                          }
                          setCountryToExclude={this.setCountryToExclude}
                          title="Exclude news from:"
                        />
                      </div>
                      <AddTermsAndConditions
                        onLinkAdded={this.onTermLinkAdded}
                        onLinkRemoved={this.onTermLinkRemoved}
                        onFileTokenAdded={this.onTermTokenAdded}
                        onFileTokenRemoved={this.onTermTokenRemoved}
                        termsAndConditionsError={termsAndConditionsError}
                        removeTermsAndConditionsError={
                          this.removeTermsAndConditionsError
                        }
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>

              {displaySocialMediaForm && (
                <CreatorSocialMedia
                  displaySocialMediaForm={(shouldDisplay) =>
                    this.displaySocialMediaForm(shouldDisplay)}
                  updateSocialMediaLinks={(links) =>
                    this.updateSocialMediaLinks(links)}
                  socialLinks={this.state.formData.social_media}
                />
              )}
              <ButtonGroup className="float-right">
                <Button outline color="primary  mr-4">
                  CANCEL
                </Button>

                <Button
                  color="primary"
                  type="submit"
                  onClick={() => {
                    this.updateFundsManagerCreationFormState(values);
                    this.setState({ imagesErrors: '' });
                    if (!values.country_calling_code_id) {
                      this.setState({
                        countryCallingCodeError: 'This field is required',
                      });
                    }
                    const {
                      terms_and_conditions,
                      terms_and_conditions_links,
                    } = this.state.formData;
                    if (
                      !(
                        terms_and_conditions.length ||
                        terms_and_conditions_links.length
                      )
                    ) {
                      this.setState({
                        termsAndConditionsError: 'This field is required',
                      });
                    }
                    if (!isValid) {
                      setValues({
                        name: values.name,
                        email: values.email,
                        country_calling_code_id: values.country_calling_code_id,
                        address: values.address,
                        website: values.website,
                        logo: values.logo,
                        symbols: this.state.formData.symbols,
                        description: values.description,
                        title: values.title,
                      });
                    }
                  }}
                >
                  send request
                </Button>
              </ButtonGroup>

              <div>{this.state.sendSuccessMsg}</div>
            </form>
          )}
        />
        {sendSuccessMsg && (
          <ModalContainer className="admin-fundsmanager-creator__modal">
            <h2 className="admin-fundsmanager-creator__modal__header">
              The fund-Manager has been created.
            </h2>
            <p className="admin-fundsmanager-creator__modal__message">
              It will be visible in the system after its acceptance.
            </p>

            <ButtonGroup>
              <Link
                to="/admin/fundsmanager/management"
                rel="noopener noreferrer"
              >
                <Button color="primary">Ok</Button>
              </Link>
            </ButtonGroup>
          </ModalContainer>
        )}
      </div>
    );
  }
}

FundsManagerCreatorView.defaultProps = {
  countriesList: [],
  countryCallingCodesList: [],
};

FundsManagerCreatorView.propTypes = {
  countriesList: PropTypes.arrayOf(PropTypes.object),
  countryCallingCodesList: PropTypes.arrayOf(PropTypes.object),
  fetchCountriesList: PropTypes.func.isRequired,
  fetchCountryCallingCodesList: PropTypes.func.isRequired,
  fetchUserData: PropTypes.func.isRequired,
  locationData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.arrayOf(PropTypes.string),
    ]),
  ).isRequired,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagerCreatorView);
