import axios from 'axios';

export const requestImageToken = (data, type) =>
  axios.post(
    `${
      process.env.REACT_APP_API_URL
    }/attachment?type=type_funds_manager_${type}`,
    data,
  );

export const sendFundsManagerDataRequest = data =>
  axios.post(`${process.env.REACT_APP_API_URL}/funds-managers?`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });

export const updateFundsManagerData = (id, data) =>
  axios.put(`${process.env.REACT_APP_API_URL}/funds-managers/${id}`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
