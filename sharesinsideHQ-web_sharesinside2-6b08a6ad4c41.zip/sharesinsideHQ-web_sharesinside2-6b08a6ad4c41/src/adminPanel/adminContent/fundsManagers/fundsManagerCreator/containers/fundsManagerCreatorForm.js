import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { FormGroup } from 'reactstrap';
import classnames from 'classnames';
import fetchLocationData from 'common/redux/actions/locationDataActions';
import Input from 'common/components/input';
import mapObjPropsToSelectFilter from 'common/utils/selectFilterUtils';
import SingleSelect from 'common/components/customSelect/singleSelect';

class FundsManagerCreatorForm extends Component {
  constructor(props) {
    super(props);
    this.timer = null;
  }

  handleLocationData = (e) => {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      const address = e.target.value;
      this.props.fetchLocationData(address);
    }, 1000);
  };

  render() {
    const {
      errorsFromApi,
      countryCallingCodesList,
      values,
      errors,
      touched,
      handleChange,
      handleBlur,
      setFieldTouched,
      setFieldValue,
      countryCallingCodeError,
      removeCountryCallingCodeError,
    } = this.props;

    return (
      <section className="panel-section info">
        <FormGroup>
          <Input
            type="text"
            name="name"
            placeholder="Fund-Manager name*"
            value={values.name}
            error={errors.name}
            touched={touched.name}
            onChange={handleChange}
            onBlur={(e) => {
              handleBlur(e);
              this.props.updateFundsManagerCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            name="phone"
            placeholder="Contact number"
            value={values.phone}
            error={errors.phone}
            touched={touched.phone}
            onChange={handleChange}
            onBlur={(e) => {
              handleBlur(e);
              this.props.updateFundsManagerCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            type="email"
            name="email"
            placeholder="E-mail address"
            value={values.email}
            error={errors.email}
            touched={touched.email}
            onChange={(e) => {
              handleChange(e);
              setFieldTouched('email', false);
            }}
            onBlur={(e) => {
              handleBlur(e);
              this.props.updateFundsManagerCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <div
            className={classnames({
              'admin-fundsmanager-creator__select-container': countryCallingCodeError,
            })}
          >
            <SingleSelect
              description="Country calling code*"
              onChange={(value) => {
                setFieldTouched('country_calling_code_id', true);
                setFieldValue('country_calling_code_id', value[0].value);
                if (countryCallingCodeError) {
                  removeCountryCallingCodeError();
                }
              }}
              options={mapObjPropsToSelectFilter({
                list: countryCallingCodesList
                  ? countryCallingCodesList.map(({ name, code, id }) => ({
                      value: id,
                      label: `${name} (${code})`,
                    }))
                  : [],
                label: 'label',
                value: 'value',
                category: 'country_calling_code',
              })}
              value={[
                {
                  category: 'country_calling_code',
                  label: countryCallingCodesList.filter(
                    (element) => element.id === values.country_calling_code_id,
                  )[0]
                    ? countryCallingCodesList.filter(
                        (element) =>
                          element.id === values.country_calling_code_id,
                      )[0].name
                    : '',
                  value: values.country_calling_code_id,
                },
              ]}
              category="country_calling_code"
              displayMenuOnTop={false}
              isSearchable
            />
            {countryCallingCodeError && (
              <div className="api-errors-container">
                {countryCallingCodeError}
              </div>
            )}
            {errorsFromApi.country_calling_code_id && (
              <div className="api-errors-container">
                {errorsFromApi.country_calling_code_id}
              </div>
            )}
          </div>
        </FormGroup>
        <FormGroup>
          <Input
            type="text"
            name="website"
            placeholder="Website*"
            value={values.website}
            error={errors.website}
            touched={touched.website}
            onChange={(e) => {
              handleChange(e);

              setFieldTouched('website', false);
            }}
            onBlur={(e) => {
              handleBlur(e);
              this.props.updateFundsManagerCreationFormState(values);
            }}
          />
        </FormGroup>
        <FormGroup>
          <Input
            name="address"
            placeholder="Address*"
            value={values.address}
            error={errors.address}
            touched={touched.address}
            onChange={(e) => {
              handleChange(e);
              this.handleLocationData(e);
            }}
            onBlur={(e) => {
              handleBlur(e);
              this.props.updateFundsManagerCreationFormState(values);
            }}
          />
        </FormGroup>
      </section>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchLocationData: (address) => dispatch(fetchLocationData(address)),
});

const mapStateToProps = () => ({});

FundsManagerCreatorForm.defaultProps = {
  countryCallingCodesList: [],
  errorsFromApi: {},
  errors: {},
};

FundsManagerCreatorForm.propTypes = {
  fetchLocationData: PropTypes.func.isRequired,
  countryCallingCodesList: PropTypes.arrayOf(PropTypes.object),
  errorsFromApi: PropTypes.objectOf(PropTypes.string),
  errors: PropTypes.objectOf(
    PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  ),
  handleChange: PropTypes.func.isRequired,
  handleBlur: PropTypes.func.isRequired,
  setFieldTouched: PropTypes.func.isRequired,
  updateFundsManagerCreationFormState: PropTypes.func.isRequired,
};
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FundsManagerCreatorForm);
