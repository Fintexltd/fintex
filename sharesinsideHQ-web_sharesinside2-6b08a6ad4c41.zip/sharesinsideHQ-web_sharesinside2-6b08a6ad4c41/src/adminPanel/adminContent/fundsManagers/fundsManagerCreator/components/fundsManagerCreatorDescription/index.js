import React, { Fragment } from 'react';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import TextEditor from 'common/components/textEditor';
import './style.scss';

const fundsManagerCreatorDescription = ({
  values,
  errors,
  touched,
  handleChange,
  handleBlur,
  updateFundsManagerCreationFormState,
  setFieldValue,
  setFieldTouched,
  setFieldError,
}) => (
  <Fragment>
    <FormGroup className="description__form-group">
      <Input
        className="description__input"
        name="title"
        placeholder="Title"
        value={values.title}
        error={errors.title}
        touched={touched.title}
        onChange={handleChange}
        onBlur={e => {
          handleBlur(e);
          updateFundsManagerCreationFormState(values);
        }}
      />
      <span className="description__letter-counter">
        {`${values.title ? values.title.trimStart().length : 0}/500`}
      </span>
    </FormGroup>

    <TextEditor
      className="description__text-editor"
      name="description"
      placeholder="Description*"
      values={values}
      errors={errors}
      touched={touched}
      setFieldError={setFieldError}
      setFieldValue={setFieldValue}
      setFieldTouched={setFieldTouched}
      handleStateUpdate={updateFundsManagerCreationFormState}
      characterLimit={20000}
    />
  </Fragment>
);

export default fundsManagerCreatorDescription;
