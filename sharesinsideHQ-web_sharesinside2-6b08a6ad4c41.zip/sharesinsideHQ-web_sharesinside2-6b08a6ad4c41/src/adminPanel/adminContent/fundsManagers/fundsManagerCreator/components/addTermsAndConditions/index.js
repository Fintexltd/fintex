import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import FileUpload from 'common/components/fileUpload';
import { requestAttachmentToken } from 'common/api/filesApi';
import plus from 'assets/icons/add_icon_big_blue.svg';
import shortid from 'shortid';
import AddTermsAndConditionsLink from './addTermsAndConditionsLink';
import AddTermsAndConditionsFile from './addTermsAndConditionsFile';
import './style.scss';

class AddTermsAndConditions extends React.Component {
  constructor(props) {
    super(props);
    this.onLinkAdded = this.props.onLinkAdded;
    this.onLinkRemoved = this.props.onLinkRemoved;
    this.onFileTokenAdded = this.props.onFileTokenAdded;
    this.onFileTokenRemoved = this.props.onFileTokenRemoved;
    const { initialFiles, initLinks } = props;
    this.state = {
      isLoading: false,
      serverError: false,
      files: initialFiles,
      links: initLinks,
      visibleAddLinkInput: false,
      fileIputKey: shortid.generate(),
    };
  }

  handleFileChange = e => {
    if (e.target.files[0]) {
      e.preventDefault();

      this.setState({ isLoading: true, serverError: false });
      const reader = new FileReader();
      const file = e.target.files[0];

      reader.onloadend = () => {
        const fileAsForm = new FormData();
        fileAsForm.append('file', file);

        requestAttachmentToken(fileAsForm, 'type_terms_and_conditions')
          .then(res => {
            const newToken = res.data.token;
            const { files, links } = this.state;
            const previousLink = links.length === 0 ? null : links[0];
            const previousFile = files.length === 0 ? null : files[0];
            this.onFileTokenAdded(newToken, previousLink, previousFile);
            this.setState({
              files: [
                {
                  file: reader.result,
                  name: file.name,
                  token: newToken,
                },
              ],
              links: [],
              serverError: false,
              isLoading: false,
            });
            this.props.removeTermsAndConditionsError();
          })
          .catch(error => {
            this.setState({ serverError: error, isLoading: false });
          });
      };
      reader.readAsDataURL(file);
    }
  };

  handleDeleteFile = file => {
    this.setState({ files: [] });
    this.onFileTokenRemoved(file);
  };

  handleLinkChange = values => {
    const addedLink = {
      name: values.name,
      url: values.url,
      type: 'type_default',
    };
    const { files, links } = this.state;
    const previousLink = links.length === 0 ? null : links[0];
    const previousFile = files.length === 0 ? null : files[0];
    this.onLinkAdded(addedLink, previousLink, previousFile);
    this.setState({
      visibleAddLinkInput: !this.state.visibleAddLinkInput,
      links: [addedLink],
      files: [],
    });
    this.props.removeTermsAndConditionsError();
  };

  handleDeleteLink = link => {
    this.setState({ links: [] });
    this.onLinkRemoved(link);
  };

  handleLinkDialogClose = () => {
    this.setState({
      visibleAddLinkInput: !this.state.visibleAddLinkInput,
    });
  };

  render() {
    const {
      isLoading,
      serverError,
      files,
      links,
      visibleAddLinkInput,
      fileIputKey,
    } = this.state;
    const {
      handleFileChange,
      handleDeleteFile,
      handleLinkChange,
      handleDeleteLink,
      handleLinkDialogClose,
    } = this;
    const { termsAndConditionsError } = this.props;
    return (
      <Fragment>
        <div className="add-terms-and-conditions">
          <p className="add-terms-and-conditions__title">
            Terms and conditions*
          </p>
          <div
            className="add-link display-inline"
            role="presentation"
            onClick={handleLinkDialogClose}
          >
            <img src={plus} alt="" height={30} width={30} />
            <span>Add Link</span>
          </div>
          <div className="display-inline or">or</div>
          <div className="display-inline">
            <FileUpload
              id="term-upload"
              key={fileIputKey}
              accept=".pdf, .doc"
              onChange={e => {
                handleFileChange(e);
                this.setState({ fileIputKey: shortid.generate() });
              }}
            >
              Upload attachement
            </FileUpload>
          </div>
          <div className="clearfix" />
        </div>
        <div className="added-contener">
          <AddTermsAndConditionsLink
            links={links}
            handleLinkChange={handleLinkChange}
            handleDeleteLink={handleDeleteLink}
            visibleAddInput={visibleAddLinkInput}
            handleClose={handleLinkDialogClose}
          />
          <AddTermsAndConditionsFile
            isLoading={isLoading}
            serverError={serverError}
            files={files}
            handleFileChange={handleFileChange}
            handleDeleteFile={handleDeleteFile}
          />
          {termsAndConditionsError && (
            <div className="api-errors-container">
              {termsAndConditionsError}
            </div>
          )}
        </div>
      </Fragment>
    );
  }
}

AddTermsAndConditions.defaultProps = {
  initialFiles: [],
  initLinks: [],
};

AddTermsAndConditions.propTypes = {
  onLinkAdded: PropTypes.func.isRequired,
  onLinkRemoved: PropTypes.func.isRequired,
  onFileTokenAdded: PropTypes.func.isRequired,
  onFileTokenRemoved: PropTypes.func.isRequired,
  initialFiles: PropTypes.arrayOf(PropTypes.object),
  initLinks: PropTypes.arrayOf(PropTypes.object),
  termsAndConditionsError: PropTypes.string.isRequired,
  removeTermsAndConditionsError: PropTypes.func.isRequired,
};

export default AddTermsAndConditions;
