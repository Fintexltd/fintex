import React from 'react';
import PropTypes from 'prop-types';
import MultiSelect from 'common/components/customSelect/multiSelect';
import ActiveFiltersList from 'common/components/activeFiltersList';
import './index.scss';

const SelectFundTypes = ({
  fundTypesList,
  selectedFundTypes,
  handleSelectedFundTypeRemoveClick,
  setFundTypeToSelect,
  setFieldValue,
}) => (
  <div className="fund-types">
    <div className="fund-types__multiselect">
      <MultiSelect
        options={fundTypesList}
        description="Asset classes*"
        onChange={values => setFundTypeToSelect(values, setFieldValue)}
        category="fund_types"
        value={selectedFundTypes}
        isSearchable
      />
    </div>
    {selectedFundTypes.length > 0 && (
      <ActiveFiltersList
        activeFiltersList={selectedFundTypes}
        handleFilterRemoveClick={label =>
          handleSelectedFundTypeRemoveClick(label, setFieldValue)
        }
        title={null}
      />
    )}
  </div>
);

SelectFundTypes.defaultProps = {
  fundTypesList: [],
  selectedFundTypes: [],
};

SelectFundTypes.propTypes = {
  fundTypesList: PropTypes.arrayOf(PropTypes.object),
  selectedFundTypes: PropTypes.arrayOf(PropTypes.object),
  handleSelectedFundTypeRemoveClick: PropTypes.func.isRequired,
  setFundTypeToSelect: PropTypes.func.isRequired,
};

export default SelectFundTypes;
