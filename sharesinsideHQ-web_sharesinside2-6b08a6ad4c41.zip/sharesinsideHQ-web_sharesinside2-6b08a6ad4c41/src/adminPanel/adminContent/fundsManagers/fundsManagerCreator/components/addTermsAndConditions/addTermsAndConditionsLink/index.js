import React, { Fragment } from 'react';
import { linkSchema as validationSchema } from 'common/validators/linkSchema';
import FormModal from 'common/components/modals/form';
import LinkFormModal from 'common/components/addLinks/linkFormModal';
import LinksList from 'common/components/addLinks/linksList';
import PropTypes from 'prop-types';
import 'common/components/addLinks/style.scss';

const AddTermsAndConditionsLink = ({
  visibleAddInput,
  links,
  handleLinkChange,
  handleDeleteLink,
  handleClose,
}) => (
  <Fragment>
    {visibleAddInput && (
      <FormModal
        isModalVisible
        handleClose={handleClose}
        header="Add Terms and conditions Link"
        validationSchema={validationSchema}
        onSubmit={handleLinkChange}
        initialValues={{
          name: '',
          url: '',
        }}
        className="addNewLink"
        confimButtonText="Save"
      >
        <LinkFormModal />
      </FormModal>
    )}
    <LinksList links={links} handleDeleteLink={handleDeleteLink} />
  </Fragment>
);

AddTermsAndConditionsLink.propTypes = {
  visibleAddInput: PropTypes.bool.isRequired,
  links: PropTypes.arrayOf(PropTypes.object).isRequired,
  handleLinkChange: PropTypes.func.isRequired,
  handleDeleteLink: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
};

export default AddTermsAndConditionsLink;
