import React, { Fragment } from 'react';
import CircleSpinner from 'common/components/circleSpinner';
import FilesList from 'common/components/uploadAttachments/FilesList';
import PropTypes from 'prop-types';
import 'common/components/uploadAttachments/style.scss';

class AddTermsAndConditionsFile extends React.Component {
  constructor(props) {
    super(props);
    this.handleFileChange = this.props.handleFileChange;
    this.handleDeleteFile = this.props.handleDeleteFile;
  }

  render() {
    const { files, serverError, isLoading } = this.props;
    return (
      <Fragment>
        <FilesList files={files} handleDeleteFile={this.handleDeleteFile} />
        {isLoading && <CircleSpinner />}
        {serverError.response && (
          <div className="error">
            <span>
              {serverError.response.data
                ? serverError.response.data.errors.file
                : ''}
            </span>
          </div>
        )}
      </Fragment>
    );
  }
}

AddTermsAndConditionsFile.defaultProps = {
  serverError: {},
};

AddTermsAndConditionsFile.propTypes = {
  isLoading: PropTypes.bool.isRequired,
  serverError: PropTypes.bool,
  handleFileChange: PropTypes.func.isRequired,
  handleDeleteFile: PropTypes.func.isRequired,
  files: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default AddTermsAndConditionsFile;
