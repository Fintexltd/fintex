import axios from 'axios';

export const deletEventDataRequest = eventId =>
  axios.delete(`${process.env.REACT_APP_API_URL}/events/${eventId}`);
