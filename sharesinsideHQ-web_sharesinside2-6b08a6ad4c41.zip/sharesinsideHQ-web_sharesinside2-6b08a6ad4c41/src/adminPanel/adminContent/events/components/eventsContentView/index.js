import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, ButtonGroup, Button } from 'reactstrap';
import EventItem from 'common/components/eventItem';
import AddButton from 'common/components/addButton';
import ModalContainer from 'common/components/modalContainer';
import { checkIfUserCanManageNewsOrEvents } from 'userAuth/utils/permissions';
import './index.scss';

const EventsContentView = ({
  eventsList,
  companyId,
  handleLoadMoreClick,
  nextPageIndex,
  toggleEventDeleteModal,
  removeEventModalDisplayed,
  eventDelete,
  userData,
}) => (
  <div className="company-event-content">
    <Row>
      {checkIfUserCanManageNewsOrEvents(userData, companyId) && (
        <AddButton
          route={`/admin/company/manage/${companyId}/add-event`}
          content="add event"
        />
      )}
      {eventsList.length > 0 &&
        eventsList.map((item) => (
          <Col xs="12" md="6" key={item.id}>
            <EventItem
              handleDelete={toggleEventDeleteModal}
              event={item}
              inAdminView
            />
          </Col>
        ))}
      {eventsList.length === 0 && (
        <Col xs="12" className="company-events-content__empty-list">
          <p className="company-events-content__empty-list-message">
            There are no events for this company
          </p>
        </Col>
      )}
    </Row>
    {nextPageIndex && (
      <div className="company-events-content__load-container">
        <button
          onClick={handleLoadMoreClick}
          className="company-events-content__load"
        >
          Load more
        </button>
      </div>
    )}
    {removeEventModalDisplayed && (
      <ModalContainer
        className="manage-team__remove-group-modal"
        handleOutsideClick={toggleEventDeleteModal}
      >
        Warning! All event data will be removed!
        <ButtonGroup>
          <Button
            outline
            color="primary"
            className="mr-5"
            type="button"
            onClick={toggleEventDeleteModal}
          >
            Cancel
          </Button>

          <Button onClick={eventDelete} color="danger">
            Delete
          </Button>
        </ButtonGroup>
      </ModalContainer>
    )}
  </div>
);

EventsContentView.defaultProps = {
  eventsList: [],
  nextPageIndex: null,
};

EventsContentView.propTypes = {
  eventsList: PropTypes.arrayOf(PropTypes.object),
  handleLoadMoreClick: PropTypes.func.isRequired,
  nextPageIndex: PropTypes.number,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default EventsContentView;
