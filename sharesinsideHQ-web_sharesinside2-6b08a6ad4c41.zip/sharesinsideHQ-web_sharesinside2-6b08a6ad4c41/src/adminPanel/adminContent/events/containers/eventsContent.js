import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import CompanyEventsContentView from 'adminPanel/adminContent/events/components/eventsContentView';
import {
  fetchAdminCompanyEvents,
  removeAdminCompanyEvents,
} from 'adminPanel/redux/actions/adminCompanyEventsActions';
import { deletEventDataRequest } from 'adminPanel/adminContent/events/api/eventsApi.js';

const mapStateToProps = (state) => ({
  eventsList: state.adminCompanyEvents.list,
  hasNextPage: state.adminCompanyEvents.hasNextPage,
  nextPageIndex: state.adminCompanyEvents.nextPageIndex,
  userData: state.userData.data,
});

const mapDispatchToProps = (dispatch) => ({
  getAdminCompanyEvents: bindActionCreators(fetchAdminCompanyEvents, dispatch),
  removeAdminCompanyEvents: bindActionCreators(
    removeAdminCompanyEvents,
    dispatch,
  ),
});

class EventsContent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoadMoreClicked: false,
      removeEventModalDisplayed: false,
    };
  }

  componentDidMount() {
    if (this.props.companyId) {
      this.props.removeAdminCompanyEvents();
      this.props.getAdminCompanyEvents(0, this.props.companyId);
    }
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props !== nextProps) {
      this.setState({ isLoadMoreClicked: false });
    }
  }

  handleLoadMoreClick = () => {
    if (!this.state.isLoadMoreClicked) {
      this.setState({ isLoadMoreClicked: true }, () => {
        this.props.getAdminCompanyEvents(
          this.props.nextPageIndex,
          this.props.companyId,
        );
      });
    }
  };

  eventDelete = () => {
    deletEventDataRequest(this.state.eventToDelete).then(() => {
      this.props.getAdminCompanyEvents(0, this.props.companyId);
      this.toggleEventDeleteModal();
    });
  };

  toggleEventDeleteModal = (eventId) => {
    this.setState((prevState) => ({
      removeEventModalDisplayed: !prevState.removeEventModalDisplayed,
      eventToDelete: eventId,
    }));
  };

  render() {
    return (
      <CompanyEventsContentView
        eventsList={this.props.eventsList}
        handleLoadMoreClick={this.handleLoadMoreClick}
        nextPageIndex={this.props.nextPageIndex}
        companyId={this.props.companyId}
        toggleEventDeleteModal={this.toggleEventDeleteModal}
        removeEventModalDisplayed={this.state.removeEventModalDisplayed}
        eventDelete={this.eventDelete}
        userData={this.props.userData}
      />
    );
  }
}

EventsContent.defaultProps = {
  companyId: null,
  nextPageIndex: null,
  eventsList: [],
};

EventsContent.propTypes = {
  companyId: PropTypes.number,
  nextPageIndex: PropTypes.number,
  eventsList: PropTypes.arrayOf(PropTypes.object),
  getAdminCompanyEvents: PropTypes.func.isRequired,
  removeAdminCompanyEvents: PropTypes.func.isRequired,
  userData: PropTypes.objectOf(
    PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.string,
      PropTypes.bool,
      PropTypes.object,
      PropTypes.array,
    ]),
  ).isRequired,
};

export default connect(mapStateToProps, mapDispatchToProps)(EventsContent);
