import React from 'react';
import { Container } from 'reactstrap';
import 'company/components/companyView/index.scss';
import 'company/components/otherCompaniesBarView/index.scss';
import LseCompanyPreviewDetails from '../lseCompanyPreviewDetails';

const LseCompanyPreview = () => (
  <div className="company-wrapper">
    <Container className="company-container">
      <div className="company-container__company">
        <LseCompanyPreviewDetails />
      </div>
    </Container>
    <div className="other-companies-bar" />
  </div>
);

export default LseCompanyPreview;
