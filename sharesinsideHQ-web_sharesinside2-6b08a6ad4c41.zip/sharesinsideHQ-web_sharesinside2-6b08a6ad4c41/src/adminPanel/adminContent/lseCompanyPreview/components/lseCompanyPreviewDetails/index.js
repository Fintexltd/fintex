import React, { Suspense } from 'react';
import { Route, Switch } from 'react-router-dom';
import ComponentLoadingIndicator from 'common/components/componentLoadingIndicator';
import CompanyHeaderMobile from 'company/components/companyHeaderMobile';
import CompanyHeaderDesktop from 'company/components/companyHeaderDesktop';
import CompanyDetailsBox from 'common/components/companyDetailsBox';
import CompanyNavigation from 'common/components/companyNavigation';
import Page404Loader from 'common/components/Page404Loader';
import { CompanyAbout } from 'company/components/companyDetailsView/detailsComponents';
import 'company/components/companyDetailsView/index.scss';
import useCompanyPreviewDetails from './useLseCompanyPreviewDetails';

const LseCompanyPreviewDetails = () => {
  const { company, userData } = useCompanyPreviewDetails();

  return (
    <div className="company-details">
      <div className="company-details__header--mobile">
        <CompanyHeaderMobile company={company} userData={userData} />
      </div>
      <div className="company-details__header--desktop">
        <CompanyHeaderDesktop company={company} userData={userData} />
        <CompanyDetailsBox company={company} />
      </div>
      <CompanyNavigation
        company={company}
        path={`/company/lse/${company.id}`}
        shouldScrollToNews
      />
      <Suspense fallback={<ComponentLoadingIndicator />}>
        <Switch>
          <Route path="/company/lse/:id/about" exact component={CompanyAbout} />
          <Route path="/company/lse/:id/*" component={Page404Loader} />
        </Switch>
      </Suspense>
    </div>
  );
};

export default LseCompanyPreviewDetails;
