import { useSelector } from 'react-redux';

const useCompanyPreviewDetails = () => {
  const company = useSelector((state) => state.company.currentCompany);
  const userData = useSelector((state) => state.userData.data);

  return {
    company,
    userData,
  };
};

export default useCompanyPreviewDetails;
