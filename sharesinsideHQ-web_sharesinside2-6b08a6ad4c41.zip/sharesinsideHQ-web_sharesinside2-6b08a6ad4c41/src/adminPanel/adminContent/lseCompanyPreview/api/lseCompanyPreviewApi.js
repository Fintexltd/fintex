import axios from 'axios';

export const getLseCompanyPreviewRequest = (lseId) =>
  axios.get(
    `${process.env.REACT_APP_API_URL}/admin/lse-company-preview/${lseId}`,
  );
