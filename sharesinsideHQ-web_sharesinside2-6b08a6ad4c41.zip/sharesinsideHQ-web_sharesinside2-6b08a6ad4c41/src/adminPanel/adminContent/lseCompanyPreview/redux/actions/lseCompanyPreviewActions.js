import {
  fetchCompanyRequest,
  fetchCompanySuccess,
  fetchCompanyFailure,
  removeCompany,
} from 'common/redux/actions/companyActions';
import { getLseCompanyPreviewRequest } from '../../api/lseCompanyPreviewApi';

export const fetchLseCompanyPreview = (lseId) => (dispatch) => {
  dispatch(fetchCompanyRequest);
  return getLseCompanyPreviewRequest(lseId)
    .then((response) => {
      dispatch(fetchCompanySuccess(response.data));
    })
    .catch(() => {
      dispatch(fetchCompanyFailure());
    });
};

export const removeLseCompanyPreview = () => removeCompany();
