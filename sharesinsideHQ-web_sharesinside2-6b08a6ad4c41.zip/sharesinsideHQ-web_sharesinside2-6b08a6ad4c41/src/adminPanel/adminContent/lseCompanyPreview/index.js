import React from 'react';
import PermissionRequired from 'permissions/components/permissionRequired';
import { PERMISSIONS_FUNCTION_TYPES } from 'userAuth/utils/permissionTypes';
import DataLoader from './dataLoader';
import LseCompanyPreview from './components/lseCompanyPreview';

const Index = () => (
  <PermissionRequired
    permission={PERMISSIONS_FUNCTION_TYPES.MANAGE_LSE_DATA_REQUESTS}
    redirectFallback="/admin/company/management"
  >
    <DataLoader />
    <LseCompanyPreview />
  </PermissionRequired>
);

export default Index;
