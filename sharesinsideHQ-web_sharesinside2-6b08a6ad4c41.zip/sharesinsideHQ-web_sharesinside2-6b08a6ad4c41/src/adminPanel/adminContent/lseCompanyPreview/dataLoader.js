import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { useParams } from 'react-router';
import {
  fetchLseCompanyPreview,
  removeLseCompanyPreview,
} from './redux/actions/lseCompanyPreviewActions';

const DataLoader = () => {
  const dispatch = useDispatch();
  const { id } = useParams();

  useEffect(() => {
    dispatch(fetchLseCompanyPreview(id));
    return () => {
      dispatch(removeLseCompanyPreview());
    };
  }, [dispatch, id]);

  return null;
};

export default DataLoader;
