import * as Yup from 'yup';

const privacySchema = Yup.object().shape({
  title: Yup.string().required('This field is required.'),
  description: Yup.string().required('This field is required.'),
});

export default privacySchema;
