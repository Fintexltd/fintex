import axios from 'axios';

export const getPrivacyToEdit = () =>
  axios(`${process.env.REACT_APP_API_URL}/static/privacy_policy/edit`);

export const editPrivacy = privacyData =>
  axios({
    method: 'put',
    url: `${process.env.REACT_APP_API_URL}/static/privacy_policy`,
    data: {
      privacy_policy: privacyData,
    },
  });
