import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import shortid from 'shortid';
import SaveButton from 'common/components/saveButton';
import CircleSpinner from 'common/components/circleSpinner';
import './index.scss';

const AdminPrivacyView = ({
  addNewPrivacySection,
  editPrivacySection,
  removePrivacySection,
  savePrivacy,
  privacyData,
  isLoading,
  isSaveInProgress,
  isSaved,
}) => (
  <div className="admin-privacy">
    {!isLoading ? (
      <Fragment>
        <h1 className="admin-privacy__heading">Manage privacy policy</h1>
        {privacyData.map((item, index) => (
          <div key={shortid.generate()} className="admin-privacy__section">
            <h2>{item.title}</h2>
            <p dangerouslySetInnerHTML={{ __html: item.description }} />
            <button
              onClick={() => editPrivacySection(item, index)}
              className="admin-privacy__button admin-privacy__button--edit"
            >
              Edit
            </button>
            <button
              onClick={() => removePrivacySection(item, index)}
              className="admin-privacy__button admin-privacy__button--remove"
            >
              Remove
            </button>
          </div>
        ))}
        <button
          onClick={addNewPrivacySection}
          className="admin-privacy__button admin-privacy__button--add"
        >
          Add new section
        </button>
        <div className="admin-privacy__save-container">
          <SaveButton
            onClick={savePrivacy}
            disabled={isSaveInProgress}
            isSaved={isSaved}
          />
        </div>
      </Fragment>
    ) : (
      <div className="admin-privacy__load-container">
        <CircleSpinner />
      </div>
    )}
  </div>
);

AdminPrivacyView.defaultProps = {
  privacyData: [],
};

AdminPrivacyView.propTypes = {
  addNewPrivacySection: PropTypes.func.isRequired,
  editPrivacySection: PropTypes.func.isRequired,
  removePrivacySection: PropTypes.func.isRequired,
  savePrivacy: PropTypes.func.isRequired,
  privacyData: PropTypes.arrayOf(PropTypes.object),
  isLoading: PropTypes.bool.isRequired,
  isSaveInProgress: PropTypes.bool.isRequired,
  isSaved: PropTypes.bool.isRequired,
};

export default AdminPrivacyView;
