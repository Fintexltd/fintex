import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { disableScroll } from 'common/utils/disableScroll';
import FormModal from 'common/components/modals/form';
import { FormGroup } from 'reactstrap';
import Input from 'common/components/input';
import TextEditor from 'common/components/textEditor';
import AdminPrivacyView from 'adminPanel/adminContent/privacy/components/adminPrivacyView';
import {
  getPrivacyToEdit,
  editPrivacy,
} from 'adminPanel/adminContent/privacy/api/privacyApi.js';
import validationSchema from 'adminPanel/adminContent/privacy/validators/privacyValidators.js';

const mapStateToProps = (state) => ({
  token: state.auth.token,
  userData: state.userData.data,
});

class AdminPrivacy extends Component {
  constructor(props) {
    super(props);
    this.state = {
      privacyData: [],
      isPrivacySectionModalVisible: false,
      editValues: {
        title: '',
        description: '',
      },
      isLoading: false,
      isSaveInProgress: false,
      isSaved: false,
    };
  }

  componentDidMount() {
    if (!this.props.token && !this.props.userData)
      this.props.history.push('/auth');

    if (
      this.props.userData &&
      !this.props.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    )
      this.props.history.push('/admin/company/management');

    this.getPrivacy();
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.userData) this.props.history.push('/auth');

    if (
      nextProps.userData &&
      !nextProps.userData.is_global_admin &&
      !this.props.userData.is_content_admin
    )
      this.props.history.push('/admin/company/management');
  }

  getPrivacy = () => {
    this.setState({ isLoading: true });
    getPrivacyToEdit().then((response) => {
      this.setState({
        privacyData: response.data,
        isLoading: false,
      });
    });
  };

  togglePrivacySectionModal = () => {
    this.setState(
      (prevState) => ({
        isPrivacySectionModalVisible: !prevState.isPrivacySectionModalVisible,
      }),
      () => disableScroll(this.state.isPrivacySectionModalVisible),
    );
  };

  editPrivacySection = (item, index) => {
    this.setState({
      editValues: item,
      editIndex: index,
    });
    this.togglePrivacySectionModal();
  };

  removePrivacySection = (item, index) => {
    this.setState((prevState) => {
      const privacyData = [...prevState.privacyData];
      privacyData.splice(index, 1);
      return { privacyData };
    });
  };

  submitPrivacySection = (values) => {
    if (typeof this.state.editIndex === 'number') {
      this.setState((prevState) => {
        const privacyData = [...prevState.privacyData];
        privacyData[prevState.editIndex] = values;
        return { privacyData };
      });
    } else {
      this.setState((prevState) => {
        const privacyData = [...prevState.privacyData];
        privacyData.push(values);
        return { privacyData };
      });
    }
    this.togglePrivacySectionModal();
  };

  addNewPrivacySection = () => {
    this.setState({
      editValues: {
        title: '',
        description: '',
      },
      editIndex: null,
    });
    this.togglePrivacySectionModal();
  };

  savePrivacy = () => {
    this.setState({ isSaveInProgress: true });
    editPrivacy(this.state.privacyData)
      .then(() => {
        this.setState({
          isSaved: true,
        });
        setTimeout(() => {
          this.setState({
            isSaved: false,
            isSaveInProgress: false,
          });
        }, 1000);
      })
      .catch(() => {
        this.setState({ isSaveInProgress: false });
      });
  };

  render() {
    const PrivacySectionModalFormView = ({ formProps }) => (
      <>
        <FormGroup>
          <Input
            type="text"
            value={formProps.values.title}
            error={formProps.errors.title}
            touched={formProps.touched.title}
            name="title"
            onChange={formProps.handleChange}
            onBlur={formProps.handleBlur}
            placeholder="Title"
          />
        </FormGroup>
        <FormGroup>
          <TextEditor
            name="description"
            placeholder="Text"
            values={formProps.values}
            defaultValue={formProps.values.description}
            errors={formProps.errors}
            touched={formProps.touched}
            setFieldValue={(element, value) => {
              formProps.setValues({
                title: formProps.values.title,
                description: value,
              });
            }}
            setFieldTouched={() => null}
            isCharacterLimitHidden
          />
        </FormGroup>
      </>
    );

    return (
      <>
        <AdminPrivacyView
          addNewPrivacySection={this.addNewPrivacySection}
          editPrivacySection={this.editPrivacySection}
          removePrivacySection={this.removePrivacySection}
          savePrivacy={this.savePrivacy}
          privacyData={this.state.privacyData}
          isLoading={this.state.isLoading}
          isSaveInProgress={this.state.isSaveInProgress}
          isSaved={this.state.isSaved}
        />
        <FormModal
          isModalVisible={this.state.isPrivacySectionModalVisible}
          handleClose={this.togglePrivacySectionModal}
          header="Privacy section"
          onSubmit={this.submitPrivacySection}
          initialValues={this.state.editValues}
          confimButtonText="Confirm"
          validationSchema={validationSchema}
        >
          <PrivacySectionModalFormView />
        </FormModal>
      </>
    );
  }
}

export default connect(mapStateToProps, null)(withRouter(AdminPrivacy));
