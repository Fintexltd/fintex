import React from 'react';
import 'adminPanel/adminContent/common/styles/advancedSearch.scss';
import SectorFilter from 'adminPanel/adminContent/common/components/filters/SectorFilter';
import IndustryFilter from 'adminPanel/adminContent/common/components/filters/IndustryFilter';
import ContinentFilter from 'adminPanel/adminContent/common/components/filters/ContinentFilter';
import CountryFilter from 'adminPanel/adminContent/common/components/filters/CountryFilter';
import DataLoader from './dataLoader';

const PushCompaniesAdvancedSearch = ({
  pushCompaniesFilters,
  handleFilterUsage,
}) => {
  return (
    <div className="admin-advanced-search">
      <DataLoader />
      <div className="admin-advanced-search__filters">
        <SectorFilter
          handleFilterUsage={handleFilterUsage}
          value={pushCompaniesFilters.sector}
        />
        <IndustryFilter
          handleFilterUsage={handleFilterUsage}
          value={pushCompaniesFilters.industry}
        />
        <ContinentFilter
          handleFilterUsage={handleFilterUsage}
          value={pushCompaniesFilters.continent}
        />
        <CountryFilter
          handleFilterUsage={handleFilterUsage}
          value={pushCompaniesFilters.country}
        />
      </div>
    </div>
  );
};

export default PushCompaniesAdvancedSearch;
