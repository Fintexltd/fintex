import { useCallback, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchPushCompanies,
  sendCompaniesPushNotifications,
} from 'adminPanel/adminContent/push/redux/actions/pushCompaniesActions';
import { savePushCompaniesFilters as savePushCompaniesFiltersAction } from 'adminPanel/adminContent/push/redux/actions/pushCompaniesFiltersActions';

const usePushEquities = () => {
  const dispatch = useDispatch();
  const pushCompanies = useSelector((state) => state.pushCompanies.list);
  const [selectedCompanies, setSelectedCompanies] = useState([]);

  const meta = useSelector((state) => state.pushCompanies.meta);
  const resultsNumber = useSelector(
    (state) => state.pushCompanies.resultsNumber,
  );

  useEffect(() => {
    setSelectedCompanies([]);
  }, [pushCompanies]);

  const getPushCompanies = useCallback(
    (page = 1) => {
      dispatch(fetchPushCompanies(page));
    },
    [dispatch],
  );

  const savePushCompaniesFilters = (filters) => {
    dispatch(savePushCompaniesFiltersAction(filters));
  };

  const handleCheckboxClick = (e) => {
    const checkedItems = [...selectedCompanies];
    const { checked, value } = e.target;
    const id = Number(value);
    if (checked) {
      checkedItems.push(id);
    } else {
      const index = checkedItems.indexOf(id);
      checkedItems.splice(index, 1);
    }
    setSelectedCompanies(checkedItems);
  };

  const sendPushNotifications = () => {
    if (selectedCompanies.length) {
      dispatch(sendCompaniesPushNotifications(selectedCompanies));
    }
  };

  const isSelected = (id) => selectedCompanies.includes(id);

  return {
    getPushCompanies,
    pushCompanies,
    meta,
    resultsNumber,
    savePushCompaniesFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  };
};

export default usePushEquities;
