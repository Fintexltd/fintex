import { useMemo } from 'react';
import { useSelector } from 'react-redux';

const usePushCompaniesFilters = () => {
  const pushCompaniesFilters = useSelector(
    (state) => state.pushCompaniesFilters,
  );

  const activeFiltersList = useMemo(
    () => [
      ...pushCompaniesFilters.sector,
      ...pushCompaniesFilters.industry,
      ...pushCompaniesFilters.continent,
      ...pushCompaniesFilters.country,
      ...pushCompaniesFilters.relations,
    ],
    [
      pushCompaniesFilters.sector,
      pushCompaniesFilters.industry,
      pushCompaniesFilters.continent,
      pushCompaniesFilters.country,
      pushCompaniesFilters.relations,
    ],
  );

  const isRemoveFiltersButtonVisible = activeFiltersList.length > 0;

  return {
    pushCompaniesFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  };
};

export default usePushCompaniesFilters;
