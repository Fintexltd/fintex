import { useSelector } from 'react-redux';
import usePushCompaniesFilters from '../pushCompaniesSearch/usePushCompaniesFilters';

const useNoDataInfo = () => {
  const resultsNumber = useSelector(
    (state) => state.pushCompanies.resultsNumber,
  );

  const {
    isRemoveFiltersButtonVisible,
    pushCompaniesFilters,
  } = usePushCompaniesFilters();

  const isAnyFilterSelected =
    isRemoveFiltersButtonVisible || pushCompaniesFilters.search;

  return {
    resultsNumber,
    isAnyFilterSelected,
  };
};

export default useNoDataInfo;
