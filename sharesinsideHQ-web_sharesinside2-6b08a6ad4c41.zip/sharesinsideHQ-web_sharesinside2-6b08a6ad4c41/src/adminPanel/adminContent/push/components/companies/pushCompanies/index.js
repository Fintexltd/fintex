import React from 'react';
import usePushEquities from './usePushCompanies';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import PushCompaniesPagination from './PushCompaniesPagination';
import DataLoader from './dataLoader';
import PushCompaniesSearch from '../pushCompaniesSearch';
import PushItem from '../../pushItem';
import SendButton from '../../sendButton';

const PushEquities = () => {
  const {
    pushCompanies,
    getPushCompanies,
    resultsNumber,
    meta,
    savePushCompaniesFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  } = usePushEquities();

  return (
    <>
      <DataLoader />
      <PushCompaniesSearch />
      <div className="push__button-container">
        <SendButton
          handleClick={sendPushNotifications}
          description="SEND PUSH NOTIFICATION"
        />
      </div>
      <div className="push__table-container">
        <table className="push__table">
          <thead className="push__thead">
            <tr>
              <th>Company</th>
              <th>Status</th>
              <th>Send notification?</th>
            </tr>
          </thead>
          <tbody>
            {pushCompanies.map((company) => (
              <PushItem
                key={company.id}
                item={company}
                handleCheckboxClick={handleCheckboxClick}
                isSelected={isSelected(company.id)}
              />
            ))}
          </tbody>
        </table>
        <LoadingIndicator />
      </div>
      <NoDataInfo />
      <PushCompaniesPagination
        meta={meta}
        resultsNumber={resultsNumber}
        saveFilters={savePushCompaniesFilters}
        getResults={getPushCompanies}
      />
    </>
  );
};

export default PushEquities;
