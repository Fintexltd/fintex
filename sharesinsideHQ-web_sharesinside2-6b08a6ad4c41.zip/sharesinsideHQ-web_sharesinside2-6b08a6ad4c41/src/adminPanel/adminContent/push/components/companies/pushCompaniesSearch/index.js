import React from 'react';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import ToggleMoreFiltersIconButton from 'common/components/toggleMoreFiltersIconButton';
import SearchInput from 'common/components/searchInput';
import MultiSelect from 'common/components/customSelect/multiSelect';
import PushCompaniesAdvancedSearch from 'adminPanel/adminContent/push/components/companies/pushCompaniesAdvancedSearch';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import { getRelationsList } from 'common/utils/relationsListUtils';
import 'adminPanel/adminContent/common/styles/search.scss';
import {
  usePushCompaniesSearch,
  usePushCompaniesSearchTextInput,
} from './usePushCompaniesSearch';

const relationsList = getRelationsList();

const PushCompaniesSearch = () => {
  const {
    activeFiltersList,
    clearActiveFilters,
    isAdvancedSearchVisible,
    isRemoveFiltersButtonVisible,
    resultsNumber,
    toggleAdvancedSearch,
    pushCompaniesFilters,
    handleFilterRemoveClick,
    handleFilterUsage,
  } = usePushCompaniesSearch();

  return (
    <div className="admin-search">
      <div className="admin-search__top">
        <div className="admin-search__top-left">
          <PushCompaniesSearchTextInput />
          <div className="admin-search__relation-filter-container">
            <MultiSelect
              options={relationsList}
              description="Relation"
              onChange={handleFilterUsage}
              value={pushCompaniesFilters.relations}
              category="relations"
            />
          </div>
          <div className="admin-search__filters-button--text">
            <ToggleMoreFiltersButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
          <div className="admin-search__filters-button--icon">
            <ToggleMoreFiltersIconButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
        </div>
        {isRemoveFiltersButtonVisible && (
          <div className="admin-search__clear-filters-button">
            <div className="admin-search__clear-filters-text-button">
              <ClearFiltersButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
            <div className="admin-search__clear-filters-icon-button">
              <ClearFiltersIconButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
          </div>
        )}
      </div>
      {isAdvancedSearchVisible && (
        <PushCompaniesAdvancedSearch
          pushCompaniesFilters={pushCompaniesFilters}
          handleFilterUsage={handleFilterUsage}
        />
      )}
      <div className="admin-search__results-container">
        <div className="admin-search__results">
          <SearchResultsCounter resultsNumber={resultsNumber} />
        </div>
        {activeFiltersList.length > 0 && (
          <ActiveFiltersList
            activeFiltersList={activeFiltersList}
            handleFilterRemoveClick={handleFilterRemoveClick}
          />
        )}
      </div>
    </div>
  );
};

const PushCompaniesSearchTextInput = () => {
  const { handleSearchInputChange, value } = usePushCompaniesSearchTextInput();

  return (
    <div className="admin-search__search-input">
      <SearchInput handleInputChange={handleSearchInputChange} value={value} />
    </div>
  );
};

export default PushCompaniesSearch;
