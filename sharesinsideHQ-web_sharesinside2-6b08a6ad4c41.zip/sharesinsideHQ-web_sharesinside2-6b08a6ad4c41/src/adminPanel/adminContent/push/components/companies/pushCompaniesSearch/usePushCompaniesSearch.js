import { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  removePushCompaniesFilters,
  savePushCompaniesSearch,
  savePushCompaniesFilters,
} from 'adminPanel/adminContent/push/redux/actions/pushCompaniesFiltersActions';
import { debounce } from 'lodash';
import usePushCompaniesFilters from './usePushCompaniesFilters';

const usePushCompaniesSearch = () => {
  const dispatch = useDispatch();

  const [isAdvancedSearchVisible, setAdvancedSearchVisible] = useState(false);

  const resultsNumber = useSelector(
    (state) => state.pushCompanies.resultsNumber,
  );

  const {
    pushCompaniesFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  } = usePushCompaniesFilters();

  const toggleAdvancedSearch = () => {
    setAdvancedSearchVisible(!isAdvancedSearchVisible);
  };

  const clearActiveFilters = () => {
    dispatch(removePushCompaniesFilters());
  };

  const handleFilterUsage = (values, category) => {
    dispatch(
      savePushCompaniesFilters(values.length > 0 ? values : { category }),
    );
  };

  const handleFilterRemoveClick = (label, category) => {
    const filteredOut = pushCompaniesFilters[category].filter(
      (el) => el.label !== label,
    );
    dispatch(
      savePushCompaniesFilters(
        filteredOut.length > 0 ? filteredOut : { category },
      ),
    );
  };

  return {
    resultsNumber,
    toggleAdvancedSearch,
    isAdvancedSearchVisible,
    clearActiveFilters,
    activeFiltersList,
    pushCompaniesFilters,
    handleFilterRemoveClick,
    isRemoveFiltersButtonVisible,
    handleFilterUsage,
  };
};

const usePushCompaniesSearchTextInput = () => {
  const dispatch = useDispatch();

  const search = useSelector((state) => state.pushCompaniesFilters.search);
  const [value, setValue] = useState(search);

  const debouncedSavePushCompaniesSearch = useCallback(
    debounce(
      (searchText) => dispatch(savePushCompaniesSearch(searchText)),
      500,
    ),
    [],
  );

  const handleSearchInputChange = useCallback(
    (newText) => {
      setValue(newText);
      debouncedSavePushCompaniesSearch(newText);
    },
    [debouncedSavePushCompaniesSearch],
  );

  return {
    handleSearchInputChange,
    value,
  };
};

export { usePushCompaniesSearch, usePushCompaniesSearchTextInput };
