import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPushCompanies } from 'adminPanel/adminContent/push/redux/actions/pushCompaniesActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const pushCompaniesFilters = useSelector(
    (state) => state.pushCompaniesFilters,
  );

  useEffect(() => {
    dispatch(fetchPushCompanies(1));
  }, [
    dispatch,
    pushCompaniesFilters.sector,
    pushCompaniesFilters.country,
    pushCompaniesFilters.continent,
    pushCompaniesFilters.industry,
    pushCompaniesFilters.relations,
    pushCompaniesFilters.search,
  ]);

  return null;
};

export default DataLoader;
