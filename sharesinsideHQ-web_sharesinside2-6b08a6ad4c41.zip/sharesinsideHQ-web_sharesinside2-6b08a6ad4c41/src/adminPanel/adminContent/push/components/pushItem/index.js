import React from 'react';
import AcceptCheckbox from 'common/components/acceptCheckbox';

const itemStatusClass = (notified) =>
  notified
    ? 'push__item-name push__item-name_notified'
    : 'push__item-name push__item-name_new';

const PushItem = ({ item, isSelected, handleCheckboxClick }) => {
  return (
    <tr className="push__item-row">
      <td>
        <span className="push__item-name">{item.name}</span>
      </td>
      <td>
        <span className={itemStatusClass(item.notified)}>
          {item.notified ? 'Notified' : 'New'}
        </span>
      </td>
      <td>
        <AcceptCheckbox
          name={item.id}
          id={item.id}
          onChange={handleCheckboxClick}
          value={item.id}
          checked={isSelected}
        />
      </td>
    </tr>
  );
};

export default PushItem;
