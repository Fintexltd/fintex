import React from 'react';
import './index.scss';

const SendButton = ({ handleClick, description }) => (
  <button className="send-button" onClick={handleClick}>
    {description}
  </button>
);

export default SendButton;
