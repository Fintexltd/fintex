import { useCallback, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  fetchPushFundsManagers,
  sendFundsManagersPushNotifications,
} from 'adminPanel/adminContent/push/redux/actions/pushFundsManagersActions';

import { savePushFundsManagersFilters as savePushFundsManagersFiltersAction } from 'adminPanel/adminContent/push/redux/actions/pushFundsManagersFiltersActions';

const usePushEquities = () => {
  const dispatch = useDispatch();
  const pushFundsManagers = useSelector(
    (state) => state.pushFundsManagers.list,
  );
  const [selectedFundsManagers, setSelectedFundsManagers] = useState([]);

  const meta = useSelector((state) => state.pushFundsManagers.meta);
  const resultsNumber = useSelector(
    (state) => state.pushFundsManagers.resultsNumber,
  );

  useEffect(() => {
    setSelectedFundsManagers([]);
  }, [pushFundsManagers]);

  const getPushFundsManagers = useCallback(
    (page = 1) => {
      dispatch(fetchPushFundsManagers(page));
    },
    [dispatch],
  );

  const savePushFundsManagersFilters = (filters) => {
    dispatch(savePushFundsManagersFiltersAction(filters));
  };

  const handleCheckboxClick = (e) => {
    const checkedItems = [...selectedFundsManagers];
    const { checked, value } = e.target;
    const id = Number(value);
    if (checked) {
      checkedItems.push(id);
    } else {
      const index = checkedItems.indexOf(id);
      checkedItems.splice(index, 1);
    }
    setSelectedFundsManagers(checkedItems);
  };

  const sendPushNotifications = () => {
    if (selectedFundsManagers.length) {
      dispatch(sendFundsManagersPushNotifications(selectedFundsManagers));
    }
  };

  const isSelected = (id) => selectedFundsManagers.includes(id);

  return {
    getPushFundsManagers,
    pushFundsManagers,
    meta,
    resultsNumber,
    savePushFundsManagersFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  };
};

export default usePushEquities;
