import React from 'react';
import usePushFundsManagers from './usePushFundsManagers';
import PushFundsManagersSearch from '../pushFundsManagersSearch';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import PushFundsManagersPagination from './PushFundsManagersPagination';
import DataLoader from './dataLoader';
import PushItem from '../../pushItem';
import SendButton from '../../sendButton';

const PushFundsManagers = () => {
  const {
    pushFundsManagers,
    getPushFundsManagers,
    resultsNumber,
    meta,
    savePushFundsManagersFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  } = usePushFundsManagers();

  return (
    <>
      <DataLoader />
      <PushFundsManagersSearch />
      <div className="push__button-container">
        <SendButton
          handleClick={sendPushNotifications}
          description="SEND PUSH NOTIFICATION"
        />
      </div>
      <div className="push__table-container">
        <table className="push__table">
          <thead className="push__thead">
            <tr>
              <th>Fund-Manager</th>
              <th>Status</th>
              <th>Send notification?</th>
            </tr>
          </thead>
          <tbody>
            {pushFundsManagers.map((fundsManager) => (
              <PushItem
                key={fundsManager.id}
                item={fundsManager}
                handleCheckboxClick={handleCheckboxClick}
                isSelected={isSelected(fundsManager.id)}
              />
            ))}
          </tbody>
        </table>
        <LoadingIndicator />
      </div>
      <NoDataInfo />
      <PushFundsManagersPagination
        meta={meta}
        resultsNumber={resultsNumber}
        saveFilters={savePushFundsManagersFilters}
        getResults={getPushFundsManagers}
      />
    </>
  );
};

export default PushFundsManagers;
