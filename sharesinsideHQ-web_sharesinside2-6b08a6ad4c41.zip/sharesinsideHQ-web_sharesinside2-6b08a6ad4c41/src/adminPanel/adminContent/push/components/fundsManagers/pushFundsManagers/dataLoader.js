import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPushFundsManagers } from 'adminPanel/adminContent/push/redux/actions/pushFundsManagersActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const pushFundsManagersFilters = useSelector(
    (state) => state.pushFundsManagersFilters,
  );

  useEffect(() => {
    dispatch(fetchPushFundsManagers(1));
  }, [
    dispatch,
    pushFundsManagersFilters.fundsManagerCountry,
    pushFundsManagersFilters.fundsManagerCountry,
    pushFundsManagersFilters.fundContinent,
    pushFundsManagersFilters.currency,
    pushFundsManagersFilters.fundType,
    pushFundsManagersFilters.fundCountry,
    pushFundsManagersFilters.activePassive,
    pushFundsManagersFilters.relations,
    pushFundsManagersFilters.search,
  ]);

  return null;
};

export default DataLoader;
