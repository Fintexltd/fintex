import React from 'react';
import useNoDataInfo from './useNoDataInfo';

const NoDataInfo = () => {
  const { resultsNumber, isAnyFilterSelected } = useNoDataInfo();

  return isAnyFilterSelected && resultsNumber === 0 ? (
    <div className="push__empty-list">
      <p className="push__empty-list-message">
        There are no fund-Managers matching these criteria
      </p>
    </div>
  ) : null;
};

export default NoDataInfo;
