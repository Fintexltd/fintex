import React from 'react';
import ClearFiltersButton from 'common/components/clearFiltersButton';
import ClearFiltersIconButton from 'common/components/clearFiltersIconButton';
import ToggleMoreFiltersButton from 'common/components/toggleMoreFiltersButton';
import ToggleMoreFiltersIconButton from 'common/components/toggleMoreFiltersIconButton';
import SearchInput from 'common/components/searchInput';
import MultiSelect from 'common/components/customSelect/multiSelect';
import ActiveFiltersList from 'common/components/activeFiltersList';
import SearchResultsCounter from 'common/components/searchResultsCounter';
import { getFundsManagersRelationsList } from 'common/utils/relationsListUtils';
import 'adminPanel/adminContent/common/styles/search.scss';
import {
  usePushFundsManagersSearch,
  usePushFundsManagersSearchTextInput,
} from './usePushFundsManagersSearch';
import PushFundsManagersAdvancedSearch from '../pushFundsManagersAdvancedSearch';

const relationsList = getFundsManagersRelationsList();

const PushFundsManagersSearch = () => {
  const {
    activeFiltersList,
    clearActiveFilters,
    isAdvancedSearchVisible,
    isRemoveFiltersButtonVisible,
    resultsNumber,
    toggleAdvancedSearch,
    pushFundsManagersFilters,
    handleFilterRemoveClick,
    handleFilterUsage,
  } = usePushFundsManagersSearch();

  return (
    <div className="admin-search">
      <div className="admin-search__top">
        <div className="admin-search__top-left">
          <PushFundsManagersSearchTextInput />
          <div className="admin-search__relation-filter-container">
            <MultiSelect
              options={relationsList}
              description="Relation"
              onChange={handleFilterUsage}
              value={pushFundsManagersFilters.relations}
              category="relations"
            />
          </div>
          <div className="admin-search__filters-button--text">
            <ToggleMoreFiltersButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
          <div className="admin-search__filters-button--icon">
            <ToggleMoreFiltersIconButton
              handleToggleMoreFiltersClick={toggleAdvancedSearch}
              isMoreFiltersVisible={isAdvancedSearchVisible}
            />
          </div>
        </div>
        {isRemoveFiltersButtonVisible && (
          <div className="admin-search__clear-filters-button">
            <div className="admin-search__clear-filters-text-button">
              <ClearFiltersButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
            <div className="admin-search__clear-filters-icon-button">
              <ClearFiltersIconButton
                handleClearFiltersClick={clearActiveFilters}
              />
            </div>
          </div>
        )}
      </div>
      {isAdvancedSearchVisible && (
        <PushFundsManagersAdvancedSearch
          pushFundsManagersFilters={pushFundsManagersFilters}
          handleFilterUsage={handleFilterUsage}
        />
      )}
      <div className="admin-search__results-container">
        <div className="admin-search__results">
          <SearchResultsCounter resultsNumber={resultsNumber} />
        </div>
        {activeFiltersList.length > 0 && (
          <ActiveFiltersList
            activeFiltersList={activeFiltersList}
            handleFilterRemoveClick={handleFilterRemoveClick}
          />
        )}
      </div>
    </div>
  );
};

const PushFundsManagersSearchTextInput = () => {
  const {
    handleSearchInputChange,
    value,
  } = usePushFundsManagersSearchTextInput();

  return (
    <div className="admin-search__search-input">
      <SearchInput handleInputChange={handleSearchInputChange} value={value} />
    </div>
  );
};

export default PushFundsManagersSearch;
