import { useSelector } from 'react-redux';
import usePushFundsManagersFilters from '../pushFundsManagersSearch/usePushFundsManagersFilters';

const useNoDataInfo = () => {
  const resultsNumber = useSelector(
    (state) => state.pushFundsManagers.resultsNumber,
  );

  const {
    isRemoveFiltersButtonVisible,
    pushFundsManagersFilters,
  } = usePushFundsManagersFilters();

  const isAnyFilterSelected =
    isRemoveFiltersButtonVisible || pushFundsManagersFilters.search;

  return {
    resultsNumber,
    isAnyFilterSelected,
  };
};

export default useNoDataInfo;
