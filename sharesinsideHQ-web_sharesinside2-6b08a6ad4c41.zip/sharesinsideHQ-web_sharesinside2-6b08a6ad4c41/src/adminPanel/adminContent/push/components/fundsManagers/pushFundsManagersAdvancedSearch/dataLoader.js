import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import fetchCountriesList from 'common/redux/actions/countriesListActions';
import fetchContinentsList from 'common/redux/actions/continentsListActions';
import fetchFundTypesList from 'common/redux/actions/fundTypesListActions';
import fetchCurrenciesList from 'common/redux/actions/currenciesListActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const countries = useSelector((state) => state.countries.list);
  const continents = useSelector((state) => state.continents.list);
  const fundTypes = useSelector((state) => state.fundTypes.list);
  const currencies = useSelector((state) => state.currencies.list);

  useEffect(() => {
    if (!countries) dispatch(fetchCountriesList());
  }, [dispatch, countries]);

  useEffect(() => {
    if (!continents) dispatch(fetchContinentsList());
  }, [dispatch, continents]);

  useEffect(() => {
    if (!fundTypes) dispatch(fetchFundTypesList());
  }, [dispatch, fundTypes]);

  useEffect(() => {
    if (!currencies) dispatch(fetchCurrenciesList());
  }, [dispatch, currencies]);

  return null;
};

export default DataLoader;
