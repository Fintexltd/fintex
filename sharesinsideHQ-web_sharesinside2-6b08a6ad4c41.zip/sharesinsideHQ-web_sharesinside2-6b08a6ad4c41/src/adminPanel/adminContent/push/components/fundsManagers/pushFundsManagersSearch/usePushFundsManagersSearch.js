import { useState, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  removePushFundsManagersFilters,
  savePushFundsManagersSearch,
  savePushFundsManagersFilters,
} from 'adminPanel/adminContent/push/redux/actions/pushFundsManagersFiltersActions';
import { debounce } from 'lodash';
import usePushFundsManagersFilters from './usePushFundsManagersFilters';

const usePushFundsManagersSearch = () => {
  const dispatch = useDispatch();

  const [isAdvancedSearchVisible, setAdvancedSearchVisible] = useState(false);

  const resultsNumber = useSelector(
    (state) => state.pushFundsManagers.resultsNumber,
  );

  const {
    pushFundsManagersFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  } = usePushFundsManagersFilters();

  const toggleAdvancedSearch = () => {
    setAdvancedSearchVisible(!isAdvancedSearchVisible);
  };

  const clearActiveFilters = () => {
    dispatch(removePushFundsManagersFilters());
  };

  const handleFilterUsage = (values, category) => {
    dispatch(
      savePushFundsManagersFilters(values.length > 0 ? values : { category }),
    );
  };

  const handleFilterRemoveClick = (label, category) => {
    const filteredOut = pushFundsManagersFilters[category].filter(
      (el) => el.label !== label,
    );
    dispatch(
      savePushFundsManagersFilters(
        filteredOut.length > 0 ? filteredOut : { category },
      ),
    );
  };

  return {
    resultsNumber,
    toggleAdvancedSearch,
    isAdvancedSearchVisible,
    clearActiveFilters,
    activeFiltersList,
    pushFundsManagersFilters,
    handleFilterRemoveClick,
    isRemoveFiltersButtonVisible,
    handleFilterUsage,
  };
};

const usePushFundsManagersSearchTextInput = () => {
  const dispatch = useDispatch();

  const search = useSelector((state) => state.pushFundsManagersFilters.search);
  const [value, setValue] = useState(search);

  const debouncedSavePushFundsManagersSearch = useCallback(
    debounce(
      (searchText) => dispatch(savePushFundsManagersSearch(searchText)),
      500,
    ),
    [],
  );

  const handleSearchInputChange = useCallback(
    (newText) => {
      setValue(newText);
      debouncedSavePushFundsManagersSearch(newText);
    },
    [debouncedSavePushFundsManagersSearch],
  );

  return {
    handleSearchInputChange,
    value,
  };
};

export { usePushFundsManagersSearch, usePushFundsManagersSearchTextInput };
