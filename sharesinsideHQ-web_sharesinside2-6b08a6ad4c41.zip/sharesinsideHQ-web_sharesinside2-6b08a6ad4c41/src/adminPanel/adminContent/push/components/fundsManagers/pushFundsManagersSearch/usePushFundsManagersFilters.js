import { useMemo } from 'react';
import { useSelector } from 'react-redux';

const usePushFundsManagersFilters = () => {
  const pushFundsManagersFilters = useSelector(
    (state) => state.pushFundsManagersFilters,
  );

  const activeFiltersList = useMemo(
    () => [
      ...pushFundsManagersFilters.fundsManagerContinent,
      ...pushFundsManagersFilters.fundsManagerCountry,
      ...pushFundsManagersFilters.fundContinent,
      ...pushFundsManagersFilters.currency,
      ...pushFundsManagersFilters.fundType,
      ...pushFundsManagersFilters.fundCountry,
      ...pushFundsManagersFilters.activePassive,
      ...pushFundsManagersFilters.relations,
    ],
    [
      pushFundsManagersFilters.fundsManagerContinent,
      pushFundsManagersFilters.fundsManagerCountry,
      pushFundsManagersFilters.fundContinent,
      pushFundsManagersFilters.currency,
      pushFundsManagersFilters.fundType,
      pushFundsManagersFilters.fundCountry,
      pushFundsManagersFilters.activePassive,
      pushFundsManagersFilters.relations,
    ],
  );

  const isRemoveFiltersButtonVisible = activeFiltersList.length > 0;

  return {
    pushFundsManagersFilters,
    activeFiltersList,
    isRemoveFiltersButtonVisible,
  };
};

export default usePushFundsManagersFilters;
