import React from 'react';
import 'adminPanel/adminContent/common/styles/advancedSearch.scss';
import CountryFilter from 'adminPanel/adminContent/common/components/filters/CountryFilter';
import ContinentFilter from 'adminPanel/adminContent/common/components/filters/ContinentFilter';
import FundTypeFilter from 'adminPanel/adminContent/common/components/filters/FundTypeFilter';
import CurrencyFilter from 'adminPanel/adminContent/common/components/filters/CurrencyFilter';
import ActivePassiveFilter from 'adminPanel/adminContent/common/components/filters/ActivePassiveFilter';
import DataLoader from './dataLoader';

const PushFundsManagersAdvancedSearch = ({
  pushFundsManagersFilters,
  handleFilterUsage,
}) => {
  return (
    <div className="admin-advanced-search">
      <DataLoader />
      <div className="admin-advanced-search__filters">
        <ContinentFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.fundsManagerContinent}
          description="Fund-Manager Continent"
          category="fundsManagerContinent"
        />
        <CountryFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.fundsManagerCountry}
          description="Fund-Manager Country"
          category="fundsManagerCountry"
        />
        <ActivePassiveFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.activePassive}
        />
      </div>
      <div className="admin-advanced-search__filters">
        <ContinentFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.fundContinent}
          description="Funds Continent"
          category="fundContinent"
        />
        <CountryFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.fundCountry}
          description="Funds Country"
          category="fundCountry"
        />
        <FundTypeFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.fundType}
        />
        <CurrencyFilter
          handleFilterUsage={handleFilterUsage}
          value={pushFundsManagersFilters.currency}
        />
      </div>
    </div>
  );
};

export default PushFundsManagersAdvancedSearch;
