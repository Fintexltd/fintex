import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import Page404Loader from 'common/components/Page404Loader';
import PushNavigation from '../pushNavigation';
import PushCompanies from '../companies/pushCompanies';
import PushStartups from '../startups/pushStartups';
import PushFundsManagers from '../fundsManagers/pushFundsManagers';
import './index.scss';

const Push = () => (
  <div className="push">
    <h1 className="push__heading">Manage Push Notifications</h1>
    <PushNavigation />
    <Switch>
      <Redirect
        exact
        from="/admin/management/push"
        to="/admin/management/push/equities"
      />
      <Route
        exact
        path="/admin/management/push/equities"
        component={PushCompanies}
      />
      <Route
        exact
        path="/admin/management/push/startups"
        component={PushStartups}
      />
      <Route
        exact
        path="/admin/management/push/funds"
        component={PushFundsManagers}
      />
      <Route component={Page404Loader} />
    </Switch>
  </div>
);

export default Push;
