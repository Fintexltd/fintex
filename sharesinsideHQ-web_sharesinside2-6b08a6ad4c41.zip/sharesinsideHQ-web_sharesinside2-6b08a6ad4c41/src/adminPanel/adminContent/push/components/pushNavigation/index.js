import React from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import usePushNavigation from './usePushNavigation';
import './index.scss';

// NOTE: Here I define sizes necessary to calculate correct investors navigation
// width
const barAndMarginsWidth = 420;
const largeBreakpointWidth = 992;
const wideScreen = 1540;

const PushNavigation = () => {
  const { width, navRef } = usePushNavigation();

  if (window.innerWidth < 500) {
    navRef.current.scrollLeft = '140';
  }
  return (
    <div
      ref={navRef}
      className="push-navigation"
      style={{
        width:
          width >= largeBreakpointWidth && width < wideScreen
            ? width - barAndMarginsWidth
            : '100%',
      }}
    >
      <LinkContainer
        to="/admin/management/push/equities"
        replace
        className="push-navigation__item"
        activeClassName="push-navigation__item--active"
      >
        <span>Equities</span>
      </LinkContainer>
      <LinkContainer
        to="/admin/management/push/startups"
        replace
        className="push-navigation__item"
        activeClassName="push-navigation__item--active"
      >
        <span>Startups</span>
      </LinkContainer>
      <LinkContainer
        to="/admin/management/push/funds"
        replace
        className="push-navigation__item"
        activeClassName="push-navigation__item--active"
      >
        <span>Fund-Managers</span>
      </LinkContainer>
    </div>
  );
};

export default PushNavigation;
