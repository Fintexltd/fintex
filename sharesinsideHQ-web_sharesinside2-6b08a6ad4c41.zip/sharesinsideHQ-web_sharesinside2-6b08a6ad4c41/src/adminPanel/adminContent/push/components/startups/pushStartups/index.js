import React from 'react';
import usePushStartups from './usePushStartups';
import PushStartupsSearch from '../pushStartupsSearch';
import LoadingIndicator from './LoadingIndicator';
import NoDataInfo from './NoDataInfo';
import PushStartupsPagination from './PushStartupsPagination';
import DataLoader from './dataLoader';
import PushItem from '../../pushItem';
import SendButton from '../../sendButton';

const PushStartups = () => {
  const {
    pushStartups,
    getPushStartups,
    resultsNumber,
    meta,
    savePushStartupsFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  } = usePushStartups();

  return (
    <>
      <DataLoader />
      <PushStartupsSearch />
      <div className="push__button-container">
        <SendButton
          handleClick={sendPushNotifications}
          description="SEND PUSH NOTIFICATION"
        />
      </div>
      <div className="push__table-container">
        <table className="push__table">
          <thead className="push__thead">
            <tr>
              <th>Startup</th>
              <th>Status</th>
              <th>Send notification?</th>
            </tr>
          </thead>
          <tbody>
            {pushStartups.map((startup) => (
              <PushItem
                key={startup.id}
                item={startup}
                handleCheckboxClick={handleCheckboxClick}
                isSelected={isSelected(startup.id)}
              />
            ))}
          </tbody>
        </table>
        <LoadingIndicator />
      </div>
      <NoDataInfo />
      <PushStartupsPagination
        meta={meta}
        resultsNumber={resultsNumber}
        saveFilters={savePushStartupsFilters}
        getResults={getPushStartups}
      />
    </>
  );
};

export default PushStartups;
