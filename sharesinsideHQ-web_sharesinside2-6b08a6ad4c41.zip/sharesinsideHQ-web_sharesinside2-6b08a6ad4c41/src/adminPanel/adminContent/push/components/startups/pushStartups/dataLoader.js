import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPushStartups } from 'adminPanel/adminContent/push/redux/actions/pushStartupsActions';

const DataLoader = () => {
  const dispatch = useDispatch();

  const pushStartupsFilters = useSelector((state) => state.pushStartupsFilters);

  useEffect(() => {
    dispatch(fetchPushStartups(1));
  }, [
    dispatch,
    pushStartupsFilters.country,
    pushStartupsFilters.category,
    pushStartupsFilters.continent,
    pushStartupsFilters.equityFund,
    pushStartupsFilters.relations,
    pushStartupsFilters.search,
  ]);

  return null;
};

export default DataLoader;
