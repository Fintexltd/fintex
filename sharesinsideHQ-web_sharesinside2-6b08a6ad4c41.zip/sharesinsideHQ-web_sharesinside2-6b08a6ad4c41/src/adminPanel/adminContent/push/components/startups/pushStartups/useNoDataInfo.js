import { useSelector } from 'react-redux';
import usePushStartupsFilters from '../pushStartupsSearch/usePushStartupsFilters';

const useNoDataInfo = () => {
  const resultsNumber = useSelector(
    (state) => state.pushStartups.resultsNumber,
  );

  const {
    isRemoveFiltersButtonVisible,
    pushStartupsFilters,
  } = usePushStartupsFilters();

  const isAnyFilterSelected =
    isRemoveFiltersButtonVisible || pushStartupsFilters.search;

  return {
    resultsNumber,
    isAnyFilterSelected,
  };
};

export default useNoDataInfo;
