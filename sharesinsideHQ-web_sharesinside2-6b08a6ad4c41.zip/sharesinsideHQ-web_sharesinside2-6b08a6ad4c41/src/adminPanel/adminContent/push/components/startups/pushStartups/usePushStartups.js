import { useCallback, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchPushStartups,
  sendStartupsPushNotifications,
} from 'adminPanel/adminContent/push/redux/actions/pushStartupsActions';
import { savePushStartupsFilters as savePushStartupsFiltersAction } from 'adminPanel/adminContent/push/redux/actions/pushStartupsFiltersActions';

const usePushEquities = () => {
  const dispatch = useDispatch();
  const pushStartups = useSelector((state) => state.pushStartups.list);
  const [selectedStartups, setSelectedStartups] = useState([]);

  const meta = useSelector((state) => state.pushStartups.meta);
  const resultsNumber = useSelector(
    (state) => state.pushStartups.resultsNumber,
  );

  useEffect(() => {
    setSelectedStartups([]);
  }, [pushStartups]);

  const getPushStartups = useCallback(
    (page = 1) => {
      dispatch(fetchPushStartups(page));
    },
    [dispatch],
  );

  const savePushStartupsFilters = (filters) => {
    dispatch(savePushStartupsFiltersAction(filters));
  };

  const handleCheckboxClick = (e) => {
    const checkedItems = [...selectedStartups];
    const { checked, value } = e.target;
    const id = Number(value);
    if (checked) {
      checkedItems.push(id);
    } else {
      const index = checkedItems.indexOf(id);
      checkedItems.splice(index, 1);
    }
    setSelectedStartups(checkedItems);
  };

  const sendPushNotifications = () => {
    if (selectedStartups.length) {
      dispatch(sendStartupsPushNotifications(selectedStartups));
    }
  };

  const isSelected = (id) => selectedStartups.includes(id);

  return {
    getPushStartups,
    pushStartups,
    meta,
    resultsNumber,
    savePushStartupsFilters,
    handleCheckboxClick,
    isSelected,
    sendPushNotifications,
  };
};

export default usePushEquities;
