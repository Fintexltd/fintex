import axios from 'axios';

const sendStartupPushNotificationsRequest = (ids) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/send`,
    {
      notificable_type: 'startup',
      notificable_ids: ids,
    },
  );

const getPushStartupsRequest = (params) =>
  axios.get(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/startups`,
    {
      params,
    },
  );

export { sendStartupPushNotificationsRequest, getPushStartupsRequest };
