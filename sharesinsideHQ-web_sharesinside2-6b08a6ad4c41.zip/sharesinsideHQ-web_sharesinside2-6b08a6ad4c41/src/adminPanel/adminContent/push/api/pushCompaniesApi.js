import axios from 'axios';

const sendCompanyPushNotificationsRequest = (ids) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/send`,
    {
      notificable_type: 'company',
      notificable_ids: ids,
    },
  );

const getPushCompaniesRequest = (params) =>
  axios.get(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/companies`,
    {
      params,
    },
  );

export { sendCompanyPushNotificationsRequest, getPushCompaniesRequest };
