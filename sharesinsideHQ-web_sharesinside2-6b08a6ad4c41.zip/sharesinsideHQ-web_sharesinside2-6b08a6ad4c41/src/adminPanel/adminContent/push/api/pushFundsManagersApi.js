import axios from 'axios';

const sendFundsManagerPushNotificationsRequest = (ids) =>
  axios.post(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/send`,
    {
      notificable_type: 'funds_manager',
      notificable_ids: ids,
    },
  );

const getPushFundsManagersRequest = (params) =>
  axios.get(
    `${process.env.REACT_APP_API_URL}/admin/manage-push-notification/funds-managers`,
    {
      params,
    },
  );

export {
  sendFundsManagerPushNotificationsRequest,
  getPushFundsManagersRequest,
};
