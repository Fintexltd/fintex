<?php

function loadConfig()
{
    $fileName = ".env";
    $config = [];

    $file = fopen($fileName, "r");

    if ($file) {
        while (!feof($file)) {
            $line = fgets($file);
            if (!preg_match('/^#/', $line) && preg_match('/=/', $line)) {
                $array = explode('=', $line, 2);
                $config[trim($array[0])] = trim($array[1]);
            }
        }
        fclose($file);
    }

    return $config;
}

function config(array $config, $key, $default = null)
{
    return array_key_exists($key, $config) ? $config[$key] : $default;
}

function getIndexContent()
{
    $file = 'index.html';

    $index = fopen($file, "r") or die("Unable to open file!");
    $content = fread($index, filesize($file));
    fclose($index);

    return $content;
}

function redirectFromSocialMedia($newsId, $socialShareKey)
{
    global $config;

    preg_match('/(?<=news\/)([0-9]+)\/([a-zA-Z0-9]+)/', $_SERVER['REQUEST_URI'], $urlParts);
    $urlKey = count($urlParts)===3 ? $urlParts[2] : '';

    if(strlen($urlKey)!==16 && strlen($socialShareKey)===16)
    {
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

        if (
            (strpos($userAgent, "facebookexternalhit") !== false ||          
            strpos($userAgent, "Facebot") !== false || 
            strpos($userAgent, "LinkedInBot") !== false || 
            strpos($userAgent, "Twitterbot") !== false)
            ||
            (strpos($referer, "facebook.com") !== false ||          
            strpos($referer, "linkedin.com") !== false || 
            strpos($referer, "twitter.com") !== false ||
            strpos($referer, "t.co") !== false)
        ) {
            //header('HTTP/1.1 301 Moved Permanently');
            header('Location: '.rtrim(config($config, 'APP_URL', 'https://www.sharesinside.com'), '/').'/news/'.$newsId.'/'.$socialShareKey);
            exit;
        }
    }
}

$config = loadConfig();

$content = getIndexContent();

$additionalMeta = '';

$regex = '/(?<=news\/)\d+/';

if (preg_match($regex, $_SERVER['REQUEST_URI'], $id)) {
    $param = array_pop($id);

    $command = 'app:news:meta';

    $backendDir = rtrim(config($config, 'BACKEND_DIR', '/var/www/2.sharesinside.com/api/'), '/');
    $php = config($config, 'PHP', 'php');

    $backendData = exec("$php $backendDir/artisan $command $param");
    $data = explode('<!--', $backendData);

    if(count($data)===2)
    {
        $additionalMeta = $data[0];
        $socialShareKey = trim(str_replace('-->', '', $data[1]));
        redirectFromSocialMedia($param, $socialShareKey);
    }

    //if (!preg_match('/^<meta property/', $additionalMeta)) {
    //    $additionalMeta = '';
    //}
}

echo str_replace('</head><body>', "$additionalMeta</head><body>", $content);
