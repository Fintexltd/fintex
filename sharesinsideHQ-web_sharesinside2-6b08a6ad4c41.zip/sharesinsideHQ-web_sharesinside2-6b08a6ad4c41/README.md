# SharesInside v2

Web app developed with React 16.3 and Redux 4.0 with redux-thunk middleware.

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app), so everything in [CRA user guide](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md) applies.

Project is available here: https://www.sharesinside.gegroup.pl/

## How to install

Clone repository and run `npm install`.

## Scripts / helpers

`npm start` runs the app in dev mode on http://localhost:3000.
It autoreloads on file changes, displays build errors in console and compiles scss to css.

`npm run build:development` builds app with development config to `./build`.
`npm run build:production` builds app with production config to `./build`.

Important!
Before you run a build command make sure that you have all .env files created and filled with correct data.
In order to provide correct meta tags for shared news you should also copy .env.public.example (as .env) and .htaccess to public directory and filled with correct data (NOTE: there is additional index.php file in public directory to provide correct meta tags for shared news).

Build is optimized, minified and filenames include hashes.

## Project structure, conventions, guidelines etc.

### Structure

There is a couple of files in `src/` directory with things like application entry point, routes etc., but other than that project is divided into modules, usually one application route meaning one module, but not necessary. There is also one 'special' directory called `common` in which you can find files related to application cross-cutting concerns and reusable components.

Every module should adhere to this structure:

```
├── api/
├── components/
├── containers/
├── hoc/
├── redux/
│   ├── actions/
│   ├── reducers/
│   ├── selectors/
│   └── types.js
├── utils/
├── validators/
├── constants.js
└── index.js
```

although not every module needs to contain all of these files/directories.

All tests should be placed in the same directory as tested file, in `__tests__` dir.

### Conventions and guidelines

API urls are set in .env file, which contrary to common convention should be commited to repo. These variables can be overriden locally, more info about that can be found in CRA user guide.

`./src` can be used as root path for absolute imports and such imports are highly encouraged - it improves understanding of component's dependencies and makes refactoring easier. The only exception is stylesheet, which should be imported as a relative path, since it must always be located next to component file and in case of moving component file without it's stylesheet relative path will raise compilation errors.

Every component should have PropTypes declared, as high in the file as possible - in case of class components, it can be a static property. These informations, apart from runtime type checking, serve as documentation and provide other developers with information what your component expects/requires. But, as important as this is, it's better to leave PropTypes out than to write half-baked ones - a lot of PropTypes errors in console makes debugging much harder. PropTypes like oneOf are sometimes useful, but do not overdo it - information that prop can be object, array, string or number is useless and if that's really the case you are doing something wrong.

Containers should not have any styles associated with them - they should render dumb components that take care of styling. The idea being that containers should contain logic and be concerned with how to get data and what do do with it, not how it's displayed. Components, on the other hand, should not care about where the data comes from (REST API, localStorage or user input), transforming it or anything else than displaying what they got from their parent and triggering functions, also passed to them from their parent. More about that [here](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0#.9gmxil6iw).

Every presentational component should have one top-level element with class name being equal to component's name, written in kebab-case. Every other styles regarding this component should be nested under this class name and selectors should be classes written with BEM methodology - using only classes helps manage specificity, always nesting them prevents styles from leaking outside component.

Forms validation should be done using Formik and Yup schema validation.

lint-staged and husky libraries provide git hook that runs prettier and eslint with --fix flag before each commit. This formats .scss and .js files and lints .js files.

If eslint finds errors or warnings that it can't fix, commit will fail. If for some reason there's a need for committing such files anyway, commit with flag --no-verify overrides it, but try to at least let prettier format the files you're commiting.

## State management

There is a `reduxUtils` file in `commons/utils` containing functions that help to reduce boilerplate needed to write redux-specific code, they should be used when writing new actions and reducers.

Actions should loosely follow Flux Standard Action spec (meaning the action shouldn't have other fields than type (which is mandatory), payload, error and meta). This is made easier with createActionCreator helper, additional helpers may be created if need arises.

Asynchronous actions are mostly handled with redux-thunk middleware. Such actions follow the same template - function calling API always dispatches request and either success or failure action. Request action isn't usually handled in reducer, but is a) useful for debugging purposes and b) makes it possible to show spinners and lock UI elements if such need arises very easily.

## Tips and Tricks

For Chrome and Firefox, there are two useful extensions:

[React dev tools](https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi)

[Redux dev tools](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd)

## Contributors

Mariusz Tabaszewski <mariusz.tabaszewski@kissdigital.com>

Michał Kaleta <michal.kaleta@kissdigital.com>

Grzegorz Kopaczek <grzegorz.kopaczek@gegroup.pl>
